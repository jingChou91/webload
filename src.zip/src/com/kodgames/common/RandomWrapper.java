package com.kodgames.common;

import java.util.Random;

public class RandomWrapper
{
	static Random rnd = new Random(System.currentTimeMillis());

	public static void SetRandomSeed(long seed)
	{
		rnd.setSeed(seed);
	}

	public static int NextInt(int n)
	{
		return rnd.nextInt(n);
	}

	public static float NextFloat()
	{
		return rnd.nextFloat();
	}

	public static float NextFloat(float value)
	{
		float result = rnd.nextFloat();
		return result * value;
	}
	
	
	//返回 [min,max] 区间的值
	public static int getRandInt(int min, int max) {
		if (min == max)
			return min;
		else {
			int temp = max;
			if (min > max) {
				max = min;
				min = temp;
			}
			int d = max - min;
			int randInt = rnd.nextInt(d + 1);
			return min + randInt;
		}
	}
}
