package com.kodgames.common;

// ZHD

public class Bit32 {

	private int bit32;

	public Bit32(int bit32)
	{
		if(bit32 >= 0)
		{
			this.bit32 = bit32;
		}
		else 
		{
			this.bit32 = 0;
		}
	}
	
	public int getBit32()
	{
		return bit32;
	}
	
	public void setBit32(int bit32)
	{
		if(bit32 >= 0)
		{
			this.bit32 = bit32;
		}
	}
	
	public int getValue(int index)
	{
		int value = bit32;
		value = value << (32 - index -1); //左移
		value = value >>>(32 - 1); //无符号右移
		return value;
	}
	
	//index位置置为1
	public void setValue(int index)
	{
		int value = 1;
		value = value << index;
		this.bit32 = this.bit32 | value;
	}
	//计算 bit32中1的个数
	public int getBit32Num()
	{
		int value = bit32;
		int num = 0;
		while(value != 0)
		{
			num += value & 1;
			value = value >>> 1;//无符号右移
		}
		return num;
	}
	
	//找到第一个为0的位置
	public int getFirstIndex()
	{
		int value = bit32;
		int index = 0;
		
		while( (value & 1) == 1 )
		{
			value = value >>>1;
			index++;
		}
		return index;
	}
	
	
//	public static void main(String[] args) {
//		int a = 1;
//		Bit32 bit32 = new Bit32(a);
//		System.out.print(bit32.getValue(0));
//		
//	}

}
