package com.kodgames.common;

import java.util.Calendar;

import ClientServerCommon._TimeDurationType;

/**
 * 关于时间的一些工具函数
 */
public class TimeUtility
{
	public static final long cMillisecondInSecend = 1000;
	public static final long cSecondInMinute = 60;
	public static final long cMinuteInHour = 60;
	public static final long cHourInDay = 24;
	public static final long cMillisecondInMinute = cMillisecondInSecend * cSecondInMinute;
	public static final long cMillisecondInHour = cMillisecondInMinute * cMinuteInHour;
	public static final long cMillisecondInDay = cMillisecondInHour * cHourInDay;

	/**
	 * 将一天中的时分秒转化为毫秒
	 */
	public static long getMillissecondOfDay(Calendar time)
	{
		return time.get(Calendar.HOUR_OF_DAY) * cMillisecondInHour + time.get(Calendar.MINUTE) * cMillisecondInMinute
			+ time.get(Calendar.SECOND) * cMillisecondInSecend + time.get(Calendar.MILLISECOND);
	}

	/**
	 * 基于充值类型,检查一个时间是否在两个时间段之内
	 */
	public static boolean isInTimeSpan(Calendar time, Calendar from, Calendar to, int timeDurationType)
	{
		long ms, fromMS, toMS;
		switch (timeDurationType)
		{
			case _TimeDurationType.Year:
				ms = time.get(Calendar.DAY_OF_YEAR) * cMillisecondInDay + getMillissecondOfDay(time);
				fromMS = from.get(Calendar.DAY_OF_YEAR) * cMillisecondInDay + getMillissecondOfDay(from);
				toMS = to.get(Calendar.DAY_OF_YEAR) * cMillisecondInDay + getMillissecondOfDay(to);
				break;

			case _TimeDurationType.Month:
				ms = time.get(Calendar.DATE) * cMillisecondInDay + getMillissecondOfDay(time);
				fromMS = from.get(Calendar.DATE) * cMillisecondInDay + getMillissecondOfDay(from);
				toMS = to.get(Calendar.DATE) * cMillisecondInDay + getMillissecondOfDay(to);
				break;

			case _TimeDurationType.Day:
				ms = getMillissecondOfDay(time);
				fromMS = getMillissecondOfDay(from);
				toMS = getMillissecondOfDay(to);
				break;

			case _TimeDurationType.Week:
				ms = (time.get(Calendar.DAY_OF_WEEK) - 1) * cMillisecondInDay + getMillissecondOfDay(time);
				fromMS = (from.get(Calendar.DAY_OF_WEEK) - 1) * cMillisecondInDay + getMillissecondOfDay(from);
				toMS = (to.get(Calendar.DAY_OF_WEEK) - 1) * cMillisecondInDay + getMillissecondOfDay(to);
				break;

			default:
				ms = getMillissecondOfDay(time);
				fromMS = getMillissecondOfDay(from);
				toMS = getMillissecondOfDay(to);
				break;
		}

		return ms > fromMS && ms <= toMS;
	}

	/**
	 * 判断两个时间点是否都在同一个时间段之内
	 */
	public static boolean isInSameTimeSpan(Calendar time1, Calendar time2, Calendar from, Calendar to,
		int timeDurationType)
	{
		if (isInTimeSpan(time1, from, to, timeDurationType) == false
			|| isInTimeSpan(time2, from, to, timeDurationType) == false)
			return false;

		Calendar fromTime1 = GetTimeBeforeTime(from, time1, timeDurationType);
		Calendar toTime1 = GetTimeAfterTime(to, time1, timeDurationType);
		return time2.getTimeInMillis() > fromTime1.getTimeInMillis() && time2.getTimeInMillis() <= toTime1.getTimeInMillis();
	}

	/**
	 * 按照时间周期类型,获取某个时间基于另一个时间之前的最近的时间点 例如 :
	 * 
	 * 当前时间是2014:5:20 20:01:50 基于 2014:5:19 的时间为 2013:5:20 20:01:50
	 * 
	 * 当前时间是2014:5:20 20:01:50 基于 2014:6:19 的时间为 2014:5:20 20:01:50
	 * 
	 * @param time 要获取的时间
	 * @param before 基准时间点
	 * @param timeDurationType 时间周期
	 */
	public static Calendar GetTimeBeforeTime(Calendar time, Calendar before, int timeDurationType)
	{
		Calendar retTime = Calendar.getInstance();
		switch (timeDurationType)
		{
			case _TimeDurationType.Year:
				// 以基准时间的年月日构造时间
				retTime.set(before.get(Calendar.YEAR), before.get(Calendar.MONTH), before.get(Calendar.DATE));
				// 以目标时间的time of day设置,
				retTime.add(Calendar.MILLISECOND, (int)getMillissecondOfDay(time));
				// 获取目标时间具体日期
				retTime.add(Calendar.DATE, time.get(Calendar.DAY_OF_YEAR) - before.get(Calendar.DAY_OF_YEAR));
				// 如果目标时间在基准时间之前, 向前计算一个周期
				if (retTime.getTimeInMillis() > before.getTimeInMillis())
					retTime.add(Calendar.YEAR, -1);
				break;

			case _TimeDurationType.Month:
				retTime.set(before.get(Calendar.YEAR), before.get(Calendar.MONTH), before.get(Calendar.DATE));
				retTime.add(Calendar.MILLISECOND, (int)getMillissecondOfDay(time));
				retTime.add(Calendar.DATE, time.get(Calendar.DATE) - before.get(Calendar.DATE));
				if (retTime.getTimeInMillis() > before.getTimeInMillis())
					retTime.add(Calendar.MONTH, -1);
				break;

			case _TimeDurationType.Day:
				retTime.set(before.get(Calendar.YEAR), before.get(Calendar.MONTH), before.get(Calendar.DATE));
				retTime.add(Calendar.MILLISECOND, (int)getMillissecondOfDay(time));
				if (retTime.getTimeInMillis() > before.getTimeInMillis())
					retTime.add(Calendar.DATE, -1);
				break;

			case _TimeDurationType.Week:
				retTime.set(before.get(Calendar.YEAR), before.get(Calendar.MONTH), before.get(Calendar.DATE));
				retTime.add(Calendar.MILLISECOND, (int)getMillissecondOfDay(time));
				retTime.add(Calendar.DATE, time.get(Calendar.DAY_OF_WEEK) - before.get(Calendar.DAY_OF_WEEK));
				if (retTime.getTimeInMillis() > before.getTimeInMillis())
					retTime.add(Calendar.DATE, -7);
				break;

			default:
				return null;
		}

		return retTime;
	}

	/**
	 * 按照时间周期类型,获取某个时间基于另一个时间之后的最近的时间点
	 * 
	 * @param time 要获取的时间
	 * @param before 基准时间点
	 * @param timeDurationType 时间周期
	 */
	public static Calendar GetTimeAfterTime(Calendar time, Calendar after, int timeDurationType)
	{
		Calendar retTime = Calendar.getInstance();
		switch (timeDurationType)
		{
			case _TimeDurationType.Year:
				// 以基准时间的年月日构造时间
				retTime.set(after.get(Calendar.YEAR), after.get(Calendar.MONTH), after.get(Calendar.DATE));
				// 以目标时间的time of day设置,
				retTime.add(Calendar.MILLISECOND, (int)getMillissecondOfDay(time));
				// 获取目标时间具体日期
				retTime.add(Calendar.DATE, time.get(Calendar.DAY_OF_YEAR) - after.get(Calendar.DAY_OF_YEAR));
				// 如果目标时间在基准时间之前, 向前计算一个周期
				if (retTime.getTimeInMillis() <= after.getTimeInMillis())
					retTime.add(Calendar.YEAR, 1);
				break;

			case _TimeDurationType.Month:
				retTime.set(after.get(Calendar.YEAR), after.get(Calendar.MONTH), after.get(Calendar.DATE));
				retTime.add(Calendar.MILLISECOND, (int)getMillissecondOfDay(time));
				retTime.add(Calendar.DATE, time.get(Calendar.DATE) - after.get(Calendar.DATE));
				if (retTime.getTimeInMillis() <= after.getTimeInMillis())
					retTime.add(Calendar.MONTH, 1);
				break;

			case _TimeDurationType.Day:
				retTime.set(after.get(Calendar.YEAR), after.get(Calendar.MONTH), after.get(Calendar.DATE));
				retTime.add(Calendar.MILLISECOND, (int)getMillissecondOfDay(time));
				if (retTime.getTimeInMillis() <= after.getTimeInMillis())
					retTime.add(Calendar.DATE, 1);
				break;

			case _TimeDurationType.Week:
				retTime.set(after.get(Calendar.YEAR), after.get(Calendar.MONTH), after.get(Calendar.DATE));
				retTime.add(Calendar.MILLISECOND, (int)getMillissecondOfDay(time));
				retTime.add(Calendar.DATE, time.get(Calendar.DAY_OF_WEEK) - after.get(Calendar.DAY_OF_WEEK));
				if (retTime.getTimeInMillis() <= after.getTimeInMillis())
					retTime.add(Calendar.DATE, 7);
				break;
		}

		return time;
	}
	
	public static void main(String[] args) throws Exception
	{
		Calendar c1 = Calendar.getInstance();
		c1.setTimeInMillis(1000000);
		assert getMillissecondOfDay(c1) == 1000000;
		
		Calendar c2 = Calendar.getInstance();
		Calendar c3 = Calendar.getInstance();
		Calendar c4 = Calendar.getInstance();
		c2.set(2010, 11, 12, 13, 14, 15);
		c3.set(2010, 12, 12, 13, 14, 15);
		c4.set(2010, 12, 12, 15, 14, 15);
		c4.set(2011, 12, 12, 15, 14, 15);
	}
}
