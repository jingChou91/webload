package com.kodgames.common;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Guid
{
	private static final Logger logger = LoggerFactory.getLogger(Guid.class);
	
	private long prefix;
	private long subffix;
	
	private Guid(long prefix, long subffix)
	{
		this.prefix = prefix;
		this.subffix = subffix;
	}
	
	public Guid()
	{
		UUID uuid = UUID.randomUUID();
		this.prefix = uuid.getMostSignificantBits();
		this.subffix = uuid.getLeastSignificantBits();
	}
	
	private Guid(String guid)
	{
		UUID uuid = UUID.fromString(guid);
		this.prefix = uuid.getMostSignificantBits();
		this.subffix = uuid.getLeastSignificantBits();
	}
	
	@Override
	public int hashCode()
	{
		UUID uuid = new UUID(this.prefix, this.subffix);
		return uuid.hashCode();
	}
	
	@Override
	public boolean equals(Object object)
	{
		if(object instanceof Guid)
		{
			Guid temp = (Guid)object;
			if(temp.prefix == this.prefix && temp.subffix == this.subffix)
			{
				return true;
			}
		}
		return false;
	}
	
	@Override
	public String toString()
	{
		UUID uuid = new UUID(this.prefix, this.subffix);
		return uuid.toString();
	}
	
	public Guid copy()
	{
		Guid guid = new Guid(this.prefix, this.subffix);
		return guid;
	}
	
	public static Guid genNewGuid(String guidString)
	{
		try 
		{
			Guid guid = new Guid(guidString);
			return guid;
		} 
		catch (Exception e) 
		{
			logger.error("String to GUID Failed, string = {}" , guidString);
		}

		return null;
	}
}
