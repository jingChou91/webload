package com.kodgames.common;

public class StateCollector
{
	protected boolean[] validAry;

	public void Initialize(int count)
	{
		Initialize(count, true);
	}

	public void Initialize(int count, boolean defaultState)
	{
		if (validAry == null || validAry.length != count)
		{
			validAry = new boolean[count];
		}

		for (int i = 0; i < count; ++i)
		{
			validAry[i] = defaultState;
		}
	}

	public boolean GetState(int idx)
	{
		return (boolean) validAry[idx];
	}

	public void SetState(int idx, boolean state)
	{
		validAry[idx] = state;
	}

	public int GetStateCount()
	{
		return validAry.length;
	}

	public int GetValidStateCount()
	{
		int count = 0;
		for (boolean state : validAry)
		{
			if (state == true)
			{
				count++;
			}
		}

		return count;
	}

	public int RandomAValidState()
	{
		// Get false 
		int validStateCount = GetValidStateCount();

		if (validStateCount > 0)
		{
			int result = RandomWrapper.NextInt(validStateCount);

			for (int i = 0, idx = 0; i < validAry.length; ++i)
			{
				if (validAry[i] == false)
				{
					continue;
				}

				if (idx == result)
				{
					validAry[i] = false;
					return i;
				}

				++idx;
			}
		}

		return -1;
	}

	public void RandomAValidState(int count)
	{
		if (count == -1)
		{
			return;
		}

		int validStateCount = GetValidStateCount();

		for (int idx = count; idx < validStateCount; idx++)
		{
			RandomAValidState();
		}
	}
}