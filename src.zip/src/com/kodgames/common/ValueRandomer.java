package com.kodgames.common;

import java.util.ArrayList;
import java.util.List;

public class ValueRandomer
{
	public ValueRandomer()
	{
		this.values = new ArrayList<>();
	}

	public void SetTotalValue(float newTotalValue, float minTotalValue)
	{
		SetTotalValue();

		// Make sure total value greater than min value
		if (minTotalValue > this.totalValue)
		{
			for (int i = 0; i < values.size(); i++)
			{
				float value = values.get(i).getFirst();
				if (value == 0)
				{
					continue;
				}

				// Increase value according to the weight in total value
				values.get(i).setFirst(minTotalValue * value / this.totalValue);
			}

			// Recalculate total value
			SetTotalValue();
		}

		// Make sure the sum of values is not greater than wanted totalValue
		this.totalValue = Math.max(this.totalValue, newTotalValue);
	}

	public void SetTotalValue()
	{
		this.totalValue = 0;

		for (int i = 0; i < values.size(); i++)
		{
			this.totalValue += values.get(i).getFirst();
		}
	}

	public void Clear()
	{
		values.clear();
	}

	public void addValue(float value, Object data)
	{
		values.add(new Pair<>(value, data));
	}

	public float GetValue(int idx)
	{
		return values.get(idx).getFirst();
	}

	public Object GetData(int idx)
	{
		return values.get(idx).getSecond();
	}
	
	//zhd add
	public void removeValue(int idx){
		values.remove(idx);
	}
	
	//txp add
	public boolean isEmpty()
	{
		return values.isEmpty();
	}
	
	

	public int Random()
	{
		float randomer = RandomWrapper.NextFloat(totalValue);
		float tempValue = 0;

		for (int i = 0; i < values.size(); i++)
		{
			tempValue += values.get(i).getFirst();
			if (randomer < tempValue)
			{
				return i;
			}
		}

		return -1;
	}

	public Object RandomData()
	{
		int idx = Random();
		if (idx == -1)
		{
			return null;
		}

		return GetData(idx);
	}
	
	/**
	 * 随机出一个结果，并将该结果从随机库中移除
	 */
	public Object RandomDataAndRemove()
	{
		int idx = Random();
		if (idx == -1)
		{
			return null;
		}
		
		Object randomData = GetData(idx);
		removeValue(idx);
		return randomData;
	}
	
	public int valueSize()
	{
		return values.size();
	}
	
	private List<Pair<Float, Object>> values;
	private float totalValue = 0;
}
