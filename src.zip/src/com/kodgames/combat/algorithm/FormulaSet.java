/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.algorithm;

import ClientServerCommon.AvatarAction;
import com.kodgames.corgi.gameconfiguration.MathParser;

public class FormulaSet
{
//	private HashMap<String, JEP> formulas = new HashMap<>();
	private MathParser parser = null;
	public FormulaSet()
	{
		parser = new MathParser();
	}
	
//	private boolean hasFormula(String expression)
//	{
//		return formulas.containsKey(expression);
//	}
//
//	private JEP addFormula(String expression)
//	{
//		MathParser parser = new MathParser(expression);
//		JEP _jep = parser.GetParser();
//		formulas.put(expression, _jep);
//
//		return _jep;
//	}

//	private JEP getFormula(String expresion)
//	{
//		if (hasFormula(expresion) == false)
//		{
//			return null;
//		}
//
//		return formulas.get(expresion);
//	}

	public double getActionFormulaValue(String expression, CombatAvatar srcAvatar, CombatAvatar targetAvatar,AvatarAction.CombatContext combatContextCfg)
	{
		parser.SetExpression(expression);
		srcAvatar.setupJEP(parser.GetParser(), targetAvatar, combatContextCfg);
		
		return parser.Evaluate();
	}
	
//	public JEP getActionFormula(String expression, CombatAvatar srcAvatar, CombatAvatar targetAvatar)
//	{
//		// Parse formula
//		boolean newJEP = false;
//		if (hasFormula(expression) == false)
//		{
//			addFormula(expression);
//			newJEP = true;
//		}
//
//		JEP jep = getFormula(expression);
//
//		// Add variables
//		srcAvatar.setupJEP(jep, targetAvatar, false);
//		targetAvatar.setupJEP(jep, srcAvatar, true);
//
//		if (newJEP && jep.parseExpression(expression) == null)
//		{
//			// Output error
//			LoggerFactory.getLogger(FormulaSet.class).error("Parse formula:{} error:{}", expression,jep.getErrorInfo());
//			return null;
//		}
//		else
//		{
//			return jep;
//		}
//	}
	
//	public JEP getTeamFormula(String expression, CombatTeam team)
//	{
//		// Parse formula
//		boolean newJEP = false;
//		if (hasFormula(expression) == false)
//		{
//			addFormula(expression);
//			newJEP = true;
//		}
//
//		JEP jep = getFormula(expression);
//
//		// Add variables
//		team.setupJEP(jep);
//
//		if (newJEP && jep.parseExpression(expression) == null)
//		{
//			// Output error
//			LoggerFactory.getLogger(FormulaSet.class).error("Parse formula:{} error:{}", expression, jep.getErrorInfo());
//			return null;
//		}
//		else
//		{
//			return jep;
//		}
//	}
}
