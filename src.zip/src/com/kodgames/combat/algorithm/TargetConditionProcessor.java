/*
 * 用于战斗作用处理选择action的目标
 */
package com.kodgames.combat.algorithm;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.LoggerFactory;

import ClientServerCommon.*;

import com.kodgames.combat.record.SkillData;
import com.kodgames.common.RandomWrapper;

/**
 * 用于过滤单独一个avatar的处理器, 注意处理器需要线程安全, 不要在静态成员中存书上下文相关信息
 */
interface ISingleAvatarProcessor
{

	public int getType();

	public boolean process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatAvatar targetAvatarCD, CombatContext combatContext);
}

/*
 * 用于过滤并对通过条件avatar进行排序的处理器, 注意处理器需要线程安全, 不要在静态成员中存书上下文相关信息
 */
interface IMultiAvatarProcessor
{

	public int getType();

	public void process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatContext combatContext, OrderedStateCollector result);
}

public class TargetConditionProcessor
{
	static HashMap<Integer, ISingleAvatarProcessor> singleProcessors = new HashMap<>();
	/**
	 * BugFix. multiProcessors不能使用哈希表存储然后根据TargetCondition的Type获取。 原因是
	 * multiProcessor必须按照固定的顺序执行。如攻击血量百分比最低的人，必须先执行AttributeProcessor，然后再执行TargetCountProcessor。
	 */
	static ArrayList<IMultiAvatarProcessor> multiProcessors = new ArrayList<>();

	static HashMap<Integer, IMultiAvatarProcessor> jgMultiProcessors = new HashMap<>();
	static ArrayList<IMultiAvatarProcessor> multiProcessorsForInterAction = new ArrayList<>();

	public static void Initialize()
	{
		singleProcessors.put(TargetCondition._Type.Relationship, new RelationshipProcessor());
		singleProcessors.put(TargetCondition._Type.AliveOrDead, new AliveOrDeadProcessor());
		singleProcessors.put(TargetCondition._Type.CountryType, new CountryTypeProcessor());
		singleProcessors.put(TargetCondition._Type.CharacterType, new CharacterTypeProcessor());
		singleProcessors.put(TargetCondition._Type.AvatarId, new CharacterAvatarIdProcessor());
		singleProcessors.put(TargetCondition._Type.CombatTurnType, new CurCombatTurnTypeProcessor());
		singleProcessors.put(TargetCondition._Type.Expression, new ExpressionProcessor());
		singleProcessors.put(TargetCondition._Type.WithBuff, new WithBuffProcessor());
		singleProcessors.put(TargetCondition._Type.CombatState, new CombatStateProcessor());
		//singleProcessors.put(TargetCondition._Type.EventType, new EventTypeProcessor());

		multiProcessors.add(new FormationRowProcessor());
		multiProcessors.add(new FormationColumnProcessor());
		multiProcessors.add(new AttributeProcessor());
		multiProcessors.add(new TargetCountProcessor());
		multiProcessors.add(new RandomTargetCountProcessor());

		//机关兽
		jgMultiProcessors.put(TargetCondition._Type.ContextCountExpression, new ContextCountExpressionProcessor());
		jgMultiProcessors.put(TargetCondition._Type.ContextExpression, new ContextExpressionProcessor());
		jgMultiProcessors.put(TargetCondition._Type.RoundState, new RoundStateProcessor());
		jgMultiProcessors.put(TargetCondition._Type.InterfaceTarget, new InterfaceTargetProcessor());

		multiProcessorsForInterAction.add(new FormationRowProcessor());
		multiProcessorsForInterAction.add(new FormationColumnProcessor());
		multiProcessorsForInterAction.add(new AttributeProcessor());
		multiProcessorsForInterAction.add(new TargetCountProcessor());
		multiProcessorsForInterAction.add(new RandomTargetCountProcessor());
		multiProcessorsForInterAction.add(new ContextCountExpressionProcessor());
		multiProcessorsForInterAction.add(new ContextExpressionProcessor());
		multiProcessorsForInterAction.add(new InterfaceTargetProcessor());
		multiProcessorsForInterAction.add(new RoundStateProcessor());
	}

	public static void Process(ITargetCondition turn, CombatAvatar srcAvatarCD, CombatContext combatContext, OrderedStateCollector collector)
	{
		TargetCondition condition;
		// 首先对单独avatar进行过滤
		ISingleAvatarProcessor singleProcessor;
		for (int idx = 0; idx < turn.GetTargetConditionCount(); idx++)
		{
			condition = turn.GetTargetCondition(idx);

			for (int stateIdx = 0; stateIdx < collector.GetStateCount(); stateIdx++)
			{
				if (collector.GetState(stateIdx) == false)
					continue;

				singleProcessor = singleProcessors.get(condition.get_type());
				if (singleProcessor != null)
					collector.SetState(stateIdx, singleProcessor.process(condition, srcAvatarCD, combatContext.getAvatars().get(stateIdx), combatContext));
			}
		}

		// 再对剩下的avatar,进行过滤并排序
		//所有multiProcessor 必须按顺序执行
		for (IMultiAvatarProcessor processor : multiProcessors)
		{
			int type = processor.getType();

			for (int idx = 0; idx < turn.GetTargetConditionCount(); idx++)
			{
				condition = turn.GetTargetCondition(idx);

				if (condition.get_type() != type)
					continue;
				processor.process(condition, srcAvatarCD, combatContext, collector);
			}
		}
	}

	public static boolean ProcessForDanAttribute(ITargetCondition danAttribute, CombatAvatar srcAvatarCD, CombatContext combatContext)
	{
		long startTime = System.currentTimeMillis();
		boolean result = true;
		TargetCondition condition;
		ISingleAvatarProcessor processor;
		for (int idx = 0; idx < danAttribute.GetTargetConditionCount() && result; idx++)
		{
			condition = danAttribute.GetTargetCondition(idx);

			long startTime1 = System.currentTimeMillis();
			//在内丹中，所有"条件"都针对于传过来的srcAvatarCD
			processor = singleProcessors.get(condition.get_type());

			if (processor != null && result)
				result &= processor.process(condition, srcAvatarCD, srcAvatarCD, combatContext);

			long endTime1 = System.currentTimeMillis();
			ProfilerData.NewCProcessorProcessTime += endTime1 - startTime1;
		}

		long endTime = System.currentTimeMillis();
		ProfilerData.NewCProcessorTotalProcessTime += endTime - startTime;

		return result;
	}

	public static void ProcessCheckingActionTrigger(ConditionGroup cGroup, CombatAvatar caster, CombatContext combatContext, OrderedStateCollector collector)
	{
		ISingleAvatarProcessor singleProcessor;
		IMultiAvatarProcessor multiProcessor;
		TargetCondition condition;

		for (int idx = 0; idx < cGroup.Get_targetConditionsCount(); idx++)
		{
			condition = cGroup.Get_targetConditionsByIndex(idx);
			multiProcessor = jgMultiProcessors.get(condition.get_type());

			if (multiProcessor != null)
				multiProcessor.process(condition, caster, combatContext, collector);
		}

		//注意必须按顺序处理
		for (int idx = 0; idx < cGroup.Get_targetConditionsCount(); idx++)
		{
			condition = cGroup.Get_targetConditionsByIndex(idx);
			singleProcessor = singleProcessors.get(condition.get_type());

			if (singleProcessor != null)
				for (int i = 0; i < collector.GetStateCount(); i++)
				{
					if (!collector.GetState(i))
						continue;

					collector.SetState(i, singleProcessor.process(condition, caster, combatContext.getCombatAvatarByIndex(i), combatContext));
				}
		}
	}

	public static void ProcessForTriggerAction(AvatarAction action, CombatAvatar srcAvatar, CombatContext combatContext, OrderedStateCollector collector)
	{
		// 首先对单独avatar进行过滤
		ISingleAvatarProcessor singleProcessor;
		TargetCondition condition;
		for (int idx = 0; idx < action.Get_targetConditionsCount(); idx++)
		{
			condition = action.Get_targetConditionsByIndex(idx);

			for (int stateIdx = 0; stateIdx < collector.GetStateCount(); stateIdx++)
			{
				if (collector.GetState(stateIdx) == false)
					continue;

				singleProcessor = singleProcessors.get(condition.get_type());
				if (singleProcessor != null)
					collector.SetState(stateIdx, singleProcessor.process(condition, srcAvatar, combatContext.getAvatars().get(stateIdx), combatContext));
			}
		}

		// 再对剩下的avatar,进行过滤并排序
		//所有multiProcessor 必须按顺序执行
		for (IMultiAvatarProcessor processor : multiProcessorsForInterAction)
		{
			int type = processor.getType();
			//TODO: action.gettargetconditionbytype();
			for (int idx = 0; idx < action.Get_targetConditionsCount(); idx++)
			{
				condition = action.Get_targetConditionsByIndex(idx);

				if (condition.get_type() != type)
					continue;
				processor.process(condition, srcAvatar, combatContext, collector);
			}
		}
	}
}

/**
 * 根据Player对手关系过滤 约定：srcAvatar始终是出手者
 */
class RelationshipProcessor implements ISingleAvatarProcessor
{

	@Override
	public int getType()
	{
		return TargetCondition._Type.Relationship;
	}

	@Override
	public boolean process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatAvatar targetAvatarCD, CombatContext combatContext)
	{
		switch (condition.get_intValue())
		{
			case TargetCondition._SubType.Enemy:
				return srcAvatarCD.getTeamIndex() != targetAvatarCD.getTeamIndex();
			case TargetCondition._SubType.Allies:
				return srcAvatarCD.getTeamIndex() == targetAvatarCD.getTeamIndex();
			case TargetCondition._SubType.AlliesWithoutSelf:
				return srcAvatarCD.getTeamIndex() == targetAvatarCD.getTeamIndex() && srcAvatarCD.getAvatarIndex() != targetAvatarCD.getAvatarIndex();
			case TargetCondition._SubType.Self:
				return srcAvatarCD.getAvatarIndex() == targetAvatarCD.getAvatarIndex();

			//目标角色是否是源角色释放组合技时的需求角色
			case TargetCondition._SubType.CompositeSupporter:

				SkillConfig.CompositeSkillInfo cSkillInfo = null;
				for (SkillData skill : srcAvatarCD.getAvatar().getSkills())
				{
					cSkillInfo = skill.GetCompositeSkillInfo(combatContext.getConfigDB());
					if (cSkillInfo != null)
						break;
				}

				if (cSkillInfo != null)
				{
					SkillConfig.CompositeSkillCondition cCondi = cSkillInfo.get_requirementCondition();

					for (int i = 0; i < cCondi.Get_partsCount(); i++)
					{
//						SkillConfig.CompositeSkillCondition.Part part = cCondi.Get_partsByIndex(i);
//						if (part.get_requiredType() == IDSeg._AssetType.Avatar)
//						{
//							for (int j = 0; j < part.Get_resourceIdsCount(); j++)
//							{
//								if (targetAvatarCD.getAvatar().getResourceId() == part.Get_resourceIdsByIndex(j)
//										&& targetAvatarCD.getTeamIndex() == srcAvatarCD.getTeamIndex())
//									return true;
//							}
//						}
					}
				}

				return false;
		}

		return false;
	}
}

/*
 * 根据Player所在的国家过滤
 */
class CountryTypeProcessor implements ISingleAvatarProcessor
{

	@Override
	public int getType()
	{
		return TargetCondition._Type.CountryType;
	}

	@Override
	public boolean process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatAvatar targetAvatarCD, CombatContext combatContext)
	{
		return (targetAvatarCD.getAvatar().getCountryType() & condition.get_intValue()) != 0;
	}
}

/*
 * 根据Player生死状态过滤
 */
class AliveOrDeadProcessor implements ISingleAvatarProcessor
{

	@Override
	public int getType()
	{
		return TargetCondition._Type.AliveOrDead;
	}

	@Override
	public boolean process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatAvatar targetAvatarCD, CombatContext combatContext)
	{
		switch (condition.get_intValue())
		{
			case TargetCondition._SubType.Dead:
				return targetAvatarCD.isDead();

			case TargetCondition._SubType.Alive:
				return targetAvatarCD.isDead() == false;
		}

		return false;
	}
}

/**
 * 根据角色是物理系还是法术系过滤
 */
class CharacterTypeProcessor implements ISingleAvatarProcessor
{
	@Override
	public int getType()
	{
		return TargetCondition._Type.CharacterType;
	}

	@Override
	public boolean process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatAvatar targetAvatarCD, CombatContext combatContext)
	{
		if (condition.get_intValue() == AvatarConfig._CharacterType.AllCharType)
			return true;

		return condition.get_intValue() == targetAvatarCD.getCharacterType();
	}
}

/**
 * 指定了角色ID
 */
class CharacterAvatarIdProcessor implements ISingleAvatarProcessor
{

	@Override
	public int getType()
	{
		return TargetCondition._Type.AvatarId;
	}

	@Override
	public boolean process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatAvatar targetAvatarCD, CombatContext combatContext)
	{
		return targetAvatarCD.getAvatar().getResourceId() == condition.get_intValue();
	}
}

/**
 * 当前正在释放的技能类型
 */
class CurCombatTurnTypeProcessor implements ISingleAvatarProcessor
{

	@Override
	public int getType()
	{
		return TargetCondition._Type.CombatTurnType;
	}

	@Override
	public boolean process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatAvatar targetAvatarCD, CombatContext combatContext)
	{
		if (condition.IsEnumContained(CombatTurn._Type.All))
		{
			return true;
		}

		//获取当前战斗环境中角色正在释放的技能
		int curSkillId = srcAvatarCD.getContextStack().getCurSkillId();

		if (curSkillId == IDSeg.InvalidId)
		{
			return false;
		}

		SkillConfig.Skill skill = combatContext.getConfigDB().get_SkillConfig().GetSkillById(curSkillId);
		if (skill == null)
		{
			return false;
		}

		return condition.IsEnumContained(skill.get_type());
	}
}

class ExpressionProcessor implements ISingleAvatarProcessor
{
	static com.kodgames.corgi.gameconfiguration.MathParser parser = new com.kodgames.corgi.gameconfiguration.MathParser();

	@Override
	public int getType()
	{
		return TargetCondition._Type.Expression;
	}

	@Override
	public boolean process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatAvatar targetAvatarCD, CombatContext combatContext)
	{
		if (condition.get_stringValue() == null || condition.get_stringValue().isEmpty())
			return false;

		parser.SetExpression(condition.get_stringValue());

		//注意谁是“目标”。即 MaxHP 和 _MaxHP指的是谁的MaxHP
		targetAvatarCD.setupJEP(parser.GetParser(), srcAvatarCD, null);

		double value = parser.Evaluate();

		switch (condition.get_intValue())
		{
			case _ConditionValueCompareType.Equal:
				return value == condition.get_doubleValue();

			case _ConditionValueCompareType.Greater:
				return value > condition.get_doubleValue();

			case _ConditionValueCompareType.GreaterEqual:
				return value >= condition.get_doubleValue();

			case _ConditionValueCompareType.Less:
				return value < condition.get_doubleValue();

			case _ConditionValueCompareType.LessEqual:
				return value <= condition.get_doubleValue();

			case _ConditionValueCompareType.NotEqual:
				return value != condition.get_doubleValue();

			default:
				return false;
		}
	}
}

//判断目标身上是否有指定Buff
class WithBuffProcessor implements ISingleAvatarProcessor
{

	@Override
	public int getType()
	{
		return TargetCondition._Type.WithBuff;
	}

	@Override
	public boolean process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatAvatar targetAvatarCD, CombatContext combatContext)
	{
		for (BuffCombatdata buff : targetAvatarCD.buffs)
		{
			if (buff != null && buff.buff != null)
			{
				if (buff.buff.get_buffType() == condition.get_intValue())
					return true;

				if (buff.buff.get_id() == condition.get_intValue1())
					return true;
			}
		}

		return false;
	}
}

//目前仅用于机关兽系统，部分状态仅在CombatAlgorithm.CheckInterfaceActio()中设置。
class CombatStateProcessor implements ISingleAvatarProcessor
{
	@Override
	public int getType()
	{
		return TargetCondition._Type.CombatState;
	}

	@Override
	public boolean process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatAvatar targetAvatarCD, CombatContext combatContext)
	{
		boolean matched = false;
		for (int i = 0; i < condition.Get_enumListCount(); i++)
		{
			int subType = condition.Get_enumListByIndex(i);
			int beKilled = combatContext.PeekEnv().avatarJustKilled;

			switch (subType)
			{
				case TargetCondition._SubType.State_Dodged://闪避了别人的攻击
					matched = targetAvatarCD.getContextStack().Peek().dodged;
					break;

				case TargetCondition._SubType.State_BeDodged://攻击被别人闪避
					matched = targetAvatarCD.getContextStack().Peek().beDodged;
					break;

				case TargetCondition._SubType.State_Critical://攻击发生了暴击
					matched = targetAvatarCD.getContextStack().Peek().critical;
					break;

				case TargetCondition._SubType.State_BeCritical://被别人暴击
					matched = targetAvatarCD.getContextStack().Peek().beCritical;
					break;

				case TargetCondition._SubType.State_OnBeKilled://被杀
					matched = combatContext.PeekEnv().avatarJustKilled == targetAvatarCD.getAvatarIndex();
					break;

				case TargetCondition._SubType.State_OnEnemyBeKilled://一名敌人被杀
					if (beKilled != -1)
					{
						CombatAvatar avatar = combatContext.getCombatAvatarByIndex(beKilled);
						matched = avatar.getTeamIndex() != targetAvatarCD.getTeamIndex();
					}
					break;

				case TargetCondition._SubType.State_OnKillTarget://击杀一名敌人
					matched = combatContext.PeekEnv().killerIndex == targetAvatarCD.getAvatarIndex();
					break;

				case TargetCondition._SubType.State_OnTeemateBeKilled://队友被杀
					if (beKilled != -1 && beKilled != targetAvatarCD.getAvatarIndex())
					{
						CombatAvatar avatar = combatContext.getCombatAvatarByIndex(beKilled);
						matched = avatar.getTeamIndex() == targetAvatarCD.getTeamIndex();
					}
					break;

				case TargetCondition._SubType.State_OnSkillCasted:
					matched = TargetCondition._SubType.State_OnSkillCasted == targetAvatarCD.getContextStack().Peek().avatarRoundState;
					break;
			}

			if (matched)
				return true;
		}

		return false;
	}
}

//仅用于机关兽系统，用于判断正在释放的技能具有治疗效果还是持续伤害等
class EventTypeProcessor implements ISingleAvatarProcessor
{
	@Override
	public int getType()
	{
		return TargetCondition._Type.EventType;
	}

	@Override
	public boolean process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatAvatar targetAvatarCD, CombatContext combatContext)
	{
		if (combatContext.PeekEnv().eventType != condition.get_intValue())
			return false;

		if (condition.get_intValue() == AvatarAction.Event._Type.AddBuff)
		{
			if (condition.get_intValue1() == combatContext.PeekEnv().eventAddBuffType)
				return true;
			else
				return false;
		}

		return true;
	}
}

/*
 * 根据阵位关系进行过滤排序的基类
 */
abstract class FormationProcessor implements IMultiAvatarProcessor
{

	// 角色阵位comparator, 配合阵位排序选择器使用
	abstract class PositionComparator implements java.util.Comparator<Integer>
	{

		protected CombatAvatar srcAvatarCD;
		protected CombatContext combatContext;

		public void setContext(CombatAvatar srcAvatarCD, CombatContext combatContext)
		{
			if (combatContext == null)
				LoggerFactory.getLogger(PositionComparator.class).error("setContext combatContext == null \n{}", ExceptionUtils.getStackTrace(new Throwable()));

			this.srcAvatarCD = srcAvatarCD;
			this.combatContext = combatContext;
		}

		protected int compareTeam(Integer p1, Integer p2)
		{
			if (combatContext == null)
				LoggerFactory.getLogger(PositionComparator.class).error("compareTeam combatContext == null \n{}", ExceptionUtils.getStackTrace(new Throwable()));

			if (combatContext.getAvatars().get(p1) == null)
				LoggerFactory.getLogger(PositionComparator.class).error("compareTeam combatContext.getAvatars().get(p1) == null p1: {}", p1);

			if (combatContext.getAvatars().get(p2) == null)
				LoggerFactory.getLogger(PositionComparator.class).error("compareTeam combatContext.getAvatars().get(p1) == null p2: {}", p2);

			return combatContext.getAvatars().get(p1).getTeamIndex() - combatContext.getAvatars().get(p2).getTeamIndex();
		}

		/*
		 * Compare row, from frist row to last row
		 */
		protected int compareRowFirst2Last(Integer p1, Integer p2)
		{
			int row1 = combatContext.getAvatars().get(p1).getBattlePositionRow();
			int row2 = combatContext.getAvatars().get(p2).getBattlePositionRow();

			return row1 - row2;
		}

		/*
		 * Compare column, from frist row to last row
		 */
		protected int compareColumnFirst2Last(Integer p1, Integer p2)
		{
			int column1 = combatContext.getAvatars().get(p1).getBattlePositionColumn();
			int column2 = combatContext.getAvatars().get(p2).getBattlePositionColumn();

			return column1 - column2;
		}

		/*
		 * Compare row, from same column to side column
		 */
		protected int compareRowSame2Side(Integer p1, Integer p2)
		{
			// Row same -> side
			int srcRow = srcAvatarCD.getBattlePositionRow();
			int row1 = combatContext.getAvatars().get(p1).getBattlePositionRow();
			int row2 = combatContext.getAvatars().get(p2).getBattlePositionRow();

			int distance = Math.abs(srcRow - row1) - Math.abs(srcRow - row2);

			if (0 == distance)
				return row1 - row2;

			return distance;
		}

		/*
		 * Compare column, from same column to side column
		 */
		protected int compareColumnSame2Side(Integer p1, Integer p2)
		{
			// Column same -> side
			int srcColumn = srcAvatarCD.getBattlePositionColumn();
			int column1 = combatContext.getAvatars().get(p1).getBattlePositionColumn();
			int column2 = combatContext.getAvatars().get(p2).getBattlePositionColumn();

			int distance = Math.abs(srcColumn - column1) - Math.abs(srcColumn - column2);
			if (distance == 0)
				return column1 - column2;

			return distance;
		}
	}
}

// avatar属性选择器，可以选中某项属性最大或者最小的目标。例如， 用来实现选择血最少的目标等效果
class AttributeProcessor implements IMultiAvatarProcessor
{

	@Override
	public int getType()
	{
		return TargetCondition._Type.Attribute;
	}

	@Override
	public void process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatContext combatContext, OrderedStateCollector result)
	{
		// Sort result in order
		AttributeComparator comparator = new AttributeComparator();
		comparator.setContext(srcAvatarCD, combatContext, condition.get_intValue1(), condition.get_intValue(), condition.get_boolValue());
		result.SortOrder(comparator);
		comparator.clearContext();
	}

	// Avatar属性比较器，配合属性选择器的使用 
	class AttributeComparator implements java.util.Comparator<Integer>
	{

		CombatAvatar srcAvatarCD;
		CombatContext combatContext;
		int attributeType;
		int valueType;
		boolean ascendingSort;

		public void setContext(CombatAvatar srcAvatarCD, CombatContext combatContext, int attributeType, int valueType, boolean ascendingSort)
		{
			this.srcAvatarCD = srcAvatarCD;
			this.combatContext = combatContext;
			this.attributeType = attributeType;
			this.ascendingSort = ascendingSort;
			this.valueType = valueType;
		}

		public void clearContext()
		{
			this.srcAvatarCD = null;
			this.combatContext = null;
		}

		@Override
		public int compare(Integer p1, Integer p2)
		{
			double attrib1 = getAttributeValue(p1);
			double attrib2 = getAttributeValue(p2);

			if (attrib1 == attrib2)
				return 0;

			return ascendingSort ? (attrib1 > attrib2 ? 1 : -1) : (attrib1 > attrib2 ? -1 : 1);

		}

		double getAttributeValue(int avatarIndex)
		{
			CombatAvatar combatAvatar = combatContext.getAvatars().get(avatarIndex);
			switch (valueType)
			{
				case TargetCondition._SubType.CurrentValue:
					return combatAvatar.getAttributes().getAttrib(attributeType).value;
				case TargetCondition._SubType.ReduceValue:
					if (attributeType != _AvatarAttributeType.HP)
						LoggerFactory.getLogger(AttributeComparator.class).error("Invalid valutType {} for attribute {}", valueType, attributeType);
					return combatAvatar.getAttributes().getAttrib(_AvatarAttributeType.MaxHP).value - combatAvatar.getAttributes().getAttrib(_AvatarAttributeType.HP).value;

				case TargetCondition._SubType.CurrentPercentage:
					if (attributeType != _AvatarAttributeType.HP)
						LoggerFactory.getLogger(AttributeComparator.class).error("Invalid valutType {} for attribute {}", valueType, attributeType);
					return combatAvatar.getAttributes().getAttrib(_AvatarAttributeType.HP).value / combatAvatar.getAttributes().getAttrib(_AvatarAttributeType.MaxHP).value;
			}

			return 0;
		}
	}
}

/*
 * Select position, result row base on condition setting, column from same to side
 */
class FormationRowProcessor extends FormationProcessor
{

	@Override
	public int getType()
	{
		return TargetCondition._Type.FormationRow;
	}

	class FirstComparator extends FormationProcessor.PositionComparator
	{

		@Override
		public int compare(Integer p1, Integer p2)
		{
			int ret = compareTeam(p1, p2);
			if (ret != 0)
				return ret;

			ret = compareRowFirst2Last(p1, p2);
			if (ret != 0)
				return ret;

			return compareColumnSame2Side(p1, p2);
		}
	}

	class FirstRandomComparator extends FormationProcessor.PositionComparator
	{

		@Override
		public int compare(Integer p1, Integer p2)
		{
			int ret = compareTeam(p1, p2);
			if (ret != 0)
				return ret;

			ret = compareRowFirst2Last(p1, p2);
			if (ret != 0)
				return ret;
			//同一排时，顺序随机
			else
				return RandomWrapper.getRandInt(-1, 1);
		}
	}

	class LastComparator extends FormationProcessor.PositionComparator
	{

		@Override
		public int compare(Integer p1, Integer p2)
		{
			int ret = compareTeam(p1, p2);
			if (ret != 0)
				return ret;

			ret = compareRowFirst2Last(p2, p1);
			if (ret != 0)
				return ret;

			return compareColumnSame2Side(p1, p2);
		}
	}

	class LastRandomComparator extends FormationProcessor.PositionComparator
	{

		@Override
		public int compare(Integer p1, Integer p2)
		{
			int ret = compareTeam(p1, p2);
			if (ret != 0)
				return ret;

			ret = compareRowFirst2Last(p2, p1);
			if (ret != 0)
				return ret;
			//同一排时，顺序随机
			else
				return RandomWrapper.getRandInt(-1, 1);
		}
	}

	class SameComparator extends FormationProcessor.PositionComparator
	{

		// Row same -> column
		@Override
		public int compare(Integer p1, Integer p2)
		{
			int ret = compareTeam(p1, p2);
			if (ret != 0)
				return ret;

			ret = compareRowSame2Side(p1, p2);
			if (ret != 0)
				return ret;

			return compareColumnSame2Side(p1, p2);
		}
	}

	@Override
	public void process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatContext combatContext, OrderedStateCollector result)
	{
		if (combatContext == null)
			LoggerFactory.getLogger(FormationRowProcessor.class).error("FormationRowProcessor combatContext == null \n{}", ExceptionUtils.getStackTrace(new Throwable()));
		// Sort result in order
		FormationProcessor.PositionComparator comparator = null;
		switch (condition.get_intValue())
		{
			case TargetCondition._SubType.Formation_First:
				comparator = new FirstComparator();
				break;
			case TargetCondition._SubType.Formation_Last:
				comparator = new LastComparator();
				break;
			case TargetCondition._SubType.Formation_Same:
				comparator = new SameComparator();
				break;
			case TargetCondition._SubType.Formation_First_Random:
				comparator = new FirstRandomComparator();
				break;
			case TargetCondition._SubType.Formation_Last_Random:
				comparator = new LastRandomComparator();
				break;
		}

		if (comparator == null)
			return;

		comparator.setContext(srcAvatarCD, combatContext);
		result.SortOrder(comparator);

		if (condition.get_boolValue())
		{
			// Select in single row
			// Find the first
			int firstState = result.GetFirstValidState();
			if (firstState == -1)
				// No row selected disable all state
				result.Initialize(result.GetStateCount(), false);
			else
			{
				int row = combatContext.getAvatars().get(firstState).getBattlePositionRow();
				for (int i = 0; i < result.GetStateCount(); ++i)
				{
					if (result.GetState(i) == false)
						continue;

					// Select avatar in the same row
					result.SetState(i, row == combatContext.getAvatars().get(i).getBattlePositionRow());
				}
			}
		}
	}
}

/*
 * Select position, result column base on condition setting, row from first to last
 */
class FormationColumnProcessor extends FormationProcessor
{

	@Override
	public int getType()
	{
		return TargetCondition._Type.FormationColumn;
	}

	class FirstComparator extends FormationProcessor.PositionComparator
	{

		@Override
		public int compare(Integer p1, Integer p2)
		{
			int ret = compareTeam(p1, p2);
			if (ret != 0)
				return ret;

			ret = compareColumnFirst2Last(p1, p2);
			if (ret != 0)
				return ret;

			return compareRowFirst2Last(p1, p2);
		}
	}

	class FirstRandomComparator extends FormationProcessor.PositionComparator
	{

		@Override
		public int compare(Integer p1, Integer p2)
		{
			int ret = compareTeam(p1, p2);
			if (ret != 0)
				return ret;

			ret = compareColumnFirst2Last(p1, p2);
			if (ret != 0)
				return ret;
			else
				return RandomWrapper.getRandInt(-1, 1);
		}
	}

	class LastComparator extends FormationProcessor.PositionComparator
	{

		@Override
		public int compare(Integer p1, Integer p2)
		{
			int ret = compareTeam(p1, p2);
			if (ret != 0)
				return ret;

			ret = compareColumnFirst2Last(p2, p1);
			if (ret != 0)
				return ret;

			return compareRowFirst2Last(p1, p2);
		}
	}

	class LastRandomComparator extends FormationProcessor.PositionComparator
	{

		@Override
		public int compare(Integer p1, Integer p2)
		{
			int ret = compareTeam(p1, p2);
			if (ret != 0)
				return ret;

			ret = compareColumnFirst2Last(p2, p1);
			if (ret != 0)
				return ret;
			else
				return RandomWrapper.getRandInt(-1, 1);
		}
	}

	class SameComparator extends FormationProcessor.PositionComparator
	{

		// Row same -> column
		@Override
		public int compare(Integer p1, Integer p2)
		{
			int ret = compareTeam(p1, p2);
			if (ret != 0)
				return ret;

			ret = compareColumnSame2Side(p1, p2);
			if (ret != 0)
				return ret;

			// 没有同列的目标,选择前排的目标
			ret = compareRowFirst2Last(p1, p2);
			if (ret != 0)
				return ret;

			// 没有同列的目标，又存在多个前排的第二目标时，选择列数小的目标
			return compareColumnFirst2Last(p1, p2);
		}
	}

	@Override
	public void process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatContext combatContext, OrderedStateCollector result)
	{
		if (combatContext == null)
			LoggerFactory.getLogger(FormationColumnProcessor.class).error("FormationColumnProcessor combatContext == null \n{}", ExceptionUtils.getStackTrace(new Throwable()));
		// Sort result in order
		FormationProcessor.PositionComparator comparator;
		switch (condition.get_intValue())
		{
			case TargetCondition._SubType.Formation_First:
				comparator = new FirstComparator();
				break;
			case TargetCondition._SubType.Formation_Last:
				comparator = new LastComparator();
				break;
			case TargetCondition._SubType.Formation_Same:
				comparator = new SameComparator();
				break;
			case TargetCondition._SubType.Formation_First_Random:
				comparator = new FirstRandomComparator();
				break;
			case TargetCondition._SubType.Formation_Last_Random:
				comparator = new LastRandomComparator();
				break;
			default:
				return;
		}

		if (comparator == null)
			return;

		comparator.setContext(srcAvatarCD, combatContext);
		result.SortOrder(comparator);

		if (condition.get_boolValue())
		{
			// Select in single column
			// Find the first
			int firstState = result.GetFirstValidState();
			if (firstState == -1)
				// No row selected disable all state
				result.Initialize(result.GetStateCount(), false);
			else
			{
				int column = combatContext.getAvatars().get(firstState).getBattlePositionColumn();
				for (int i = 0; i < result.GetStateCount(); ++i)
				{
					if (result.GetState(i) == false)
						continue;

					// Select avatar in the same row
					result.SetState(i, column == combatContext.getAvatars().get(i).getBattlePositionColumn());
				}
			}
		}
	}
}

/*
 * 目标数量选择器, 超出数量的avatar不会选中
 */
class TargetCountProcessor implements IMultiAvatarProcessor
{

	@Override
	public int getType()
	{
		return TargetCondition._Type.TargetCount;
	}

	@Override
	public void process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatContext combatContext, OrderedStateCollector result)
	{
		CalcTargetStates(condition.get_intValue(), srcAvatarCD, combatContext, result);
	}

	protected void CalcTargetStates(int targetCount, CombatAvatar srcAvatarCD, CombatContext combatContext, OrderedStateCollector result)
	{
		int validCount = 0;
		for (int i = 0; i < result.GetStateCount(); ++i)
		{
			int stateIndex = result.GetOrderedStateIndex(i);
			if (result.GetState(stateIndex) == false)
				continue;

			if (validCount >= targetCount)
				result.SetState(stateIndex, false);

			++validCount;
		}
	}
}

//随机数量。 取出 [最小值,最大值] 范围内随机数量的角色。
class RandomTargetCountProcessor extends TargetCountProcessor
{
	@Override
	public int getType()
	{
		return TargetCondition._Type.RandomTargetCount;
	}

	@Override
	public void process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatContext combatContext, OrderedStateCollector result)
	{
		CalcTargetStates(RandomWrapper.getRandInt(condition.get_intValue(), condition.get_intValue1()), srcAvatarCD, combatContext, result);
	}
}

/**
 * 用于判定当前目标中是否有指定人数满足指定条件 不满足条件的目标其状态将被设置为false 如果人数不匹配，所有目标的状态将被设为false
 */
class ContextCountExpressionProcessor implements IMultiAvatarProcessor
{
	static com.kodgames.corgi.gameconfiguration.MathParser parser = new com.kodgames.corgi.gameconfiguration.MathParser();

	@Override
	public int getType()
	{
		return TargetCondition._Type.ContextCountExpression;
	}

	@Override
	public void process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatContext combatContext, OrderedStateCollector result)
	{
		parser.SetExpression(condition.get_stringValue());
		int matchCount = 0;

		for (int idx = 0; idx < result.GetStateCount(); idx++)
		{
			if (!result.GetState(idx))
				continue;

			CombatAvatar targetAvatar = combatContext.getCombatAvatarByIndex(idx);
			targetAvatar.setupJEP(parser.GetParser(), srcAvatarCD, null);

			double value = parser.Evaluate();

			switch (condition.get_intValue())
			{
				case _ConditionValueCompareType.Equal:
					if (value == condition.get_doubleValue())
						matchCount++;
					else
						result.SetState(idx, false);
					break;

				case _ConditionValueCompareType.Greater:
					if (value > condition.get_doubleValue())
						matchCount++;
					else
						result.SetState(idx, false);
					break;

				case _ConditionValueCompareType.GreaterEqual:
					if (value >= condition.get_doubleValue())
						matchCount++;
					else
						result.SetState(idx, false);
					break;

				case _ConditionValueCompareType.Less:
					if (value < condition.get_doubleValue())
						matchCount++;
					else
						result.SetState(idx, false);
					break;

				case _ConditionValueCompareType.LessEqual:
					if (value <= condition.get_doubleValue())
						matchCount++;
					else
						result.SetState(idx, false);
					break;

				case _ConditionValueCompareType.NotEqual:
					if (value != condition.get_doubleValue())
						matchCount++;
					else
						result.SetState(idx, false);
					break;
			}
		}

		boolean matched = true;
		switch (condition.get_intValue1())
		{
			case _ConditionValueCompareType.Equal:
				matched = matchCount == (int) condition.get_doubleValue1();
				break;

			case _ConditionValueCompareType.Greater:
				matched = matchCount > condition.get_doubleValue1();
				break;

			case _ConditionValueCompareType.GreaterEqual:
				matched = matchCount >= condition.get_doubleValue1();
				break;

			case _ConditionValueCompareType.Less:
				matched = matchCount < condition.get_doubleValue1();
				break;

			case _ConditionValueCompareType.LessEqual:
				matched = matchCount <= condition.get_doubleValue1();
				break;

			case _ConditionValueCompareType.NotEqual:
				matched = matchCount != (int) condition.get_doubleValue1();
				break;
		}

		if (!matched)
			result.Initialize(result.GetStateCount(), false);
	}
}

/**
 * 检测当前战斗上下文是否满足条件
 *
 * 提供参数： 我方存活/死亡人数 敌方存活/死亡人数
 *
 * 可以在表达式中配置 rand() 从而支持概率触发
 *
 * 以传入的srcAvatarCD 决定我方和敌方
 */
class ContextExpressionProcessor implements IMultiAvatarProcessor
{
	static com.kodgames.corgi.gameconfiguration.MathParser parser = new com.kodgames.corgi.gameconfiguration.MathParser();

	@Override
	public int getType()
	{
		return TargetCondition._Type.ContextExpression;
	}

	@Override
	public void process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatContext combatContext, OrderedStateCollector result)
	{
		int srcTeamIndex = srcAvatarCD.getTeamIndex();
		int enemyTeamIndex = srcTeamIndex ^ 1;

		CombatTeam srcTeam = combatContext.getTeam(srcTeamIndex);
		CombatTeam enemyTeam = combatContext.getTeam(enemyTeamIndex);

		int aliveCount = srcTeam.getLiveAvatarCount();
		int enemyAliveCount = enemyTeam.getLiveAvatarCount();
		int deadCount = srcTeam.getAvatars().size() - aliveCount;
		int enemyDeadCount = enemyTeam.getAvatars().size() - enemyAliveCount;

		//我方、敌方有几人怒气满
		int srcSPFullCount = 0, enemySpFullCount = 0;

		for (int i = 0; i < combatContext.getAvatars().size(); i++)
		{
			CombatAvatar avatar = combatContext.getCombatAvatarByIndex(i);
			if (avatar.isDead())
				continue;

			if (avatar.getAttributes().getAttrib(_AvatarAttributeType.SP).value >= 100)
			{
				if (avatar.getTeamIndex() == srcTeamIndex)
					srcSPFullCount++;
				else if (avatar.getTeamIndex() == enemyTeamIndex)
					enemySpFullCount++;
			}
		}

		parser.SetExpression(condition.get_stringValue());
		parser.SetVariable("AliveCount", aliveCount);
		parser.SetVariable("DeadCount", deadCount);
		parser.SetVariable("SpFullCount", srcSPFullCount);
		parser.SetVariable("_AliveCount", enemyAliveCount);
		parser.SetVariable("_DeadCount", enemyDeadCount);
		parser.SetVariable("_SpFullCount", enemySpFullCount);

		double value = parser.Evaluate();

		boolean matched = true;
		switch (condition.get_intValue())
		{
			case _ConditionValueCompareType.Equal:
				matched = value == condition.get_doubleValue();
				break;

			case _ConditionValueCompareType.Greater:
				matched = value > condition.get_doubleValue();
				break;

			case _ConditionValueCompareType.GreaterEqual:
				matched = value >= condition.get_doubleValue();
				break;

			case _ConditionValueCompareType.Less:
				matched = value < condition.get_doubleValue();
				break;

			case _ConditionValueCompareType.LessEqual:
				matched = value <= condition.get_doubleValue();
				break;

			case _ConditionValueCompareType.NotEqual:
				matched = value != (int) condition.get_doubleValue();
				break;
		}

		if (!matched)
			result.Initialize(result.GetStateCount(), false);
	}
}

//回合状态。
class RoundStateProcessor implements IMultiAvatarProcessor
{
	@Override
	public int getType()
	{
		return TargetCondition._Type.RoundState;
	}

	@Override
	public void process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatContext combatContext, OrderedStateCollector result)
	{
		boolean matched = false;
		switch (condition.get_intValue())
		{
			case TargetCondition._SubType.RoundStart://回合开始。所有人出一次手为一回合
				matched = combatContext.PeekEnv().roundState == TargetCondition._SubType.RoundStart;

			case TargetCondition._SubType.BeforeRoundEnd://回合结束前（结算Buff前）
				matched = combatContext.PeekEnv().roundState == TargetCondition._SubType.BeforeRoundEnd;
		}

		if (!matched)
			result.Initialize(result.GetStateCount(), false);
	}

}

/**
 * 仅用于机关兽接口。Action触发后选择目标
 */
class InterfaceTargetProcessor implements IMultiAvatarProcessor
{

	@Override
	public int getType()
	{
		return TargetCondition._Type.InterfaceTarget;
	}

	@Override
	public void process(TargetCondition condition, CombatAvatar srcAvatarCD, CombatContext combatContext, OrderedStateCollector result)
	{
		for (int idx = 0; idx < result.GetStateCount(); idx++)
		{
//			if (!result.GetState(idx))
//				continue;

			CombatAvatar target = combatContext.getCombatAvatarByIndex(idx);

			switch (condition.get_intValue())
			{
				case TargetCondition._SubType.Attacker://攻击者
					if (combatContext.attacker != null)
						result.SetState(idx, target.getAvatarIndex() == combatContext.attacker.getAvatarIndex());
					break;

				case TargetCondition._SubType.AttackerAllies://攻击者全队
					if (combatContext.attacker != null)
						result.SetState(idx, target.getTeamIndex() == combatContext.attacker.getTeamIndex());
					break;

				case TargetCondition._SubType.AttackerTeemates://攻击者队友角色
					if (combatContext.attacker != null)
						result.SetState(idx, target.getTeamIndex() == combatContext.attacker.getTeamIndex() && target.getAvatarIndex() != combatContext.attacker.getAvatarIndex());
					break;

				case TargetCondition._SubType.AttackerRow://攻击者所在一排
					if (combatContext.attacker != null)
						result.SetState(idx, target.getBattlePositionRow() == combatContext.attacker.getBattlePositionRow());
					break;

				case TargetCondition._SubType.AttackerColumn://攻击者所在一列
					if (combatContext.attacker != null)
						result.SetState(idx, target.getBattlePositionColumn() == combatContext.attacker.getBattlePositionColumn());
					break;

				case TargetCondition._SubType.Defender://防御者
					if (combatContext.defender != null)
						result.SetState(idx, target.getAvatarIndex() == combatContext.defender.getAvatarIndex());
					break;

				case TargetCondition._SubType.DefenderAllies://防御者全队
					if (combatContext.defender != null)
						result.SetState(idx, target.getTeamIndex() == combatContext.defender.getTeamIndex());
					break;

				case TargetCondition._SubType.DefenderTeemates://防御者队友角色
					if (combatContext.defender != null)
						result.SetState(idx, target.getTeamIndex() == combatContext.defender.getTeamIndex() && target.getAvatarIndex() != combatContext.defender.getAvatarIndex());
					break;

				case TargetCondition._SubType.DefenderRow://防御者所在一排
					if (combatContext.defender != null)
						result.SetState(idx, target.getBattlePositionRow() == combatContext.defender.getBattlePositionRow());
					break;

				case TargetCondition._SubType.DefenderColumn://防御者所在一列
					if (combatContext.defender != null)
						result.SetState(idx, target.getBattlePositionColumn() == combatContext.defender.getBattlePositionColumn());
					break;
			}
		}
	}
}
