package com.kodgames.combat.algorithm;

import com.kodgames.common.StateCollector;
import java.util.ArrayList;

public class OrderedStateCollector extends StateCollector
{
	ArrayList<Integer> orderedStateIndices = new ArrayList<>();
	
	@Override
	public void Initialize(int count, boolean defaultState)
	{
		// Random order
		super.Initialize(count, true);
		
		orderedStateIndices.clear();
		while (true)
		{
			int idx = RandomAValidState();
			if (idx == -1)
			{
				break;
			}
			
			orderedStateIndices.add(idx);
		}
		
		super.Initialize(count, defaultState);
	}
	
	public void SortOrder(java.util.Comparator comparator)
	{
		java.util.Collections.sort(orderedStateIndices, comparator);
	}
	
	public int GetOrderedStateIndex(int index)
	{
		return orderedStateIndices.get(index);
	}
	
	public boolean HasValidState()
	{
		for (boolean valid : validAry)
		{
			if (valid)
				return true;
		}
		
		return false;
	}
	
	public void CopyState(OrderedStateCollector other)
	{
		this.Initialize(other.GetStateCount(), true);
		for (int i = 0; i < other.GetStateCount(); i++)
		{
			this.SetState(i, other.GetState(i));
		}
	}
	
	public int GetFirstValidState()
	{
		for (int index = 0; index < orderedStateIndices.size(); index++)
		{
			int stateIndex = orderedStateIndices.get(index);
			if (validAry[stateIndex] == true)
			{
				return stateIndex;
			}
		}
		
		return -1;
	}
}
