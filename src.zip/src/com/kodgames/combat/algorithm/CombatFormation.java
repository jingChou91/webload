/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.algorithm;

import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 *
 * @author sonilics
 */
public class CombatFormation
{
	private CombatContext combatContext;
	private int modifyCount = 0;
	private CombatAvatar[][] positions;

	public CombatFormation(CombatContext combatContext)
	{
		this.combatContext = combatContext;
		positions = new CombatAvatar[combatContext.getConfigDB().get_GameConfig().get_maxRowInFormation()][combatContext.getConfigDB().get_GameConfig().get_maxColumnInFormation()];

	}

	// 固定Column，遍历row
	private class RowIterator implements Iterator<CombatAvatar>
	{
		int row = 0;
		int column = 0;
		int expectedModCount = modifyCount;

		public RowIterator()
		{
		}

		public RowIterator(int row, int column)
		{
			checkRow(row);
			checkColumn(column);

			this.row = row;
			this.column = column;
		}

		@Override
		public boolean hasNext()
		{
			return row < combatContext.getConfigDB().get_GameConfig().get_maxRowInFormation();
		}

		@Override
		public CombatAvatar next()
		{
			checkForComodification();
			int i = row;
			if (i >= combatContext.getConfigDB().get_GameConfig().get_maxRowInFormation())
			{
				throw new NoSuchElementException();
			}

			row = i + 1;
			return positions[i][column];
		}

		@Override
		public void remove()
		{
		}

		final void checkForComodification()
		{
			if (modifyCount != expectedModCount)
			{
				throw new ConcurrentModificationException();
			}
		}
	}

	// 固定row，遍历column
	private class ColumnIterator implements Iterator<CombatAvatar>
	{
		int row;
		int column;
		int expectedModCount = modifyCount;

		public ColumnIterator()
		{
		}

		public ColumnIterator(int row, int column)
		{
			checkRow(row);
			checkColumn(column);

			this.row = row;
			this.column = column;
		}

		@Override
		public boolean hasNext()
		{
			return column < combatContext.getConfigDB().get_GameConfig().get_maxColumnInFormation();
		}

		@Override
		public CombatAvatar next()
		{
			checkForComodification();
			int i = column;
			if (i >= combatContext.getConfigDB().get_GameConfig().get_maxColumnInFormation())
			{
				throw new NoSuchElementException();
			}

			column = i + 1;
			return positions[row][i];
		}

		@Override
		public void remove()
		{
		}

		final void checkForComodification()
		{
			if (modifyCount != expectedModCount)
			{
				throw new ConcurrentModificationException();
			}
		}
	}

	private static void checkRow(int row)
	{
		if (row < 0)
		{
			throw new IndexOutOfBoundsException();
		}
	}

	private static void checkColumn(int column)
	{
		if (column < 0)
		{
			throw new IndexOutOfBoundsException();
		}
	}

	public Iterator<CombatAvatar> rowIterator()
	{
		return rowIterator(0, 0);
	}

	public Iterator<CombatAvatar> rowIterator(int column)
	{
		return new RowIterator(0, column);
	}

	public Iterator<CombatAvatar> rowIterator(int row, int column)
	{
		return new RowIterator(row, column);
	}

	public Iterator<CombatAvatar> columnIterator()
	{
		return columnIterator(0, 0);
	}

	public Iterator<CombatAvatar> columnIterator(int row, int column)
	{
		return new ColumnIterator(row, column);
	}

	public Iterator<CombatAvatar> columnIterator(int row)
	{
		return new ColumnIterator(row, 0);
	}

	public CombatAvatar getFirstValidAvatarInColumn(int column)
	{
		Iterator<CombatAvatar> iterator = rowIterator(column);
		while (iterator.hasNext())
		{
			CombatAvatar avatar = iterator.next();
			if (avatar != null)
			{
				return avatar;
			}
		}

		return null;
	}

	public void setAvatar(CombatAvatar avatar)
	{
		setAvatar(avatar.getBattlePositionRow(), avatar.getBattlePositionColumn(), avatar);
	}

	public void setAvatar(int row, int column, CombatAvatar avatar)
	{
		checkRow(row);
		checkColumn(column);
		assert (positions[row][column] == null || positions[row][column] == avatar);

		positions[row][column] = avatar;
	}

	public CombatAvatar getAvatar(int row, int column)
	{
		checkRow(row);
		checkColumn(column);

		return positions[row][column];
	}
}
