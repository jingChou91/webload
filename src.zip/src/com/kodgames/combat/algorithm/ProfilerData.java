/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.algorithm;

/**
 *
 * @author Administrator
 */
public class ProfilerData
{
	public static long prepareDanModifiersTime = 0;
	public static int calcuateCombatAttributeCallTime = 0;
	public static long calcuateCombatAttributeTime = 0;
	public static long calcuateCombatAttributeTimeWithoutPrepareTime = 0;

	public static long NewCProcessorProcessTime = 0;
	public static long NewCProcessorTotalProcessTime = 0;

	public static long MergeDanAttriHoldersTime = 0;

	public static long buildAttributeChangedEventTime = 0;
}
