package com.kodgames.combat.algorithm;

import java.util.*;

//接口Action支持。目前用于机关兽
public class InterfaceContextMgr
{
	//自带接口（配置在技能中）
	public HashMap<Integer, ArrayList<InterfaceContext>> dic = new HashMap<>();
	//记录指定角色指定action在一场战斗中的触发次数（用于支持次数限制）
	public HashMap<Integer, HashMap<Integer, Integer>> triggerTimeDicBattle = new HashMap<>();
	//记录指定角色指定action在一回合战斗中的触发次数（用于支持次数限制）
	public HashMap<Integer, HashMap<Integer, Integer>> triggerTimeDicRound = new HashMap<>();

	public void ConfirmAvatarIndex(int avatarIndex)
	{
		if (!dic.containsKey(avatarIndex))
			dic.put(avatarIndex, new ArrayList<InterfaceContext>());

		if (!triggerTimeDicBattle.containsKey(avatarIndex))
			triggerTimeDicBattle.put(avatarIndex, new HashMap<Integer, Integer>());

		if (!triggerTimeDicRound.containsKey(avatarIndex))
			triggerTimeDicRound.put(avatarIndex, new HashMap<Integer, Integer>());
	}

	/**
	 * Action触发后，记录触发次数
	 */
	public void AddTriggerTime(int avatarIndex, int actionId)
	{
		ConfirmAvatarIndex(avatarIndex);
		HashMap<Integer, Integer> temp = triggerTimeDicBattle.get(avatarIndex);
		if (!temp.containsKey(actionId))
			temp.put(actionId, 1);
		else
			temp.put(actionId, temp.get(actionId) + 1);

		temp = triggerTimeDicRound.get(avatarIndex);
		if (!temp.containsKey(actionId))
			temp.put(actionId, 1);
		else
			temp.put(actionId, temp.get(actionId) + 1);
	}

	/**
	 * 获取本场战斗中指定角色指定action的触发次数
	 */
	public int GetTriggerTimeBattle(int avatarIndex, int actionId)
	{
		HashMap<Integer, Integer> temp = triggerTimeDicBattle.get(avatarIndex);
		if (temp == null || temp.isEmpty() || !temp.containsKey(actionId))
			return 0;

		return temp.get(actionId);
	}

	/**
	 * 获取本回合战斗中指定角色指定action的触发次数
	 */
	public int GetTriggerTimeRound(int avatarIndex, int actionId)
	{
		HashMap<Integer, Integer> temp = triggerTimeDicRound.get(avatarIndex);
		if (temp == null || temp.isEmpty() || !temp.containsKey(actionId))
			return 0;

		return temp.get(actionId);
	}

	/**
	 * 用于主动效果。 将所有触发的Action的有效目标合并
	 */
	public static void GetMergedActionTargets(ArrayList<InterfaceContext> triggeredActions, int actionId, OrderedStateCollector result)
	{
		for (InterfaceContext triggered : triggeredActions)
		{
			if (triggered.interfaceAction.get_id() == actionId)
			{
				for (int idx = 0; idx < triggered.actionTriggers.GetStateCount(); idx++)
				{
					if (triggered.actionTriggers.GetState(idx))
						result.SetState(idx, true);
				}
			}
		}
	}
}
