package com.kodgames.combat.algorithm;

import ClientServerCommon.AvatarAction;

//接口Action支持。目前用于机关兽
public class InterfaceContext
{
	/**
	 * 触发的Action由谁来做
	 */
	public int whoDoAction;
	/**
	 * 检测触发时出手的人
	 */
	public int attackerIdx;
	/**
	 * 被触发的Action
	 */
	public AvatarAction interfaceAction;
	/**
	 * 触发时whoDoAction的avatarContext（当时的战斗环境）
	 */
	public AvatarContext avatarContext;
	/**
	 * 如果触发的是<b>主动效果</b>，则保存触发后所有选中的目标中满足目标触发条件的人<br/>
	 * 从另一方面理解，这些人触发了InterfaceAction<br/>
	 * 
	 * matchedTargets是对于Attacker而言的。 由于选择目标时要么全是队友，要么全是敌人，<br/>
	 * 所以从attacker的角度看，matchedTargets中保存的要么全是队友，要么全是敌人。<br/>
	 *
	 * 如果触发的是<b>被动效果</b>，则只有出手者置为True.
	 */
	public OrderedStateCollector actionTriggers;

	public double attackerTotalDamage = 0;
}
