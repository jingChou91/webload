package com.kodgames.combat.algorithm;

import ClientServerCommon.AvatarAction;
import ClientServerCommon.TargetCondition;

public class CombatEnv
{
	public boolean checkTriggerAction = true;//是否允许机关兽技能接口触发
	public boolean isProcessingDominner = false;//是否正在进行霸气处理
	public int roundState = TargetCondition._SubType.Invalid;//当前战斗状态，回合开始、回合结束前等
	public int killerIndex = -1;//如果当前刚刚有一个角色击杀一个角色，记录出手者
	public int avatarJustKilled = -1;//如果当前刚刚有一个角色击杀一个角色，记录被杀的角色
	public int eventType = -1;//当前正在处理的事件
	public int eventAddBuffType = -1;//如果当前事件是加Buff，则保存buff类型

	public boolean isEventTypeSet()
	{
		return eventType != AvatarAction.Event._Type.Unknown;
	}

	public CombatEnv()
	{
		Reset();
	}

	public final void Reset()
	{
		this.checkTriggerAction = true;
		this.isProcessingDominner = false;
		this.roundState = TargetCondition._SubType.Invalid;
		this.killerIndex = -1;
		this.avatarJustKilled = -1;
		this.eventType = -1;
		this.eventAddBuffType = -1;
	}

	public CombatEnv DeepClone()
	{
		CombatEnv result = new CombatEnv();
		result.checkTriggerAction = this.checkTriggerAction;
		result.roundState = this.roundState;
		result.isProcessingDominner = this.isProcessingDominner;
		result.killerIndex = this.killerIndex;
		result.avatarJustKilled = this.avatarJustKilled;
		result.eventType = this.eventType;
		result.eventAddBuffType = this.eventAddBuffType;

		return result;
	}
}
