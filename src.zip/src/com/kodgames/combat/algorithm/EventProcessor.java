/*
 * 战斗中涉及到的event的处理器
 */
package com.kodgames.combat.algorithm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.LoggerFactory;

import ClientServerCommon.*;
import com.kodgames.combat.record.ActionRecord;
import com.kodgames.combat.record.EventRecord;
import com.kodgames.combat.record.EventTargetRecord;
import com.kodgames.common.RandomWrapper;
import com.kodgames.corgi.gameconfiguration.CfgDB;

/**
 * Event处理器基类, 注意Event处理器需要线程安全, 处理器中不能够存储上下文相关的变量
 */
public class EventProcessor
{

	static Map<Integer, IEventProcessor> processors = new HashMap<>();

	public static void Initialize()
	{
		AddProcessor(new DamageProcessor());
		AddProcessor(new ThrowDamageProcessor());
		AddProcessor(new SPDamageProcessor());
		AddProcessor(new HealProcessor());
		AddProcessor(new AddBuffProcessor());
		AddProcessor(new DeleteBuffProcessor());
		AddProcessor(new BuffTimeUpProcessor());
		AddProcessor(new EnterStateProcessor());
		AddProcessor(new LeaveStateProcessor());
		AddProcessor(new SkillStartProcessor());
		AddProcessor(new CompositeSkillStartProcessor());
		AddProcessor(new SuperSkillEffectProcessor());
		AddProcessor(new EnterBattleGroundProcessor());
		AddProcessor(new SetSkillPowerProcessor());
		AddProcessor(new CounterAttackStartProcessor());
	}

	private static void AddProcessor(IEventProcessor processor)
	{
		processors.put(processor.GetType(), processor);
	}

	public static boolean Process(CombatAvatar srcAvatar, AvatarAction.Event event, CombatAvatar targetAvatar, CombatContext combatContext,
			boolean checkTurnTest, int[] turnTestResults, EventTargetRecord eventTargetRecord, OrderedStateCollector collector, EventRecord eventRecord)
	{
		IEventProcessor processor = processors.get(event.get_eventType());
		if (processor != null)
		{
			eventTargetRecord.setEventType(processor.GetType());

			if (event.IsLogicEvent())
				// Check event flag
				if (event.get_checkEventFlag() && srcAvatar.getContextStack().isEventCheckFlagSet()
						&& srcAvatar.getContextStack().getEventCheckFlag(targetAvatar.getAvatarIndex()) == false)
					return false;
				// Check dodge state
				else if (checkTurnTest && (turnTestResults[targetAvatar.getAvatarIndex()] & CombatTurn._TestType.Dodged) != 0)
				{
					eventTargetRecord.setTestType(eventTargetRecord.getTestType() | CombatTurn._TestType.Dodged);

					if (targetAvatar.inState(_CombatStateType.Dodging) == false)
					{
						// Target the action to target avatar self
						collector.Initialize(combatContext.getAvatars().size(), false);
						collector.SetState(targetAvatar.getAvatarIndex(), true);

						// Do dodge action
						AvatarAction dodginAction = srcAvatar.getActionByType(AvatarAction._Type.Dodge);

						CombatAlgorithm.doPassiveAction(targetAvatar, dodginAction, combatContext, collector, false, null, eventTargetRecord);

						// 技能闪避不加怒气
//						if (!srcAvatar.getContextStack().isCurrentTurnIDSet())
//						{
//							float dodgedAttackDeltaSkillPower = CfgDB.getDefautConfig().get_GameConfig().get_combatSetting().get_dodgedAttackSkillPowerDelta();
//							eventTargetRecord.addPassiveActionRecord(targetAvatar.increaseSkillPower(dodgedAttackDeltaSkillPower), true);
//						}
					}

					return true;
				}
				// Process logic event
				else
				{
					if (checkTurnTest && (turnTestResults[srcAvatar.getAvatarIndex()] & CombatTurn._TestType.Countered) != 0)
						eventTargetRecord.setTestType(eventTargetRecord.getTestType() | CombatTurn._TestType.Countered);

					return processor.Process(srcAvatar, event, targetAvatar, combatContext, checkTurnTest, turnTestResults, eventTargetRecord, collector, eventRecord);
				}
		}

		return false;
	}
}

interface IEventProcessor
{

	public int GetType();

	public boolean Process(CombatAvatar srcAvatar, AvatarAction.Event event, CombatAvatar targetAvatar, CombatContext combatContext,
			boolean checkTurnTest, int[] turnTestResults, EventTargetRecord eventTargetRecord, OrderedStateCollector collector, EventRecord eventRecord);
}

class CounterAttackStartProcessor implements IEventProcessor
{

	@Override
	public int GetType()
	{
		return AvatarAction._Type.CounterAttackStart;
	}

	@Override
	public boolean Process(CombatAvatar srcAvatar, AvatarAction.Event event, CombatAvatar targetAvatar, CombatContext combatContext,
			boolean checkTurnTest, int[] turnTestResults, EventTargetRecord eventTargetRecord, OrderedStateCollector collector, EventRecord eventRecord)
	{
		return true;
	}
}

class AddBuffProcessor implements IEventProcessor
{
	@Override
	public int GetType()
	{
		return AvatarAction.Event._Type.AddBuff;
	}

	@Override
	public boolean Process(CombatAvatar srcAvatar, AvatarAction.Event event, CombatAvatar targetAvatar, CombatContext combatContext,
			boolean checkTurnTest, int[] turnTestResults, EventTargetRecord eventTargetRecord, OrderedStateCollector collector, EventRecord eventRecord)
	{
		// 目标死了 就不加buff了
		if (targetAvatar.isDead())
			return false;

		// Set buff data.
		int buffID = srcAvatar.getContextStack().isBuffIDToBeAddedSet() ? srcAvatar.getContextStack().getBuffIDToBeAdded() : event.get_buffId();

		ClientServerCommon.Buff buff = CfgDB.getDefautConfig().get_ActionConfig().GetBuffById(buffID);

		//处理失败时，log不存在的BuffId。提供失败信息。
		if (buff == null)
			LoggerFactory.getLogger(AddBuffProcessor.class).error("GetBuffById Failed: buffId=" + buffID);

		int buffType = buff.get_buffType();

		// 查看这种buff是否被免疫
		if ((buffType & targetAvatar.getCombatAbility().immuneBuffType) != 0)
			return false;

		//获取Buff的叠加方式 默认UpdateDuration
		//全局配置
		GlobalBuffSuperpositionType buffSuType = combatContext.getConfigDB().get_ActionConfig().GetBuffSuperpositionTypeByBuffType(buffType);
		if (buffSuType == null)
		{
			buffSuType = new GlobalBuffSuperpositionType();
			//默认处理 相同Id更新持续回合数
			buffSuType.set_buffType(buffType);
			buffSuType.set_superpositionType(Buff._SuperpositionType.IDMutualExclusion);
			buffSuType.set_conflictStrategy(Buff._ConflictStrategy.UpdateDuration);
		}

		//如果buff配置了自己的冲突处理法案，覆盖全局配置进行处理
		if (buff.get_superpositionType() != ClientServerCommon.Buff._SuperpositionType.IDMutualExclusion || buff.get_conflictStrategy() != Buff._ConflictStrategy.UpdateDuration)
		{
			buffSuType.set_superpositionType(buff.get_superpositionType());
			buffSuType.set_conflictStrategy(buff.get_conflictStrategy());
		}

		//ID互斥，默认处理
		if (buffSuType.get_superpositionType() == Buff._SuperpositionType.IDMutualExclusion)
		{
			switch (buffSuType.get_conflictStrategy())
			{
				//相同ID更新回合数，默认处理
				case Buff._ConflictStrategy.UpdateDuration:
					if (targetAvatar.IsBuffExist(buffID))
					{
						BuffCombatdata refreshedBuff = targetAvatar.RefreshBuff(buffID, srcAvatar.getContextStack().getCurrentTurnLevel(), srcAvatar);
						eventTargetRecord.setValue(refreshedBuff.instanceID);
						eventTargetRecord.setValue1(refreshedBuff.buff.get_id());
					}
					else
					{
						AvatarAddBuff(srcAvatar, targetAvatar, eventTargetRecord, buffID, combatContext);
					}
					break;

				//如果是由不同的人施加的（不同的人释放同一个Id的Buff只有一种情况：这个人上场了两个），则叠加，否则更新回合数
				case Buff._ConflictStrategy.SuperpositionIfDifferentSrcAvatar_ElseUpdateDuration:

					if (targetAvatar.IsBuffExist(buffID))
					{
						//通过AvatarIndex不同将角色视为不同角色。比如两个西蜀石兰，对同一个人释放持续掉血的Dot，这两个Dot BuffId相同，但都要加上。
						//但同一个西蜀石兰对同一个人加两次Dot，则只更新回合数
						if (!targetAvatar.HasTheBuffAddedByAvatar(buffID, srcAvatar.getAvatarIndex()))
							AvatarAddBuff(srcAvatar, targetAvatar, eventTargetRecord, buffID, combatContext);
						else
						{
							BuffCombatdata refreshedBuff = targetAvatar.RefreshBuff(buffID, srcAvatar.getContextStack().getCurrentTurnLevel(), srcAvatar);
							eventTargetRecord.setValue(refreshedBuff.instanceID);
							eventTargetRecord.setValue1(refreshedBuff.buff.get_id());
						}
					}
					else
					{
						AvatarAddBuff(srcAvatar, targetAvatar, eventTargetRecord, buffID, combatContext);
					}
					break;

				default:
					return false;
			}
		}
		//直接叠加效果
		else if (buffSuType.get_superpositionType() == Buff._SuperpositionType.IDSuperposition)
		{
			AvatarAddBuff(srcAvatar, targetAvatar, eventTargetRecord, buffID, combatContext);
		}
		//类型互斥
		else if (buffSuType.get_superpositionType() == Buff._SuperpositionType.TypeMutualExclusion)
		{
			switch (buffSuType.get_conflictStrategy())
			{
				//保留这种类型的Buff中持续回合最长的一个
				case Buff._ConflictStrategy.KeepLongestDuration:

					ArrayList<BuffCombatdata> allBuffs = targetAvatar.getAllBuffs();
					ArrayList<Integer> buffsToRemove = new ArrayList<>();

					boolean addNew = true;

					//由于buff可以独立配置叠加方式，可能有多个相同buff存在
					for (BuffCombatdata temp : allBuffs)
					{
						//移除晕回合少的buff
						if (temp.buff.get_buffType() == buffSuType.get_buffType())
						{
							//新buff回合更久，则去掉当前的buff，之后添加新buff，使效果持续回合数最多
							if (buff.get_duration() >= temp.leftTurns)
							{
								buffsToRemove.add(temp.instanceID);
							}
							else
							{
								//当前有buff还能持续更久，忽略新buff
								addNew = false;
							}
						}
					}

					//移除旧Buff
					for (int insToBeRemoved : buffsToRemove)
					{
						EventTargetRecord removeBuffEvent = new EventTargetRecord();
						removeBuffEvent.setTargetIndex(targetAvatar.getAvatarIndex());
						removeBuffEvent.setEventType(AvatarAction._Type.BuffTimeUp);

						BuffCombatdata removedBuff = targetAvatar.RemoveBuffByInstanceId(insToBeRemoved);
						removeBuffEvent.setValue(removedBuff.instanceID);

						ActionRecord actionRecord = new ActionRecord();
						boolean hasAction = CombatAlgorithm.ProcessBuff(targetAvatar, removedBuff, AvatarAction._Type.OnDeleteBuff, combatContext, actionRecord);
						if (hasAction)
							removeBuffEvent.addPassiveActionRecord(actionRecord, true);

						eventRecord.addRecord(removeBuffEvent, true);
					}

					buffsToRemove.clear();

					//添加新的Buff
					if (addNew)
						AvatarAddBuff(srcAvatar, targetAvatar, eventTargetRecord, buffID, combatContext);
					else
						return false;

					break;

				default:
					return false;
			}
		}

		return true;
	}

	private void AvatarAddBuff(CombatAvatar srcAvatar, CombatAvatar targetAvatar, EventTargetRecord eventTargetRecord, int buffId, CombatContext combatContext)
	{
		BuffCombatdata newBuff = targetAvatar.AddBuffByBuffId(buffId, srcAvatar.getContextStack().getCurrentTurnLevel(), srcAvatar);

		// Set buff record.
		eventTargetRecord.setValue(newBuff.instanceID);
		eventTargetRecord.setValue1(newBuff.buff.get_id());

		// Process on create action.
		ActionRecord actionRecord = new ActionRecord();
		boolean hasAction = CombatAlgorithm.ProcessBuff(targetAvatar, newBuff, AvatarAction._Type.OnCreateBuff, combatContext, actionRecord);
		if (hasAction)
			eventTargetRecord.addPassiveActionRecord(actionRecord, true);

	}
}

class SPDamageProcessor implements IEventProcessor
{
	@Override
	public int GetType()
	{
		return AvatarAction.Event._Type.SPDamage;
	}

	@Override
	public boolean Process(CombatAvatar srcAvatar, AvatarAction.Event event, CombatAvatar targetAvatar, CombatContext combatContext,
			boolean checkTurnTest, int[] turnTestResults, EventTargetRecord eventTargetRecord, OrderedStateCollector collector, EventRecord eventRecord)
	{
		int damage = 0;
		if (event.get_damageWeight() != 0)
		{
			double totalSPDamage = 0;
			if (srcAvatar.getContextStack().isAPForDamageCaculationSet())
				totalSPDamage = srcAvatar.getContextStack().getApForDamageCaculation(targetAvatar.getAvatarIndex());

			//防止SPD过高时公式产生负值
			if (totalSPDamage < 0)
				totalSPDamage = 0;

			if (checkTurnTest && (turnTestResults[targetAvatar.getAvatarIndex()] & CombatTurn._TestType.CriticalHit) != 0)
			{
				totalSPDamage *= srcAvatar.getAttributes().getAttrib(_AvatarAttributeType.CSF).value;

				// Set critical-hit bit
				eventTargetRecord.setTestType(eventTargetRecord.getTestType() | CombatTurn._TestType.CriticalHit);
			}

			damage = (int) totalSPDamage;

			eventTargetRecord.setValue(damage);

			targetAvatar.getAttributes().changeSP(-damage);

			srcAvatar.getContextStack().addValidTarget(targetAvatar.getAvatarIndex());
		}
		else
			eventTargetRecord.setValue(0);

		return true;
	}

}

class DamageProcessor implements IEventProcessor
{

	@Override
	public int GetType()
	{
		return AvatarAction.Event._Type.Damage;
	}

	@Override
	public boolean Process(CombatAvatar srcAvatar, AvatarAction.Event event, CombatAvatar targetAvatar, CombatContext combatContext,
			boolean checkTurnTest, int[] turnTestResults, EventTargetRecord eventTargetRecord, OrderedStateCollector collector, EventRecord eventRecord)
	{
		int damage = 0;
		if (event.get_damageWeight() != 0)
		{
			// Set damage to value;
			double totalAP = 0;
			//应用机关兽指定的附加伤害配置（targetAvatar.getContextStack().Peek().customDmg为对目标造成的总伤害，此处用于实现额外伤害）
			if (event.get_JG_additionDmgR() != 0)
				totalAP = targetAvatar.getContextStack().Peek().customDmg * event.get_JG_additionDmgR();
			else if (srcAvatar.getContextStack().isAPForDamageCaculationSet())
				totalAP = srcAvatar.getContextStack().getApForDamageCaculation(targetAvatar.getAvatarIndex());

			float skillPowerExtraDamageRate = srcAvatar.getContextStack().getSkillPowerExtraDamageRate();

			totalAP *= skillPowerExtraDamageRate;

			//内丹伤害加强
			totalAP *= 1 + srcAvatar.getAttributes().getAttrib(_AvatarAttributeType.Dan_AR).value;
			//内丹伤害吸收
			totalAP *= Math.max(0, 1 - targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.Dan_DR).value);

			if (checkTurnTest && (turnTestResults[targetAvatar.getAvatarIndex()] & CombatTurn._TestType.CriticalHit) != 0)
			{
				totalAP *= srcAvatar.getAttributes().getAttrib(_AvatarAttributeType.CSF).value;
				//目标角色内丹暴击伤害吸收率
				totalAP *= Math.max(0, 1 - targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.Dan_CrtDR).value);
				// Set critical-hit bit
				eventTargetRecord.setTestType(eventTargetRecord.getTestType() | CombatTurn._TestType.CriticalHit);
			}

			if (checkTurnTest && (turnTestResults[srcAvatar.getAvatarIndex()] & CombatTurn._TestType.Countered) != 0)
			{
				//伤害是由反击产生的，srcAvatar是反击者
				//内丹反击伤害加强
				totalAP *= 1 + srcAvatar.getAttributes().getAttrib(_AvatarAttributeType.Dan_CntAR).value;
				//内丹反击伤害吸收
				totalAP *= Math.max(0, 1 - targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.Dan_CntDR).value);
			}

			double normalAP = totalAP * event.get_damageWeight();
			double apOffset = normalAP * combatContext.getConfigDB().get_GameConfig().get_combatSetting().get_damageFloatFactor();
			int minAP = (int) Math.floor(normalAP - apOffset);
			int maxAP = (int) Math.ceil(normalAP + apOffset);
			int randomAPOffset = minAP + RandomWrapper.NextInt(maxAP - minAP + 1);

			damage = (int) Math.max(1.0f, randomAPOffset);

			//根据当前释放的技能类型应用护盾。机关兽触发的攻击效果不受护盾影响
			double guard = 0;
			switch (srcAvatar.getContextStack().getCurrentTurnType())
			{
				case CombatTurn._Type.NormalSkill:
					guard = targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.ShiledNormal).value;
					break;

				case CombatTurn._Type.ActiveSkill:
					guard = targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.ShiledActive).value;
					break;

				case CombatTurn._Type.CompositeSkill:
					guard = targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.ShiledComposite).value;
					break;

				default:
					guard = 0;
					break;
			}

			damage = (int) Math.max(0, damage - guard);

			// If damage to self, make sure cannot selfkill
			if (srcAvatar == targetAvatar && damage >= targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.HP).value)
				damage = (int) targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.HP).value - 1;

			eventTargetRecord.setValue(damage);

			// Change HP
			targetAvatar.getAttributes().changeHP(-damage);

			// Save suffered damage
			targetAvatar.getContextStack().addSufferedDamage(damage);
			srcAvatar.getContextStack().addCauseDamage(damage);
			srcAvatar.getContextStack().addValidTarget(targetAvatar.getAvatarIndex());
		}
		else
			eventTargetRecord.setValue(0);

		if (event.get_lastDamageEvent() && damage != 0 && !combatContext.getWoundedAvatars().contains(targetAvatar))
			combatContext.getWoundedAvatars().add(targetAvatar);

		// Do passsive action
		if (event.get_lastDamageEvent() && targetAvatar.isDead())
		{
			CombatTurn deathSkillTurn = targetAvatar.getTurnByTypeWithRate(ClientServerCommon.CombatTurn._Type.DeathSkill);
			if (deathSkillTurn != null)
			{
				// Do get-hit action
				AvatarAction passsiveAction = targetAvatar.getActionByType(AvatarAction._Type.GetHit);
				collector.Initialize(combatContext.getAvatars().size(), false);
				collector.SetState(targetAvatar.getAvatarIndex(), true);
				CombatAlgorithm.doPassiveAction(targetAvatar, passsiveAction, combatContext, collector, false, null, eventTargetRecord);
				targetAvatar.isCastDeathSkill = true;
			}
			else
			{
				// Avatar is dead, do die action
				AvatarAction passsiveAction = targetAvatar.getActionByType(AvatarAction._Type.Die);
				collector.Initialize(combatContext.getAvatars().size(), false);
				collector.SetState(targetAvatar.getAvatarIndex(), true);
				CombatAlgorithm.doPassiveAction(targetAvatar, passsiveAction, combatContext, collector, false, null, eventTargetRecord);

				//有人死亡
				combatContext.PushKillEnv(srcAvatar.getAvatarIndex(), targetAvatar.getAvatarIndex());
				CombatAlgorithm.CheckInterfaceAction(true, srcAvatar, targetAvatar, combatContext, collector, turnTestResults);
				combatContext.PopCombatEnviroment();

				// Remove dead avatar from formation
				CombatTeam combatTeam = combatContext.getTeams().get(targetAvatar.getTeamIndex());
				combatTeam.getFormation().setAvatar(targetAvatar.getBattlePositionRow(), targetAvatar.getBattlePositionColumn(), null);
			}
		}
		else
		{
			// Do get-hit action
			AvatarAction passsiveAction = targetAvatar.getActionByType(AvatarAction._Type.GetHit);
			if (passsiveAction != null)
			{
				collector.Initialize(combatContext.getAvatars().size(), false);
				collector.SetState(targetAvatar.getAvatarIndex(), true);
				CombatAlgorithm.doPassiveAction(targetAvatar, passsiveAction, combatContext, collector, false, null, eventTargetRecord);
			}
		}

		return true;
	}
}

class ThrowDamageProcessor extends DamageProcessor
{

	@Override
	public int GetType()
	{
		return AvatarAction.Event._Type.ThrowDamage;
	}
}

class BuffTimeUpProcessor implements IEventProcessor
{

	@Override
	public int GetType()
	{
		return AvatarAction.Event._Type.BuffTimeUp;
	}

	@Override
	public boolean Process(CombatAvatar srcAvatar, AvatarAction.Event event, CombatAvatar targetAvatar, CombatContext combatContext,
			boolean checkTurnTest, int[] turnTestResults, EventTargetRecord eventTargetRecord, OrderedStateCollector collector, EventRecord eventRecord)
	{
		BuffCombatdata removedBuff = targetAvatar.RemoveBuffByInstanceId(srcAvatar.getContextStack().getBuffInstIDToBeRemoved());
		// Set buff instance ID to record
		eventTargetRecord.setValue(removedBuff.instanceID);

		// Process on delete action
		ActionRecord actionRecord = new ActionRecord();
		boolean hasAction = CombatAlgorithm.ProcessBuff(targetAvatar, removedBuff, AvatarAction._Type.OnDeleteBuff, combatContext, actionRecord);
		if (hasAction)
			eventTargetRecord.addPassiveActionRecord(actionRecord, true);
		return true;
	}
}

//<Event KeyFrameId="1" Type="DeleteBuff" BuffType="Beneficial" PlayOnAllTarget="true" CheckEventFlag="true">
//	<CombatContext LevelFilter="1" EventFlagExpression="rand()-0.01"/>
//</Event>
// 驱散buff,按照buff的类型或者buffid删除指定buff
class DeleteBuffProcessor implements IEventProcessor
{

	@Override
	public int GetType()
	{
		return AvatarAction.Event._Type.DeleteBuff;
	}

	@Override
	public boolean Process(CombatAvatar srcAvatar, AvatarAction.Event event, CombatAvatar targetAvatar, CombatContext combatContext,
			boolean checkTurnTest, int[] turnTestResults, EventTargetRecord eventTargetRecord, OrderedStateCollector collector, EventRecord eventRecord)
	{
		//获取targetAvatar身上的所有buff
		ArrayList<BuffCombatdata> buffs = targetAvatar.getAllBuffs();

		if (buffs != null)
		{
			int removedBuffTypes = 0;
			int types = event.get_buffType();

			Iterator<BuffCombatdata> iterator = buffs.iterator();
			while (iterator.hasNext())
			{
				BuffCombatdata buff = iterator.next();

				//如果是要删除的buff
				if ((buff.buff.get_buffType() & types) != 0)
				{
					ActionRecord actionRecord = new ActionRecord();

					//执行OnDeleteBuff，用于眩晕一类的技能，否则角色不能离开Stun状态，无法再出手
					boolean hasAction = CombatAlgorithm.ProcessBuff(targetAvatar, buff, AvatarAction._Type.OnDeleteBuff, combatContext, actionRecord);
					if (hasAction)
						eventTargetRecord.addPassiveActionRecord(actionRecord, true);

					//删除ModifierSet
					targetAvatar.RemoveModifierSet(buff.modifierSet);
					iterator.remove();
					removedBuffTypes |= buff.buff.get_buffType();
				}
			}

			eventTargetRecord.setValue1(removedBuffTypes);
		}

		return true;
	}
}

class EnterStateProcessor implements IEventProcessor
{

	@Override
	public int GetType()
	{
		return AvatarAction.Event._Type.EnterState;
	}

	@Override
	public boolean Process(CombatAvatar srcAvatar, AvatarAction.Event event, CombatAvatar targetAvatar, CombatContext combatContext,
			boolean checkTurnTest, int[] turnTestResults, EventTargetRecord eventTargetRecord, OrderedStateCollector collector, EventRecord eventRecord)
	{
		// Enter new state
		eventTargetRecord.setValue(event.get_combatStateType());
		targetAvatar.enterState(eventTargetRecord.getValue());

		return true;
	}
}

class LeaveStateProcessor implements IEventProcessor
{

	@Override
	public int GetType()
	{
		return AvatarAction.Event._Type.LeaveState;
	}

	@Override
	public boolean Process(CombatAvatar srcAvatar, AvatarAction.Event event, CombatAvatar targetAvatar, CombatContext combatContext,
			boolean checkTurnTest, int[] turnTestResults, EventTargetRecord eventTargetRecord, OrderedStateCollector collector, EventRecord eventRecord)
	{
		// Leave state
		eventTargetRecord.setValue(event.get_combatStateType());
		targetAvatar.leaveState(eventTargetRecord.getValue());

		return true;
	}
}

class SkillStartProcessor implements IEventProcessor
{

	@Override
	public int GetType()
	{
		return AvatarAction.Event._Type.SkillStart;
	}

	@Override
	public boolean Process(CombatAvatar srcAvatar, AvatarAction.Event event, CombatAvatar targetAvatar, CombatContext combatContext,
			boolean checkTurnTest, int[] turnTestResults, EventTargetRecord eventTargetRecord, OrderedStateCollector collector, EventRecord eventRecord)
	{
		// Set Skill ID to record
		int turnID = srcAvatar.getContextStack().getCurrentTurnID();

		CombatTurn turn = srcAvatar.getTurnByIdFromConfig(turnID);
		if (turn != null)
			eventTargetRecord.setValue(turnID);

		return true;
	}
}

class CompositeSkillStartProcessor implements IEventProcessor
{

	@Override
	public int GetType()
	{
		return AvatarAction.Event._Type.CompositeSkillStart;
	}

	@Override
	public boolean Process(CombatAvatar srcAvatar, AvatarAction.Event event, CombatAvatar targetAvatar, CombatContext combatContext,
			boolean checkTurnTest, int[] turnTestResults, EventTargetRecord eventTargetRecord, OrderedStateCollector collector, EventRecord eventRecord)
	{
		// Set Skill ID to record
		int compositeSkillId = srcAvatar.getContextStack().getCurrentCompositeSkillID();
		ClientServerCommon.SkillConfig.Skill skillCfg = combatContext.getConfigDB().get_SkillConfig().GetSkillById(compositeSkillId);
		if (skillCfg != null)
			eventTargetRecord.setValue(compositeSkillId);

		return true;
	}
}

class SuperSkillEffectProcessor extends SkillStartProcessor
{

	@Override
	public int GetType()
	{
		return AvatarAction.Event._Type.SuperSkillEffect;
	}
}

class SetSkillPowerProcessor implements IEventProcessor
{

	@Override
	public int GetType()
	{
		return AvatarAction.Event._Type.SetSkillPower;
	}

	@Override
	public boolean Process(CombatAvatar srcAvatar, AvatarAction.Event event, CombatAvatar targetAvatar, CombatContext combatContext,
			boolean checkTurnTest, int[] turnTestResults, EventTargetRecord eventTargetRecord, OrderedStateCollector collector, EventRecord eventRecord)
	{
		int skillPowerValue = event.get_skillPowerValue();
		switch (event.get_modifyType())
		{
			case PropertyModifier._ValueModifyType.Replace:
				skillPowerValue = (int) targetAvatar.setSkillPower(skillPowerValue);
				break;
			case PropertyModifier._ValueModifyType.Value:
				skillPowerValue = (int) targetAvatar.updateSkillPower(skillPowerValue);
				break;
		}
		eventTargetRecord.setValue(skillPowerValue);
		// Value1等于1时客户端会popui 变化为0时不popui
//		if(skillPowerValue != 0)
//		{
//			eventTargetRecord.setValue1(1);
//		}

		return true;
	}
}

class EnterBattleGroundProcessor implements IEventProcessor
{

	@Override
	public int GetType()
	{
		return AvatarAction.Event._Type.EnterBattleGround;
	}

	@Override
	public boolean Process(CombatAvatar srcAvatar, AvatarAction.Event event, CombatAvatar targetAvatar, CombatContext combatContext,
			boolean checkTurnTest, int[] turnTestResults, EventTargetRecord eventTargetRecord, OrderedStateCollector collector, EventRecord eventRecord)
	{
		eventTargetRecord.setValue(srcAvatar.getBattlePosition());

		return true;
	}
}

//治疗
class HealProcessor implements IEventProcessor
{

	@Override
	public int GetType()
	{
		return AvatarAction.Event._Type.Heal;
	}

	public boolean IsLogicEvent()
	{
		return true;
	}

	@Override
	public boolean Process(CombatAvatar srcAvatar, AvatarAction.Event event, CombatAvatar targetAvatar, CombatContext combatContext,
			boolean checkTurnTest, int[] turnTestResults, EventTargetRecord eventTargetRecord, OrderedStateCollector collector, EventRecord eventRecord)
	{
		int healValue = 0;
		if (srcAvatar.getContextStack().isAPForDamageCaculationSet())
			healValue = (int) Math.max(1, srcAvatar.getContextStack().getApForDamageCaculation(targetAvatar.getAvatarIndex()));
		else
			healValue = (int) Math.max(1, event.get_healValue());

		float temp = srcAvatar.getContextStack().getSkillPowerExtraDamageRate();
		healValue *= temp;

		if (checkTurnTest && (turnTestResults[targetAvatar.getAvatarIndex()] & CombatTurn._TestType.CriticalHit) != 0)
		{
			healValue *= srcAvatar.getAttributes().getAttrib(_AvatarAttributeType.CSF).value;
			eventTargetRecord.setTestType(eventTargetRecord.getTestType() | CombatTurn._TestType.CriticalHit);
		}

		healValue *= 1 + srcAvatar.getAttributes().getAttrib(_AvatarAttributeType.Dan_HealRA).value;

		// Add hp
		targetAvatar.getAttributes().changeHP(healValue);

		// Reset suffered damage
		targetAvatar.getContextStack().resetSufferedDamage();

		// Record hp value
		eventTargetRecord.setValue(healValue);

		if (healValue != 0)
			eventTargetRecord.setValue1(1);

		return true;
	}
}
