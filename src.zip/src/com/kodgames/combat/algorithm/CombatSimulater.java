package com.kodgames.combat.algorithm;

import ClientServerCommon.*;
import com.kodgames.combat.record.BattleRecord;
import com.kodgames.combat.record.CombatAvatarData;
import com.kodgames.combat.record.CombatPlayer;
import com.kodgames.combat.record.DanAttriHolder;
import com.kodgames.corgi.gameconfiguration.AppPath;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import system.Console;

public class CombatSimulater
{
	/**
	 * @param args the command line arguments
	 */
	static String gameResBasePath = AppPath.PATH_conf_client;
	static String preSaveRecordFile = "Battle_b001302_b001301_1_true.bytes";

	public static void main(String[] args) throws Exception
	{
		//LogBackConfigLoader.load();
		// TODO code application logic here
		Console.WriteLine("Arg count " + args.length);

		if (args.length != 0)
		{
			gameResBasePath = args[0];
			Console.WriteLine("gameResBasePath " + gameResBasePath);
			CfgDB.initialize(gameResBasePath);
			CombatAlgorithm.initialize();
			String savePath = args[1];
			Console.WriteLine("savePath " + savePath);
			String saveCombatSimulaterPath = args[2];
			Console.WriteLine("saveCombatSimulaterPath " + saveCombatSimulaterPath);

			if (args[3].compareToIgnoreCase("GenerateNpcCombat") == 0)
			{
				int repeat = Integer.parseInt(args[4], 10);
				int saveRecord = Integer.parseInt(args[5], 10);

				List<Integer> avatarIdInTeam1 = new ArrayList<>();
				List<Integer> avatarIdInPos1 = new ArrayList<>();
				List<Integer> avatarIdInTeam2 = new ArrayList<>();
				List<Integer> avatarIdInPos2 = new ArrayList<>();
				int teamIndex = 0;
				for (int i = 6; i < args.length; i++)
				{
					if (args[i].compareToIgnoreCase("Team1") == 0)
					{
						teamIndex = 1;
						continue;
					}
					else if (args[i].compareToIgnoreCase("Team2") == 0)
					{
						teamIndex = 2;
						continue;
					}
					else
					{
						int npcID = Integer.parseInt(args[i], 16);
						int pos = Integer.parseInt(args[++i], 10);
						if (teamIndex == 1)
						{
							avatarIdInTeam1.add(npcID);
							avatarIdInPos1.add(pos);
						}
						else if (teamIndex == 2)
						{
							avatarIdInTeam2.add(npcID);
							avatarIdInPos2.add(pos);
						}
					}
				}

				generateCombatResult(CfgDB.getDefautConfig(), avatarIdInTeam1, avatarIdInPos1, avatarIdInTeam2, avatarIdInPos2, repeat, saveRecord, savePath, saveCombatSimulaterPath);
			}
		}
		else
		{
			CfgDB.initialize(gameResBasePath);
			CombatAlgorithm.initialize();

			List<Integer> avatarIdInPos1 = new ArrayList<>();
			List<Integer> avatarIdInPos2 = new ArrayList<>();

			List<Integer> avatarIdInTeam1 = new ArrayList<>();

			avatarIdInTeam1.add(0x05030041);//星魂 35508
			avatarIdInTeam1.add(0x05030041);//星魂 35508
			avatarIdInTeam1.add(0x05090123);//星魂 19441
			avatarIdInTeam1.add(0x05080003);//盖聂 71551
			avatarIdInTeam1.add(0x05080032);//荀子 71551
			avatarIdInTeam1.add(0x05080039);//大铁锤 71551

//			avatarIdInTeam1.add(0x05080073);//天道逍遥子 71551
//			avatarIdInTeam1.add(0x05080026);//少司命 71551
//			avatarIdInTeam1.add(0x05080075);//血手大司命 71551
//			avatarIdInTeam1.add(0x05080009);//赤练 71551
//			avatarIdInTeam1.add(0x05080009);//赤练 71551
//			avatarIdInTeam1.add(0x05080077);//魅姬赤练
//			avatarIdInTeam1.add(0x05080002);//鬼谷子 71551
//			avatarIdInTeam1.add(0x05080073);//天道逍遥子 71551
//			avatarIdInTeam1.add(0x05080011);//端木蓉71551
			avatarIdInPos1.add(0);
			avatarIdInPos1.add(1);
			avatarIdInPos1.add(2);
			avatarIdInPos1.add(3);
			avatarIdInPos1.add(4);
			avatarIdInPos1.add(5);
			List<Integer> avatarIdInTeam2 = new ArrayList<>();

			avatarIdInTeam2.add(0x05080002);//鬼谷子 71551
			avatarIdInTeam2.add(0x05080073);//天道逍遥子 71551
			avatarIdInTeam2.add(0x05080009);//赤练 71551
			avatarIdInTeam2.add(0x05080005);//卫庄 71551
			avatarIdInTeam2.add(0x05080039);//大铁锤 71551

//			avatarIdInTeam2.add(0x05080026);//少司命 71551
//			avatarIdInTeam2.add(0x05080075);//血手大司命 71551
			avatarIdInPos2.add(0);
			avatarIdInPos2.add(1);
			avatarIdInPos2.add(2);
			avatarIdInPos2.add(3);
			avatarIdInPos2.add(4);
//			avatarIdInPos2.add(5);

			generateCombatResult(CfgDB.getDefautConfig(), avatarIdInTeam1, avatarIdInPos1, avatarIdInTeam2, avatarIdInPos2);

		}
	}

	private static CombatAvatarData loadCombatAvatar(ConfigDatabase configDB, int resourceId, int battlePosion)
	{
		return CombatAvatarData.createNpcCombatAvatar(configDB, resourceId, 0, battlePosion, null);
	}

	private static void generateCombatResult(ConfigDatabase configDB, List<Integer> avatarIdInTeam1, List<Integer> avatarIdInPos1, List<Integer> avatarIdInTeam2, List<Integer> avatarIdInPos2) throws FileNotFoundException, IOException
	{
		final int team1Column = 3;
		final int team2Column = 3;

		// Construct player list
		List<CombatPlayer> players = new ArrayList<>();
		{
			CombatPlayer combatPlayer = new CombatPlayer();
			combatPlayer.setPlayerId(1);
			combatPlayer.setDisplayName("npc1");
//			combatPlayer.setExtendsHP(true);
			for (int index = 0; index < avatarIdInTeam1.size(); ++index)
			{
				int avatarId = avatarIdInTeam1.get(index);
				int battlePosition = CombatAvatarData.getBattlePosition(avatarIdInPos1.get(index) / team1Column, avatarIdInPos1.get(index) % team1Column);
				CombatAvatarData avatar = loadCombatAvatar(configDB, avatarId, battlePosition);
				avatar.setBattlePosition(battlePosition);
				combatPlayer.getCombatAvatarDatas().add(avatar);
			}
			players.add(combatPlayer);
		}
		{
			CombatPlayer combatPlayer = new CombatPlayer();
			combatPlayer.setPlayerId(2);
			combatPlayer.setDisplayName("npc2");
			for (int index = 0; index < avatarIdInTeam2.size(); ++index)
			{
				int avatarId = avatarIdInTeam2.get(index);
				int battlePosition = CombatAvatarData.getBattlePosition(avatarIdInPos2.get(index) / team2Column, avatarIdInPos2.get(index) % team2Column);
				CombatAvatarData avatar = loadCombatAvatar(configDB, avatarId, battlePosition);
				avatar.setBattlePosition(battlePosition);
				combatPlayer.getCombatAvatarDatas().add(avatar);

				//Logger.Info(avatar.getCountryType()+" "+ClientServerCommon.AvatarConfig._AvatarCountryType.GetNameByType(avatar.getCountryType(),system.Type.GetTypeFromHandle(ClientServerCommon.AvatarConfig._AvatarCountryType.class)));
			}
			players.add(combatPlayer);
		}

		BattleRecord combatRet = new BattleRecord();

		//生成内丹测试数据
		ArrayList<DanAttriHolder> testDatas = GenDanTestInfos();
		ArrayList<DanAttriHolder> testDatas_Defense = GenDanTestInfos_Defense();

		ArrayList<DanAttriHolder> testDatasFromCfg = GenDanTestInfosFromConfig(configDB);
		for (com.kodgames.combat.record.CombatPlayer player : players)
		{
			for (com.kodgames.combat.record.CombatAvatarData combatAvatar : player.getCombatAvatarDatas())
			{
				combatAvatar.danAttriHolders.clear();
//				combatAvatar.danAttriHolders.addAll(testDatasFromCfg);
//				combatAvatar.danAttriHolders.addAll(testDatas);
//				combatAvatar.danAttriHolders.addAll(testDatas_Defense);
//				combatAvatar.danAttriHolders.addAll(testDatasFromCfg);
//				combatAvatar.danAttriHolders.addAll(testDatas);
//				combatAvatar.danAttriHolders.addAll(testDatas_Defense);
			}
		}

		configDB.get_ActionConfig();
		configDB.get_AvatarConfig();
		configDB.get_SkillConfig();
		long startTime = System.currentTimeMillis();
		for (int i = 0; i < 1; i++)
		{
			combatRet = new BattleRecord();
			// Do combat
			CombatAlgorithm.process(CfgDB.getDefautConfig(), players, 0, 40, false, combatRet);
		}
		long endTime = System.currentTimeMillis();
		System.out.println("程序运行时间：" + (endTime - startTime) + "ms");

		Logger.Info("\nprepareDanModifiersTime {}\ncalcuateCombatAttributeCallTime {}\ncalcuateCombatAttributeTime {}\ncalcuateCombatAttributeTimeWithoutPrepareTime {}\n"
				+ "NewCProcessorProcessTime {}\nNewCProcessorTotalProcessTime {}\nMergeDanAttriHoldersTime {}\nbuildAttributeChangedEventTime {} \n", new Object[]
				{
					ProfilerData.prepareDanModifiersTime, ProfilerData.calcuateCombatAttributeCallTime, ProfilerData.calcuateCombatAttributeTime, ProfilerData.calcuateCombatAttributeTimeWithoutPrepareTime,
					ProfilerData.NewCProcessorProcessTime, ProfilerData.NewCProcessorTotalProcessTime, ProfilerData.MergeDanAttriHoldersTime, ProfilerData.buildAttributeChangedEventTime
				}
		);

		// Save protocol to file
		com.kodgames.corgi.protocol.CombatData.BattleRecord protoBufRecord = combatRet.toProtoBufClass().build();
//		try (FileOutputStream output = new FileOutputStream("Battle.bytes"))	
		try (FileOutputStream output = new FileOutputStream("H:\\workSpace\\unity3D\\dev\\Client\\Assets\\TestBattle1.bytes"))
		{
			protoBufRecord.writeTo(output);
		}
	}

	static ArrayList<DanAttriHolder> GenDanTestInfosFromConfig(ClientServerCommon.ConfigDatabase cfgDb)
	{
		ArrayList<DanAttriHolder> res = new ArrayList<>();

		DanAttriHolder danAttrH = new DanAttriHolder();

		//57200001	【星魂】的蓄力技【四成聚气成刃】伤害提高
//		danAttrH.danAttribute = cfgDb.get_DanConfig().GetDanAttributeById(0x57200001);
//		danAttrH.level = 1;
//		res.add(danAttrH);
//		//57201001	【星魂】的怒气技【八成聚气成刃】伤害提高	DamageModify	Damage	AllCharType	03000029		ActiveSkill		0.02	0.03	0.06	0.07	0.08	0.11	0.12	0.13	0.16		57201001;
//		danAttrH = new DanAttriHolder();
//		danAttrH.danAttribute = cfgDb.get_DanConfig().GetDanAttributeById(0x57201001);
//		danAttrH.level = 2;
//		res.add(danAttrH);
//
//		//57201017	【少司命】的怒气技【万叶飞花流】伤害及治疗效果提高	DamageModify	Damage	AllCharType	03000026		ActiveSkill		0.02	0.03	0.06	0.07	0.08	0.11	0.12	0.13	0.16		57201017;
//		danAttrH = new DanAttriHolder();
//		danAttrH.danAttribute = cfgDb.get_DanConfig().GetDanAttributeById(0x57201017);
//		danAttrH.level = 2;
//		res.add(danAttrH);
//
//		danAttrH = new DanAttriHolder();
//		danAttrH.danAttribute = cfgDb.get_DanConfig().GetDanAttributeById(0x5720B017);
//		danAttrH.level = 2;
//		res.add(danAttrH);
//		
		//57214003	角色蓄力技吸血效果(按实际伤害吸)	DamageHeal	DmgHealByDmg	AllCharType		All	NormalSkill		0.00625	0.009375	0.01875	0.021875	0.025	0.034375	0.0375	0.040625	0.05		57214003;
		danAttrH = new DanAttriHolder();
		danAttrH.danAttribute = cfgDb.get_DanConfig().GetDanAttributeById(0x57214003);
		danAttrH.level = 9;
		res.add(danAttrH);

		//57214006	角色怒气技吸血效果(按实际伤害吸)	DamageHeal	DmgHealByDmg	AllCharType		All	ActiveSkill		0.00625	0.009375	0.01875	0.021875	0.025	0.034375	0.0375	0.040625	0.05		57214006;
		danAttrH = new DanAttriHolder();
		danAttrH.danAttribute = cfgDb.get_DanConfig().GetDanAttributeById(0x57214006);
		danAttrH.level = 9;
		res.add(danAttrH);

		//57214009	角色组合技吸血效果(按实际伤害吸)	DamageHeal	DmgHealByDmg	AllCharType		All	CompositeSkill		0.00625	0.009375	0.01875	0.021875	0.025	0.034375	0.0375	0.040625	0.05		57214009;
		danAttrH = new DanAttriHolder();
		danAttrH.danAttribute = cfgDb.get_DanConfig().GetDanAttributeById(0x57214009);
		danAttrH.level = 9;
		res.add(danAttrH);

//		//56FF0006	反击伤害提高
//		danAttrH.danAttribute = cfgDb.get_DanConfig().GetDanAttributeById(0x56FF0006);
//		danAttrH.level = 1;
//		res.add(danAttrH);
		//按攻击力吸血
		DanAttriHolder holder = new DanAttriHolder();

		holder.level = 10;
		holder.danAttribute = new DanConfig.DanAttribute();
		holder.danAttribute.set_FuncType(DanConfig._DanFuncType.DamageHeal);
		holder.danAttribute.AddFuncParam(DanConfig._DanFuncParam.DmgHealByAP);

		//添加10个等级的Modifier
		for (int i = 1; i <= 10; i++)
		{
			PropertyModifierSet pms = new PropertyModifierSet();
			pms.set_levelFilter(i);

			PropertyModifier m = new PropertyModifier();
			m.set_type(PropertyModifier._Type.AttributeModifier);
			m.set_modifyType(PropertyModifier._ValueModifyType.Value);
			m.set_attributeType(_AvatarAttributeType.Dan_DmgHealByAP);
			m.set_attributeValue(i * 0.03f);

			pms.AddOneModifier(m);

			holder.danAttribute.get_ModifierSets().Add(pms);
		}
		res.add(holder);

		//按最大血量吸血
		holder = new DanAttriHolder();

		holder.level = 1;
		holder.danAttribute = new DanConfig.DanAttribute();
		holder.danAttribute.set_FuncType(DanConfig._DanFuncType.DamageHeal);
		holder.danAttribute.AddFuncParam(DanConfig._DanFuncParam.DmgHealByMaxHP);

		//添加10个等级的Modifier
		for (int i = 1; i <= 10; i++)
		{
			PropertyModifierSet pms = new PropertyModifierSet();
			pms.set_levelFilter(i);

			PropertyModifier m = new PropertyModifier();
			m.set_type(PropertyModifier._Type.AttributeModifier);
			m.set_modifyType(PropertyModifier._ValueModifyType.Value);
			m.set_attributeType(_AvatarAttributeType.Dan_DmgHealByMaxHp);
			m.set_attributeValue(i * 0.01f);

			pms.AddOneModifier(m);

			holder.danAttribute.get_ModifierSets().Add(pms);
		}
		res.add(holder);

		return res;
	}

	static ArrayList<DanAttriHolder> GenDanTestInfos()
	{
		ArrayList<DanAttriHolder> res = new ArrayList<>();

		DanAttriHolder holder = new DanAttriHolder();
		//57200001	【星魂】的蓄力技【四成聚气成刃】伤害提高	DamageModify	Damage	AllCharType	03000029		NormalSkill				0.03	0.015	0.045	0.015	0.015	0.045	0.015	0.015	0.045		57200001;
		holder.level = 1;
		holder.danAttribute = new DanConfig.DanAttribute();
		holder.danAttribute.set_FuncType(DanConfig._DanFuncType.DamageModify);
		holder.danAttribute.AddFuncParam(DanConfig._DanFuncParam.Damage);

		//指定物理/法术派系
		TargetCondition condi = new TargetCondition();
		condi.set_type(TargetCondition._Type.CharacterType);
		condi.set_intValue(AvatarConfig._CharacterType.AllCharType);
		holder.danAttribute.get_TargetConditions().Add(condi);

		//指定角色Id
		condi = new TargetCondition();
		condi.set_type(TargetCondition._Type.AvatarId);
		condi.set_intValue(0x03000029);//星魂
		holder.danAttribute.get_TargetConditions().Add(condi);

		//指定蓄力技
		condi = new TargetCondition();
		condi.set_type(TargetCondition._Type.CombatTurnType);
		condi.EnumListAddValue(CombatTurn._Type.NormalSkill);
		holder.danAttribute.get_TargetConditions().Add(condi);

		//添加10个等级的Modifier
		for (int i = 1; i <= 10; i++)
		{
			PropertyModifierSet pms = new PropertyModifierSet();
			pms.set_levelFilter(i);

			PropertyModifier m = new PropertyModifier();
			m.set_type(PropertyModifier._Type.AttributeModifier);
			m.set_modifyType(PropertyModifier._ValueModifyType.Value);
			m.set_attributeType(_AvatarAttributeType.Dan_AR);//伤害上升
			m.set_attributeValue(i * 0.03f);

			pms.AddOneModifier(m);

			holder.danAttribute.get_ModifierSets().Add(pms);
		}
		res.add(holder);

		//血手大司命的蓄力技和组合技“阴阳两生 死" 伤害提高+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++==
		//伤害增加+暴伤增加
		holder = new DanAttriHolder();

		holder.level = 1;
		holder.danAttribute = new DanConfig.DanAttribute();
		holder.danAttribute.set_FuncType(DanConfig._DanFuncType.DamageModify);
		holder.danAttribute.AddFuncParam(DanConfig._DanFuncParam.Damage);

		//指定角色Id
		condi = new TargetCondition();
		condi.set_type(TargetCondition._Type.AvatarId);
		condi.set_intValue(0x03000076);//血手大司命
		holder.danAttribute.get_TargetConditions().Add(condi);

		//指定组合技
		condi = new TargetCondition();
		condi.set_type(TargetCondition._Type.CombatTurnType);
		condi.EnumListAddValue(CombatTurn._Type.CompositeSkill);
		condi.EnumListAddValue(CombatTurn._Type.NormalSkill);
		holder.danAttribute.get_TargetConditions().Add(condi);

		//添加10个等级的Modifier
		for (int i = 1; i <= 10; i++)
		{
			PropertyModifierSet pms = new PropertyModifierSet();
			pms.set_levelFilter(i);

			PropertyModifier m = new PropertyModifier();
			m.set_type(PropertyModifier._Type.AttributeModifier);
			m.set_modifyType(PropertyModifier._ValueModifyType.Value);
			m.set_attributeType(_AvatarAttributeType.CSF);//暴击伤害上升
			m.set_attributeValue(i * 0.03f);

			pms.AddOneModifier(m);

			m = new PropertyModifier();
			m.set_type(PropertyModifier._Type.AttributeModifier);
			m.set_modifyType(PropertyModifier._ValueModifyType.Value);
			m.set_attributeType(_AvatarAttributeType.Dan_AR);//伤害上升
			m.set_attributeValue(i * 0.03f);

			pms.AddOneModifier(m);

			holder.danAttribute.get_ModifierSets().Add(pms);
		}
		res.add(holder);

		//组合技触发概率提高++++++++++++++++++++++++++++++++++++++++++++++++++++++++==
		holder = new DanAttriHolder();

		holder.level = 6;
		holder.danAttribute = new DanConfig.DanAttribute();
		holder.danAttribute.set_FuncType(DanConfig._DanFuncType.TriggerRate);
		holder.danAttribute.AddFuncParam(DanConfig._DanFuncParam.CompositeSkillRate);

		//添加10个等级的Modifier
		for (int i = 1; i <= 10; i++)
		{
			PropertyModifierSet pms = new PropertyModifierSet();
			pms.set_levelFilter(i);

			PropertyModifier m = new PropertyModifier();
			m.set_type(PropertyModifier._Type.AttributeModifier);
			m.set_modifyType(PropertyModifier._ValueModifyType.Value);
			m.set_attributeType(_AvatarAttributeType.Dan_CmpTRA);//组合技触发概率上升
			m.set_attributeValue(i * 0.1f);

			pms.AddOneModifier(m);

			holder.danAttribute.get_ModifierSets().Add(pms);
		}
		res.add(holder);

		//少司命++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		//血量小于80%时，攻击力提升100%
		holder = new DanAttriHolder();

		holder.level = 10;
		holder.danAttribute = new DanConfig.DanAttribute();
		holder.danAttribute.set_FuncType(DanConfig._DanFuncType.DamageModify);
		holder.danAttribute.AddFuncParam(DanConfig._DanFuncParam.AllDmg);

		//指定角色Id
		condi = new TargetCondition();
		condi.set_type(TargetCondition._Type.AvatarId);
		condi.set_intValue(0x03000026);//少司命
		holder.danAttribute.get_TargetConditions().Add(condi);

		//表达式
		condi = new TargetCondition();
		condi.set_type(TargetCondition._Type.Expression);
		condi.set_stringValue("HP/MaxHP");
		condi.set_doubleValue(0.8);
		condi.set_intValue(_ConditionValueCompareType.Less);
		holder.danAttribute.get_TargetConditions().Add(condi);

		//添加10个等级的Modifier
		for (int i = 1; i <= 10; i++)
		{
			PropertyModifierSet pms = new PropertyModifierSet();
			pms.set_levelFilter(i);

			PropertyModifier m = new PropertyModifier();
			m.set_type(PropertyModifier._Type.AttributeModifier);
			m.set_modifyType(PropertyModifier._ValueModifyType.Value);
			m.set_attributeType(_AvatarAttributeType.Dan_AR);//伤害上升
			m.set_attributeValue(i * 0.1f);

			pms.AddOneModifier(m);

			m = new PropertyModifier();
			m.set_type(PropertyModifier._Type.AttributeModifier);
			m.set_modifyType(PropertyModifier._ValueModifyType.Value);
			m.set_attributeType(_AvatarAttributeType.CSF);//暴击伤害上升
			m.set_attributeValue(i * 0.1f);

			pms.AddOneModifier(m);

			m = new PropertyModifier();
			m.set_type(PropertyModifier._Type.AttributeModifier);
			m.set_modifyType(PropertyModifier._ValueModifyType.Value);
			m.set_attributeType(_AvatarAttributeType.Dan_CntAR);//反击伤害上升
			m.set_attributeValue(i * 0.1f);

			pms.AddOneModifier(m);

			holder.danAttribute.get_ModifierSets().Add(pms);
		}
		res.add(holder);

		return res;
	}

	static ArrayList<DanAttriHolder> GenDanTestInfos_Defense()
	{
		ArrayList<DanAttriHolder> res = new ArrayList<>();

		DanAttriHolder holder = new DanAttriHolder();
		//伤害吸收
		holder.level = 10;
		holder.danAttribute = new DanConfig.DanAttribute();
		holder.danAttribute.set_FuncType(DanConfig._DanFuncType.DamageModify_Defense);

		TargetCondition condi = new TargetCondition();
		condi = new TargetCondition();
		condi.set_type(TargetCondition._Type.CombatTurnType);
		condi.EnumListAddValue(CombatTurn._Type.CompositeSkill);
		holder.danAttribute.get_TargetConditions().Add(condi);

		//添加10个等级的Modifier
		for (int i = 1; i <= 10; i++)
		{
			PropertyModifierSet pms = new PropertyModifierSet();
			pms.set_levelFilter(i);

			PropertyModifier m = new PropertyModifier();
			m.set_type(PropertyModifier._Type.AttributeModifier);
			m.set_modifyType(PropertyModifier._ValueModifyType.Value);
			m.set_attributeType(_AvatarAttributeType.Dan_DR);//伤害吸收
			m.set_attributeValue(i * 0.03f);

			pms.AddOneModifier(m);

			m = new PropertyModifier();
			m.set_type(PropertyModifier._Type.AttributeModifier);
			m.set_modifyType(PropertyModifier._ValueModifyType.Value);
			m.set_attributeType(_AvatarAttributeType.Dan_CrtDR);//暴击伤害吸收
			m.set_attributeValue(i * 0.03f);

			pms.AddOneModifier(m);

			holder.danAttribute.get_ModifierSets().Add(pms);
		}
		res.add(holder);

		return res;
	}

	private static void generateCombatResult(ConfigDatabase configDB, List<Integer> avatarIdInTeam1, List<Integer> avatarIdInPos1, List<Integer> avatarIdInTeam2, List<Integer> avatarIdInPos2, int repeatCount, int saveRecord, String savePath, String saveCombatSimulaterPath) throws FileNotFoundException, IOException
	{
		final int team1Column = 3;
		final int team2Column = 3;

		int winCount = 0;
		for (int repeatIdx = 0; repeatIdx < repeatCount; ++repeatIdx)
		{
			String saveFileName = "";
			// Construct player list
			List<CombatPlayer> players = new ArrayList<>();
			{
				CombatPlayer combatPlayer = new CombatPlayer();
				combatPlayer.setPlayerId(1);
				for (int index = 0; index < avatarIdInTeam1.size(); ++index)
				{
					int avatarId = avatarIdInTeam1.get(index);
					int battlePosition = CombatAvatarData.getBattlePosition(avatarIdInPos1.get(index) / team1Column, avatarIdInPos1.get(index) % team1Column);
					CombatAvatarData avatar = loadCombatAvatar(configDB, avatarId, battlePosition);
					avatar.setBattlePosition(battlePosition);
					combatPlayer.getCombatAvatarDatas().add(avatar);
					if ("".equals(saveFileName) && avatar.getSkills().size() > 0)
					{
						saveFileName = Integer.toString(avatar.getSkills().get(0).getCombatTurnID(configDB), 16);
					}
				}
				players.add(combatPlayer);
			}
			{
				CombatPlayer combatPlayer = new CombatPlayer();
				combatPlayer.setPlayerId(2);
				for (int index = 0; index < avatarIdInTeam2.size(); ++index)
				{
					int avatarId = avatarIdInTeam2.get(index);
					int battlePosition = CombatAvatarData.getBattlePosition(avatarIdInPos2.get(index) / team2Column, avatarIdInPos2.get(index) % team2Column);
					CombatAvatarData avatar = loadCombatAvatar(configDB, avatarId, battlePosition);
					avatar.setBattlePosition(battlePosition);
					combatPlayer.getCombatAvatarDatas().add(avatar);
				}
				players.add(combatPlayer);
			}

			BattleRecord combatRet = new BattleRecord();

			// Do combat
			CombatAlgorithm.process(CfgDB.getDefautConfig(), players, 0, CfgDB.getDefautConfig().get_GameConfig().get_combatSetting().get_maxRound(), false, combatRet);

			// Save protocol to file
			com.kodgames.corgi.protocol.CombatData.BattleRecord protoBufRecord = combatRet.toProtoBufClass().build();

			boolean isWinner = combatRet.getTeamRecords().get(0).isWinner();
			String winStr = "Lose";
			if (isWinner)
			{
				winCount++;
				winStr = "Win";
			}
			// Write to disk.
			if (saveRecord == 1)
			{
				String fileName = savePath + saveFileName + "_" + winStr + "_" + Integer.toString(repeatIdx) + ".bytes";
				Console.WriteLine("fileName " + fileName);
				FileOutputStream output = new FileOutputStream(fileName);
				protoBufRecord.writeTo(output);
				output.close();

				output = new FileOutputStream(saveCombatSimulaterPath);
				protoBufRecord.writeTo(output);
				output.close();
			}
		}

		Console.WriteLine("winCount " + Integer.toString(winCount));
	}
}
