package com.kodgames.combat.algorithm;

import java.util.ArrayList;
import java.util.List;

import org.nfunk.jep.JEP;
import org.slf4j.LoggerFactory;

import ClientServerCommon.*;
import com.kodgames.combat.record.*;
import com.kodgames.common.RandomWrapper;

public class CombatAvatar
{
	private static final org.slf4j.Logger logger = LoggerFactory.getLogger(CombatAvatar.class);

	private boolean useLastHp = false;
	private CombatContext combatContext;
	private CombatAvatarData avatar;
	private GuardBeast guardBeast;//守护机关兽
	private int teamIndex;
	private int playerIndex;
	private int avatarIndex;
	private int battlePosition;
	private int currentWeaponType = EquipmentConfig._WeaponType.Empty;
	private CombatAttributes attributes = new CombatAttributes();
	private CombatAbility ability = new CombatAbility();
	private ArrayList<Integer> combatStates = new ArrayList<>();
	private ArrayList<PropertyModifierSet> modifierSets = new ArrayList<>();
	private AvatarContextStack contextStack = new AvatarContextStack();
	private boolean mainActionInterrupted = false;
	public ArrayList<BuffCombatdata> buffs = new ArrayList<>();
	private int buffInstanceIDAllocator = IDSeg.InvalidId;
	public boolean isCastDeathSkill = false;

	//内丹计算支持
	private ArrayList<PropertyModifierSet> danModifierSets = new ArrayList<>();
	//属性计算的临时变量
	private ArrayList<PropertyModifierSet> totalModifiers = new ArrayList<>();

	//触发式Action
	public ArrayList<AvatarAction> triggerAbleActions = new ArrayList<>();

	public CombatAvatar()
	{
		contextStack.Push();
	}

	public void initiailize(CombatContext combatContex, CombatAvatarData avatar, int teamIndex, int playerIndex, int avatarIndex, boolean useLastHp)
	{
		this.combatContext = combatContex;
		this.avatar = avatar;
		this.teamIndex = teamIndex;
		this.playerIndex = playerIndex;
		this.avatarIndex = avatarIndex;
		this.useLastHp = useLastHp;
		this.battlePosition = avatar.getBattlePosition();

		// 获取角色装备的武器
		for (EquipmentData equipment : avatar.getEquipments())
		{
			EquipmentConfig.Equipment equipmentCfg = combatContext.getConfigDB().get_EquipmentConfig().GetEquipmentById(equipment.getId());
			if (equipmentCfg == null)
			{
				continue;
			}

			if (equipmentCfg.get_type() == EquipmentConfig._Type.Weapon)
			{
				currentWeaponType = equipmentCfg.get_weaponType();
				break;
			}
		}

		// 初始化所有属性, 这个时候只有角色的基础属性
		attributes.Initialize(avatar);

		// 添加战斗之外的属性加成, 注意:战斗外加成,霸气加成和战斗内加成为连乘的关系
		AddAllModifierSet(avatar.getModifierSets(), false);

		//计算守护机关兽的数据
		if (avatar.guardBeastData != null)
		{
			this.guardBeast = new GuardBeast();
			this.guardBeast.initiailize(combatContext, avatar.guardBeastData);
		}

		//机关兽接口测试用+++++++++++++++++++++++++++++++++++++++++++++++++
		//提取直接配置给角色的触发式Action
		ArrayList<Integer> interfaceActionIds = new ArrayList<>();

		for (SkillData skill : avatar.getSkills())
		{
			if (skill.isCompositeSkill(combatContext.getConfigDB()))
				continue;

			CombatTurn turn = getTurnByIdFromConfig(skill.getCombatTurnID(combatContext.getConfigDB()));
			if (turn == null)
				continue;

			for (int i = 0; i < turn.Get_interfaceActionsCount(); i++)
			{
				if (!interfaceActionIds.contains(turn.Get_interfaceActionsByIndex(i)))
					interfaceActionIds.add(turn.Get_interfaceActionsByIndex(i));
			}
		}

		//获取守护机关兽身上的技能
		if (guardBeast != null)
		{
			List<Integer> actionIds = guardBeast.getInterfaceActionIds();
			for (int tempId : actionIds)
			{
				if (!interfaceActionIds.contains(tempId))
					interfaceActionIds.add(tempId);
			}
		}

		//合并保存所有该角色配置的InterfaceAction
		for (int id : interfaceActionIds)
		{
			AvatarAction actionTemp = getActionByID(id);
			if (actionTemp != null)
				triggerAbleActions.add(actionTemp);
			else
				ClientServerCommon.Logger.Error("Actoin Id ={0} Id dosen't exist.", new Object[]
				{
					id
				});
		}
	}

	public void initializeBaseAttribute()
	{
		// 这个时候会计算战斗外的modifier
		calcuateCombatAttribute(false, false, null);

		// 移除计算过的战斗外modifier
		modifierSets.clear();

		// 用计算战斗外modifier之后的属性作为基础属性
		for (CombatAttributes.Attribute attribute : attributes.getAttributes())
		{
			attribute.initValue = attribute.baseValue = attribute.value;
			attribute.modifyValue = 0;
			attribute.modifyPercentage = 1;
		}

		//千层楼战斗需要继承HP
		attributes.initializeHP(this.useLastHp, avatar.leftHP, avatar.leftMaxHP);
		attributes.initializeSP();
	}

	public void initializeDominnerAttribute()
	{
		calcuateDominnerAttribute();

		// 移除计算过的霸气modifier
		modifierSets.clear();
		//modifier已经clear了，buff留着没有意义
		buffs.clear();

		// 用计算过霸气之后的属性作为基础属性
		for (CombatAttributes.Attribute attribute : attributes.getAttributes())
		{
			attribute.initValue = attribute.baseValue = attribute.value;
			attribute.modifyValue = 0;
			attribute.modifyPercentage = 1;
		}

		attributes.initializeHP(this.useLastHp, avatar.leftHP, avatar.leftMaxHP);
		attributes.initializeSP();
	}

	public void setupJEP(JEP jep, CombatAvatar targetAvatar, AvatarAction.CombatContext combatContextCfg)
	{
		// 为公式设置角色相关的属相, 
		jep.addVariable("MaxHP", this.attributes.getAttrib(_AvatarAttributeType.MaxHP).value);
		jep.addVariable("HP", this.attributes.getAttrib(_AvatarAttributeType.HP).value);
		jep.addVariable("DHP", this.attributes.getAttrib(_AvatarAttributeType.DHP).value);
		jep.addVariable("PAP", this.attributes.getAttrib(_AvatarAttributeType.PAP).value);
		jep.addVariable("PDP", this.attributes.getAttrib(_AvatarAttributeType.PDP).value);
		jep.addVariable("MAP", this.attributes.getAttrib(_AvatarAttributeType.MAP).value);
		jep.addVariable("MDP", this.attributes.getAttrib(_AvatarAttributeType.MDP).value);
		jep.addVariable("BSP", this.attributes.getAttrib(_AvatarAttributeType.BSP).value);
		jep.addVariable("DSP", this.attributes.getAttrib(_AvatarAttributeType.DSP).value);
		jep.addVariable("SP", this.attributes.getAttrib(_AvatarAttributeType.SP).value);
		jep.addVariable("SPA", this.attributes.getAttrib(_AvatarAttributeType.SPA).value);
		jep.addVariable("SPD", this.attributes.getAttrib(_AvatarAttributeType.SPD).value);

		jep.addVariable("PAR", this.attributes.getAttrib(_AvatarAttributeType.PAR).value);
		jep.addVariable("PDR", this.attributes.getAttrib(_AvatarAttributeType.PDR).value);
		jep.addVariable("MAR", this.attributes.getAttrib(_AvatarAttributeType.MAR).value);
		jep.addVariable("MDR", this.attributes.getAttrib(_AvatarAttributeType.MDR).value);
		jep.addVariable("HR", this.attributes.getAttrib(_AvatarAttributeType.HR).value);
		jep.addVariable("DgR", this.attributes.getAttrib(_AvatarAttributeType.DgR).value);
		jep.addVariable("RR", this.attributes.getAttrib(_AvatarAttributeType.RR).value);
		jep.addVariable("CR", this.attributes.getAttrib(_AvatarAttributeType.CR).value);
		jep.addVariable("RCR", this.attributes.getAttrib(_AvatarAttributeType.RCR).value);
		jep.addVariable("AR", this.attributes.getAttrib(_AvatarAttributeType.AR).value);
		jep.addVariable("DR", this.attributes.getAttrib(_AvatarAttributeType.DR).value);
		jep.addVariable("FAR", this.attributes.getAttrib(_AvatarAttributeType.FAR).value);
		jep.addVariable("CSF", this.attributes.getAttrib(_AvatarAttributeType.CSF).value);
		jep.addVariable("SPDR", this.attributes.getAttrib(_AvatarAttributeType.SPDR).value);
		jep.addVariable("RD", this.attributes.getAttrib(_AvatarAttributeType.RD).value);
		jep.addVariable("CTLR", this.attributes.getAttrib(_AvatarAttributeType.CTLR).value);
		jep.addVariable("RCTL", this.attributes.getAttrib(_AvatarAttributeType.RCTL).value);

		//不体现在界面中，仅战斗中作为临时变量。
		jep.addVariable("THGA", this.attributes.getAttrib(_AvatarAttributeType.THGA).value);

		//应用机关兽的属性
		//TODO：如果能只在机关兽触发效果执行时设置机关兽属性可以优化性能
		if (this.guardBeast != null)
			this.guardBeast.setupJEP(jep, targetAvatar.guardBeast, combatContextCfg);

		if (targetAvatar != null)
		{
			// 为公式设置目标角色相关的属性, 
			jep.addVariable("_MaxHP", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.MaxHP).value);
			jep.addVariable("_HP", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.HP).value);
			jep.addVariable("_DHP", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.DHP).value);
			jep.addVariable("_PAP", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.PAP).value);
			jep.addVariable("_PDP", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.PDP).value);
			jep.addVariable("_MAP", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.MAP).value);
			jep.addVariable("_MDP", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.MDP).value);
			jep.addVariable("_BSP", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.BSP).value);
			jep.addVariable("_DSP", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.DSP).value);
			jep.addVariable("_SP", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.SP).value);
			jep.addVariable("_SPA", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.SPA).value);
			jep.addVariable("_SPD", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.SPD).value);

			jep.addVariable("_PAR", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.PAR).value);
			jep.addVariable("_PDR", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.PDR).value);
			jep.addVariable("_MAR", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.MAR).value);
			jep.addVariable("_MDR", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.MDR).value);
			jep.addVariable("_HR", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.HR).value);
			jep.addVariable("_DgR", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.DgR).value);
			jep.addVariable("_RR", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.RR).value);
			jep.addVariable("_CR", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.CR).value);
			jep.addVariable("_RCR", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.RCR).value);
			jep.addVariable("_AR", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.AR).value);
			jep.addVariable("_DR", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.DR).value);
			jep.addVariable("_FAR", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.FAR).value);
			jep.addVariable("_CSF", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.CSF).value);
			jep.addVariable("_SPDR", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.SPDR).value);
			jep.addVariable("_RD", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.RD).value);
			jep.addVariable("_CTLR", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.CTLR).value);
			jep.addVariable("_RCTL", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.RCTL).value);

			jep.addVariable("_THGA", targetAvatar.getAttributes().getAttrib(_AvatarAttributeType.THGA).value);
		}

		if (combatContextCfg != null)
			// 设置自定义参数
			jep.addVariable("Param1", combatContextCfg.get_Param1());
	}

	/**
	 * 计算属性之前根据当前的战斗环境取出满足触发条件的内丹属性加成（对战斗有各种影响，不单单是属性上的） 。 关于
	 * caster：对于伤害吸收的效果，TargetCondition决定的是要吸收的目标，即吸收 哪个国家的/哪个Id的/哪个技能的 等等
	 * 所造成的伤害，所以在计算我方效果是否触发时也需要敌方信息。
	 *
	 * 最复杂的情况下执行100次战斗服 calcuateCombatAttribute()或这个函数 调用量约为200000~400000左右
	 */
	private void PrepareDanModifiers(CombatAvatar caster)
	{
		long startTime = System.currentTimeMillis();
		danModifierSets.clear();
		//检索所有的内丹属性
//		for (DanAttriHolder dan : avatar.danAttriHolders)
		//使用合并的DanAttribute
		for (DanAttriHolder dan : avatar.mergedDanAttriHolders)
		{
			//战前属性调整不在战斗中起作用
			//TODO：进入战斗服直接干掉
//			if (dan.danAttribute.get_FuncType() == DanConfig._DanFuncType.AttributeModifyAfterInit_P
//					|| dan.danAttribute.get_FuncType() == DanConfig._DanFuncType.AttributeModifyAfterInit_V
//					|| dan.danAttribute.get_FuncType() == DanConfig._DanFuncType.EquipStrengthen)
//				continue;

			boolean processResult = true;
			//检查在当前战斗环境下该内丹效果是否能够被触发			
			//传递了攻击者信息，且内丹的效果是伤害吸收，则检测其是否触发
			if (caster != null && dan.danAttribute.get_FuncType() == DanConfig._DanFuncType.DamageModify_Defense)
				processResult = TargetConditionProcessor.ProcessForDanAttribute(dan.danAttribute, caster, combatContext);
			else
				processResult = TargetConditionProcessor.ProcessForDanAttribute(dan.danAttribute, this, combatContext);

			//成功触发内丹效果
			if (processResult)
			{
				PropertyModifierSet modifierSetWithLevel = dan.danAttribute.GetPropertyModifierSetByLevel(dan.level);
				if (modifierSetWithLevel != null)
					danModifierSets.add(modifierSetWithLevel);
			}
		}
		ProfilerData.prepareDanModifiersTime += System.currentTimeMillis() - startTime;
	}

	public void calcuateCombatAttribute(boolean skipBaseAttribute, boolean includeDanAttributes, CombatAvatar caster)
	{
		ProfilerData.calcuateCombatAttributeCallTime++;
		long startTime = System.currentTimeMillis();
		danModifierSets.clear();
		if (!combatContext.PeekEnv().isProcessingDominner && includeDanAttributes)
			PrepareDanModifiers(caster);
		long startTime2 = System.currentTimeMillis();
		totalModifiers.clear();
		totalModifiers.addAll(modifierSets);
		totalModifiers.addAll(danModifierSets);

		attributes.prepareCaculateValue(skipBaseAttribute);

		PropertyModifier modifier;
		// Calcuate base attribute
		for (PropertyModifierSet modifierSet : totalModifiers)
		{
			for (int i = 0; i < modifierSet.Get_modifiersCount(); i++)
			{
				modifier = modifierSet.Get_modifiersByIndex(i);
				if (modifier.get_type() != PropertyModifier._Type.AttributeModifier)
				{
					continue;
				}

				// 计算战斗属性的时候不应该有霸气modifier
				if (modifier.get_buffType() == Buff._BuffType.Domineer)
				{
					//TODO:
					//这行日志并不能检测错误，在处理霸气技的Round中，给角色加Buff后也会调到这里
					//logger.error("domineer modifier found when processing combat attribute");
					continue;
				}

				CombatAttributes.Attribute attribute = attributes.getAttrib(modifier.get_attributeType());
				if (attribute == null)
				{
					logger.error("Invalid attribute type:{}", modifier.get_attributeType());
					continue;
				}

				switch (modifier.get_modifyType())
				{
					case PropertyModifier._ValueModifyType.Replace:
						attribute.baseValue = modifier.get_attributeValue();
						break;
					case PropertyModifier._ValueModifyType.Value:
						attribute.modifyValue += modifier.get_attributeValue();
						break;
					case PropertyModifier._ValueModifyType.Percentage:
						attribute.modifyPercentage += modifier.get_attributeValue();
						break;
				}
			}
		}

		attributes.caculateValue(skipBaseAttribute);
		long endTime = System.currentTimeMillis();

		ProfilerData.calcuateCombatAttributeTime += endTime - startTime;
		ProfilerData.calcuateCombatAttributeTimeWithoutPrepareTime += endTime - startTime2;
	}

	private void calcuateDominnerAttribute()
	{
		attributes.prepareCaculateValue(false);

		// 先获取计算减益抵抗相关数据
		for (PropertyModifierSet modifierSet : modifierSets)
		{
			for (int i = 0; i < modifierSet.Get_modifiersCount(); i++)
			{
				PropertyModifier modifier = modifierSet.Get_modifiersByIndex(i);
				if (modifier.get_type() != PropertyModifier._Type.AttributeModifier)
				{
					continue;
				}

				// 计算霸气的时候所有加载角色身上的modifier都应该是霸气modifier
				if (modifier.get_buffType() != Buff._BuffType.Domineer)
				{
					logger.error("None-domineer modifier found when processing dominner attribute");
					continue;
				}

				CombatAttributes.Attribute attribute = attributes.getAttrib(modifier.get_attributeType());
				if (attribute == null)
				{
					logger.error("Invalid attribute type:{}", modifier.get_attributeType());
					continue;
				}

				// 先处理减益属性和抵抗属性
				if (modifier.get_attributeType() == _AvatarAttributeType.RD || modifier.get_attributeValue() < 0)
				{
					switch (modifier.get_modifyType())
					{
						// 霸气只有value属性的修改器
						case PropertyModifier._ValueModifyType.Value:
							attribute.modifyValue += modifier.get_attributeValue();
							break;
						case PropertyModifier._ValueModifyType.Percentage:
							attribute.modifyPercentage += modifier.get_attributeValue();
							break;
						default:
							logger.error("Invalid modify type of domineer modifier:{}", modifier.get_modifyType());
							break;
					}
				}
			}
		}

		// 计算霸气抵抗的最终属性
		CombatAttributes.Attribute attribute_RD = attributes.getAttrib(_AvatarAttributeType.RD);
		attribute_RD.CaculateValue();

		// 计算霸气抵抗之后的属性
		for (CombatAttributes.Attribute attribute : attributes.getAttributes())
		{
			if (attribute == attribute_RD)
			{
				continue;
			}

			if (attribute.type < _AvatarAttributeType.NUMBER_RATE_SPACE)
			{
				// 霸气抵抗属性对于值属性, 修改百分比系数
				attribute.modifyPercentage = Math.min(1, attribute.modifyPercentage + attribute_RD.value);
			}
			else
			{
				// 对于百分比属性, 修改值系数
				attribute.modifyValue = Math.min(0, attribute.modifyValue + attribute_RD.value);
			}
		}

		// 计算霸气增益
		for (PropertyModifierSet modifierSet : modifierSets)
		{
			for (int i = 0; i < modifierSet.Get_modifiersCount(); i++)
			{
				PropertyModifier modifier = modifierSet.Get_modifiersByIndex(i);
				if (modifier.get_type() != PropertyModifier._Type.AttributeModifier || modifier.get_buffType() != Buff._BuffType.Domineer)
					continue;

				CombatAttributes.Attribute attribute = attributes.getAttrib(modifier.get_attributeType());
				if (attribute == null)
				{
					logger.error("Invalid attribute type:{}", modifier.get_attributeType());
					continue;
				}

				// 处理霸气增益
				if (modifier.get_attributeType() != _AvatarAttributeType.RD && modifier.get_attributeValue() >= 0)
				{
					switch (modifier.get_modifyType())
					{
						// 霸气只有value和属性的修改器
						case PropertyModifier._ValueModifyType.Value:
							attribute.modifyValue += modifier.get_attributeValue();
							break;
						case PropertyModifier._ValueModifyType.Percentage:
							attribute.modifyPercentage += modifier.get_attributeValue();
							break;
						default:
							logger.error("Invalid modify type of domineer modifier:{}", modifier.get_modifyType());
							break;
					}
				}
			}

			//处理buff免疫
			for (int i = 0; i < modifierSet.Get_modifiersCount(); i++)
			{
				PropertyModifier modifier = modifierSet.Get_modifiersByIndex(i);
				if (modifier.get_type() != PropertyModifier._Type.AbilityModifier || modifier.get_buffType() != Buff._BuffType.Domineer)
					continue;

				//如果在霸气中配置了buff免疫，则整场战斗均免疫
				switch (modifier.get_abilityType())
				{
					case _AvatarAbilityType.ImmuneBuff:
						ability.alwaysKeptImmuneBuffType |= modifier.get_abilityValue();
						break;
				}

			}
		}

		// 计算最终属性
		attributes.caculateValue(false);
	}

	private void calcuateCombatAbility()
	{
		// 重新计算之前需要重置
		ability.Reset();

		// Calcuate base attribute
		for (PropertyModifierSet modifierSet : modifierSets)
		{
			for (int i = 0; i < modifierSet.Get_modifiersCount(); i++)//GetModifierCount()
			{
				PropertyModifier modifier = modifierSet.Get_modifiersByIndex(i);//GetModifier(i)
				if (modifier.get_type() != PropertyModifier._Type.AbilityModifier)
				{
					continue;
				}

				switch (modifier.get_abilityType())
				{
					case _AvatarAbilityType.ImmuneBuff:
						// Buff免疫的参数是bit合集
						ability.immuneBuffType |= modifier.get_abilityValue();
						break;
				}
			}
		}
	}

	public CombatAvatarData getAvatar()
	{
		return this.avatar;
	}

	public CombatAttributes getAttributes()
	{
		return attributes;
	}

	public float getSkillPower()
	{
		return (float) this.attributes.getAttrib(_AvatarAttributeType.SP).value;
	}

	public CombatAbility getCombatAbility()
	{
		return this.ability;
	}

	public int getCharacterType()
	{
		return combatContext.getConfigDB().get_AvatarConfig().GetAvatarById(this.avatar.getResourceId()).get_characterType();
	}

	public boolean canUseSkill()
	{
		return getSkillPower() >= combatContext.getConfigDB().get_GameConfig().get_combatSetting().get_maxSkillPower();
	}

	public int getTeamIndex()
	{
		return teamIndex;
	}

	public int getPlayerIndex()
	{
		return playerIndex;
	}

	public int getAvatarIndex()
	{
		return avatarIndex;
	}

	public int getBattlePosition()
	{
		return battlePosition;
	}

	public int getBattlePositionRow()
	{
		return (battlePosition >>> 16) & 0xFFFF;
	}

	public int getBattlePositionColumn()
	{
		return battlePosition & 0xFFFF;
	}

	public void setBattlePosition(int battlePosition)
	{
		this.battlePosition = battlePosition;
	}

	public void setBattlePosition(int row, int column)
	{
		battlePosition = ((row & 0x0000FFFF) << 16) | (column & 0x0000FFFF);
	}

	public AvatarContextStack getContextStack()
	{
		return contextStack;
	}

	public boolean getMainActionInterrupted()
	{
		return mainActionInterrupted;
	}

	public void setMainActionInterrupted(boolean tf)
	{
		mainActionInterrupted = tf;
	}

	public boolean isDead()
	{
		return attributes.getAttrib(_AvatarAttributeType.HP).value <= 0;
	}

	/*
	 * Avatar get into a state
	 */
	public void enterState(int stateType)
	{
		if (inState(stateType))
		{
			return;
		}

		for (int idx = 0; idx < combatStates.size(); idx++)
		{
			if (combatStates.get(idx) > stateType)
			{
				combatStates.add(idx, stateType);
				return;
			}
		}

		combatStates.add(stateType);
	}

	/*
	 * Avatar leave a state
	 */
	public void leaveState(int stateType)
	{
		for (int index = 0; index < combatStates.size(); index++)
		{
			if (combatStates.get(index) == stateType)
			{
				combatStates.remove(index);
				return;
			}
		}
	}

	/*
	 * Check if the avatar is in the specific state
	 */
	public boolean inState(int stateType)
	{
		for (Integer existState : combatStates)
		{
			if (stateType == existState)
			{
				return true;
			}

			if (existState > stateType)
			{
				return false;
			}
		}

		return false;
	}

	/*
	 * Add attrib modifier
	 */
	public void AddModifierSet(PropertyModifierSet modifierSet)
	{
		if (modifierSet == null)
		{
			return;
		}

		modifierSets.add(modifierSet);

		// Recalcuate attribute
		calcuateCombatAttribute(true, true, null);
		calcuateCombatAbility();
	}

	public void AddAllModifierSet(List<PropertyModifierSet> sets, boolean calcDanAttris)
	{
		if (sets == null)
		{
			return;
		}

		this.modifierSets.addAll(sets);

		// Recalcuate attribute
		calcuateCombatAttribute(true, calcDanAttris, null);
		calcuateCombatAbility();
	}

	/*
	 * Remove a attrib modifier
	 */
	public void RemoveModifierSet(PropertyModifierSet modifierSet)
	{
		if (modifierSets.remove(modifierSet) == true)
		{
			// Recalcuate attribute
			calcuateCombatAttribute(true, true, null);
			calcuateCombatAbility();
		}
	}

	public boolean canDoAction()
	{
		if (combatStates.isEmpty() == false && combatStates.get(combatStates.size() - 1) != _CombatStateType.Default)
		{
			return false;
		}

		return isDead() == false;
	}

	public void pushSkillTurnContext(int turnId, int turnLevel, int turnType)
	{
		AvatarContext context = contextStack.Push();
		context.setCurrentTurnId(turnId);
		context.setCurrentTurnLevel(turnLevel);
		context.setCurCompositeSkillID(turnId);
		context.SetCurSkillId(turnId);
		context.setCurrentTurnType(turnType);
	}

	public void pushCompositeSkillTurnContext(boolean isSupporter, int turnId, int turnType, int compositeSkillId, int turnLevel)
	{
		AvatarContext context = contextStack.Push();
		context.setCurrentTurnId(turnId);
		context.setCurrentTurnLevel(turnLevel);
		context.setCurCompositeSkillID(compositeSkillId);
		context.SetCurSkillId(compositeSkillId);
		context.setCurrentTurnType(turnType);
		context.setIsCompositeSupporter(isSupporter);
	}

	public void pushSkillPowerExtraDamageRateContext(float rate)
	{
		AvatarContext context = contextStack.Push();
		context.setSkillPowerExtraDamageRate(rate);
	}

	public void popContext()
	{
		contextStack.Pop();
	}

	/*
	 * Get action by ID for config
	 */
	public AvatarAction getActionByID(int Id)
	{
		// TODO : Get action from ID
		return combatContext.getConfigDB().get_ActionConfig().GetActionById(Id);
	}

	/*
	 * Get buff by ID for config
	 */
	public Buff getBuffById(int Id)
	{
		// TODO : Get action from ID
		return combatContext.getConfigDB().get_ActionConfig().GetBuffById(Id);
	}

	/*
	 * Get action by action type from config, priority is actionType >
	 * statesType > weaponType
	 */
	public AvatarAction getActionByType(int actionType)
	{
		int randomer = RandomWrapper.NextInt(100);

		// Get action by avatar stage from the higher priority to lower priority
		for (int stateIdx = combatStates.size() - 1; stateIdx >= 0; stateIdx--)
		{
			int stateType = combatStates.get(stateIdx);

			AvatarAction action = getActionByType(stateType, actionType,
					randomer);
			if (action != null)
			{
				return action;
			}
		}

		return getActionByType(_CombatStateType.Default, actionType, randomer);
	}

	/*
	 * Get action by ID from config
	 */
	private AvatarAction getActionByType(int stateType, int actionType, int randomer)
	{
		AvatarAction action = getRandomAction(currentWeaponType, stateType, actionType, randomer);
		if (action != null)
		{
			return action;
		}

		return getRandomAction(ClientServerCommon.EquipmentConfig._WeaponType.Empty, stateType, actionType, randomer);
	}

	private AvatarAction getRandomAction(int weaponType, int stateType, int actionType, int randomer)
	{
		int actionCount = combatContext.getConfigDB().get_ActionConfig().GetActionCountInType(weaponType, stateType, actionType);
		if (actionCount == 0)
		{
			return null;
		}

		return combatContext.getConfigDB().get_ActionConfig().GetActionInTypeByIndex(weaponType, stateType, actionType, randomer % actionCount);
	}

	/*
	 * Get action by stage type in turn from config
	 */
	public AvatarAction getActionInTurnByStage(CombatTurn turn, int stageType)
	{
		CombatTurn.Stage stage = turn.GetStage(stageType);
		if (stage != null)
		{
			switch (stage.get_valueType())
			{
				case CombatTurn.Stage._ValueType.ActionId:
					return getActionByID(stage.get_value());

				case CombatTurn.Stage._ValueType.ActionType:
					return getActionByType(stage.get_value());
			}
		}

		return null;
	}

	public CombatTurn getTurnByTypeWithRate(int turnType)
	{
		for (SkillData skilldata : avatar.getSkills())
		{
			int turnId = skilldata.getCombatTurnID(combatContext.getConfigDB());
			CombatTurn turn = getTurnByIdFromConfig(turnId);

			if (turn == null)
				return null;

			if (RandomWrapper.NextFloat() > turn.get_castRate())
				return null;

			if (turn.get_type() == turnType)
			{
				return turn;
			}
		}
		return null;
	}

	public CombatTurn getTurnByType(int turnType)
	{
		for (SkillData skilldata : avatar.getSkills())
		{
			int turnId = skilldata.getCombatTurnID(combatContext.getConfigDB());
			CombatTurn turn = getTurnByIdFromConfig(turnId);

			if (turn == null)
				return null;

			if (turn.get_type() == turnType)
			{
				return turn;
			}
		}
		return null;
	}

	/*
	 * Get turn by Id from config
	 */
	public CombatTurn getTurnByIdFromConfig(int Id)
	{
		CombatTurn turn = combatContext.getConfigDB().get_ActionConfig().GetCombatTurnByID(Id);
		if (turn == null)
		{
			SkillConfig.Skill skill = combatContext.getConfigDB().get_SkillConfig().GetSkillById(Id);
			if (skill != null && skill.get_type() == CombatTurn._Type.CompositeSkill)
			{
				logger.error("getTurnByIdFromConfig(): Turn ID is CompositeSkill Level0 Id.  " + Integer.toHexString(Id));
				return null;
			}

			logger.error("getTurnByIdFromConfig(): Turn ID Dosen't Exist, ID = " + Integer.toHexString(Id));
		}

		return turn;
	}

	/*
	 * Get turn by turn type from config
	 */
	public CombatTurn getTurnByTypeFromConfig(int turnType)
	{
		int randomer = 0;
		return combatContext.getConfigDB().get_ActionConfig().GetCombatTurnByType(turnType, randomer);
	}

	public boolean IsBuffExist(int Id)
	{
		// If the buff is existing on the avatar, return true
		for (BuffCombatdata buff : buffs)
		{
			if (buff.buff.get_id() == Id)
			{
				return true;
			}
		}

		return false;
	}

	public BuffCombatdata RefreshBuff(int Id, int levelFilter, CombatAvatar srcAvatar)
	{
		return RefreshBuff(Id, getBuffById(Id).get_duration(), levelFilter, srcAvatar);
	}

	public BuffCombatdata RefreshBuff(int Id, int duration, int levelFilter, CombatAvatar srcAvatar)
	{
		for (BuffCombatdata buff : buffs)
		{
			if (buff.buff.get_id() == Id)
			{
				// Refresh duration and context to new buff
				buff.leftTurns = duration;
				buff.context = srcAvatar != null ? srcAvatar.contextStack.DumpContext() : null;
				buff.srcAvatarIndex = srcAvatar != null ? srcAvatar.avatarIndex : -1;
				buff.ownAvatarIndex = this.avatarIndex;

				// Refresh attribute modifier
				RemoveModifierSet(buff.modifierSet);
				buff.modifierSet = null;

				for (int idx = 0; idx < buff.buff.Get_modifierSetsCount(); ++idx)//GetModifierSetCount()
				{
					PropertyModifierSet modifierSet = buff.buff.Get_modifierSetsByIndex(idx);//GetModifierSet(idx)

					// Zero LevelFiliter means for all level setting
					if (modifierSet.get_levelFilter() == 0 || modifierSet.get_levelFilter() == levelFilter)
					{
						buff.modifierSet = modifierSet;
						AddModifierSet(buff.modifierSet);
						break;
					}
				}

				return buff;
			}
		}

		return null;
	}

	/*
	 * Add a new buff by buff Id
	 */
	public BuffCombatdata AddBuffByBuffId(int Id, int levelFilter, CombatAvatar srcAvatar)
	{
		return AddBuffByBuffId(Id, getBuffById(Id).get_duration(), levelFilter, srcAvatar);
	}

	/*
	 * Add a new buff by buff Id
	 */
	public BuffCombatdata AddBuffByBuffId(int Id, int duration, int levelFilter, CombatAvatar srcAvatar)
	{
		// Increase Id allocator
		++buffInstanceIDAllocator;

		// Create a new buff and add to the avatar
		BuffCombatdata newBuff = new BuffCombatdata();
		buffs.add(newBuff);

		newBuff.instanceID = buffInstanceIDAllocator;
		newBuff.buff = getBuffById(Id);

		newBuff.leftTurns = duration;
		newBuff.context = srcAvatar != null ? srcAvatar.contextStack.DumpContext() : null;
		newBuff.srcAvatarIndex = srcAvatar != null ? srcAvatar.avatarIndex : -1;
		newBuff.ownAvatarIndex = this.avatarIndex;

		// Set modifier
		for (int idx = 0; idx < newBuff.buff.Get_modifierSetsCount(); ++idx)
		{
			PropertyModifierSet modifierSet = newBuff.buff.Get_modifierSetsByIndex(idx);

			// Zero LevelFiliter means for all level setting
			if (modifierSet.get_levelFilter() == 0 || modifierSet.get_levelFilter() == levelFilter)
			{
				newBuff.modifierSet = modifierSet;
				AddModifierSet(newBuff.modifierSet);
				break;
			}
		}

		return newBuff;
	}

	public ArrayList<BuffCombatdata> getAllBuffs()
	{
		return buffs;
	}

	public boolean HasTheBuffAddedByAvatar(int buffId, int avatarIndex)
	{
		for (BuffCombatdata buff : buffs)
		{
			if (buff.buff.get_id() == buffId && buff.srcAvatarIndex == avatarIndex)
				return true;
		}

		return false;
	}

	/*
	 * Remove buff by Buff Id
	 */
	public BuffCombatdata RemoveBuffByBuffId(int Id)
	{
		for (int index = 0; index < buffs.size(); index++)
		{
			BuffCombatdata buff = buffs.get(index);

			if (buff.buff.get_id() == Id)
			{
				RemoveModifierSet(buff.modifierSet);
				buffs.remove(index);
				return buff;
			}
		}

		return null;
	}

	/*
	 * Remove buff by instance Id
	 */
	public BuffCombatdata RemoveBuffByInstanceId(int Id)
	{
		for (int index = 0; index < buffs.size(); index++)
		{
			BuffCombatdata buff = buffs.get(index);

			if (buff.instanceID == Id)
			{
				RemoveModifierSet(buff.modifierSet);
				buffs.remove(index);
				return buff;
			}
		}

		return null;
	}

	public void recoverSP(RoundRecord roundRecord)
	{
		increaseRoundSkillPower(roundRecord, (int) getAttributes().getAttrib(_AvatarAttributeType.DSP).value);
	}

	public void recoverHP(RoundRecord roundRecord)
	{
		updateRoundHP(roundRecord, (int) getAttributes().getAttrib(_AvatarAttributeType.DHP).value);
	}

	public void increaseRoundSkillPower(RoundRecord roundRecord, float deltaSkillPower)
	{
		TurnRecord turnRecord = new TurnRecord();
		turnRecord.setAvatarIndex(avatarIndex);
		turnRecord.addRecord(increaseSkillPower(deltaSkillPower), true);
		roundRecord.addRecord(turnRecord, true);
	}

	public double setSkillPower(int value)
	{
		int changedValue = value - (int) getSkillPower();
		return this.attributes.changeSP(changedValue);
	}

	public double updateSkillPower(int deltaValue)
	{
		return this.attributes.changeSP(deltaValue);
	}

	public ActionRecord increaseSkillPower(float deltaSkillPower)
	{
		float skillPower = getSkillPower() + deltaSkillPower;
		skillPower = Math.max(0, skillPower);
		this.attributes.getAttrib(_AvatarAttributeType.SP).value = skillPower;

		return createSetSkillPowerActionRecord(deltaSkillPower);
	}

	private ActionRecord createSetSkillPowerActionRecord(float deltaSkillPower)
	{
		// Contruct add skill power action
		ActionRecord actionRecord = new ActionRecord();
		actionRecord.setSrcAvatarIndex(avatarIndex);
		actionRecord.addTargetAvatarIndex(avatarIndex);

		EventRecord eventRecord = new EventRecord(actionRecord);

		EventTargetRecord targetRecord = new EventTargetRecord();
		targetRecord.setEventType(AvatarAction.Event._Type.SetSkillPower);
		targetRecord.setTargetIndex(avatarIndex);
		targetRecord.setValue((int) Math.ceil(deltaSkillPower));

		eventRecord.addRecord(targetRecord, true);
		actionRecord.addRecord(eventRecord, true);

		return actionRecord;
	}

	public void updateRoundHP(RoundRecord roundRecord, int deltaHP)
	{
		TurnRecord turnRecord = new TurnRecord();
		turnRecord.setAvatarIndex(avatarIndex);
		turnRecord.addRecord(updateHP(deltaHP), true);
		roundRecord.addRecord(turnRecord, true);
	}

	public ActionRecord updateHP(int deltaHP)
	{
		getAttributes().changeHP(deltaHP);
		return createHealActionRecord(deltaHP);
	}

	private ActionRecord createHealActionRecord(float deltaHP)
	{
		// Contruct heal action
		ActionRecord actionRecord = new ActionRecord();
		actionRecord.setSrcAvatarIndex(avatarIndex);
		actionRecord.addTargetAvatarIndex(avatarIndex);

		EventRecord eventRecord = new EventRecord(actionRecord);

		EventTargetRecord targetRecord = new EventTargetRecord();
		targetRecord.setEventType(AvatarAction.Event._Type.Heal);
		targetRecord.setTargetIndex(avatarIndex);
		targetRecord.setValue((int) Math.ceil(deltaHP));

		eventRecord.addRecord(targetRecord, true);
		actionRecord.addRecord(eventRecord, true);

		return actionRecord;
	}

	public boolean WithMeleeCombat()
	{
		return ClientServerCommon.EquipmentConfig._WeaponType.IsMeleeWeapon(currentWeaponType);
	}

	//判断是否有属性发生变化，需要过滤HP和SP
	public boolean HasTheAttributeChange()
	{
		CombatAttributes.Attribute attr;
		for (CombatAttributes.Attribute newAttribute : attributes.getAttributes())
		{
//			if (newAttribute.type == _AvatarAttributeType.HP || newAttribute.type == _AvatarAttributeType.SP)
//				continue;
			if (newAttribute.type != _AvatarAttributeType.Speed)
				continue;

			attr = contextStack.getCombatAttributeses().getAttrib(newAttribute.type);

			if (attr != null && attr.value != newAttribute.value)
				return true;
		}

		return false;
	}

	//获取产生变化的属性（HP和SP需要过滤 产生变化也不发送给客户端）
	public List<CombatAttributes.Attribute> getChangedAttributes()
	{
		List<CombatAttributes.Attribute> addAttributes = new ArrayList<>();
		CombatAttributes.Attribute attr;

		for (CombatAttributes.Attribute newAttribute : attributes.getAttributes())
		{
//			if (newAttribute.type == _AvatarAttributeType.HP || newAttribute.type == _AvatarAttributeType.SP)
//				continue;
			if (newAttribute.type != _AvatarAttributeType.Speed)
				continue;

			attr = contextStack.getCombatAttributeses().getAttrib(newAttribute.type);
			if (attr != null && attr.value != newAttribute.value)
				addAttributes.add(newAttribute);
		}

		if (addAttributes.isEmpty())
			return null;

		contextStack.getCombatAttributeses().copy(attributes);

		return addAttributes;
	}

	/**
	 * 记录在技能释放过程中受到的伤害
	 *
	 * 涉及功能：机关兽效果 额外x%伤害。此时需要记录目标收到的伤害，用于使用百分比计算额外伤害
	 */
	public void PushCustemDmg(double customDmg)
	{
		AvatarContext newNode = contextStack.Push();
		newNode.customDmg = customDmg;
	}

	public void PushAvatarRoundState(int avatarRoundState)
	{
		AvatarContext newNode = contextStack.Push();
		newNode.avatarRoundState = avatarRoundState;
	}
}
