/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.algorithm;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import ClientServerCommon.AvatarAction;
import ClientServerCommon.IDSeg;

/**
 *
 * @author sonilics
 */
public class AvatarContextStack
{
	private Stack<AvatarContext> stack = new Stack<>();
	private int sufferedDamage = 0;//在一次技能释放过程中所受伤害
	private int causeDamage = 0;
	private List<Integer> validTargetIndexs = new ArrayList<>();
	private CombatAttributes attributes = new CombatAttributes();
	private List<CombatAttributes.Attribute> addAttributes = new ArrayList<>();

	public AvatarContext Push()
	{
		AvatarContext newNode;
		if (!stack.isEmpty())
			newNode = stack.peek().DeepClone();
		else
			newNode = new AvatarContext();

		stack.push(newNode);
		return stack.peek();
	}

	public AvatarContext Push(AvatarContext node)
	{
		stack.push(node);
		return stack.peek();
	}

	public AvatarContext Pop()
	{
		if (stack.empty())
		{
			return null;
		}
		return stack.pop();
	}

	public AvatarContext Peek()
	{
		if (stack.empty())
			return null;

		return stack.peek();
	}

	public AvatarContext DumpContext()
	{
		return stack.peek();
	}

	public boolean isCurSkillIdSet()
	{
		return stack.peek().IsCurSkillIdSet();
	}

	public int getCurSkillId()
	{
		return stack.peek().GetCurSkillId();
	}

	public int getCurrentTurnType()
	{
		return stack.peek().getCurrentTurnType();
	}

	public boolean isCurrentTurnIDSet()
	{
		return stack.peek().isCurrentTurnIDSet();
	}

	public int getCurrentTurnID()
	{
		return stack.peek().getCurrentTurnID();
	}

	public boolean isCurrentCompositeSkillIDSet()
	{
		return stack.peek().isCurCompositeSkillIDSet();
	}

	public int getCurrentCompositeSkillID()
	{
		return stack.peek().getCurCompositeSkillID();
	}

	public float getSkillPowerExtraDamageRate()
	{
		return stack.peek().getSkillPowerExtraDamageRate();
	}

	public int getCurrentTurnLevel()
	{
		return stack.peek().getCurrentTurnLevel();
	}

	public boolean isBuffInstIDToBeRemoveSet()
	{
		return stack.peek().isBuffInstIDToBeRemovedSet();
	}

	public int getBuffInstIDToBeRemoved()
	{
		return stack.peek().getBuffInstIDToBeRemoved();
	}

	public boolean isBuffIDToBeAddedSet()
	{
		return stack.peek().isBuffIDToBeAddedSet();
	}

	public int getBuffIDToBeAdded()
	{
		return stack.peek().getBuffIDToBeAdded();
	}

	public boolean isBuffDurationToBeAddedSet()
	{
		return stack.peek().isBuffDurationToBeAddedSet();
	}

	public int getBuffDurationToBeAdded()
	{
		return stack.peek().getBuffDurationToBeAdded();
	}

	public boolean isAPForDamageCaculationSet()
	{
		return stack.peek().isAPForDamageCaculationSet();
	}

	public float getApForDamageCaculation(int avatarIndex)
	{
		return stack.peek().getApForDamageCaculation(avatarIndex);
	}

	public boolean isEventCheckFlagSet()
	{
		return stack.peek().IsEventCheckFlagSet();
	}

	public boolean getEventCheckFlag(int avatarIndex)
	{
		return stack.peek().getEventCheckFlag(avatarIndex);
	}

	public int getSufferedDamage()
	{
		return sufferedDamage;
	}

	public void addSufferedDamage(int damage)
	{
		sufferedDamage += damage;
	}

	public void resetSufferedDamage()
	{
		sufferedDamage = 0;
	}

	public int getCauseDamage()
	{
		return causeDamage;
	}

	public void addCauseDamage(int damage)
	{
		causeDamage += damage;
	}

	public void resetCauseDamage()
	{
		causeDamage = 0;
	}

	public List<Integer> getValidTargets()
	{
		return validTargetIndexs;
	}

	public void addValidTarget(int index)
	{
		validTargetIndexs.add(index);
	}

	public void resetValidTargets()
	{
		validTargetIndexs.clear();
	}

	public CombatAttributes getCombatAttributeses()
	{
		return attributes;
	}

	public List<CombatAttributes.Attribute> getAddAttributes()
	{
		return addAttributes;
	}

	public boolean getIsCompositeSupporter()
	{
		return stack.peek().getIsCompositeSupporter();
	}
}
