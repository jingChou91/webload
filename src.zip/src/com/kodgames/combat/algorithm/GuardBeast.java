package com.kodgames.combat.algorithm;

import ClientServerCommon.AvatarAction;
import ClientServerCommon.BeastConfig;
import ClientServerCommon._AvatarAttributeType;
import com.kodgames.combat.record.GuardBeastData;
import com.kodgames.corgi.server.gameserver.beast.util.BeastUtil;
import java.util.ArrayList;
import java.util.List;
import org.nfunk.jep.JEP;
import system.Collections.Generic.List_1;

/**
 * 守护机关兽
 */
public class GuardBeast
{
	private CombatAttributes attributes = new CombatAttributes();
	private GuardBeastData guardBeastData;
	//守护机关兽技能
	private List<Integer> interfaceActionIds = new ArrayList<>();

	public void initiailize(CombatContext combatContext, GuardBeastData guardBeast)
	{
		this.guardBeastData = guardBeast;

		attributes.InitializeGuardBeast(guardBeast);
		attributes.prepareCaculateValue(false);
		attributes.caculateValue(false);
		interfaceActionIds = new ArrayList<>();

		BeastConfig.BreakthoughtAndLevel config = BeastUtil.getBreakthoughtAndLevelByIdAndBreakAndLevel(combatContext.getConfigDB().get_BeastConfig(), guardBeast.getId(), guardBeast.getBreakThrough(), guardBeast.getLevel());
		if (config != null)
		{
			List_1 list = config.GetAllInterfaceActionsIds();

			for (int idx = 0; idx < list.get_Count(); idx++)
			{
				int actionId =((system.ClrInt32) list.get_Item(idx)).ToInt32(null);

				//不重复添加，否则处理时可能出现问题。
				if (!interfaceActionIds.contains(actionId))
					interfaceActionIds.add(actionId);
			}
		}
	}

	public GuardBeastData getGuardBeastData()
	{
		return this.guardBeastData;
	}

	public List<Integer> getInterfaceActionIds()
	{
		return this.interfaceActionIds;
	}

	public CombatAttributes getAttributes()
	{
		return attributes;
	}

	public void setupJEP(JEP jep, GuardBeast targetBeast, AvatarAction.CombatContext combatContextCfg)
	{
		jep.addVariable("JMaxHP", this.attributes.getAttrib(_AvatarAttributeType.MaxHP).value);
		jep.addVariable("JHP", this.attributes.getAttrib(_AvatarAttributeType.HP).value);
		jep.addVariable("JDHP", this.attributes.getAttrib(_AvatarAttributeType.DHP).value);
		jep.addVariable("JPAP", this.attributes.getAttrib(_AvatarAttributeType.PAP).value);
		jep.addVariable("JPDP", this.attributes.getAttrib(_AvatarAttributeType.PDP).value);
		jep.addVariable("JMAP", this.attributes.getAttrib(_AvatarAttributeType.MAP).value);
		jep.addVariable("JMDP", this.attributes.getAttrib(_AvatarAttributeType.MDP).value);
		jep.addVariable("JBSP", this.attributes.getAttrib(_AvatarAttributeType.BSP).value);
		jep.addVariable("JDSP", this.attributes.getAttrib(_AvatarAttributeType.DSP).value);
		jep.addVariable("JSP", this.attributes.getAttrib(_AvatarAttributeType.SP).value);
		jep.addVariable("JSPA", this.attributes.getAttrib(_AvatarAttributeType.SPA).value);
		jep.addVariable("JSPD", this.attributes.getAttrib(_AvatarAttributeType.SPD).value);
		jep.addVariable("JPAR", this.attributes.getAttrib(_AvatarAttributeType.PAR).value);
		jep.addVariable("JPDR", this.attributes.getAttrib(_AvatarAttributeType.PDR).value);
		jep.addVariable("JMAR", this.attributes.getAttrib(_AvatarAttributeType.MAR).value);
		jep.addVariable("JMDR", this.attributes.getAttrib(_AvatarAttributeType.MDR).value);
		jep.addVariable("JHR", this.attributes.getAttrib(_AvatarAttributeType.HR).value);
		jep.addVariable("JDgR", this.attributes.getAttrib(_AvatarAttributeType.DgR).value);
		jep.addVariable("JRR", this.attributes.getAttrib(_AvatarAttributeType.RR).value);
		jep.addVariable("JCR", this.attributes.getAttrib(_AvatarAttributeType.CR).value);
		jep.addVariable("JRCR", this.attributes.getAttrib(_AvatarAttributeType.RCR).value);
		jep.addVariable("JAR", this.attributes.getAttrib(_AvatarAttributeType.AR).value);
		jep.addVariable("JDR", this.attributes.getAttrib(_AvatarAttributeType.DR).value);
		jep.addVariable("JFAR", this.attributes.getAttrib(_AvatarAttributeType.FAR).value);
		jep.addVariable("JCSF", this.attributes.getAttrib(_AvatarAttributeType.CSF).value);
		jep.addVariable("JSPDR", this.attributes.getAttrib(_AvatarAttributeType.SPDR).value);
		jep.addVariable("JRD", this.attributes.getAttrib(_AvatarAttributeType.RD).value);
		jep.addVariable("JCTLR", this.attributes.getAttrib(_AvatarAttributeType.CTLR).value);
		jep.addVariable("JRCTL", this.attributes.getAttrib(_AvatarAttributeType.RCTL).value);
		jep.addVariable("JTHGA", this.attributes.getAttrib(_AvatarAttributeType.THGA).value);

		if (targetBeast != null)
		{
			jep.addVariable("_JMaxHP", targetBeast.attributes.getAttrib(_AvatarAttributeType.MaxHP).value);
			jep.addVariable("_JHP", targetBeast.attributes.getAttrib(_AvatarAttributeType.HP).value);
			jep.addVariable("_JDHP", targetBeast.attributes.getAttrib(_AvatarAttributeType.DHP).value);
			jep.addVariable("_JPAP", targetBeast.attributes.getAttrib(_AvatarAttributeType.PAP).value);
			jep.addVariable("_JPDP", targetBeast.attributes.getAttrib(_AvatarAttributeType.PDP).value);
			jep.addVariable("_JMAP", targetBeast.attributes.getAttrib(_AvatarAttributeType.MAP).value);
			jep.addVariable("_JMDP", targetBeast.attributes.getAttrib(_AvatarAttributeType.MDP).value);
			jep.addVariable("_JBSP", targetBeast.attributes.getAttrib(_AvatarAttributeType.BSP).value);
			jep.addVariable("_JDSP", targetBeast.attributes.getAttrib(_AvatarAttributeType.DSP).value);
			jep.addVariable("_JSP", targetBeast.attributes.getAttrib(_AvatarAttributeType.SP).value);
			jep.addVariable("_JSPA", targetBeast.attributes.getAttrib(_AvatarAttributeType.SPA).value);
			jep.addVariable("_JSPD", targetBeast.attributes.getAttrib(_AvatarAttributeType.SPD).value);
			jep.addVariable("_JPAR", targetBeast.attributes.getAttrib(_AvatarAttributeType.PAR).value);
			jep.addVariable("_JPDR", targetBeast.attributes.getAttrib(_AvatarAttributeType.PDR).value);
			jep.addVariable("_JMAR", targetBeast.attributes.getAttrib(_AvatarAttributeType.MAR).value);
			jep.addVariable("_JMDR", targetBeast.attributes.getAttrib(_AvatarAttributeType.MDR).value);
			jep.addVariable("_JHR", targetBeast.attributes.getAttrib(_AvatarAttributeType.HR).value);
			jep.addVariable("_JDgR", targetBeast.attributes.getAttrib(_AvatarAttributeType.DgR).value);
			jep.addVariable("_JRR", targetBeast.attributes.getAttrib(_AvatarAttributeType.RR).value);
			jep.addVariable("_JCR", targetBeast.attributes.getAttrib(_AvatarAttributeType.CR).value);
			jep.addVariable("_JRCR", targetBeast.attributes.getAttrib(_AvatarAttributeType.RCR).value);
			jep.addVariable("_JAR", targetBeast.attributes.getAttrib(_AvatarAttributeType.AR).value);
			jep.addVariable("_JDR", targetBeast.attributes.getAttrib(_AvatarAttributeType.DR).value);
			jep.addVariable("_JFAR", targetBeast.attributes.getAttrib(_AvatarAttributeType.FAR).value);
			jep.addVariable("_JCSF", targetBeast.attributes.getAttrib(_AvatarAttributeType.CSF).value);
			jep.addVariable("_JSPDR", targetBeast.attributes.getAttrib(_AvatarAttributeType.SPDR).value);
			jep.addVariable("_JRD", targetBeast.attributes.getAttrib(_AvatarAttributeType.RD).value);
			jep.addVariable("_JCTLR", targetBeast.attributes.getAttrib(_AvatarAttributeType.CTLR).value);
			jep.addVariable("_JRCTL", targetBeast.attributes.getAttrib(_AvatarAttributeType.RCTL).value);
			jep.addVariable("_JTHGA", targetBeast.attributes.getAttrib(_AvatarAttributeType.THGA).value);
		}
		else
		{
			jep.addVariable("_JMaxHP", 0);
			jep.addVariable("_JHP", 0);
			jep.addVariable("_JDHP", 0);
			jep.addVariable("_JPAP", 0);
			jep.addVariable("_JPDP", 0);
			jep.addVariable("_JMAP", 0);
			jep.addVariable("_JMDP", 0);
			jep.addVariable("_JBSP", 0);
			jep.addVariable("_JDSP", 0);
			jep.addVariable("_JSP", 0);
			jep.addVariable("_JSPA", 0);
			jep.addVariable("_JSPD", 0);
			jep.addVariable("_JPAR", 0);
			jep.addVariable("_JPDR", 0);
			jep.addVariable("_JMAR", 0);
			jep.addVariable("_JMDR", 0);
			jep.addVariable("_JHR", 0);
			jep.addVariable("_JDgR", 0);
			jep.addVariable("_JRR", 0);
			jep.addVariable("_JCR", 0);
			jep.addVariable("_JRCR", 0);
			jep.addVariable("_JAR", 0);
			jep.addVariable("_JDR", 0);
			jep.addVariable("_JFAR", 0);
			jep.addVariable("_JCSF", 0);
			jep.addVariable("_JSPDR", 0);
			jep.addVariable("_JRD", 0);
			jep.addVariable("_JCTLR", 0);
			jep.addVariable("_JRCTL", 0);
			jep.addVariable("_JTHGA", 0);
		}
	}
}
