/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.algorithm;

import java.util.ArrayList;
import java.util.List;

import system.Diagnostics.Debug;
import ClientServerCommon.AvatarAction;
import ClientServerCommon.CombatTurn;
import ClientServerCommon.IDSeg;
import ClientServerCommon.TargetCondition;

/**
 *
 * @author sonilics
 */
public final class AvatarContext
{
	private int currentTurnID = IDSeg.InvalidId;
	private int curCompositeSkillID = IDSeg.InvalidId;
	private int currentTurnLevel = AvatarAction.CombatContext._InvalidValue.levelFilter;
	private int buffInstIDToBeRemoved = IDSeg.InvalidId;
	private int buffIDToBeAdded = IDSeg.InvalidId;
	private int buffDurationToBeAdded = AvatarAction.CombatContext._InvalidValue.buffDurationToBeAdded;
	private List<Float> valueForHealCaculateions = null;
	private List<Float> apForDamageCaculations = null;
	private List<Boolean> eventCheckFlags = null;
	private float skillPowerExtraDamageRate = 1.0f;
	private int currentSkillId = IDSeg.InvalidId;
	private int currentTurnType = CombatTurn._Type.Unknown;
	private boolean isCompositeSupporter = false;//在组合技的释放中，是否为辅助者

	/**
	 * 闪避了别人的一次攻击
	 */
	public boolean dodged = false;
	/**
	 * 一次攻击被别人闪避
	 */
	public boolean beDodged = false;
	/**
	 * 一次攻击队目标造成了暴击
	 */
	public boolean critical = false;
	/**
	 * 被暴击了一次
	 */
	public boolean beCritical = false;

	public double customDmg = 0;

	public int avatarRoundState = TargetCondition._SubType.Invalid;

	public AvatarContext()
	{
		Reset();
	}

	public void Reset()
	{
		currentTurnID = IDSeg.InvalidId;
		currentTurnLevel = AvatarAction.CombatContext._InvalidValue.levelFilter;
		curCompositeSkillID = IDSeg.InvalidId;
		setCurrentTurnType(CombatTurn._Type.Unknown);
		setIsCompositeSupporter(false);
		dodged = false;
		beDodged = false;
		critical = false;
		beCritical = false;
		customDmg = 0;
		avatarRoundState = TargetCondition._SubType.Invalid;

		ResetExceptTurnID();
	}

	public void ResetExceptTurnID()
	{
		buffInstIDToBeRemoved = IDSeg.InvalidId;
		buffIDToBeAdded = IDSeg.InvalidId;
		buffDurationToBeAdded = AvatarAction.CombatContext._InvalidValue.buffDurationToBeAdded;

		if (valueForHealCaculateions != null)
		{
			valueForHealCaculateions.clear();
		}

		if (apForDamageCaculations != null)
		{
			apForDamageCaculations.clear();
		}

		if (eventCheckFlags != null)
		{
			eventCheckFlags.clear();
		}
	}

	public AvatarContext DeepClone()
	{
		AvatarContext result = new AvatarContext();
		result.setCurrentTurnId(this.currentTurnID);
		result.setCurCompositeSkillID(this.curCompositeSkillID);
		result.setCurrentTurnLevel(this.currentTurnLevel);
		result.setBuffInstIDToBeRemoved(this.buffInstIDToBeRemoved);
		result.setBuffIDToBeAdded(this.buffIDToBeAdded);
		result.setBuffDurationToBeAdded(this.buffDurationToBeAdded);
		result.setIsCompositeSupporter(this.getIsCompositeSupporter());
		result.dodged = this.dodged;
		result.beDodged = this.beDodged;
		result.critical = this.critical;
		result.beCritical = this.beCritical;
		result.customDmg = this.customDmg;
		result.avatarRoundState = this.avatarRoundState;
		result.setCurrentTurnType(this.getCurrentTurnType());

		if (this.valueForHealCaculateions != null)
		{
			result.valueForHealCaculateions = new ArrayList<>();
			result.valueForHealCaculateions.addAll(this.valueForHealCaculateions);
		}
		if (this.apForDamageCaculations != null)
		{
			result.apForDamageCaculations = new ArrayList<>();
			result.apForDamageCaculations.addAll(this.apForDamageCaculations);
		}
		if (this.eventCheckFlags != null)
		{
			result.eventCheckFlags = new ArrayList<>();
			result.eventCheckFlags.addAll(this.eventCheckFlags);
		}
		result.setSkillPowerExtraDamageRate(skillPowerExtraDamageRate);

		result.SetCurSkillId(currentSkillId);

		return result;
	}

	public boolean IsCurSkillIdSet()
	{
		return GetCurSkillId() != IDSeg.InvalidId;
	}

	public int GetCurSkillId()
	{
		return currentSkillId;
	}

	public void SetCurSkillId(int currentSkillId)
	{
		this.currentSkillId = currentSkillId;
	}

	public boolean isCurrentTurnIDSet()
	{
		return getCurrentTurnID() != IDSeg.InvalidId;
	}

	public int getCurrentTurnID()
	{
		return currentTurnID;
	}

	public void setCurrentTurnId(int currentTurnID)
	{
		this.currentTurnID = currentTurnID;
	}

	public int getCurrentTurnLevel()
	{
		return currentTurnLevel;
	}

	public boolean isCurCompositeSkillIDSet()
	{
		return getCurCompositeSkillID() != IDSeg.InvalidId;
	}

	public void setCurCompositeSkillID(int compositeTurnID)
	{
		this.curCompositeSkillID = compositeTurnID;
	}

	public int getCurCompositeSkillID()
	{
		return curCompositeSkillID;
	}

	public void setCurrentTurnLevel(int currentTurnLevel)
	{
		this.currentTurnLevel = currentTurnLevel;
	}

	public boolean isSkillPowerExtraDamageRateSet()
	{
		if (Math.abs(getSkillPowerExtraDamageRate() - 1.0f) < 0.00000001)
		{
			return false;
		}

		return true;
	}

	public float getSkillPowerExtraDamageRate()
	{
		return skillPowerExtraDamageRate;
	}

	public void setSkillPowerExtraDamageRate(float skillPowerExtraDamageRate)
	{
		this.skillPowerExtraDamageRate = skillPowerExtraDamageRate;
	}

	public boolean isBuffInstIDToBeRemovedSet()
	{
		return getBuffInstIDToBeRemoved() != IDSeg.InvalidId;
	}

	public int getBuffInstIDToBeRemoved()
	{
		return buffInstIDToBeRemoved;
	}

	public void setBuffInstIDToBeRemoved(int buffInstIDToBeRemoved)
	{
		this.buffInstIDToBeRemoved = buffInstIDToBeRemoved;
	}

	public boolean isBuffIDToBeAddedSet()
	{
		return getBuffIDToBeAdded() != IDSeg.InvalidId;
	}

	public int getBuffIDToBeAdded()
	{
		return buffIDToBeAdded;
	}

	public void setBuffIDToBeAdded(int buffIDToBeAdded)
	{
		this.buffIDToBeAdded = buffIDToBeAdded;
	}

	public boolean isBuffDurationToBeAddedSet()
	{
		return getBuffDurationToBeAdded() != AvatarAction.CombatContext._InvalidValue.buffDurationToBeAdded;
	}

	public int getBuffDurationToBeAdded()
	{
		return buffDurationToBeAdded;
	}

	public void setBuffDurationToBeAdded(int buffDurationToBeAdded)
	{
		this.buffDurationToBeAdded = buffDurationToBeAdded;
	}

	public boolean isValueForHealCaculationSet()
	{
		return valueForHealCaculateions != null && valueForHealCaculateions.isEmpty();
	}

	public float getValueForHealCaculateion(int avatarIndex)
	{
		if (valueForHealCaculateions != null && avatarIndex < valueForHealCaculateions.size())
		{
			return valueForHealCaculateions.get(avatarIndex);
		}
		else
		{
			return 0;
		}
	}

	public int getValueForHealCaculateionCount()
	{
		if (valueForHealCaculateions != null)
		{
			return valueForHealCaculateions.size();
		}
		else
		{
			return 0;
		}
	}

	public void setValueForHealCaculateion(int avatarIndex, float valueForHealCaculateion)
	{
		if (valueForHealCaculateions == null)
		{
			valueForHealCaculateions = new ArrayList<>();
		}

		Debug.Assert(avatarIndex <= valueForHealCaculateions.size());
		if (avatarIndex >= valueForHealCaculateions.size())
		{
			valueForHealCaculateions.add(valueForHealCaculateion);
		}
		else
		{
			valueForHealCaculateions.set(avatarIndex, valueForHealCaculateion);
		}
	}

	public boolean isAPForDamageCaculationSet()
	{
		return apForDamageCaculations != null && !apForDamageCaculations.isEmpty();
	}

	public float getApForDamageCaculation(int avatarIndex)
	{
		if (apForDamageCaculations != null && avatarIndex < apForDamageCaculations.size())
		{
			return apForDamageCaculations.get(avatarIndex);
		}
		else
		{
			return 0;
		}
	}

	public int getApForDamageCaculationCount()
	{
		if (apForDamageCaculations != null)
		{
			return apForDamageCaculations.size();
		}
		else
		{
			return 0;
		}
	}

	public void setApForDamageCaculation(int avatarIndex, float apForDamageCaculation)
	{
		if (apForDamageCaculations == null)
		{
			apForDamageCaculations = new ArrayList<>();
		}

		Debug.Assert(avatarIndex <= apForDamageCaculations.size());
		if (avatarIndex >= apForDamageCaculations.size())
		{
			apForDamageCaculations.add(apForDamageCaculation);
		}
		else
		{
			apForDamageCaculations.set(avatarIndex, apForDamageCaculation);
		}
	}

	public boolean IsEventCheckFlagSet()
	{
		return eventCheckFlags != null && !eventCheckFlags.isEmpty();
	}

	public float getEventCheckFlagCount()
	{
		if (eventCheckFlags != null)
		{
			return eventCheckFlags.size();
		}
		else
		{
			return 0;
		}
	}

	public boolean getEventCheckFlag(int avatarIndex)
	{
		if (eventCheckFlags != null && avatarIndex < eventCheckFlags.size())
		{
			return eventCheckFlags.get(avatarIndex);
		}
		else
		{
			return false;
		}
	}

	public void setEventCheckFlag(int avatarIndex, boolean flag)
	{
		if (eventCheckFlags == null)
		{
			eventCheckFlags = new ArrayList<>();
		}

		Debug.Assert(avatarIndex <= eventCheckFlags.size());
		if (avatarIndex >= eventCheckFlags.size())
		{
			eventCheckFlags.add(flag);
		}
		else
		{
			eventCheckFlags.set(avatarIndex, flag);
		}
	}

	public int getCurrentTurnType()
	{
		return currentTurnType;
	}

	public void setCurrentTurnType(int currentTurnType)
	{
		this.currentTurnType = currentTurnType;
	}

	public boolean getIsCompositeSupporter()
	{
		return isCompositeSupporter;
	}

	public void setIsCompositeSupporter(boolean isCompositeSupporter)
	{
		this.isCompositeSupporter = isCompositeSupporter;
	}
}
