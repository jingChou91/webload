/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.algorithm;

/**
 *
 * @author koduser
 */
public final class CombatAbility
{
	public int immuneBuffType;
	//角色始终具有的buff免疫效果，例如在霸气中配置免疫效果时。
	public int alwaysKeptImmuneBuffType;

	public CombatAbility()
	{
		alwaysKeptImmuneBuffType = ClientServerCommon.Buff._BuffType.Unknown;
		Reset();
	}

	public void Reset()
	{
		immuneBuffType = alwaysKeptImmuneBuffType;
	}
}
