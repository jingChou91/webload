package com.kodgames.combat.algorithm;

import java.util.ArrayList;
import org.nfunk.jep.JEP;

/**
 * 战斗中记录战斗队伍的类, 包含队伍中的角色和其他队伍相关的战斗信息
 *
 * @author sonilics
 */
public class CombatTeam
{
	private int teamIndex;
	private ArrayList<CombatAvatar> combatAvatars = new ArrayList<>();
	private CombatFormation combatFormation;

	public CombatTeam(CombatContext combatContext, int teamIndex)
	{
		this.teamIndex = teamIndex;
		this.combatFormation = new CombatFormation(combatContext);
	}

	public CombatAvatar getCombatAvatarByBattlePosition(int row, int column)
	{
		for (CombatAvatar combatAvatar : combatAvatars)
		{
			if (combatAvatar.getBattlePositionRow() == row && combatAvatar.getBattlePositionColumn() == column)
			{
				return combatAvatar;
			}
		}

		return null;
	}

	public void initialize()
	{
		for (CombatAvatar avatar : combatAvatars)
		{
			combatFormation.setAvatar(avatar);
		}
	}

	public int getTeamIndex()
	{
		return teamIndex;
	}

	public int getEvaluation()
	{
		int evaluation = 0;
		for (CombatAvatar combatAvatar : combatAvatars)
		{
			evaluation += combatAvatar.getAvatar().getEvaluation();
		}

		return evaluation;
	}

	public ArrayList<CombatAvatar> getAvatars()
	{
		return combatAvatars;
	}

	public CombatFormation getFormation()
	{
		return combatFormation;
	}

	public boolean hasAliveAvatar()
	{
		for (CombatAvatar combatAvatar : combatAvatars)
		{
			if (combatAvatar.isDead() == false)
			{
				return true;
			}
		}

		return false;
	}

	public void setupJEP(JEP jep)
	{
		jep.addVariable("TeamLiveAvatarCount", getLiveAvatarCount());
	}

	public int getLiveAvatarCount()
	{
		int liveCount = 0;
		for (CombatAvatar combatAvatar : combatAvatars)
		{
			if (combatAvatar.isDead() == false)
			{
				liveCount++;
			}
		}

		return liveCount;
	}
}
