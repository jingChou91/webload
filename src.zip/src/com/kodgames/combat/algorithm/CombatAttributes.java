package com.kodgames.combat.algorithm;

import ClientServerCommon.AttributeCalculator;
import ClientServerCommon._AvatarAttributeType;
import com.kodgames.combat.record.CombatAvatarData;
import com.kodgames.combat.record.GuardBeastData;
import java.util.Collection;
import java.util.HashMap;
import system.Collections.Generic.List_1;

public class CombatAttributes
{

	public static class Attribute
	{
		int type = 0;
		double value = 0;
		boolean baseAttrib = false; // 基础属性是指战斗开始之后, 不能通过modifier修改的属性
		double baseValue = 0;
		double modifyValue = 0;
		double modifyPercentage = 1.0f;
		double initValue = 0;
		double minValue = Double.MIN_VALUE;
		double maxValue = Double.MAX_VALUE;

		public Attribute(int type, boolean baseAttrib, double initValue, double minValue, double maxValue)
		{
			this.type = type;
			this.baseAttrib = baseAttrib;
			this.minValue = minValue;
			this.maxValue = maxValue;
		}

		public void PrepareCaculateValue()
		{
			baseValue = initValue;
			modifyValue = 0;
			modifyPercentage = 1.0f;
		}

		public void CaculateValue()
		{
			value = CaculateValueWithAddtionalModifyValue(0);
		}

		public double CaculateValueWithAddtionalModifyValue(double _modifyValue)
		{
			return Math.min(maxValue, Math.max(minValue, (baseValue + modifyValue + _modifyValue) * Math.max(0.0f, modifyPercentage)));
		}
	}
	private HashMap<Integer, Attribute> attributs = new HashMap<>();

	public void Initialize(CombatAvatarData avatar)
	{
		IntializeAttrib();

		// Set base attribute
		for (com.kodgames.combat.record.Attribute attribute : avatar.getBaseAttributes())
		{
			if (getAttrib(attribute.getType()) == null)
				continue;

			getAttrib(attribute.getType()).initValue = attribute.getValue();
		}
	}

	public void InitializeGuardBeast(GuardBeastData guardBeast)
	{
		IntializeAttrib();

		List_1 outputAttris = guardBeast.guardBeastParam.outPutAttributes;

		// Set base attribute
		for (int idx = 0; idx < outputAttris.get_Count(); idx++)
		{
			AttributeCalculator.Attribute attribute = (AttributeCalculator.Attribute) outputAttris.get_Item(idx);
			
			if (getAttrib(attribute.type) == null)
				continue;

			getAttrib(attribute.type).initValue = attribute.value;
		}
	}

	private void IntializeAttrib()
	{
		// Initialize attributes
		attributs.clear();

		//BaseAttribute=ture 则值不能通过modifier修改。
		addInitAttrib(_AvatarAttributeType.MaxHP, true);
		addInitAttrib(_AvatarAttributeType.HP, true);
		addInitAttrib(_AvatarAttributeType.DHP);
		addInitAttrib(_AvatarAttributeType.Speed);

		addInitAttrib(_AvatarAttributeType.PAP);
		addInitAttrib(_AvatarAttributeType.PDP);
		addInitAttrib(_AvatarAttributeType.MAP);
		addInitAttrib(_AvatarAttributeType.MDP);

		addInitAttrib(_AvatarAttributeType.BSP);
		addInitAttrib(_AvatarAttributeType.DSP);
		addInitAttrib(_AvatarAttributeType.SP, true);
		addInitAttrib(_AvatarAttributeType.SPA);
		addInitAttrib(_AvatarAttributeType.SPD);

		addInitAttrib(_AvatarAttributeType.PAR);
		addInitAttrib(_AvatarAttributeType.MAR);
		addInitAttrib(_AvatarAttributeType.PDR);
		addInitAttrib(_AvatarAttributeType.MDR);

		addInitAttrib(_AvatarAttributeType.HR);
		addInitAttrib(_AvatarAttributeType.DgR);
		addInitAttrib(_AvatarAttributeType.CSR);
		addInitAttrib(_AvatarAttributeType.RR);
		addInitAttrib(_AvatarAttributeType.CR);
		addInitAttrib(_AvatarAttributeType.RCR);
		addInitAttrib(_AvatarAttributeType.AR);
		addInitAttrib(_AvatarAttributeType.DR);
		addInitAttrib(_AvatarAttributeType.FAR);

		addInitAttrib(_AvatarAttributeType.CSF);
		addInitAttrib(_AvatarAttributeType.SPDR);
		addInitAttrib(_AvatarAttributeType.RD);
		addInitAttrib(_AvatarAttributeType.CTLR);
		addInitAttrib(_AvatarAttributeType.RCTL);

		addInitAttrib(_AvatarAttributeType.THGA);//治疗增益，被治疗时的增益效果
		addInitAttrib(_AvatarAttributeType.ShiledNormal);//治疗增益，被治疗时的增益效果
		addInitAttrib(_AvatarAttributeType.ShiledActive);//治疗增益，被治疗时的增益效果
		addInitAttrib(_AvatarAttributeType.ShiledComposite);//治疗增益，被治疗时的增益效果

		//内丹接口
		addInitAttrib(_AvatarAttributeType.Dan_CrtDR);//暴击伤害吸收率
		addInitAttrib(_AvatarAttributeType.Dan_CntAR);//反击伤害增强率
		addInitAttrib(_AvatarAttributeType.Dan_CntDR);//反击伤害吸收率
		addInitAttrib(_AvatarAttributeType.Dan_CmpTRA);//组合技释放附加概率
		addInitAttrib(_AvatarAttributeType.Dan_HealRA);//治疗技能效果增益
		addInitAttrib(_AvatarAttributeType.Dan_AR);//内丹伤害增益。
		addInitAttrib(_AvatarAttributeType.Dan_DR);//内丹伤害吸收。
		addInitAttrib(_AvatarAttributeType.Dan_DmgHealByDmg);//内丹伤害吸收。
		addInitAttrib(_AvatarAttributeType.Dan_DmgHealByAP);//内丹伤害吸收。
		addInitAttrib(_AvatarAttributeType.Dan_DmgHealByMaxHp);//内丹伤害吸收。
	}

	private void addInitAttrib(int type, boolean baseAttrib)
	{
		// 百分比型属性可以为负值
		if (type < _AvatarAttributeType.NUMBER_RATE_SPACE)
			attributs.put(type, new Attribute(type, baseAttrib, 0, 0, Float.MAX_VALUE));
		else
			attributs.put(type, new Attribute(type, baseAttrib, 0, -Float.MAX_VALUE, Float.MAX_VALUE));
	}

	private void addInitAttrib(int type)
	{
		addInitAttrib(type, false);
	}

	public void initializeHP(boolean isExternHP, double leftHp, double leftMaxHp)
	{
		// 最大血量至少为1
		if (getAttrib(_AvatarAttributeType.MaxHP).value < 1.0f)
			getAttrib(_AvatarAttributeType.MaxHP).value = 1.0f;

		// 继承上次的hp
		double hp = getAttrib(_AvatarAttributeType.MaxHP).value;
		if (isExternHP)
			hp *= leftHp / leftMaxHp;

		getAttrib(_AvatarAttributeType.HP).baseValue = getAttrib(_AvatarAttributeType.HP).initValue = getAttrib(_AvatarAttributeType.HP).value = hp;
	}

	public void initializeSP()
	{
		getAttrib(_AvatarAttributeType.SP).value = getAttrib(_AvatarAttributeType.BSP).value;
		getAttrib(_AvatarAttributeType.SP).baseValue = getAttrib(_AvatarAttributeType.SP).initValue = getAttrib(_AvatarAttributeType.SP).value;
	}

	public Collection<Attribute> getAttributes()
	{
		return attributs.values();
	}

	public double changeHP(int value)
	{
		double HP = getAttrib(_AvatarAttributeType.HP).value;
		double newHP = Math.min(getAttrib(_AvatarAttributeType.MaxHP).value, Math.max(HP + value, 0));
		getAttrib(_AvatarAttributeType.HP).value = newHP;
		return HP - newHP;
	}

	public double changeSP(int deltaValue)
	{
		Attribute spAttrib = getAttrib(_AvatarAttributeType.SP);
		double oldSPValue = spAttrib.value;
		spAttrib.value = Math.max(oldSPValue + deltaValue, 0);
		return spAttrib.value - oldSPValue;
	}

	public Attribute getAttrib(int type)
	{
		if (attributs.containsKey(type))
			return attributs.get(type);

		return null;
	}

	public void prepareCaculateValue(boolean skipBaseAttribute)
	{
		for (Attribute attrib : attributs.values())
		{
			if (skipBaseAttribute == true && attrib.baseAttrib == true)
				continue;

			attrib.PrepareCaculateValue();
		}
	}

	public void caculateValue(boolean skipBaseAttribute)
	{
		for (Attribute attrib : attributs.values())
		{
			if (skipBaseAttribute == true && attrib.baseAttrib == true)
				continue;

			attrib.CaculateValue();
		}
	}

	public double getAttribValue(CombatAttributes targetAvatar, int attribType)
	{
		if (targetAvatar == null)
			return getAttrib(attribType).value;

		switch (attribType)
		{
			case _AvatarAttributeType.HR:
			{
				// Get source hr with level supress
				double hr = getAttrib(_AvatarAttributeType.HR).value;
				// Get target dgr with level supress
				double dgr = targetAvatar.getAttrib(_AvatarAttributeType.DgR).value;
				// Get final hr
				double retHr = Math.max(0, hr - dgr);

				return retHr;
			}

			case _AvatarAttributeType.CSR:
			{
				// Get source csr with level supress
				double csr = getAttrib(_AvatarAttributeType.CSR).value;
				// Get target rr with level supress
				double rr = targetAvatar.getAttrib(_AvatarAttributeType.RR).value;
				// Get final csr
				double retCsr = Math.max(0, csr - rr);

				return retCsr;
			}

			case _AvatarAttributeType.CR:
			{
				// Get source csr with level supress
				double cr = getAttrib(_AvatarAttributeType.CR).value;
				// Get target rr with level supress
				double rcr = targetAvatar.getAttrib(_AvatarAttributeType.RCR).value;
				// Get final csr
				double retCsr = Math.max(0, cr - rcr);

				return retCsr;
			}

			default:
				return getAttrib(attribType).value;
		}
	}

	public void copy(CombatAttributes attrib)
	{
		Collection<Attribute> attribs = attrib.getAttributes();
		attributs.clear();

		for (Attribute newAttribute : attribs)
		{
			Attribute attribute = new Attribute(newAttribute.type, true, 0, -Float.MAX_VALUE, Float.MAX_VALUE);
			attribute.value = newAttribute.value;
			attributs.put(attribute.type, attribute);
		}
	}
}
