package com.kodgames.combat.algorithm;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.LoggerFactory;

import ClientServerCommon.*;
import ClientServerCommon.CombatTurn._TestType;
import com.kodgames.combat.record.*;
import com.kodgames.common.RandomWrapper;
import java.util.Map.Entry;

public class CombatAlgorithm
{

	private static final org.slf4j.Logger logger = LoggerFactory.getLogger(CombatAlgorithm.class);

	public static void initialize()
	{
		EventProcessor.Initialize();
		TargetConditionProcessor.Initialize();
	}

        //入口
	public static void process(ConfigDatabase configDB, List<CombatPlayer> players, int sceneId, int maxRecordCount, boolean sponsorWinWhenReachMaxRound, BattleRecord battleRecord)
	{

		// Initialize combat data
		CombatContext combatContext = new CombatContext(configDB, battleRecord);

		initializeCombatData(players, combatContext);

		//Process combat logic
		processCombat(combatContext, battleRecord, maxRecordCount);

		// Generate game result and do end action
		generateGameResult(sceneId, players, combatContext, battleRecord, maxRecordCount, sponsorWinWhenReachMaxRound);
	}

	/*
	 * Initialize data for combat from player data
	 * 初始化 ：把所有的角色属性攻击计算  添加到战斗角色里面战斗角色数据，并保存在战斗数据【combatContext】
	 */
	private static void initializeCombatData(List<CombatPlayer> players, CombatContext combatContext)
	{
		if (combatContext == null)
			LoggerFactory.getLogger(CombatAlgorithm.class).error("CombatAlgorithm initializeCombatData combatContext == null \n{}", ExceptionUtils.getStackTrace(new Throwable()));

		assert combatContext != null;
		combatContext.getPlayers().clear();
		combatContext.getAvatars().clear();

		// Construct the base data for game combat
		for (int i = 0; i < players.size(); i++)
		{
			CombatPlayer player = players.get(i);

			// 创建战斗双方对手
			combatContext.getPlayers().add(player);

			// Add combat team
			CombatTeam combatTeam = new CombatTeam(combatContext, i);
			combatContext.getTeams().add(combatTeam);

			for (CombatAvatarData avatar : player.getCombatAvatarDatas())
			{
				// 忽略不再战斗阵位之内的角色
				if (avatar.getBattlePositionRow() >= combatContext.getConfigDB().get_GameConfig().get_maxRowInFormation()
						|| avatar.getBattlePositionColumn() >= combatContext.getConfigDB().get_GameConfig().get_maxColumnInFormation())
					continue;

				avatar.PrepareMergedDanAttriHolders();
				// 创建并初始化角色 把所有是的战斗数据绑定在战斗角色身上
				CombatAvatar combatAvatar = new CombatAvatar();
				combatAvatar.initiailize(combatContext, avatar, i, i, combatContext.getAvatars().size(), player.isExtendsHP());

				combatContext.getAvatars().add(combatAvatar);
				//战斗队伍添加战斗角色
				combatTeam.getAvatars().add(combatAvatar);
			}
		}

		// Initializing
		combatContext.initialize();
	}

	private static void generateGameResult(int sceneId, List<CombatPlayer> players, CombatContext combatContext, BattleRecord combatRecord, int maxRecordCount, boolean sponsorWinWhenReachMaxRound)
	{
		// Set map ID
		combatRecord.setSceneId(sceneId);
		combatRecord.setMaxRecordCount(maxRecordCount);

		// 获取胜利队伍
		CombatTeam winnerTeam = combatContext.getWinnerTeam(sponsorWinWhenReachMaxRound);

		// 战斗结果中添加team record
		for (int playerIndex = 0; playerIndex < players.size(); ++playerIndex)
		{
			TeamRecord teamRecord = new TeamRecord();
			teamRecord.setTeamIndex(playerIndex);
			teamRecord.setIsWinner(winnerTeam.getTeamIndex() == playerIndex);
			teamRecord.setDisplayName(players.get(playerIndex).getDisplayName());
			teamRecord.setEvaluation(players.get(playerIndex).getEvaluation());

			combatRecord.getTeamRecords().add(teamRecord);
		}

		for (int idx = 0; idx < combatContext.getAvatars().size(); idx++)
		{
			CombatAvatar avatar = combatContext.getAvatars().get(idx);
			TeamRecord teamRecord = combatRecord.getTeamRecords().get(avatar.getTeamIndex());

			// Add avata result
			AvatarResult avatarResult = new AvatarResult();
			avatarResult.setAvatarIndex(idx);
			avatarResult.setTeamIndex(avatar.getTeamIndex());

			avatarResult.setMaxHP((int) (avatar.getAttributes().getAttrib(_AvatarAttributeType.MaxHP).value + 0.5));
			avatarResult.setLeftHP((int) (avatar.getAttributes().getAttrib(_AvatarAttributeType.HP).value + 0.5));
			avatarResult.setCombatAvatarData(avatar.getAvatar());

			// 如果有结束动画, 播放结束动画
			AvatarAction endAction = avatar.getActionByType(teamRecord.isWinner() ? AvatarAction._Type.Win : AvatarAction._Type.Lose);
			if (endAction != null)
			{
				avatarResult.setEndAction(new ActionRecord());
				doEndAction(avatar, endAction, avatarResult.getEndAction());
			}

			teamRecord.getAvatarResults().add(avatarResult);
		}
	}

	/*
	 * Process combat logic
	 */
	private static void processCombat(CombatContext combatContext, BattleRecord result, int maxRecordCount)
	{
		combatContext.PushCheckTriggerAction(false);//不进行机关兽效果触发
		//攻击目标
		OrderedStateCollector mainTargetCollector = new OrderedStateCollector();
		//攻击人数
		mainTargetCollector.Initialize(combatContext.getAvatars().size());

		// 初始化角色基础属性
		combatContext.initializeAttribute();

		//在这些处理中关闭对内丹效果的处理==============================================================
		CombatEnv env = combatContext.PushEnvStack();
		env.isProcessingDominner = true;

		// 霸气技能
		RoundRecord dominnerSkillRound = processDomineerSkillRound(combatContext, mainTargetCollector);

		// 计算霸气加成后的属性
		combatContext.initializeDominnerAttribute();

		// 战斗初始属性计算完毕
		combatContext.finishAttributeInitialization();

		// 下面开始战斗回合计算过程
		// 进场之后移动到战斗点
		processEnterBattlePositionRound(combatContext, mainTargetCollector, result.getCombatRecord());

		//只播放霸气技特效，从Round中移除所有逻辑事件（addbuff）
		processDomineerSkillPfxRound(result.getCombatRecord(), dominnerSkillRound);

		combatContext.PopCombatEnviroment();//Pop isProcessingDominner
		combatContext.PopCombatEnviroment();//Pop checkTriggerAction

		// 正式战斗循环
		while (isGameOver(combatContext) == false && combatContext.getTotalRoundCount() < maxRecordCount)
		{
			//回合前机关兽技能接口处理
			combatContext.PushRoundState(TargetCondition._SubType.RoundStart);
			CheckInterfaceActionGlobal(combatContext);
			combatContext.PopCombatEnviroment();

			// 按照avatar的速度属性排序, 决定出手顺序 
			combatContext.ResortAvatarBySpeed();

			boolean isOver = false;
			// 处理所有角色, 在processCombatRound中会按照顺序处理
			int avatarCount = combatContext.getAvatars().size();
			for (int i = 0; i < avatarCount; i++)
			{
				processCombatRound(combatContext, mainTargetCollector, result.getCombatRecord());
				// 某个角色出手之后 就可能导致结束
				if (isGameOver(combatContext))
				{
					isOver = true;
					break;
				}
			}

			if (isOver)
				break;

			//T回合结束前机关兽技能接口处理
			combatContext.PushRoundState(TargetCondition._SubType.BeforeRoundEnd);
			CheckInterfaceActionGlobal(combatContext);
			combatContext.PopCombatEnviroment();

			combatContext.PushCheckTriggerAction(false);//不触发机关兽技能接口
			{
				// 每回合的最后统一结算buff的回合数和更新buff状态
				processBuffRound(combatContext, result.getCombatRecord());
				// 回合最后根据相关属性值自动恢复怒气和血
				processAutoRecoverRound(combatContext, result.getCombatRecord());
			}
			combatContext.PopCombatEnviroment();

			combatContext.increaseTotalRoundCount();
		}

		combatContext.interfaceCtxMgr.triggerTimeDicBattle.clear();
	}

	private static void processEnterBattlePositionRound(CombatContext combatContext, OrderedStateCollector mainTargetCollector, CombatRecord combatRecord)
	{
		RoundRecord roundRecord = new RoundRecord();
		roundRecord.setRoundType(_CombatRoundType.EnterBattleGround);

		for (CombatTeam team : combatContext.getTeams())
		// Must do the action by battle position row order
		{
			for (int i = 0; i < combatContext.getConfigDB().get_GameConfig().get_maxRowInFormation(); ++i)
			{
				Iterator<CombatAvatar> iter = team.getFormation().columnIterator(i);
				while (iter.hasNext())
				{
					CombatAvatar avatar = iter.next();
					if (avatar != null && avatar.canDoAction())
					{
						// boss 不往前跑
						if (avatar.getBattlePositionRow() == 2)
							continue;

						// Create turn record
						TurnRecord turnRecord = new TurnRecord();
						turnRecord.setAvatarIndex(avatar.getAvatarIndex());

						mainTargetCollector.Initialize(combatContext.getAvatars().size(), false);
						mainTargetCollector.SetState(avatar.getAvatarIndex(), true);

						AvatarAction moveAction = avatar.getActionByType(AvatarAction._Type.EnterBattleGround);
						doAction(avatar, moveAction, combatContext, mainTargetCollector, false, null, turnRecord);

						roundRecord.addRecord(turnRecord, true);
					}
				}
			}
		}

		combatRecord.addRecord(roundRecord, true);
	}

	private static void processCombatRound(CombatContext combatContext, OrderedStateCollector mainTargetCollector, CombatRecord combatRecord)
	{
		CombatAvatar combatAvatar = combatContext.getCurrentActionCombatAvatar();
		if (!combatAvatar.canDoAction())
			return;

		//角色释放技能。
		processSkillRound(combatContext, combatAvatar, mainTargetCollector, combatRecord);

		//单人出手结束时检测触发，有些效果为“当角色出手完成时如果。。。。"的条件。
		OrderedStateCollector collector = new OrderedStateCollector();
		//此时没有目标的概念。
		collector.Initialize(mainTargetCollector.GetStateCount(), false);
		collector.SetState(combatAvatar.getAvatarIndex(), true);
		//设置角色的回合状态为"技能释放完毕（出手完毕前）"
		combatAvatar.PushAvatarRoundState(TargetCondition._SubType.State_OnSkillCasted);
		CheckInterfaceAction(false, combatAvatar, null, combatContext, collector, null);
		combatAvatar.popContext();
		//执行触发的机关兽接口
		processTriggeredActionRound(combatAvatar, combatContext, combatRecord);

		combatAvatar.getContextStack().resetCauseDamage();
		combatAvatar.getContextStack().resetValidTargets();

		//每次技能释放完毕后重置所受伤害
		for (int i = 0; i < combatContext.getAvatars().size(); i++)
		{
			combatContext.getAvatars().get(i).getContextStack().resetSufferedDamage();
		}
	}

	private static void CheckInterfaceActionGlobal(CombatContext combatContext)
	{
		OrderedStateCollector temp = new OrderedStateCollector();
		int avatarCount = combatContext.getAvatars().size();

		for (int idx = 0; idx < avatarCount; idx++)
		{
			CombatAvatar avatar = combatContext.getCombatAvatarByIndex(idx);

			//这里需要找策划确认
			if (!avatar.canDoAction())
				continue;

			temp.Initialize(avatarCount, false);
			temp.SetState(idx, true);
			CheckInterfaceAction(false, avatar, null, combatContext, temp, null);
		}
	}

	/**
	 * 执行触发的机关兽接口
	 *
	 * TODO:注意，由于是执行时属于正常的技能Action逻辑，，所以所有对内丹的判断都会正常执行。 目前不允许触发一下内丹效果：
	 *
	 * 1、条件为技能类型的内丹
	 */
	private static void processTriggeredActionRound(CombatAvatar caster, CombatContext combatContext, CombatRecord combatRecord)
	{
		combatContext.PushCheckTriggerAction(false);

		//记录在技能释放过程中受到的伤害，用于支持上下文相关的额外伤害（额外x%伤害）
		//值在DamageProcessor中用到
		for (int idx = 0; idx < combatContext.getAvatars().size(); idx++)
		{
			CombatAvatar temp = combatContext.getCombatAvatarByIndex(idx);
			temp.PushCustemDmg(temp.getContextStack().getSufferedDamage());
		}

		int casterIndex = caster.getAvatarIndex();
		ArrayList<InterfaceContext> triggeredActs;

		//出手者主动效果触发
		if (caster.canDoAction() && combatContext.interfaceCtxMgr.dic.containsKey(casterIndex))
		{

			triggeredActs = combatContext.interfaceCtxMgr.dic.get(casterIndex);
			for (InterfaceContext triggered : triggeredActs)
			{
				RoundRecord roundRcd = new RoundRecord();
				roundRcd.setRoundIndex(combatContext.getTotalRoundCount() + 1);
				roundRcd.setRoundType(_CombatRoundType.NormalCombat);
				roundRcd.setTeamIndex(caster.getTeamIndex());

				if (triggered.interfaceAction != null && RandomWrapper.NextFloat() <= triggered.interfaceAction.get_castRate())
					processTriggerAction(caster, triggered, combatContext, roundRcd);

				combatRecord.addRecord(roundRcd, true);
			}

			combatContext.interfaceCtxMgr.dic.remove(casterIndex);
		}

		//被动者被动效果触发
		Iterator<Entry<Integer, ArrayList<InterfaceContext>>> iter = combatContext.interfaceCtxMgr.dic.entrySet().iterator();

		RoundRecord roundRcd = new RoundRecord();
		roundRcd.setRoundIndex(combatContext.getTotalRoundCount() + 1);
		roundRcd.setRoundType(_CombatRoundType.NormalCombat);
		roundRcd.setTeamIndex(caster.getTeamIndex());

		while (iter.hasNext())
		{
			Entry<Integer, ArrayList<InterfaceContext>> next = iter.next();
			triggeredActs = next.getValue();

			CombatAvatar defender = combatContext.getCombatAvatarByIndex(next.getKey());
			if (defender.canDoAction())
				for (InterfaceContext triggered : triggeredActs)
				{
					//执行action，机关兽Action有触发概率
					if (triggered.interfaceAction != null && RandomWrapper.NextFloat() <= triggered.interfaceAction.get_castRate())
						processTriggerAction(defender, triggered, combatContext, roundRcd);
				}

			triggeredActs.clear();
		}

		combatRecord.addRecord(roundRcd, true);
		combatContext.interfaceCtxMgr.dic.clear();
		combatContext.interfaceCtxMgr.triggerTimeDicRound.clear();

		//弹出 记录受到的伤害
		for (int idx = 0; idx < combatContext.getAvatars().size(); idx++)
		{
			combatContext.getCombatAvatarByIndex(idx).popContext();
		}

		combatContext.PopCombatEnviroment();
	}

	private static void processTriggerAction(CombatAvatar srcAvatar, InterfaceContext triggeredCtx, CombatContext combatContext, RoundRecord roundRcd)
	{
		TurnRecord turnRcd = new TurnRecord();
		turnRcd.setAvatarIndex(srcAvatar.getAvatarIndex());

		OrderedStateCollector collector = new OrderedStateCollector();

		//默认使用触发了机关兽效果的人
		collector.CopyState(triggeredCtx.actionTriggers);
		//在结算时可能有角色不能够出手（死亡）
		for (int idx = 0; idx < collector.GetStateCount(); idx++)
		{
			if (collector.GetState(idx))
				collector.SetState(idx, !combatContext.getCombatAvatarByIndex(idx).isDead());
		}

		if (!collector.HasValidState())
			return;

		combatContext.attacker = combatContext.getCombatAvatarByIndex(triggeredCtx.attackerIdx);
		int firstDefender = collector.GetFirstValidState();
		if (firstDefender != -1)
			combatContext.defender = combatContext.getCombatAvatarByIndex(firstDefender);
		else
			combatContext.defender = null;

		//如果配置了目标选择条件则重新选择目标。
		if (triggeredCtx.interfaceAction.Get_targetConditionsCount() != 0)
		{
			collector.Initialize(combatContext.getAvatars().size());
			for (int i = 0; i < collector.GetStateCount(); i++)
			{
				collector.SetState(i, !combatContext.getCombatAvatarByIndex(i).isDead());
			}

			TargetConditionProcessor.ProcessForTriggerAction(triggeredCtx.interfaceAction, srcAvatar, combatContext, collector);
		}

		//TODO: 单独保存每个target上一轮的sufferedDamage。
		combatContext.attacker = null;
		combatContext.defender = null;

		ActionRecord actionRcd = new ActionRecord(turnRcd);

		srcAvatar.pushSkillTurnContext(0, 0, CombatTurn._Type.Unknown);

		doAction(srcAvatar, triggeredCtx.interfaceAction, combatContext, collector, true, new int[collector.GetStateCount()], actionRcd);

		srcAvatar.popContext();

		turnRcd.addRecord(actionRcd, true);
		roundRcd.addRecord(turnRcd, true);
	}

	private static RoundRecord processDomineerSkillRound(CombatContext combatContext, OrderedStateCollector mainTargetCollector)
	{
		//构建Round，进场后播放霸气技文字特效
		RoundRecord domineerSkillPfxRcd = new RoundRecord();
		domineerSkillPfxRcd.setRoundIndex(combatContext.getTotalRoundCount() + 1);
		domineerSkillPfxRcd.setRoundType(_CombatRoundType.EnterBattleSkill);

		int avatarCount = combatContext.getAvatars().size();

		for (int i = 0; i < avatarCount; i++)
		{
			CombatAvatar combatAvatar = combatContext.getCombatAvatarByIndex(i);
			if (combatAvatar.canDoAction() == false)
				continue;

			combatContext.getValueRandomer().Clear();
			for (SkillData skill : combatAvatar.getAvatar().getSkills())
			{
				if (skill.isCompositeSkill(combatContext.getConfigDB()))
					continue;

				CombatTurn skillTurn = combatAvatar.getTurnByIdFromConfig(skill.getCombatTurnID(combatContext.getConfigDB()));
				if (skillTurn == null)
					continue;

				if (skillTurn.get_type() != CombatTurn._Type.DomineerSkill)
					continue;

				// 霸气技能有一定释放概率
				if (RandomWrapper.NextFloat() > skillTurn.get_castRate())
					continue;

				// Select target
				mainTargetCollector.Initialize(combatContext.getAvatars().size());
				try
				{
					TargetConditionProcessor.Process(skillTurn, combatAvatar, combatContext, mainTargetCollector);
				}
				catch (Exception e)
				{
					throw e;
				}

				// No target, can not do this action
				assert mainTargetCollector.GetValidStateCount() != 0;
				if (mainTargetCollector.GetValidStateCount() == 0)
					continue;

				// Set combat contex
				combatAvatar.pushSkillTurnContext(skill.getCombatTurnID(combatContext.getConfigDB()), skill.getLevel(), CombatTurn._Type.DomineerSkill);

				// 霸气不需要客户端回放, 不进入战斗播放数据
				TurnRecord skillTurnRecord = new TurnRecord(skillTurn.get_id());
				skillTurnRecord.setAvatarIndex(combatAvatar.getAvatarIndex());

				// Process skill
				int[] turnTestResults = new int[combatContext.getAvatars().size()];
				processTurn(combatAvatar, skillTurn, combatContext, mainTargetCollector, skillTurnRecord, turnTestResults);

				domineerSkillPfxRcd.addRecord(skillTurnRecord, true);
			}
		}

		return domineerSkillPfxRcd;
	}

	private static void processDomineerSkillPfxRound(CombatRecord combatRecord, RoundRecord domineerSkillPfxRcd)
	{
		//移除所有逻辑事件, 客户端只播放特效
		for (int i = 0; i < domineerSkillPfxRcd.getTurnRecords().size(); i++)
		{
			TurnRecord turnTemp = domineerSkillPfxRcd.getTurnRecords().get(i);

			for (int j = 0; j < turnTemp.getActionRecords().size(); j++)
			{
				turnTemp.getActionRecords().get(j).getEventRecords().clear();
			}
		}

		combatRecord.addRecord(domineerSkillPfxRcd, true);
	}

	private static void processBuffRound(CombatContext combatContext, CombatRecord combatRecord)
	{
		RoundRecord roundRecord = new RoundRecord();
		roundRecord.setRoundIndex(combatContext.getTotalRoundCount() + 1);
		roundRecord.setRoundType(_CombatRoundType.NormalCombat);
		int avatarCount = combatContext.getAvatars().size();
		for (int i = 0; i < avatarCount; i++)
		{
			CombatAvatar avatar = combatContext.getCombatAvatarByIndex(i);
			if (!avatar.isDead() && avatar.buffs.size() > 0)
			{
				TurnRecord buffTurnRecord = new TurnRecord();
				// Update buffs
				UpdateAvatarBuffs(avatar, combatContext, buffTurnRecord);
				roundRecord.addRecord(buffTurnRecord, true);
			}
		}

		//分开处理，先处理OnUpdateBuff（如持续掉血），然后如果减益属性回合到了再去掉。
		//比如法抗降20%2回合，并2回合持续掉血，如果不分开处理则可能在处理持续掉血时可能将法抗的效果已经先消失了。
		for (int i = 0; i < avatarCount; i++)
		{
			CombatAvatar avatar = combatContext.getCombatAvatarByIndex(i);
			if (!avatar.isDead() && avatar.buffs.size() > 0)
			{
				TurnRecord buffTurnRecord = new TurnRecord();
				// CheckBuffDuration
				CheckAvatarBuffDuration(avatar, Buff._DurationCheckType.AftarRound, combatContext, buffTurnRecord);
				roundRecord.addRecord(buffTurnRecord, true);
			}
		}

		//由Dot造成的伤害不计算在角色的CauseDamage中。
		for (int i = 0; i < combatContext.getAvatars().size(); i++)
		{
			combatContext.getCombatAvatarByIndex(i).getContextStack().resetCauseDamage();
		}

		combatRecord.addRecord(roundRecord, true);
	}

	private static void processAutoRecoverRound(CombatContext combatContext, CombatRecord combatRecord)
	{
		RoundRecord roundRecord = new RoundRecord();
		roundRecord.setRoundIndex(combatContext.getTotalRoundCount() + 1);
		roundRecord.setRoundType(_CombatRoundType.NormalCombat);
		int avatarCount = combatContext.getAvatars().size();
		for (int i = 0; i < avatarCount; i++)
		{
			CombatAvatar avatar = combatContext.getCombatAvatarByIndex(i);
			if (!avatar.isDead())
			{
				avatar.recoverHP(roundRecord);
				avatar.recoverSP(roundRecord);
			}
		}

		combatRecord.addRecord(roundRecord, true);
	}

	private static boolean processSkillRound(CombatContext combatContext, CombatAvatar srcAvatar, OrderedStateCollector mainTargetCollector, CombatRecord combatRecord)
	{
		RoundRecord roundRecord = new RoundRecord();
		roundRecord.setRoundIndex(combatContext.getTotalRoundCount() + 1);

		//选取组合技
		CombatTurn skillTurn = null;

		//应用内丹属性
		srcAvatar.calcuateCombatAttribute(true, true, null);

		//组合技要先判断角色能不能出手，因为辅助角色要也要做Action
		if (srcAvatar.canDoAction())
			skillTurn = selectCompositeTurnAndTarget_PlayerSkill(srcAvatar, combatContext, mainTargetCollector, true);

		if (skillTurn == null)
		{
			// 选取暴走技，如果暴走技不符合释放条件，就选取蓄力技能(蓄力技就是普通攻击)
			skillTurn = selectTurnAndTarget_PlayerSkill(srcAvatar, combatContext, mainTargetCollector, CombatTurn._Type.ActiveSkill, false);
			if (skillTurn == null)
			{
				//普通攻击
				roundRecord.setRoundType(_CombatRoundType.NormalCombat);

				skillTurn = selectTurnAndTarget_PlayerSkill(srcAvatar, combatContext, mainTargetCollector, CombatTurn._Type.NormalSkill, false);
				if (skillTurn == null)
				{
					// 没有普通攻击战斗会出错
					logger.error("Missing NormalSkill on avatar:{}", srcAvatar.getAvatar().getResourceId());
					return false;
				}
			}
			else
				//暴走技
				roundRecord.setRoundType(_CombatRoundType.ActiveSkillCombat);
		}
		else
			//组合技
			roundRecord.setRoundType(_CombatRoundType.CompositeSkillCombat);

		// 暴走技和组合技需要设置怒气溢出时候提升伤害的比例,在 Damage Event里面用到
		if (roundRecord.getRoundType() == _CombatRoundType.CompositeSkillCombat || roundRecord.getRoundType() == _CombatRoundType.ActiveSkillCombat)
			srcAvatar.pushSkillPowerExtraDamageRateContext(srcAvatar.getSkillPower() / skillTurn.get_costSkillPower());

		roundRecord.setTeamIndex(srcAvatar.getTeamIndex());

		/*
		 * Process skill
		 */
		TurnRecord skillTurnRecord = new TurnRecord(skillTurn.get_id());
		skillTurnRecord.setAvatarIndex(srcAvatar.getAvatarIndex());

		//组合技
		if (roundRecord.getRoundType() == _CombatRoundType.CompositeSkillCombat)
		{
			//TODO: 组合技释放者和辅助者谁先出手对结果的影响（是在出手前还是出手后客户端才能看到效果）

			//释放者起手Action
			AvatarAction skillStartAction = srcAvatar.getActionByType(AvatarAction._Type.CompositeSkillStart);
			if (skillStartAction != null)
				doAction(srcAvatar, skillStartAction, combatContext, mainTargetCollector, false, null, skillTurnRecord);

			//释放者先出手
			int[] turnTestResults = new int[combatContext.getAvatars().size()];
			processTurn(srcAvatar, skillTurn, combatContext, mainTargetCollector, skillTurnRecord, turnTestResults);

			//释放者削减怒气
			TurnRecord skillPowerTurnRecord = new TurnRecord();
			skillPowerTurnRecord.setAvatarIndex(-1);
			skillPowerTurnRecord.addRecord(srcAvatar.increaseSkillPower(-srcAvatar.getSkillPower()), true);

			roundRecord.addRecord(skillPowerTurnRecord, true);
			roundRecord.addRecord(skillTurnRecord, true);

			//所有辅助者出手
			ArrayList<Integer> supporterIndexes = new ArrayList<>();
			SkillData compositeSkill = GetValidCompositeSkillAndSupporterIndexes(srcAvatar, combatContext, supporterIndexes);
			int supporterActionId = compositeSkill.GetCompositeSkillInfo(combatContext.getConfigDB()).get_supporterActionId();
			for (int supporterIndex : supporterIndexes)
			{
				CombatAvatar supporter = combatContext.getCombatAvatarByIndex(supporterIndex);

				//每个辅助者的行为保存在同一个RoundRecord中的不同的TurnRecord中，目的是让所有人同时出手
				TurnRecord turnRcd = new TurnRecord();
				turnRcd.setAvatarIndex(supporterIndex);

				supporter.pushCompositeSkillTurnContext(true, skillTurn.get_id(), compositeSkill.getResourceId(), compositeSkill.getLevel(), CombatTurn._Type.CompositeSkill);

				//辅助者SkillStart（弹UI）
				if (skillStartAction != null && !supporter.isDead())
					doAction(supporter, skillStartAction, combatContext, mainTargetCollector, false, null, turnRcd);

				//如果辅助者不能行动，则没有行为，但屏幕遮罩时需要点亮，也要发到客户端
				if (!supporter.canDoAction() && !supporter.isDead())
				{
					roundRecord.addRecord(turnRcd, false);
					supporter.popContext();
					continue;
				}

				//辅助者需要做的动作。
				AvatarAction compositeSupporterAction = srcAvatar.getActionByID(supporterActionId);
				if (compositeSupporterAction != null)
				{
					ActionRecord actRcd = new ActionRecord(turnRcd);
					doAction(supporter, compositeSupporterAction, combatContext, mainTargetCollector, false, null, actRcd);
					turnRcd.addRecord(actRcd, false);
				}

				supporter.popContext();

				roundRecord.addRecord(turnRcd, true);
			}

			// 战斗上下文出栈
			srcAvatar.getContextStack().Pop();
		}
		// 暴走技
		else if (roundRecord.getRoundType() == _CombatRoundType.ActiveSkillCombat)
		{
			// 选择播放技能起始动画
			SkillConfig.Skill skillCfg = combatContext.getConfigDB().get_SkillConfig().GetSkillById(skillTurn.get_id());
			boolean isSuperSkill = false;
			if (skillCfg != null)
				isSuperSkill = skillCfg.get_isSuperSkill();

			AvatarAction skillStartAction = srcAvatar.getActionByType(isSuperSkill ? AvatarAction._Type.SuperSkillStart : AvatarAction._Type.SkillStart);
			if (skillStartAction != null)
				doAction(srcAvatar, skillStartAction, combatContext, mainTargetCollector, false, null, skillTurnRecord);

			/*
			 * 释放暴走技，重置怒气为0
			 */
			TurnRecord skillPowerTurnRecord = new TurnRecord();
			skillPowerTurnRecord.setAvatarIndex(-1);
			skillPowerTurnRecord.addRecord(srcAvatar.increaseSkillPower(-srcAvatar.getSkillPower()), true);
			roundRecord.addRecord(skillPowerTurnRecord, true);

			// 处理技能逻辑
			int[] turnTestResults = new int[combatContext.getAvatars().size()];
			processTurn(srcAvatar, skillTurn, combatContext, mainTargetCollector, skillTurnRecord, turnTestResults);
			roundRecord.addRecord(skillTurnRecord, true);

			// 战斗上下文出栈
			srcAvatar.getContextStack().Pop();
		}
		else// (roundRecord.getRoundType() == _CombatRoundType.NormalCombat)
		{
			// 处理技能逻辑
			int[] turnTestResults = new int[combatContext.getAvatars().size()];
			processTurn(srcAvatar, skillTurn, combatContext, mainTargetCollector, skillTurnRecord, turnTestResults);

			roundRecord.addRecord(skillTurnRecord, true);
		}

		combatRecord.addRecord(roundRecord, true);

		return true;
	}

	private static boolean processDeathSkillRound(CombatContext combatContext, CombatAvatar deathSkillAvatar, OrderedStateCollector mainTargetCollector, CombatRecord combatRecord)
	{
		RoundRecord roundRecord = new RoundRecord();
		roundRecord.setRoundIndex(combatContext.getTotalRoundCount() + 1);

		// Select skill
		CombatTurn skillTurn = selectTurnAndTarget_PlayerSkill(deathSkillAvatar, combatContext, mainTargetCollector, CombatTurn._Type.DeathSkill, false);
		if (skillTurn == null)
			return false;

		roundRecord.setRoundType(_CombatRoundType.ActiveSkillCombat);

		roundRecord.setTeamIndex(deathSkillAvatar.getTeamIndex());
		/*
		 * Process skill
		 */
		TurnRecord skillTurnRecord = new TurnRecord(skillTurn.get_id());
		skillTurnRecord.setAvatarIndex(deathSkillAvatar.getAvatarIndex());

		// Do skill start action
		SkillConfig.Skill skillCfg = combatContext.getConfigDB().get_SkillConfig().GetSkillById(skillTurn.get_id());
		boolean isSuperSkill = false;
		if (skillCfg != null)
		{
//			isSuperSkill = skillCfg.get_isSuperSkill();
		}

		AvatarAction skillStartAction = deathSkillAvatar.getActionByType(isSuperSkill ? AvatarAction._Type.SuperSkillStart : AvatarAction._Type.SkillStart);
		if (skillStartAction != null)
			doAction(deathSkillAvatar, skillStartAction, combatContext, mainTargetCollector, false, null, skillTurnRecord);

		// Do super skill effect action 
//		if (isSuperSkill)
//		{
//			AvatarAction superSkillEffectAction = avatar.getActionByType(AvatarAction._Type.SuperSkillEffect);
//			if (superSkillEffectAction != null)
//			{
//				doAction(avatar, superSkillEffectAction, combatContext, mainTargetCollector, false, null, skillTurnRecord);
//			}
//		}
		// Process skill
		int[] turnTestResults = new int[combatContext.getAvatars().size()];
		processTurn(deathSkillAvatar, skillTurn, combatContext, mainTargetCollector, skillTurnRecord, turnTestResults);

		AvatarAction passsiveAction = deathSkillAvatar.getActionByType(AvatarAction._Type.Die);
		OrderedStateCollector collector = new OrderedStateCollector();
		collector.Initialize(combatContext.getAvatars().size(), false);
		collector.SetState(deathSkillAvatar.getAvatarIndex(), true);
		doAction(deathSkillAvatar, passsiveAction, combatContext, collector, false, null, skillTurnRecord);
		// Remove dead avatar from formation
		CombatTeam combatTeam = combatContext.getTeams().get(deathSkillAvatar.getTeamIndex());
		combatTeam.getFormation().setAvatar(deathSkillAvatar.getBattlePositionRow(), deathSkillAvatar.getBattlePositionColumn(), null);

		roundRecord.addRecord(skillTurnRecord, true);

		// Add round record
		combatRecord.addRecord(roundRecord, true);
		deathSkillAvatar.getContextStack().Pop();

		return true;
	}

	//如果一个CombatAvatar的组合技满足释放条件（这里不考虑概率），即相关需求角色（可选的、必选的）都在场上且未死亡，返回这个组合技及相关需求角色的索引列表
	private static SkillData GetValidCompositeSkillAndSupporterIndexes(CombatAvatar srcAvatar, CombatContext combatContext, ArrayList<Integer> result)
	{
		SkillData compositeSkillData = null;
		result.clear();

		SkillConfig.CompositeSkillInfo compositeSkillInfo = null;
		for (SkillData skill : srcAvatar.getAvatar().getSkills())
		{
			compositeSkillInfo = skill.GetCompositeSkillInfo(combatContext.getConfigDB());
			if (compositeSkillInfo == null)
				continue;

			compositeSkillData = skill;
			break;
		}

		if (compositeSkillInfo == null)
			return compositeSkillData;

		SkillConfig.CompositeSkillCondition requirementCondi = compositeSkillInfo.get_requirementCondition();
		if (requirementCondi == null || requirementCondi.get_requiredCount() == 0)
			return compositeSkillData;

		int satisfiedCount = 0;
		//当前：每个Part所需求的所有ResourceID中至少要有一个Avatar在场
		for (int i = 0; i < requirementCondi.Get_partsCount(); i++)
		{
			SkillConfig.CompositeSkillCondition.Part part = requirementCondi.Get_partsByIndex(i);
			boolean satisfiedCountAdded = false;
			switch (part.get_requiredType())
			{
				case IDSeg._AssetType.Avatar:
					for (int j = 0; j < part.Get_resourceIdsCount(); j++)
					{
						//同一队有需求的人在场，如果ResourceId相同的多个人存在，全都要包含进来
						int requiredResId = part.Get_resourceIdsByIndex(j);
						int avatarCount = combatContext.getAvatars().size();

						for (int k = 0; k < avatarCount; k++)
						{
							CombatAvatar temp = combatContext.getCombatAvatarByIndex(k);

							if (temp == null || temp.getAvatarIndex() == srcAvatar.getAvatarIndex())//不包含释放者
								continue;

							if (temp.getAvatar().getResourceId() == requiredResId//ResourceId满足条件
									&& !result.contains(temp.getAvatarIndex())//未收集
									&& temp.getTeamIndex() == srcAvatar.getTeamIndex()//与释放者同一个队伍
									&& !temp.isDead())//未死亡
							{
								result.add(temp.getAvatarIndex());
								if (!satisfiedCountAdded)
								{
									//有一个，则对于这个Part满足
									satisfiedCount++;
									satisfiedCountAdded = true;
								}
							}
						}
					}
					break;
			}
		}

		//如果不是每个Part都满足
		if (satisfiedCount != requirementCondi.get_requiredCount())
		{
			result.clear();
			return null;
		}

		return compositeSkillData;
	}

	private static CombatTurn selectCompositeTurnAndTarget_PlayerSkill(CombatAvatar srcAvatar, CombatContext combatContext, OrderedStateCollector collector, boolean checkRate)
	{
		combatContext.getValueRandomer().Clear();

		ArrayList<Integer> result = new ArrayList<>();
		SkillData cSkill = GetValidCompositeSkillAndSupporterIndexes(srcAvatar, combatContext, result);
		if (cSkill != null && !result.isEmpty())//有组合技，且满足触发条件。
		{
			int turnId = cSkill.getCompositeCombatTurnID(combatContext.getConfigDB());
			CombatTurn turn = srcAvatar.getTurnByIdFromConfig(turnId);

			if (turn == null)
			{
				logger.error("selectCompositeTurnAndTarget_PlayerSkill NO CompositeSkill CombatTurn. Skill Id: " + Integer.toHexString(cSkill.getCombatTurnID(combatContext.getConfigDB())) + " CombatTurn Id:" + Integer.toHexString(turnId));
				return null;
			}

			//触发概率
			if (checkRate && RandomWrapper.NextFloat() > (turn.get_castRate() + (float) (srcAvatar.getAttributes().getAttrib(_AvatarAttributeType.Dan_CmpTRA).value)))
				return null;

			//检测怒气是否足够
			double spValue = srcAvatar.getAttributes().getAttrib(_AvatarAttributeType.SP).value;
			if (turn.get_costSkillPower() > spValue)
				return null;

			// Select target
			collector.Initialize(combatContext.getAvatars().size());
			try
			{
				TargetConditionProcessor.Process(turn, srcAvatar, combatContext, collector);
			}
			catch (Exception e)
			{
				logger.error("selectTurnAndTarget_PlayerSkill CombatTurnId={}  combatContext.getAvatars().size()={}", turn.get_id(), combatContext.getAvatars().size());
				throw e;
			}

			// No target, can not do this action
			assert collector.GetValidStateCount() != 0;
			if (collector.GetValidStateCount() == 0)
				return null;

			//设置combatTurnId、组合技技能id  和 技能等级。 等级用于LevelFilter.
			srcAvatar.pushCompositeSkillTurnContext(false, cSkill.getCompositeCombatTurnID(combatContext.getConfigDB()), cSkill.getResourceId(), cSkill.getLevel(), CombatTurn._Type.CompositeSkill);
			return turn;
		}

		return null;
	}

	/*
	 * Select a skill and the target of the skill
	 */
	private static CombatTurn selectTurnAndTarget_PlayerSkill(CombatAvatar srcAvatar, CombatContext combatContext, OrderedStateCollector collector, int turnType, boolean checkRate)
	{
		// Ramdon select a skill
		combatContext.getValueRandomer().Clear();
		for (SkillData skill : srcAvatar.getAvatar().getSkills())
		{
			if (skill.isCompositeSkill(combatContext.getConfigDB()))
				continue;

			CombatTurn turn = srcAvatar.getTurnByIdFromConfig(skill.getCombatTurnID(combatContext.getConfigDB()));
			if (turn == null)
				continue;

			//触发概率
			if (checkRate && RandomWrapper.NextFloat() > turn.get_castRate())
				return null;

			//检测怒气是否足够
			double spValue = srcAvatar.getAttributes().getAttrib(_AvatarAttributeType.SP).value;
			if (turn.get_type() != turnType || turn.get_costSkillPower() > spValue)
				continue;

			// Select target
			collector.Initialize(combatContext.getAvatars().size());
			try
			{
				TargetConditionProcessor.Process(turn, srcAvatar, combatContext, collector);
			}
			catch (Exception e)
			{
				logger.error("selectTurnAndTarget_PlayerSkill CombatTurnId={}  combatContext.getAvatars().size()={}", Integer.toHexString(turn.get_id()), combatContext.getAvatars().size());
				throw e;
			}

			// No target, can not do this action
			assert collector.GetValidStateCount() != 0;
			if (collector.GetValidStateCount() == 0)
				continue;

			// Set combat contex
			srcAvatar.pushSkillTurnContext(skill.getCombatTurnID(combatContext.getConfigDB()), skill.getLevel(), turnType);
			return turn;
		}

		return null;
	}

	private static void processTurn(CombatAvatar srcAvatar, CombatTurn turn, CombatContext combatContext, OrderedStateCollector mainTargets, TurnRecord turnRecord, int[] turnTestResults)
	{
		for (int idx = 0; idx < turnTestResults.length; idx++)
		{
			turnTestResults[idx] = CombatTurn._TestType.None;
		}

		// Reset mainActionInterrupted flag
		srcAvatar.setMainActionInterrupted(false);

		// Construct collector for temp usage
		OrderedStateCollector collector = new OrderedStateCollector();
		collector.Initialize(combatContext.getAvatars().size());

		// Do all action in this turn
		combatContext.getWoundedAvatars().clear();
		for (int stepIdx = CombatTurn.Stage._StageType.Awake; stepIdx < CombatTurn.Stage._StageType.Count; stepIdx++)
		{
			AvatarAction action = srcAvatar.getActionInTurnByStage(turn, stepIdx);

			switch (stepIdx)
			{
				case CombatTurn.Stage._StageType.Awake:
				case CombatTurn.Stage._StageType.Rush:
				case CombatTurn.Stage._StageType.Start:
				case CombatTurn.Stage._StageType.Back:
				case CombatTurn.Stage._StageType.End:
				{
					if (srcAvatar.canDoAction() && action != null)
					{
						//支持暴击和闪避
						for (int targetIdx = 0; targetIdx < mainTargets.GetStateCount(); targetIdx++)
						{
							if (mainTargets.GetState(targetIdx) == false)
								continue;

							CombatAvatar targetAvatar = combatContext.getAvatars().get(targetIdx);
							turnTestResults[targetIdx] = TestTurn(srcAvatar, targetAvatar, turn.get_testType(), CombatTurn._TestType.Dodged, turnTestResults[targetIdx], combatContext);
							turnTestResults[targetIdx] = TestTurn(srcAvatar, targetAvatar, turn.get_testType(), CombatTurn._TestType.CriticalHit, turnTestResults[targetIdx], combatContext);
						}

						doAction(srcAvatar, action, combatContext, mainTargets, true, turnTestResults, turnRecord);
					}
					break;
				}

				case CombatTurn.Stage._StageType.Main:
				{
					if ((srcAvatar.canDoAction() || srcAvatar.isCastDeathSkill) && srcAvatar.getMainActionInterrupted() == false && action != null)
					{
						/*
						 * Check dodge and CriticalHit
						 */
						for (int targetIdx = 0; targetIdx < mainTargets.GetStateCount(); targetIdx++)
						{
							if (mainTargets.GetState(targetIdx) == false)
								continue;

							CombatAvatar targetAvatar = combatContext.getAvatars().get(targetIdx);
							turnTestResults[targetIdx] = TestTurn(srcAvatar, targetAvatar, turn.get_testType(), CombatTurn._TestType.Dodged, turnTestResults[targetIdx], combatContext);
							turnTestResults[targetIdx] = TestTurn(srcAvatar, targetAvatar, turn.get_testType(), CombatTurn._TestType.CriticalHit, turnTestResults[targetIdx], combatContext);
						}

						// Do main action
						doAction(srcAvatar, action, combatContext, mainTargets, true, turnTestResults, turnRecord);

					}

					break;
				}

				//Counter阶段服务器专用，不可配置
				case CombatTurn.Stage._StageType.Counter:
				{
					//反击时不能触发机关兽接口
					/*
					 * 处理反击逻辑
					 */
					// 反击顺序需要按照速度排序
					combatContext.sortWoundedAvatars();

					int[] testResults = new int[combatContext.getAvatars().size()];

					for (int i = 0; i < combatContext.getWoundedAvatars().size(); i++)
					{

						CombatAvatar targetAvatar = combatContext.getWoundedAvatars().get(i);
						int targetIdx = targetAvatar.getAvatarIndex();

						if (targetIdx == srcAvatar.getAvatarIndex())
							continue;

						if (targetAvatar.canDoAction() == false || (turn.get_testType() & CombatTurn._TestType.Countered) == 0)
							continue;

						testResults[targetIdx] = TestTurn(targetAvatar, srcAvatar, turn.get_testType(), CombatTurn._TestType.Countered, testResults[targetIdx], combatContext);

						// 反击计算逻辑
						if ((testResults[targetIdx] & CombatTurn._TestType.Countered) != 0 && targetAvatar.canDoAction())
						{
							// Set action target to src action
							collector.Initialize(combatContext.getAvatars().size(), false);
							collector.SetState(srcAvatar.getAvatarIndex(), true);

							// 选择反击动作
							AvatarAction counterAction = null;
							switch (targetAvatar.getCharacterType())
							{
								case AvatarConfig._CharacterType.Physics:
									counterAction = targetAvatar.getActionByType(AvatarAction._Type.CounterAttack_PAP);
									break;
								case AvatarConfig._CharacterType.Magic:
									counterAction = targetAvatar.getActionByType(AvatarAction._Type.CounterAttack_MAP);
									break;
							}

							if (counterAction == null)
								continue;

							combatContext.PushCheckTriggerAction(false);
							// Do counter action
							doAction(targetAvatar, counterAction, combatContext, collector, true, testResults, turnRecord);
							combatContext.PopCombatEnviroment();
							//反击伤害不计入causeDamage，以免造成伤害吸血计算错误
							targetAvatar.getContextStack().resetCauseDamage();
						}
					}

					break;
				}
			}
		}

		/**
		 * 如果角色身上的内丹附带了吸血效果，则构建吸血事件发送给客户端。 吸血分为3种，按总伤害吸血，按攻击力吸血，按最大血量吸血。
		 *
		 * 每种吸血弹一次UI.
		 *
		 * 添加了一种新的Action类型：Dan_DmgHeal。配置了Idle动画（循环播放）
		 *
		 * progress确定了客户端每个事件的延迟时间。
		 * TestType用来保存一个标记，即这个事件是不是最终的吸血事件。如果是，则角色要进入Idle状态（循环播放的动画角色是不能自己进入Idle状态的）
		 *
		 * 如果以后添加了新需求：降低。。。的吸血效果，则这些计算要移到DamageEvent中。
		 *
		 */
		srcAvatar.calcuateCombatAttribute(true, true, null);

		//如果有内丹吸血效果，构建吸血事件。
		double dmgHealByDmg = srcAvatar.getAttributes().getAttrib(_AvatarAttributeType.Dan_DmgHealByDmg).value;
		double dmgHealByAP = srcAvatar.getAttributes().getAttrib(_AvatarAttributeType.Dan_DmgHealByAP).value;
		double dmgHealByMaxHP = srcAvatar.getAttributes().getAttrib(_AvatarAttributeType.Dan_DmgHealByMaxHp).value;
		int heal;

		ActionRecord ac = new ActionRecord(turnRecord);
		ac.setActionId(srcAvatar.getActionByType(AvatarAction._Type.Dan_DmgHeal).get_id());
//		ac.setActionId(IDSeg.InvalidId);
		ac.setSrcAvatarIndex(srcAvatar.getAvatarIndex());
		ac.addTargetAvatarIndex(srcAvatar.getAvatarIndex());

		int progress = 1;
//		Logger.Info("Avatar " + srcAvatar.getAvatar().getDisplayName() + " CauseDamage " + srcAvatar.getContextStack().getCauseDamage());
		//按造成的总伤害吸血（无论打多少人、打多少次）
		heal = (int) Math.round(dmgHealByDmg * srcAvatar.getContextStack().getCauseDamage());
		if (heal > 0 && dmgHealByDmg >= 0.00001)
		{
			srcAvatar.getAttributes().changeHP(heal);

			EventRecord er = new EventRecord(ac);
			EventTargetRecord etr = new EventTargetRecord();
			etr.setEventType(AvatarAction.Event._Type.Dan_DamageHeal);
			etr.setTargetIndex(srcAvatar.getAvatarIndex());
			etr.setTestType(0);

			er.addRecord(etr, true);
			etr.setValue(heal);
			etr.setValue1(progress);

			ac.addRecord(er, true);
			progress++;
		}

		//按攻击力吸血
		heal = (int) Math.round(dmgHealByAP * Math.max(srcAvatar.getAttributes().getAttrib(_AvatarAttributeType.PAP).value, srcAvatar.getAttributes().getAttrib(_AvatarAttributeType.MAP).value));
		if (heal > 0 && dmgHealByAP >= 0.00001)
		{
			srcAvatar.getAttributes().changeHP(heal);

			EventRecord er = new EventRecord(ac);
			EventTargetRecord etr = new EventTargetRecord();
			etr.setEventType(AvatarAction.Event._Type.Dan_DamageHeal);
			etr.setTargetIndex(srcAvatar.getAvatarIndex());
			etr.setTestType(0);

			er.addRecord(etr, true);
			etr.setValue(heal);
			etr.setValue1(progress);

			ac.addRecord(er, true);
			progress++;
		}

		//按最大血量吸血
		heal = (int) Math.round(dmgHealByMaxHP * srcAvatar.getAttributes().getAttrib(_AvatarAttributeType.MaxHP).value);
		if (heal > 0 && dmgHealByMaxHP >= 0.00001)
		{
			srcAvatar.getAttributes().changeHP(heal);

			EventRecord er = new EventRecord(ac);
			EventTargetRecord etr = new EventTargetRecord();
			etr.setEventType(AvatarAction.Event._Type.Dan_DamageHeal);
			etr.setTargetIndex(srcAvatar.getAvatarIndex());
			etr.setTestType(0);

			er.addRecord(etr, true);
			etr.setValue(heal);
			etr.setValue1(progress);

			ac.addRecord(er, true);
			progress++;
		}

		//必须保证最后一个事件TestType为1（告诉客户端这是最后一个事件，否则客户端会卡死
		if (progress > 1)
		{
			ac.getEventRecords().get(ac.getEventRecords().size() - 1).GetEventTargetRecords().get(0).setTestType(1);
			turnRecord.addRecord(ac, true);
		}

		// Pop out the context for turn setting
		srcAvatar.popContext();
	}

	private static void processDeathSkill(CombatContext combatContext, OrderedStateCollector mainTargets, CombatRecord combatRecord)
	{
		for (int targetIdx = 0; targetIdx < mainTargets.GetStateCount(); targetIdx++)
		{
			if (mainTargets.GetState(targetIdx) == false)
				continue;
			CombatAvatar deathSkillAvatar = combatContext.getAvatars().get(targetIdx);
			if (deathSkillAvatar.isCastDeathSkill)
			{
				mainTargets.Initialize(combatContext.getAvatars().size());
				processDeathSkillRound(combatContext, deathSkillAvatar, mainTargets, combatRecord);
				deathSkillAvatar.isCastDeathSkill = false;
			}
		}
	}

//	<Event KeyFrameId="2" Type="Damage" PlayOnAllTarget="true" Delay="0.3">
//		<CombatContext LevelFilter="1" APForDamageCaculation="PAP*2"/>
//		<Effect Type="PFX" PlayOnTarget="true" Model="p_SkillS5_DaGouBangFa_GetHit" Bone="" Offset="0,1.6,0" BoneFollow="false"/>
//	</Event>
// CombatContext的配置移动到event里面，每个event分别设置。用于实现分段伤害使用不同的伤害公式
	private static boolean SetActionAvatarContext(CombatAvatar srcAvatar, AvatarAction action, AvatarAction.Event event, CombatContext combatContext, OrderedStateCollector collector)
	{
		AvatarContext newAvatarContex = null;
		// Process combat context in turn setting
		if (event.GetCombatContextCount() != 0)
		{
			AvatarAction.CombatContext combatContextCfg;
			if (srcAvatar.getContextStack().isCurrentTurnIDSet())
				combatContextCfg = event.GetCombatContext(srcAvatar.getContextStack().getCurrentTurnLevel());
			else
				combatContextCfg = event.GetCombatContext(AvatarAction.CombatContext._InvalidValue.levelFilter);

			if (combatContextCfg != null)
			{
				if (newAvatarContex == null)
					newAvatarContex = srcAvatar.getContextStack().Push();

				//应用内丹属性
				srcAvatar.calcuateCombatAttribute(true, true, null);
				// Set ap expression
				if (combatContextCfg.IsAPForDamageCaculationSet())
					// Parse formula
					for (int i = 0; i < collector.GetStateCount(); ++i)
					{
						if (collector.GetState(i) == false)
							newAvatarContex.setApForDamageCaculation(i, 0);
						else
						{
							combatContext.getAvatars().get(i).calcuateCombatAttribute(true, true, srcAvatar);

							double jepValue = combatContext.getFormulaSet().getActionFormulaValue(combatContextCfg.get_apForDamageCaculation(), srcAvatar, combatContext.getAvatars().get(i), combatContextCfg);
							newAvatarContex.setApForDamageCaculation(i, (float) jepValue);
						}
					}

				// Set event check expression
				if (combatContextCfg.IsEventFlagExpressionSet())
					// Parse formula
					for (int i = 0; i < collector.GetStateCount(); ++i)
					{
						if (collector.GetState(i) == false)
							newAvatarContex.setEventCheckFlag(i, false);
						else
						{
							combatContext.getAvatars().get(i).calcuateCombatAttribute(true, true, srcAvatar);
							double jepValue = combatContext.getFormulaSet().getActionFormulaValue(combatContextCfg.get_eventFlagExpression(), srcAvatar, combatContext.getAvatars().get(i), combatContextCfg);
							newAvatarContex.setEventCheckFlag(i, jepValue >= 0);
						}
					}

				if (combatContextCfg.IsBuffIDToBeAddedSet())
					newAvatarContex.setBuffIDToBeAdded(combatContextCfg.get_buffIDToBeAdded());

				if (combatContextCfg.IsBuffDurationToBeAddedSet())
					newAvatarContex.setBuffDurationToBeAdded(combatContextCfg.get_buffDurationToBeAdded());
			}
		}

		return newAvatarContex != null;
	}

	/*
	 * Do an action
	 */
	public static ActionRecord doAction(CombatAvatar srcAvatar, AvatarAction action, CombatContext combatContext, OrderedStateCollector mainTargets,
			boolean checkTurnTest, int[] turnTestResults, TurnRecord turnRecord)
	{
		ActionRecord actionRecord = new ActionRecord(turnRecord);
		doAction(srcAvatar, action, combatContext, mainTargets, checkTurnTest, turnTestResults, actionRecord);
		turnRecord.addRecord(actionRecord, true);
		return actionRecord;
	}

	/*
	 * Do an action
	 */
	public static boolean doAction(CombatAvatar srcAvatar, AvatarAction action, CombatContext combatContext, OrderedStateCollector mainTargets,
			boolean checkTurnTest, int[] turnTestResults, ActionRecord actionRecord)
	{
		actionRecord.setActionId(action.get_id());

		// 为啥设置为0?
		if (action.get_animations().get_Count() == 0)
			actionRecord.setActionId(0);

		actionRecord.setSrcAvatarIndex(srcAvatar.getAvatarIndex());

		// 保存所有的target编号, 客户端用
		for (int targetIdx = 0; targetIdx < mainTargets.GetStateCount(); targetIdx++)
		{
			if (mainTargets.GetState(targetIdx) == false)
				continue;
			actionRecord.addTargetAvatarIndex(targetIdx);
		}

		// Process all events
		OrderedStateCollector collector = null;
		for (int eventIdx = 0; eventIdx < action.Get_eventsCount(); eventIdx++)
		{
			AvatarAction.Event actionEvent = action.Get_eventsByIndex(eventIdx);

			// 临时buff，实现技能额外属性，例如技能额外暴击
			srcAvatar.AddModifierSet(actionEvent.GetModifierSetByLevelFilter(1));

			// 如果event有配置目标选择条件，则使用配置的条件重新进行目标选择，不使用combatturn中选中的目标
			if (actionEvent.GetTargetConditionCount() != 0)
			{
				OrderedStateCollector eventTargetCollector = new OrderedStateCollector();
				eventTargetCollector.Initialize(combatContext.getAvatars().size());
				TargetConditionProcessor.Process(actionEvent, srcAvatar, combatContext, eventTargetCollector);
				collector = eventTargetCollector;
			}
			else
				collector = mainTargets;

			if (collector.HasValidState())
			{
				for (int targetIdx = 0; targetIdx < collector.GetStateCount(); targetIdx++)
				{
					if (collector.GetState(targetIdx) == false)
						continue;
					actionRecord.addTargetAvatarIndex(targetIdx);
				}

				// 处理event
				combatContext.PushEventEnv(actionEvent);
				ProcessEvent(srcAvatar, action, actionEvent, combatContext, collector, checkTurnTest, turnTestResults, actionRecord);
				combatContext.PopCombatEnviroment();
			}

			// 删除临时buff
			srcAvatar.RemoveModifierSet(actionEvent.GetModifierSetByLevelFilter(1));
		}

		return true;
	}

	public static void ProcessEvent(CombatAvatar srcAvatar, AvatarAction action, AvatarAction.Event actionEvent, CombatContext combatContext, OrderedStateCollector mainTargets, boolean checkTurnTest, int[] turnTestResults, ActionRecord actionRecord)
	{
		boolean needPopContext = false;
		try
		{
			needPopContext = SetActionAvatarContext(srcAvatar, action, actionEvent, combatContext, mainTargets);
		}
		catch (Exception ex)
		{
			java.util.logging.Logger.getLogger(CombatAlgorithm.class.getName()).log(Level.SEVERE, null, ex);
		}

		int[] testResult = turnTestResults;
		if (actionEvent.get_testType() != CombatTurn._TestType.None)
		{
			int[] eventTestResults = new int[combatContext.getAvatars().size()];
			for (int idx = 0; idx < eventTestResults.length; idx++)
			{
				eventTestResults[idx] = CombatTurn._TestType.None;
			}

			srcAvatar.calcuateCombatAttribute(true, true, null);
			for (int targetIdx = 0; targetIdx < mainTargets.GetStateCount(); targetIdx++)
			{
				if (mainTargets.GetState(targetIdx) == false)
					continue;

				CombatAvatar targetAvatar = combatContext.getAvatars().get(targetIdx);
				targetAvatar.calcuateCombatAttribute(true, true, srcAvatar);

				eventTestResults[targetIdx] = TestTurn(srcAvatar, targetAvatar, actionEvent.get_testType(), CombatTurn._TestType.Dodged, eventTestResults[targetIdx], combatContext);
				eventTestResults[targetIdx] = TestTurn(srcAvatar, targetAvatar, actionEvent.get_testType(), CombatTurn._TestType.CriticalHit, eventTestResults[targetIdx], combatContext);
			}
			testResult = eventTestResults;
		}

		ProcessEvent(srcAvatar, actionEvent, combatContext, mainTargets, checkTurnTest, testResult, actionRecord);

		if (needPopContext)
			srcAvatar.getContextStack().Pop();
	}

	/*
	 * Do a passive action
	 */
	public static void doPassiveAction(CombatAvatar srcAvatar, AvatarAction action, CombatContext combatContext, OrderedStateCollector mainTargets,
			boolean checkTurnTest, int[] turnTestResults, EventTargetRecord eventTargetRecord)
	{
		if (action == null)
			return;

		combatContext.PushCheckTriggerAction(false);
		ActionRecord actionRecord = new ActionRecord();
		doAction(srcAvatar, action, combatContext, mainTargets, checkTurnTest, turnTestResults, actionRecord);
		eventTargetRecord.addPassiveActionRecord(actionRecord, true);
		combatContext.PopCombatEnviroment();
	}

	/*
	 * Do a action for game end
	 */
	public static void doEndAction(CombatAvatar srcAvatar, AvatarAction action, ActionRecord endActionRecord)
	{
		if (action == null)
			return;

		endActionRecord.setActionId(action.get_id());
		endActionRecord.setSrcAvatarIndex(srcAvatar.getAvatarIndex());
		endActionRecord.addTargetAvatarIndex(srcAvatar.getAvatarIndex());
	}

	/*
	 * Process a event in action
	 */
	private static boolean ProcessEvent(CombatAvatar srcAvatar, AvatarAction.Event event, CombatContext combatContext, OrderedStateCollector mainTargets,
			boolean checkTurnTest, int[] turnTestResults, ActionRecord actoinRecord)
	{
		EventRecord eventRecord = new EventRecord(actoinRecord);
		eventRecord.setEventIndex(event.get_index());

		boolean eventTargetResults = false;
		// Process all event action for each targets.
		for (int targetIdx = 0; targetIdx < mainTargets.GetStateCount(); targetIdx++)
		{
			if (mainTargets.GetState(targetIdx) == false)
				continue;

			CombatAvatar targetAvatar = combatContext.getAvatars().get(targetIdx);

			eventTargetResults |= ProcessEventTarget(srcAvatar, event, targetAvatar, combatContext, checkTurnTest, turnTestResults, eventRecord, mainTargets);
		}

		// Add to record 全都未处理的event不加到action里面
		if (eventTargetResults)
			actoinRecord.addRecord(eventRecord, true);
		return eventTargetResults;
	}

	/*
	 * Process the event to multi-targets
	 */
	private static boolean ProcessEventTarget(CombatAvatar srcAvatar, AvatarAction.Event event, CombatAvatar targetAvatar, CombatContext combatContext,
			boolean checkTurnTest, int[] turnTestResults, EventRecord eventRecord, OrderedStateCollector mainTargets)
	{
		boolean result = false;
		EventTargetRecord eventTargetRecord = new EventTargetRecord();
		eventTargetRecord.setTargetIndex(targetAvatar.getAvatarIndex());

		OrderedStateCollector collector = new OrderedStateCollector();

		//应用有效的内丹属性，传递攻击者，用于检测伤害吸收是否触发
		if (event.get_eventType() == AvatarAction.Event._Type.Damage || event.get_eventType() == AvatarAction.Event._Type.ThrowDamage)
			targetAvatar.calcuateCombatAttribute(true, true, srcAvatar);

		//检测并记录是否有Action被触发（机关兽）
		//检测主动者和被动者是否触发守护效果并记录
		CheckInterfaceAction(true, srcAvatar, targetAvatar, combatContext, mainTargets, turnTestResults);
                int EnterState_type=AvatarAction.Event._Type.EnterState;
		result = EventProcessor.Process(srcAvatar, event, targetAvatar, combatContext, checkTurnTest, turnTestResults, eventTargetRecord, collector, eventRecord);

		long startTime = System.currentTimeMillis();
		if (srcAvatar.HasTheAttributeChange() || targetAvatar.HasTheAttributeChange())
		{
			ActionRecord passiveActRcd = new ActionRecord();
			passiveActRcd.setActionId(IDSeg.InvalidId);
			passiveActRcd.setSrcAvatarIndex(srcAvatar.getAvatarIndex());
			EventRecord eventRcd = new EventRecord(passiveActRcd);

			if (srcAvatar.HasTheAttributeChange())
			{
				passiveActRcd.addTargetAvatarIndex(srcAvatar.getAvatarIndex());

				for (CombatAttributes.Attribute attribute : srcAvatar.getChangedAttributes())
				{
					EventTargetRecord eventTagRcd = new EventTargetRecord();
					eventTagRcd.setEventType(AvatarAction.Event._Type.AttributeChange);
					eventTagRcd.setValue(attribute.type);
					eventTagRcd.setValue1((int) Math.ceil(attribute.value));
					eventTagRcd.setTargetIndex(srcAvatar.getAvatarIndex());
					eventRcd.addRecord(eventTagRcd, true);
				}
			}

			if (targetAvatar.HasTheAttributeChange())
			{
				passiveActRcd.addTargetAvatarIndex(targetAvatar.getAvatarIndex());

				for (CombatAttributes.Attribute attribute : targetAvatar.getChangedAttributes())
				{
					EventTargetRecord eventTagRcd = new EventTargetRecord();
					eventTagRcd.setEventType(AvatarAction.Event._Type.AttributeChange);
					eventTagRcd.setValue(attribute.type);
					eventTagRcd.setValue1((int) Math.ceil(attribute.value));
					eventTagRcd.setTargetIndex(targetAvatar.getAvatarIndex());
					eventRcd.addRecord(eventTagRcd, true);
				}
			}

			passiveActRcd.addRecord(eventRcd, true);

			eventTargetRecord.addPassiveActionRecord(passiveActRcd, true);

		}

		ProfilerData.buildAttributeChangedEventTime += System.currentTimeMillis() - startTime;

		if (result)
			eventRecord.addRecord(eventTargetRecord, true);

		return result;
	}

	/*
	 * Check if the game is over
	 */
	private static boolean isGameOver(CombatContext combatContext)
	{
		for (CombatAvatar avatar1 : combatContext.getAvatars())
		{
			if (avatar1.isDead())
				continue;

			for (CombatAvatar avatar2 : combatContext.getAvatars())
			{
				if (avatar2.isDead())
					continue;

				if (avatar1.getAvatarIndex() != avatar2.getAvatarIndex() && avatar1.getTeamIndex() != avatar2.getTeamIndex())
					return false;
			}
		}

		return true;
	}

	/*
	 * Test turn action
	 */
	public static int TestTurn(CombatAvatar avatar, CombatAvatar targetAvatar, int testCondition, int testType, CombatContext combatContext)
	{
		return TestTurn(avatar, targetAvatar, testCondition, testType, 0, combatContext);
	}

	/*
	 * Test turn action and replace old result
	 */
	private static int TestTurn(CombatAvatar avatar, CombatAvatar targetAvatar, int testCondition, int testType, int prevTestResult, CombatContext combatContext)
	{
		int testResult = 0;

		if (avatar.canDoAction() && (testCondition & testType) != 0)
			switch (testType)
			{
				case CombatTurn._TestType.Dodged:
					// 目标被晕的时候是不能闪避的
					if (targetAvatar.canDoAction())
						testResult = RandomWrapper.NextInt(100) > avatar.getAttributes().getAttribValue(targetAvatar.getAttributes(), _AvatarAttributeType.HR) * 100 ? testType : 0;
					break;

				case CombatTurn._TestType.CriticalHit:
					//治疗事件忽略抗暴属性
					if (combatContext.PeekEnv().eventType == AvatarAction.Event._Type.Heal)
						testResult = RandomWrapper.NextInt(100) < avatar.getAttributes().getAttrib(_AvatarAttributeType.CSR).value * 100 ? testType : 0;
					else
						testResult = RandomWrapper.NextInt(100) < avatar.getAttributes().getAttribValue(targetAvatar.getAttributes(), _AvatarAttributeType.CSR) * 100 ? testType : 0;

					break;

				case CombatTurn._TestType.Countered:
					testResult = RandomWrapper.NextInt(100) < avatar.getAttributes().getAttribValue(targetAvatar.getAttributes(), _AvatarAttributeType.CR) * 100 ? testType : 0;
					break;
			}

		return (prevTestResult & (~testType)) | testResult;
	}

	public static boolean ProcessBuff(CombatAvatar ownAvatar, BuffCombatdata buff, int actionType, CombatContext combatContext, ActionRecord actionRecord)
	{
		AvatarAction action = buff.buff.GetActionByType(actionType);
		if (action == null)
			return false;

		CombatAvatar srcAvatar = combatContext.getAvatars().get(buff.srcAvatarIndex);

		// Set target to buff-owner self
		OrderedStateCollector targetCollector = new OrderedStateCollector();
		targetCollector.Initialize(combatContext.getAvatars().size(), false);
		targetCollector.SetState(ownAvatar.getAvatarIndex(), true);

		if (buff.context != null)
			srcAvatar.getContextStack().Push(buff.context);

		// Do this action
		doAction(srcAvatar, action, combatContext, targetCollector, false, null, actionRecord);

		if (buff.context != null)
			srcAvatar.getContextStack().Pop();

		// The ID of buff process action should contain the information of buff ID
		actionRecord.setActionId(Buff.ComposeBuffActionID(action.get_id(), buff.buff.get_id()));

		return true;
	}

	/**
	 * 刷新Buff，处理Dot和Hot，同时合并计算Dot和Hot效果，供客户端对Dot和Hot只弹一次板
	 * 先处理Dot，后处理Hot，如果处理Dot中角色死亡，则没有Hot处理
	 */
	private static void UpdateAvatarBuffs(CombatAvatar ownAvatar, CombatContext combatContext, TurnRecord turnRecord)
	{
		//先处理除了dot和hot之外的buff
		for (BuffCombatdata buff : ownAvatar.buffs)
		{
			if (buff.buff.get_buffType() == Buff._BuffType.Dot || buff.buff.get_buffType() == Buff._BuffType.Hot)
				continue;

			// Process on-update event
			ActionRecord actionRecord = new ActionRecord(turnRecord);
			if (ProcessBuff(ownAvatar, buff, AvatarAction._Type.OnUpdateBuff, combatContext, actionRecord))
				turnRecord.addRecord(actionRecord, true);
		}

		//用于记录Dot或Hot的处理过程
		List<ActionRecord> actionRecs = new ArrayList<>();

		//初始化一个新的ActionRecord 将之前储存的Buff效果叠加在一起
		ActionRecord actions = new ActionRecord();
		actions.setSrcAvatarIndex(ownAvatar.getAvatarIndex());
		actions.addTargetAvatarIndex(ownAvatar.getAvatarIndex());

		//先处理dot。如果角色死亡，则没有hot处理阶段
		//不论角色是否死亡，所有Dot的伤害都要计算，用于客户端合并显示总伤害弹板
		for (BuffCombatdata buff : ownAvatar.buffs)
		{
			if (buff.buff.get_buffType() != Buff._BuffType.Dot)
				continue;

			// Process on-update event
			ActionRecord actionRecord = new ActionRecord(turnRecord);
			if (ProcessBuff(ownAvatar, buff, AvatarAction._Type.OnUpdateBuff, combatContext, actionRecord))
				actionRecs.add(actionRecord);
		}

		//合并计算所有Dot效果
		int damageValue = 0;
		for (ActionRecord action : actionRecs)
		{
			Iterator<EventRecord> evtIter = action.getEventRecords().iterator();
			while (evtIter.hasNext())
			{
				EventRecord evtRcd = evtIter.next();
				Iterator<EventTargetRecord> evtTgtRcdIter = evtRcd.GetEventTargetRecords().iterator();

				while (evtTgtRcdIter.hasNext())
				{
					EventTargetRecord evtTgtRcd = evtTgtRcdIter.next();
					if (evtTgtRcd.getEventType() == AvatarAction.Event._Type.Damage)
					{
						damageValue += evtTgtRcd.getValue();
						//合并伤害值，删除事件
						evtTgtRcdIter.remove();
					}
				}

				if (evtRcd.GetEventTargetRecords().isEmpty())
					evtIter.remove();
			}

			//如果还有其他类型的事件，要将EventTargetRecord保留下来
			if (!action.getEventRecords().isEmpty())
				turnRecord.addRecord(action, false);
		}

		if (damageValue > 0)
		{
			EventTargetRecord eventTarRec = new EventTargetRecord();
			eventTarRec.setEventType(AvatarAction.Event._Type.Damage);
			eventTarRec.setValue(damageValue);
			eventTarRec.setTargetIndex(ownAvatar.getAvatarIndex());

			OrderedStateCollector collector = new OrderedStateCollector();
			// Do get-hit action
			if (!ownAvatar.isDead())
			{
				AvatarAction passsiveAction = ownAvatar.getActionByType(AvatarAction._Type.GetHit);
				if (passsiveAction != null)
				{
					collector.Initialize(combatContext.getAvatars().size(), false);
					collector.SetState(ownAvatar.getAvatarIndex(), true);
					CombatAlgorithm.doPassiveAction(ownAvatar, passsiveAction, combatContext, collector, false, null, eventTarRec);
				}
			}
			else
			{
				// do die action
				AvatarAction passsiveAction = ownAvatar.getActionByType(AvatarAction._Type.Die);
				collector.Initialize(combatContext.getAvatars().size(), false);
				collector.SetState(ownAvatar.getAvatarIndex(), true);
				CombatAlgorithm.doPassiveAction(ownAvatar, passsiveAction, combatContext, collector, false, null, eventTarRec);

				// Remove dead avatar from formation
				CombatTeam combatTeam = combatContext.getTeams().get(ownAvatar.getTeamIndex());
				combatTeam.getFormation().setAvatar(ownAvatar.getBattlePositionRow(), ownAvatar.getBattlePositionColumn(), null);
			}

			EventRecord eventRcd = new EventRecord(actions);
			eventRcd.addRecord(eventTarRec, true);
			actions.addRecord(eventRcd, true);
		}

		if (!ownAvatar.isDead())
		{
			actionRecs.clear();
			//处理Hot
			for (BuffCombatdata buff : ownAvatar.buffs)
			{
				if (buff.buff.get_buffType() != Buff._BuffType.Hot)
					continue;

				// Process on-update event
				ActionRecord actionRecord = new ActionRecord(turnRecord);
				if (ProcessBuff(ownAvatar, buff, AvatarAction._Type.OnUpdateBuff, combatContext, actionRecord))
					actionRecs.add(actionRecord);
			}

			//合并计算所有Hot效果
			int healValue = 0;
			for (ActionRecord action : actionRecs)
			{
				Iterator<EventRecord> evtIter = action.getEventRecords().iterator();
				while (evtIter.hasNext())
				{
					EventRecord evtRcd = evtIter.next();
					Iterator<EventTargetRecord> evtTgtRcdIter = evtRcd.GetEventTargetRecords().iterator();

					while (evtTgtRcdIter.hasNext())
					{
						EventTargetRecord evtTgtRcd = evtTgtRcdIter.next();
						if (evtTgtRcd.getEventType() == AvatarAction.Event._Type.Heal)
						{
							healValue = healValue + evtTgtRcd.getValue();
							//合并回复值，删除事件
							evtTgtRcdIter.remove();
						}
					}

					if (evtRcd.GetEventTargetRecords().isEmpty())
						evtIter.remove();
				}

				//如果还有其他类型的事件，要将EventTargetRecord保留下来
				if (!action.getEventRecords().isEmpty())
					turnRecord.addRecord(action, false);
			}

			if (healValue > 0)
			{
				EventTargetRecord eventTarRec = new EventTargetRecord();
				eventTarRec.setEventType(AvatarAction.Event._Type.Heal);
				eventTarRec.setValue(healValue);
				//Client Show Heal Value UI.
				eventTarRec.setValue1(1);
				eventTarRec.setTargetIndex(ownAvatar.getAvatarIndex());
				EventRecord eventRcd = new EventRecord(actions);
				eventRcd.addRecord(eventTarRec, true);
				actions.addRecord(eventRcd, true);
			}
		}

		turnRecord.addRecord(actions, true);
	}

	/*
	 * Check buff duration and if the buff is end up, do action to remove the
	 * buff
	 */
	private static void CheckAvatarBuffDuration(CombatAvatar ownAvatar, int durationCheckType, CombatContext combatContext, TurnRecord turnRecord)
	{
		List<Integer> buffsTimeUp = new ArrayList<>();

		for (BuffCombatdata buff : ownAvatar.buffs)
		{
			if (buff.buff.get_durationCheckType() != durationCheckType)
				continue;

			buff.leftTurns--;
			if (buff.leftTurns != 0)
				continue;

			buffsTimeUp.add(buff.instanceID);
		}

		for (int buffInstId : buffsTimeUp)
		{
			// Construct the action for processing buff time up
			AvatarAction buffTimeUpAction = ownAvatar.getActionByType(AvatarAction._Type.BuffTimeUp);

			// Set target to buff-owner self
			OrderedStateCollector targetCollector = new OrderedStateCollector();
			targetCollector.Initialize(combatContext.getAvatars().size(), false);
			targetCollector.SetState(ownAvatar.getAvatarIndex(), true);

			// Set remove buff context
			AvatarContext newContext = ownAvatar.getContextStack().Push();
			newContext.setBuffInstIDToBeRemoved(buffInstId);

			// 清除buff 不需要动作 所以id设置为0 这样客户端可以直接处理event
			ActionRecord actionRecord = doAction(ownAvatar, buffTimeUpAction, combatContext, targetCollector, false, null, turnRecord);
			actionRecord.setActionId(0);
			actionRecord.setSrcAvatarIndex(ownAvatar.getAvatarIndex());
			// Pop current context
			ownAvatar.getContextStack().Pop();

		}

		buffsTimeUp.clear();
	}

	/**
	 * <b>谨慎调用</b>
	 *
	 * 针对<b>攻击者</b>和<b>其目标</b>分别检测触技能接口是否触发 注意不能修改传入的OrderedStateCollector<br/>
	 * 对于一个技能来说，有多少个目标、有哪个敌方、己方目标在技能施放完成前是无法确定的。<br/>
	 * 所以需要在每个事件执行时进行检测，记录触发的Action和触发的角色、满足条件的目标角色。<br/>
	 * 对于一个可以触发的Action，对于不同的角色应该是分别可以触发的，这种情况会发生在有多段攻击且每次打不同的人时。对于每次攻击指定的Action都需要重新判断触发。<br/>
	 * 概率触发是个例外，同一个角色只能被判定一次<br/>
	 *
	 * @param caster 当前出手者
	 * @param defender 当前出手者的目标（当前事件的目标）
	 * @param mainTargets 当前出手者的所有目标
	 */
	public static void CheckInterfaceAction(boolean checkEvt, CombatAvatar caster, CombatAvatar defender, CombatContext combatContext, OrderedStateCollector mainTargets, int[] turnTestResults)
	{
		if (!combatContext.PeekEnv().checkTriggerAction)
			return;

		//如果出手者是组合技辅助者，略过
		if (caster.getContextStack().getIsCompositeSupporter())
			return;

		/**
		 * 以下事件忽略，提高处理速度，一方面也尽量避免错误的触发判定，发生这些事件时不应该进行触发判定
		 */
		if (checkEvt)
		{
			int eventType = combatContext.PeekEnv().eventType;
			if (eventType == AvatarAction.Event._Type.PlayEffect
					|| eventType == AvatarAction.Event._Type.AttributeChange
					|| eventType == AvatarAction.Event._Type.BuffTimeUp
					|| eventType == AvatarAction.Event._Type.ChangeBattlePosition
					|| eventType == AvatarAction.Event._Type.ChangeWeapon
					|| eventType == AvatarAction.Event._Type.ShowWeapon
					|| eventType == AvatarAction.Event._Type.Dan_DamageHeal//TODO: 是否忽略？
					|| eventType == AvatarAction.Event._Type.EnterState//TODO: 是否忽略？
					|| eventType == AvatarAction.Event._Type.LeaveState//TODO: 是否忽略？
					|| eventType == AvatarAction.Event._Type.HideWeapon
					|| eventType == AvatarAction.Event._Type.InactiveAvatar
					|| eventType == AvatarAction.Event._Type.RecoverWeapon
					|| eventType == AvatarAction.Event._Type.SetBattleTrans
					|| eventType == AvatarAction.Event._Type.SetSkillPower//TODO: 是否忽略？
					|| eventType == AvatarAction.Event._Type.ShowAvatar
					|| eventType == AvatarAction.Event._Type.ShowBattleBar
					|| eventType == AvatarAction.Event._Type.ShowDialogue
					|| eventType == AvatarAction.Event._Type.Unknown
					|| eventType == AvatarAction.Event._Type.RefreshBuff
					|| eventType == AvatarAction.Event._Type.SkillStart
					|| eventType == AvatarAction.Event._Type.SuperSkillEffect
					|| eventType == AvatarAction.Event._Type.CompositeSkillStart
					|| eventType == AvatarAction.Event._Type.EnterBattleGround
					|| eventType == AvatarAction.Event._Type.CounterAttackStart)
				return;
		}

		InterfaceContextMgr interfaceCtxMgr = combatContext.interfaceCtxMgr;
		interfaceCtxMgr.ConfirmAvatarIndex(caster.getAvatarIndex());

		//记录是否发生了闪避或暴击（有些效果仅在这些情况下触发），用于TargetConditionProcessor
		if (turnTestResults != null && defender != null)
		{
			boolean dodged = (turnTestResults[defender.getAvatarIndex()] & _TestType.Dodged) != 0;
			boolean critical = (turnTestResults[defender.getAvatarIndex()] & _TestType.CriticalHit) != 0;

			AvatarContext casterContext = caster.getContextStack().Push();
			casterContext.dodged = false;
			casterContext.beCritical = false;
			casterContext.beDodged = dodged;
			casterContext.critical = critical;

			AvatarContext defenderContext = defender.getContextStack().Push();
			defenderContext.dodged = dodged;
			defenderContext.beCritical = critical;
			defenderContext.beDodged = false;
			defenderContext.critical = false;
		}

		//出手者检测其主动效果是否被触发====================================================================
		OrderedStateCollector checker = new OrderedStateCollector();
		OrderedStateCollector mergedTargets = new OrderedStateCollector();

		//直接配置给角色的InterfaceAction
		ArrayList<InterfaceContext> triggeredActions = interfaceCtxMgr.dic.get(caster.getAvatarIndex());
		for (AvatarAction casterAction : caster.triggerAbleActions)
		{
			//只触发主动效果
			if (casterAction.get_isPassive())
				continue;

			checker.CopyState(mainTargets);

			if (casterAction.get_battleMaxTriggerTime() != 0 && interfaceCtxMgr.GetTriggerTimeBattle(caster.getAvatarIndex(), casterAction.get_id()) >= casterAction.get_battleMaxTriggerTime())
				continue;

			if (casterAction.get_roundMaxTriggerTime() != 0 && interfaceCtxMgr.GetTriggerTimeRound(caster.getAvatarIndex(), casterAction.get_id()) >= casterAction.get_roundMaxTriggerTime())
				continue;

			if (TriggerInterfaceAction(caster, combatContext, casterAction, checker))
			{
				mergedTargets.Initialize(checker.GetStateCount(), false);
				//如果这个action被触发过，将所有已经触发这个action的目标取出来，这些目标将会被排除，因为他们不能够在一次技能释放中作为同一个主动action的目标两次
				InterfaceContextMgr.GetMergedActionTargets(triggeredActions, casterAction.get_id(), mergedTargets);
				for (int idx = 0; idx < checker.GetStateCount(); idx++)
				{
					if (checker.GetState(idx) && mergedTargets.GetState(idx))
						checker.SetState(idx, false);
				}

				if (checker.HasValidState())
				{
					InterfaceContext ic = new InterfaceContext();

					ic.attackerIdx = ic.whoDoAction = caster.getAvatarIndex();
					ic.interfaceAction = casterAction;

					//主动效果触发 记录所有触发者
					ic.actionTriggers = new OrderedStateCollector();
					ic.actionTriggers.CopyState(checker);

//					ic.avatarContext = caster.getContextStack().DumpContext();
					triggeredActions.add(ic);
					interfaceCtxMgr.AddTriggerTime(caster.getAvatarIndex(), casterAction.get_id());
				}
			}
		}

		//被动者 检测其被动效果是否触发====================================================================
		if (defender != null)
		{
			interfaceCtxMgr.ConfirmAvatarIndex(defender.getAvatarIndex());
			//获取被动者已经触发的action
			triggeredActions = interfaceCtxMgr.dic.get(defender.getAvatarIndex());

			//检测被动者身上是否触发新的被动效果。
			for (AvatarAction defenderAction : defender.triggerAbleActions)
			{
				//只触发被动效果
				if (!defenderAction.get_isPassive())
					continue;

				//触发次数限制
				if (defenderAction.get_battleMaxTriggerTime() != 0 && interfaceCtxMgr.GetTriggerTimeBattle(defender.getAvatarIndex(), defenderAction.get_id()) >= defenderAction.get_battleMaxTriggerTime())
					continue;

				if (defenderAction.get_roundMaxTriggerTime() != 0 && interfaceCtxMgr.GetTriggerTimeRound(defender.getAvatarIndex(), defenderAction.get_id()) >= defenderAction.get_roundMaxTriggerTime())
					continue;

				boolean temp = false;
				for (InterfaceContext triggered : triggeredActions)
				{
					if (triggered.interfaceAction.get_id() == defenderAction.get_id())
					{
						temp = true;
						break;
					}
				}

				//已经触发了
				if (temp)
					continue;

				checker.CopyState(mainTargets);

				if (TriggerInterfaceAction(caster, combatContext, defenderAction, checker))
					//可能caster的其他目标通过了测试但defender本人没通过条件测试，要再次判断
					if (checker.GetState(defender.getAvatarIndex()))
					{
						InterfaceContext ic = new InterfaceContext();
						ic.whoDoAction = defender.getAvatarIndex();
						ic.attackerIdx = caster.getAvatarIndex();
						ic.interfaceAction = defenderAction;

						//被动效果触发 只记录出手者
						ic.actionTriggers = new OrderedStateCollector();
						ic.actionTriggers.Initialize(checker.GetStateCount(), false);
						ic.actionTriggers.SetState(caster.getAvatarIndex(), true);

//					ic.avatarContext = defender.getContextStack().DumpContext();
						triggeredActions.add(ic);
						interfaceCtxMgr.AddTriggerTime(defender.getAvatarIndex(), defenderAction.get_id());
					}
			}
		}

		if (turnTestResults != null)
		{
			caster.popContext();

			if (defender != null)
				defender.popContext();
		}

		//环境条件检测==============================================================================================
		for (int idx = 0; idx < combatContext.getAvatars().size(); idx++)
		{
			CombatAvatar temp = combatContext.getCombatAvatarByIndex(idx);

			if (!temp.canDoAction())
				continue;

			triggeredActions = interfaceCtxMgr.dic.get(idx);

			interfaceCtxMgr.ConfirmAvatarIndex(idx);
			for (AvatarAction action : temp.triggerAbleActions)
			{
				ConditionGroup cGroup = action.get_envConditionGroup();
				if (cGroup == null)
					continue;

				if (action.get_battleMaxTriggerTime() != 0 && interfaceCtxMgr.GetTriggerTimeBattle(temp.getAvatarIndex(), action.get_id()) >= action.get_battleMaxTriggerTime())
					continue;

				if (action.get_roundMaxTriggerTime() != 0 && interfaceCtxMgr.GetTriggerTimeRound(temp.getAvatarIndex(), action.get_id()) >= action.get_roundMaxTriggerTime())
					continue;

				boolean hasTriggered = false;
				for (InterfaceContext tempAction : triggeredActions)
				{
					if (tempAction.interfaceAction.get_id() == action.get_id())
					{
						hasTriggered = true;
						break;
					}
				}
				if (hasTriggered)
					continue;

				checker.Initialize(combatContext.getAvatars().size(), true);
				//注意传递的temp并没有用到，如果用到则表示配置错误，此情况下仅用于防止出现空指针异常
				TargetConditionProcessor.ProcessCheckingActionTrigger(cGroup, temp, combatContext, checker);

				for (int i = 0; i < checker.GetStateCount(); i++)
				{
					if (!checker.GetState(i))
						continue;

					temp = combatContext.getCombatAvatarByIndex(i);

					InterfaceContext ic = new InterfaceContext();
					ic.whoDoAction = i;
					ic.attackerIdx = caster.getAvatarIndex();
					ic.interfaceAction = action;

					ic.actionTriggers = new OrderedStateCollector();
					ic.actionTriggers.Initialize(checker.GetStateCount(), false);
					triggeredActions.add(ic);
					interfaceCtxMgr.AddTriggerTime(i, action.get_id());
				}
			}
		}
	}

	/**
	 * 根据指定的出手者caster、出手者的目标集合casterTargets、战斗上下文combatContext判断给定的AvatarAction（配置了触发条件）是否触发。<br/>
	 * 如果检测通过，<b>传入的casterTargets会被修改</b>，保存通过了检测的目标。
	 */
	private static boolean TriggerInterfaceAction(CombatAvatar caster, CombatContext combatContext, AvatarAction actionForTesting, OrderedStateCollector casterTargets)
	{
		//条件组，确定了一组特定条件。
		ConditionGroup cGroup;
		OrderedStateCollector tempChecker = new OrderedStateCollector();

		//检查出手者是否满足条件。
		cGroup = actionForTesting.get_casterConditionGroup();
		if (cGroup != null)
		{
			tempChecker.CopyState(casterTargets);
			//将caster置为有效，目的仅仅是为了用TargetConditionProcessor检测对于条件组 caster是否满足条件.
			//注意这里显式设置了caster在tempChecker中的状态。
			tempChecker.SetState(caster.getAvatarIndex(), true);
			TargetConditionProcessor.ProcessCheckingActionTrigger(cGroup, caster, combatContext, tempChecker);
			//如果出手者不满足条件
			if (!tempChecker.GetState(caster.getAvatarIndex()))
				return false;
		}

		//检查是否有满足条件的目标。
		cGroup = actionForTesting.get_defenderConditionGroup();
		if (cGroup != null)
		{
			tempChecker.CopyState(casterTargets);
			TargetConditionProcessor.ProcessCheckingActionTrigger(cGroup, caster, combatContext, tempChecker);

			if (tempChecker.HasValidState())
			{
				//记录有哪些人满足条件
				casterTargets.CopyState(tempChecker);
				return true;
			}
		}

		//如果没有配置条件则不会触发
		return false;
	}
}
