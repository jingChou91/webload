package com.kodgames.combat.algorithm;

import ClientServerCommon.AvatarAction;
import ClientServerCommon.Buff;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.IDSeg;
import ClientServerCommon._AvatarAttributeType;
import com.kodgames.combat.record.BattleRecord;
import com.kodgames.combat.record.CombatPlayer;
import com.kodgames.common.RandomWrapper;
import com.kodgames.common.ValueRandomer;
import java.util.*;

public class CombatContext
{
	private ConfigDatabase configDB;
	private BattleRecord battleRecord;
	private ArrayList<CombatPlayer> players = new ArrayList<>();
	private ArrayList<CombatTeam> combatTeams = new ArrayList<>();
	private ArrayList<CombatAvatar> combatAvatars = new ArrayList<>();
	private ArrayList<CombatAvatar> woundedAvatars = new ArrayList<>();
	// 决定出手顺序的数组
	private ArrayList<CombatAvatar> sortedCombatAvatars = new ArrayList<>();
	private FormulaSet formulaSet = new FormulaSet();
	private ValueRandomer valueRandomer = new ValueRandomer();
	private int totalRoundCount = 0;
	private CombatTeam currentActTeam = null;
	private int currentActionAvatarIndex = 0;
	private AvatarSpeedComparator speedComparator = new AvatarSpeedComparator();

	//InterfaceAction 功能接口管理
	public InterfaceContextMgr interfaceCtxMgr = new InterfaceContextMgr();
	public CombatAvatar attacker = null;
	public CombatAvatar defender = null;

	Stack<CombatEnv> envStack = new Stack<>();
	//==========================================================

	class AvatarSpeedComparator implements Comparator<CombatAvatar>
	{
		@Override
		public int compare(CombatAvatar o1, CombatAvatar o2)
		{
			// 如果敏捷相同，则出手顺序随机
			if (Double.compare(o2.getAttributes().getAttrib(_AvatarAttributeType.Speed).value, o1.getAttributes().getAttrib(_AvatarAttributeType.Speed).value) == 0)
				return RandomWrapper.getRandInt(-1, 1);

			return Double.compare(o2.getAttributes().getAttrib(_AvatarAttributeType.Speed).value, o1.getAttributes().getAttrib(_AvatarAttributeType.Speed).value);
		}
	}

	public void ResortAvatarBySpeed()
	{
		currentActionAvatarIndex = 0;
		sortedCombatAvatars.clear();
		sortedCombatAvatars.addAll(combatAvatars);
		// TOTO : SortAvatar不需要每次new
		java.util.Collections.sort(sortedCombatAvatars, speedComparator);
	}

	public CombatContext(ConfigDatabase configDB, BattleRecord battleRecord)
	{
		this.configDB = configDB;
		this.battleRecord = battleRecord;
		//Avoid Empty Stack Exception.
		this.envStack.push(new CombatEnv());
	}

	public ConfigDatabase getConfigDB()
	{
		return this.configDB;
	}

	public BattleRecord getBattleRecord()
	{
		return battleRecord;
	}

	public List<CombatAvatar> getWoundedAvatars()
	{
		return this.woundedAvatars;
	}

	public void sortWoundedAvatars()
	{
		java.util.Collections.sort(woundedAvatars, speedComparator);
	}

	public List<CombatPlayer> getPlayers()
	{
		return this.players;
	}

	public ArrayList<CombatTeam> getTeams()
	{
		return this.combatTeams;
	}

	public CombatTeam getTeam(int index)
	{
		if (index >= combatTeams.size())
			return null;

		return combatTeams.get(index);
	}

	public CombatTeam getOpponentTeam(int teamIndex)
	{
		int opponentTeamIndex = teamIndex + 1;
		if (opponentTeamIndex == combatTeams.size())
			opponentTeamIndex = 0;

		return combatTeams.get(opponentTeamIndex);
	}

	public ArrayList<CombatAvatar> getAvatars()
	{
		return this.combatAvatars;
	}

	public FormulaSet getFormulaSet()
	{
		return this.formulaSet;
	}

	public ValueRandomer getValueRandomer()
	{
		return this.valueRandomer;
	}

	public int getTotalRoundCount()
	{
		return this.totalRoundCount;
	}

	public void setTotalRoundCount(int totalRoundCount)
	{
		this.totalRoundCount = totalRoundCount;
	}

	public void increaseTotalRoundCount()
	{
		this.totalRoundCount++;
	}

	public CombatTeam getCurrentActionTeam()
	{
		return this.currentActTeam;
	}

	public void initialize()
	{
		for (CombatTeam team : combatTeams)
		{
			team.initialize();
		}
	}

	public void initializeAttribute()
	{
		for (CombatAvatar combatAvatar : combatAvatars)
		{
			combatAvatar.initializeBaseAttribute();
		}
	}

	public void initializeDominnerAttribute()
	{
		for (CombatAvatar combatAvatar : combatAvatars)
		{
			combatAvatar.initializeDominnerAttribute();
		}
	}

	public void finishAttributeInitialization()
	{
		// 将初始属性保存在avatar中
		for (CombatAvatar combatAvatar : combatAvatars)
		{
			for (CombatAttributes.Attribute attribute : combatAvatar.getAttributes().getAttributes())
			{
				combatAvatar.getAvatar().ReplaceAttribute(attribute.type, attribute.value);
			}
		}

		//保存一份初始属性在AvatarContextStack中
		for (CombatAvatar combatAvatar : combatAvatars)
		{
			combatAvatar.getContextStack().getCombatAttributeses().copy(combatAvatar.getAttributes());
		}

	}

	public void nextRound()
	{
		if (currentActTeam == null)
			// Get first team for first round
			currentActTeam = getFirstCombatTeam();
		else
		{
			// Get next team
			CombatTeam nextTeam = nextTeam(currentActTeam);

			currentActTeam = nextTeam;
		}
	}

	public CombatAvatar getCombatAvatarByIndex(int index)
	{
		if (index >= combatAvatars.size())
			return null;

		return combatAvatars.get(index);
	}

	public CombatAvatar getCurrentActionCombatAvatar()
	{
		if (currentActionAvatarIndex >= sortedCombatAvatars.size())
			return null;

		return sortedCombatAvatars.get(currentActionAvatarIndex++);
	}

	private CombatTeam getFirstCombatTeam()
	{
		// Get team with greatest worth
		CombatTeam firstTeam = null;
		for (int i = 0; i < combatTeams.size(); ++i)
		{
			CombatTeam combatTeam = combatTeams.get(i);

			if (firstTeam == null)
				firstTeam = combatTeam;
			else if (firstTeam.getEvaluation() < combatTeam.getEvaluation())
				firstTeam = combatTeam;
		}

		return firstTeam;
	}

	private CombatTeam nextTeam(CombatTeam team)
	{
		int teamIndex = team.getTeamIndex() + 1;
		teamIndex = teamIndex >= combatTeams.size() ? 0 : teamIndex;
		CombatTeam nextTeam = combatTeams.get(teamIndex);
		return nextTeam != team ? nextTeam : null;
	}

	public CombatTeam getWinnerTeam(boolean sponsorWinWhenReachMaxRound)
	{
		// 判断那只是胜利队伍
		CombatTeam winnerTeam = null;
		{
			boolean sponsorTeamHasLiveAvatar = combatTeams.get(0).hasAliveAvatar();
			boolean opponentTeamHasLiveAvatar = combatTeams.get(1).hasAliveAvatar();

			if (sponsorTeamHasLiveAvatar && opponentTeamHasLiveAvatar)
				// 双方都没有死, 达到最大回合数
				winnerTeam = combatTeams.get(sponsorWinWhenReachMaxRound ? 0 : 1);
			else
				// 有一方死亡
				winnerTeam = combatTeams.get(sponsorTeamHasLiveAvatar ? 0 : 1);
		}

		assert (winnerTeam != null);
		return winnerTeam;
	}

	//Battle Enviroment controller parameters=======================================================================
	public Stack<CombatEnv> getEnvStack()
	{
		return envStack;
	}

	public CombatEnv PushEnvStack()
	{
		CombatEnv newNode = envStack.peek().DeepClone();
		envStack.push(newNode);
		return newNode;
	}

	public CombatEnv PeekEnv()
	{
		//不会发生EmptyStackException，已确保栈中至少有一个元素
		return envStack.peek();
	}

	/**
	 * 是否进行机关兽效果触发判定
	 */
	public void PushCheckTriggerAction(boolean check)
	{
		CombatEnv newNode = PushEnvStack();
		newNode.checkTriggerAction = check;
	}

	public void PushRoundState(int roundState)
	{
		CombatEnv newNode = PushEnvStack();
		newNode.roundState = roundState;
	}

	public void PushKillEnv(int killer, int beKilled)
	{
		CombatEnv newNode = PushEnvStack();
		newNode.killerIndex = killer;
		newNode.avatarJustKilled = beKilled;
	}

	public void PopCombatEnviroment()
	{
		envStack.pop();
	}

	public void PushEventEnv(AvatarAction.Event event)
	{
		CombatEnv newNode = PushEnvStack();
		newNode.eventType = event.get_eventType();

		if (event.get_buffId() != IDSeg.InvalidId)
		{
			Buff buff = configDB.get_ActionConfig().GetBuffById(event.get_buffId());

			if (buff != null)
				newNode.eventAddBuffType = buff.get_buffType();
		}
	}
}
