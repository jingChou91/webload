/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.algorithm;

import ClientServerCommon.Buff;
import ClientServerCommon.IDSeg;
import ClientServerCommon.PropertyModifierSet;

/**
 *
 * @author sonilics
 */
public class BuffCombatdata
{
	public int instanceID = IDSeg.InvalidId;
	public int srcAvatarIndex = -1;
	public int ownAvatarIndex = -1;
	public Buff buff = null;
	public int leftTurns = 0;
	public PropertyModifierSet modifierSet = null;
	public AvatarContext context = null;
}