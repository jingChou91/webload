package com.kodgames.combat.record;

import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.gamedata.player.GamePlayer;

public class PlayerRankRecord {
	int playerId;
	String playerName = "";
	int playerValue;
	String supermanGuid = "";
	int supermanValue;
	int resourceId;
	int level;
	
	public PlayerRankRecord(){}

	public PlayerRankRecord(int playerId)
	{
		this.playerId=playerId;
	}
	
	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public int getResourceId() {
		return resourceId;
	}

	public void setResourceId(int resourceId) {
		this.resourceId = resourceId;
	}

	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public int getPlayerValue() {
		return playerValue;
	}
	public void setPlayerValue(int playerValue) {
		this.playerValue = playerValue;
	}
	public String getSupermanGuid() {
		return supermanGuid;
	}
	public void setSupermanGuid(String supermanGuid) {
		this.supermanGuid = supermanGuid;
	}
	public int getSupermanValue() {
		return supermanValue;
	}
	public void setSupermanValue(int supermanValue) {
		this.supermanValue = supermanValue;
	}
	
	public int compareToLevel(PlayerRankRecord record)
	{
		if(record.getLevel() > this.level)
			return -1;
		else if(record.getLevel() < this.level)
			return 1;
		if(record.getPlayerValue() > this.playerValue)
			return -1;
		else if(record.getPlayerValue() < this.playerValue)
			return 1;
		if(record.getPlayerId() < this.playerId)
			return -1;
		else
			return 1;
	}
	
	public int compareToSupermanValue(PlayerRankRecord record)
	{
		if(record.getSupermanValue() > this.supermanValue)
			return -1;
		else if(record.getSupermanValue() < this.supermanValue)
			return 1;
		if(record.getPlayerId() < this.playerId)
			return -1;
		else
			return 1;
	}
	
	public int compareToPlayerValue(PlayerRankRecord record)
	{
		if(record.getPlayerValue() > this.playerValue)
			return -1;
		else if(record.getPlayerValue() < this.playerValue)
			return 1;
		if(record.getLevel() > this.level)
			return -1;
		else if(record.getLevel() < this.level)
			return 1;
		if(record.getPlayerId() < this.playerId)
			return -1;
		else
			return 1;
	}
//	//服务器之间
//	public com.kodgames.corgi.protocol.CommonProtocols.PlayerRankRecord toProtoBuf()
//	{
//		com.kodgames.corgi.protocol.CommonProtocols.PlayerRankRecord.Builder builder = 
//				com.kodgames.corgi.protocol.CommonProtocols.PlayerRankRecord.newBuilder();
//		
//		builder.setPlayerId(playerId);
//		builder.setLevel(level);
//		builder.setPlayerValue(playerValue);
//		builder.setSupermanGuid(supermanGuid);
//		builder.setSupermanValue(supermanValue);
//		builder.setResourceId(resourceId);
//		if(playerName == null)
//			builder.setPlayerName("");
//		else
//			builder.setPlayerName(playerName);
//		
//		return builder.build();
//	}
//	//服务器之间
//	public PlayerRankRecord fromProtoBuf(CommonProtocols.PlayerRankRecord protoRecord)
//	{
//		this.playerId = protoRecord.getPlayerId();
//		
//		this.level = protoRecord.getLevel();
//		this.playerValue = protoRecord.getPlayerValue();
//		this.supermanGuid = protoRecord.getSupermanGuid();
//		this.supermanValue = protoRecord.getSupermanValue();
//		this.resourceId = protoRecord.getResourceId();
//		if(protoRecord.hasPlayerName() && protoRecord.getPlayerName()=="")
//			this.playerName=null;
//		else
//			this.playerName = protoRecord.getPlayerName();
//
//		return this;
//	}
	//服务器playerRankRecord转客户端playerRecord
	public CommonProtocols.PlayerRecord toProtoBufForClient()
	{
		CommonProtocols.PlayerRecord.Builder builder = CommonProtocols.PlayerRecord.newBuilder();
		builder.setPlayerId(playerId);
		builder.setPlayerLevel(level);
		if(playerName!=null&&!playerName.equals(""))
		{
			builder.setPlayerName(playerName);
		}
		else
		{
			builder.setPlayerName(GamePlayer.PLAYER_PREFIX_NAME+playerId);
		}
//		builder.addDatas(playerValue);
//		builder.addDatas(supermanValue);
//		builder.addDatas(resourceId);
//		builder.addDataStrings(supermanGuid);
		return builder.build();
	}
}
