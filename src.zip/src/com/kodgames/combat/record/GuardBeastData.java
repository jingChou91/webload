package com.kodgames.combat.record;

import java.util.ArrayList;
import java.util.List;
import system.Collections.Generic.List_1;
import ClientServerCommon.*;
import ClientServerCommon.AttributeCalculator.GuardBeastParam;

/**
 * 守护机关兽的数据
 */
public class GuardBeastData
{
	//属性
	private List<Attribute> baseAttributes = new ArrayList<>();
	private int id;
	private int breakThrough;
	private int level;

	public AttributeCalculator.GuardBeastParam guardBeastParam = null;

	public int getId()
	{
		return id;
	}

	public int getBreakThrough()
	{
		return breakThrough;
	}

	public int getLevel()
	{
		return level;
	}

	public List<Attribute> getBaseAttributes()
	{
		return this.baseAttributes;
	}

	public List_1 getAttributeList_1()
	{
		List_1 myList = ClientServerCommon.AttributeCalculator.CreateAttributeListHelper();
		for (Attribute at : baseAttributes)
		{
			myList.Add(new ClientServerCommon.AttributeCalculator.Attribute(at.getType(), at.getValue()));
		}
		return myList;
	}

	public void setAttributeByList_1(List_1 attributeList)
	{
		baseAttributes.clear();
		for (int k = 0; k < attributeList.get_Count(); ++k)
		{
			ClientServerCommon.AttributeCalculator.Attribute at
					= (ClientServerCommon.AttributeCalculator.Attribute) attributeList.get_Item(k);
			baseAttributes.add(new Attribute(at.type, at.value));
		}
	}

	public static GuardBeastData CreateGuardBeastData(ConfigDatabase cfgDb, int beastId, int breakThrough, int level, List<Integer> partAttributeIds)
	{
		GuardBeastData res = new GuardBeastData();
		AttributeCalculator.GuardBeastParam guardBeastParam = new AttributeCalculator.GuardBeastParam();

		res.id = guardBeastParam.id = beastId;
		res.breakThrough = guardBeastParam.breakThrough = breakThrough;
		res.level = guardBeastParam.level = level;
		for (int id : partAttributeIds)
		{
			system.ClrInt32 clrInt = new system.ClrInt32();
			clrInt.setValue(id);
			guardBeastParam.partAttributeIds.Add(clrInt);
		}

		//计算机关兽的属性
		cfgDb.get_AttributeCalculator().CalculateGuardBeastAttributes(guardBeastParam);

		//保存属性
		res.setAttributeByList_1(guardBeastParam.outPutAttributes);
		res.guardBeastParam = guardBeastParam;

		return res;
	}

	public GuardBeastData copy()
	{
		GuardBeastData res = new GuardBeastData();
		res.baseAttributes = new ArrayList<>();

		for (Attribute attri : this.baseAttributes)
		{
			res.baseAttributes.add(new Attribute(attri.getType(), attri.getValue()));
		}

		res.id = this.id;
		res.breakThrough = this.breakThrough;
		res.level = this.level;

		if (this.guardBeastParam != null)
			res.guardBeastParam = GuardBeastParam.CopyFrom(this.guardBeastParam);

		return res;
	}
}
