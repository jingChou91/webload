/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.record;

/**
 *
 * @author koduser
 */
public class EquipmentData
{
	private int id;
	private int breakThrough;

	public EquipmentData()
	{
	}

	public EquipmentData(int id, int breakThrough)
	{
		this.id = id;
		this.breakThrough = breakThrough;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public int getBreakThrough()
	{
		return breakThrough;
	}

	public void setBreakThrough(int breakThrough)
	{
		this.breakThrough = breakThrough;
	}

	public EquipmentData copy()
	{
		EquipmentData equipmentData = new EquipmentData();
		equipmentData.id = this.id;
		equipmentData.breakThrough = this.breakThrough;
		return equipmentData;
	}

	public com.kodgames.corgi.protocol.CombatData.EquipmentData toProtoBufClass()
	{
		com.kodgames.corgi.protocol.CombatData.EquipmentData.Builder builder = com.kodgames.corgi.protocol.CombatData.EquipmentData.newBuilder();
		builder.setId(id);
		builder.setBreakThrough(breakThrough);

		return builder.build();
	}

	public EquipmentData fromProtoBufClass(com.kodgames.corgi.protocol.CombatData.EquipmentData protocol)
	{
		id = protocol.getId();
		breakThrough = protocol.getBreakThrough();

		return this;
	}
}
