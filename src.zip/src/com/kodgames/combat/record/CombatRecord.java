/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.record;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author marui
 */
public class CombatRecord
{
	private List<RoundRecord> roundRecords = new LinkedList<>();
	
	public int getMaxRoundIndex()
	{
		int maxRoundIndex = 0;
		for(int i = 0;i<roundRecords.size();i++)
		{
			int roundIndex = roundRecords.get(i).getRoundIndex();
			if(maxRoundIndex < roundIndex)
			{
				maxRoundIndex=roundIndex;
			}
		}
		return maxRoundIndex;
	}

	public List<RoundRecord> getRecord()
	{
		return roundRecords;
	}

	public void addRecord(RoundRecord record, boolean check)
	{
		if (check && record.getTurnRecords().isEmpty())
		{
			return;
		}

		roundRecords.add(record);
	}

	public com.kodgames.corgi.protocol.CombatData.CombatRecord toProtoBufClass()
	{
		com.kodgames.corgi.protocol.CombatData.CombatRecord.Builder builder = com.kodgames.corgi.protocol.CombatData.CombatRecord.newBuilder();
		for (RoundRecord roundRecord : roundRecords)
		{
			builder.addRoundRecords(roundRecord.toProtoBufClass());
		}

		return builder.build();
	}

	public CombatRecord fromProtoBufClass(com.kodgames.corgi.protocol.CombatData.CombatRecord combatRecord)
	{
		for (com.kodgames.corgi.protocol.CombatData.RoundRecord roundRecord : combatRecord.getRoundRecordsList())
		{
			this.roundRecords.add(new RoundRecord().fromProtoBufClass(roundRecord));
		}

		return this;
	}
}
