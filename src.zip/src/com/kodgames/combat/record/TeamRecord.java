/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.record;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author sonilics
 */
public class TeamRecord
{
	private int teamIndex = -1;
	private boolean isWinner = false;
	private String displayName = "";
	private int evaluation;
	private List<AvatarResult> avatarResults = new ArrayList<>();
//	private List<Attribute> teamBaseAttributes = new ArrayList<>();
	
	public int getTeamIndex()
	{
		return teamIndex;
	}

	public void setTeamIndex(int teamIndex)
	{
		this.teamIndex = teamIndex;
	}
	
	public void setDisplayName(String name)
	{
		this.displayName = name;
	}
	
	public String getDisplayName()
	{
		return displayName;
	}
	
	public void setEvaluation(int evaluation)
	{
		this.evaluation = evaluation;
	}
	
	public int getEvaluation()
	{
		return evaluation;
	}
	
//	public void SetTeamBaseAttributes(List<Attribute> teamBaseAttributes)
//	{
//		this.teamBaseAttributes = teamBaseAttributes;
//	}

	public boolean isWinner()
	{
		return isWinner;
	}

	public void setIsWinner(boolean isWinner)
	{
		this.isWinner = isWinner;
	}

	public List<AvatarResult> getAvatarResults()
	{
		return this.avatarResults;
	}

	public com.kodgames.corgi.protocol.CombatData.TeamRecord toProtoBufClass()
	{
		com.kodgames.corgi.protocol.CombatData.TeamRecord.Builder builder = com.kodgames.corgi.protocol.CombatData.TeamRecord.newBuilder();

		builder.setTeamIndex(teamIndex);
		builder.setIsWinner(isWinner);
		builder.setDisplayName(displayName);
		builder.setEvaluation(evaluation);
		
		if (avatarResults != null)
		{
			for (AvatarResult avatarResult : avatarResults)
			{
				builder.addAvatarResults(avatarResult.toProtoBufClass());
			}
		}
		
//		if(teamBaseAttributes != null )
//		{
//			for (Attribute attr : teamBaseAttributes)
//			{
//				builder.addTeamBaseAttributes(attr.toProtobuf());
//			}
//		}

		return builder.build();
	}

	public TeamRecord fromProtoBufClass(com.kodgames.corgi.protocol.CombatData.TeamRecord protocol)
	{
		teamIndex = protocol.getTeamIndex();
		isWinner = protocol.getIsWinner();
		displayName = protocol.getDisplayName();
		evaluation = protocol.getEvaluation();

		for (com.kodgames.corgi.protocol.CombatData.AvatarResult avatarResult : protocol.getAvatarResultsList())
		{
			avatarResults.add(new AvatarResult().fromProtoBufClass(avatarResult));
		}
		
//		for (com.kodgames.corgi.protocol.CommonProtocols.Attribute attribute : protocol.getTeamBaseAttributesList())
//		{
//			teamBaseAttributes.add(new Attribute().fromProtobuf(attribute));
//		}

		return this;
	}
}
