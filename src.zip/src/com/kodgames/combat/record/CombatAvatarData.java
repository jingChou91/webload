/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.record;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import system.Collections.Generic.List_1;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon.DanConfig.DanAttribute;
import ClientServerCommon.NpcConfig;
import ClientServerCommon.PositionConfig._EmBattleType;
import ClientServerCommon.PropertyModifier;
import ClientServerCommon.PropertyModifierSet;
import ClientServerCommon._AvatarAttributeType;
import ClientServerCommon._AvatarType;
import ClientServerCommon._NpcType;
import ClientServerCommon.color;

import com.kodgames.common.Guid;
import com.kodgames.corgi.server.gameserver.guildstage.data.struct.GuildStageCombat;
import com.kodgames.corgi.server.gameserver.guildstage.util.StageUtil;

/**
 *
 * @author sonilics
 */
public class CombatAvatarData
{

	private static final Logger logger = LoggerFactory.getLogger(CombatAvatarData.class);

	int avatarType = _AvatarType.Unknown;
	String displayName = "";
	Guid guid = null; //角色卡Guid(烽火狼烟用)
	int resourceId;
	int breakThrough;
	LevelAttribute levelAttribute = new LevelAttribute();
	List<EquipmentData> equips = new ArrayList<>();
	List<Attribute> baseAttributes = new ArrayList<>();
	List<SkillData> skills = new ArrayList<>();
	List<BuffData> buffs = new ArrayList<>();
	private ArrayList<PropertyModifierSet> modifierSets = new ArrayList<>();
	int battlePosition;
	int evaluation;
	float scale = 1;
	int npcType = _NpcType.Normal;
	private int npcId;
	private int countryType = ClientServerCommon.AvatarConfig._AvatarCountryType.UnKnow;

	public double totalHPFotGSRank = 0;//只门派关卡boss排行榜那边用（boss天赋削弱前的总血量，查询boss伤害排行榜明细时使用）
	public double leftHP = 0;
	public double leftMaxHP = 0;
	public int illusionId;
	public GuardBeastData guardBeastData = null;//守护机关兽

	//[Attribute,Level]
	public ArrayList<DanAttriHolder> danAttriHolders = new ArrayList<>();

	public ArrayList<DanAttriHolder> mergedDanAttriHolders = new ArrayList<>();

	public static CombatAvatarData createNpcCombatAvatar(ConfigDatabase configDB, int npcId,
			int replaceNpcActiveSkillLevel, int battlePosition, GuildStageCombat guildStageCombat)
	{
		return createNpcCombatAvatar(configDB, npcId, replaceNpcActiveSkillLevel, battlePosition, null, guildStageCombat);
	}

	public static CombatAvatarData createNpcCombatAvatar(ConfigDatabase configDB, int npcId,
			int replaceNpcActiveSkillLevel, int battlePosition, ClientServerCommon.PropertyModifierSet propertyModifierSet, GuildStageCombat guildStageCombat)
	{
		NpcConfig.Npc npcCfg = configDB.get_NpcConfig().GetNpcById(npcId);
		if (npcCfg == null)
		{
			logger.error("createNpcCombatAvatar failed : npcId={}", Integer.toHexString(npcId));
			return null;
		}

		CombatAvatarData combatAvatar = new CombatAvatarData();
		combatAvatar.setAvatarType(_AvatarType.NpcAvatar);
		combatAvatar.setResourceId(npcCfg.get_avatarId());
		combatAvatar.setBreakThrough(npcCfg.get_breakthroughLevel());
//		combatAvatar.setCountryType(configDB.get_AvatarConfig().GetAvatarById(npcCfg.get_avatarId()).get_countryType());
		combatAvatar.setCountryType(npcCfg.get_countryType());

		// 这里 直接从npcCfg读取名字
		String name = npcCfg.get_name();
		combatAvatar.setDisplayName(name);
		combatAvatar.getLevelAttribute().setLevel(npcCfg.get_level());
		combatAvatar.setBattlePosition(battlePosition);

		// Initialize attribute
		combatAvatar.initializeBaseAttribute(configDB);
		for (int i = 0; i < npcCfg.Get_attribsCount(); ++i)
		{
			ClientServerCommon.Attribute attributeCfg = npcCfg.Get_attribsByIndex(i);
			combatAvatar.ReplaceAttribute(attributeCfg.get_type(), attributeCfg.get_value());
		}

		// Set skill
		for (int i = 0; i < npcCfg.Get_skillsCount(); ++i)
		{
			ClientServerCommon.NpcConfig.Skill skillCfg = npcCfg.Get_skillsByIndex(i);
			int skillId = skillCfg.get_id();
			// 技能等级至少是1
			int skillLevel = Math.max(1, skillCfg.get_level());
			combatAvatar.getSkills().add(new SkillData(skillId, skillLevel));
		}

		// npc机关兽配置
		NpcConfig.Equipment npcBeastCfg = npcCfg.get_beast();
		if (npcBeastCfg != null)
		{
			// 计算机关兽自身属性
			GuardBeastData guardBeastData
					= GuardBeastData.CreateGuardBeastData(configDB, npcBeastCfg.get_id(), npcBeastCfg.get_breakthroughLevel(), npcBeastCfg.get_level(), new ArrayList<Integer>());
			// 将计算后的机关兽属性传到角色身上用于计算角色的机关兽守护属性
			List_1 tempList = configDB.get_AttributeCalculator().ApplyGuardBeastAttributeToNpc(combatAvatar.getAttributeList_1(), guardBeastData.guardBeastParam);
			combatAvatar.setAttributeByList_1(tempList);
			// 将机关兽传至战斗服
			combatAvatar.guardBeastData = guardBeastData;
		}

		// // modifier
		// if(npcCfg.get_modifierSet() != null)
		// {
		//	combatAvatar.getModifierSets().add(npcCfg.get_modifierSet());
		// }
		// 计算阵位加成(前排,后排)
		ClientServerCommon.EmBattleAttribute emBattleAttribute = null;
		if (combatAvatar.getBattlePositionRow() == 0)
		{
			emBattleAttribute = configDB.get_PositionConfig().GetEmBattleAttributeByType(_EmBattleType.Front);
		}
		else if (combatAvatar.getBattlePositionRow() == 1)
		{
			emBattleAttribute = configDB.get_PositionConfig().GetEmBattleAttributeByType(_EmBattleType.Back);
		}

		if (emBattleAttribute != null)
		{
			PropertyModifierSet propertyModifierSetTemp = new PropertyModifierSet();
			for (int k = 0; k < emBattleAttribute.Get_modifiersCount(); k++)
			{
				propertyModifierSetTemp.AddOneModifier(emBattleAttribute.Get_modifiersByIndex(k));
			}
			List_1 myListRet
					= configDB.get_AttributeCalculator().ApplyPropertyModifiers(combatAvatar.getAttributeList_1(),
							propertyModifierSetTemp,
							true);

			// 门派关卡boss排行榜用
			for (int i = 0; i < myListRet.get_Count(); i++)
			{
				ClientServerCommon.AttributeCalculator.Attribute at
						= (ClientServerCommon.AttributeCalculator.Attribute) myListRet.get_Item(i);
				if (at.type == _AvatarAttributeType.MaxHP)
					combatAvatar.setTotalHPFotGSRank(at.value);
			}

			if (guildStageCombat != null)
			{
				int level = StageUtil.getTalentLevelById(guildStageCombat.getPlayerId(), configDB, guildStageCombat.getTalentId());
				if (level > 0)
				{
					configDB.get_AttributeCalculator().ApplyGuildTalent(myListRet, guildStageCombat.getTalentId(), level);
				}
			}
			combatAvatar.setAttributeByList_1(myListRet);
		}

		if (propertyModifierSet != null)
		{
			List_1 myListRet
					= configDB.get_AttributeCalculator().ApplyPropertyModifiers(combatAvatar.getAttributeList_1(),
							propertyModifierSet,
							true);
			if (guildStageCombat != null)
			{
				int level = StageUtil.getTalentLevelById(guildStageCombat.getPlayerId(), configDB, guildStageCombat.getTalentId());
				if (level > 0)
				{
					configDB.get_AttributeCalculator().ApplyGuildTalent(myListRet, guildStageCombat.getTalentId(), level);
				}
			}
			combatAvatar.setAttributeByList_1(myListRet);
		}

		return combatAvatar;
	}

	public static CombatAvatarData createStepNpcCombatAvatarForMelaleucaFloor(ConfigDatabase configDB, int npcId,
			int replaceNpcActiveSkillLevel, int battlePosition, int step)
	{
		NpcConfig.Npc npcCfg = configDB.get_NpcConfig().GetNpcById(npcId);
		if (npcCfg == null)
		{
			logger.error("createNpcCombatAvatar failed : npcId={}", npcId);
			return null;
		}

		CombatAvatarData combatAvatar = new CombatAvatarData();
		combatAvatar.setAvatarType(_AvatarType.NpcAvatar);
		combatAvatar.setResourceId(npcCfg.get_avatarId());
		combatAvatar.setBreakThrough(npcCfg.get_breakthroughLevel());
//		combatAvatar.setCountryType(CfgDB.getDefautConfig()
//				.get_AvatarConfig()
//				.GetAvatarById(npcCfg.get_avatarId())
//				.get_countryType());
		combatAvatar.setCountryType(npcCfg.get_countryType());

		// 这里 直接从npcCfg读取名字
		String name = npcCfg.get_name();
		combatAvatar.setDisplayName(name);
		combatAvatar.getLevelAttribute().setLevel(npcCfg.get_level());
		combatAvatar.setBattlePosition(battlePosition);

		// Initialize attribute
		combatAvatar.initializeBaseAttribute(configDB);
		for (int i = 0; i < npcCfg.Get_attribsCount(); ++i)// GetAttributeCount()
		{
			ClientServerCommon.Attribute attributeCfg = npcCfg.Get_attribsByIndex(i);// GetAttribute(i)
			double value = attributeCfg.get_value();
			switch (attributeCfg.get_type())
			{
				case _AvatarAttributeType.PAP:// 物理攻击
				case _AvatarAttributeType.MAP:// 魔法攻击
				case _AvatarAttributeType.Speed: // 敏捷
				case _AvatarAttributeType.HP: // 血量
				case _AvatarAttributeType.MaxHP: // 最大血量
					value *= Math.pow((double) 1.2, step);
					break;
				case _AvatarAttributeType.CSR: // 暴击率
				case _AvatarAttributeType.RR: // 免暴率
				case _AvatarAttributeType.HR: // 命中率
				case _AvatarAttributeType.DgR: // 闪避率
				case _AvatarAttributeType.AR: // 伤害率
				case _AvatarAttributeType.PDR: // 物抗
				case _AvatarAttributeType.MDR: // 法抗
				case _AvatarAttributeType.CR: // 反击
				case _AvatarAttributeType.RCR: // 抗反击
					value *= ((step - 1) * (double) 0.2 + 1);

			}
			combatAvatar.ReplaceAttribute(attributeCfg.get_type(), value);
		}

		// Set skill
		for (int i = 0; i < npcCfg.Get_skillsCount(); ++i)// GetSkillCount()
		{
			ClientServerCommon.NpcConfig.Skill skillCfg = npcCfg.Get_skillsByIndex(i);// GetSkill(i)
			int skillId = skillCfg.get_id();
			// 技能等级至少是1
			int skillLevel = Math.max(1, skillCfg.get_level());
			combatAvatar.getSkills().add(new SkillData(skillId, skillLevel));
		}

		// npc机关兽配置
		NpcConfig.Equipment npcBeastCfg = npcCfg.get_beast();
		if (npcBeastCfg != null)
		{
			// 计算机关兽自身属性
			GuardBeastData guardBeastData
					= GuardBeastData.CreateGuardBeastData(configDB, npcBeastCfg.get_id(), npcBeastCfg.get_breakthroughLevel(), npcBeastCfg.get_level(), new ArrayList<Integer>());
			// 将计算后的机关兽属性传到角色身上用于计算角色的机关兽守护属性
			List_1 tempList = configDB.get_AttributeCalculator().ApplyGuardBeastAttributeToNpc(combatAvatar.getAttributeList_1(), guardBeastData.guardBeastParam);
			combatAvatar.setAttributeByList_1(tempList);
			// 将机关兽传至战斗服
			combatAvatar.guardBeastData = guardBeastData;
		}

		// // modifier
		// if(npcCfg.get_modifierSet() != null)
		// {
		// combatAvatar.getModifierSets().add(npcCfg.get_modifierSet());
		// }
		// 计算阵位加成(前排,后排)
		ClientServerCommon.EmBattleAttribute emBattleAttribute = null;
		if (combatAvatar.getBattlePositionRow() == 0)
		{
			emBattleAttribute = configDB.get_PositionConfig().GetEmBattleAttributeByType(_EmBattleType.Front);
		}
		else if (combatAvatar.getBattlePositionRow() == 1)
		{
			emBattleAttribute = configDB.get_PositionConfig().GetEmBattleAttributeByType(_EmBattleType.Back);
		}

		if (emBattleAttribute != null)
		{
			PropertyModifierSet propertyModifierSet = new PropertyModifierSet();
			for (int k = 0; k < emBattleAttribute.Get_modifiersCount(); k++)
			{
				propertyModifierSet.AddOneModifier(emBattleAttribute.Get_modifiersByIndex(k));
			}
			List_1 myListRet
					= configDB.get_AttributeCalculator().ApplyPropertyModifiers(combatAvatar.getAttributeList_1(),
							propertyModifierSet,
							true);
			combatAvatar.setAttributeByList_1(myListRet);
		}

		return combatAvatar;
	}

	/**
	 * 合并相同的DanAttribute，减少计算次数
	 */
	public void PrepareMergedDanAttriHolders()
	{
		long startTime = System.currentTimeMillis();
		ArrayList<DanAttriHolder> merged = new ArrayList<>();
		int mergedIdx = -1;
		DanAttriHolder mergedH;
		for (DanAttriHolder holder : danAttriHolders)
		{
			//战前属性调整不在战斗中起作用
			if (holder.danAttribute.get_FuncType() == DanConfig._DanFuncType.AttributeModifyAfterInit_P
					|| holder.danAttribute.get_FuncType() == DanConfig._DanFuncType.AttributeModifyAfterInit_V
					|| holder.danAttribute.get_FuncType() == DanConfig._DanFuncType.EquipStrengthen)
				continue;

			mergedIdx = merged.indexOf(holder);
			if (mergedIdx == -1)
			{
				merged.add(DanAttriHolder.CopyFrom(holder));
				continue;
			}

			mergedH = merged.get(mergedIdx);
			DanAttribute.CheckAndMerge(holder.danAttribute, mergedH.danAttribute, mergedH.level);
		}

		this.mergedDanAttriHolders = merged;

		com.kodgames.combat.algorithm.ProfilerData.MergeDanAttriHoldersTime += System.currentTimeMillis() - startTime;
	}

	public double getAttributeValue(int type)
	{
		for (Attribute attr : baseAttributes)
		{
			if (attr.getType() == type)
			{
				return attr.getValue();
			}
		}

		return 0;
	}

	public Attribute getAttribute(int type)
	{
		for (Attribute attr : baseAttributes)
		{
			if (attr.getType() == type)
			{
				return attr;
			}
		}
		return null;
	}

	public void setAttributeValue(int type, double value)
	{
		for (Attribute attr : baseAttributes)
		{
			if (attr.getType() == type)
			{
				attr.setValue(value);
			}
		}
	}

	public boolean hasAttribute(int type)
	{
		for (Attribute attr : baseAttributes)
		{
			if (attr.getType() == type)
			{
				return true;
			}
		}

		return false;
	}

	public Guid getGuid()
	{
		return guid;
	}

	public void setGuid(Guid guid)
	{
		this.guid = guid;
	}

	public float getScale()
	{
		return this.scale;
	}

	public void setScale(float scale)
	{
		this.scale = scale;
	}

	public int getNpcType()
	{
		return this.npcType;
	}

	public void setNpcType(int npcType)
	{
		this.npcType = npcType;
	}

	public int getNpcId()
	{
		return this.npcId;
	}

	public void setNpcId(int npcId)
	{
		this.npcId = npcId;
	}

	public int getCountryType()
	{
		return this.countryType;
	}

	public void setCountryType(int countryType)
	{
		this.countryType = countryType;
	}

	public int getEvaluation()
	{
		return evaluation;
	}

	public int getAvatarType()
	{
		return this.avatarType;
	}

	public void setAvatarType(int avatarType)
	{
		this.avatarType = avatarType;
	}

	public String getDisplayName()
	{
		return this.displayName;
	}

	public void setDisplayName(String displayName)
	{
		this.displayName = displayName;
	}

	public int getResourceId()
	{
		return resourceId;
	}

	public void setResourceId(int resourceId)
	{
		this.resourceId = resourceId;
	}

	public int getBreakThrough()
	{
		return breakThrough;
	}

	public void setBreakThrough(int breakThrough)
	{
		this.breakThrough = breakThrough;
	}

	public LevelAttribute getLevelAttribute()
	{
		return levelAttribute;
	}

	public void setLevelAttribute(LevelAttribute levelAttribute)
	{
		this.levelAttribute = levelAttribute;
	}

	public List<EquipmentData> getEquipments()
	{
		return equips;
	}

	public List<Attribute> getBaseAttributes()
	{
		return baseAttributes;
	}

	public List<SkillData> getSkills()
	{
		return skills;
	}

	public List<BuffData> getBuffs()
	{
		return buffs;
	}

	public List<PropertyModifierSet> getModifierSets()
	{
		return modifierSets;
	}

	public void addModifierSet(PropertyModifierSet set)
	{
		modifierSets.add(set);
	}

	public int getIllusionId()
	{
		return illusionId;
	}

	public void setIllusionId(int illusionId)
	{
		this.illusionId = illusionId;
	}

	public int getBattlePosition()
	{
		return battlePosition;
	}

	public int getBattlePositionRow()
	{
		return (battlePosition >>> 16) & 0xFFFF;
	}

	public int getBattlePositionColumn()
	{
		return battlePosition & 0xFFFF;
	}

	public void setBattlePosition(int battlePosition)
	{
		this.battlePosition = battlePosition;
	}

	public void setBattlePosition(int row, int column)
	{
		battlePosition = ((row & 0x0000FFFF) << 16) | (column & 0x0000FFFF);
	}

	public void setBattlePositionRow(int row)
	{
		battlePosition = ((row & 0x0000FFFF) << 16) | (getBattlePositionColumn() & 0x0000FFFF);
	}

	public static int getBattlePosition(int row, int column)
	{
		return ((row & 0x0000FFFF) << 16) | (column & 0x0000FFFF);
	}

	public void setEvaluation(int evaluation)
	{
		this.evaluation = evaluation;
	}

	/**
	 * 只门派关卡boss排行榜那边用
	 *
	 * @return
	 */
	public double getTotalHPFotGSRank()
	{
		return totalHPFotGSRank;
	}

	public void setTotalHPFotGSRank(double totalHPFotGSRank)
	{
		this.totalHPFotGSRank = totalHPFotGSRank;
	}

	/**
	 * 如果在GameConfig.CombatSetting中配置了属性值，则所有角色的该属性会被替换为配置的属性
	 *
	 * @param configDB
	 */
	public void initializeBaseAttribute(ConfigDatabase configDB)
	{
		for (int i = 0; i < configDB.get_GameConfig().get_combatSetting().Get_baseAttributesCount(); ++i)
		{
			ClientServerCommon.Attribute baseAttribute
					= configDB.get_GameConfig().get_combatSetting().Get_baseAttributesByIndex(i);
			if (baseAttribute == null)
			{
				continue;
			}

			ReplaceAttribute(baseAttribute.get_type(), baseAttribute.get_value());
		}
	}

	public void ReplaceAttribute(int attributeType, double value)
	{
		for (Attribute attribute : baseAttributes)
		{
			if (attribute.getType() == attributeType)
			{
				attribute.setValue(value);
				return;
			}
		}

		Attribute attribute = new Attribute();
		attribute.setType(attributeType);
		attribute.setValue(value);
		baseAttributes.add(attribute);
	}

	public CombatAvatarData copy()
	{
		CombatAvatarData combatAvatarData = new CombatAvatarData();
		combatAvatarData.displayName = this.displayName;
		combatAvatarData.resourceId = this.resourceId;
		combatAvatarData.breakThrough = this.breakThrough;
		combatAvatarData.levelAttribute = this.levelAttribute.copy();
		combatAvatarData.battlePosition = this.battlePosition;
		combatAvatarData.evaluation = this.evaluation;
		combatAvatarData.avatarType = this.avatarType;
		combatAvatarData.scale = this.scale;
		combatAvatarData.npcType = this.npcType;
		combatAvatarData.npcId = this.npcId;
		combatAvatarData.countryType = this.countryType;
		combatAvatarData.leftHP = this.leftHP;
		combatAvatarData.leftMaxHP = this.leftMaxHP;
		combatAvatarData.illusionId = this.illusionId;
		if (this.guardBeastData != null)
			combatAvatarData.guardBeastData = this.guardBeastData.copy();

		for (EquipmentData equi : this.equips)
		{
			combatAvatarData.equips.add(equi.copy());
		}

		for (Attribute attr : this.baseAttributes)
		{
			combatAvatarData.baseAttributes.add(attr.copy());
		}

		for (SkillData skill : this.skills)
		{
			combatAvatarData.skills.add(skill.copy());
		}

		for (BuffData buff : this.buffs)
		{
			combatAvatarData.buffs.add(buff.copy());
		}

		for (PropertyModifierSet set : this.modifierSets)
		{
			PropertyModifierSet tmp = new PropertyModifierSet();
			for (int i = 0; i < set.Get_modifiersCount(); i++)// GetModifierCount()
			{
				PropertyModifier modifier = set.Get_modifiersByIndex(i);// GetModifier(i)
				PropertyModifier tmpModifier = new PropertyModifier();
				tmpModifier.set_type(modifier.get_type());
				tmpModifier.set_abilityType(modifier.get_abilityType());
				tmpModifier.set_abilityValue(modifier.get_abilityValue());
				tmpModifier.set_attributeType(modifier.get_attributeType());
				tmpModifier.set_attributeValue(modifier.get_attributeValue());
				tmpModifier.set_buffType(modifier.get_buffType());
				tmpModifier.set_color(color.CopyFrom(modifier.get_color()));
				tmpModifier.set_modifyType(modifier.get_modifyType());
				tmp.AddOneModifier(tmpModifier);
			}

			combatAvatarData.modifierSets.add(tmp);
		}
		return combatAvatarData;
	}

	public CombatAvatarData fromProtobuf(com.kodgames.corgi.protocol.CombatData.CombatAvatarData protocol)
	{
		this.displayName = protocol.getDisplayName();
		this.resourceId = protocol.getResourceId();
		this.breakThrough = protocol.getBreakThrough();
		this.levelAttribute = new LevelAttribute().fromProtobuf(protocol.getLevelAttrib());
		this.battlePosition = protocol.getBattlePosition();
		this.evaluation = protocol.getEvaluation();
		this.avatarType = protocol.getAvatarType();
		this.scale = protocol.getScale();
		this.npcType = protocol.getNpcType();
		this.npcId = protocol.getNpcId();
		this.countryType = protocol.getCountryType();
		this.illusionId = protocol.getIllusionId();

		for (com.kodgames.corgi.protocol.CombatData.EquipmentData _protocol : protocol.getEquipsList())
		{
			this.equips.add(new EquipmentData().fromProtoBufClass(_protocol));
		}

		for (com.kodgames.corgi.protocol.CommonProtocols.Attribute _protocol : protocol.getAttributesList())
		{
			this.baseAttributes.add(new Attribute().fromProtobuf(_protocol));
		}

		for (com.kodgames.corgi.protocol.CombatData.SkillData _protocol : protocol.getSkillsList())
		{
			this.skills.add(new SkillData().fromProtoBufClass(_protocol));
		}

		for (com.kodgames.corgi.protocol.CombatData.BuffData _protocol : protocol.getBuffsList())
		{
			this.buffs.add(new BuffData().fromProtoBufClass(_protocol));
		}

		List<ModifierSet> modifierDataSets = new ArrayList<>();
		for (com.kodgames.corgi.protocol.CombatData.ModifierSet _protocol : protocol.getModifierSetsList())
		{
			modifierDataSets.add(new ModifierSet().fromProtoBufClass(_protocol));
		}

		for (ModifierSet setDate : modifierDataSets)
		{
			PropertyModifierSet set = new PropertyModifierSet();
			for (Modifier mdate : setDate.getModifierSet())
			{
				PropertyModifier modifier = new PropertyModifier();
				modifier.set_type(mdate.getType());
				modifier.set_abilityType(mdate.getAbilityType());
				modifier.set_abilityValue(mdate.getAbilityValue());
				set.AddOneModifier(modifier);
			}
			this.modifierSets.add(set);
		}

		return this;
	}

	public com.kodgames.corgi.protocol.CombatData.CombatAvatarData toProtobuf()
	{
		com.kodgames.corgi.protocol.CombatData.CombatAvatarData.Builder builder
				= com.kodgames.corgi.protocol.CombatData.CombatAvatarData.newBuilder();

		builder.setResourceId(resourceId);
		builder.setBreakThrough(breakThrough);
		builder.setDisplayName(displayName);
		builder.setLevelAttrib(levelAttribute.toProtobuf());
		builder.setBattlePosition(battlePosition);
		builder.setEvaluation(evaluation);
		builder.setAvatarType(this.avatarType);
		builder.setScale(scale);
		builder.setNpcType(npcType);
		builder.setNpcId(npcId);
		builder.setCountryType(countryType);
		builder.setIllusionId(illusionId);

		for (EquipmentData equipment : this.equips)
		{
			builder.addEquips(equipment.toProtoBufClass());
		}

		for (Attribute attribute : this.baseAttributes)
		{
			builder.addAttributes(attribute.toProtobuf());
		}

		for (SkillData skill : this.skills)
		{
			builder.addSkills(skill.toProtoBufClass());
		}

		for (BuffData buff : this.buffs)
		{
			builder.addBuffs(buff.toProtoBufClass());
		}

		for (PropertyModifierSet set : this.modifierSets)
		{
			ModifierSet setDate = new ModifierSet();
			for (int i = 0; i < set.Get_modifiersCount(); i++)// GetModifierCount()
			{
				PropertyModifier modifier = set.Get_modifiersByIndex(i);// GetModifier(i)
				Modifier modifierDate
						= new Modifier(modifier.get_type(), modifier.get_abilityType(), modifier.get_abilityValue());
				setDate.addModifier(modifierDate);
			}

			builder.addModifierSets(setDate.toProtoBufClass());
		}

		return builder.build();
	}

	public List_1 getAttributeList_1()
	{
		List_1 myList = ClientServerCommon.AttributeCalculator.CreateAttributeListHelper();
		for (Attribute at : baseAttributes)
		{
			myList.Add(new ClientServerCommon.AttributeCalculator.Attribute(at.getType(), at.getValue()));
		}
		return myList;
	}

	public void setAttributeByList_1(List_1 attributeList)
	{
		baseAttributes.clear();
		for (int k = 0; k < attributeList.get_Count(); ++k)
		{
			ClientServerCommon.AttributeCalculator.Attribute at
					= (ClientServerCommon.AttributeCalculator.Attribute) attributeList.get_Item(k);
			baseAttributes.add(new Attribute(at.type, at.value));
		}
	}

	public static StringBuffer getDumpAttributes(List_1 attributeList)
	{
		StringBuffer sb = new StringBuffer();
		if (attributeList != null)
		{
			for (int k = 0; k < attributeList.get_Count(); ++k)
			{
				ClientServerCommon.AttributeCalculator.Attribute at
						= (ClientServerCommon.AttributeCalculator.Attribute) attributeList.get_Item(k);
				sb.append("\t").append(at.type).append("\t").append(at.value).append("\n");
			}
		}
		return sb;
	}
}
