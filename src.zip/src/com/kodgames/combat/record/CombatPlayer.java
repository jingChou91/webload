/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.record;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author sonilics
 */
public class CombatPlayer
{
	private int playerId;
	private String displayName = "";
	private List<CombatAvatarData> combatAvatarDatas = new ArrayList<>();
	private int evaluation;
	private boolean isExtendsHP = false; // 服务器战斗线程使用

	public boolean isExtendsHP()
	{
		return isExtendsHP;
	}

	public void setExtendsHP(boolean isExtendsHP)
	{
		this.isExtendsHP = isExtendsHP;
	}

	public int getEvaluation()
	{
		return evaluation;
	}

	public void setEvaluation(int evaluation)
	{
		this.evaluation = evaluation;
	}

	public int getPlayerId()
	{
		return playerId;
	}

	public void setPlayerId(int playerId)
	{
		this.playerId = playerId;
	}

	public void setDisplayName(String name)
	{
		this.displayName = name;
	}

	public String getDisplayName()
	{
		return displayName;
	}

	public List<CombatAvatarData> getCombatAvatarDatas()
	{
		return this.combatAvatarDatas;
	}

	public void addCombatAvatarDatas(CombatAvatarData combatAvatarData)
	{
		combatAvatarDatas.add(combatAvatarData);
	}

	public CombatPlayer copy()
	{
		CombatPlayer combatPlayer = new CombatPlayer();
		combatPlayer.playerId = this.playerId;
		combatPlayer.isExtendsHP = this.isExtendsHP;
		combatPlayer.evaluation = this.evaluation;
		combatPlayer.displayName = new String(this.displayName);

		for (CombatAvatarData combatAvatarData : this.combatAvatarDatas)
		{
			combatPlayer.combatAvatarDatas.add(combatAvatarData.copy());
		}
		return combatPlayer;
	}

	public CombatPlayer fromProtobuf(com.kodgames.corgi.protocol.CombatData.CombatPlayer protocol)
	{
		this.playerId = protocol.getPlayerId();
		this.displayName = protocol.getDisplayName();
		this.evaluation = protocol.getEvaluation();

		combatAvatarDatas.clear();
		for (com.kodgames.corgi.protocol.CombatData.CombatAvatarData _protocol : protocol.getCombatAvatarDatasList())
		{
			combatAvatarDatas.add(new CombatAvatarData().fromProtobuf(_protocol));
		}

		return this;
	}

	public com.kodgames.corgi.protocol.CombatData.CombatPlayer toProtobuf()
	{
		com.kodgames.corgi.protocol.CombatData.CombatPlayer.Builder builder = com.kodgames.corgi.protocol.CombatData.CombatPlayer.newBuilder();

		builder.setPlayerId(playerId);
		if (displayName == null)
			builder.setDisplayName("" + playerId);
		else
			builder.setDisplayName(displayName);
		builder.setEvaluation(evaluation);

		for (CombatAvatarData avatar : combatAvatarDatas)
		{
			builder.addCombatAvatarDatas(avatar.toProtobuf());
		}

		return builder.build();
	}
}
