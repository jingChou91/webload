package com.kodgames.combat.record;

import java.util.ArrayList;

import com.kodgames.gamedata.player.PlayerNode;

public class PlayerRecord
{

	int playerId;
	String playerName = "";
	int playerLevel;
	int vipLevel;

	ArrayList<Integer> avatarResourceIds = new ArrayList<Integer>();
	ArrayList<Integer> datas = new ArrayList<Integer>();

	public static PlayerRecord copy(PlayerRecord record)
	{
		PlayerRecord copy = new PlayerRecord();
		copy.setPlayerId(record.getPlayerId());
		copy.setPlayerName(record.getPlayerName());
		copy.setPlayerLevel(record.getPlayerLevel());
		copy.setVipLevel(record.getVipLevel());

		ArrayList<Integer> avatarResourceIds = new ArrayList<Integer>();
		for (int i : record.getAvatarResourceIds())
		{
			avatarResourceIds.add(i);
		}
		copy.setAvatarResourceIds(avatarResourceIds);

		ArrayList<Integer> datas = new ArrayList<Integer>();
		for (int i : record.getDatas())
		{
			datas.add(i);
		}
		copy.setDatas(datas);
		return copy;
	}

	// public String getFixName(){
	// if(playerName==null||playerName.equals(""))
	// return GamePlayer.PLAYER_PREFIX_NAME+playerId;
	// return playerName;
	// }

	public int getVipLevel()
	{
		return vipLevel;
	}

	public void setVipLevel(int vipLevel)
	{
		this.vipLevel = vipLevel;
	}

	public int getPlayerId()
	{
		return playerId;
	}

	public void setPlayerId(int playerId)
	{
		this.playerId = playerId;
	}

	public String getPlayerName()
	{
		return playerName;
	}

	public void setPlayerName(String playerName)
	{
		this.playerName = playerName;
	}

	public int getPlayerLevel()
	{
		return playerLevel;
	}

	public void setPlayerLevel(int playerLevel)
	{
		this.playerLevel = playerLevel;
	}

	public ArrayList<Integer> getAvatarResourceIds()
	{
		return avatarResourceIds;
	}

	public void setAvatarResourceIds(ArrayList<Integer> avatarResourceIds)
	{
		this.avatarResourceIds = avatarResourceIds;
	}

	public ArrayList<Integer> getDatas()
	{
		return datas;
	}

	public void setDatas(ArrayList<Integer> datas)
	{
		this.datas = datas;
	}

	public com.kodgames.corgi.protocol.CommonProtocols.PlayerRecord toProtobuf()
	{
		com.kodgames.corgi.protocol.CommonProtocols.PlayerRecord.Builder builder =
			com.kodgames.corgi.protocol.CommonProtocols.PlayerRecord.newBuilder();

		builder.setPlayerId(playerId);
		if (playerName != null)
		{
			builder.setPlayerName(playerName);
		}
		builder.setPlayerLevel(playerLevel);
		builder.setVipLevel(vipLevel);

		for (int avatarResourceId : avatarResourceIds)
		{
			builder.addAvatarResourceIds(avatarResourceId);
		}

//		for (int data : datas)
//		{
//			builder.addDatas(data);
//		}

		return builder.build();
	}

	public PlayerRecord fromProtobuf(com.kodgames.corgi.protocol.CommonProtocols.PlayerRecord playerRecord)
	{
		playerId = playerRecord.getPlayerId();
		playerName = playerRecord.getPlayerName();
		playerLevel = playerRecord.getPlayerLevel();
		vipLevel = playerRecord.getVipLevel();

		avatarResourceIds.clear();
		for (int avatarResourceId : playerRecord.getAvatarResourceIdsList())
		{
			avatarResourceIds.add(avatarResourceId);
		}

		datas.clear();
//		for (int data : playerRecord.getDatasList())
//		{
//			datas.add(data);
//		}
//
//		if (this.playerName == null || this.playerName.equals(""))
//		{
//			this.playerName = GamePlayer.PLAYER_PREFIX_NAME + this.playerId;
//		}

		return this;
	}

//	public PlayerRecord()
//	{
//	}
//
	public static PlayerRecord newFromPlayerNode(PlayerNode playerNode, int[] _datas)
	{

		PlayerRecord playerRecord = new PlayerRecord();
		return playerRecord.fromRobPlayer(playerNode, _datas);
	}
//
//	public static PlayerRecord newFromGamePlayer(PlayerNode playerNode, int[] _datas, ConfigDatabase cd)
//	{
//
//		PlayerRecord playerRecord = new PlayerRecord();
//		return playerRecord.fromGamePlayer(playerNode, _datas, cd);
//	}
//
	public PlayerRecord fromRobPlayer(PlayerNode playerNode, int[] _datas)
	{
		this.playerId = playerNode.getPlayerId();
		this.playerName = playerNode.getGamePlayer().getFixName();
		this.playerLevel = playerNode.getGamePlayer().getLevel();
		this.vipLevel = playerNode.getGamePlayer().getVipLevel();

//		avatarResourceIds.clear();
//		for (int avatarResourceId : playerNode.getGamePlayer().getCombatAvatarsMgr().getAvatarResourceId())
//		{
//			if (avatarResourceId != 0)
//			{
//				avatarResourceIds.add(avatarResourceId);
//			}
//		}

		this.datas.clear();
		if (_datas != null)
		{
			for (int data : _datas)
			{
				this.datas.add(data);
			}
		}

//		if (this.playerName == null || this.playerName.equals(""))
//		{
//			this.playerName = GamePlayer.PLAYER_PREFIX_NAME + this.playerId;
//		}
		return this;
	}
//
//	public PlayerRecord fromGamePlayer(PlayerNode playerNode, int[] _datas, ConfigDatabase cd)
//	{
//
//		this.playerId = playerNode.getPlayerId();
//		this.playerName = playerNode.getGamePlayer().getFixName();
//		this.playerLevel = playerNode.getGamePlayer().getLevel();
//		this.vipLevel = playerNode.getGamePlayer().getVipLevel();
//
//		avatarResourceIds.clear();
//		avatarResourceIds = AvatarEquipSkillManager.getCombatAvatarIds(playerNode, cd, false);
//
//		this.datas.clear();
//		if (_datas != null)
//		{
//			for (int data : _datas)
//			{
//				this.datas.add(data);
//			}
//		}
//
//		if (this.playerName == null || this.playerName.equals(""))
//		{
//			this.playerName = GamePlayer.PLAYER_PREFIX_NAME + this.playerId;
//		}
//
//		return this;
//	}
//
//	public static StringBuffer getDump(ArrayList<PlayerRecord> playerRecords)
//	{
//		StringBuffer sb = new StringBuffer();
//		if (playerRecords == null)
//		{
//			sb.append("playerRecords_is_null\n");
//		}
//		else
//		{
//			if (playerRecords.size() == 0)
//			{
//				sb.append("playerRecords_num_is_0\n");
//			}
//			else
//			{
//				sb.append("playerRecords : \n");
//				for (PlayerRecord temp : playerRecords)
//				{
//					sb.append(PlayerRecord.getDumpData(temp));
//				}
//			}
//		}
//
//		return sb;
//	}
//
//	public static StringBuffer getDumpData(PlayerRecord playerRecord)
//	{
//		StringBuffer sb = new StringBuffer();
//		if (playerRecord == null)
//		{
//			sb.append("playerRecord is null");
//		}
//		else
//		{
//			sb.append("\tid=");
//			sb.append(playerRecord.getPlayerId());
//			sb.append("\tlevel=");
//			sb.append(playerRecord.getPlayerLevel());
//			sb.append("\tname=");
//			sb.append(playerRecord.getPlayerName());
//			sb.append("\tdatas=");
//			sb.append(playerRecord.getDatas());
//		}
//		sb.append("\n");
//		return sb;
//	}
//
//	public static PlayerRecord genPlayerRecord(int playerId, int damage, WorldBossRecord bossRecord)
//	{
//		PlayerRecord record = new PlayerRecord();
//		record.setPlayerId(playerId);
//		if (record.getDatas().size() <= 0)
//		{
//			record.getDatas().add(0);
//		}
//		record.getDatas().set(0, damage);
//
//		if (bossRecord != null)
//		{
//			// 奖励值 是排名奖励
//			if (record.getDatas().size() <= 1)
//			{
//				record.getDatas().add(0);
//			}
//			record.getDatas().set(1,
//				(int)ExpressionCalc.getValue_WorldBossNotDeadRankReward(CfgDB.getDefautConfig(), bossRecord, damage));
//		}
//
//		return record;
//	}
//
//	public static PlayerRecord genPlayerRecord(int playerId, int damage, int rewardCount)
//	{
//		PlayerRecord record = new PlayerRecord();
//		record.setPlayerId(playerId);
//		if (record.getDatas().size() <= 0)
//		{
//			record.getDatas().add(0);
//		}
//		if (record.getDatas().size() <= 1)
//		{
//			record.getDatas().add(0);
//		}
//
//		record.getDatas().set(0, damage);
//		record.getDatas().set(1, rewardCount);
//
//		return record;
//	}
//
//	public static PlayerRecord genFriendFeedPlayerRecord(int playerId, int extraGet)
//	{
//		PlayerRecord record = new PlayerRecord();
//		record.setPlayerId(playerId);
//		if (record.getDatas().size() <= 0)
//		{
//			record.getDatas().add(extraGet);
//		}
//		record.getDatas().set(0, extraGet);
//
//		PlayerNode playerNode = ServerDataGS.playerManager.getMemoryPlayerNode(playerId);
//		if (playerNode != null && playerNode.getGamePlayer() != null)
//		{
//			record.setPlayerName(playerNode.getGamePlayer().getFixName());
//		}
//		else
//		{
//			record.setPlayerName(GamePlayer.PLAYER_PREFIX_NAME + record.getPlayerId());
//		}
//
//		return record;
//	}
//
//	public void setWorldBossRewardCount(int rewardCount)
//	{
//
//		if (this.getDatas().size() <= 0)
//		{
//			this.getDatas().add(0);
//		}
//		if (this.getDatas().size() <= 1)
//		{
//			this.getDatas().add(0);
//		}
//		this.getDatas().set(1, rewardCount);
//	}
}