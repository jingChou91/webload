/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.record;

/**
 *
 * @author koduser
 */
public class Modifier
{
	private int type;
	private int abilityType;
	private int abilityValue;

	public Modifier(int type, int abilityType, int value)
	{
		this.type = type;
		this.abilityType = abilityType;
		this.abilityValue = value;
	}

	public int getType()
	{
		return type;
	}

	public int getAbilityType()
	{
		return abilityType;
	}

	public int getAbilityValue()
	{
		return abilityValue;
	}

	public com.kodgames.corgi.protocol.CombatData.Modifier toProtoBufClass()
	{
		com.kodgames.corgi.protocol.CombatData.Modifier.Builder builder = com.kodgames.corgi.protocol.CombatData.Modifier.newBuilder();
		builder.setType(type);
		builder.setAbilityType(abilityType);
		builder.setValue(abilityValue);

		return builder.build();
	}

	public Modifier fromProtoBufClass(com.kodgames.corgi.protocol.CombatData.Modifier protocol)
	{
		type = protocol.getType();
		abilityType = protocol.getAbilityType();
		abilityValue = protocol.getValue();

		return this;
	}
}
