/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.record;

import ClientServerCommon.DanConfig.DanAttribute;

/**
 * 内丹属性 等级，具体属性
 */
public class DanAttriHolder
{
	public int level;
	public DanAttribute danAttribute;

	public DanAttriHolder()
	{
	}

	public DanAttriHolder(int level, DanAttribute danAttribute)
	{
		this.level = level;
		this.danAttribute = danAttribute;
	}
	
	public static DanAttriHolder CopyFrom(DanAttriHolder other)
	{
		DanAttriHolder dh = new DanAttriHolder();
		dh.level = other.level;
		dh.danAttribute = DanAttribute.CopyFrom(other.danAttribute);
		return dh;
	}

	@Override
	public boolean equals(Object other)
	{
		//等级相同，功能相同，所有TargetCondition相同且数量相同
		if (other instanceof DanAttriHolder)
			if (this.level == ((DanAttriHolder) other).level)
				return DanAttribute.FuncEquals(this.danAttribute, ((DanAttriHolder) other).danAttribute);

		return false;
	}
}
