package com.kodgames.combat.record;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author marui
 */
public class EventTargetRecord
{
	private int targetIndex;
	private int eventType;
	private int testType;
	private int value;
	private int value1;
	private List<ActionRecord> passiveActionRecords = new ArrayList<>();

	public int getTargetIndex()
	{
		return targetIndex;
	}

	public void setTargetIndex(int targetIndex)
	{
		this.targetIndex = targetIndex;
	}

	public int getEventType()
	{
		return eventType;
	}

	public void setEventType(int eventType)
	{
		this.eventType = eventType;
	}

	public int getTestType()
	{
		return testType;
	}

	public void setTestType(int testType)
	{
		this.testType = testType;
	}

	public int getValue()
	{
		return value;
	}

	public void setValue(int value)
	{
		this.value = value;
	}

	public int getValue1()
	{
		return value1;
	}

	public void setValue1(int value1)
	{
		this.value1 = value1;
	}

	public List<ActionRecord> getPassiveActionRecords()
	{
		return passiveActionRecords;
	}

	public void addPassiveActionRecord(ActionRecord record, boolean check)
	{
		// Skip empty action.
		if (check && record.getActionId() == 0 && record.getRecordCount() == 0)
		{
			return;
		}

		this.passiveActionRecords.add(record);
	}

	public com.kodgames.corgi.protocol.CombatData.EventTargetRecord toProtoBufClass()
	{
		com.kodgames.corgi.protocol.CombatData.EventTargetRecord.Builder builder = com.kodgames.corgi.protocol.CombatData.EventTargetRecord.newBuilder();
		builder.setTargetIndex(targetIndex);
		if(testType != 0)
		{
			builder.setTestType(testType);
		}
		if(value != 0)
		{
			builder.setValue(value);
		}
		if(value1 != 0)
		{
			builder.setValue1(value1);
		}
		builder.setEventType(eventType);
		for (ActionRecord actionRecord : passiveActionRecords)
		{
			builder.addPassiveActionRecords(actionRecord.toProtoBufClass());
		}

		return builder.build();
	}

	public EventTargetRecord fromProtoBufClass(com.kodgames.corgi.protocol.CombatData.EventTargetRecord eventTargetRecord)
	{
		targetIndex = eventTargetRecord.getTargetIndex();
		testType = eventTargetRecord.getTestType();
		value = eventTargetRecord.getValue();
		value1 = eventTargetRecord.getValue1();
		eventType = eventTargetRecord.getEventType();
		for (com.kodgames.corgi.protocol.CombatData.ActionRecord actionRecord : eventTargetRecord.getPassiveActionRecordsList())
		{
			passiveActionRecords.add(new ActionRecord().fromProtoBufClass(actionRecord));
		}

		return this;
	}
}
