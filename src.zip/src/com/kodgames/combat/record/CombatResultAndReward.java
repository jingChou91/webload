package com.kodgames.combat.record;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.kodgames.combat.record.BattleRecord;
import com.kodgames.corgi.protocol.CombatData;
import com.kodgames.gamedata.player.costandreward.Reward;

public class CombatResultAndReward
{

	private LinkedList<BattleRecord> battleRecords = new LinkedList<BattleRecord>();
	private LinkedList<Reward> rewards = new LinkedList<Reward>();
	private Reward dungeonReward = new Reward();
	private Reward dungeonReward_ExpSilver = new Reward();
	private List<Integer> starCompleteIndexs = new ArrayList<Integer>();
	private Reward firstpassReward = new Reward();
	private int starNum;
	private int combatNumMax;
	private int combatNumReal;
	//是否是剧情战斗
	private boolean isPlotBattle = false;

	public CombatResultAndReward()
	{

	}

	public CombatResultAndReward(LinkedList<BattleRecord> battleRecords, LinkedList<Reward> rewards,
			Reward dungeonReward, Reward dungeonReward_ExpSilver, List<Integer> starCompleteIndexs, Reward firstpassReward,
			int starNum)
	{
		super();
		this.battleRecords = battleRecords;
		this.rewards = rewards;
		this.dungeonReward = dungeonReward;
		this.dungeonReward_ExpSilver = dungeonReward_ExpSilver;
		this.starCompleteIndexs = starCompleteIndexs;
		this.firstpassReward = firstpassReward;
		this.starNum = starNum;
	}

	public void addBattleRecords(BattleRecord battleRecord)
	{
		battleRecords.add(battleRecord);
	}

	public void addRewards(Reward reward)
	{
		rewards.add(reward);
	}

	public boolean getIsPlotBattle()
	{
		return this.isPlotBattle;
	}

	public void setIsPlotBattle(boolean isPlotBattle)
	{
		this.isPlotBattle = isPlotBattle;
	}

	public int getStarNum()
	{
		return starNum;
	}

	public void setStarNum(int starNum)
	{
		this.starNum = starNum;
	}

	public Reward getDungeonReward()
	{
		return dungeonReward;
	}

	public void setDungeonReward(Reward dungeonReward)
	{
		this.dungeonReward = dungeonReward;
	}

	public Reward getFirstpassReward()
	{
		return firstpassReward;
	}

	public void setFirstpassReward(Reward firstpassReward)
	{
		this.firstpassReward = firstpassReward;
	}

	public LinkedList<BattleRecord> getBattleRecords()
	{
		return battleRecords;
	}

	public void setBattleRecords(LinkedList<BattleRecord> battleRecords)
	{
		this.battleRecords = battleRecords;
	}

	public LinkedList<Reward> getRewards()
	{
		return rewards;
	}

	public void setRewards(LinkedList<Reward> rewards)
	{
		this.rewards = rewards;
	}

	public Reward getDungeonReward_ExpSilver()
	{
		return dungeonReward_ExpSilver;
	}

	public void setDungeonReward_ExpSilver(Reward dungeonReward_ExpSilver)
	{
		this.dungeonReward_ExpSilver = dungeonReward_ExpSilver;
	}

	public List<Integer> getStarCompleteIndexs()
	{
		return starCompleteIndexs;
	}

	public void setStarCompleteIndexs(List<Integer> starCompleteIndexs)
	{
		this.starCompleteIndexs = starCompleteIndexs;
	}

	public int getCombatNumMax()
	{
		return combatNumMax;
	}

	public void setCombatNumMax(int combatNumMax)
	{
		this.combatNumMax = combatNumMax;
	}

	public int getCombatNumReal()
	{
		return combatNumReal;
	}

	public void setCombatNumReal(int combatNumReal)
	{
		this.combatNumReal = combatNumReal;
	}

	public CombatData.CombatResultAndReward toProtobuf()
	{
		CombatData.CombatResultAndReward.Builder combatResultAndRewardBuilder
				= CombatData.CombatResultAndReward.newBuilder();

		for (BattleRecord battleRecord : battleRecords)
		{
			combatResultAndRewardBuilder.addBattleRecords(battleRecord.toProtoBufClass());
		}

		for (Reward reward : rewards)
		{
			combatResultAndRewardBuilder.addRewards(reward.toProtobuf());
		}

		for (int index : starCompleteIndexs)
		{
			combatResultAndRewardBuilder.addStarCompleteIndexs(index);
		}

		combatResultAndRewardBuilder.setIsPlotBattle(this.isPlotBattle);
		combatResultAndRewardBuilder.setDungeonReward(dungeonReward.toProtobuf());
		combatResultAndRewardBuilder.setDungeonRewardExpSilver(dungeonReward_ExpSilver.toProtobuf());
		combatResultAndRewardBuilder.setFirstpassReward(firstpassReward.toProtobuf());
		combatResultAndRewardBuilder.setCombatNumMax(this.combatNumMax);
		combatResultAndRewardBuilder.setCombatNumReal(this.combatNumReal);
		return combatResultAndRewardBuilder.build();
	}

	public com.kodgames.combat.record.CombatResultAndReward fromProtobuf(CombatData.CombatResultAndReward result)
	{
		for (com.kodgames.corgi.protocol.CombatData.BattleRecord a : result.getBattleRecordsList())
		{
			BattleRecord battleRecord = new BattleRecord();
			battleRecord.fromProtoBufClass(a);
			this.battleRecords.add(battleRecord);
		}

		for (com.kodgames.corgi.protocol.CommonProtocols.Reward tmp : result.getRewardsList())
		{
			Reward reward = new Reward();
			this.rewards.add(reward.fromProtobuf(tmp));
		}

		for (int index : result.getStarCompleteIndexsList())
		{
			this.starCompleteIndexs.add(index);
		}

		this.isPlotBattle = result.getIsPlotBattle();
		this.dungeonReward = new Reward().fromProtobuf(result.getDungeonReward());
		this.dungeonReward_ExpSilver = new Reward().fromProtobuf(result.getDungeonRewardExpSilver());
		this.firstpassReward = new Reward().fromProtobuf(result.getFirstpassReward());
		this.combatNumMax = result.getCombatNumMax();
		this.combatNumReal = result.getCombatNumReal();

		return this;
	}
}
