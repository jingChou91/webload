/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.record;

/**
 * 
 * @author sonilics
 */
public class Attribute {
	private int type = 0;
	private double value = 0;

	public Attribute() {
	}
	
	public Attribute(int type, double value) {
		this.type = type;
		this.value = value;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public double getValue() {
		return this.value;
	}

	public void setValue(double value) {
		this.value = value;
	}
	
	public Attribute copy()
	{
		Attribute attr = new Attribute();
		attr.type = this.type;
		attr.value = this.value;
		return attr;
	}

	public Attribute fromProtobuf(com.kodgames.corgi.protocol.CommonProtocols.Attribute protocol) {
		this.type = protocol.getType();
		this.value = protocol.getValue();
		return this;
	}

	public com.kodgames.corgi.protocol.CommonProtocols.Attribute toProtobuf() {
		com.kodgames.corgi.protocol.CommonProtocols.Attribute.Builder builder = com.kodgames.corgi.protocol.CommonProtocols.Attribute
				.newBuilder();

		builder.setType(this.type);
		builder.setValue(this.value);

		return builder.build();
	}
}
