/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.record;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author koduser
 */
public class ModifierSet
{
	private List<Modifier> modifiers = new ArrayList<>();
	
	public void addModifier(Modifier modifier)
	{
		modifiers.add(modifier);
	}
	
	public List<Modifier> getModifierSet()
	{
		return modifiers;
	}
	
	public com.kodgames.corgi.protocol.CombatData.ModifierSet toProtoBufClass()
	{
		com.kodgames.corgi.protocol.CombatData.ModifierSet.Builder builder = com.kodgames.corgi.protocol.CombatData.ModifierSet.newBuilder();
		for(Modifier m : modifiers)
		{
			builder.addModifiers(m.toProtoBufClass());
		}

		return builder.build();
	}

	public ModifierSet fromProtoBufClass(com.kodgames.corgi.protocol.CombatData.ModifierSet protocol)
	{
		modifiers.clear();
		
		for(com.kodgames.corgi.protocol.CombatData.Modifier m : protocol.getModifiersList())
		{
			Modifier mDate = new Modifier(m.getType(), m.getAbilityType(), m.getValue());
			modifiers.add(mDate);
		}
		
		return this;
	}
}
