/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.record;

import ClientServerCommon.SkillConfig;

/**
 *
 * @author sonilics
 */
public class SkillData
{
	private int id;
	private int level;

	public SkillData()
	{
	}

	public SkillData(int id, int level)
	{
		this.id = id;
		this.level = level;
	}

	public int getResourceId()
	{
		return id;
	}

	//添加了组合技之后，skillID与CombatTurnID不再唯一对应。不能够在根据skillId直接查找CombatTurnID
	public int getCombatTurnID(ClientServerCommon.ConfigDatabase cfgDb)
	{
		//如果是普通技能，直接返回技能Id
		SkillConfig.CompositeSkillInfo compositeSkillInfo = GetCompositeSkillInfo(cfgDb);
		//注意当组合技等级为0时，compositeSkillInfo也为null
		if (compositeSkillInfo == null)
			return id;

		//如果是组合技，则返回与等级对应的CombatTurn ID.
		return compositeSkillInfo.get_combatTurnId();
	}

	public boolean isCompositeSkill(ClientServerCommon.ConfigDatabase cfgDb)
	{
		SkillConfig.Skill skillCfg = cfgDb.get_SkillConfig().GetSkillById(id);
		if (skillCfg == null)
			return false;

		return skillCfg.get_type() == ClientServerCommon.CombatTurn._Type.CompositeSkill;
	}

	//根据等级获取组合技ID
	public int getCompositeCombatTurnID(ClientServerCommon.ConfigDatabase cfgDb)
	{
		return getCombatTurnID(cfgDb);
	}

	public int getLevel()
	{
		return level;
	}

	public SkillData copy()
	{
		SkillData skillData = new SkillData();
		skillData.id = this.id;
		skillData.level = this.level;
		return skillData;
	}

	public SkillConfig.CompositeSkillInfo GetCompositeSkillInfo(ClientServerCommon.ConfigDatabase configDB)
	{
		SkillConfig.Skill skillCfg = configDB.get_SkillConfig().GetSkillById(id);
		if (skillCfg == null)
			return null;

		if (skillCfg.get_type() != ClientServerCommon.CombatTurn._Type.CompositeSkill)
			return null;

		return skillCfg.GetCompositeSkillInfoByLevel(level);
	}

	public com.kodgames.corgi.protocol.CombatData.SkillData toProtoBufClass()
	{
		com.kodgames.corgi.protocol.CombatData.SkillData.Builder builder = com.kodgames.corgi.protocol.CombatData.SkillData.newBuilder();
		builder.setId(id);
		builder.setLevel(level);

		return builder.build();
	}

	public SkillData fromProtoBufClass(com.kodgames.corgi.protocol.CombatData.SkillData protocol)
	{
		id = protocol.getId();
		level = protocol.getLevel();

		return this;
	}
}
