package com.kodgames.combat.record;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author marui
 */
public class ActionRecord
{
	private int actionId = 0;
	private int srcAvatarIndex = -1;
	private List<Integer> targetAvatarIndices = new ArrayList<>();
	private List<EventRecord> eventRecords = new LinkedList<>();
	private TurnRecord parent = null;
	
	public ActionRecord()
	{
		
	}
	
	public ActionRecord(TurnRecord parent)
	{
		this.parent = parent;
	}
	
	public TurnRecord getParent()
	{
		return parent;
	}
	
	public int getActionId()
	{
		return actionId;
	}
	
	public List<EventRecord> getEventRecords()
	{
		return this.eventRecords;
	}

	public void setActionId(int actionId)
	{
		this.actionId = actionId;
	}

//	public int getSrcAvatarIndex()
//	{
//		return srcAvatarIndex;
//	}

	public void setSrcAvatarIndex(int srcAvatarIndex)
	{
		this.srcAvatarIndex = srcAvatarIndex;
	}

//	public List<Integer> getTargetAvatarIndices()
//	{
//		return targetAvatarIndices;
//	}

	public void addTargetAvatarIndex(int targetAvatarIndex)
	{
		if(targetAvatarIndices.contains(targetAvatarIndex))
		{
			return;
		}
		
		targetAvatarIndices.add(targetAvatarIndex);
	}

	public void clearTargetAvatarIndex()
	{
		targetAvatarIndices.clear();
	}

	public void addRecord(EventRecord record, boolean check)
	{
		eventRecords.add(record);
	}

	public int getRecordCount()
	{
		return eventRecords.size();
	}

	public com.kodgames.corgi.protocol.CombatData.ActionRecord toProtoBufClass()
	{
		com.kodgames.corgi.protocol.CombatData.ActionRecord.Builder builder = com.kodgames.corgi.protocol.CombatData.ActionRecord.newBuilder();
		if(actionId != 0)
		{
			builder.setActionId(actionId);
		}
		
		builder.setSrcAvatarIndex(srcAvatarIndex);

		for (Integer targetAvatarIndex : targetAvatarIndices)
		{
			builder.addTargetAvatarIndeices(targetAvatarIndex);
		}

		for (EventRecord eventRecord : eventRecords)
		{
			builder.addEventRecords(eventRecord.toProtoBufClass());
		}

		return builder.build();
	}

	public ActionRecord fromProtoBufClass(com.kodgames.corgi.protocol.CombatData.ActionRecord actionRecord)
	{
		actionId = actionRecord.getActionId();
		srcAvatarIndex = actionRecord.getSrcAvatarIndex();

		for (Integer targetAvatarIndex : actionRecord.getTargetAvatarIndeicesList())
		{
			targetAvatarIndices.add(targetAvatarIndex);
		}

		for (com.kodgames.corgi.protocol.CombatData.EventRecord eventRecord : actionRecord.getEventRecordsList())
		{
			this.eventRecords.add(new EventRecord(this).fromProtoBufClass(eventRecord));
		}

		return this;
	}
}
