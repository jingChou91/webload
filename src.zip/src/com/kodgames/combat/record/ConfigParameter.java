/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.record;

public class ConfigParameter
{
	public String Name;
	public String Value;

	public com.kodgames.corgi.protocol.CombatData.ConfigParameter toProtoBufClass()
	{
		com.kodgames.corgi.protocol.CombatData.ConfigParameter.Builder builder = com.kodgames.corgi.protocol.CombatData.ConfigParameter.newBuilder();
		builder.setName(Name);
		builder.setValue(Value);

		return builder.build();
	}

	public ConfigParameter fromProtoBufClass(com.kodgames.corgi.protocol.CombatData.ConfigParameter protocol)
	{
		this.Name = protocol.getName();
		this.Value = protocol.getValue();

		return this;
	}
}
