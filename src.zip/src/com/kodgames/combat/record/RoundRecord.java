package com.kodgames.combat.record;

import ClientServerCommon._CombatRoundType;
import java.util.LinkedList;
import java.util.List;

public class RoundRecord
{
	private int roundType = _CombatRoundType.Unknown;
	private int teamIndex = 0;
	private int rowIndex = 0;
	private int roundIndex = 0;
	private List<TurnRecord> turnRecords = new LinkedList<>();
	private List<ConfigParameter> roundParameters = new LinkedList<ConfigParameter>();

	public int getRoundType()
	{
		return roundType;
	}

	public void setRoundType(int roundType)
	{
		this.roundType = roundType;
	}

	public int getRoundIndex()
	{
		return this.roundIndex;
	}

	public void setRoundIndex(int roundIndex)
	{
		this.roundIndex = roundIndex;
	}

	public int getTeamIndex()
	{
		return this.teamIndex;
	}

	public void setTeamIndex(int teamIndex)
	{
		this.teamIndex = teamIndex;
	}

	public int getRowIndex()
	{
		return this.rowIndex;
	}

	public void setRowIndex(int rowIndex)
	{
		this.rowIndex = rowIndex;
	}

	public List<TurnRecord> getTurnRecords()
	{
		return this.turnRecords;
	}

	public void addRecord(TurnRecord record, boolean check)
	{
		// Skip empty turn.
		if (check && record.getRecordCount() == 0)
		{
			return;
		}

		turnRecords.add(record);
	}

	public com.kodgames.corgi.protocol.CombatData.RoundRecord toProtoBufClass()
	{
		com.kodgames.corgi.protocol.CombatData.RoundRecord.Builder builder = com.kodgames.corgi.protocol.CombatData.RoundRecord.newBuilder();
		builder.setRoundType(roundType);
		builder.setTeamIndex(teamIndex);
		builder.setRowIndex(rowIndex);
		builder.setRoundIndex(roundIndex);
		
		for (TurnRecord turnRecord : turnRecords)
		{
			builder.addTurnRecords(turnRecord.toProtoBufClass());
		}
		
		for(ConfigParameter configParameter:roundParameters)
		{
			builder.addCustomRoundParameters(configParameter.toProtoBufClass());
		}

		return builder.build();
	}

	public RoundRecord fromProtoBufClass(com.kodgames.corgi.protocol.CombatData.RoundRecord protocol)
	{
		this.roundType = protocol.getRoundType();
		this.teamIndex = protocol.getTeamIndex();
		this.rowIndex = protocol.getRowIndex();
		this.roundIndex = protocol.getRoundIndex();
		
		this.turnRecords.clear();
		for (com.kodgames.corgi.protocol.CombatData.TurnRecord turnRecord : protocol.getTurnRecordsList())
		{
			turnRecords.add(new TurnRecord().fromProtoBufClass(turnRecord));
		}
		
		this.roundParameters.clear();
		for(com.kodgames.corgi.protocol.CombatData.ConfigParameter configParameter:protocol.getCustomRoundParametersList())
		{
			this.roundParameters.add(new ConfigParameter().fromProtoBufClass(configParameter));
		}

		return this;
	}
}
