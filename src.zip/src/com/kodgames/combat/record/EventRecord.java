package com.kodgames.combat.record;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author marui
 */
public class EventRecord
{
	private int eventIndex;
	private List<EventTargetRecord> eventTargetRecords = new LinkedList<>();
	private ActionRecord parent = null;

	public EventRecord(ActionRecord parent)
	{
		this.parent = parent;
	}

	public ActionRecord getParent()
	{
		return parent;
	}

	public void addRecord(EventTargetRecord record, boolean check)
	{
		eventTargetRecords.add(record);
	}

	public List<EventTargetRecord> GetEventTargetRecords()
	{
		return eventTargetRecords;
	}

	public int getEventIndex()
	{
		return eventIndex;
	}

	public void setEventIndex(int eventIndex)
	{
		this.eventIndex = eventIndex;
	}

	public com.kodgames.corgi.protocol.CombatData.EventRecord toProtoBufClass()
	{
		com.kodgames.corgi.protocol.CombatData.EventRecord.Builder builder = com.kodgames.corgi.protocol.CombatData.EventRecord.newBuilder();
		builder.setEventIdx(eventIndex);
		for (EventTargetRecord eventTargetRecord : eventTargetRecords)
		{
			builder.addEventTargetRecords(eventTargetRecord.toProtoBufClass());
		}
		return builder.build();
	}

	public EventRecord fromProtoBufClass(com.kodgames.corgi.protocol.CombatData.EventRecord eventRecord)
	{
		eventIndex = eventRecord.getEventIdx();
		for (com.kodgames.corgi.protocol.CombatData.EventTargetRecord eventTargetRecord : eventRecord.getEventTargetRecordsList())
		{
			this.eventTargetRecords.add(new EventTargetRecord().fromProtoBufClass(eventTargetRecord));
		}

		return this;
	}
}
