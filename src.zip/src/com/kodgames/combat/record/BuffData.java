/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.record;

/**
 *
 * @author koduser
 */
public class BuffData
{
	private int instId;
	private int buffId;
	
	public BuffData()
	{
	}

	public BuffData(int instId, int buffId)
	{
		this.instId = instId;
		this.buffId = buffId;
	}

	public int getInstId()
	{
		return instId;
	}

	public void setInstId(int instId)
	{
		this.instId = instId;
	}

	public int getBuffId()
	{
		return buffId;
	}

	public void setBuffId(int buffId)
	{
		this.buffId = buffId;
	}
	
	public BuffData copy()
	{
		BuffData buffData = new BuffData();
		buffData.buffId = this.buffId;
		buffData.instId = this.instId;
		return buffData;
	}

	public com.kodgames.corgi.protocol.CombatData.BuffData toProtoBufClass()
	{
		com.kodgames.corgi.protocol.CombatData.BuffData.Builder builder = com.kodgames.corgi.protocol.CombatData.BuffData.newBuilder();
		builder.setInstId(instId);
		builder.setBuffId(buffId);

		return builder.build();
	}

	public BuffData fromProtoBufClass(com.kodgames.corgi.protocol.CombatData.BuffData protocol)
	{
		instId = protocol.getInstId();
		buffId = protocol.getBuffId();

		return this;
	}
}
