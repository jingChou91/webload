package com.kodgames.combat.record;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author marui
 */
public class BattleRecord
{
	private int sceneId = 0;
	// 一次战斗的最大次数，只客户端有用
	private int maxRecordCount = 1;
	private CombatRecord combatRecord = new CombatRecord();
	private List<TeamRecord> teamRecords = new ArrayList<>();

	public int getSceneId()
	{
		return sceneId;
	}

	public void setSceneId(int mapID)
	{
		this.sceneId = mapID;
	}
	
	public int getMaxRecordCount()
	{
		return maxRecordCount;
	}

	public void setMaxRecordCount(int maxRecordCount)
	{
		this.maxRecordCount = maxRecordCount;
	}

	public CombatRecord getCombatRecord()
	{
		return combatRecord;
	}

	public List<TeamRecord> getTeamRecords()
	{
		return teamRecords;
	}

//	public TeamRecord getTeamResultByIndex(int index)
//	{
//		if (index >= this.teamRecords.size())
//		{
//			return null;
//		}
//		return teamRecords.get(index);
//	}
//
//	public TeamResult getTeamResultByAvatarID(int avatarID)
//	{
//		// int index = 0;
//		// for (Player player : this.players) {
//		// if (player.getAvatarData().getAvatarID() == avatarID)
//		// return this.results.get(index);
//		//
//		// ++index;
//		// }
//
//		return null;
//	}
//
//	public AvatarResult getAvatarResultByAvatarID(int avatarID)
//	{
//		// int index = 0;
//		// for (Player player : this.players) {
//		// if (player.getAvatarData().getAvatarID() == avatarID)
//		// return this.results.get(index).getAvatarResults().get(0);
//		//
//		// ++index;
//		// }
//
//		return null;
//
//	}
	public com.kodgames.corgi.protocol.CombatData.BattleRecord.Builder toProtoBufClass()
	{
		com.kodgames.corgi.protocol.CombatData.BattleRecord.Builder builder = com.kodgames.corgi.protocol.CombatData.BattleRecord.newBuilder();
		builder.setSceneId(sceneId);
		builder.setMaxRecordCount(maxRecordCount);

		if (combatRecord != null)
		{
			builder.setCombatRecord(combatRecord.toProtoBufClass());
		}

		for (TeamRecord teamRecord : teamRecords)
		{
			builder.addTeamRecord(teamRecord.toProtoBufClass());
		}
		return builder;
	}

	public void fromProtoBufClass(com.kodgames.corgi.protocol.CombatData.BattleRecord combatResult)
	{
		sceneId = combatResult.getSceneId();
		maxRecordCount = combatResult.getMaxRecordCount();
		if (combatResult.hasCombatRecord())
		{
			combatRecord = new CombatRecord().fromProtoBufClass(combatResult.getCombatRecord());
		}

		for (com.kodgames.corgi.protocol.CombatData.TeamRecord teamResult : combatResult.getTeamRecordList())
		{
			teamRecords.add(new TeamRecord().fromProtoBufClass(teamResult));
		}
	}
}
