/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.record;

/**
 *
 * @author sonilics
 */
public class LevelAttribute
{
	int level;
	int experience;

	public LevelAttribute()
	{
		level = 1;
		experience = 0;
	}

	public LevelAttribute(int level, int experience)
	{
		this.level = level;
		this.experience = experience;
	}

	public int getLevel()
	{
		return this.level;
	}

	public void setLevel(int level)
	{
		this.level = level;
	}

	public int getExperience()
	{
		return this.experience;
	}

	public void setExperience(int experinece)
	{
		this.experience = experinece;
	}

	public LevelAttribute copy()
	{
		LevelAttribute attr = new LevelAttribute();
		attr.level = this.level;
		attr.experience = this.experience;
		return attr;
	}

	public LevelAttribute fromProtobuf(com.kodgames.corgi.protocol.CommonProtocols.LevelAttrib protocol)
	{
		this.level = protocol.getLevel();
		this.experience = protocol.getExperience();
		return this;
	}

	public com.kodgames.corgi.protocol.CommonProtocols.LevelAttrib toProtobuf()
	{
		com.kodgames.corgi.protocol.CommonProtocols.LevelAttrib.Builder protoBuilder = com.kodgames.corgi.protocol.CommonProtocols.LevelAttrib.newBuilder();
		protoBuilder.setLevel(level);
		protoBuilder.setExperience(experience);
		return protoBuilder.build();
	}
}
