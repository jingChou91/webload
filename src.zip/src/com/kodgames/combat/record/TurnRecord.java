package com.kodgames.combat.record;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author marui
 */
public class TurnRecord
{
	private int avatarIndex = -1;
	private List<ActionRecord> actionRecords = new LinkedList<>();
	private int turnId = 0 ;
	
	public TurnRecord()
	{
	}
	
	public TurnRecord(int turnId)
	{
		this.turnId = turnId;
	}
	
	public int getTurnId()
	{
		return turnId;
	}
	
	public int getAvatarIndex()
	{
		return avatarIndex;
	}

	public void setAvatarIndex(int avatarIndex)
	{
		this.avatarIndex = avatarIndex;
	}

	public void addRecord(ActionRecord record, boolean check)
	{
		// Skip empty action.
		if (check && record.getActionId() == 0 && record.getRecordCount() == 0)
		{
			return;
		}

		actionRecords.add(record);
	}
	
	public List<ActionRecord> getActionRecords()
	{
		return this.actionRecords;
	}

	public int getRecordCount()
	{
		return actionRecords.size();
	}

	public com.kodgames.corgi.protocol.CombatData.TurnRecord toProtoBufClass()
	{
		com.kodgames.corgi.protocol.CombatData.TurnRecord.Builder builder = com.kodgames.corgi.protocol.CombatData.TurnRecord.newBuilder();
		builder.setAvatarIndex(avatarIndex);
		for (ActionRecord actionRecord : actionRecords)
		{
			builder.addActionRecords(actionRecord.toProtoBufClass());
		}

		return builder.build();
	}

	public TurnRecord fromProtoBufClass(com.kodgames.corgi.protocol.CombatData.TurnRecord turnRecord)
	{
		avatarIndex = turnRecord.getAvatarIndex();
		for (com.kodgames.corgi.protocol.CombatData.ActionRecord actionRecord : turnRecord.getActionRecordsList())
		{
			actionRecords.add(new ActionRecord(this).fromProtoBufClass(actionRecord));
		}

		return this;
	}
}
