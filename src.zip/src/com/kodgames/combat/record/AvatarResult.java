/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.combat.record;

/**
 *
 * @author sonilics
 */
public class AvatarResult
{

	int avatarIndex = -1;
	int teamIndex = -1;
	int maxHP = 0;
	int leftHP = 0;
	ActionRecord endAction = null; // End action can be null
	CombatAvatarData combatAvatarData;

	public int getAvatarIndex()
	{
		return avatarIndex;
	}

	public void setAvatarIndex(int avatarIndex)
	{
		this.avatarIndex = avatarIndex;
	}

	public int getTeamIndex()
	{
		return teamIndex;
	}

	public void setTeamIndex(int teamIndex)
	{
		this.teamIndex = teamIndex;
	}

	public int getMaxHP()
	{
		return maxHP;
	}

	public void setMaxHP(int maxHP)
	{
		this.maxHP = maxHP;
	}

	public int getLeftHP()
	{
		return leftHP;
	}

	public void setLeftHP(int leftHP)
	{
		this.leftHP = leftHP;
	}

	public ActionRecord getEndAction()
	{
		return endAction;
	}

	public void setEndAction(ActionRecord endAction)
	{
		this.endAction = endAction;
	}

	public CombatAvatarData getCombatAvatarData()
	{
		return combatAvatarData;
	}

	public void setCombatAvatarData(CombatAvatarData combatAvatarData)
	{
		this.combatAvatarData = combatAvatarData;
	}

	public com.kodgames.corgi.protocol.CombatData.AvatarResult toProtoBufClass()
	{
		com.kodgames.corgi.protocol.CombatData.AvatarResult.Builder builder = com.kodgames.corgi.protocol.CombatData.AvatarResult.newBuilder();
		builder.setAvatarIndex(avatarIndex);
		builder.setTeamIndex(teamIndex);
		builder.setLeftHP(this.leftHP);
		builder.setMaxHP(this.maxHP);
		builder.setCombatAvatarData(combatAvatarData.toProtobuf());
		if (endAction != null)
		{
			builder.setEndAction(endAction.toProtoBufClass());
		}

		return builder.build();
	}

	public AvatarResult fromProtoBufClass(com.kodgames.corgi.protocol.CombatData.AvatarResult protocol)
	{
		avatarIndex = protocol.getAvatarIndex();
		teamIndex = protocol.getTeamIndex();
		leftHP = protocol.getLeftHP();
		maxHP = protocol.getMaxHP();
		combatAvatarData = new CombatAvatarData().fromProtobuf(protocol.getCombatAvatarData());
		if (protocol.hasEndAction())
		{
			endAction = new ActionRecord().fromProtoBufClass(protocol.getEndAction());
		}

		return this;
	}
}
