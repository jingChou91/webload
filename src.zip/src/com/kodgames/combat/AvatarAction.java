package com.kodgames.combat;

public class AvatarAction {
	
	public enum _Type{
		CounterAttackStart(0),
		AddBuff(1),
		SPDamage(2),
		Damage(3),
		ThrowDamage(4),
		BuffTimeUp(5),
		DeleteBuff(6),
		EnterState(7),
		LeaveState(8),
		SkillStart(9),
		CompositeSkillStart(10),
		SuperSkillEffect(11),
		SetSkillPower(12),
		EnterBattleGround(13),
		Heal(14);
		
		_Type(int r) {
			
		
		}
	}
	
	
}
