/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.protocol;

/**
 *
 * @author Elvin
 */
public class ServerProtocols extends Protocols
{

	// Manage Protocols for Servers 0x0001xxxx, xxxx start from 0x5000
	final public static int P_MANAGE_SERVER_LOGIN_REQ = 0x00015001;
	final public static int P_MANAGE_SERVER_LOGIN_RES = 0x00015002;
	final public static int P_MANAGE_SERVER_LOGIN_CONFIRM = 0x00015003;
	final public static int P_MANAGE_SERVER_SYNC = 0x00015004;
	final public static int P_MANAGE_SERVER_RELOAD_CONFIG_REQ = 0x00015005;
	final public static int P_MANAGE_SERVER_RELOAD_CONFIG_RES = 0x00015006;

	// AuthServer Protocols for Servers 0x0002xxxx, xxxx start from 0x5000
	final public static int P_AUTH_SERVER_QUERY_TOKEN_REQ = 0x00025001;
	final public static int P_AUTH_SERVER_QUERY_TOKEN_RES = 0x00025002;

	// Interface Protocols for Servers 0x0003xxxx, xxxx start from 0x5000
	final public static int P_INTERFACE_CLIENT_TO_OTHERSERVER = 0x00035001;
	final public static int P_INTERFACE_OTHERSERVER_TO_CLIENT = 0x00035002;
	final public static int P_INTERFACE_KICK_PLAYER = 0x00035003;

	// Game Protocols for Servers 0x0004xxxx, xxxx start from 0x5000
	final public static int P_GAME_CLIENT_DISCONNECT_REQ = 0x00045001;

	// Function Protocols for Servers 0x0007xxxx xxxx start from 0x5000
	final public static int P_FUNCTION_PLAYER_ONLINE_STATUS_REQ = 0x00075001;
	final public static int P_FUNCTION_CHAT_REQ = 0x00075002;

	// SYNC protocols that all server can use.
	final public static int P_SYNC_XG_QUERY_PLAYERINFO_REQ = 0x00085001;
	final public static int P_SYNC_GX_QUERY_PLAYERINFO_RES = -0x00085002;
	final public static int P_SYNC_XG_SET_COST_AND_REWARD_REQ = 0x00085003;
	final public static int P_SYNC_GX_SET_COST_AND_REWARD_RES = -0x00085004;

	final public static int P_ALL_QUERY_COMBAT_RESULT_REQ = 0x00085005;
	final public static int P_ALL_QUERY_COMBAT_RESULT_RES = 0x00085006;
	final public static int P_ALL_UPDATE_REMOTE_PLAYER_RECORD_REQ = 0x00085007;

	final public static int P_SYNC_XF_QUERY_INFO_FOR_GAMESERVER_REQ = 0x00085009;
	final public static int P_SYNC_FX_QUERY_INFO_FOR_GAMESERVER_RES = -0x00085010;

	final public static int P_GAME_GF_PVE_RANK_ADD_RECORD_REQ = 0x00085013;
	final public static int P_GAME_FG_PVE_RANK_ADD_RECORD_RES = 0x00085014;

	final public static int P_SYNC_XG_CHANGE_LEVEL_REQ = 0x00085016;
	final public static int P_SYNC_GX_CHANGE_LEVEL_RES = -0x00085017;

	final public static int P_ALL_CLIENT_XML_VERSION_REQ = 0x00085020;

	final public static int P_ALL_XML_RELOAD_REQ = 0x00085028;
	final public static int P_ALL_XML_RELOAD_RES = 0x00085029;

	final public static int P_XF_SEND_EMAIL_REQ = 0x00085030;

	final public static int P_ALL_UPDATE_REMOTE_PLAYER_RANK_RECORD_REQ = 0x00085032;
	// final public static int P_ALL_UPDATE_REMOTE_PLAYER_RANK_RECORD_RES =
	// 0x00085033;

	final public static int P_XF_SEND_GROUP_EMAIL_REQ = 0x00085034;

	final public static int P_SYNC_XF_CHANGE_RANK_REQ = 0x00085036;
	final public static int P_SYNC_FX_CHANGE_RANK_RES = -0x00085037;

	final public static int P_SYNC_XF_ONLINE_PLAYER_NUM_REQ = 0x00085038;
	final public static int P_SYNC_FX_ONLINE_PLAYER_NUM_RES = -0x00085039;

	final public static int P_SYNC_XF_QUERY_PVE_RANK_REQ = 0x00085042;
	final public static int P_SYNC_FX_QUERY_PVE_RANK_RES = -0x00085043;

	final public static int P_XF_SET_COST_AND_REWARD_REQ = 0x00085044;

	// syncclient test
	final public static int P_SYNC_XF_SEND_SYNCLIENT_TESTCASE_REQ = 0x00085046;
	final public static int P_SYNC_FX_SEND_SYNCLIENT_TESTCASE_RES = -0x00085047;

	final public static int P_FG_READY_TEST = 0x00085048;
	final public static int P_GF_NOTIFY = 0x00085049;

	final public static int P_XF_SET_PLAYERNAME_REQ = 0x00085050;

	final public static int P_XF_SEND_SYSTEM_MSG_REQ = 0x00085052;

	final public static int P_SYNC_XF_RESET_PLAYER_INFO_REQ = 0x00085058;
	final public static int P_SYNC_FX_RESET_PLAYER_INFO_RES = -0x00085059;

	final public static int P_GF_SEND_EMAIL_REWARD_REQ = 0x00085062;
	final public static int P_FG_PROCESS_QUEST_EVENT_REQ = 0x00085064;

	final public static int P_SYNC_XG_RESET_OPEN_DUNGEON_REQ = 0x00085066;
	final public static int P_SYNC_GX_RESET_OPEN_DUNGEON_RES = -0x00085067;

	final public static int P_SYNC_GF_FIRST_GET_REQ = 0x00085068;
	final public static int P_SYNC_FG_FIRST_GET_RES = -0x00085069;

	final public static int P_PG_CHANNEL_PURCHASE_REQ = 0x00085070;
	final public static int P_GP_CHANNEL_PURCHASE_RES = -0x00085071;

	final public static int P_XG_LOADPLAYER_ROBOT_REQ = 0x00085072;

	final public static int P_SYNC_GF_FETCH_PLAYER_NAMES_REQ = 0x00085073;
	final public static int P_SYNC_FG_FETCH_PLAYER_NAMES_RES = -0x00085074;

	final public static int P_GF_ACCUMULATE_REQ = 0x00085075;

	final public static int P_SYNC_XF_QUERY_PLAYERID_REQ = 0x00085076;
	final public static int P_SYNC_FX_QUEYR_PLAYERID_RES = -0x00085077;

	final public static int P_SYNC_GA_QUERY_UDID_FROM_ACCOUNT_REQ = 0x00085078;
	final public static int P_SYNC_AG_QUERY_UDID_FROM_ACCOUNT_RES = -0x00085079;

	final public static int P_SYNC_XG_CHECK_COST_ONLY_REQ = 0x00085080;
	final public static int P_SYNC_GX_CHECK_COST_ONLY_RES = -0x00085081;

	final public static int P_XG_SEND_MINE_REWARD_BUFFS_REQ = 0x00085082;

	final public static int P_SYNC_XF_CHECK_PLAYERID_REQ = 0x00085084;
	final public static int P_SYNC_FX_CHECK_PLAYERID_RES = -0x00085085;

	final public static int P_SYNC_GF_ISFROZEN_REQ = 0x00085087;
	final public static int P_SYNC_FG_ISFROZEN_RES = -0x00085088;

	final public static int P_SYNC_XG_CHECK_GUID_REQ = 0x00085089;
	final public static int P_SYNC_GX_CHECK_GUID_RES = -0x00085090;

	final public static int P_GF_SIXDOORS_CONTRIBUTION_NOTIFY = 0x00085091;
	final public static int P_SYNC_XG_EFUN_PLAYER_INFO_REQ = 0x00085092;
	final public static int P_SYNC_GX_EFUN_PLAYER_INFO_RES = -0x00085093;

	final public static int P_SYNC_PG_PING_REQ = 0x00085121;
	final public static int P_SYNC_GP_PING_RES = -0x00085122;

	final public static int P_XG_SEND_BATCH_REWARD_EMAIL_REQ = 0x00085221;
	final public static int P_GX_SEND_BATCH_REWARD_EMAIL_RES = 0x00085222;

	final public static int P_XG_SEND_GROUP_REWARD_EMAIL_REQ = 0x00085321;

	final public static int P_SYNC_XG_FUZZY_QUERY_PLAYER_NAME_REQ = 0x00085421;
	final public static int P_SYNC_GX_FUZZY_QUERY_PLAYER_NAME_RES = 0x00085422;

	final public static int P_ALL_SHUTDOWN_REQ = 0x00085521;

	final public static int P_SYNE_XG_QUERY_ORDER_INFO_REQ = 0x00085621;
	final public static int P_SYNE_GX_QUERY_ORDER_INFO_RES = 0x00085622;

	final public static int P_SYNC_XG_QUERY_ARENA_RANK_REQ = 0x00085721;
	final public static int P_SYNC_GX_QUERY_ARENA_RANK_RES = 0x00085722;

	final public static int P_SYNC_XG_QUERY_COMBAT_TEST_REQ = 0x00085821;
	final public static int P_SYNC_GX_QUERY_COMBAT_TEST_RES = 0x00085822;

	final public static int P_SYNC_XG_ADD_MONTH_CARD_REQ = 0x00085921;
	final public static int P_SYNC_GX_ADD_MONTH_CARD_RES = 0x00085922;

	final public static int P_XG_GAG_REQ = 0x00086021;

	final public static int P_SYNC_XG_QUERY_GAG_REQ = 0x00086221;
	final public static int P_SYNC_GX_QUERY_GAG_RES = 0x00086222;

	final public static int P_SYNC_XG_QUERY_MF_RANK_REQ = 0x00086321;
	final public static int P_SYNC_GX_QUERY_MF_RANK_RES = 0x00086322;

	final public static int P_SYNC_XG_QUERY_EMAIL_GROUP_INFO_REQ = 0x00086421;
	final public static int P_SYNC_GX_QUERY_EMAIL_GROUP_INFO_RES = -0x00086422;

	final public static int P_SYNC_XG_QUERY_PRIVATE_EMAIL_INFO_REQ = 0x00086521;
	final public static int P_SYNC_GX_QUERY_PRIVATE_EMAIL_INFO_RES = -0x00086522;

	final public static int P_SYNC_XG_DELETE_EMAIL_REQ = 0x00086621;
	final public static int P_SYNC_GX_DELETE_EMAIL_RES = 0x00086622;

	final public static int P_XG_FREEZE_REQ = 0x00086721;

	final public static int P_SYNC_XG_QUERY_FREEZE_REQ = 0x00086821;
	final public static int P_SYNC_GX_QUERY_FREEZE_RES = 0x00086822;

	final public static int P_SYNC_XG_GUILD_QUERY_REQ = 0x00086921;
	final public static int P_SYNC_GX_GUILD_QUERY_RES = 0x00086922;

	final public static int P_SYNC_XG_GUILD_QUERY_LIST_REQ = 0x00087021;
	final public static int P_SYNC_GX_GUILD_QUERY_LIST_RES = 0x00087022;

	final public static int P_SYNC_XG_GUILD_SET_REQ = 0x00087121;
	final public static int P_SYNC_GX_GUILD_SET_RES = 0x00087122;

	final public static int P_SYNC_XG_GUILD_QUERY_ID_BY_NAME_REQ = 0x00087221;
	final public static int P_SYNC_GX_GUILD_QUERY_ID_BY_NAME_RES = 0x00087222;
	// -------error
	// code------------------------------------------------------------------

	// the error code for game protocols 0x0004xxxx, xxxx start from 0x5000

	// the error code for trade protocols 0x0005xxxx, xxxx start from 0x5000
	final public static int E_MANAGE_LOGIN_SUCCESS = 0X00015001;
	final public static int E_MANAGE_LOGIN_FAILED = 0X00015002;
	final public static int E_MANAGE_RELOAD_CONFIG_SUCCESS = 0X00015001;
	final public static int E_MANAGE_RELOAD_CONFIG_FAILED = 0X00015002;

	// the error code for combat protocols 0x0006xxxx, xxxx start from 0x5000

	// the error code for general Server protocols 0
	final public static int E_SYNC_QUERY_PLAYERINFO_SUCCESS = 0x00085001;
	final public static int E_SYNC_QUERY_PLAYERINFO_FAILED = 0x00085002;

	final public static int E_SYNC_XG_SET_COST_AND_REWARD_SUCCESS = 0x00085003;
	final public static int E_SYNC_GX_SET_COST_AND_REWARD_FAILED = 0x00085004;

	final public static int E_ALL_QUERY_COMBAT_RESULT_SUCCESS = 0x00085005;

	final public static int E_SYNC_QUERY_INFO_FOR_GAMESERVER_SUCCESS = 0x00085008;
	final public static int E_SYNC_QUERY_INFO_FOR_GAMESERVER_FAILED = 0x00085009;

	final public static int E_SYNC_CHANGE_LEVEL_SUCCESS = 0x00085014;
	final public static int E_SYNC_CHANGE_LEVEL_FAILED = 0x00085015;

	// final public static int E_ALL_BUY_CONSIGNMENT_SUCCESS =0x00085016;
	// final public static int E_ALL_BUY_CONSIGNMENT_FAILED =0x00085017;

	final public static int E_GAME_CONFIG_ERROR = 0x00085032;

	final public static int E_SYNC_CHANGE_RANK_SUCCESS = 0x00085033;
	final public static int E_SYNC_CHANGE_RANK_FAILED = 0x00085034;

	final public static int E_SYNC_ONLINE_PLAYER_NUM_SUCCESS = 0x00085035;
	final public static int E_SYNC_ONLINE_PLAYER_NUM_FAILED = 0x00085036;

	final public static int E_SYNC_FG_QUERY_PVE_RANK_SUCCESS = 0x00085042;

	final public static int E_SYNC_SET_COST_AND_REWARD_NOTENOUGH = 0x00085044;

	final public static int E_FUNCTION_SYNC_XF_RESET_PLAYER_INFO_SUCCESS = 0x00085053;
	final public static int E_FUNCTION_SYNC_XF_RESET_PLAYER_INFO_FAILED = 0x00085054;

	final public static int E_SYNC_RESET_OPEN_DUNGEON_SUCCESS = 0x00085059;
	final public static int E_SYNC_RESET_OPEN_DUNGEON_FAILED = 0x00085060;

	final public static int E_FUNCTION_SYNC_XF_FIRST_GET_SUCCESS = 0x00085061;
	final public static int E_FUNCTION_SYNC_XF_FIRST_GET_FAILED = 0x00085062;
	final public static int E_FUNCTION_SYNC_XF_FIRST_GET_FAILED_ALREADY_GET = 0x00085063;

	final public static int E_SYNC_FETCH_PLAYERNAMES_FOR_ROBOT_SUCCESS = 0x00085064;

	final public static int E_SYNC_QUERY_PLAYERID_SUCCESS = 0x00085065;
	final public static int E_SYNC_QUERY_PLAYERID_FAILED = 0x00085066;

	final public static int E_FUNCTION_FX_CHECK_PLAYERID_SUCCESS = 0x00085073;
	final public static int E_FUNCTION_FX_CHECK_PLAYERID_FAILD = 0x00085074;

	final public static int E_SYNC_GX_CHECK_GUID_SUCCESS = 0x00085075;
	final public static int E_SYNC_GX_CHECK_GUID_FAILD = 0x00085076;

	final public static int E_SYNC_GF_ISFROZEN_SUCCESS = 0x00085077;
	final public static int E_SYNC_GF_ISFROZEN_FAILED = 0x00085078;
	final public static int E_AUTH_QUERY_UDID_SUCCESS = 0x00085079;
	final public static int E_AUTH_QUERY_UDID_FAILED = 0x00085080;

	final public static int E_ALL_GX_CHECK_COST_ONLY_SUCCESS = 0x00085081;
	final public static int E_ALL_GX_CHECK_COST_ONLY_FAILED = 0x00085082;
	final public static int E_ALL_GX_CHECK_COST_ONLY_NOTENOUGH = 0x00085083;

	final public static int E_FUNCTION_SYNC_GF_ISFROZEN_SUCCESS = 0x00085084;
	final public static int E_FUNCTION_SYNC_GF_ISFROZEN_FAILED = 0x00085085;

	final public static int E_GX_SEND_BATCH_REWARD_EMAIL_SUCCESS = 0x00085086;
	final public static int E_GX_SEND_BATCH_REWARD_EMAIL_FAILED = 0x00085087;

	final public static int E_SYNC_XG_FUZZY_QUERY_PLAYER_NAME_SUCCESS = 0x00085088;
	final public static int E_SYNC_XG_FUZZY_QUERY_PLAYER_NAME_FAILED = 0x00085089;

	final public static int E_SYNC_CHANNEL_PURCHASE_SUCCESS = 0x00085092;
	final public static int E_SYNC_CHANNEL_PURCHASE_FAILED = 0x00085093;

	final public static int E_SYNE_XG_QUERY_ORDER_INFO_SUCCESS = 0X00085094;
	final public static int E_SYNE_XG_QUERY_ORDER_INFO_FAILED = 0X00085095;

	final public static int E_SYNC_XG_QUERY_ARENA_RANK_SUCCESS = 0x00085096;
	final public static int E_SYNC_GX_QUERY_ARENA_RANK_FAILED = 0x00085097;

	final public static int E_SYNC_XG_QUERY_COMBAT_TEST_SUCCESS = 0x00085098;
	final public static int E_SYNC_XG_QUERY_COMBAT_TEST_FAILED = 0x00085099;

	final public static int E_SYNC_XG_ADD_MONTH_CARD_SUCCESS = 0x00086010;
	final public static int E_SYNC_XG_ADD_MONTH_CARD_FAILED = 0x00086011;
	final public static int E_SYNC_XG_ADD_MONTH_CARD_FAILED_MAX_NUM = 0x00086012;

	final public static int E_SYNC_XG_GAG_SUCCESS = 0x00087010;
	final public static int E_SYNC_XG_GAG_FAILED = 0x00087011;

	final public static int E_SYNC_XG_QUERY_GAG_SUCCESS = 0x00088010;
	final public static int E_SYNC_XG_QUERY_GAG_FAILED = 0x00088011;

	final public static int E_SYNC_XG_QUERY_MF_RANK_SUCCESS = 0x00089010;
	final public static int E_SYNC_GX_QUERY_MF_RANK_FAILED = 0x00089011;

	final public static int E_SYNC_XG_QUERY_PRIVATE_EMAILINFO_SUCCESS = 0x00090010;
	final public static int E_SYNC_XG_QUERY_PRIVATE_EMAILINFO_FAILED = 0x00090011;

	final public static int E_SYNC_XG_QUERY_EMAIL_GROUP_INFO_SUCCESS = 0x00091010;
	final public static int E_SYNC_XG_QUERY_EMAIL_GROUP_INFO_FAILED = 0x00091011;

	final public static int E_SYNC_XG_DELETE_EMAIL_SUCCESS = 0x00092010;
	final public static int E_SYNC_XG_DELETE_EMAIL_FAILED = 0x00092011;

	final public static int E_SYNC_XG_FREEZE_SUCCESS = 0x93010;
	final public static int E_SYNC_XG_FREEZE_FAILED = 0x93011;
	final public static int E_SYNC_XG_FREEZE_FAILED_FREEZE_TIME_VALID = 0x93012;

	final public static int E_SYNC_XG_QUERY_FREEZE_SUCCESS = 0x94010;
	final public static int E_SYNC_XG_QUERY_FREEZE_FAILED = 0x94011;

	final public static int E_SYNC_XG_SUCCESS = 0x95010;
	final public static int E_SYNC_XG_FAILED = 0x95011;
	
	final public static int E_SYNC_XG_EFUN_PLAYER_INFO_SUCCESS = 0x96010;
	final public static int E_SYNC_XG_EFUN_PLAYER_INFO_FAILE = 0x96011;
}
