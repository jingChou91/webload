/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kodgames.corgi.protocol;

import org.jboss.netty.buffer.ChannelBuffer;

import com.google.protobuf.MessageLite;

/**
 * 
 * @author mrui
 */
public class Protocol
{
	private int id;
	private MessageLite protoBufMessage;
	private ChannelBuffer buffer;

	public Protocol(int id)
	{
		this.id = id;
	}

	/**
	 * @return the id
	 */
	public int getId()
	{
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id)
	{
		this.id = id;
	}

	/**
	 * @return the protoBufMessage
	 */
	public MessageLite getProtoBufMessage()
	{
		return protoBufMessage;
	}

	/**
	 * @param protoBufMessage the protoBufMessage to set
	 */
	public void setProtoBufMessage(MessageLite protoBufMessage)
	{
		this.protoBufMessage = protoBufMessage;
	}

	/**
	 * @return the buffer
	 */
	public ChannelBuffer getBuffer()
	{
		return buffer;
	}

	/**
	 * @param buffer the buffer to set
	 */
	public void setBuffer(ChannelBuffer buffer)
	{
		this.buffer = buffer;
	}

}
