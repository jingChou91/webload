/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.protocol;

/**
 * 
 * @author mrui
 */
public class Protocols
{
	// ServerType 0xxxxx0000
	final public static int SERVER_TYPE_MANAGE = 0x00010000;
	final public static int SERVER_TYPE_AUTH = 0x00020000;
	final public static int SERVER_TYPE_GAME = 0x00030000;
	final public static int SERVER_TYPE_PURCHASE = 0x00040000;

	// Protocol Type 0xxxxx0000
	final public static int PROTOCOL_TYPE_MANAGE = 0x00010000;
	final public static int PROTOCOL_TYPE_AUTH = 0x00020000;
	final public static int PROTOCOL_TYPE_GAME = 0x00030000;

	public static int type(Integer id)
	{
		return 0xffff0000 & id;
	}

	public static int idWithoutType(Integer id)
	{
		return 0x0000ffff & id;
	}
}
