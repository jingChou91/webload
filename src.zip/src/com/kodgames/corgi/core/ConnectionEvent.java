/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kodgames.corgi.core;

import org.jboss.netty.channel.Channel;
import java.net.SocketAddress;
import org.jboss.netty.channel.ChannelEvent;
import org.jboss.netty.channel.ChannelFuture;
import static org.jboss.netty.channel.Channels.*;

/**
 *
 * @author marui
 */
public class ConnectionEvent implements ChannelEvent{

    /**
     * @return the status
     */
    public STATUS getStatus() {
        return status;
    }
    public static enum STATUS{
        CONNECTED,CLOSED
    }

    private final Channel channel;
    private final SocketAddress remoteAddress;
    private final int serverID;
    private final CorgiUID clientUID;
    private STATUS status;

    public ConnectionEvent(Channel channel, SocketAddress remoteAddress, int serverID, STATUS status ){
        this.channel = channel;
        if (remoteAddress != null) {
            this.remoteAddress = remoteAddress;
        } else {
            this.remoteAddress = channel.getRemoteAddress();
        }
        this.serverID = serverID;
        this.status = status;
        this.clientUID = new CorgiUID();
    }

    public ConnectionEvent(Channel channel, SocketAddress remoteAddress, CorgiUID clientUID, STATUS status ){
        this.channel = channel;
        if (remoteAddress != null) {
            this.remoteAddress = remoteAddress;
        } else {
            this.remoteAddress = channel.getRemoteAddress();
        }
        this.clientUID = clientUID;
        this.status = status;
        this.serverID = 0;
    }

    public Channel getChannel() {
        return channel;
    }

    public ChannelFuture getFuture() {
        return succeededFuture(getChannel());
    }

    public SocketAddress getRemoteAddress() {
        return remoteAddress;
    }

    public int getRemoteServerID(){
        return serverID;
    }

	public CorgiUID getClientUID()
	{
		return this.clientUID;
	}

    @Override
    public String toString() {
        return getChannel().toString() + " ServerID of Remote Server:" + serverID;
    }
}
