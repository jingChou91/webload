/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kodgames.corgi.core;

import java.net.SocketAddress;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.MessageEvent;

/**
 *
 * @author mrui
 */
public class ServerNode extends CommunicateNode{
    private int serverID;
    public ServerNode( MessageEvent evt ){
        super(evt);
    }

    public ServerNode(Channel channel, SocketAddress remoteAddress, int remoteServerID){
    	super(channel,remoteAddress);
        this.serverID = remoteServerID;
    }

    /**
     * @return the serverID
     */
    public int getServerID() {
        return serverID;
    }

    /**
     * @param serverID the serverID to set
     */
    public void setServerID(int serverID) {
        this.serverID = serverID;
    }
}
