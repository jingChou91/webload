/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kodgames.corgi.core;

import java.util.concurrent.atomic.AtomicInteger;

import com.kodgames.corgi.protocol.CommonProtocols.DeviceInfo;

/**
 *
 * @author marui
 */
public class CorgiUID {
    private int playerId;
    private int sequenceId;
    private long loginTime;//玩家上次登录时间
    private String ipMessage;
    private DeviceInfo deviceInfo;
    private String clientVersion;
    private String channelUniqueId;
    private String channelUserName;
    private String marketChannelId;//畅游推广渠道ID
    private int serverXmlVersion;//GameServer当前版本号
    private int channelId;

	/**
	 * 获取 serverXmlVersion
	 * @return 返回 serverXmlVersion
	 */
	public int getServerXmlVersion()
	{
		return serverXmlVersion;
	}

	/**
	 * 设置 serverXmlVersion
	 * @param 对serverXmlVersion进行赋值
	 */
	public void setServerXmlVersion(int serverXmlVersion)
	{
		this.serverXmlVersion = serverXmlVersion;
	}

	private static AtomicInteger seqId=new AtomicInteger(1);
    public static int getNextSeqId()
    {
    	return seqId.incrementAndGet();
    }
    
	public String getChannelUniqueId() {
		return channelUniqueId;
	}

	public void setChannelUniqueId(String channelUniqueId) {
		this.channelUniqueId = channelUniqueId;
	}

    public int getPlayerID() {
		return playerId;
	}

	public void setPlayerID(int playerId) {
		this.playerId = playerId;
	}

	public String getIpMessage() {
		return ipMessage;
	}

	public void setIpMessage(String ipMessage) {
		this.ipMessage = ipMessage;
	}

	public DeviceInfo getDeviceInfo() {
		return deviceInfo;
	}

	public void setDeviceInfo(DeviceInfo deviceInfo) {
		this.deviceInfo = deviceInfo;
	}
	
    public String getChannelUserName() {
		return channelUserName;
	}

	public void setChannelUserName(String channelUserName) {
		this.channelUserName = channelUserName;
	}
	
	public String getClientVersion()
	{
		return clientVersion;
	}

	public void setClientVersion(String clientVersion)
	{
		this.clientVersion = clientVersion;
	}

	public CorgiUID()
	{

    }

    public long getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(long loginTime)
	{
		this.loginTime = loginTime;
	}

	public String getMarketChannelId()
	{
		return marketChannelId;
	}

	public void setMarketChannelId(String marketChannelId)
	{
		this.marketChannelId = marketChannelId;
	}

	public int getChannelId() 
	{
		return channelId;
	}

	public void setChannelId(int channelId)
	{
		this.channelId = channelId;
	}

	/**
     * @return the sequenceID
     */
    public int getSequenceId()
    {
        return sequenceId;
    }

    /**
     * @param sequenceID the sequenceID to set
     */
    public void setSequenceID(int sequenceId)
    {
        this.sequenceId = sequenceId;
    }    
}
