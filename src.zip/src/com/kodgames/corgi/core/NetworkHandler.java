/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.core;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.Channel;
import java.util.Arrays;

import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffers;
import org.jboss.netty.channel.ChannelDownstreamHandler;
import org.jboss.netty.channel.ChannelEvent;
import org.jboss.netty.channel.ChannelFutureListener;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.ChannelStateEvent;
import org.jboss.netty.channel.Channels;
import org.jboss.netty.channel.ChildChannelStateEvent;
import org.jboss.netty.channel.MessageEvent;
import org.jboss.netty.channel.SimpleChannelUpstreamHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 *
 * @author mrui
 */
public class NetworkHandler extends SimpleChannelUpstreamHandler implements ChannelDownstreamHandler {

	private static final Logger logger = LoggerFactory.getLogger(NetworkHandler.class);
	
    public static final short NETWORK_MSG_DATA = 1;
    public static final short NETWORK_MSG_EXCHANGE_INFO = 2;
    public static final short NETWORK_MSG_DATA_LZO = 3;
                                                        
    public static final int MAX_COMPRESS_MESSAGE_SIZE = 2048000;
    public static final int MAX_UNCOMPRESS_MESSAGE_SIZE = 2097152;// 1024*1024*2
    
    public static final int CLIENTHELP_MAX_COMPRESS_MESSAGE_SIZE = 203216; 
    public static final int ClIENTHELP_MAX_UNCOMPRESS_MESSAGE_SIZE = 2097152;
    
    protected final Transmitter transmitter;
    protected ServerNode remoteServerNode;
    protected ClientNode remoteClientNode;
	static private long appSendSize = 0;
	static private long appReceiveSize = 0;
    static private int[] compressDict = new int[MAX_UNCOMPRESS_MESSAGE_SIZE];

    public NetworkHandler(Transmitter transmitter) {
        this.transmitter = transmitter;
    }

    /**
     * Invoked when a message object (e.g: {@link ChannelBuffer}) was received
     * from a remote peer.
     */
    @Override
    public void messageReceived(
            ChannelHandlerContext ctx, MessageEvent evt) throws Exception {
        MessageEvent me = (MessageEvent) evt;
        if (!(me.getMessage() instanceof ChannelBuffer)) {
            ctx.sendUpstream(evt);
            return;
        }

        ChannelBuffer buffer = (ChannelBuffer) me.getMessage();
		NetworkHandler.appReceiveSize += buffer.readableBytes();

        short messageType = buffer.readShort();
        int length = buffer.readInt();

        if (messageType == NETWORK_MSG_DATA) {
            Channels.fireMessageReceived(ctx, buffer, me.getRemoteAddress());//buffer.readBytes(length), me.getRemoteAddress());
        }else if (messageType == NETWORK_MSG_DATA_LZO){
            //TODO:
            ChannelBuffer uncompressBuffer = LZOUncompressData( buffer );
            if ( uncompressBuffer == ChannelBuffers.EMPTY_BUFFER ){
                //TODO:
                if ( remoteServerNode != null )
                {
                    throw new UnsupportedOperationException( "Not supported empty uncompress buffer. remote serverID:" + remoteServerNode.getServerID());
                }                
                else
                {
                    throw new UnsupportedOperationException( "Not supported empty uncompress buffer.");
                }
            } 
            Channels.fireMessageReceived(ctx, uncompressBuffer, me.getRemoteAddress()); 
        }else if (messageType == NETWORK_MSG_EXCHANGE_INFO) {
            if (length != 4) {
                //TODO:
                return;
            }
            int serverID = buffer.readInt();
            transmitter.addServerNode(serverID, ctx.getChannel(), me.getRemoteAddress());
           	ctx.sendUpstream(new ConnectionEvent(ctx.getChannel(), me.getRemoteAddress(), serverID, ConnectionEvent.STATUS.CONNECTED));

        } else {
            //TODO:
            throw new UnsupportedOperationException("Not supported message type yet.");
        }
    }
	
	@Override
    public void channelConnected(
            ChannelHandlerContext ctx, ChannelStateEvent evt) throws Exception {
    }


    /**
     * Invoked when a child {@link Channel} was closed.
     * (e.g. the accepted connection was closed)
     */
    @Override
    public void childChannelClosed(
            ChannelHandlerContext ctx, ChildChannelStateEvent e) throws Exception {
        if (getRemoteServerNode() != null) {
            transmitter.removeServerNode(getRemoteServerNode().getServerID());
            ctx.sendUpstream(new ConnectionEvent(ctx.getChannel(), getRemoteServerNode().getRemoteAddress(), getRemoteServerNode().getServerID(), ConnectionEvent.STATUS.CLOSED));
        } else {
            ctx.sendUpstream(e);
        }
    }

    /**
     * Invoked when a {@link Channel} was disconnected from its remote peer.
     */
    @Override
    public void channelDisconnected(
            ChannelHandlerContext ctx, ChannelStateEvent e) throws Exception {
        if (getRemoteServerNode() != null && getRemoteServerNode().getChannel() == e.getChannel()) 
        {
            transmitter.removeServerNode(getRemoteServerNode().getServerID());
            ctx.sendUpstream(new ConnectionEvent(ctx.getChannel(), getRemoteServerNode().getRemoteAddress(), getRemoteServerNode().getServerID(), ConnectionEvent.STATUS.CLOSED));
        } 
        else if (remoteClientNode != null && remoteClientNode.getChannel() == e.getChannel())
        {
        	remoteClientNode.getChannel().close().addListener(ChannelFutureListener.CLOSE);
        	ctx.sendUpstream(new ConnectionEvent(ctx.getChannel(), remoteClientNode.getRemoteAddress(), remoteClientNode.getClientUID(), ConnectionEvent.STATUS.CLOSED));
        }
        else
        {
            ctx.sendUpstream(e);
        }
    }
    
    private ChannelBuffer LZOCompressData(ChannelBuffer body){
        byte[] compressMsg = new byte[body.readableBytes() + 255];
        org.jvcompress.util.MInt outL = new org.jvcompress.util.MInt();
        int r = 0;
        //need to compare the performance among GC, memory pool and synchronized
        //need to confirm the size of dict
        //TODO:marui 
        synchronized (compressDict) {
            Arrays.fill(compressDict, 0);
            r = org.jvcompress.lzo.MiniLZO.lzo1x_1_compress(body.array(), body.arrayOffset() + body.readerIndex(), body.readableBytes(), compressMsg, outL, compressDict);
        }
        if ( r == 0){
            return ChannelBuffers.wrappedBuffer(compressMsg, 0, outL.v);
        }else{
            return ChannelBuffers.EMPTY_BUFFER;
        }     
    }
    
    private ChannelBuffer LZOUncompressData(ChannelBuffer body){
        byte[] uncompressMsg = new byte[MAX_UNCOMPRESS_MESSAGE_SIZE];
        org.jvcompress.util.MInt outL=new org.jvcompress.util.MInt(); 
        int r = 0;
        if ( body.hasArray() )
        {
            r = org.jvcompress.lzo.MiniLZO.lzo1x_decompress(body.array(), body.arrayOffset() + body.readerIndex(), body.readableBytes(), uncompressMsg, outL);
        }
        else
        {
            ByteBuffer singleBuffer = body.toByteBuffer();
            r = org.jvcompress.lzo.MiniLZO.lzo1x_decompress(singleBuffer.array(), singleBuffer.arrayOffset(), singleBuffer.capacity(), uncompressMsg, outL);           
        }
        if ( r == 0){
            return ChannelBuffers.wrappedBuffer(uncompressMsg,0, outL.v);
        }else{
            return ChannelBuffers.EMPTY_BUFFER;
        }     
    }

    public void handleDownstream(ChannelHandlerContext ctx, ChannelEvent evt) throws Exception {
        if (!(evt instanceof MessageEvent)) {
            ctx.sendDownstream(evt);
            return;
        }

        MessageEvent me = (MessageEvent) evt;
        if (!(me.getMessage() instanceof ChannelBuffer)) {
            ctx.sendDownstream(evt);
            return;
        }

        short msgType = NETWORK_MSG_DATA;
        ChannelBuffer body = (ChannelBuffer) me.getMessage();
        if((body.readableBytes()+6) > ClIENTHELP_MAX_UNCOMPRESS_MESSAGE_SIZE)
        {
        	logger.error("Uncompress message size is too big. size:{}", body.readableBytes()+6);
        	return;
        }
        
        logger.debug("before compress body size {}", body.readableBytes());
        if ( remoteClientNode != null && body.readableBytes() > 1024)
        {
            ChannelBuffer compressBody = LZOCompressData(body);
            if ( compressBody != ChannelBuffers.EMPTY_BUFFER )
            {
                body = compressBody;
                msgType = NETWORK_MSG_DATA_LZO;
            }
        }
        else if (remoteServerNode != null && body.readableBytes() > 65535)
        {
            ChannelBuffer compressBody = LZOCompressData(body);
            if ( compressBody != ChannelBuffers.EMPTY_BUFFER ){
                body = compressBody;
                msgType = NETWORK_MSG_DATA_LZO;
            }
        }
        
        ChannelBuffer header =
                evt.getChannel().getConfig().getBufferFactory().getBuffer(ByteOrder.BIG_ENDIAN, 6);
        header.writeShort(msgType);
        header.writeInt(body.readableBytes());
        
        if ( header.readableBytes() + body.readableBytes() > MAX_UNCOMPRESS_MESSAGE_SIZE )
        {
            if (remoteServerNode != null)
            {
            	logger.error("Compress message size is too big. size: {}  remote serverID:{}",header.readableBytes() + body.readableBytes(), remoteServerNode.getServerID());
            }
            else
            {
            	logger.error("Compress message size is too big. size: {}", header.readableBytes() + body.readableBytes());
            }
            return;
        }

        Channels.write(ctx, evt.getFuture(), ChannelBuffers.wrappedBuffer(header, body), me.getRemoteAddress());
		
		NetworkHandler.appSendSize += header.readableBytes() + body.readableBytes();
		
		
		if(body.readableBytes() > CLIENTHELP_MAX_COMPRESS_MESSAGE_SIZE)
		{
			logger.error("compress message size is too big. size:{}", body.readableBytes()+6);
		}
		logger.debug("after compress handleDownStream size {} header {} body {}", NetworkHandler.appSendSize, header.readableBytes(), body.readableBytes());
    }

    /**
     * @return the remoteServerNode
     */
    public ServerNode getRemoteServerNode() {
        return remoteServerNode;
    }

    /**
     * @param remoteServerNode the remoteServerNode to set
     */
    public void setRemoteServerNode(ServerNode remoteServerNode) {
        this.remoteServerNode = remoteServerNode;
    }

    /**
     * @return the remoteClientNode
     */
    public ClientNode getRemoteClientNode() {
        return remoteClientNode;
    }

    /**
     * @param remoteClientNode the remoteClientNode to set
     */
    public void setRemoteClientNode(ClientNode remoteClientNode) {
        this.remoteClientNode = remoteClientNode;
    }

	static public long getAppReceiveSize()
	{
		return NetworkHandler.appReceiveSize;
	}

	static public long getAppSendSize()
	{
		return NetworkHandler.appSendSize;
	}
    
//    public static void main(String[] args) throws Exception{
//        /*
//        byte[] kk = new byte[1024];
//        ChannelBuffer cb = ChannelBuffers.wrappedBuffer(kk, 10, 200);
//        cb.readByte();
//        Console.WriteLine(cb.arrayOffset() + "  " + cb.readerIndex() + "  " + cb.readableBytes());
//        * 
//        */
//        byte[] kk = new byte[65535];
//        for ( int i = 0; i < 65535; i++)
//        {
//            kk[i] = 1;
//        }
//        kk[0] = 2;
//        kk[65533] = 3;
//        kk[65534] = 4;
//        ChannelBuffer cb = ChannelBuffers.wrappedBuffer(kk, 0, 655);
//        
//        NetworkHandler nh = new NetworkHandler(null);
//        
//        ChannelBuffer compressedBuffer = nh.LZOCompressData(cb);
//        ChannelBuffer adfaf = ChannelBuffers.wrappedBuffer(cb, compressedBuffer);
//        adfaf.readerIndex(655);
//         
//        ChannelBuffer uncompressedBuffer =  nh.LZOUncompressData(adfaf);
//        byte[] dd = uncompressedBuffer.array();
//        int kd = dd.length;
//        
//        
//        
//    }
}
