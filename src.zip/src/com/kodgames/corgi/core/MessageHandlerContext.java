/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kodgames.corgi.core;

import java.net.SocketAddress;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.MessageHandler.HandlerAction;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.BaseServerData;

/**
 *
 * @author mrui
 */
public class MessageHandlerContext {
    private static final Logger logger = LoggerFactory.getLogger(MessageHandlerContext.class);
    private int protocolID;
    private MessageHandler handler;
    private MessageHandlerContext prev;
    private MessageHandlerContext next;

    /**
     * @return the handler
     */
    public MessageHandler getHandler() {
        return handler;
    }

    /**
     * @param handler the handler to set
     */
    public void setHandler(MessageHandler handler) {
        this.handler = handler;
    }

    /**
     * @return the prev
     */
    public MessageHandlerContext getPrev() {
        return prev;
    }

    /**
     * @param prev the prev to set
     */
    public void setPrev(MessageHandlerContext prev) {
        this.prev = prev;
    }

    /**
     * @return the next
     */
    public MessageHandlerContext getNext() {
        return next;
    }

    /**
     * @param next the next to set
     */
    public void setNext(MessageHandlerContext next) {
        this.next = next;
    }

    /**
     * @return the protocolID
     */
    public int getProtocolID() {
        return protocolID;
    }

    /**
     * @param protocolID the protocolID to set
     */
    public void setProtocolID(int protocolID) {
        this.protocolID = protocolID;
    }

    public void sendUpstream(ServerNode sender, Protocol message){
        if ( handler.handleServerMessage(sender, message) == HandlerAction.CONTINUE && next != null){
            next.sendUpstream(sender, message);
        }
    }
    
    public void sendUpstream(ClientNode sender, Protocol message){
    	try
    	{
    		if(sender.getClientUID().getServerXmlVersion() == CfgDB.getVersion() &&  //检测当前版本号是否最新
    				handler.handleClientMessage(sender, message) == HandlerAction.CONTINUE && next != null)
    		{
    			next.sendUpstream(sender, message);
    		}
    		else if(sender.getClientUID().getServerXmlVersion() != CfgDB.getVersion()) // 配置文件过时
    		{
    			// 发送错误码
    			GameProtocolsForClient.ReturnExceptionCallback.Builder builder = GameProtocolsForClient.ReturnExceptionCallback.newBuilder();
    			builder.setExceptionCallback(0);
    			builder.setResult(ClientProtocols.E_COMMON_CONFIG_IS_NOT_LATEST);
    			Protocol protocol = new Protocol(ClientProtocols.P_GC_FC_RETURN_EXCEPTION_CALLBACK);
    			protocol.setProtoBufMessage(builder.build());
    			BaseServerData.transmitter.sendToClient(sender, protocol);
    		}
    	}
    	catch(Exception ex)
		{
			logger.error("{}",ExceptionUtils.getStackTrace(ex));
			//未响应，返回
			GameProtocolsForClient.ReturnExceptionCallback.Builder builder = GameProtocolsForClient.ReturnExceptionCallback.newBuilder();
			builder.setExceptionCallback(handler.getExceptionCallbackForClient());
			builder.setResult(ClientProtocols.E_SERVER_PROC_ERROR);
			Protocol protocol = new Protocol(ClientProtocols.P_GC_FC_RETURN_EXCEPTION_CALLBACK);
			protocol.setProtoBufMessage(builder.build());
			
			handler.getTransmitter().sendToClient(sender, protocol);
		}
    }

    public void sendUpstream(Channel channel, SocketAddress remoteAddress, Protocol message){
        if (handler.handleMessage(channel, remoteAddress, message) == HandlerAction.CONTINUE && next != null ){
            next.sendUpstream(channel, remoteAddress, message);
        }
    }
}
