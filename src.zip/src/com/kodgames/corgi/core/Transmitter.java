/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.core;

import java.net.SocketAddress;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelFuture;
import org.jboss.netty.channel.ChannelFutureListener;
import org.jboss.netty.channel.ChannelHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.MessageLite;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.Protocols;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.ServerDataGS.SessionStatus;
import com.kodgames.corgi.server.manageserver.ManageClientHandler;
import com.kodgames.corgi.server.manageserver.ServerDataMS;
import com.kodgames.corgi.server.manageserver.ServerInfo;

/**
 *
 * @author mrui
 */
public class Transmitter {
	
	private static final Logger logger = LoggerFactory.getLogger(Transmitter.class);
	
	public interface AvatarServer
	{
		public int getDstServerByProtocolID(int playerID, int protocolType );
		public int getDstServerByServerType(int playerID, int serverType);
		public List<ManageClientHandler.InternalServerNode> getDstServersByServerType(int areaID, int serverType);
		public List<ServerInfo> getGameServers(int areaId);
	}
	
    private ConcurrentHashMap<Integer, ServerNode> servers = new ConcurrentHashMap<>();

    private int localServerID = 0;
    private AvatarServer avatarServer;
    
    public void setAvatarServer(AvatarServer avatarServer)
    {
    	this.avatarServer = avatarServer;
    }

    @Deprecated
    public ChannelFuture send(Channel channel,  int protocolID, MessageLite message){
    	Protocol protocol = new Protocol(protocolID);
    	protocol.setProtoBufMessage(message);
        return send(channel, protocol);
    }
    
    @Deprecated
    public ChannelFuture send(Channel channel, Protocol message){
        return channel.write(message);
    }
    

	public void sendAndClose(Channel channel, Protocol message)
	{
		ChannelFuture f = channel.write(message);
		f.addListener(new ChannelFutureListener()
		{
            public void operationComplete(ChannelFuture future) 
            {
                Channel ch = future.getChannel();
                ch.close().addListener(ChannelFutureListener.CLOSE);;
            }
        });
	}
	
	public void sendAndClose(Channel channel,  int protocolID, MessageLite message)
	{
		Protocol protocol = new Protocol(protocolID);
    	protocol.setProtoBufMessage(message);
    	sendAndClose(channel, protocol);
	}
    
    public void sendToServer(ServerNode receiver, Protocol message) {
        send(receiver.getChannel(),message);
    }
    
    public void sendToServer(ServerNode receiver, int protocolID, MessageLite message)
    {
    	Protocol protocol = new Protocol(protocolID);
		protocol.setProtoBufMessage(message);
		sendToServer(receiver, protocol);
    }

	// Auto send the message to the server which the avatar assigned to
	public boolean sendToServer(int serverType, int playerID, int protocolID, MessageLite message) 
	{
		int dstServerID = getDstServerByServerType(playerID, serverType);
		Protocol protocol = new Protocol(protocolID);
		protocol.setProtoBufMessage(message);
		return sendToServer(dstServerID, protocol);
	}
	
	public boolean sendToServer(int remoteServerID, Protocol message)
	{
		ServerNode remoteServerNode = servers.get(remoteServerID);
        
        if (remoteServerNode == null) 
        {
            return false;
        }
        sendToServer(remoteServerNode, message);
        return true;
	}
	
	public void sendToClient(int playerId, Protocol message)
	{
		ServerDataGS.ClientSession session = ServerDataGS.sessions.get(playerId);
        if(null == session || session.getStatus() != SessionStatus.verified_Connected || session.isNormalPlayer() == false)
        {
        	return;
        }
		send(session.getChannel(), message);
	}
	
    public void sendToClient(ClientNode receiver, Protocol message)
    {
		sendToClient(receiver.getClientUID().getPlayerID(), message);
    }
    
    public void sendToClient(ClientNode receiver, int protocolID, MessageLite message)
    {
    	Protocol protocol = new Protocol(protocolID);
		protocol.setProtoBufMessage(message);
		sendToClient(receiver.getClientUID().getPlayerID(), protocol);
    }
    
    public boolean sendToClient(CorgiUID corgiUID, Protocol message)
    {
    	if(corgiUID==null)
    	{
    		logger.warn("remoteClientUID is null : {}",ExceptionUtils.getStackTrace(new Throwable()));
    		return false;
    	}

    	sendToClient(corgiUID.getPlayerID(), message);
    	return true;
    }
    
    public void sendToClients(int areaID, Protocol message)
    {
    	for(Integer playerId : ServerDataGS.sessions.keySet())
    	{
    		sendToClient(playerId, message);
    	}
    }
    
    public boolean closeClientConnection(int playerId){

    	ServerDataGS.ClientSession clientSession = ServerDataGS.sessions.get(playerId);
    	if (clientSession == null) 
    	{
    		return false;
    	}
    	clientSession.getChannel().close();
    	return true;
    }

    public ServerNode addServerNode(int serverID, Channel channel, SocketAddress remoteAddress) {
        ServerNode serverNode = new ServerNode(channel, remoteAddress, serverID);

        servers.put(serverID, serverNode);
        ChannelHandler handler =  channel.getPipeline().get(NetworkHandler.class);
        if ( handler != null ){
            NetworkHandler networkHandler = (NetworkHandler)handler;
            networkHandler.setRemoteServerNode(serverNode);
        }

        handler = channel.getPipeline().get(MessageBaseHandler.class);
        if ( handler != null ){
            MessageBaseHandler messageBaseHandler = (MessageBaseHandler)handler;
            messageBaseHandler.setRemoteServerNode(serverNode);
        }

        return serverNode;
    }

    public void removeServerNode(int serverID) {
        servers.remove(serverID);
    }

    public void addClientNode(CorgiUID clientUID, Channel channel, SocketAddress remoteAddress){
        ClientNode clientNode = new ClientNode(clientUID, channel, remoteAddress);
        channel.setAttachment(clientUID);
        ChannelHandler handler =  channel.getPipeline().get(NetworkHandler.class);
        if ( handler != null ){
            NetworkHandler networkHandler = (NetworkHandler)handler;
            networkHandler.setRemoteClientNode(clientNode);
        }

        handler = channel.getPipeline().get(MessageBaseHandler.class);
        if ( handler != null ){
            MessageBaseHandler messageBaseHandler = (MessageBaseHandler)handler;
            messageBaseHandler.setRemoteClientChannel(channel);
        }
    }

    /**
     * @return the localServerID
     */
    public int getLocalServerID() {
        return localServerID;
    }

    /**
     * @param localServerID the localServerID to set
     */
    public void setLocalServerID(int localServerID) {
        this.localServerID = localServerID;
    }

    @Deprecated
	public void sendToServers(int serverType, Protocol message)
	{
		for(ServerNode serverNode : this.servers.values())
		{
			if(Protocols.type(serverNode.getServerID()) == serverType)
			{
				this.sendToServer(serverNode, message);
			}
		}
	}
	
	public void sendToServerForManager(int serverType, Protocol message ,int areaId)
	{
		for(ServerInfo serverInfo : ServerDataMS.serverSynchronizer.getServers())
		{
			if(serverInfo.isInArea(areaId) && Protocols.type(serverInfo.getId()) == serverType)
			{
				sendToServer(serverInfo.getId(), message);
			}
		}
	}
	
	public int getDstServerByProtocolID(int playerID, int protocolID )
	{
		if( this.avatarServer == null)
		{
			return 0;
		}
		return this.avatarServer.getDstServerByProtocolID(playerID, protocolID);
	}
	public int getDstServerByServerType(int playerID, int serverType)
	{
		if( this.avatarServer == null)
		{
			return 0;
		}
		return this.avatarServer.getDstServerByServerType(playerID, serverType);
	}
	public List<ServerInfo> getGameServers(int areaId)
	{
		return this.avatarServer.getGameServers(areaId);
	}
}
