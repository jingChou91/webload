/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kodgames.corgi.core;

import java.net.SocketAddress;

import org.jboss.netty.channel.Channel;

/**
 *
 * @author mrui
 */
public class ClientNode extends CommunicateNode{
    private CorgiUID clientUID;
    public ClientNode(CorgiUID clientUID, Channel channel, SocketAddress remoteAddress)
    {
    	super(channel,remoteAddress);
        this.clientUID = clientUID;
    }

    /**
     * @return the clientUID
     */
    public CorgiUID getClientUID() {
        return clientUID;
    }

    /**
     * @param clientUID the clientUID to set
     */
    public void setClientUID(CorgiUID clientUID) {
        this.clientUID = clientUID;
    }

}
