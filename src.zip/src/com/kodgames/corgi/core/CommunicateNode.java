/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kodgames.corgi.core;

import java.net.SocketAddress;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.MessageEvent;

/**
 *
 * @author mrui
 */
public abstract class CommunicateNode {
 
    public CommunicateNode( MessageEvent evt )
    {
        channel = evt.getChannel();
        remoteAddress = evt.getRemoteAddress();
    }

    public CommunicateNode(Channel channel, SocketAddress remoteAddress){
        this.channel = channel;
        this.remoteAddress = remoteAddress;
    }

    Channel channel;
    SocketAddress remoteAddress;

    /**
     * @return the channel
     */
    public Channel getChannel() {
        return channel;
    }

    /**
     * @return the remoteAddress
     */
    public SocketAddress getRemoteAddress() {
        return remoteAddress;
    }

}
