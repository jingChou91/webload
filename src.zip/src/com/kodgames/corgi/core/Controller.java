/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kodgames.corgi.core;

import com.google.protobuf.MessageLite;
import com.kodgames.corgi.protocol.Protocol;
import java.net.SocketAddress;
import org.jboss.netty.channel.Channel;

/**
 *
 * @author mrui
 */
public interface Controller {
    //Handler used to process the protocol
    void addHandler(int procotolID, MessageHandlerFactory handlerFactory);
    //one protocolID map a protoBuf message
    void registerMessageLite(int protocolID, MessageLite protoBufMessageLite);
    MessageLite getMesasgeLite(int protocolID);
    void sendUpstream(ServerNode source, Protocol message);
    void sendUpstream(ServerNode source, MessageHandlerContext ctx, Protocol message);
    void sendUpstream(ClientNode source, Protocol message);
    void sendUpstream(ClientNode source, MessageHandlerContext ctx, Protocol message);
    void sendUpstream(Channel channel, SocketAddress remoteAddress, Protocol message);
}
