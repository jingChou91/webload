/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.core;

import java.nio.ByteOrder;

import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.ChannelStateEvent;
import org.jboss.netty.channel.Channels;

import com.kodgames.corgi.server.ServerReconnect;


/**
 *
 * @author Elvin
 */
public class ServerNetworkHandler extends NetworkHandler{
	public ServerNetworkHandler(Transmitter transmitter) {
		super(transmitter);
	}

	@Override
    public void channelConnected(
            ChannelHandlerContext ctx, ChannelStateEvent evt) throws Exception {
        if (transmitter.getLocalServerID() > 0 ) {
        	boolean temp = true;
        	if(ServerReconnect.USE_SERVERS_RECONNECT)
        	{
        		temp = (false==ServerReconnect.getManagerAddr().equals(evt.getChannel().getRemoteAddress().toString()));
        	}
        	if(temp)
        	{
        		//msg type(NETWORK_MSG_EXCHANGE_INFO) + length + local severaccountID
        		// 2 bytes                            + 4 bytes+ 4 bytes
        		ChannelBuffer exchangeInfoMsg =
        				evt.getChannel().getConfig().getBufferFactory().getBuffer(ByteOrder.BIG_ENDIAN, 10);
        		exchangeInfoMsg.writeShort(NETWORK_MSG_EXCHANGE_INFO);
        		exchangeInfoMsg.writeInt(4);
        		exchangeInfoMsg.writeInt(transmitter.getLocalServerID());
        		Channels.write(ctx, Channels.future(evt.getChannel()), exchangeInfoMsg);
        	}
        }
        ctx.sendUpstream(evt);
    }
}
