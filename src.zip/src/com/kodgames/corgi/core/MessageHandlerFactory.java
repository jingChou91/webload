/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kodgames.corgi.core;

/**
 *
 * @author mrui
 */
public interface MessageHandlerFactory {
    MessageHandler getHandler();
}
