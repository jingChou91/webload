/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.core;

import static com.kodgames.corgi.protocol.Protocols.idWithoutType;
import static com.kodgames.corgi.protocol.Protocols.type;

import java.net.SocketAddress;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.jboss.netty.channel.Channel;

import com.google.protobuf.MessageLite;
import com.kodgames.corgi.protocol.Protocol;

/**
 *
 * @author mrui
 */
public class DefaultController implements Controller {

    Map<Integer, MessageHandlerContext> protocolTypeHandlers = new ConcurrentHashMap<>();
    Map<Integer, MessageHandlerContext> handlers = new ConcurrentHashMap<>();
    private Map<Integer,MessageLite> protobufMessages = new ConcurrentHashMap<>();

	protected Map<Integer, MessageHandlerContext> getHandlers()
	{
		return this.handlers;
	}

    //protocolID is comprised of two parts: protocoltype(short) and idwithouttype
    //two types of protocolID:
    // protocoltype != 0  and idwithouttype != 0 
    // protocoltyp != 0 and idwithouttype =0  it means the handler is applied to all the protocols with this type
    public void addHandler(int protocolID, MessageHandlerFactory handlerFactory) {

        //if the protocolID exists, append the new handler at next
        //It must be the first type of protocolID (protocoltype != 0  and idwithouttype != 0 )
        if (handlers.containsKey(protocolID)) {
            MessageHandlerContext ctx = new MessageHandlerContext();
            ctx.setProtocolID(protocolID);
            ctx.setHandler(handlerFactory.getHandler());
            MessageHandlerContext _ctx = handlers.get(protocolID);
            while (_ctx.getNext() != null) {
                _ctx = _ctx.getNext();
            }

            _ctx.setNext(ctx);
            ctx.setPrev(_ctx);
        } else if (type(protocolID) != 0 && idWithoutType(protocolID) != 0) { //the protocolID doesn't exist and it is first type of protocolid
            MessageHandlerContext ctx = new MessageHandlerContext();
            ctx.setProtocolID(protocolID);
            ctx.setHandler(handlerFactory.getHandler());
            MessageHandlerContext _ctx = null;
            MessageHandlerContext _ctxPrev = null;
            MessageHandlerContext _ctxHeader = null;
            MessageHandlerContext _newCtx = null;
            /*
            for (RawHandler rawHandler : rawHandlers) {
                if (type(rawHandler.id) == type(protocolID) && idWithoutType(rawHandler.id) == 0) {
                    _ctx = new MessageHandlerContext();
                    _ctx.setProtocolID(protocolID);
                    _ctx.setHandler(rawHandler.factory.getHandler());
                    _ctx.setPrev(_ctxPrev);
                    _ctxPrev = _ctx;
                }

                if (_ctxHeader == null && _ctx != null) {
                    _ctxHeader = _ctx;
                }
            }
             *
             */
            _ctx = protocolTypeHandlers.get(type(protocolID));
            while(_ctx != null){
                _newCtx = new MessageHandlerContext();
                _newCtx.setProtocolID(protocolID);
                _newCtx.setHandler(_ctx.getHandler());
                _newCtx.setPrev(_ctxPrev);
                if ( _ctxPrev != null ){
                    _ctxPrev.setNext(_newCtx);
                }
                if (_ctxHeader == null){
                    _ctxHeader = _newCtx;
                }

                _ctx = _ctx.getNext();
            }

            if (_newCtx != null) {
                _newCtx.setNext(ctx);
                ctx.setPrev(_ctx);
            }else{
                _ctxHeader = ctx;
            }

            handlers.put(protocolID, _ctxHeader);
        } else if (type(protocolID) != 0 && idWithoutType(protocolID) == 0) {
            //the protocolID doesn't exist and it is second type of protocolid. therefor we need to apply the handler to all the protocol with same protocol type
            for (MessageHandlerContext _ctx : handlers.values()) {
                MessageHandlerContext __ctx = _ctx;
                if (type(__ctx.getProtocolID()) == type(protocolID)) {
                    while (__ctx.getNext() != null) {
                        __ctx = __ctx.getNext();
                    }
                    MessageHandlerContext ctx = new MessageHandlerContext();
                    ctx.setProtocolID(protocolID);
                    ctx.setHandler(handlerFactory.getHandler());
                    __ctx.setNext(ctx);
                    ctx.setPrev(__ctx);
                }

            }

            if (protocolTypeHandlers.containsKey(protocolID) ){

                MessageHandlerContext ctx = new MessageHandlerContext();
                ctx.setProtocolID(protocolID);
                ctx.setHandler(handlerFactory.getHandler());
                MessageHandlerContext _ctx = protocolTypeHandlers.get(protocolID);
                while(_ctx.getNext() != null ){
                    _ctx = _ctx.getNext();
                }
                _ctx.setNext(ctx);
                ctx.setPrev(_ctx);
            }else{
                MessageHandlerContext ctx = new MessageHandlerContext();
                ctx.setProtocolID(protocolID);
                ctx.setHandler(handlerFactory.getHandler());
                protocolTypeHandlers.put(protocolID, ctx);
            }
            
            //rawHandlers.add(new RawHandler(protocolID, handlerFactory));
        }
    }

    private MessageHandlerContext getMessageContext(int protocolID){
        MessageHandlerContext ctx = handlers.get(protocolID);
        if (ctx == null){
            ctx = protocolTypeHandlers.get(type(protocolID));
        }
        return ctx;
    }

    public void sendUpstream(ServerNode source, Protocol message) {
        MessageHandlerContext ctx = getMessageContext(message.getId());
        if (ctx == null) {
            return;
        }

        ctx.sendUpstream(source, message);
    }

    public void sendUpstream(ServerNode source, MessageHandlerContext ctx, Protocol message) {
        ctx.sendUpstream(source, message);
    }

    public void sendUpstream(ClientNode source, Protocol message){
        MessageHandlerContext ctx = handlers.get(message.getId());
        if (ctx == null) {
            return;
        }

        ctx.sendUpstream(source, message);
    }

    public void sendUpstream(ClientNode source, MessageHandlerContext ctx, Protocol message){
        ctx.sendUpstream(source, message);
    }

    public void sendUpstream(Channel channel, SocketAddress remoteAddress, Protocol message){
        MessageHandlerContext ctx = handlers.get(message.getId());
        if (ctx == null) {
            return;
        }

        ctx.sendUpstream(channel, remoteAddress, message);
    }


    public void registerMessageLite(int protocolID, MessageLite protoBufMessageLite){
        protobufMessages.put(protocolID, protoBufMessageLite);
    }
    
    public MessageLite getMesasgeLite(int protocolID){
        return protobufMessages.get(protocolID);
    }
}
