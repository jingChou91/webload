package com.kodgames.corgi.core;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.gamedata.baseinfo.BaseInfoConfigMgr;

public class ClientSeqIdData extends Thread
{
	private static final int SEQID_NO_FILL = 0;
	private static final int SEQID_FILL_NOINC = 1;
	private static final int SEQID_FILL_INC = 2;
	
	public static final int SEQID_SUCCESS = 0;
	public static final int SEQID_SERVER_ERROR = 1;
	public static final int SEQID_CLIENT_RESEND = 2;
	public static final int SEQID_CLIENT_ERROR = 3;
	public static final int SEQID_IGNORE = 4;	//收到重复包，丢弃
	
	private static final Logger logger = LoggerFactory.getLogger(ClientSeqIdData.class);
	
	public class SeqIdData
	{
		int clientSeqId;
		int serverSeqId;
		long lastCheckTime;
	}
	
	private ConcurrentHashMap<Integer, SeqIdData> clientSeqIdMaps = new ConcurrentHashMap<Integer, SeqIdData>();
	
	private boolean stop = false;
	
	private long checkInterval = 1000 * 60 * 10;		//10分钟
	
	public int checkSeqId(int playerId, int protocolId, int clientSeqId, int serverSeqId)
	{
		int result = SEQID_SUCCESS;
		boolean isCheckSeq = BaseInfoConfigMgr.getInstance().getCfg().isReconnect();
		if (!isCheckSeq)
		{
			logger.debug("checkSeqId flag is false then return success");
			return result;
		}
		int fillType = getSeqIdFillType(protocolId);
		if (fillType == SEQID_NO_FILL)		//不填充seqid直接success
		{
			result = SEQID_SUCCESS;
		}
		else if (fillType == SEQID_FILL_NOINC)		//客户端没有该类型的包
		{
			logger.warn("recv strange protocol type {}", protocolId);
		}
		else
		{
			if (clientSeqIdMaps.containsKey(playerId))
			{
				SeqIdData idData = clientSeqIdMaps.get(playerId);
				
				logger.debug("before check recv checkSeqId playerId {} protocolid {} local client {} local server {}",
					playerId, Integer.toHexString(protocolId), idData.clientSeqId, idData.serverSeqId);
				
				//if (!checkServerSeqId(serverSeqId, idData.serverSeqId))
				{
				//	result = SEQID_SERVER_ERROR;
				}
				//else
				
				if (clientSeqId <= idData.clientSeqId)
				{
					//已经收到的seqid包，直接丢弃，不认为失败
					return SEQID_IGNORE;
				}					
				else if (!checkClientSeqId(clientSeqId, idData.clientSeqId, fillType == SEQID_FILL_INC))
				{
					result =  SEQID_CLIENT_ERROR;
				}
				else
				{
					if (clientSeqId > idData.clientSeqId)
					{
						idData.clientSeqId = clientSeqId;
					}
				}
						
				idData.lastCheckTime = System.currentTimeMillis();
				logger.debug("after check recv checkSeqId playerId {} protocolid {} local client {} local server {}",
					playerId, Integer.toHexString(protocolId), idData.clientSeqId, idData.serverSeqId);
			}
			else
			{
				//服务器重新启动
				if (serverSeqId != 0)
				{
					result = SEQID_SERVER_ERROR;
				}
				else if (clientSeqId != 1)
				{
					result = SEQID_CLIENT_ERROR;
				}
				else
				{
					SeqIdData idData = new SeqIdData();
					idData.clientSeqId = clientSeqId;
					idData.serverSeqId = serverSeqId;
					idData.lastCheckTime = System.currentTimeMillis();

					logger.debug("server restart playerId {} protocolid {}", playerId, Integer.toHexString(protocolId));

					clientSeqIdMaps.put(playerId, idData);
				}
			}			
		}
		
		logger.debug("recv checkSeqId playerId {} protocolid {} recv clientSeqId {} recv serverSeqId {} result {}", 
			playerId, Integer.toHexString(protocolId), clientSeqId, serverSeqId, result);
		return result;
	}
	
	public SeqIdData getSeqId(int playerId, int protocolId)
	{
		SeqIdData idData = clientSeqIdMaps.get(playerId);
		if (idData == null)
		{
			return null;
		}
		
		int fillType = getSeqIdFillType(protocolId);
		switch(fillType)
		{
			case SEQID_NO_FILL:
				return null;
			case SEQID_FILL_NOINC:
				break;
			case SEQID_FILL_INC:
				idData.serverSeqId++;
				if (idData.serverSeqId <= 0)
				{
					idData.serverSeqId = 1;
				}
				break;
		}
		
		return idData;
	}
	
	@Override
	public void run()
	{
		while (!stop)
		{
			excute();
			
			try
			{
				Thread.sleep(checkInterval);
			}
			catch (InterruptedException e)
			{
				logger.error("{}",ExceptionUtils.getStackTrace(e));
			}
		}
	}
	
	private void excute()
	{
		Iterator<Map.Entry<Integer, SeqIdData>> iter = clientSeqIdMaps.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Integer, SeqIdData> entry = iter.next();
			if (entry.getValue().lastCheckTime + checkInterval * 5 < System.currentTimeMillis())
			{
				clientSeqIdMaps.remove(entry.getKey());
			}
		}
	}

	private boolean checkClientSeqId(int inputSeqId, int localSeqId, boolean isInc)
	{
		if (inputSeqId == 0)
		{
			return true;
		}
		
		if (localSeqId == 0)
		{
			localSeqId = inputSeqId;
			return true;
		}

		if (!isInc)
		{
			logger.warn("checkClientSeqId recv SEQID_FILL_NOINC strange data");
			return localSeqId == inputSeqId;
		}
		else
		{
			int tmpId = localSeqId + 1;
			if (tmpId <= 0)
			{
				tmpId = 1;
			}
			
			if (tmpId == inputSeqId)
			{
				localSeqId = inputSeqId;
			}
			
			return tmpId == inputSeqId;
		}
	}
	
	/*
	 * 服务器端收包时，必选先调用checkServerSeqId，然后才能调用getSeqId
	 */
	private boolean checkServerSeqId(int inputSeqId, int localSeqId)
	{
		if (0 == inputSeqId)
		{
			return true;
		}
		
		return inputSeqId == localSeqId;
	}
	
	private int getSeqIdFillType(int protocolId)
	{
		//获取该协议的seqid填充规则
		//0--不填充
		//1--填充当前的seqid，但是不消耗serverSeqId
		//2--填充seqid，并消耗serverSeqId
 		switch(protocolId)
		{
			case ClientProtocols.P_AUTH_CA_QUERY_MANIFEST_REQ:
			case ClientProtocols.P_AUTH_AC_QUERY_MANIFEST_RES:
			case ClientProtocols.P_AUTH_CA_CREATE_ACCOUNT_REQ:
			case ClientProtocols.P_AUTH_AC_CREATE_ACCOUNT_RES:
			case ClientProtocols.P_AUTH_CA_LOGIN_REQ:
			case ClientProtocols.P_AUTH_CA_QUICK_LOGIN_REQ:
			case ClientProtocols.P_AUTH_AC_LOGIN_RES:
			case ClientProtocols.P_AUTH_CA_BIND_ACCOUNT_REQ:
			case ClientProtocols.P_AUTH_AC_BIND_ACCOUNT_RES:
			case ClientProtocols.P_AUTH_CA_RESET_PASSWORD_REQ:
			case ClientProtocols.P_AUTH_AC_RESET_PASSWORD_RES:
			case ClientProtocols.P_AUTH_CA_AUTH_ACTIVITY_CODE_REQ:
			case ClientProtocols.P_AUTH_AC_AUTH_ACTIVITY_CODE_RES:
			case ClientProtocols.P_GAME_CG_QUERY_INITINFO_REQ:
			case ServerProtocols.P_MANAGE_SERVER_LOGIN_REQ:
			case ServerProtocols.P_MANAGE_SERVER_LOGIN_RES:
			case ServerProtocols.P_MANAGE_SERVER_LOGIN_CONFIRM:
			case ServerProtocols.P_MANAGE_SERVER_SYNC:
			case ServerProtocols.P_AUTH_SERVER_QUERY_TOKEN_REQ:
			case ServerProtocols.P_AUTH_SERVER_QUERY_TOKEN_RES:
			case ServerProtocols.P_INTERFACE_CLIENT_TO_OTHERSERVER:
			case ServerProtocols.P_INTERFACE_OTHERSERVER_TO_CLIENT:
			case ServerProtocols.P_INTERFACE_KICK_PLAYER:
			case ServerProtocols.P_GAME_CLIENT_DISCONNECT_REQ:
			case ServerProtocols.P_FUNCTION_PLAYER_ONLINE_STATUS_REQ:
			case ServerProtocols.P_FUNCTION_CHAT_REQ:
			case ServerProtocols.P_SYNC_XG_QUERY_PLAYERINFO_REQ:
			case ServerProtocols.P_SYNC_GX_QUERY_PLAYERINFO_RES:
			case ServerProtocols.P_SYNC_XG_SET_COST_AND_REWARD_REQ:
			case ServerProtocols.P_SYNC_GX_SET_COST_AND_REWARD_RES:
			case ServerProtocols.P_ALL_QUERY_COMBAT_RESULT_REQ:
			case ServerProtocols.P_ALL_QUERY_COMBAT_RESULT_RES:
			case ServerProtocols.P_ALL_UPDATE_REMOTE_PLAYER_RECORD_REQ:
			case ServerProtocols.P_SYNC_XF_QUERY_INFO_FOR_GAMESERVER_REQ:
			case ServerProtocols.P_SYNC_FX_QUERY_INFO_FOR_GAMESERVER_RES:
			case ServerProtocols.P_GAME_GF_PVE_RANK_ADD_RECORD_REQ:
			case ServerProtocols.P_GAME_FG_PVE_RANK_ADD_RECORD_RES:
			case ServerProtocols.P_SYNC_XG_CHANGE_LEVEL_REQ:
			case ServerProtocols.P_SYNC_GX_CHANGE_LEVEL_RES:
			case ServerProtocols.P_ALL_CLIENT_XML_VERSION_REQ:
			case ServerProtocols.P_ALL_XML_RELOAD_REQ:
			case ServerProtocols.P_ALL_XML_RELOAD_RES:
			case ServerProtocols.P_XF_SEND_EMAIL_REQ:
			case ServerProtocols.P_ALL_UPDATE_REMOTE_PLAYER_RANK_RECORD_REQ:
			case ServerProtocols.P_XF_SEND_GROUP_EMAIL_REQ:
			case ServerProtocols.P_SYNC_XF_CHANGE_RANK_REQ:
			case ServerProtocols.P_SYNC_FX_CHANGE_RANK_RES:
			case ServerProtocols.P_SYNC_XF_ONLINE_PLAYER_NUM_REQ:
			case ServerProtocols.P_SYNC_FX_ONLINE_PLAYER_NUM_RES:
			case ServerProtocols.P_SYNC_XF_QUERY_PVE_RANK_REQ:
			case ServerProtocols.P_SYNC_FX_QUERY_PVE_RANK_RES:
			case ServerProtocols.P_XF_SET_COST_AND_REWARD_REQ:
			case ServerProtocols.P_SYNC_XF_SEND_SYNCLIENT_TESTCASE_REQ:
			case ServerProtocols.P_SYNC_FX_SEND_SYNCLIENT_TESTCASE_RES:
			case ServerProtocols.P_FG_READY_TEST:
			case ServerProtocols.P_GF_NOTIFY:
			case ServerProtocols.P_XF_SET_PLAYERNAME_REQ:
			case ServerProtocols.P_XF_SEND_SYSTEM_MSG_REQ:
			case ServerProtocols.P_SYNC_XG_QUERY_EMAIL_GROUP_INFO_REQ:
			case ServerProtocols.P_SYNC_GX_QUERY_EMAIL_GROUP_INFO_RES:
			case ServerProtocols.P_SYNC_XG_QUERY_PRIVATE_EMAIL_INFO_REQ:
			case ServerProtocols.P_SYNC_GX_QUERY_PRIVATE_EMAIL_INFO_RES:
			case ServerProtocols.P_SYNC_XF_RESET_PLAYER_INFO_REQ:
			case ServerProtocols.P_SYNC_FX_RESET_PLAYER_INFO_RES:
			case ServerProtocols.P_GF_SEND_EMAIL_REWARD_REQ:
			case ServerProtocols.P_FG_PROCESS_QUEST_EVENT_REQ:
			case ServerProtocols.P_SYNC_XG_RESET_OPEN_DUNGEON_REQ:
			case ServerProtocols.P_SYNC_GX_RESET_OPEN_DUNGEON_RES:
			case ServerProtocols.P_SYNC_GF_FIRST_GET_REQ:
			case ServerProtocols.P_SYNC_FG_FIRST_GET_RES:
			case ServerProtocols.P_PG_CHANNEL_PURCHASE_REQ:
			case ServerProtocols.P_XG_LOADPLAYER_ROBOT_REQ:
			case ServerProtocols.P_SYNC_GF_FETCH_PLAYER_NAMES_REQ:
			case ServerProtocols.P_SYNC_FG_FETCH_PLAYER_NAMES_RES:
			case ServerProtocols.P_GF_ACCUMULATE_REQ:
			case ServerProtocols.P_SYNC_XF_QUERY_PLAYERID_REQ:
			case ServerProtocols.P_SYNC_FX_QUEYR_PLAYERID_RES:
			case ServerProtocols.P_SYNC_GA_QUERY_UDID_FROM_ACCOUNT_REQ:
			case ServerProtocols.P_SYNC_AG_QUERY_UDID_FROM_ACCOUNT_RES:
			case ServerProtocols.P_SYNC_XG_CHECK_COST_ONLY_REQ:
			case ServerProtocols.P_SYNC_GX_CHECK_COST_ONLY_RES:
			case ServerProtocols.P_XG_SEND_MINE_REWARD_BUFFS_REQ:
			case ServerProtocols.P_SYNC_XF_CHECK_PLAYERID_REQ:
			case ServerProtocols.P_SYNC_FX_CHECK_PLAYERID_RES:
			case ServerProtocols.P_XG_FREEZE_REQ:
			case ServerProtocols.P_SYNC_GF_ISFROZEN_REQ:
			case ServerProtocols.P_SYNC_FG_ISFROZEN_RES:
			case ServerProtocols.P_SYNC_XG_CHECK_GUID_REQ:
			case ServerProtocols.P_SYNC_GX_CHECK_GUID_RES:
			case ServerProtocols.P_GF_SIXDOORS_CONTRIBUTION_NOTIFY:
			case ServerProtocols.P_SYNC_PG_PING_REQ:
			case ServerProtocols.P_SYNC_GP_PING_RES:
			case ServerProtocols.P_XG_SEND_BATCH_REWARD_EMAIL_REQ:
			case ServerProtocols.P_GX_SEND_BATCH_REWARD_EMAIL_RES:
			case ServerProtocols.P_XG_SEND_GROUP_REWARD_EMAIL_REQ:
			case ServerProtocols.P_SYNC_XG_FUZZY_QUERY_PLAYER_NAME_REQ:
			case ServerProtocols.P_SYNC_XG_EFUN_PLAYER_INFO_REQ:			//请求efun信息
			case ClientProtocols.P_INTERFACE_CI_AUTH_TOKEN_REQ:
			case ClientProtocols.P_GAME_CG_QUERY_NOTIFY_REQ://断线重连后AuthToken成功，但是不需要queryInitInfo，该协议等同queryInitInfoReq
			//case ClientProtocols.P_GAME_GC_QUERY_NOTIFY_RES:
				return SEQID_NO_FILL;
			case ClientProtocols.P_INTERFACE_IC_AUTH_TOKEN_RES:
			case ClientProtocols.P_GAME_GC_QUERY_INITINFO_RES:
			case ClientProtocols.P_GAME_GC_SYNC_WORLD_AND_FLOW_MESSAGE:
			case ClientProtocols.P_GC_FC_RETURN_EXCEPTION_CALLBACK:
			case ClientProtocols.P_GAME_GC_SYNC_UN_READ_EMAIL_COUNT:
			case ClientProtocols.P_GAME_GC_ADD_FRIEND_RES:
			case ClientProtocols.P_GAME_GC_DEL_FRIEND_RES:
				return SEQID_FILL_NOINC;
			default:
				return SEQID_FILL_INC;
		}
	}
}
