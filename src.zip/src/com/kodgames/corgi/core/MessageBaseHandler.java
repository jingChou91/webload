/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kodgames.corgi.core;

import java.nio.ByteOrder;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.buffer.ChannelBufferInputStream;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelDownstreamHandler;
import org.jboss.netty.channel.ChannelEvent;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.Channels;
import org.jboss.netty.channel.ExceptionEvent;
import org.jboss.netty.channel.MessageEvent;
import org.jboss.netty.channel.SimpleChannelUpstreamHandler;
import org.perf4j.StopWatch;
import org.perf4j.slf4j.Slf4JStopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.MessageLite;
import com.kodgames.corgi.core.ClientSeqIdData.SeqIdData;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_NotifySeqIdError;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.authserver.ServerDataAS;

/**
 *
 * @author mrui
 */
public class MessageBaseHandler  extends SimpleChannelUpstreamHandler implements ChannelDownstreamHandler {
	private static final Logger logger = LoggerFactory.getLogger(MessageBaseHandler.class);

	private Controller controller;
    private ServerNode remoteServerNode;
    private Channel remoteClientChannel;

    private static ClientSeqIdData seqIdData = new ClientSeqIdData();
    private static Object seqIdLock = new Object();
    
    public MessageBaseHandler(Controller controller){
    	if (seqIdData.getState() == Thread.State.NEW)
    	{
    		seqIdData.start();
    	}
        this.controller = controller;
    }

    @Override
    public void messageReceived(
            ChannelHandlerContext ctx, MessageEvent evt) throws Exception {
        MessageEvent me = (MessageEvent)evt;
        if ( ! (me.getMessage() instanceof ChannelBuffer )){
            ctx.sendUpstream(evt);
            return;
        }

        if (controller == null){
            ctx.sendUpstream(evt);
            return;
        }
        
        ChannelBuffer channelBuffer = (ChannelBuffer)me.getMessage();
        channelBuffer.markReaderIndex();
        int checkResult = checkSeqId(evt.getChannel(), channelBuffer);
        if (checkResult == ClientSeqIdData.SEQID_IGNORE)
        {
        	logger.warn("checkSeqId recv duplicate data ignored");
        	return;
        }
        if (checkResult != ClientSeqIdData.SEQID_SUCCESS)
        {
        	logger.warn("checkSeqId found seq is error checkresult {}", checkResult);
        	//发送NotifySeqIdError消息给客户端
        	GC_NotifySeqIdError.Builder builder = GC_NotifySeqIdError.newBuilder();
        	builder.setErrorType(checkResult);
        	
        	ServerDataAS.transmitter.send(evt.getChannel(), ClientProtocols.P_GAME_GC_NOTIFY_SEQID_ERROR, builder.build());
        	
        	return;
        }
        channelBuffer.resetReaderIndex();
         
        Protocol protocolMessage = decodeProtoBuf((ChannelBuffer)me.getMessage());
        if ( protocolMessage == null){
            ctx.sendUpstream(evt);
            return;
        }

        try
        {
        	StopWatch stopWatch = new  Slf4JStopWatch("Message " + Integer.toHexString(protocolMessage.getId()));
        	if (remoteServerNode != null){
        		controller.sendUpstream(remoteServerNode, protocolMessage);
        	}
        	else if(remoteClientChannel != null )
        	{
        		CorgiUID corgiUID = (CorgiUID)remoteClientChannel.getAttachment();
        		if(corgiUID != null)
        		{
        			ClientNode remoteClientNode = new ClientNode(corgiUID, remoteClientChannel, remoteClientChannel.getRemoteAddress());
        			controller.sendUpstream(remoteClientNode, protocolMessage);
        		}
        		else
        		{
					controller.sendUpstream(remoteClientChannel, remoteClientChannel.getRemoteAddress(), protocolMessage);
				}
        	}else{// before the CommunicateNode (AccountID of server or CorgiUID of client) is ready
        		controller.sendUpstream(evt.getChannel(), evt.getRemoteAddress(), protocolMessage);
        	}
        	stopWatch.stop();

        }
        catch(Exception ex)
        {
        	logger.error("{}",ExceptionUtils.getStackTrace(ex));
        }
    }
    
    @Override
    public void exceptionCaught(
            ChannelHandlerContext ctx, ExceptionEvent e) {
        //logger.error("exceptionCaught {}", ExceptionUtils.getStackTrace(e.getCause()));
        ctx.getChannel().close();
    }

    public void handleDownstream(ChannelHandlerContext ctx, ChannelEvent evt) throws Exception{
        if (!(evt instanceof MessageEvent)) {
            ctx.sendDownstream(evt);
            return;
        }

        MessageEvent me = (MessageEvent)evt;
        if ( ! (me.getMessage() instanceof Protocol )){
            ctx.sendDownstream(evt);
            return;
        }

		Channel channel = evt.getChannel();
		int playerId = getPlayerIdFromChannel(channel);

		Protocol protocol = (Protocol)me.getMessage();
		int protocolId = protocol.getId();

		int clientSeqId = 0;
		int serverSeqId = 0;
		// 调用getSeqId之后，this.clientSeqId,this.serverSeqId被设置，然后再encodeProtoBuf中被封装到buffer中
		synchronized (seqIdLock)
		{
			SeqIdData idData = seqIdData.getSeqId(playerId, protocolId);
			if (idData != null)
			{
				clientSeqId = idData.clientSeqId;
				serverSeqId = idData.serverSeqId;
			}

			ChannelBuffer buffer =
				encodeProtobuf(evt.getChannel(), (Protocol)me.getMessage(), clientSeqId, serverSeqId);
			Channels.write(ctx, evt.getFuture(), buffer, me.getRemoteAddress());
		}
	}

    
    // protocolID + protobuf
    private Protocol decodeProtoBuf( ChannelBuffer buf ) throws Exception{
       if ( buf.readableBytes() < 4 ){
           return null;
       }
       int protocolID = buf.readInt();
       //跳过clientSeqId和serverSeqId
       buf.readInt();
       buf.readInt();
       Protocol protocol = new Protocol(protocolID);

       MessageLite prototype = controller.getMesasgeLite(protocolID);
       if (prototype == null){
		   //when interface transfer protocol from client to other server
           protocol.setBuffer(buf);
           return protocol;
       }

       if (buf.hasArray()) {
            final int offset = buf.readerIndex();
                protocol.setProtoBufMessage(prototype.newBuilderForType().mergeFrom(buf.array(), buf.arrayOffset() + offset, buf.readableBytes()).build());

        } else {
                protocol.setProtoBufMessage(prototype.newBuilderForType().mergeFrom(new ChannelBufferInputStream(buf)).build());

        }

       return protocol;
    }

    protected ChannelBuffer encodeProtobuf(Channel channel, Protocol msg, int clientSeqId, int serverSeqId) throws Exception 
	{
		if(null != msg.getProtoBufMessage()) 
		{
			//send data from protoBufMessage
        	byte[]  body = msg.getProtoBufMessage().toByteArray();
        	ChannelBuffer buffer =
       		     channel.getConfig().getBufferFactory().getBuffer(ByteOrder.BIG_ENDIAN, 12 + body.length);
        	buffer.writeInt(msg.getId());
        	buffer.writeInt(clientSeqId);
        	buffer.writeInt(serverSeqId);
        	buffer.writeBytes(body);
			return buffer;
		}
		else
		{
            //send data from buffer
            int dataSize = msg.getBuffer() != null ? msg.getBuffer().readableBytes() : 0;

            ChannelBuffer buffer =
                    channel.getConfig().getBufferFactory().getBuffer(ByteOrder.BIG_ENDIAN, 12 + dataSize);
            buffer.writeInt(msg.getId());
            buffer.writeInt(clientSeqId);
        	buffer.writeInt(serverSeqId);
            if (dataSize > 0) {
                buffer.writeBytes(msg.getBuffer());
                //buffer.writeBytes(msg.getBuffer()) will change the readindex of msg. It is strange, so we need to reset the index.
                //don't forget to mark the read index when setting the buffer to msg
                msg.getBuffer().resetReaderIndex();
            }
            return buffer;
        }
    }

    /**
     * @param remoteServerNode the remoteServerNode to set
     */
    public void setRemoteServerNode(ServerNode remoteServerNode) {
        this.remoteServerNode = remoteServerNode;
    }

	public void setRemoteClientChannel(Channel remoteClientChannel) {
		this.remoteClientChannel = remoteClientChannel;
	}
	
	private int getPlayerIdFromChannel(Channel channel)
	{
		if (channel != null)
        {
        	CorgiUID corgiUID = (CorgiUID)channel.getAttachment();
        	if (corgiUID != null)
        	{
        		return corgiUID.getPlayerID();
        	}
        }
		
		return 0;
	}	

	private int checkSeqId(Channel channel, ChannelBuffer channelBuffer)
	{
		if (!channel.equals(remoteClientChannel))
		{
			return ClientSeqIdData.SEQID_SUCCESS;
		}
		
        int playerId = getPlayerIdFromChannel(channel);
        int protocolId = channelBuffer.readInt();
        int clientSeqId = channelBuffer.readInt();
        int serverSeqId = channelBuffer.readInt();
        
        return seqIdData.checkSeqId(playerId, protocolId, clientSeqId, serverSeqId);
	}
}
