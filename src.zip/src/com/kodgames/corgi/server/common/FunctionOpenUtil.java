package com.kodgames.corgi.server.common;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.gamedata.player.PlayerNode;

public class FunctionOpenUtil
{
	// 判断功能是否开启
	public static boolean isFunctionOpen(ConfigDatabase cd, PlayerNode playerNode, int functionType)
	{
		// 功能未开启,返回false
		if (!getFunctionStatus(functionType, cd.get_LevelConfig()))
		{
			return false;
		}
		// 级别不够,返回false
		int openLevel = getOpenPlayerLevel(functionType, cd.get_LevelConfig());
		if (playerNode.getGamePlayer().getLevel() < openLevel)
		{
			return false;
		}
		return true;
	}

	// 获取功能开启状态
	public static boolean getFunctionStatus(int functionType, ClientServerCommon.LevelConfig levelCfg)
	{
		return levelCfg.GetFunctionStatusByOpenFunction(functionType);
	}

	// 获取开启等级
	public static int getOpenPlayerLevel(int functionType, ClientServerCommon.LevelConfig levelCfg)
	{
		return levelCfg.GetPlayerLevelByOpenFunciton(functionType);
	}
}
//if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Dungeon))
//{
//	result = ClientProtocols.E_GAME_QUERY_DUNGEON_GUIDE_LOAD_PLAYER_FAILED;
//	break;
//}
