/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.hyperic.sigar.NetInterfaceConfig;
import org.hyperic.sigar.NetInterfaceStat;
import org.hyperic.sigar.ProcCpu;
import org.hyperic.sigar.ProcMem;
import org.hyperic.sigar.Sigar;
import org.hyperic.sigar.SigarException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.NetworkHandler;
import com.kodgames.corgi.protocol.ManageProtocolsForServer;

/**
 *
 * @author Elvin
 */
public class Statistics 
{
	private static final Logger logger = LoggerFactory.getLogger(Statistics.class);
	private String serverName = null;
	private Sigar sigar = null;
	private List<NetInterfaceConfig> validNetInterfaceConfig = null;
	private HashMap<String, NetInterfaceStat> lastNetInterfaceStatMap = null; //[ip, NetInterfaceStat]
	private HashMap<String, NetInterfaceStat> currentNetInterfaceStatMap = null; //[ip, NetInterfaceStat]
	private long lastSampleTime = 0;
	private long lastAppReceiveSize = 0;
	private long lastAppSendSize = 0;
	private long currentAppReceiveSize = 0;
	private long currentAppSendSize = 0;
	private boolean logEnabled = true;

	public Statistics(String serverName) throws SigarException
	{
		this.serverName = serverName;

		this.sigar = new Sigar();
		this.validNetInterfaceConfig = this.collectNetInterface();
		this.lastNetInterfaceStatMap = new HashMap<String, NetInterfaceStat>();
		this.currentNetInterfaceStatMap = new HashMap<String, NetInterfaceStat>();
		this.lastSampleTime = System.currentTimeMillis();
		this.recordCurrentNetInterfaceState();
		this.recordCurrentAppReceiveState();
		this.recordCurrentAppSendState();
	}

	private List<NetInterfaceConfig> collectNetInterface() throws SigarException 
	{
		List<NetInterfaceConfig> validNetInterface = new ArrayList<NetInterfaceConfig>();
		String[] interfaceList = this.sigar.getNetInterfaceList();
		for(int i = 0; i < interfaceList.length; ++i)
		{
			NetInterfaceConfig netInterfaceConfig = sigar.getNetInterfaceConfig(interfaceList[i]);
			if(!netInterfaceConfig.getAddress().equals("0.0.0.0"))
			{
				validNetInterface.add(netInterfaceConfig);
			}
		}
		return validNetInterface;
	}

	private void recordCurrentAppReceiveState()
	{
		this.lastAppReceiveSize = this.currentAppReceiveSize;
		this.currentAppReceiveSize = NetworkHandler.getAppReceiveSize();
	}

	private void recordCurrentAppSendState()
	{
		this.lastAppSendSize = this.currentAppSendSize;
		this.currentAppSendSize = NetworkHandler.getAppSendSize();
	}

	@SuppressWarnings("unchecked")
	private void recordCurrentNetInterfaceState() throws SigarException
	{
		this.lastNetInterfaceStatMap = (HashMap<String, NetInterfaceStat>) this.currentNetInterfaceStatMap.clone();
		for(NetInterfaceConfig netInterfaceConfig : this.validNetInterfaceConfig)
		{
			try
			{
				NetInterfaceStat stat = null;
				stat = this.sigar.getNetInterfaceStat(netInterfaceConfig.getName());
				this.currentNetInterfaceStatMap.put(netInterfaceConfig.getAddress(), stat);
			}
			catch(Exception ex)
			{
				if(this.logEnabled)
				{
					logger.error("interface name: {}/n{}",
							netInterfaceConfig.getName(),ExceptionUtils.getStackTrace(ex));
				}
			}
		}
		this.logEnabled = false;
	}

	private double getCpuPercent() throws SigarException
	{
		ProcCpu procCpu = null;
		procCpu = sigar.getProcCpu(this.sigar.getPid());
		return procCpu.getPercent();
	}

	public ManageProtocolsForServer.ServerStatistics.Builder getAllStatistics() throws SigarException
	{
		long sampleInterval = (System.currentTimeMillis() - this.lastSampleTime) / 1000; //second
		this.lastSampleTime = System.currentTimeMillis();

		ManageProtocolsForServer.ServerStatistics.Builder statisticsBuilder = ManageProtocolsForServer.ServerStatistics.newBuilder();
		ProcMem procMem = this.getProcMem();
		if(null != procMem)
		{
			statisticsBuilder.setVirtualMemory(procMem.getSize());
			statisticsBuilder.setResidentMemory(procMem.getResident());
			statisticsBuilder.setSharedMemory(procMem.getShare());
		}
		statisticsBuilder.setCpuPercent(this.getCpuPercent());
		statisticsBuilder.setServerName(this.serverName);
		statisticsBuilder.setTime(System.currentTimeMillis());
		statisticsBuilder.addAllNetworkStatistics(this.getNetworkStatistics(sampleInterval));
		statisticsBuilder.setAppReceiveSpeed(this.getAppReceiveSpeed(sampleInterval));
		statisticsBuilder.setAppSendSpeed(this.getAppSendSpeed(sampleInterval));

		return statisticsBuilder;
	}

	private List<ManageProtocolsForServer.ServerNetworkStatistics> getNetworkStatistics(long sampleInterval) throws SigarException
	{
		this.recordCurrentNetInterfaceState();

		List<ManageProtocolsForServer.ServerNetworkStatistics> networkStatistics = 
				new ArrayList<ManageProtocolsForServer.ServerNetworkStatistics>();
		for(Entry<String, NetInterfaceStat> entry : this.currentNetInterfaceStatMap.entrySet())
		{
			NetInterfaceStat lastStat = this.lastNetInterfaceStatMap.get(entry.getKey());
			if(null != lastStat)
			{
				int receiveSpeed  = 0;
				int sendSpeed = 0;
				if(0 != sampleInterval)
				{
					receiveSpeed = (int) ((entry.getValue().getRxBytes() - lastStat.getRxBytes()) / sampleInterval);
					sendSpeed = (int) ((entry.getValue().getTxBytes() - lastStat.getTxBytes()) / sampleInterval);
				}
				ManageProtocolsForServer.ServerNetworkStatistics statistics = 
						ManageProtocolsForServer.ServerNetworkStatistics.newBuilder()
						.setIp(entry.getKey())
						.setReceiveSpeed(receiveSpeed)
						.setSendSpeed(sendSpeed)
						.build();
				networkStatistics.add(statistics);
			}
		}
		return networkStatistics;
	}

	public int getAppReceiveSpeed(long sampleInterval)
	{
		this.recordCurrentAppReceiveState();
		if(0 != sampleInterval)
		{
			return (int) ((this.currentAppReceiveSize - this.lastAppReceiveSize) / sampleInterval);
		}
		else
		{
			return 0;
		}
	}

	public int getAppSendSpeed(long sampleInterval)
	{
		this.recordCurrentAppSendState();
		if(0 != sampleInterval)
		{
			return (int) ((this.currentAppSendSize - this.lastAppSendSize) / sampleInterval);
		}
		else
		{
			return 0;
		}
	}

	private ProcMem getProcMem() throws SigarException
	{
		ProcMem	procMem = null;
		procMem = sigar.getProcMem(this.sigar.getPid());
		return procMem;
	}

	public long getVirtualMemorySize() throws SigarException
	{
		ProcMem procMem = this.getProcMem();
		if(null != procMem)
		{
			return procMem.getSize();
		}
		return 0;
	}

	public long getResidentMemorySize() throws SigarException
	{
		ProcMem procMem = this.getProcMem();
		if(null != procMem)
		{
			return procMem.getResident();
		}
		return 0;
	}

	public long getSharedMemorySize() throws SigarException
	{
		ProcMem procMem = this.getProcMem();
		if(null != procMem)
		{
			return procMem.getShare();
		}
		return 0;
	}

}
