/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.common;

import com.kodgames.corgi.core.Transmitter;
/**
 *
 * @author  ZHD
 */
public class BaseServerData
{
	static public Transmitter transmitter = new Transmitter();
	static public DBCluster dbCluster = null;
	static public Statistics statistics = null;
	static public int statisticsInterval = 30; //second 不改
}