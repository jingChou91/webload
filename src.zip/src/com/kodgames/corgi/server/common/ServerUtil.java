/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import system.DateTime;

import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.core.MessageHandlerFactory;
import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.sun.org.apache.xerces.internal.impl.dv.util.HexBin;

/**
 * 
 * @author Elvin
 */
public class ServerUtil
{
	private static final Logger logger = LoggerFactory.getLogger(ServerUtil.class);

	// 每小时毫秒数
	public static final long aHourMillsLong = 3600000L;
	// 一周
	public static final long OneWeek = 7 * 24 * 60 * 60 * 1000L;

	public static MessageHandlerFactory getFacilityMessageHandlerFactory(final MessageHandler messageHandler)
	{
		return new MessageHandlerFactory()
		{
			public MessageHandler getHandler()
			{
				return messageHandler;
			}
		};
	}

	static public List<Integer> stringListToIntList(List<String> stringList)
	{
		List<Integer> intList = new ArrayList<Integer>();
		for (String s : stringList)
		{
			intList.add(Integer.parseInt(s));
		}
		return intList;
	}

	static public String filterStringForTLog(String s)
	{
		return s.replaceAll("[|\n]", "");
	}

	static public String getTimeForTLog()
	{
		Date now = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return dateFormat.format(now);
	}

	static public String getDayStr(Date date)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		return dateFormat.format(date);
	}

	static public String getChineseTime()
	{
		// xxxx年xx月xx日 xx:xx
		String date = getTimeForTLog();
		date = date.replaceFirst("-", "年");
		date = date.replaceFirst("-", "月");
		date = date.replaceFirst(" ", "日 ");
		date = date.substring(0, date.lastIndexOf(':'));
		return date;
	}

	static public Date getDay(long timeMS)
	{
		String str = getDayStr(new Date(timeMS)) + " 00:00:00";
		return getDate(str);
	}

	public static java.util.Date getWeekFirstDate(java.util.Date dt)
	{
		Date zeroDate = getDay(dt.getTime());
		Calendar c1 = Calendar.getInstance();
		c1.setTime(zeroDate);
		int day = c1.get(Calendar.DAY_OF_WEEK);
		Date newDate = new Date(zeroDate.getTime() - (day - 2) * 3600L * 24 * 1000);
		return newDate;
	}

	public static java.util.Date getWeekLastDate(java.util.Date dt)
	{
		Date zeroDate = getDay(dt.getTime());
		Calendar c1 = Calendar.getInstance();
		c1.setTime(zeroDate);
		int day = c1.get(Calendar.DAY_OF_WEEK);
		Date newDate = new Date(zeroDate.getTime() + (-day + 8) * 3600L * 24 * 1000);
		return newDate;
	}

	public static java.util.Date getMonthFirstDate(java.util.Date dt)
	{
		Date zeroDate = getDay(dt.getTime());
		Calendar c1 = Calendar.getInstance();
		c1.setTime(zeroDate);
		int day = c1.get(Calendar.DAY_OF_MONTH);
		Date newDate = new Date(zeroDate.getTime() - (day - 1) * 3600L * 24 * 1000);
		return newDate;
	}

	static public Date getDate(String strDate)
	{
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date;
		try
		{
			date = sf.parse(strDate);
			return date;
		}
		catch (ParseException e)
		{
			logger.error("getDate strDate={} /n {}", strDate, ExceptionUtils.getStackTrace(e));
		}
		return null;
	}

	static public int getServerType(int serverID)
	{
		return serverID & 0xffff0000;
	}

	// 将clientservercommon的UTCticks转换成java的时间
	static public long getLongForJava(long timeCs, int timezone)
	{
		return timeCs - timezone * aHourMillsLong;
	}

	static public long getLongFromStrHHmmss(String hhmmss, int timezone)
	{
		Calendar now = Calendar.getInstance();
		StringBuffer sb = new StringBuffer();
		sb.append(now.get(Calendar.YEAR) + ":" + (now.get(Calendar.MONTH) + 1) + ":" + now.get(Calendar.DAY_OF_MONTH)
			+ " ");
		sb.append(hhmmss);

		return convertTimeStringWithTimezoneToLong(timezone, sb.toString());
	}

	// 从int生成字符串（8-------GMT+08:00）
	static public String getTimeZoneStringFromInt(int timezoneInt)
	{
		return "GMT+" + timezoneInt;
	}

	static public final int TimeWithMills = 0;
	static public final int TimeWithoutMills = 1;

	// 将服务器时间long(UTC)转成配置时区的字符串时间
	static public String convertLongToTimeStringWithTimezone(int timezoneInt, long time, int needMills)
	{
		Calendar now = Calendar.getInstance();
		TimeZone timezone = TimeZone.getTimeZone(ServerUtil.getTimeZoneStringFromInt(timezoneInt));
		now.setTimeZone(timezone);
		now.setTimeInMillis(time);
		StringBuffer sb = new StringBuffer();
		sb.append(now.get(Calendar.YEAR) + "-" + (now.get(Calendar.MONTH) + 1) + "-" + now.get(Calendar.DAY_OF_MONTH)
			+ " " + now.get(Calendar.HOUR_OF_DAY) + ":" + now.get(Calendar.MINUTE) + ":" + now.get(Calendar.SECOND));

		if (needMills == TimeWithMills)
		{
			sb.append("." + now.get(Calendar.MILLISECOND));
		}
		return sb.toString();
	}

	// 将数据库读出的时间字符串（含有配置时区）转成long(UTC)
	static public long convertTimeStringWithTimezoneToLong(int timezoneInt, String timeString)
	{
		if (timeString == null || timeString.equals(""))
		{
			return 0;
		}

		String[] cells = new String[7];
		String[] cells2 = timeString.split("\\:|\\-|\\ |\\.");
		for (int i = 0; i < cells2.length; ++i)
		{
			cells[i] = cells2[i];
		}
		if (cells2.length <= 7)
		{
			for (int i = cells2.length; i < 7; ++i)
			{
				cells[i] = "0";
			}
		}
		Calendar now = Calendar.getInstance();
		TimeZone timezone = TimeZone.getTimeZone(ServerUtil.getTimeZoneStringFromInt(timezoneInt));
		now.setTimeZone(timezone);
		try
		{
			now.set(Calendar.YEAR, Integer.parseInt(cells[0]));
			now.set(Calendar.MONTH, Integer.parseInt(cells[1]) - 1);
			now.set(Calendar.DAY_OF_MONTH, Integer.parseInt(cells[2]));
			now.set(Calendar.HOUR_OF_DAY, Integer.parseInt(cells[3]));
			now.set(Calendar.MINUTE, Integer.parseInt(cells[4]));
			now.set(Calendar.SECOND, Integer.parseInt(cells[5]));
			now.set(Calendar.MILLISECOND, Integer.parseInt(cells[6]));
		}
		catch (NumberFormatException e)
		{
			logger.error(ExceptionUtils.getStackTrace(e));
		}
		long time = now.getTimeInMillis();
		return time;
	}

	// 将二进制流转为Hexstring
	public static String toHexString(byte[] bin)
	{
		if (bin.length > 0)
		{
			return "0x" + HexBin.encode(bin);
		}

		return null;
	}

	// 将Hexstring转为二进制
	public static byte[] fromHexString(String hexString)
	{
		if (hexString != null && hexString.startsWith("0x"))
		{
			return HexBin.decode(hexString.substring(2, hexString.length()));
		}

		return null;
	}

	// 生成文本，用分号隔开
	public static String toHexString(List<Integer> list)
	{
		if (list == null || list.size() == 0)
			return "";
		StringBuffer sb = new StringBuffer();
		for (Integer id : list)
		{
			sb.append("" + Integer.toHexString(id) + ";");
		}
		return sb.toString();
	}

	static public List<Integer> convertHexsToIntList(String str)
	{
		List<Integer> list = new ArrayList<Integer>();

		if (str == null || str.equals(""))
			return list;
		String intStrs[] = str.split("\\;|\\|");
		for (int i = 0; i < intStrs.length; i++)
		{
			try
			{
				list.add(Integer.parseInt(intStrs[i], 16));
			}
			catch (Exception e)
			{
				logger.warn(ExceptionUtils.getFullStackTrace(new Throwable()));
			}
		}

		return list;
	}

	static public ArrayList<Integer> convertDecsToIntList(String str)
	{
		ArrayList<Integer> list = new ArrayList<Integer>();

		if (str == null || str.equals(""))
			return list;
		String intStrs[] = str.split("\\;|\\|");
		for (int i = 0; i < intStrs.length; i++)
		{
			try
			{
				list.add(Integer.parseInt(intStrs[i], 10));
			}
			catch (Exception e)
			{
				logger.warn(ExceptionUtils.getFullStackTrace(new Throwable()));
			}
		}

		return list;
	}

	// 把配置文件中的DateTime转成Java系统时间 "00:00:00" "23:23:45"
	public static long configTimeToLongForJava(DateTime configTime, int timeZone)
	{
		return getLongForJava(ClientServerCommon.ConvertTicksToMs.DateTimeToInt64(configTime), timeZone);
	}

	// 根据传入的时间和刷新时间 判断传入时间的下次刷新时间 "00:00:00" "23:23:45"
	// 1、根据系统当前时间,获得下次的刷新时间
	// 2、根据存储的上次刷新时间,获得下次刷新时间
	// 3、如果两次的下次刷新时间,不相同就刷新
	public static long getNextRefreshTime(long time, long refreshTime)
	{
		long dtime = refreshTime - time;

		dtime = dtime % (24 * 60 * 60 * 1000L); //

		if (dtime > 0)
		{
			refreshTime = dtime + time;
		}
		else
		{
			refreshTime = dtime + time + 24 * 60 * 60 * 1000;
		}

		return refreshTime;
	}

	public static boolean isNeedRefresh(DateTime refreshTime_DateTime, long lastRefreshTime)
	{
		long refreshTime =
			getLongForJava(ClientServerCommon.ConvertTicksToMs.DateTimeToInt64(refreshTime_DateTime),
				TimeZoneData.getTimeZone());
		long nextResetTime = getNextRefreshTime(System.currentTimeMillis(), refreshTime);
		long time = getNextRefreshTime(lastRefreshTime, refreshTime);
		if (nextResetTime != time)
		{
			return true;
		}
		return false;
	}
	
	public static boolean isNeedRefresh(DateTime refreshTime_DateTime, long lastRefreshTime,long now)
	{
		long refreshTime =
			getLongForJava(ClientServerCommon.ConvertTicksToMs.DateTimeToInt64(refreshTime_DateTime),
				TimeZoneData.getTimeZone());
		long nextResetTime = getNextRefreshTime(now, refreshTime);
		long time = getNextRefreshTime(lastRefreshTime, refreshTime);
		if (nextResetTime != time)
		{
			return true;
		}
		return false;
	}

	public static boolean isNeedRefreshForWeek(Long initRefreshTime, long lastRefreshTime, long now)
	{
		long nowWeeks = (now - initRefreshTime) / ServerUtil.OneWeek + 1;
		long lastTimeWeeks = (lastRefreshTime - initRefreshTime) / ServerUtil.OneWeek + 1;
		return nowWeeks != lastTimeWeeks;
	}

	public static long nextRefreshTime(long time, DateTime refreshTime_DateTime)
	{
		long refreshTime =
			getLongForJava(ClientServerCommon.ConvertTicksToMs.DateTimeToInt64(refreshTime_DateTime),
				TimeZoneData.getTimeZone());
		return getNextRefreshTime(time, refreshTime);
	}

	// list转string
	public static String listToString(List list)
	{
		String str = "";
		for (Object obj : list)
		{
			str += obj + ",";
		}
		return str;
	}

	// list转string
	public static String listToString(List list, String separated)
	{
		String str = "";
		for (Object obj : list)
		{
			str += obj + separated;
		}
		return str;
	}

	// Hashset转string
	public static String hashSetToString(HashSet hashSet)
	{
		String str = "";
		for (Object obj : hashSet)
		{
			str += obj + ",";
		}
		return str;
	}
	
	// Map转string
	public static String MapToString(Map<Integer, Integer> map)
	{
		String str = "";
		for (Map.Entry<Integer, Integer> entry : map.entrySet())
		{
			str += entry.getKey() + "&" + entry.getValue() + "|";
		}
		return str;
	}

	// 把date转为yyyy-MM-dd HH:mm:ss格式 如2014-08-22 11:26:12
	public static String getStringTime(Date date)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return dateFormat.format(date);
	}

	// 将127.0.0.1形式的IP地址转换成十进制整数
	public static long transferIPToLong(String stringIP)
	{
		long[] ip = new long[4];
		// 先找到IP地址字符串中.的位置
		int position1 = stringIP.indexOf(".");
		int position2 = stringIP.indexOf(".", position1 + 1);
		int position3 = stringIP.indexOf(".", position2 + 1);
		// 将每个.之间的字符串转换成整型
		ip[0] = Long.parseLong(stringIP.substring(0, position1));
		ip[1] = Long.parseLong(stringIP.substring(position1 + 1, position2));
		ip[2] = Long.parseLong(stringIP.substring(position2 + 1, position3));
		ip[3] = Long.parseLong(stringIP.substring(position3 + 1));
		return (ip[0] << 24) + (ip[1] << 16) + (ip[2] << 8) + ip[3];
	}

	// 将十进制整数形式转换成127.0.0.1形式的ip地址
	public static String transferLongToIP(long longIP)
	{
		StringBuffer sb = new StringBuffer("");
		// 直接右移24位
		sb.append(String.valueOf((longIP >>> 24)));
		sb.append(".");
		// 将高8位置0，然后右移16位
		sb.append(String.valueOf((longIP & 0x00FFFFFF) >>> 16));
		sb.append(".");
		// 将高16位置0，然后右移8位
		sb.append(String.valueOf((longIP & 0x0000FFFF) >>> 8));
		sb.append(".");
		// 将高24位置0
		sb.append(String.valueOf((longIP & 0x000000FF)));
		return sb.toString();
	}

	public static String getRemoteIP(String remoteAddr)
	{
		int index1 = remoteAddr.indexOf("/");
		int index2 = remoteAddr.indexOf(":");

		String remoteIP = remoteAddr.substring(index1 + 1, index2);
		return remoteIP;
	}

	// 返回 20141220
	public static int getDayIntByTime(long now, int timezone)
	{
		TimeZone tz = TimeZone.getTimeZone(ServerUtil.getTimeZoneStringFromInt(timezone));
		Calendar c = Calendar.getInstance(tz);
		c.setTimeInMillis(now);
		int yyyy = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH);
		int day = c.get(Calendar.DAY_OF_MONTH);
		int ret = yyyy * 10000 + (month + 1) * 100 + day;
		return ret;
	}
}
