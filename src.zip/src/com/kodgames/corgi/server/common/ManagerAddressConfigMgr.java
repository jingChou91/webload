/*
 * 文 件 名:  ManagerAddressConfigMgr.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:  <描述>
 * 创 建 人:  <创建人>
 * 创建时间:  2014年8月16日
 * 修 改 人:  <修改人>
 * 修改时间:  2014年8月16日
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.common;

import org.dom4j.Element;


import com.kodgames.corgi.gameconfiguration.AppPath;
import com.kodgames.gamedata.xml.IXmlLoader;
import com.kodgames.gamedata.xml.xmlConfig;

/**
 * <一句话功能简述>
 * <功能详细描述>
 * 
 * @author  姓名
 * @version  [版本号, 2014年8月16日]
 * @see  [相关类/方法]
 * @since  [产品/模块版本]
 */
public class ManagerAddressConfigMgr implements IXmlLoader
{
	private static ManagerAddressConfigMgr managerAddressConfigMgr = new ManagerAddressConfigMgr();
	private String managerServerIP;
	private int managerServerPort;
	
	private ManagerAddressConfigMgr()
	{
	}
	
	public String getManagerServerIP()
	{
		return managerServerIP;
	}

	public int getManagerServerPort()
	{
		return managerServerPort;
	}


	public static ManagerAddressConfigMgr getInstance()
	{
		return managerAddressConfigMgr;
	}
	
	
	public boolean load()
	{
		boolean ret = xmlConfig.load(AppPath.file_ManagerAddress, this);
		return ret;
	}
	
	/**
	 * 重载方法
	 * @param root
	 * @return
	 */
	@Override
	public boolean reload(Element root)
	{
		Element manager = root.element("ManagerServer");
		this.managerServerIP = xmlConfig.parseStr(manager.attributeValue("IPForServer"), "127.0.0.1");
		this.managerServerPort =xmlConfig.parseInt(manager.attributeValue("PortForServer"), 0);
		return true;
	}

	/**
	 * 重载方法
	 * @param key
	 * @param value
	 * @return
	 */
	@Override
	public boolean reloadFromMemory(String key, String value)
	{
		boolean ret = xmlConfig.loadFromMemory(value, this);
		return ret;
	}
}
