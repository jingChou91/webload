package com.kodgames.corgi.server.common;


public class AreaDBCluster {
	
	private int areaId;
	private DBServerConfig gameDBConfig = null;
	private DBServerConfig logDBConfig = null;

	public AreaDBCluster()
	{
		
	}
	public int getAreaId() {
		return areaId;
	}
	public void setAreaId(int areaId) {
		this.areaId = areaId;
	}

	public DBServerConfig getGameDBConfig() {
		return gameDBConfig;
	}
	public void setGameDBConfig(DBServerConfig gameDBConfig) {
		this.gameDBConfig = gameDBConfig;
	}
	public DBServerConfig getLogDBConfig() {
		return logDBConfig;
	}
	public void setLogDBConfig(DBServerConfig logDBConfig) {
		this.logDBConfig = logDBConfig;
	}
}
