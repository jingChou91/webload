package com.kodgames.corgi.server.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CheckEmail {

	public static boolean emailFormat(String email) {
		boolean tag = true;
		String pattern = "^[a-zA-Z0-9_-]+@([a-zA-Z0-9_-])+(\\.([a-zA-Z0-9_-])+)+$";
		Pattern myPattern = Pattern.compile(pattern);
		final Matcher matcher = myPattern.matcher(email);
		if (!matcher.find()) {
			tag = false;
		}
		return tag;
	}

	public static boolean emailLength(String email, int maxLength) {
		boolean tag = true;
		if ((email.length() < 6) || (email.length() > maxLength)) {
			tag = false;
		}
		return tag;
	}
	
	public static boolean passwordFormat(String password) {
		boolean tag = true;
		String pattern = "^[a-zA-Z0-9]+$";
		Pattern myPattern = Pattern.compile(pattern);
		final Matcher matcher = myPattern.matcher(password);
		if (!matcher.find()) {
			tag = false;
		}
		return tag;
	}
	
	public static boolean checkPhoneNum(String phoneNum)
	{
		boolean tag = true;
		String pattern = "^[0-9]+$";
		Pattern myPattern = Pattern.compile(pattern);
		final Matcher matcher = myPattern.matcher(phoneNum);
		if (!matcher.find()) {
			tag = false;
		}
		return tag;
	}

}
