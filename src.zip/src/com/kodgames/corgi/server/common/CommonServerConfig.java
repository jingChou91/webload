/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.common;

import org.dom4j.Element;

/**
 *
 * @author Elvin
 */
public class CommonServerConfig {
	
	private String managerServerIP = null;
	private int managerServerPort = 0;
	private String serverName = null;
	private Element rootElement = null;

	public static int OPT_managerserverThreadNum = 1; //ManagerServer单线程
	public static int OPT_serverThreadNum = 16;
	public static boolean OPT_isSuffixPlayerNameOpen = false;//当玩家昵称重名时，自动加后缀
	
	private static CommonServerConfig cfg=null;
	public static CommonServerConfig getInstance(){
		if(cfg==null)
		{
			cfg=new CommonServerConfig();
		}
		return cfg;
	}
	
	static
	{
		{Integer value=getInteger("OPT_serverThreadNum");if(value!=null)CommonServerConfig.OPT_serverThreadNum=value;}
		{Boolean value=getBoolean("OPT_isSuffixPlayerNameOpen");if(value!=null)CommonServerConfig.OPT_isSuffixPlayerNameOpen=value;}
	}
	
	public static Integer getInteger(String defineString){
		Integer value=null;
		try{
			value=Integer.valueOf(System.getProperty(defineString));
		}
		catch(Exception ex){
			
		}
		return value; 
	}
	
	public static boolean getBoolean(String defineString){
		Boolean value=null;
		try{
			value=Boolean.valueOf(System.getProperty(defineString));
		}
		catch(Exception ex){
			
		}
		return value; 
	}

	public String getServerName()
	{
		return this.serverName;
	}
	
	public void setServerName(String serverName) 
	{
		this.serverName = serverName;
	}
	
}
