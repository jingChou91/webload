package com.kodgames.corgi.server.common;

import java.util.HashMap;
import java.util.Map;

public class Context
{
	public final Map<String, String> paramList;
	public final String command;
	public Context(Map<String, String> paramList, String command)
	{
		super();
		this.paramList = paramList;
		this.command = command;
	}

	public Context(String uri, String split, boolean uppercaseKey)
	{
		command = uri;
		paramList = new HashMap<String, String>();

		if (uri == null || uri.trim().length() == 0)
			return;

		// 将各组键值对取出
		String[] queryParam = command.split(split);
		int length = queryParam.length;
		// 将键值对保存
		for (int i = 0; i < length; i++)
		{
			String param = queryParam[i];
			int index = param.indexOf("=");
			if (index != -1)
			{
				String paramKey = param.substring(0, index);
				String paramValue = param.substring(index + 1, param.length());
				// key转换成大写保存
				if (uppercaseKey)
				{
					paramList.put(paramKey.toUpperCase(), paramValue);
				}
				else
				{
					paramList.put(paramKey, paramValue);
				}
			}
		}
	}
}
