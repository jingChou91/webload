package com.kodgames.corgi.server.common;

import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class LoopRunnable implements Runnable
{
	private static Logger logger = LoggerFactory.getLogger(LoopRunnable.class);

	private static final long DEFAULT_LOOP_TIME = 2000L;
	public static volatile boolean shutdown = false;
	public static AtomicInteger lowThreadNum = new AtomicInteger(0);
	public static AtomicInteger mediumThreadNum = new AtomicInteger(0);
	public static AtomicInteger highThreadNum = new AtomicInteger(0);

	// 关闭等级决定了关闭顺序
	public enum ShutdownLevel
	{
		// 最先关闭
		LOW,
		// low之后关闭
		MEDIUM,
		// 最后关闭
		HIGH
	}

	private long loopTime = DEFAULT_LOOP_TIME;
	private ShutdownLevel shutdownLevel = ShutdownLevel.LOW;
	public LoopRunnable(long loopTime)
	{
		if (loopTime <= 0)
		{
			this.loopTime = DEFAULT_LOOP_TIME;
		}
		else
		{
			this.loopTime = loopTime;
		}
		
	}

	public LoopRunnable(long loopTime, ShutdownLevel shutdownLevel)
	{
		this(loopTime);
		this.shutdownLevel = shutdownLevel;
	}

	/*
	 * 循环线程，如果loopTime<DEFAULT_LOOP_TIME,则每loopTime执行一次任务，否则，每DEFAULT_LOOP_TIME检测
	 * 线程是否结束，每loopTime执行一次任务
	 */
	@Override
	public final void run()
	{
		switch (shutdownLevel)
		{
		case LOW:
			lowThreadNum.incrementAndGet();
			break;
		case MEDIUM:
			mediumThreadNum.incrementAndGet();
			break;
		case HIGH:
			highThreadNum.incrementAndGet();
			break;
		default:
			break;
		}

		long sleepTime = 0L;
		if (loopTime < DEFAULT_LOOP_TIME)
		{
			sleepTime = loopTime;
		}
		else
		{
			sleepTime = DEFAULT_LOOP_TIME;
		}

		while (!shutdown)
		{
			try
			{
				execute();
			}
			catch (Exception e)
			{
				logger.error(ExceptionUtils.getStackTrace(e));
			}
			
			long time = System.currentTimeMillis();
			while (!shutdown && (System.currentTimeMillis() - time) < loopTime && System.currentTimeMillis() >= time)
			{
				await(sleepTime);
			}
		}
		
		// 关闭顺序，根据shutdownLevel，low全部关闭后关闭medium,最后关闭high
		switch (shutdownLevel)
		{
		case LOW:
			shutdownHook();
			lowThreadNum.decrementAndGet();
			break;
		case MEDIUM:
			while (lowThreadNum.get() != 0)
			{
				await(sleepTime);
			}
			await(sleepTime);
			shutdownHook();
			mediumThreadNum.decrementAndGet();
			break;
		case HIGH:
			while (mediumThreadNum.get() != 0 || lowThreadNum.get() != 0)
			{
				await(sleepTime);
			}
			await(sleepTime);
			shutdownHook();
			highThreadNum.decrementAndGet();
			break;
		default:
			break;
		}
		logger.error(Thread.currentThread().getName() + " stop!!! shutdown. level:" + this.shutdownLevel.toString());
	}

	/*
	 * 子类须覆写的任务执行过程 
	 */
	public abstract void execute();

	/*
	 * 任务结束时的挂钩，任务结束时调用，执行该线程结束必须的清理工作
	 */
	public void shutdownHook()
	{
	}

	/*
	 * 关闭所有线程
	 */
	public static void shutdwonAll()
	{
		logger.error(ShutdownLevel.LOW.toString() + ":" + lowThreadNum.get() + "\t" + ShutdownLevel.MEDIUM.toString() + ":" + mediumThreadNum.get() + "\t"
				+ ShutdownLevel.HIGH.toString() + ":" + highThreadNum.get());
		shutdown = true;
		while (highThreadNum.get() != 0 || mediumThreadNum.get() != 0 || lowThreadNum.get() != 0)
		{
			await(DEFAULT_LOOP_TIME);
		}
	}

	private static void await(long time)
	{
		try
		{
			Thread.sleep(time);
		}
		catch (InterruptedException e)
		{
			logger.error(ExceptionUtils.getStackTrace(e));
		}
	}
}
