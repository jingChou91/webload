package com.kodgames.corgi.server.common;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import com.kodgames.corgi.gameconfiguration.AreaData;
import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.xml.xmlConfig;

/**
 * 
 * @author ZHD
 */
public class TimeRange
{
	private int year;
	private int month;
	private int day;
	private int hour;
	private int minute;
	private int second;
	private long time;

	// get set--------------------------------------------------------------------------------
	public long getTime()
	{
		return time;
	}

	public void setTime(long time)
	{
		this.time = time;
	}

	public int getYear()
	{
		return year;
	}

	public void setYear(int year)
	{
		this.year = year;
	}

	public int getMonth()
	{
		return month;
	}

	public void setMonth(int month)
	{
		this.month = month;
	}

	public int getDay()
	{
		return day;
	}

	public void setDay(int day)
	{
		this.day = day;
	}

	public int getHour()
	{
		return hour;
	}

	public void setHour(int hour)
	{
		this.hour = hour;
	}

	public int getMinute()
	{
		return minute;
	}

	public void setMinute(int minute)
	{
		this.minute = minute;
	}

	public int getSecond()
	{
		return second;
	}

	public void setSecond(int second)
	{
		this.second = second;
	}

	// get set----------------------------------------------------------------------------------
	// 构造函数------------------------------------------------------------------------------------
	public TimeRange(Calendar time)
	{
		this.year = time.get(Calendar.YEAR);
		this.month = time.get(Calendar.MONTH) + 1;
		this.day = time.get(Calendar.DAY_OF_MONTH);
		this.hour = time.get(Calendar.HOUR_OF_DAY); // 24小时制
		this.minute = time.get(Calendar.MINUTE);
		this.second = time.get(Calendar.SECOND);
		this.time = time.getTimeInMillis();
	}

	public TimeRange(long time)
	{
		Calendar _time = Calendar.getInstance();
		_time.setTimeInMillis(time);
		this.year = _time.get(Calendar.YEAR);
		this.month = _time.get(Calendar.MONTH) + 1;
		this.day = _time.get(Calendar.DAY_OF_MONTH);
		this.hour = _time.get(Calendar.HOUR_OF_DAY); // 24小时制
		this.minute = _time.get(Calendar.MINUTE);
		this.second = _time.get(Calendar.SECOND);
		this.time = time;
	}

	// ----------------------------------------------------------------------------------------
	public static String getDate()
	{
		Calendar now = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		return sdf.format(now.getTime());
	}

	public boolean checkMonth(Calendar time)
	{
		int _year = time.get(Calendar.YEAR);
		int _month = time.get(Calendar.MONTH) + 1;

		if (year == _year && month == _month)
		{
			return true;
		}

		return false;
	}

	// public static boolean checkDungeonDay(long oldTime,long now, int activityId,ConfigDatabase cd)
	// {
	// // Calendar time = Calendar.getInstance();
	// // time.setTimeInMillis(oldTime);
	//
	// ActivityConfig activityConfig = cd.get_ActivityConfig();
	// if(activityConfig == null)
	// {
	// return true;
	// }
	//
	// ActivityConfig.Activity activity = activityConfig.GetActivityById(activityId);
	// if(activity == null)
	// {
	// return true;
	// }
	//
	// long resetTime = ActivityManager.getNextResetTime(activity, oldTime);
	//
	// if(now < resetTime)
	// {
	// return true;
	// }
	//
	// return false;
	// }

	public static boolean checkDay(long oldTime, long now)
	{
		Calendar time = Calendar.getInstance();
		time.setTimeInMillis(oldTime);
		int _year = time.get(Calendar.YEAR);
		int _month = time.get(Calendar.MONTH) + 1;
		int _day = time.get(Calendar.DAY_OF_MONTH);

		Calendar _time = Calendar.getInstance();
		_time.setTimeInMillis(now);
		int year = _time.get(Calendar.YEAR);
		int month = _time.get(Calendar.MONTH) + 1;
		int day = _time.get(Calendar.DAY_OF_MONTH);

		if (year == _year && month == _month && day == _day)
		{
			return true;
		}

		return false;
	}

	// --------------------------------------------------------------------------------
	// 刷新当前服务器时间
	public static int refreshServerTime()
	{
		Calendar time = Calendar.getInstance();
		int year = time.get(Calendar.YEAR); // 得到年
		int month = time.get(Calendar.MONTH) + 1; // 得到月，因为从0开始的，所以要加1
		int day = time.get(Calendar.DAY_OF_MONTH); // 得到天

		String timeString = "" + year;
		if (month < 10)
		{
			timeString = timeString + "0" + month;
		}
		else
		{
			timeString = timeString + month;
		}

		if (day < 10)
		{
			timeString = timeString + "0" + day;
		}
		else
		{
			timeString = timeString + day;
		}

		return Integer.parseInt(timeString);
	}

	// -------------------------------------------------------------------
	@Deprecated
	public static java.sql.Timestamp string2Time(String dateString)
		throws java.text.ParseException
	{
		DateFormat dateFormat;
		// 设定格式
		dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		// util类型
		java.util.Date timeDate = dateFormat.parse(dateString);
		// Timestamp类型,timeDate.getTime()返回一个long型
		java.sql.Timestamp dateTime = new java.sql.Timestamp(timeDate.getTime());
		return dateTime;
	}

//	//
//	// 添加参数isShow,如果是show,根据三个预售期,计算出预售时间,根据三个开启时间,计算出开启时间. 取两个时间中较小者为openTime_Long
//	public static boolean isGoodStatusOpen(GoodStatusConfig.TimeLimit timeLimit, PlayerNode playerNode, boolean isShow)
//	{
//		boolean result = false;
//		if (timeLimit == null)
//		{
//			return result;
//		}
//			
//		// 如果没有时间限制,那么该状态开启
//		if (timeLimit.get_closeTime().equals("") && timeLimit.get_openTime().equals("")
//			&& timeLimit.get_relativeAreaCloseTime().equals("") && timeLimit.get_relativeAreaOpenTime().equals("")
//			&& timeLimit.get_relativeAccountOpenTime().equals("") && timeLimit.get_relativeAreaCloseTime().equals(""))
//		{
//			return true;
//		}
//
//		Calendar now = Calendar.getInstance();
//		now.setTimeZone(TimeZone.getTimeZone(ServerUtil.getTimeZoneStringFromInt(TimeZoneData.getTimeZone())));
//
//		// 开启时间取大日期
//		Calendar openTime = Calendar.getInstance();
//
//		long earlyShowTime =
//			TimeRange.fixAndSelectRightTime(timeLimit.get_closeTime(),
//				timeLimit.get_relativeAreaEarlyShowTime(),
//				timeLimit.get_relativeAccountEarlyShowTime(),
//				playerNode,
//				false);
//		long openTime_Long =
//			TimeRange.fixAndSelectRightTime(timeLimit.get_openTime(),
//				timeLimit.get_relativeAreaOpenTime(),
//				timeLimit.get_relativeAccountOpenTime(),
//				playerNode,
//				false);
//		if (isShow && earlyShowTime < openTime_Long)
//		{
//			openTime.setTimeInMillis(earlyShowTime);
//
//		}
//		else
//		{
//			openTime.setTimeInMillis(openTime_Long);
//		}
//
//		// 关闭时间取小日期
//		Calendar closeTime = Calendar.getInstance();
//		long closeTime_Long =
//			TimeRange.fixAndSelectRightTime(timeLimit.get_closeTime(),
//				timeLimit.get_relativeAreaCloseTime(),
//				timeLimit.get_relativeAccountCloseTime(),
//				playerNode,
//				true);
//		closeTime.setTimeInMillis(closeTime_Long);
//
//		// 如果没有配置关闭时间,并且当前时间大于开启时间,那么该状态开启
//		if (closeTime_Long == 0)
//		{
//			if (now.after(openTime))
//			{
//				return true;
//			}
//			else
//			{
//				return false;
//			}
//		}
//		// 如果没有配置开启时间,并且当前时间大于关闭时间,那么该状态开启
//		if (openTime_Long == 0)
//		{
//			if (now.before(closeTime))
//			{
//				return true;
//			}
//			else
//			{
//				return false;
//			}
//		}
//		// 有开启和关闭时间,那么处理周期
//		switch (timeLimit.get_timeDurationType())
//		{
//			case _TimeDurationType.Unknown:
//				if (now.after(openTime) && now.before(closeTime))
//				{
//					result = true;
//				}
//				break;
//			case _TimeDurationType.Era:
//				if (now.after(openTime) && now.before(closeTime))
//				{
//					result = true;
//				}
//				break;
//
//			case _TimeDurationType.Day:
//				// 将三个时间的年月日赋予相同值,以便比较
//				openTime.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH));
//				closeTime.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH));
//				now.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH));
//
//				if (now.after(openTime) && now.before(closeTime))
//				{
//					result = true;
//				}
//				break;
//
//			case _TimeDurationType.Year:
//				openTime.set(Calendar.YEAR, now.get(Calendar.YEAR));
//				closeTime.set(Calendar.YEAR, now.get(Calendar.YEAR));
//				now.set(Calendar.YEAR, now.get(Calendar.YEAR));
//
//				if (now.after(openTime) && now.before(closeTime))
//				{
//					result = true;
//				}
//				break;
//
//			case _TimeDurationType.Month:
//				openTime.set(Calendar.YEAR, now.get(Calendar.YEAR));
//				closeTime.set(Calendar.YEAR, now.get(Calendar.YEAR));
//				now.set(Calendar.YEAR, now.get(Calendar.YEAR));
//				openTime.set(Calendar.MONTH, now.get(Calendar.MONTH));
//				closeTime.set(Calendar.MONTH, now.get(Calendar.MONTH));
//				now.set(Calendar.MONTH, now.get(Calendar.MONTH));
//
//				if (now.after(openTime) && now.before(closeTime))
//				{
//					result = true;
//				}
//				break;
//
//			case _TimeDurationType.Week:
//				openTime.set(Calendar.YEAR, now.get(Calendar.YEAR));
//				closeTime.set(Calendar.YEAR, now.get(Calendar.YEAR));
//				now.set(Calendar.YEAR, now.get(Calendar.YEAR));
//				openTime.set(Calendar.MONTH, now.get(Calendar.MONTH));
//				closeTime.set(Calendar.MONTH, now.get(Calendar.MONTH));
//				now.set(Calendar.MONTH, now.get(Calendar.MONTH));
//				openTime.set(Calendar.WEEK_OF_MONTH, now.get(Calendar.WEEK_OF_MONTH));
//				closeTime.set(Calendar.WEEK_OF_MONTH, now.get(Calendar.WEEK_OF_MONTH));
//				now.set(Calendar.WEEK_OF_MONTH, now.get(Calendar.WEEK_OF_MONTH));
//
//				if (now.after(openTime) && now.before(closeTime))
//				{
//					result = true;
//				}
//				break;
//
//			default:
//				break;
//		}
//
//		return result;
//	}
//
//	public static boolean isSameGoodStatus(GoodStatusConfig.TimeLimit timeLimit, String buyGoodsTime, PlayerNode playerNode,boolean isShow)
//	{
//		boolean result = false;
//		if (isGoodStatusOpen(timeLimit, playerNode,isShow))
//		{
//			if (timeLimit.get_closeTime().equals("") && timeLimit.get_openTime().equals("")
//				&& timeLimit.get_relativeAreaCloseTime().equals("") && timeLimit.get_relativeAreaOpenTime().equals("")
//				&& timeLimit.get_relativeAccountOpenTime().equals("")
//				&& timeLimit.get_relativeAreaCloseTime().equals(""))
//			{
//				return true;
//			}
//
//			Calendar now = Calendar.getInstance();
//			now.setTimeZone(TimeZone.getTimeZone(ServerUtil.getTimeZoneStringFromInt(TimeZoneData.getTimeZone())));
//
//			Calendar buyGood = Calendar.getInstance();
//			buyGood.setTimeInMillis(ServerUtil.convertTimeStringWithTimezoneToLong(TimeZoneData.getTimeZone(),
//				buyGoodsTime));
//
//			Calendar openTime = Calendar.getInstance();
//			long openTime_Long =
//				TimeRange.fixAndSelectRightTime(timeLimit.get_openTime(),
//					timeLimit.get_relativeAreaOpenTime(),
//					timeLimit.get_relativeAccountOpenTime(),
//					playerNode,
//					false);
//			openTime.setTimeInMillis(openTime_Long);
//
//			Calendar closeTime = Calendar.getInstance();
//			long closeTime_Long =
//				TimeRange.fixAndSelectRightTime(timeLimit.get_closeTime(),
//					timeLimit.get_relativeAreaCloseTime(),
//					timeLimit.get_relativeAccountCloseTime(),
//					playerNode,
//					true);
//			closeTime.setTimeInMillis(closeTime_Long);
//
//			// 如果没有配置关闭时间,并且当前时间大于开启时间,那么该状态开启
//			if (closeTime_Long == 0)
//			{
//				if (buyGood.after(openTime))
//				{
//					return true;
//				}
//				else
//				{
//					return false;
//				}
//			}
//			// 如果没有配置开启时间,并且当前时间大于关闭时间,那么该状态开启
//			if (openTime_Long == 0)
//			{
//				if (buyGood.before(closeTime))
//				{
//					return true;
//				}
//				else
//				{
//					return false;
//				}
//			}
//			// 有开启和关闭时间,那么处理周期
//			// 如果是按天循环,如果昨天买的,今天查询,那么会返回false;
//			switch (timeLimit.get_timeDurationType())
//			{
//				case _TimeDurationType.Unknown:
//					if (buyGood.after(openTime) && buyGood.before(closeTime))
//					{
//						result = true;
//					}
//					break;
//
//				case _TimeDurationType.Era:
//					if (buyGood.after(openTime) && buyGood.before(closeTime))
//					{
//						result = true;
//					}
//					break;
//
//				case _TimeDurationType.Day:
//					openTime.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH));
//					closeTime.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH));
//					now.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH));
//
//					if (buyGood.after(openTime) && buyGood.before(closeTime))
//					{
//						result = true;
//					}
//					break;
//
//				case _TimeDurationType.Year:
//					openTime.set(Calendar.YEAR, now.get(Calendar.YEAR));
//					closeTime.set(Calendar.YEAR, now.get(Calendar.YEAR));
//					now.set(Calendar.YEAR, now.get(Calendar.YEAR));
//
//					if (buyGood.after(openTime) && buyGood.before(closeTime))
//					{
//						result = true;
//					}
//					break;
//
//				case _TimeDurationType.Month:
//					openTime.set(Calendar.YEAR, now.get(Calendar.YEAR));
//					closeTime.set(Calendar.YEAR, now.get(Calendar.YEAR));
//					now.set(Calendar.YEAR, now.get(Calendar.YEAR));
//					openTime.set(Calendar.MONTH, now.get(Calendar.MONTH));
//					closeTime.set(Calendar.MONTH, now.get(Calendar.MONTH));
//					now.set(Calendar.MONTH, now.get(Calendar.MONTH));
//
//					if (buyGood.after(openTime) && buyGood.before(closeTime))
//					{
//						result = true;
//					}
//					break;
//
//				case _TimeDurationType.Week:
//					openTime.set(Calendar.YEAR, now.get(Calendar.YEAR));
//					closeTime.set(Calendar.YEAR, now.get(Calendar.YEAR));
//					now.set(Calendar.YEAR, now.get(Calendar.YEAR));
//					openTime.set(Calendar.MONTH, now.get(Calendar.MONTH));
//					closeTime.set(Calendar.MONTH, now.get(Calendar.MONTH));
//					now.set(Calendar.MONTH, now.get(Calendar.MONTH));
//					openTime.set(Calendar.WEEK_OF_MONTH, now.get(Calendar.WEEK_OF_MONTH));
//					closeTime.set(Calendar.WEEK_OF_MONTH, now.get(Calendar.WEEK_OF_MONTH));
//					now.set(Calendar.WEEK_OF_MONTH, now.get(Calendar.WEEK_OF_MONTH));
//
//					if (buyGood.after(openTime) && buyGood.before(closeTime))
//					{
//						result = true;
//					}
//					break;
//
//				default:
//					break;
//			}
//		}
//
//		return result;
//	}
//
//	public static long getGoodsTime(String absoluteTimestr, String relativeAreaTime, String relativeAccountTime,
//		PlayerNode playerNode, boolean returnSmaller, int timeDurationType)
//	{
//		if ((absoluteTimestr == null || absoluteTimestr.equals(""))
//			&& (relativeAreaTime == null || relativeAreaTime.equals("")
//				&& (relativeAccountTime == null || relativeAccountTime.equals(""))))
//		{
//			return 0;
//		}
//
//		Calendar goodsTime = Calendar.getInstance();
//		Calendar now = Calendar.getInstance();
//		switch (timeDurationType)
//		{
//			case _TimeDurationType.Era:
//				goodsTime.setTimeInMillis(TimeRange.fixAndSelectRightTime(absoluteTimestr,
//					relativeAreaTime,
//					relativeAccountTime,
//					playerNode,
//					returnSmaller));
//				break;
//
//			case _TimeDurationType.Day:
//				goodsTime.setTimeInMillis(TimeRange.fixAndSelectRightTime(absoluteTimestr,
//					relativeAreaTime,
//					relativeAccountTime,
//					playerNode,
//					returnSmaller));
//				goodsTime.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH));
//				break;
//
//			case _TimeDurationType.Year:
//				goodsTime.setTimeInMillis(TimeRange.fixAndSelectRightTime(absoluteTimestr,
//					relativeAreaTime,
//					relativeAccountTime,
//					playerNode,
//					returnSmaller));
//				goodsTime.set(Calendar.YEAR, now.get(Calendar.YEAR));
//				break;
//
//			case _TimeDurationType.Month:
//				goodsTime.setTimeInMillis(TimeRange.fixAndSelectRightTime(absoluteTimestr,
//					relativeAreaTime,
//					relativeAccountTime,
//					playerNode,
//					returnSmaller));
//				goodsTime.set(Calendar.YEAR, now.get(Calendar.YEAR));
//				goodsTime.set(Calendar.MONTH, now.get(Calendar.MONTH));
//				break;
//
//			case _TimeDurationType.Week:
//				goodsTime.setTimeInMillis(TimeRange.fixAndSelectRightTime(absoluteTimestr,
//					relativeAreaTime,
//					relativeAccountTime,
//					playerNode,
//					returnSmaller));
//				goodsTime.set(Calendar.YEAR, now.get(Calendar.YEAR));
//				goodsTime.set(Calendar.MONTH, now.get(Calendar.MONTH));
//				goodsTime.set(Calendar.WEEK_OF_MONTH, now.get(Calendar.WEEK_OF_MONTH));
//				break;
//
//			default:
//				break;
//		}
//
//		return goodsTime.getTimeInMillis();
//	}

	// 修正绝对时间和相对时间,返回其中一个大的,或小的(由 returnSmaller决定)
	public static long fixAndSelectRightTime(String absoluteTimestr, String relativeAreaTime,
		String relativeAccountTime, PlayerNode playerNode, boolean returnSmaller)
	{
		List<Long> fixTime = new ArrayList<Long>();
		// 绝对时间
		if (absoluteTimestr != null && !absoluteTimestr.equals(""))
		{
			fixTime.add(ServerUtil.convertTimeStringWithTimezoneToLong(TimeZoneData.getTimeZone(), absoluteTimestr));
		}
		// 相对开区时间
		long areaStartTime = AreaData.getAreaStartTimeMS();
		if (relativeAreaTime != null && !relativeAreaTime.equals(""))
		{
			fixTime.add(xmlConfig.parseTimeString(relativeAreaTime,
				"0-0-0 0:0:0",
				areaStartTime,
				TimeZoneData.getTimeZone()));
		}
		// 相对建号时间
		long accountCreateTime = playerNode.getPlayerInfo().getClientLoginMessage().getCreateTime();
		if (relativeAccountTime != null && !relativeAccountTime.equals(""))
		{
			fixTime.add(xmlConfig.parseTimeString(relativeAccountTime,
				"0-0-0 0:0:0",
				accountCreateTime,
				TimeZoneData.getTimeZone()));
		}
		if (fixTime.size() == 0)
		{
			return 0;
		}
		else
		{
			if (returnSmaller)
			{
				return Collections.min(fixTime);
			}
			else
			{
				return Collections.max(fixTime);
			}
		}
	}
	public static long fixAndSelectRightTimeEx(String absoluteTimeStr, 
			Long relativeBasedAbsoluteTime, String relativeTime, boolean returnSmaller)
		{
			List<Long> fixTime = new ArrayList<Long>();
			
			// 绝对时间
			if (absoluteTimeStr != null && !absoluteTimeStr.equals(""))
			{
				fixTime.add(ServerUtil.convertTimeStringWithTimezoneToLong(TimeZoneData.getTimeZone(), absoluteTimeStr));
			}
			
			// 相对时间
			if (relativeTime != null && !relativeTime.equals(""))
			{
				fixTime.add(xmlConfig.parseTimeString(relativeTime,
					"0-0-0 0:0:0",
					relativeBasedAbsoluteTime,
					TimeZoneData.getTimeZone()));
			}
			
			if (fixTime.size() == 0)
			{
				return 0;
			}
			else
			{
				if (returnSmaller)
				{
					return Collections.min(fixTime);
				}
				else
				{
					return Collections.max(fixTime);
				}
			}
		}
		public static long fixAndSelectRightTimeEx(Long absoluteTimeMillion, 
			Long relativeBasedAbsoluteTime, String relativeTime, boolean returnSmaller)
		{
			List<Long> fixTime = new ArrayList<Long>();
			
			// 绝对时间
			fixTime.add(absoluteTimeMillion);
			// 相对时间的基准时间 
			if (relativeTime != null && !relativeTime.equals(""))
			{
				fixTime.add(xmlConfig.parseTimeString(relativeTime,
					"0-0-0 0:0:0",
					relativeBasedAbsoluteTime,
					TimeZoneData.getTimeZone()));
			}
			
			if (fixTime.size() == 0)
			{
				return 0;
			}
			else
			{
				if (returnSmaller)
				{
					return Collections.min(fixTime);
				}
				else
				{
					return Collections.max(fixTime);
				}
			}
		}
	
}
