package com.kodgames.corgi.server.common;

public class Range {

	private String SuffixName = null;
	private int start;
	private int end;
     
	public Range(String SuffixName, int start, int end)
	{
		this.start = start;
		this.end = end;
		this.SuffixName = SuffixName;
	}
	
	public String getSuffixName() {
		return SuffixName;
	}
	public void setSuffixName(String suffixName) {
		SuffixName = suffixName;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getEnd() {
		return end;
	}
	public void setEnd(int end) {
		this.end = end;
	}

}
