package com.kodgames.corgi.server.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import com.kodgames.corgi.gameconfiguration.AppPath;
import com.kodgames.gamedata.xml.IXmlLoader;
import com.kodgames.gamedata.xml.xmlConfig;


public class DBServerConfigMgr implements IXmlLoader
{
	private static final DBServerConfigMgr dbServerConfigMgr = new DBServerConfigMgr();
	
	private ArrayList<Range> ranges = new ArrayList<Range>();
	private DBServerConfig accountDBConfig = null;
	private DBServerConfig managerDBConfig = null;
	private DBServerConfig purchaseDBConfig = null;
	private List<AreaDBCluster> areaDBClusterList = new ArrayList<AreaDBCluster>();
	private Element rootElement = null;
	
	public synchronized String asXML()
	{
		return this.rootElement.asXML();
	}
	
	private DBServerConfigMgr ()
	{
	}

	public static DBServerConfigMgr getInstance() 
	{
		return dbServerConfigMgr;
	}
	
	public synchronized boolean reload()
	{
		boolean ret = xmlConfig.load(AppPath.file_DBServer, this);
		return ret;
	}
	
	public synchronized void load(String dbServerXML, int placeHolder)throws DocumentException 
	{
		Document document = DocumentHelper.parseText(dbServerXML);
		this.rootElement = document.getRootElement();
		reload(rootElement);
	}

	
	@Override
	public synchronized boolean reload(Element root) 
	{
		this.rootElement = root;
		
		Element playerDBSelector = root.element("PlayerDBSelector");
		List<Element> ranges = playerDBSelector.elements("Range");
		this.ranges.clear();
		for(Element range: ranges)
		{
			this.ranges.add(parseRangeDB(range));
		}
		
		Element accountDBElement = root.element("AccountDB");
		this.accountDBConfig = parseDB(accountDBElement);

		Element managerDBElement = root.element("ManagerDB");
		this.managerDBConfig = parseDB(managerDBElement);
		
		Element purchaseDBElement = root.element("PurchaseDB");
		this.purchaseDBConfig = parseDB(purchaseDBElement);

		List<Element> areaElements = root.elements("AreaDBCluster");
		this.areaDBClusterList.clear();
		for (Element areaCfg : areaElements)
		{
			AreaDBCluster areaDBCluster = new AreaDBCluster();
			areaDBCluster.setAreaId(Integer.parseInt(areaCfg.attributeValue("AreaId")));
			areaDBCluster.setGameDBConfig(parseDB(areaCfg.element("GameDB")));
			areaDBCluster.setLogDBConfig(parseDB(areaCfg.element("LogDB")));
			
			areaDBClusterList.add(areaDBCluster);
		}

		return true;
	}
	
	private DBServerConfig parseDB(Element dbElement)
	{
		HashMap<String, String> kv = xmlConfig.getAttribute(dbElement);
		String Jdbc = xmlConfig.parseStr(kv.get("JdbcUrl"), "");
		String UserName = xmlConfig.parseStr(kv.get("UserName"), "");
		String Password = xmlConfig.parseStr(kv.get("Password"), "");

		DBServerConfig dbConfig = new DBServerConfig(Jdbc, UserName, Password);
		return dbConfig;
	}
	
	private Range parseRangeDB(Element rangeElement)
	{
		String suffixName = rangeElement.attributeValue("SuffixName");
		int start = Integer.parseInt(rangeElement.attributeValue("Start"),16);
		int end = Integer.parseInt(rangeElement.attributeValue("End"),16);
		Range range = new Range(suffixName, start ,end);
		return range;
	}

	public synchronized DBServerConfig getAccountDBConfig() 
	{
		return this.accountDBConfig;
	}

	public synchronized DBServerConfig getManagerDBConfig()
	{
		return managerDBConfig;
	}
	
	public synchronized List<AreaDBCluster> getAreaDBClusterList() 
	{
		return areaDBClusterList;
	}
	
	public synchronized DBServerConfig getPurchaseDBConfig() {
		return purchaseDBConfig;
	}

	public synchronized ArrayList<Range> getRanges()
	{
		return ranges;
	}


	@Override
	public synchronized boolean reloadFromMemory(String key, String value)
	{
		return xmlConfig.loadFromMemory(value, this);
	}	
}
