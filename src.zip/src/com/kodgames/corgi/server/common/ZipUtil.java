/*
 * 文 件 名:  ZipUtil.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:  <描述>
 * 创 建 人:  <创建人>
 * 创建时间:  2014年8月18日
 * 修 改 人:  <修改人>
 * 修改时间:  2014年8月18日
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.common;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * 将一个字符串按照zip方式压缩和解压缩
 * 
 */
public class ZipUtil
{
	/*
	 * 压缩
	 */
	public static String compress(String str)
		throws IOException
	{
		if (str == null || str.length() == 0)
		{
			return str;
		}
		ByteArrayOutputStream out = null;
		GZIPOutputStream gzip = null;
		try
		{
			out = new ByteArrayOutputStream();
			gzip = new GZIPOutputStream(out);
			gzip.write(str.getBytes());
			gzip.finish();
			gzip.flush();
			out.flush();
		}
		catch (IOException e)
		{
			throw e;
		}
		finally
		{
			if (gzip != null)
			{
				try
				{
					gzip.close();
				}
				catch (IOException ex)
				{
					throw ex;
				}
			}

			if (out != null)
			{
				try
				{
					out.close();
				}
				catch (IOException ex)
				{
					throw ex;
				}
			}
		}

		return out.toString("ISO-8859-1");
	}

	/*
	 * 解压缩
	 */
	public static String uncompress(String str)
		throws IOException
	{
		if (str == null || str.length() == 0)
		{
			return str;
		}
		ByteArrayOutputStream out = null;
		ByteArrayInputStream in = null;
		GZIPInputStream gzip = null;
		try
		{
			out = new ByteArrayOutputStream();
			in = new ByteArrayInputStream(str.getBytes("ISO-8859-1"));
			gzip = new GZIPInputStream(in);
			byte[] buffer = new byte[256];
			int n;
			while ((n = gzip.read(buffer)) >= 0)
			{
				out.write(buffer, 0, n);
			}
			out.flush();
		}
		catch (IOException e)
		{
			throw e;
		}
		finally
		{
			if (gzip != null)
			{
				try
				{
					gzip.close();
				}
				catch (IOException ex)
				{
					throw ex;
				}
			}

			if (in != null)
			{
				try
				{
					in.close();
				}
				catch (IOException ex)
				{
					throw ex;
				}
			}

			if (out != null)
			{
				try
				{
					out.close();
				}
				catch (IOException ex)
				{
					throw ex;
				}
			}
		}

		// toString()使用平台默认编码，也可以显式的指定如toString("GBK")
		return out.toString();
	}
}