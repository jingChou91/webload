package com.kodgames.corgi.server.common;

import java.util.HashSet;
import java.util.List;

import org.dom4j.Element;

import com.kodgames.corgi.gameconfiguration.AppPath;
import com.kodgames.gamedata.xml.IXmlLoader;
import com.kodgames.gamedata.xml.xmlConfig;

public class StatisticsConfigMgr implements IXmlLoader
{
	private static StatisticsConfigMgr statisticsConfigMgr = new StatisticsConfigMgr();
	private HashSet<Integer> itemIdSet = new HashSet<>();
	private HashSet<Integer> specialIdSet = new HashSet<>();
	private HashSet<Integer> skillQualitySet = new HashSet<>();
	private HashSet<Integer> avatarQualitySet = new HashSet<>();
	private HashSet<Integer> equipQualitySet = new HashSet<>();
	
	public static StatisticsConfigMgr getInstance() 
	{
		return statisticsConfigMgr;
	}
	
	public boolean init()
	{
		reload();
		return true;
	}

	private boolean reload()
	{
		boolean ret = xmlConfig.load(AppPath.file_statistics, this);
		return ret;
	}

	@Override
	public boolean reload(Element root) 
	{
		HashSet<Integer> itemIdSet_temp = new HashSet<>();
		HashSet<Integer> specialIdSet_temp = new HashSet<>();
		HashSet<Integer> avatarIdSet_temp = new HashSet<>();
		HashSet<Integer> skillIdSet_temp = new HashSet<>();
		HashSet<Integer> equipIdSet_temp = new HashSet<>();
		
		Element xml_itemIdSet = root.element("ItemIdList");
		Element xml_specialIdSet = root.element("SpecialIdList");
		Element xml_skillIdSet = root.element("SkillQuality");
		Element xml_equipIdSet = root.element("EquipQuality");
		Element xml_avatarIdSet = root.element("AvatarQuality");
		
		List<Element> itemIds = xml_itemIdSet.elements("Id");
		for (Element tempE : itemIds) 
		{
			int id = xmlConfig.parseHexInt(tempE.getStringValue(), 0);
			itemIdSet_temp.add(id);
		}
		
		List<Element> specialIds = xml_specialIdSet.elements("Id");
		for (Element tempE : specialIds) 
		{
			int id = xmlConfig.parseHexInt(tempE.getStringValue(), 0);
			specialIdSet_temp.add(id);
		}
		
		List<Element> skillIds = xml_skillIdSet.elements("Id");
		for (Element tempE : skillIds) 
		{
			int id = xmlConfig.parseInt(tempE.getStringValue(), 0);
			skillIdSet_temp.add(id);
		}
		
		List<Element> avatarIds = xml_avatarIdSet.elements("Id");
		for (Element tempE : avatarIds) 
		{
			int id = xmlConfig.parseInt(tempE.getStringValue(), 0);
			avatarIdSet_temp.add(id);
		}
		
		List<Element> equipIds = xml_equipIdSet.elements("Id");
		for (Element tempE : equipIds) 
		{
			int id = xmlConfig.parseInt(tempE.getStringValue(), 0);
			equipIdSet_temp.add(id);
		}
		
		
		itemIdSet = itemIdSet_temp;
		specialIdSet = specialIdSet_temp;
		avatarQualitySet = avatarIdSet_temp;
		skillQualitySet = skillIdSet_temp;
		equipQualitySet = equipIdSet_temp;
		return true;
	}
	
	public boolean containItemId(int id)
	{
		return itemIdSet.contains(id);
	}
	
	public boolean containSpecialId(int id)
	{
		return specialIdSet.contains(id);
	}
	
	public boolean containAvatarQuality(int quality)
	{
		return avatarQualitySet.contains(quality);
	}
	
	public boolean containSkillQuality(int quality)
	{
		return skillQualitySet.contains(quality);
	}
	
	public boolean containEquipQuality(int quality)
	{
		return equipQualitySet.contains(quality);
	}

	@Override
	public boolean reloadFromMemory(String key, String value)
	{
		return xmlConfig.loadFromMemory(value, this);
	}

}
