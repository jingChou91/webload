/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.common;

import java.sql.SQLException;

import org.dom4j.DocumentException;

import com.kodgames.corgi.protocol.Protocols;
import com.kodgames.corgi.server.dbclient.DBClient;

/**
 * 
 * @author Elvin
 */
public class DBCluster
{	
	private DBClient gameDBClient = null;
	private DBClient logDBClient = null;
	private DBClient accountDBClient = null;
	private DBClient managerDbClient = null;
	private DBClient purchaseDbClient = null;

	public DBCluster(String dbServerXML, int areaId, int serverType)
		throws SQLException, DocumentException, ClassNotFoundException
	{
		DBServerConfigMgr.getInstance().load(dbServerXML, 0);
		initialize(DBServerConfigMgr.getInstance(), areaId, serverType);
	}

	private void initialize(DBServerConfigMgr dbServerConfigMgr, int areaId, int serverType)
		throws SQLException, ClassNotFoundException
	{

		if (serverType == Protocols.SERVER_TYPE_AUTH || serverType == Protocols.SERVER_TYPE_MANAGE)
		{
			this.accountDBClient =
				new DBClient(dbServerConfigMgr.getAccountDBConfig().getJdbcUrl(),
					dbServerConfigMgr.getAccountDBConfig().getUserName(), dbServerConfigMgr.getAccountDBConfig()
						.getPassword(), 1, 0, 20, 1);
		}

		if (serverType == Protocols.SERVER_TYPE_AUTH || serverType == Protocols.SERVER_TYPE_MANAGE || serverType == Protocols.SERVER_TYPE_GAME)
		{
			this.managerDbClient =
				new DBClient(dbServerConfigMgr.getManagerDBConfig().getJdbcUrl(),
					dbServerConfigMgr.getManagerDBConfig().getUserName(), dbServerConfigMgr.getManagerDBConfig()
						.getPassword(), 1, 0, 10, 1);
		}
		
		if(serverType == Protocols.SERVER_TYPE_PURCHASE)
		{
			this.purchaseDbClient =
					new DBClient(dbServerConfigMgr.getPurchaseDBConfig().getJdbcUrl(),
							dbServerConfigMgr.getPurchaseDBConfig().getUserName(), dbServerConfigMgr.getPurchaseDBConfig()
							.getPassword());
		}

		TableSelect.initialize(dbServerConfigMgr.getRanges());

		for (AreaDBCluster areaDBCluster : dbServerConfigMgr.getAreaDBClusterList())
		{
			if (areaDBCluster.getAreaId() == areaId)
			{
				if (serverType == Protocols.SERVER_TYPE_GAME)
				{
					gameDBClient =
						new DBClient(areaDBCluster.getGameDBConfig().getJdbcUrl(), areaDBCluster.getGameDBConfig()
							.getUserName(), areaDBCluster.getGameDBConfig().getPassword(), 4, 3, 20, 5);
					logDBClient =
						new DBClient(areaDBCluster.getLogDBConfig().getJdbcUrl(), areaDBCluster.getLogDBConfig()
							.getUserName(), areaDBCluster.getLogDBConfig().getPassword());
				}
				break;
			}
		}
	}

	public DBClient getManagerDbClient()
	{
		return managerDbClient;
	}

	public DBClient getGameDBClient()
	{
		return gameDBClient;
	}

	public DBClient getPurchaseDbClient() {
		return purchaseDbClient;
	}

	public DBClient getLogDBClient()
	{
		return logDBClient;
	}

	public DBClient getAccountDBClient()
	{
		return this.accountDBClient;
	}
}
