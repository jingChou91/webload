/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.common;

import java.text.NumberFormat;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.hyperic.sigar.SigarException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.protocol.ManageProtocolsForServer;
import com.kodgames.corgi.server.dbclient.DBWriter;

/**
 *
 * @author Elvin
 */
public class StatisticsRunnable extends LoopRunnable
{

	private static final Logger logger = LoggerFactory.getLogger("StatisticsRunnable");
	
	public StatisticsRunnable()
	{
		super(BaseServerData.statisticsInterval * 1000);
	}
	
	@Override
	public void execute()
	{
		try
		{
			this.handleStatistics();
		} 
		catch (Exception ex)
		{
			logger.error("{}", ExceptionUtils.getStackTrace(ex));
		}
	}

	public void handleStatistics() throws SigarException
	{
		ManageProtocolsForServer.ServerStatistics.Builder statisticsBuilder = BaseServerData.statistics.getAllStatistics();
		printStatistics(statisticsBuilder.build());
	}

	public void printStatistics(ManageProtocolsForServer.ServerStatistics statistics)
	{
		this.printOverViewStatistics(statistics);
		logger.info("");
		this.printNetworkStatistics(statistics);
		logger.info("");
		String nowStr = ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(), System.currentTimeMillis(), ServerUtil.TimeWithMills);
		String time = String.format("Time: %s ", nowStr);
		logger.info("{}", time);
		logger.info("{}",DBWriter.dumpSqlNum());

	}

	private String getFormattedPercentNumber(double percent)
	{
		NumberFormat numberFormat = NumberFormat.getPercentInstance();
		numberFormat.setMaximumFractionDigits(2);
		return numberFormat.format(percent);
	}

	private void printOverViewStatistics(ManageProtocolsForServer.ServerStatistics statistics)
	{
		if (statistics == null)
		{
			return;
		}

		String title = String.format(
				"%1$-20s%2$-25s%3$-20s%4$-20s%5$-20s%6$-20s%7$-20s%8$-20s%9$-20s",
				"Name",
				"Time",
				"Cpu Percent",
				"Resident Memory",
				"Virtual Memory",
				"Shared Memory",
				"App Recveive Speed",
				"App Send Speed",
				"Online Player Count");
		logger.info("{}", title);
		
		String data = String.format(
				"%1$-20s%2$-25s%3$-20s%4$-20s%5$-20s%6$-20s%7$-20s%8$-20s%9$-20s",
				statistics.getServerName(),
				ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(), statistics.getTime(), ServerUtil.TimeWithMills),
				this.getFormattedPercentNumber(statistics.getCpuPercent()),
				this.getFormattedMemory(statistics.getResidentMemory()),
				this.getFormattedMemory(statistics.getVirtualMemory()),
				this.getFormattedMemory(statistics.getSharedMemory()),
				this.getFormattedNetworkSpeed(statistics.getAppReceiveSpeed()),
				this.getFormattedNetworkSpeed(statistics.getAppSendSpeed()),
				Integer.toString(statistics.getOnlinePlayerCount()));
		logger.info("{}", data);
	}

	private void printNetworkStatistics(ManageProtocolsForServer.ServerStatistics statistics)
	{
		if (statistics == null)
		{
			return;
		}

		String title = String.format(
				"%1$-20s%2$-25s%3$-20s%4$-20s%5$-20s",
				"Name",
				"Time",
				"IP",
				"Receive Speed",
				"Send Speed");
		logger.info(title);
		for (ManageProtocolsForServer.ServerNetworkStatistics networkStatistics : statistics.getNetworkStatisticsList())
		{
			String data = String.format(
					"%1$-20s%2$-25s%3$-20s%4$-20s%5$-20s",
					statistics.getServerName(),
					ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(), statistics.getTime(), ServerUtil.TimeWithMills),
					networkStatistics.getIp(),
					this.getFormattedNetworkSpeed(networkStatistics.getReceiveSpeed()),
					this.getFormattedNetworkSpeed(networkStatistics.getSendSpeed()));
			logger.info("{}", data);
		}
	}

	private String getFormattedMemory(long memorySize)
	{
		int sizeMB = (int)(memorySize / (1024 * 1024));
		if (1 <= sizeMB)
		{
			return sizeMB + " MB";
		}

		int sizeKB = (int)(memorySize / 1024);
		if (1 <= sizeKB)
		{
			return sizeKB + " KB";
		}

		return memorySize + " B";
	}

	private String getFormattedNetworkSpeed(int speed)
	{
		int speedMBS = speed / (1024 * 1024);
		if (1 <= speedMBS)
		{
			return speedMBS + " MB/s";
		}

		int speedKBS = speed / 1024;
		if (1 <= speedKBS)
		{
			return speedKBS + " KB/s";
		}

		return speed + " B/s";
	}
}
