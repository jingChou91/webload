package com.kodgames.corgi.server.common;

import java.util.ArrayList;
import java.util.HashMap;

import com.kodgames.gamedata.player.db.PlayerIdxDB;

/**
 * 
 * @author zhd
 */
public class TableSelect
{
	private static ArrayList<String> avatar_names = new ArrayList<>();
	private static ArrayList<String> skill_names = new ArrayList<>();
	private static ArrayList<String> equipment_names = new ArrayList<>();
	private static ArrayList<String> avatar_basic_names = new ArrayList<>();
	private static ArrayList<String> skill_basic_names = new ArrayList<>();
	private static ArrayList<String> equipment_basic_names = new ArrayList<>();
	private static ArrayList<Range> ranges = new ArrayList<Range>();
	private static HashMap<Integer, Integer> playerId2PlayerIdx = new HashMap<Integer, Integer>();
	public static int playerIdxMax = 0;

	public static void initialize(ArrayList<Range> rangesTemp)
	{
		ranges = rangesTemp;
		for (Range range : ranges)
		{
			avatar_names.add("avatar" + range.getSuffixName());
			skill_names.add("skill" + range.getSuffixName());
			equipment_names.add("equipment" + range.getSuffixName());
			avatar_basic_names.add("avatar_basic" + range.getSuffixName());
			skill_basic_names.add("skill_basic" + range.getSuffixName());
			equipment_basic_names.add("equipment_basic" + range.getSuffixName());
		}

	}

	public synchronized static void initializePlayerIdx()
	{
		playerId2PlayerIdx = PlayerIdxDB.loadAllPlayerIdx();
	}

	public static HashMap<Integer, Integer> getAllPlayerIdx()
	{
		return playerId2PlayerIdx;
	}

	public static String get_avatar(int playerId)
	{
		int index = getIndex(playerId);
		return avatar_names.get(index);
	}

	public static String get_skill(int playerId)
	{
		int index = getIndex(playerId);
		return skill_names.get(index);
	}

	public static String get_equipment(int playerId)
	{
		int index = getIndex(playerId);
		return equipment_names.get(index);
	}
	
	public static String get_avatar_basic(int playerId)
	{
		int index = getIndex(playerId);
		return avatar_basic_names.get(index);
	}

	public static String get_skill_basic(int playerId)
	{
		int index = getIndex(playerId);
		return skill_basic_names.get(index);
	}

	public static String get_equipment_basic(int playerId)
	{
		int index = getIndex(playerId);
		return equipment_basic_names.get(index);
	}

	public static synchronized void addPlayerIndex(int playerId, int playerIdx)
	{
		playerIdxMax++;
		playerId2PlayerIdx.put(playerId, playerIdx);
	}

	public static synchronized int getIndex(int playerId)
	{

		int result = -1;
		Integer Idx = playerId2PlayerIdx.get(playerId);

		if (Idx != null)
		{
			int i = -1;
			for (Range range : ranges)
			{
				++i;
				if (Idx >= range.getStart() && Idx <= range.getEnd())
				{
					return i;
				}
			}
			result = i;
		}

		return result;
	}

	public static int getTotalRangesNum()
	{
		return ranges.size();
	}
}
