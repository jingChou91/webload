package com.kodgames.corgi.server.common;

//暴走武侠遗留平台标识，暂时不用
public class AccountType 
{
	public static final int LOCAL_ACCOUNT_ROBOT = 0;
	public static final int LOCAL_ACCOUNT = 1;
	public static final int KUNLUN_ACCOUNT = 2;
	public static final int QIHOO360_ACCOUNT = 3;
	public static final int UC_ACCOUNT = 4;
	public static final int OPPO_ACCOUNT = 5;
	public static final int DK_ACCOUNT = 6; //多酷
	public static final int WDJ_ACCOUNT = 7;//豌豆荚
	public static final int XM_ACCOUNT = 8;//小米
	public static final int DOWNJOY_ACCOUNT = 9;//当乐
	public static final int ND91_ACCOUNT = 10;//网龙91
	public static final int XXWAN_ACCOUNT = 11;//梦想手游
	public static final int JINSHAN_ACCOUNT = 12;//金山
	public static final int KUAIBO_ACCOUNT = 13;//快播
	public static final int KUNLUN_ANDROID_ACCOUNT = 14;//昆仑安卓
	public static final int ANZHI_ACCOUNT = 15;//安智
	public static final int CY_AGGREGATE = 16;//畅游
	public static final int CMGE_ACCOUNT = 17; //中手游
	public static final int EFUN_ACCOUONT = 18; //易幻手游
}
