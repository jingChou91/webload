package com.kodgames.corgi.server.common;

public class GenNewPlayerType 
{
	public static final int GenNewPlayer_ForNormal=0;
	public static final int GenNewPlayer_Version1=1;
	public static final int GenNewPlayer_StressTest=2;
	public static final int GenNewPlayer_ConfigXml=3;
}
