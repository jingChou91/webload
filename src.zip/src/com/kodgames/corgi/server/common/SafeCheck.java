package com.kodgames.corgi.server.common;

import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.gameconfiguration.KodThreadName;

/**
 * 
 * @author Tangxiongping
 */
public class SafeCheck {
	private static final Logger logger = LoggerFactory.getLogger(SafeCheck.class);
	private ConcurrentHashMap<Long, ThreadInfo> checks = new ConcurrentHashMap<Long, ThreadInfo>();

	private static SafeCheck instance = new SafeCheck();

	public SafeCheck() {
		Thread myThread = new Thread(new KOD_SafeCheckRunnable(), KodThreadName.genName("KOD_SafeCheckRunnable"));
		myThread.start();
	}

	public static SafeCheck getInstance() {
		return instance;
	}

	private static class ThreadInfo {
		private long threadId;
		private ArrayList<Integer> ids = new ArrayList<Integer>();
		private long time;
		private String threadName;

		private ThreadInfo(long threadId) {
			this.threadId=threadId;
			this.time = System.currentTimeMillis();
			this.threadName = Thread.currentThread().getName();
		}

		private synchronized void start(int playerId1, int playerId2) {
			ids.add(playerId1);
			ids.add(playerId2);
		}

		private synchronized void end(int playerId1, int playerId2) {
			if (ids.size() >= 2) {
				int temp_playerId2 = ids.remove(ids.size() - 1);
				int temp_playerId1 = ids.remove(ids.size() - 1);
				if (temp_playerId1 == playerId1 && temp_playerId2 == playerId2) {
					if (ids.size() == 0) {
						SafeCheck.getInstance().removeThisThreadInfo();
					}
					return;
				}
				else {
					logger.error("before_unlock check failed : not same :  playerId2={} , playerId1={}  \n{}", new Object[] { playerId2, playerId1, ExceptionUtils.getStackTrace(new Throwable()) });
				}
			}
			else {
				logger.error("before_unlock check failed : ids={} : playerId2={} , playerId1={}  \n{}", new Object[] { ids, playerId2, playerId1, ExceptionUtils.getStackTrace(new Throwable()) });
			}
		}

		private synchronized StringBuffer getDump() {
			StringBuffer sb = new StringBuffer();
			long nowMS = System.currentTimeMillis();
			if (Math.abs(time - nowMS) > 4000) {
				sb.append("\t * ThreadName=" + threadName + " threadid=" + threadId + " ids=" + ids);
			}
			else {
				sb.append("\t   ThreadName=" + threadName + " threadid=" + threadId + " ids=" + ids);
			}
			return sb;
		}

		private synchronized boolean didLock() {
			return ids.size() > 0;
		}
	}

	private synchronized ThreadInfo getThreadInfo() {
		long id = Thread.currentThread().getId();
		ThreadInfo info = checks.get(id);
		if (info == null) {
			info = new ThreadInfo(id);
			checks.put(id, info);
		}
		return info;
	}

	private synchronized ThreadInfo getRealThreadInfo() {
		long id = Thread.currentThread().getId();
		ThreadInfo info = checks.get(id);
		return info;
	}

	public StringBuffer getDump() {
		StringBuffer sb = new StringBuffer();
		TreeMap<Long, ThreadInfo> mapInfo = new TreeMap<Long, ThreadInfo>();
		for (Entry<Long, ThreadInfo> kv : checks.entrySet()) {
			mapInfo.put(kv.getKey(), kv.getValue());
		}

		sb.append("SafeCheck dump------size="+mapInfo.size()+"\n");
		for (Entry<Long, ThreadInfo> kv : mapInfo.entrySet()) {
			sb.append("\t");
			sb.append(kv.getValue().getDump());
			sb.append("\n");
		}

		return sb;
	}

	public static class KOD_SafeCheckRunnable extends LoopRunnable {

		public KOD_SafeCheckRunnable(){
			super(60000L); 
		}
		
		@Override
		public void execute() {
			//StringBuffer sb = SafeCheck.getInstance().getDump();
			//logger.info(sb.toString());			
		}
	}

	private synchronized void removeThisThreadInfo() {
		long id = Thread.currentThread().getId();
		checks.remove(id);
	}

	public void start(int playerId1, int playerId2) {
		try {
			ThreadInfo info = getThreadInfo();
			if (info != null) {
				info.start(playerId1, playerId2);
			}
		}
		catch (Exception e) {
			logger.error("{}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
		}
	}

	public void end(int playerId1, int playerId2) {
		try {
			ThreadInfo info = getThreadInfo();
			if (info != null) {
				info.end(playerId1, playerId2);
			}
		}
		catch (Exception e) {
			logger.error("{}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
		}
	}

	public boolean showDidLock() {
		ThreadInfo info = getRealThreadInfo();
		if (info != null && info.didLock()) {
			logger.error("ThreadInfo need unlock : {}\n{}", info.getDump(), ExceptionUtils.getStackTrace(new Throwable()));
			return true;
		}
		return false;
	}
}
