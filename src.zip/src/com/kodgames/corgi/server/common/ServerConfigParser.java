/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.common;

import java.util.HashMap;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import com.kodgames.gamedata.xml.xmlConfig;

/**
 *
 * @author Elvin
 */
public class ServerConfigParser {
	private Element serverElement = null;
	private HashMap<String, String> kvServer = new HashMap<String, String>();

	public ServerConfigParser(String ServerContent) throws DocumentException
	{
		if(ServerContent!=null)
		{
			Document document = DocumentHelper.parseText(ServerContent);
			serverElement = document.getRootElement();			
			kvServer = xmlConfig.getAttribute(serverElement);
		}
	}
	
	public String parseStr(String key){
		String ret=xmlConfig.parseStr(kvServer.get(key), "");
		return ret;
	}
	
	public int parseInt(String key){
		int ret=xmlConfig.parseInt(kvServer.get(key), 0);
		return ret;
	}
	
	//判断某个key是否存在
	public boolean isExist(String key)
	{
		return null!=kvServer.get(key);
	}
	
}
