package com.kodgames.corgi.server.common;

import java.util.HashMap;

import com.kodgames.gamedata.xml.IXmlLoader;

public class StreamLoaderDispatchMgr
{
	private StreamLoaderDispatchMgr()
	{
	}

	private static StreamLoaderDispatchMgr streamLoaderDispatchMgr = new StreamLoaderDispatchMgr();

	private HashMap<String, IXmlLoader> loaderMap = new HashMap<String, IXmlLoader>();

	public static StreamLoaderDispatchMgr getInstance()
	{
		return streamLoaderDispatchMgr;
	}

	public synchronized void register(String name, IXmlLoader ixmlLoader)
	{
		loaderMap.put(name, ixmlLoader);
	}

	public synchronized boolean loadFromMeomry(String fileName, String content)
	{
		if (loaderMap.containsKey(fileName))
		{
			loaderMap.get(fileName).reloadFromMemory(fileName, content);
			return true;
		}
		return false;
	}
}
