package com.kodgames.corgi.server.common;

import com.kodgames.corgi.server.dbclient.KodLog;

public abstract class CmdProc
{

	public String uuid = null;
	protected int manual = 0;

	protected boolean needLog = true;

	public static String RET_CODE = "retCode";
	public static String RET_MSG = "retMsg";

	public void setUuid(String uuid)
	{
		this.uuid = uuid;
	}

	public void writeKodLog(Context ctx)
	{
		if (!needLog)
			return;

		int areaId = -1;
		if (ctx.paramList.get("AREA") != null)
		{
			areaId = Integer.parseInt(ctx.paramList.get("AREA"));
		}

		String username = ctx.paramList.get("USERCODE");
		KodLog.gm_log(username, KodLog.getDatetime(System.currentTimeMillis()), ctx.command, areaId);
	}

	public abstract String proc(Context ctx) throws Exception;

}
