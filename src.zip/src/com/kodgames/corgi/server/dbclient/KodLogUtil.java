package com.kodgames.corgi.server.dbclient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.AvatarConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.EquipmentConfig;
import ClientServerCommon.SkillConfig;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.CorgiUID;
import com.kodgames.corgi.gameconfiguration.AreaData;
import com.kodgames.corgi.protocol.CommonProtocols.DeviceInfo;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.avatar.data.Avatar;
import com.kodgames.corgi.server.gameserver.dan.data.Dan;
import com.kodgames.corgi.server.gameserver.dungeon.data.Dungeon;
import com.kodgames.corgi.server.gameserver.equipment.data.Equipment;
import com.kodgames.corgi.server.gameserver.skill.data.Skill;
import com.kodgames.gamedata.player.PlayerNode;

public class KodLogUtil
{
	private static final Logger logger = LoggerFactory.getLogger(KodLogUtil.class);

	public static void special_id_change(PlayerNode playerNode, Integer iEventId, Integer iSpecialId, Integer iTo,
		Integer iFrom)
	{
		if (iFrom != iTo)
		{
			KodLog.special_id_change(KodLog.getDatetime(System.currentTimeMillis()),
				iEventId,
				playerNode.getPlayerId(),
				AreaData.getAreaId(),
				playerNode.getPlayerId(),
				playerNode.getGamePlayer().getFixName(),
				playerNode.getGamePlayer().getLevel(),
				iSpecialId,
				iTo,
				iFrom,
				playerNode.getGamePlayer().getChannelId());
		}

	}

	public static void avatar_create(PlayerNode playerNode, Avatar avatar, ConfigDatabase cd, int kodEventId)
	{
		int quality = getAvatarQuality(cd, avatar);
		KodLog.avatar_create(KodLog.getDatetime(System.currentTimeMillis()),
			kodEventId,
			playerNode.getPlayerId(),
			AreaData.getAreaId(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			avatar.getGuid().toString(),
			avatar.getResourceId(),
			quality,
			avatar.getLevel(),
			avatar.getLevel(),
			avatar.getBreakthoughtLevel(),
			avatar.getBreakthoughtLevel(),
			playerNode.getGamePlayer().getChannelId());

	}

	public static void avatar_Destory(PlayerNode playerNode, Avatar avatar, ConfigDatabase cd, int kodEventId)
	{
		int quality = getAvatarQuality(cd, avatar);
		KodLog.avatar_destory(KodLog.getDatetime(System.currentTimeMillis()),
			kodEventId,
			playerNode.getPlayerId(),
			AreaData.getAreaId(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			avatar.getGuid().toString(),
			avatar.getResourceId(),
			quality,
			avatar.getLevel(),
			avatar.getLevel(),
			avatar.getBreakthoughtLevel(),
			avatar.getBreakthoughtLevel(),
			playerNode.getGamePlayer().getChannelId());

	}

	public static void avatar_breakthought(PlayerNode playerNode, Avatar avatar, ConfigDatabase cd)
	{
		int quality = getAvatarQuality(cd, avatar);
		KodLog.avatar_breakthoughlevelup(KodLog.getDatetime(System.currentTimeMillis()),
			KodLogEvent.AvatarLogic_AvatarBreakthought,
			playerNode.getPlayerId(),
			AreaData.getAreaId(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			avatar.getGuid().toString(),
			avatar.getResourceId(),
			quality,
			avatar.getLevel(),
			avatar.getLevel(),
			avatar.getBreakthoughtLevel(),
			avatar.getBreakthoughtLevel() - 1,
			1,
			playerNode.getGamePlayer().getChannelId());
	}

	public static void avatar_levelup(PlayerNode playerNode, Avatar avatar, ConfigDatabase cd, int oldLevel)
	{
		int quality = getAvatarQuality(cd, avatar);
		KodLog.avatar_levelup(KodLog.getDatetime(System.currentTimeMillis()),
			KodLogEvent.AvatarLogic_AvatarLevelUp,
			playerNode.getPlayerId(),
			AreaData.getAreaId(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			avatar.getGuid().toString(),
			avatar.getResourceId(),
			quality,
			avatar.getLevel(),
			oldLevel,
			avatar.getLevel() - oldLevel,
			avatar.getBreakthoughtLevel(),
			avatar.getBreakthoughtLevel(),
			playerNode.getGamePlayer().getChannelId());
	}

	public static void equip_create(PlayerNode playerNode, Equipment equip, ConfigDatabase cd, int kodEventId)
	{
		int quality = getEquipQuality(cd, equip);
		KodLog.equip_create(KodLog.getDatetime(System.currentTimeMillis()),
			kodEventId,
			playerNode.getPlayerId(),
			AreaData.getAreaId(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			equip.getGuid().toString(),
			equip.getResourceId(),
			quality,
			equip.getLevel(),
			equip.getLevel(),
			equip.getBreakthoughtLevel(),
			equip.getBreakthoughtLevel(),
			playerNode.getGamePlayer().getChannelId());
	}

	public static void dan_create(PlayerNode playerNode, Dan dan, ConfigDatabase cd, int kodEventId)
	{
		int quality = 0;// getEquipQuality(cd, dan);
		KodLog.dan_create(KodLog.getDatetime(System.currentTimeMillis()),
			kodEventId,
			playerNode.getPlayerId(),
			AreaData.getAreaId(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			dan.getGuid().toString(),
			dan.getResourceId(),
			quality,
			dan.getLevel(),
			dan.getLevel(),
			dan.getBreakthoughtLevel(),
			dan.getBreakthoughtLevel(),
			ServerUtil.listToString(dan.getAttributes(), "|"),
			playerNode.getGamePlayer().getChannelId());
	}

	public static void equip_destory(PlayerNode playerNode, Equipment equip, ConfigDatabase cd, int kodEventId)
	{
		int quality = getEquipQuality(cd, equip);
		KodLog.equip_destory(KodLog.getDatetime(System.currentTimeMillis()),
			kodEventId,
			playerNode.getPlayerId(),
			AreaData.getAreaId(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			equip.getGuid().toString(),
			equip.getResourceId(),
			quality,
			equip.getLevel(),
			equip.getLevel(),
			equip.getBreakthoughtLevel(),
			equip.getBreakthoughtLevel(),
			playerNode.getGamePlayer().getChannelId());
	}
	
	public static void dan_destory(PlayerNode playerNode, Dan dan, ConfigDatabase cd, int kodEventId)
	{
		int quality = 0;//getEquipQuality(cd, equip);
		KodLog.dan_destory(KodLog.getDatetime(System.currentTimeMillis()),
			kodEventId,
			playerNode.getPlayerId(),
			AreaData.getAreaId(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			dan.getGuid().toString(),
			dan.getResourceId(),
			quality,
			dan.getLevel(),
			dan.getLevel(),
			dan.getBreakthoughtLevel(),
			dan.getBreakthoughtLevel(),
			ServerUtil.listToString(dan.getAttributes(), "|"),
			playerNode.getGamePlayer().getChannelId());
	}

	public static void equip_breakthoughlevelup(PlayerNode playerNode, Equipment equip, ConfigDatabase cd)
	{
		int quality = getEquipQuality(cd, equip);
		KodLog.equip_breakthoughlevelup(KodLog.getDatetime(System.currentTimeMillis()),
			KodLogEvent.EquipLogic_EquipBreakthrough,
			playerNode.getPlayerId(),
			AreaData.getAreaId(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			equip.getGuid().toString(),
			equip.getResourceId(),
			quality,
			equip.getLevel(),
			equip.getLevel(),
			equip.getBreakthoughtLevel(),
			equip.getBreakthoughtLevel() - 1,
			1,
			playerNode.getGamePlayer().getChannelId());
	}

	public static void equip_levelup(PlayerNode playerNode, Equipment equip, ConfigDatabase cd, int oldLevel)
	{
		int quality = getEquipQuality(cd, equip);
		KodLog.equip_levelup(KodLog.getDatetime(System.currentTimeMillis()),
			KodLogEvent.EquipLogic_EquipLevelUp,
			playerNode.getPlayerId(),
			AreaData.getAreaId(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			equip.getGuid().toString(),
			equip.getResourceId(),
			quality,
			equip.getLevel(),
			oldLevel,
			equip.getLevel() - oldLevel,
			equip.getBreakthoughtLevel(),
			equip.getBreakthoughtLevel(),
			playerNode.getGamePlayer().getChannelId());
	}

	public static void skill_create(PlayerNode playerNode, Skill skill, ConfigDatabase cd, int kodEventId)
	{
		int quality = getSkillQuality(cd, skill);

		KodLog.skill_create(KodLog.getDatetime(System.currentTimeMillis()),
			kodEventId,
			playerNode.getPlayerId(),
			AreaData.getAreaId(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			skill.getGuid().toString(),
			skill.getResourceId(),
			quality,
			skill.getLevel(),
			skill.getLevel(),
			playerNode.getGamePlayer().getChannelId());
	}

	public static void skill_destory(PlayerNode playerNode, Skill skill, ConfigDatabase cd, int kodEventId)
	{
		int quality = getSkillQuality(cd, skill);

		KodLog.skill_destory(KodLog.getDatetime(System.currentTimeMillis()),
			kodEventId,
			playerNode.getPlayerId(),
			AreaData.getAreaId(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			skill.getGuid().toString(),
			skill.getResourceId(),
			quality,
			skill.getLevel(),
			skill.getLevel(),
			playerNode.getGamePlayer().getChannelId());
	}

	public static void skill_levelup(PlayerNode playerNode, Skill skill, ConfigDatabase cd, int oldLevel)
	{
		int quality = getSkillQuality(cd, skill);
		KodLog.skill_levelup(KodLog.getDatetime(System.currentTimeMillis()),
			KodLogEvent.SkillLogic_SkillLevelUp,
			playerNode.getPlayerId(),
			AreaData.getAreaId(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			skill.getGuid().toString(),
			skill.getResourceId(),
			quality,
			skill.getLevel(),
			oldLevel,
			skill.getLevel() - oldLevel,
			playerNode.getGamePlayer().getChannelId());
	}

	public static void campaign_record(PlayerNode playerNode, Dungeon dungeon)
	{
		int iAreaId = AreaData.getAreaId();
		KodLog.campaign_record(KodLog.getDatetime(System.currentTimeMillis()),
			KodLogEvent.DungeonLogic_AddCompleteTimes,
			playerNode.getPlayerId(),
			iAreaId,
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			dungeon.getZoneId(),
			dungeon.getDungeonId(),
			dungeon.getTodayCompleteTimes(),
			dungeon.getTodayCompleteTimes() - 1,
			playerNode.getGamePlayer().getChannelId());
	}

	public static void item(PlayerNode playerNode, int KodLogEventId, int itemId, int amount_old, int amount_new)
	{
		int iAreaId = AreaData.getAreaId();
		Integer channelId = playerNode.getGamePlayer().getChannelId();
		KodLog.item(KodLog.getDatetime(System.currentTimeMillis()),
			KodLogEventId,
			playerNode.getPlayerId(),
			iAreaId,
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			itemId,
			amount_new,
			amount_old,
			amount_new - amount_old,
			channelId);
	}

	public static void private_chat(PlayerNode playerNode, PlayerNode receiverNode, String content)
	{
		int iAreaId = AreaData.getAreaId();
		int iAccountId = playerNode.getPlayerId();
		int iRoleId = playerNode.getPlayerId();
		int iRoleLevel = playerNode.getGamePlayer().getLevel();
		String vRoleName = playerNode.getGamePlayer().getFixName();
		int iToAccountId = receiverNode.getPlayerId();
		int iToRoleId = receiverNode.getPlayerId();
		int iToRoleLevel = receiverNode.getGamePlayer().getLevel();
		String vToRoleName = receiverNode.getGamePlayer().getFixName();
		KodLog.private_chat(KodLog.getDatetime(System.currentTimeMillis()),
			iAccountId,
			iAreaId,
			iRoleId,
			vRoleName,
			iRoleLevel,
			content,
			iToAccountId,
			iToRoleId,
			vToRoleName,
			iToRoleLevel,
			playerNode.getGamePlayer().getChannelId());
	}

	public static void world_chat(PlayerNode playerNode, String content)
	{
		int iAreaId = AreaData.getAreaId();
		int iAccountId = playerNode.getPlayerId();
		int iRoleId = playerNode.getPlayerId();
		int iRoleLevel = playerNode.getGamePlayer().getLevel();
		String vRoleName = playerNode.getGamePlayer().getFixName();
		KodLog.world_chat(KodLog.getDatetime(System.currentTimeMillis()),
			iAccountId,
			iAreaId,
			iRoleId,
			vRoleName,
			iRoleLevel,
			content,
			playerNode.getGamePlayer().getChannelId());
	}

	public static void role_create(PlayerNode playerNode, CorgiUID corgiUID)
	{
		int iAreaId = AreaData.getAreaId();
		if (corgiUID != null && corgiUID.getDeviceInfo() != null)
		{
			DeviceInfo deviceInfo = corgiUID.getDeviceInfo();
			KodLog.role_create(KodLog.getDatetime(System.currentTimeMillis()),
				playerNode.getPlayerId(),
				iAreaId,
				playerNode.getPlayerId(),
				playerNode.getGamePlayer().getFixName(),
				playerNode.getGamePlayer().getLevel(),
				corgiUID.getIpMessage(),
				deviceInfo.getOSType(),
				deviceInfo.getOSVersion(),
				deviceInfo.getDeviceName(),
				deviceInfo.getDeviceType(),
				deviceInfo.getUDID(),
				corgiUID.getDeviceInfo().getUDID(),
				playerNode.getGamePlayer().getChannelId());
		}
		else
		{
			KodLog.role_create(KodLog.getDatetime(System.currentTimeMillis()),
				playerNode.getPlayerId(),
				iAreaId,
				playerNode.getPlayerId(),
				playerNode.getGamePlayer().getFixName(),
				playerNode.getGamePlayer().getLevel(),
				"",
				"",
				"",
				"",
				-1,
				"",
				"",
				playerNode.getGamePlayer().getChannelId());
		}

	}

	//
	public static void realmoney(PlayerNode playerNode, int KodLogEventId, int oldNum, int newNum, int itemId, int count)
	{
		int iRoleId = playerNode.getPlayerId();
		int iAreaId = AreaData.getAreaId();
		Integer channelId = playerNode.getGamePlayer().getChannelId();
		KodLog.realmoney(KodLog.getDatetime(System.currentTimeMillis()),
			KodLogEventId,
			iRoleId,
			iAreaId,
			iRoleId,
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			newNum,
			oldNum,
			newNum - oldNum,
			itemId,
			count,
			channelId);
	}

	public static void role_levelup(PlayerNode playerNode, int KodLogEventId, int oldLevel)
	{
		int iAreaId = AreaData.getAreaId();
		CorgiUID corgiUID = playerNode.getPlayerInfo().getClientLoginMessage().getCorgiUID();
		if (corgiUID != null && corgiUID.getDeviceInfo() != null)
		{
			DeviceInfo deviceInfo = corgiUID.getDeviceInfo();
			KodLog.role_levelup(KodLog.getDatetime(System.currentTimeMillis()),
				KodLogEventId,
				playerNode.getPlayerId(),
				iAreaId,
				playerNode.getPlayerId(),
				playerNode.getGamePlayer().getFixName(),
				playerNode.getGamePlayer().getLevel(),
				oldLevel,
				corgiUID.getIpMessage(),
				deviceInfo.getOSType(),
				deviceInfo.getOSVersion(),
				deviceInfo.getDeviceName(),
				deviceInfo.getDeviceType(),
				deviceInfo.getUDID(),
				playerNode.getGamePlayer().getChannelId());
		}
		else
		{
			KodLog.role_levelup(KodLog.getDatetime(System.currentTimeMillis()),
				KodLogEventId,
				playerNode.getPlayerId(),
				iAreaId,
				playerNode.getPlayerId(),
				playerNode.getGamePlayer().getFixName(),
				playerNode.getGamePlayer().getLevel(),
				oldLevel,
				"",
				"",
				"",
				"",
				-1,
				"",
				playerNode.getGamePlayer().getChannelId());
		}

	}

	public static void role_login(PlayerNode playerNode, ClientNode sender)
	{
		int iAreaId = AreaData.getAreaId();
		DeviceInfo deviceInfo = sender.getClientUID().getDeviceInfo();
		KodLog.role_login(KodLog.getDatetime(System.currentTimeMillis()),
			playerNode.getPlayerId(),
			iAreaId,
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			playerNode.getGamePlayer().getLevel(),
			sender.getClientUID().getIpMessage(),
			deviceInfo.getOSType(),
			deviceInfo.getOSVersion(),
			deviceInfo.getDeviceName(),
			deviceInfo.getDeviceType(),
			deviceInfo.getUDID(),
			sender.getClientUID().getDeviceInfo().getUDID(),
			playerNode.getGamePlayer().getChannelId());
	}

	public static void role_logout(PlayerNode playerNode)
	{
		CorgiUID corgiUID = playerNode.getPlayerInfo().getClientLoginMessage().getCorgiUID();
		if (corgiUID != null)
		{
			long onlineTimeSecond = (System.currentTimeMillis() - corgiUID.getLoginTime()) / 1000;
			KodLog.role_logout(KodLog.getDatetime(System.currentTimeMillis()),
				playerNode.getPlayerId(),
				AreaData.getAreaId(),
				playerNode.getPlayerId(),
				playerNode.getGamePlayer().getFixName(),
				playerNode.getGamePlayer().getLevel(),
				(int)(onlineTimeSecond),
				playerNode.getGamePlayer().getChannelId());
			logger.debug("playerId={} onlineTimeSecond={}", playerNode.getPlayerId(), onlineTimeSecond);
		}

	}

	public static int getAvatarQuality(ConfigDatabase cd, Avatar avatar)
	{
		AvatarConfig avatarConfig = cd.get_AvatarConfig();
		if (avatarConfig != null)
		{
			if (avatarConfig.GetAvatarById(avatar.getResourceId()) != null)
			{
				return avatarConfig.GetAvatarById(avatar.getResourceId()).get_qualityLevel();
			}
		}
		return 0;
	}

	public static int getEquipQuality(ConfigDatabase cd, Equipment equipment)
	{
		EquipmentConfig equipConfig = cd.get_EquipmentConfig();
		if (equipConfig != null)
		{
			if (equipConfig.GetEquipmentById(equipment.getResourceId()) != null)
			{
				return equipConfig.GetEquipmentById(equipment.getResourceId()).get_qualityLevel();
			}
		}
		return 0;
	}

	public static int getSkillQuality(ConfigDatabase cd, Skill skill)
	{
		SkillConfig skillCfg = cd.get_SkillConfig();
		if (skillCfg != null)
		{
			if (skillCfg.GetSkillById(skill.getResourceId()) != null)
			{
				return skillCfg.GetSkillById(skill.getResourceId()).get_qualityLevel();
			}
		}
		return 0;
	}
}
