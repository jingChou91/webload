/*
 * 文 件 名:  TableChangeEvent.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:  <描述>
 * 创 建 人:  <创建人>
 * 创建时间:  2014年8月7日
 * 修 改 人:  <修改人>
 * 修改时间:  2014年8月7日
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.dbclient;

/**
 * sql语句代码
 * 
 * @author 姓名
 * @version [版本号, 2014年8月7日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
public class TableChangeEvent
{
	// 表名_***DB中的方法名
	// 对player表的操作
	public static final int PLAYER_UPDATEBADGE = 101;
	public static final int PLAYER_UPDATEGAMEMONEY = 102;
	public static final int PLAYER_UPDATEFIXTIMEACTIVTY = 103;
	public static final int PLAYER_UPDATELASTLOGINTIME = 104;
	public static final int PLAYER_UPDATEMEDALS = 105;
	public static final int PLAYER_UPDATENOTICE = 106;
	public static final int PLAYER_UPDATECHALLENGEPOINT = 107;
	public static final int PLAYER_UPDATECHATCOUNT = 108;
	public static final int PLAYER_UPDATEGRADEPOINT = 109;
	public static final int PLAYER_UPDATEIRON = 111;
	public static final int PLAYER_UPDATEPLAYERMELALEUCAFLOORDATA = 112;
	public static final int PLAYER_UPDATEPLAYERLEVELANDEXP = 113;
	public static final int PLAYER_UPDATESOUL = 114;
	public static final int PLAYER_UPDATESPIRIT = 115;
	public static final int PLAYER_UPDATESTAMINA = 116;
	public static final int PLAYER_UPDATETHREETOKEN = 117;
	public static final int PLAYER_UPDATETRIALSTAMP = 118;
	public static final int PLAYER_UPDATESTAMINALIMIT = 119;
	public static final int PLAYER_UPDATETUTORIAL = 120;
	public static final int PLAYER_REPLACEMASTERPOSITION = 121;
	public static final int PLAYER_UPDATESTARTSERVERREWARDSTATE = 122;
	public static final int PLAYER_UPDATESTARTSERVERREWARD = 123;
	public static final int PLAYER_UPDATEPLAYERREWARDTIMES = 124;
	public static final int PLAYER_UPDATECARDS = 125;
	public static final int PLAYER_UPDATEPICKEDLEVEL = 126;
	public static final int PLAYER_UPDATEPLAYERSIGNDATA = 127;
	public static final int PLAYER_UPDATEPLAYERDUNGEONDATA = 128;
	public static final int PLAYER_UPDATELEVELREWARD = 129;
	public static final int PLAYER_UPDATEQININFOANSWERCOUNT = 130;
	public static final int PLAYER_UPDATETUTORIALDELETE = 131;
	public static final int PLAYER_UPDATEENERGY = 132;
	public static final int PLAYER_UPDATEWINESOUL = 133;
	public static final int PLAYER_UPDATEBUYSTAMINACOUNT = 134;
	public static final int PLAYER_UPDATEBUYENERGYCOUNT = 135;
	public static final int PLAYER_UPDATEZENTIA = 136;
	public static final int PLAYER_UPDATELASTLOGOUTTIME = 137;
	public static final int PLAYER_UPDATEPOWER = 138;

	// 对position表的操作
	public static final int POSITION_UPDATEPOSITION = 201;
	public static final int POSITION_UPDATEPARTNER = 202;

	// 对tavern表的操作
	public static final int TAVERN_UPDATESPECIALMULTIPART = 301;
	public static final int TAVERN_UPDATETAVERNDATA = 302;

	// 对diner_info表的操作
	public static final int DINER_INFO_UPDATEDINERINFODATA = 601;

	// 对domineer表的操作
	public static final int DOMINEER_REPLACEDOMINEER = 701;

	// 对dungeon表的操作
	public static final int DUNGEON_UPDATEDUNGEON = 801;

	// 对Email表的操作
	public static final int EMAIL_UN_READ_UPDATEEMAILUNREAD = 901;

	// 对exchange表的操作
	public static final int EXCHANGE_UPDATEEXCHANGE = 1001;

	// 对gacha表的操作
	public static final int GACHA_UPDATESPECIALMULTIPART = 1101;

	// 对melaleuca_floor_rank表的操作
	public static final int MELALEUCA_FLOOR_RANK_UPDATERANKINFO = 1201;

	// 对meridian表的操作
	public static final int MERIDIAN_REPLACEMERIDIAN = 1301;

	// 对mystery_counter表的操作
	public static final int MYSTERY_COUNTER_UPDATECOUNTERINFO = 1501;

	// 对mystery_shop表的操作
	public static final int MYSTERY_SHOP_UPDATEMYSTERYSHOP = 1601;

	// 对partner_open表的操作
	public static final int PARTNER_OPEN_ADDPARTNEROPEN = 1701;

	// 对position_avatars_on表的操作
	public static final int POSITION_AVATARS_ON_REPALCEPOSITIONAVATARON = 1801;

	// 对quest表的操作
	public static final int QUEST_UPDATEQUEST = 1901;

	// 对travel_trader表的操作
	public static final int TRAVEL_TRADER_UPDATETRAVEL = 2001;

	// 对treasurebowl表的操作
	public static final int TREASUREBOWL_UPDATETREASUREBOWL = 2101;

	// 对unique_goods表的操作
	public static final int UNIQUE_GOODS_ADDUNIQUEGOODS = 2201;

	// 对wolf_smoke表的操作
	public static final int WOLF_SMOKE_UPDATEWOLFSMOKE = 2301;

	// 秦时百科
	public static final int QIN_INFO_UPDATEQININFO = 2400;

	// 好友系统
	public static final int FRIEND_UPDATE = 2500;
	// 全服礼包全服计数器
	public static final int ALL_PLAYER_GIFT_COUNTER_UPDATEALLPLAYERGIFTCOUNTER = 2601;

	// 全服礼包个人计数器和保底计数器
	public static final int PLAYER_GIFT_COUNTER_UPDATEPLAYERGIFTCOUNTER = 2701;

	// 好友副本 对friend_campaign表的操作
	public static final int FRIEND_CAMPAIGN_UPDATEFRIENDCAMPAIGN = 2801;

	// 奇遇
	public static final int MARVELLOUS_UPDATEMARVELLOUS = 2900;

	// 幻化
	public static final int ILLUSION_UPDATE = 3000;

	// 酒馆神秘商人
	public static final int MYSTERYER_UPDATE = 3100;

	// 替换一条FC榜单数据
	public static final int FCRANK_REPLACE_ONE = 3200;

	// 东海寻仙玩家数据replace
	public static final int ZENTIA_REPACE = 3300;
	// 东海寻仙全服数据replace
	public static final int ZENTIA_RANK_REPLACE = 3301;

	// 丹房
	public static final int DANHOME_UPDATE = 3400;
	// 内丹
	public static final int DANINFO_UPDATE = 3401;

	// 门派粮草
	public static final int GUILD_MONEY_UPDATE = 3500;
	// 门派Boss信物
	public static final int GUILD_BOSS_COUNT = 3501;
	// 门派行动力
	public static final int GUILD_MOVE_COUNT = 3502;
	//

	// 门派兑换
	public static final int GUILD_PLAYER_EXCHANGE_SHOP = 3601;
	// 门派任务
	public static final int GUILD_PLAYER_TASK_INFO = 3602;
	// 门派个人商店
	public static final int GUILD_PLAYER_PRIVATE_SHOP = 3603;
	// 门派建设
	public static final int GUILD_PLAYER_CONSTRUCT = 3604;
	// 门派贡献
	public static final int GUILD_PLAYER_CONSTRIBUTION = 3605;
	// 已查看门派留言
	public static final int GUILD_PLAYER_MSG_VIEW = 3606;
	// 已查看门派动态
	public static final int GUILD_PLAYER_NEWS_VIEW = 3607;
	// 已查看门派聊天
	public static final int GUILD_PLAYER_CHAT_VIEW = 3608;

	// 门派关卡所有门派
	public static final int GUILDSTAGE_ALL = 3700;
	// 门派关卡一个门派
	public static final int GUILDSTAGE_GUILD = 3701;
	// 门派关卡一个玩家
	public static final int GUILDSTAGE_PLAYER = 3702;

	// 集卡活动
	public static final int FIRSTTHREEDAY_UPDATE = 3800;

	// 机关兽系统
	public static final int BEAST = 3900;

	public static String getKey(int playerId, int tableEvent, Object... args)
	{
		String key = "";
		if (args != null)
		{
			for (Object object : args)
			{
				key = key + "|" + object;
			}
		}

		return playerId + "|" + tableEvent + key;
	}
}
