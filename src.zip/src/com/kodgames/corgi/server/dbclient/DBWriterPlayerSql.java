package com.kodgames.corgi.server.dbclient;

public class DBWriterPlayerSql
{
	private int playerId;
	private String sql;
	private long time;

	public DBWriterPlayerSql(int playerId, String sql, long time)
	{
		this.playerId = playerId;
		this.sql = sql;
		this.time = time;
	}

	public int getPlayerId()
	{
		return playerId;
	}

	public String getSql()
	{
		return sql;
	}

	public long getTime()
	{
		return time;
	}
}
