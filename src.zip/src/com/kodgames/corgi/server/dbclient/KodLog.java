package com.kodgames.corgi.server.dbclient;

import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.server.common.DBCluster;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.common.StatisticsConfigMgr;

public class KodLog {

	public static final int AvatarOpType_AvatarCreate=1000;
	public static final int AvatarOpType_AvatarDestory=1001;
	public static final int AvatarOpType_AvatarLevelUp=1002;
	public static final int AvatarOpType_AvatarBreakthroughLevelUp=1003;
	
	public static final int EquipOpType_EquipCreate=2000;
	public static final int EquipOpType_EquipDestory=2001;
	public static final int EquipOpType_EquipLevelUp=2002;
	public static final int EquipOpType_EquipBreakthroughLevelUp=2003;
	
	public static final int SkillOpType_SkillCreate=3000;
	public static final int SkillOpType_SkillDestory=3001;
	public static final int SkillOpType_SkillLevelUp=3002;
	
	public static final int DanOpType_DanCreate=4000;
	public static final int DanOpType_DanDestory=4001;
	public static final int DanOpType_DanLevelUp=4002;
	public static final int DanOpType_DanBreakthroughLevelUp=4003;
	
	private static DBCluster dbCluster = null;

	public static void Init(DBCluster dbCluster)
	{
		KodLog.dbCluster = dbCluster;
	}

	public static String getDatetime(long value)
	{
		return ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(), value, ServerUtil.TimeWithoutMills);
	}

	private static final String[] table_account_login = new String[] { "account_login", "dtEventTime", "iAccountId", "iChannelId", "vClientIp", "vUDID", "vDeviceOSType", "vDeviceOSVersion", "vDeviceName", "iDeviceType" ,"iAccountType"};

	public static void account_login(String dtEventTime, Integer iAccountId, Integer iChannelId, String vClientIp, String vUDID, String vDeviceOSType, String vDeviceOSVersion, String vDeviceName, Integer iDeviceType,Integer iAccountType) {
		KodLogDB.addLog(dbCluster.getAccountDBClient(), table_account_login, dtEventTime, iAccountId, iChannelId, vClientIp, vUDID, vDeviceOSType, vDeviceOSVersion, vDeviceName, iDeviceType, iAccountType);
	}
	
	public static void avatar_create(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vAvatarGuid, Integer iAvatarResourceId, Integer iAvatarQuality, Integer iAvatarLevel,Integer iAvatarLevelFrom, Integer iAvatarBreakthoughLevel,Integer iAvatarBreakthoughLevelFrom,Integer iChannelId) {
		avatar(dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel,AvatarOpType_AvatarCreate, vAvatarGuid, iAvatarResourceId, iAvatarQuality, iAvatarLevel,  iAvatarLevelFrom, 0, iAvatarBreakthoughLevel,iAvatarBreakthoughLevelFrom, 0,iChannelId);
	}

	public static void avatar_destory(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vAvatarGuid, Integer iAvatarResourceId, Integer iAvatarQuality, Integer iAvatarLevel,Integer iAvatarLevelFrom, Integer iAvatarBreakthoughLevel,Integer iAvatarBreakthoughLevelFrom,Integer iChannelId) {
		avatar(dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel,AvatarOpType_AvatarDestory, vAvatarGuid, iAvatarResourceId, iAvatarQuality, iAvatarLevel,  iAvatarLevelFrom, 0, iAvatarBreakthoughLevel,iAvatarBreakthoughLevelFrom, 0,iChannelId);
	}

	public static void avatar_levelup(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vAvatarGuid, Integer iAvatarResourceId, Integer iAvatarQuality, Integer iAvatarLevel, Integer iAvatarLevelFrom, Integer iAvatarLevelChange, Integer iAvatarBreakthoughLevel,Integer iAvatarBreakthoughLevelFrom,Integer iChannelId) {
		avatar(dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel,AvatarOpType_AvatarLevelUp, vAvatarGuid, iAvatarResourceId, iAvatarQuality, iAvatarLevel,  iAvatarLevelFrom, iAvatarLevelChange, iAvatarBreakthoughLevel,iAvatarBreakthoughLevelFrom, 0,iChannelId);
	}

	public static void avatar_breakthoughlevelup(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vAvatarGuid, Integer iAvatarResourceId, Integer iAvatarQuality, Integer iAvatarLevel,Integer iAvatarLevelFrom,Integer iAvatarBreakthoughLevel, Integer iAvatarBreakthoughLevelFrom, Integer iAvatarBreakthoughLevelChange,Integer iChannelId) {
		avatar(dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel,AvatarOpType_AvatarBreakthroughLevelUp, vAvatarGuid, iAvatarResourceId, iAvatarQuality, iAvatarLevel,  iAvatarLevelFrom, 0, iAvatarBreakthoughLevel,iAvatarBreakthoughLevelFrom, iAvatarBreakthoughLevelChange,iChannelId);
	}

	public static void equip_create(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vEquipGuid, Integer iEquipResourceId, Integer iEquipQuality, Integer iEquipLevel,Integer iEquipLevelFrom, Integer iEquipBreakthoughLevel,Integer iEquipBreakthoughLevelFrom,Integer iChannelId) {
		equip(dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel,EquipOpType_EquipCreate, vEquipGuid, iEquipResourceId, iEquipQuality, iEquipLevel, iEquipLevelFrom, 0, iEquipBreakthoughLevel,iEquipBreakthoughLevelFrom,0,iChannelId);
	}
	
	public static void dan_create(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vEquipGuid, Integer iEquipResourceId, Integer iEquipQuality, Integer iEquipLevel,Integer iEquipLevelFrom, Integer iEquipBreakthoughLevel,Integer iEquipBreakthoughLevelFrom,String attributes, Integer iChannelId) {
		dan(dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel,DanOpType_DanCreate, vEquipGuid, iEquipResourceId, iEquipQuality, iEquipLevel, iEquipLevelFrom, 0, iEquipBreakthoughLevel,iEquipBreakthoughLevelFrom,0,attributes,iChannelId);
	}

	public static void equip_destory(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vEquipGuid, Integer iEquipResourceId, Integer iEquipQuality, Integer iEquipLevel, Integer iEquipLevelFrom, Integer iEquipBreakthoughLevel,Integer iEquipBreakthoughLevelFrom,Integer iChannelId) {
		equip(dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel,EquipOpType_EquipDestory, vEquipGuid, iEquipResourceId, iEquipQuality, iEquipLevel, iEquipLevelFrom, 0, iEquipBreakthoughLevel,iEquipBreakthoughLevelFrom,0,iChannelId);
	}
	
	public static void dan_destory(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vEquipGuid, Integer iEquipResourceId, Integer iEquipQuality, Integer iEquipLevel, Integer iEquipLevelFrom, Integer iEquipBreakthoughLevel,Integer iEquipBreakthoughLevelFrom,String attributes, Integer iChannelId) {
		dan(dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel,DanOpType_DanDestory, vEquipGuid, iEquipResourceId, iEquipQuality, iEquipLevel, iEquipLevelFrom, 0, iEquipBreakthoughLevel,iEquipBreakthoughLevelFrom,0,attributes,iChannelId);
	}

	public static void equip_levelup(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vEquipGuid, Integer iEquipResourceId, Integer iEquipQuality, Integer iEquipLevel, Integer iEquipLevelFrom, Integer iEquipLevelChange, Integer iEquipBreakthoughLevel,Integer iEquipBreakthoughLevelFrom,Integer iChannelId) {
		equip(dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel,EquipOpType_EquipLevelUp, vEquipGuid, iEquipResourceId, iEquipQuality, iEquipLevel, iEquipLevelFrom, iEquipLevelChange, iEquipBreakthoughLevel,iEquipBreakthoughLevelFrom,0,iChannelId);
	}

	public static void equip_breakthoughlevelup(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vEquipGuid, Integer iEquipResourceId, Integer iEquipQuality, Integer iEquipLevel,Integer iEquipLevelFrom, Integer iEquipBreakthoughLevel, Integer iEquipBreakthoughLevelFrom, Integer iEquipBreakthoughLevelChange,Integer iChannelId) {
		equip(dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel,EquipOpType_EquipBreakthroughLevelUp, vEquipGuid, iEquipResourceId, iEquipQuality, iEquipLevel, iEquipLevelFrom, 0, iEquipBreakthoughLevel,iEquipBreakthoughLevelFrom,iEquipBreakthoughLevelChange,iChannelId);
	}

	private static final String[] table_item = new String[] { "item", "dtEventTime", "iEventId", "iAccountId", "iAreaId", "iRoleId", "vRoleName", "iRoleLevel", "iItemId", "iItemNum", "iItemNumFrom", "iItemNumChange" ,"iChannelId"};

	public static void item(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, Integer iItemId, Integer iItemNum, Integer iItemNumFrom, Integer iItemNumChange,Integer iChannelId) {
		if (StatisticsConfigMgr.getInstance().containItemId(iItemId) == false) {
			return;
		}
		KodLogDB.addLog(dbCluster.getLogDBClient(), table_item, dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel, iItemId, iItemNum, iItemNumFrom, iItemNumChange,iChannelId);
	}

	private static final String[] table_combat_count = new String[] { "combat_count", "dtEventTime", "iAccountId", "iAreaId", "iRoleId", "vRoleName", "iRoleLevel", "iDungeonWin", "iDungeonLose","iActiveDungeonWin", "iActiveDungeonLose", "iArenaWin", "iArenaLose", "iPveWin", "iPveLose","iRobSkillWin","iRobSkillLose" ,"iWorldBoss","iChannelId"};

	public static void combat_count(String dtEventTime, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, Integer iDungeonWin, Integer iDungeonLose,Integer iActiveDungeonWin, Integer iActiveDungeonLose, Integer iArenaWin, Integer iArenaLose, Integer iPveWin,Integer iPveLose,Integer iRobSkillWin, Integer iRobSkillLose, Integer iWorldBoss,Integer iChannelId) {
		KodLogDB.addLog(dbCluster.getLogDBClient(), table_combat_count, dtEventTime, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel, iDungeonWin, iDungeonLose,iActiveDungeonWin, iActiveDungeonLose, iArenaWin, iArenaLose, iPveWin, iPveLose, iRobSkillWin,iRobSkillLose,iWorldBoss,iChannelId);
	}

	private static final String[] table_realmoney = new String[] { "realmoney", "dtEventTime", "iEventId", "iAccountId", "iAreaId", "iRoleId", "vRoleName", "iRoleLevel", "iRealMoney", "iRealMoneyFrom", "iRealMoneyChange","iItemId","iCount" ,"iChannelId"};

	public static void realmoney(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, Integer iRealMoney, Integer iRealMoneyFrom, Integer iRealMoneyChange,Integer iItemId,Integer iCount,Integer iChannelId) {
		KodLogDB.addLog(dbCluster.getLogDBClient(), table_realmoney, dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel, iRealMoney, iRealMoneyFrom, iRealMoneyChange,iItemId, iCount,iChannelId);
	}

	private static final String[] table_role_create = new String[] { "role_create", "dtEventTime", "iAccountId", "iAreaId", "iRoleId", "vRoleName", "iRoleLevel", "vClientIp", "vDeviceOSType", "vDeviceOSVersion", "vDeviceName", "iDeviceType", "vUDID","vUDID_From_Account","iChannelId" };

	public static void role_create(String dtEventTime, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vClientIp, String vDeviceOSType, String vDeviceOSVersion, String vDeviceName, Integer iDeviceType, String vUDID,String vUDID_From_Account,Integer iChannelId) {
		KodLogDB.addLog(dbCluster.getLogDBClient(), table_role_create, dtEventTime, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel, vClientIp, vDeviceOSType, vDeviceOSVersion, vDeviceName, iDeviceType, vUDID,vUDID_From_Account,iChannelId);
	}

	private static final String[] table_role_levelup = new String[] { "role_levelup", "dtEventTime", "iEventId", "iAccountId", "iAreaId", "iRoleId", "vRoleName", "iRoleLevel", "iRoleLevelFrom", "vClientIp", "vDeviceOSType", "vDeviceOSVersion", "vDeviceName", "iDeviceType", "vUDID" ,"iChannelId"};

	public static void role_levelup(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, Integer iRoleLevelFrom, String vClientIp, String vDeviceOSType, String vDeviceOSVersion, String vDeviceName, Integer iDeviceType, String vUDID,Integer iChannelId) {
		KodLogDB.addLog(dbCluster.getLogDBClient(), table_role_levelup, dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel, iRoleLevelFrom, vClientIp, vDeviceOSType, vDeviceOSVersion, vDeviceName, iDeviceType, vUDID,iChannelId);
	}

	private static final String[] table_role_login = new String[] { "role_login", "dtEventTime", "iAccountId", "iAreaId", "iRoleId", "vRoleName", "iRoleLevel", "vClientIp", "vDeviceOSType", "vDeviceOSVersion", "vDeviceName", "iDeviceType", "vUDID" ,"vUDID_From_Account","iChannelId"};

	public static void role_login(String dtEventTime, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vClientIp, String vDeviceOSType, String vDeviceOSVersion, String vDeviceName, Integer iDeviceType, String vUDID,String vUDID_From_Account,Integer iChannelId) {
		KodLogDB.addLog(dbCluster.getLogDBClient(), table_role_login, dtEventTime, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel, vClientIp, vDeviceOSType, vDeviceOSVersion, vDeviceName, iDeviceType, vUDID,vUDID_From_Account,iChannelId);
	}

	private static final String[] table_role_logout = new String[] { "role_logout", "dtEventTime", "iAccountId", "iAreaId", "iRoleId", "vRoleName", "iRoleLevel", "iOnlineTime","iChannelId" };

	public static void role_logout(String dtEventTime, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, Integer iOnlineTime,Integer iChannelId) {
		KodLogDB.addLog(dbCluster.getLogDBClient(), table_role_logout, dtEventTime, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel, iOnlineTime,iChannelId);
	}

	public static void skill_create(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vSkillGuid, Integer iSkillResourceId, Integer iSkillQuality, Integer iSkillLevel,Integer iSkillLevelFrom,Integer iChannelId) {
		skill(dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel,SkillOpType_SkillCreate, vSkillGuid, iSkillResourceId, iSkillQuality, iSkillLevel, iSkillLevelFrom, 0,iChannelId);
	}

	public static void skill_destory(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vSkillGuid, Integer iSkillResourceId, Integer iSkillQuality, Integer iSkillLevel,Integer iSkillLevelFrom,Integer iChannelId) {
		skill(dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel,SkillOpType_SkillDestory, vSkillGuid, iSkillResourceId, iSkillQuality, iSkillLevel, iSkillLevelFrom, 0,iChannelId);
	}

	public static void skill_levelup(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vSkillGuid, Integer iSkillResourceId, Integer iSkillQuality, Integer iSkillLevel, Integer iSkillLevelFrom, Integer iSkillLevelChange,Integer iChannelId) {
		skill(dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel,SkillOpType_SkillLevelUp, vSkillGuid, iSkillResourceId, iSkillQuality, iSkillLevel, iSkillLevelFrom, iSkillLevelChange,iChannelId);
	}

	private static final String[] table_private_chat = new String[] { "private_chat", "dtEventTime", "iAccountId", "iAreaId", "iRoleId", "vRoleName", "iRoleLevel", "vMsg", "iToAccountId", "iToRoleId", "vToRoleName", "iToRoleLevel" ,"iChannelId"};
	public static void private_chat(String dtEventTime, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vMsg, Integer iToAccountId, Integer iToRoleId, String vToRoleName, Integer iToRoleLevel,Integer iChannelId) {
		KodLogDB.addLog(dbCluster.getLogDBClient(), table_private_chat, dtEventTime, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel, vMsg, iToAccountId, iToRoleId, vToRoleName, iToRoleLevel,iChannelId);
	}

	private static final String[] table_world_chat = new String[] { "world_chat", "dtEventTime", "iAccountId", "iAreaId", "iRoleId", "vRoleName", "iRoleLevel", "vMsg" ,"iChannelId"};

	public static void world_chat(String dtEventTime, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, String vMsg,Integer iChannelId) {
		KodLogDB.addLog(dbCluster.getLogDBClient(), table_world_chat, dtEventTime, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel, vMsg,iChannelId);
	}

	private static final String[] table_campaign_record = new String[] { "campaign_record", "dtEventTime", "iEventId", "iAccountId", "iAreaId", "iRoleId", "vRoleName", "iRoleLevel", "iZoneId", "iDungeonId", "iEnterCount", "iEnterCountFrom" ,"iChannelId"};

	public static void campaign_record(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, Integer iZoneId, Integer iDungeonId, Integer iEnterCount, Integer iEnterCountFrom,Integer iChannelId) {
		KodLogDB.addLog(dbCluster.getLogDBClient(), table_campaign_record, dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel, iZoneId, iDungeonId, iEnterCount, iEnterCountFrom,iChannelId);
	}

	private static final String[] table_special_id_change = new String[] { "special_id_change", "dtEventTime","iEventId", "iAccountId", "iAreaId", "iRoleId", "vRoleName", "iRoleLevel", "iSpecialId", "iTo", "iFrom", "iChange" ,"iChannelId"};

	public static void special_id_change(String dtEventTime,Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel, Integer iSpecialId, Integer iTo, Integer iFrom,Integer iChannelId) {
		if (StatisticsConfigMgr.getInstance().containSpecialId(iSpecialId) == false) {
			return;
		}
		KodLogDB.addLog(dbCluster.getLogDBClient(), table_special_id_change, dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel, iSpecialId, iTo, iFrom, iTo-iFrom,iChannelId);
	}

	private static final String[] table_gs_online_status = new String[] { "gs_online_status", "iServerId", "dtStartTime", "dtEndTime", "iMax", "iMin", "iAvg","iMemoryMax" };

	public static void gs_online_status(Integer iServerId, String dtStartTime, String dtEndTime, Integer iMax, Integer iMin, Integer iAvg, Integer iMemoryMax) {
		KodLogDB.addLog(dbCluster.getLogDBClient(), table_gs_online_status, iServerId, dtStartTime, dtEndTime, iMax, iMin, iAvg, iMemoryMax);
	}
	
	// GMLog
	private static final String[] table_gm_log = new String[] { "gm_log", "gm_account", "dtEventTime", "command", "area_id" };

	public static void gm_log(String username, String dtEventTime, String command, Integer areaId) {
		KodLogDB.addLog(dbCluster.getManagerDbClient(), table_gm_log, username, dtEventTime, command, areaId);
	}

	// proxy_Receive log
	private static final String[] table_proxy_receive = new String[] { "proxy_receive", "dtEventTime", "uri", "uuid", "manual"};
	public static void proxy_receive(String dtEventTime, String uri, String uuid, int manual) {
		KodLogDB.addLog(dbCluster.getManagerDbClient(), table_proxy_receive, dtEventTime, uri, uuid, manual);
	}
	
	private static final String[] table_apple_log = new String[] { "apple_log", "dtEventTime", "iRoleId", "vProductId", "iQuantity", "vTransactionId", "vPurchaseDatetime", "vReceipt" };
	public static void apple_log(String dtEventTime, Integer iRoleId, String vProductId, Integer iQuantity, String vTransactionId, String vPurchaseDatetime, String vReceipt) {
		KodLogDB.addLog(dbCluster.getManagerDbClient(), table_apple_log, dtEventTime, iRoleId, vProductId, iQuantity, vTransactionId, vPurchaseDatetime, vReceipt);
	}
	private static final String[] table_avatar = new String[] { "avatar", "dtEventTime", "iEventId", "iAccountId", "iAreaId", "iRoleId", "vRoleName", "iRoleLevel","iAvatarOpType", "vAvatarGuid", "iAvatarResourceId", "iAvatarQuality", "iAvatarLevel", "iAvatarLevelFrom", "iAvatarLevelChange", "iAvatarBreakthoughLevel","iAvatarBreakthoughLevelFrom","iAvatarBreakthoughLevelChange" ,"iChannelId"};
	private static void avatar(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel,Integer iAvatarOpType, String vAvatarGuid, Integer iAvatarResourceId, Integer iAvatarQuality, Integer iAvatarLevel, Integer iAvatarLevelFrom, Integer iAvatarLevelChange, Integer iAvatarBreakthoughLevel,Integer iAvatarBreakthoughLevelFrom,Integer iAvatarBreakthoughLevelChange,Integer iChannelId) {
		if (StatisticsConfigMgr.getInstance().containAvatarQuality(iAvatarQuality) == false) {
			return;
		}
		KodLogDB.addLog(dbCluster.getLogDBClient(), table_avatar, dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel, iAvatarOpType, vAvatarGuid, iAvatarResourceId, iAvatarQuality, iAvatarLevel, iAvatarLevelFrom, iAvatarLevelChange, iAvatarBreakthoughLevel,iAvatarBreakthoughLevelFrom,iAvatarBreakthoughLevelChange,iChannelId);
	}
	
	private static final String[] table_equip = new String[] { "equip", "dtEventTime", "iEventId", "iAccountId", "iAreaId", "iRoleId", "vRoleName", "iRoleLevel","iEquipOpType", "vEquipGuid", "iEquipResourceId", "iEquipQuality", "iEquipLevel", "iEquipLevelFrom", "iEquipLevelChange", "iEquipBreakthoughLevel", "iEquipBreakthoughLevelFrom", "iEquipBreakthoughLevelChange","iChannelId"};

	private static void equip(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel,Integer iEquipOpType, String vEquipGuid, Integer iEquipResourceId, Integer iEquipQuality, Integer iEquipLevel, Integer iEquipLevelFrom, Integer iEquipLevelChange, Integer iEquipBreakthoughLevel,Integer iEquipBreakthoughLevelFrom,Integer iEquipBreakthoughLevelChange,Integer iChannelId) {
		if (StatisticsConfigMgr.getInstance().containEquipQuality(iEquipQuality) == false) {
			return;
		}
		KodLogDB.addLog(dbCluster.getLogDBClient(), table_equip, dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel,iEquipOpType, vEquipGuid, iEquipResourceId, iEquipQuality, iEquipLevel, iEquipLevelFrom, iEquipLevelChange, iEquipBreakthoughLevel,iEquipBreakthoughLevelFrom,iEquipBreakthoughLevelChange,iChannelId);
	}
	
	private static final String[] table_dan = new String[] { "dan", "dtEventTime", "iEventId", "iAccountId", "iAreaId", "iRoleId", "vRoleName", "iRoleLevel","iEquipOpType", "vEquipGuid", "iEquipResourceId", "iEquipQuality", "iEquipLevel", "iEquipLevelFrom", "iEquipLevelChange", "iEquipBreakthoughLevel", "iEquipBreakthoughLevelFrom", "iEquipBreakthoughLevelChange","attributes","iChannelId"};

	private static void dan(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel,Integer iEquipOpType, String vEquipGuid, Integer iEquipResourceId, Integer iEquipQuality, Integer iEquipLevel, Integer iEquipLevelFrom, Integer iEquipLevelChange, Integer iEquipBreakthoughLevel,Integer iEquipBreakthoughLevelFrom,Integer iEquipBreakthoughLevelChange,String attributes, Integer iChannelId) {
		KodLogDB.addLog(dbCluster.getLogDBClient(), table_dan, dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel,iEquipOpType, vEquipGuid, iEquipResourceId, iEquipQuality, iEquipLevel, iEquipLevelFrom, iEquipLevelChange, iEquipBreakthoughLevel,iEquipBreakthoughLevelFrom,iEquipBreakthoughLevelChange,attributes,iChannelId);
	}
	
	private static final String[] table_skill = new String[] { "skill", "dtEventTime", "iEventId", "iAccountId", "iAreaId", "iRoleId", "vRoleName", "iRoleLevel","iSkillOpType", "vSkillGuid", "iSkillResourceId", "iSkillQuality", "iSkillLevel", "iSkillLevelFrom", "iSkillLevelChange" ,"iChannelId"};

	private static void skill(String dtEventTime, Integer iEventId, Integer iAccountId, Integer iAreaId, Integer iRoleId, String vRoleName, Integer iRoleLevel,Integer iSkillOpType, String vSkillGuid, Integer iSkillResourceId, Integer iSkillQuality, Integer iSkillLevel, Integer iSkillLevelFrom, Integer iSkillLevelChange,Integer iChannelId) {
		if (StatisticsConfigMgr.getInstance().containSkillQuality(iSkillQuality) == false)
		{
			return;
		}
		KodLogDB.addLog(dbCluster.getLogDBClient(), table_skill, dtEventTime, iEventId, iAccountId, iAreaId, iRoleId, vRoleName, iRoleLevel, iSkillOpType, vSkillGuid, iSkillResourceId, iSkillQuality, iSkillLevel, iSkillLevelFrom, iSkillLevelChange, iChannelId);
	}
}
