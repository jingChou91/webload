package com.kodgames.corgi.server.dbclient;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.googlecode.concurrentlinkedhashmap.ConcurrentLinkedHashMap;
import com.kodgames.corgi.server.common.LoopRunnable;
import com.kodgames.gamedata.dbcommon.DBEasy;

public class DBCacheWriterPart extends LoopRunnable
{
	private static final Logger loggerPlayerSqlLog = LoggerFactory.getLogger("PlayerSqlLog");
	private static final Logger logger = LoggerFactory.getLogger(DBCacheWriterPart.class);

	private static final int MaxCount = 20;
	private static final long dMS = 20;
	private static final int MaxRedoCount = 4;
	private static int expiredTime = 600000;//ten minutes
	private static int MaxSqlCount = 50000;

	private DBConnectionPool connectionPool;

	public DBCacheWriterPart(DBConnectionPool connectionPool)
	{
		super(dMS, LoopRunnable.ShutdownLevel.HIGH);
		this.connectionPool = connectionPool;
	}

	ConcurrentLinkedHashMap<String, DBWriterPlayerSql> sqls = new ConcurrentLinkedHashMap.Builder<String, DBWriterPlayerSql>().maximumWeightedCapacity(Integer.MAX_VALUE).build();
	private ConcurrentHashMap<Integer, Long> cacheTime = new ConcurrentHashMap<>();
	private ArrayList<DBWriterPlayerSql> lastSqls = null;
	private int lastSqlDidCount = 0;
	Thread myThread = null;

	public void insertCommand(String key, int playerId, String sql)
	{
		DBWriter.sql_add_count.getAndIncrement();
		long now = System.currentTimeMillis();
		cacheTime.put(playerId, now);
		sqls.put(key, new DBWriterPlayerSql(playerId, sql, now));
	}

	public boolean isContain(int playerId)
	{
		return cacheTime.containsKey(playerId);
	}

	@Override
	public void shutdownHook()
	{
		expiredTime = 0;
		MaxSqlCount = 0;
		while (!sqls.isEmpty() || lastSqls != null)
		{
			execute();
		}
	}

	@Override
	public void execute()
	{
		while (lastSqls != null && lastSqlDidCount < MaxRedoCount)
		{
			++lastSqlDidCount;
			excuteList(lastSqls);

			try
			{
				Thread.sleep(dMS);
			}
			catch (InterruptedException ex)
			{
				logger.error("{}", ExceptionUtils.getStackTrace(ex));
			}
		}

		lastSqlDumpError();
		lastSqlReset();

		while (!sqls.isEmpty())
		{
			ArrayList<DBWriterPlayerSql> myList = new ArrayList<>();
			HashMap<String, DBWriterPlayerSql> myMap = new HashMap<>();
			int i = 0;
			for (Iterator<Map.Entry<String, DBWriterPlayerSql>> it = this.sqls.ascendingMap().entrySet().iterator(); it.hasNext();)
			{
				Map.Entry<String, DBWriterPlayerSql> entry = it.next();
				i++;
				if (i > MaxCount)
				{
					break;
				}
				else if (this.sqls.size() < MaxSqlCount && (System.currentTimeMillis() - entry.getValue().getTime()) < expiredTime)
				{
					break;
				}

				myList.add(entry.getValue());
				myMap.put(entry.getKey(), entry.getValue());
				DBWriter.sql_poll_count.getAndIncrement();
			}
			if (myList == null || myList.size() == 0)
			{
				break;
			}
			else
			{
				for(Map.Entry<String, DBWriterPlayerSql> entry : myMap.entrySet())
				{
					sqls.remove(entry.getKey(), entry.getValue());
				}
			}

			if (myList != null && myList.size() > 0)
			{
				lastSqls = myList;

				lastSqlDidCount = 1;
				excuteList(lastSqls);

				if (lastSqls != null)
				{
					break;
				}
			}
		}
	}

	private void lastSqlReset()
	{
		if (lastSqls != null)
		{
			for (DBWriterPlayerSql sql : lastSqls)
			{
				cacheTime.remove(sql.getPlayerId(), sql.getTime());
			}
		}

		lastSqlDidCount = 0;
		lastSqls = null;
	}

	private void lastSqlDumpError()
	{
		if (lastSqls != null)
		{
			loggerPlayerSqlLog.error("lastSqlDidCount={}", lastSqlDidCount);
			for (DBWriterPlayerSql ps : lastSqls)
			{
				loggerPlayerSqlLog.error("lastSqlDumpError={}", ps.getSql());
			}
		}
	}

	private void excuteList(ArrayList<DBWriterPlayerSql> myList)
	{

		Connection connection = null;
		Statement statement = null;
		try
		{
			connection = this.connectionPool.getConnection();

			try
			{
				connection.setAutoCommit(false);

				try
				{
					statement = connection.createStatement();

					// ---------------------------------------------------------------------
					for (DBWriterPlayerSql playerSql : myList)
					{

						if (playerSql.getSql() == null || playerSql.getSql().equals(""))
						{
							continue;
						}

						if (DBEasy.enableDBLog)
						{
							logger.debug("excuteList[sql]={}", playerSql.getSql());
						}
						statement.addBatch(playerSql.getSql());
					}
					int[] result = statement.executeBatch();
					
					connection.commit();
					lastSqlReset();
					// ---------------------------------------------------------------------
				}
				catch (SQLException e)
				{
					logger.error("Error: {}\n{}", e.getErrorCode(), ExceptionUtils.getStackTrace(e));
					loggerPlayerSqlLog.error("Error: {}\n{}", e.getErrorCode(), ExceptionUtils.getStackTrace(e));
					connection.rollback();
				}
				catch (Exception e)
				{
					logger.error("Error: {}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
					loggerPlayerSqlLog.error("Error: {}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
				}
			}
			catch (SQLException e)
			{
				logger.error("Error: {}\n{}", e.getErrorCode(), ExceptionUtils.getStackTrace(e));
				loggerPlayerSqlLog.error("Error: {}\n{}", e.getErrorCode(), ExceptionUtils.getStackTrace(e));
			}
			finally
			{

				try
				{
					connection.setAutoCommit(true);
				}
				catch (Exception e)
				{
					logger.error("Error: {}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
					loggerPlayerSqlLog.error("Error: {}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
				}

				try
				{
					if (statement != null)
					{
						statement.close();
					}
				}
				catch (Exception e)
				{
					logger.error("Error: {}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
					loggerPlayerSqlLog.error("Error: {}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
				}

				try
				{
					this.connectionPool.closeConnection(connection);
				}
				catch (Exception e)
				{
					logger.error("Error: {}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
					loggerPlayerSqlLog.error("Error: {}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
				}
			}
		}
		catch (SQLException e)
		{
			logger.error("Error: {}\n{}", e.getErrorCode(), ExceptionUtils.getStackTrace(e));
			loggerPlayerSqlLog.error("Error: {}\n{}", e.getErrorCode(), ExceptionUtils.getStackTrace(e));
		}
	}

}
