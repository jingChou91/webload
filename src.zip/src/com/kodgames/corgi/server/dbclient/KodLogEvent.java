package com.kodgames.corgi.server.dbclient;

public class KodLogEvent
{
	public static final int Type_Create = 1;
	public static final int Type_Destroy = 2;

	// createPlayer
	public static final int InitCreatePlayer = 10001;
	public static final int InitLoadPlayer = 10002;

	// AvatarLogic
	public static final int AvatarLogic_AvatarLevelUp = 10100;
	public static final int AvatarLogic_AvatarBreakthought = 10101;
	// EquipLogic
	public static final int EquipLogic_EquipBreakthrough = 10200;
	public static final int EquipLogic_EquipLevelUp = 10201;

	// SkillLogic
	public static final int SkillLogic_SkillLevelUp = 10300;

	// Domineer
	public static final int DomineerLogic_ChangeDomineer = 10400;

	// Meridian
	public static final int MeridianLogic_ChangeMeridian = 10500;

	// ChatLogic_Chat
	public static final int ChatLogic_Chat = 10600;

	// PartnerLogic
	public static final int PartnerLogic_Open = 10700;

	// PositionLogic
	public static final int PositionLogic_Open = 10800;

	// SellLogin
	public static final int SellLogic_SellItem = 10900;

	// GoodsLogic
	public static final int GoodsLogic_BuyAndUse = 11000;
	public static final int GoodsLogic_BuyGoods = 11001;
	public static final int GoodsLogic_ConsumeItem = 11002;
	public static final int GoodsLogic_BuySpecialGoods = 11003;

	//
	public static final int ExchangeCodeLogic_Exchange = 11100;

	//
	public static final int MysteryShopLogic_Refresh = 11200;
	public static final int MysteryShopLogic_Buy = 11201;

	// DinerLogic
	public static final int DinerLogic_HireDiner = 11300;

	//
	public static final int DinerLogic_RenewDiner = 11401;
	public static final int DinerLogic_RefreshDiner = 11402;

	//
	public static final int TavernLogic_Buy = 11500;

	public static final int DailySignInLogic_sign = 11600;
	public static final int DailySignInLogic_Remedy = 11601;

	public static final int PurchaseLogic_Buy = 11700;

	// StartServerReward
	public static final int StartServerRewardLogic_PickReward = 11800;

	// 比武场积分奖励
	public static final int Arena_Grade_Point_Reward = 11900;

	// 玩家升级奖励
	public static final int NotifyLevelUpRewardLogic_AddReward = 12000;
	// levelReward
	public static final int LevelRewardLogic_Get = 12100;

	public static final int Arena_Combat = 12200;
	// 图鉴合成
	public static final int IllustrationLogic_Merge = 12300;

	// DungeonLogic
	public static final int DungeonLogic_Combat = 12400;
	public static final int DungeonLogic_Combat_Secret = 12401;
	public static final int DungeonLogic_QueryDungeonCombatResult = 12402;
	public static final int DungeonLogic_QueryDungeonCombatResult_Secret = 12403;
	public static final int DungeonLogic_ResetCompleteTimes = 12404;
	public static final int DungeonLogic_ResetCompleteTimes_Secret = 12405;
	public static final int DungeonLogic_AddCompleteTimes = 12406;
	public static final int DungeonLogic_AddCompleteTimes_Secret = 12407;
	public static final int DungeonLogic_BuyTravel = 12408;
	public static final int DungeonLogic_BuyTravel_Secret = 12409;
	public static final int DungeonLogic_GetReward = 12410;
	public static final int DungeonLogic_GetReward_Secret = 12411;
	public static final int DungeonLogic_ContinueCombat = 12412;
	public static final int DungeonLogic_ContinueCombat_Secret = 12413;
	public static final int DungeonLogic_DungeonFirstPassRewardCompensate = 12414;

	// 兑换
	public static final int ExchangeLogic_Exchange = 12500;

	// 邮件
	public static final int Email_GetAttachments = 12600;
	// 有间客栈
	public static final int GetFixTime = 12700;

	// 新手引导
	public static final int TutorialLogic_GetTutorialAvatar = 12800;

	// 千层楼
	public static final int MelaleucaFloorLogic_DayReward = 12900;
	public static final int MelaleucaFloorLogic_PassReward = 12902;

	// 聚宝盆
	public static final int TreasureBowl_Exchange = 13000;

	// 每日任务
	public static final int QuestLogic_PickReward = 13100;
	// GM工具
	public static final int GMToolLogic_GiveCost = 13201;
	public static final int GMToolLogic_GiveReward = 13202;
	public static final int GMToolLogic_ChangeLevel = 13203;

	// monthcard
	public static final int MonthCardLogic_Buy = 13300;
	public static final int MonthCardLogic_Pick = 13301;

	// 烽火狼烟
	public static final int WolfSmokeLogic_Buy = 13400;
	public static final int WolfSmokeLogic_Refresh = 13401;
	public static final int WolfSmokeLogic_QueryWolfSmokeCombatResult = 13402;

	// 助手
	public static final int AssistantLogic_Check = 13500;

	// 埋点日志
	public static final int BP_InitPlayer = 13600;
	public static final int BP_Recharge = 13601;

	// 秦时百科
	public static final int QinInfo_Answer = 13700;
	public static final int QinInfo_GetContinueReward = 13701;

	// 累计充值
	public static final int AccumulateLogic_PickReward = 13801;

	// 好友系统
	public static final int FriendLogic_CombatFriend = 13900;

	// Marvllous
	public static final int Marvllous_Check = 14000;
	public static final int MarvellousNextLogic_GetReward = 14001;
	public static final int MarvellousNextLogic_Consume = 14002;
	public static final int MarvellousPickDelayReward = 14003;
	public static final int MarvellousNextLogic_Buy = 14004;

	// 好友副本
	public static final int FriendCampaignLogic_CombatResult = 15000;

	// 幻化系统
	public static final int IllusionLogic_Activate = 16000;
	public static final int IllusionLogic_ActivateAndIllusion = 16001;

	// 酒馆神秘商人
	public static final int MysteryerLogic_Buy = 17000;
	public static final int MysteryerLogic_Refresh = 17001;
	public static final int MysteryerLogic_DeleteWineSoul = 17002;

	// 好友副本排行榜
	public static final int FCRankRewardLogic_Get = 18000;

	// 东海寻仙
	public static final int ZentiaLogic_ExchangeZentiaItem = 19000;
	public static final int ZentiaLogic_Refresh = 19001;
	public static final int ZentiaLogic_BuyZentiaGood = 19002;
	public static final int ZentiaLogic_GetServerReward = 19003;
	public static final int ZentiaLogic_DeleteZentia = 19004;

	// 内丹
	public static final int Dan_Alchemy = 20000;
	public static final int Dan_AlchemyPickBox = 20001;
	public static final int Dan_Decompose = 20002;
	public static final int Dan_AttributeRefresh = 20003;
	public static final int Dan_LevelUp = 20004;
	public static final int Dan_Breakthought = 20005;

	// 门派
	public static final int Guild_CreateGuild = 21001;
	public static final int Guild_BuyPublicGoods = 21002;
	public static final int Guild_BuyPrivateGoods = 21003;
	public static final int Guild_ExchangeActivityGoods = 21004;
	public static final int Guild_Dice = 21005;
	public static final int Guild_RefreshGuildTask = 21006;	
	public static final int Guild_RefreshConstruct = 21007;
	public static final int Guild_AccomplishConstruct = 21008;
	
	// 门派关卡
	public static final int GuildStage_Explore = 22000;
	public static final int GuildStage_CombatBoss = 22001;
	public static final int GuildStage_CombatEnemy = 22002;

	//邀请码
	public static final int Invitecode_Use_Other_Reward = 23000;
	public static final int Invitecode_Pick_Reward = 23001;
	
	//711活动
	public static final int Seven_Eleven_Gift = 24000;
	
	//改名消耗
	public static final int ChangeName_Eleven = 25000;
	
	// 机关兽
	public static final int Beast_Breakthought = 26000;
	public static final int Beast_Exchange = 26001;
	public static final int Beast_RefreshShop = 26002;
	public static final int Beast_Active = 26003;
	public static final int Beast_EquipPart = 26004;
}
