package com.kodgames.corgi.server.dbclient;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicLong;

import com.kodgames.corgi.gameconfiguration.KodThreadName;

public class DBWriter
{
	private static ArrayList<DBWriter> dbwrites = new ArrayList<DBWriter>();
	public static AtomicLong sql_add_count = new AtomicLong();
	public static AtomicLong sql_poll_count = new AtomicLong();

	private DBConnectionPool connectionPool;
	private ArrayList<DBWriterPart> parts = new ArrayList<DBWriterPart>();
	private ArrayList<DBCacheWriterPart> cacheParts = new ArrayList<DBCacheWriterPart>();
	private int dbWriterPartNum = 1;
	private int dbCacheWriterPartNum = 0;

	DBWriter(DBConnectionPool connectionPool, int dbWriterPartNum, int dbCacheWriterPartNum)
	{
		this.connectionPool = connectionPool;
		dbwrites.add(this);

		if (dbWriterPartNum > 0 && dbWriterPartNum <= 10)
		{
			this.dbWriterPartNum = dbWriterPartNum;
		}

		if (dbCacheWriterPartNum >= 0 && dbCacheWriterPartNum <= 10)
		{
			this.dbCacheWriterPartNum = dbCacheWriterPartNum;
		}

		for (int i = 0; i < this.dbWriterPartNum; ++i)
		{
			DBWriterPart part = new DBWriterPart(this.connectionPool);
			parts.add(part);
		}

		for (int i = 0; i < this.dbCacheWriterPartNum; ++i)
		{
			DBCacheWriterPart part = new DBCacheWriterPart(this.connectionPool);
			cacheParts.add(part);
		}
	}

	public boolean isContain(int playerId)
	{
		DBWriterPart part = parts.get(playerId % parts.size());
		DBCacheWriterPart cachePart = cacheParts.get(playerId % cacheParts.size());
		
		boolean contain = false;
		boolean cacheContain = false;
		
		if(part != null)
		{
			contain= part.isContain(playerId);
		}
		
		if(cachePart != null)
		{
			cacheContain = cachePart.isContain(playerId);
		}
		
		return contain || cacheContain;
	}

	public void startThread()
	{
		for (int i = 0; i < parts.size(); ++i)
		{
			DBWriterPart part = parts.get(i);
			part.myThread = new Thread(part, KodThreadName.genName("KOD_DBWriterPartThread"));
			part.myThread.start();
		}

		for (int i = 0; i < cacheParts.size(); ++i)
		{
			DBCacheWriterPart part = cacheParts.get(i);
			part.myThread = new Thread(part, KodThreadName.genName("KOD_DBCacheWriterPartThread"));
			part.myThread.start();
		}
	}

	public void insertCommand(String key, int playerId, String sql)
	{
		DBCacheWriterPart part = cacheParts.get(playerId % cacheParts.size());
		if (part != null)
		{
			part.insertCommand(key, playerId, sql);
		}
	}

	public void insertCommand(int playerId, String sql)
	{
		DBWriterPart part = parts.get(playerId % parts.size());
		if (part != null)
		{
			part.insertCommand(playerId, sql);
		}
	}

	public static StringBuffer dumpSqlNum()
	{

		ArrayList<Long> totalNum = new ArrayList<Long>();
		ArrayList<Long> totalCacheNum = new ArrayList<Long>();
		for (DBWriter dbWriter : dbwrites)
		{
			long totalPart = 0;
			for (int i = 0; i < dbWriter.parts.size(); ++i)
			{
				totalPart += dbWriter.parts.get(i).sqls.size();
			}
			totalNum.add(new Long(totalPart));

			long totalCachePart = 0;
			for (int i = 0; i < dbWriter.cacheParts.size(); ++i)
			{
				totalCachePart += dbWriter.cacheParts.get(i).sqls.size();
			}
			totalCacheNum.add(new Long(totalCachePart));
		}

		StringBuffer sb = new StringBuffer();
		sb.append("sql_add_total=" + sql_add_count.get() + " sql_poll_count=" + sql_poll_count.get());
		sb.append(" total sqls.size()=" + totalNum);
		sb.append(" totalCache sqls.size()=" + totalCacheNum);
		return sb;
	}
}
