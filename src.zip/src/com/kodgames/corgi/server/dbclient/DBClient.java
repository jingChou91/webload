/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kodgames.corgi.server.dbclient;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.rowset.CachedRowSet;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.gamedata.dbcommon.DBEasy;
import com.sun.rowset.CachedRowSetImpl;

/**
 * 
 * @author YHYang
 */
public class DBClient
{
	private DBConnectionPool connectionPool;
	private DBWriter dbWriter;

	private static final Logger logger = LoggerFactory.getLogger(DBClient.class);

	public DBClient(String jdbcUrl, String userName, String password, int dbWriterPartNum, int dbCacheWriterPartNum, int maxConnections, int minConnections)
		throws SQLException, ClassNotFoundException
	{
		this.connectionPool = new DBConnectionPool(jdbcUrl, userName, password,maxConnections,minConnections);
		this.dbWriter = new DBWriter(this.connectionPool, dbWriterPartNum, dbCacheWriterPartNum);

		dbWriter.startThread();
	}

	public DBClient(String jdbcUrl, String userName, String password)
		throws SQLException, ClassNotFoundException
	{
		this.connectionPool = new DBConnectionPool(jdbcUrl, userName, password);
		this.dbWriter = new DBWriter(this.connectionPool, 1, 0);

		dbWriter.startThread();
	}

	public int executeUpdate(String command) throws SQLException
	{
		Connection connection = null;
		Statement statement = null;
		int affectedLine = 0;
		try
		{
			connection = this.connectionPool.getConnection();
			statement = connection.createStatement();
			if (DBEasy.enableDBLog)
				logger.debug("{}", command);
			affectedLine = statement.executeUpdate(command);
		}
		finally
		{
			if(statement != null)
			{
				try
				{
					statement.close();
				}
				catch(Exception e)
				{
					logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
				}
			}
			
			if(connection != null)
			{
				try
				{
					this.connectionPool.closeConnection(connection);
				}
				catch(Exception e)
				{
					logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
				}
			}
		}
		return affectedLine;
	}

	/*
	 * There may be error using this function. executeAsynchronousUpdate is an asynchronous operation, and
	 * executePreparedStatement is a synchronous operation. If you use executeUpdate before executePreparedStatement,
	 * script executed by excutePreparedStatement may be processed earlier than script executed by
	 * executeAsynchronousUpdate.
	 */
	public void executeAsynchronousUpdate(int playerId, String sql)
	{
		this.dbWriter.insertCommand(playerId, sql);
	}
	
	public void executeAsynchronousUpdate(String key, int playerId, String sql)
	{
		this.dbWriter.insertCommand(key, playerId, sql);
	}
	
	public boolean isContain(int playerId)
	{
		return this.dbWriter.isContain(playerId);
	}

	public CachedRowSet executeQuery(String sqlCommand)
		throws SQLException
	{
		Connection connection = null;
		Statement statement = null;
		CachedRowSet cachedRowSet = null;
		try
		{
			connection = this.connectionPool.getConnection();
			statement = connection.createStatement();
			if (DBEasy.enableDBLog)
				logger.debug("{}", sqlCommand);
			ResultSet resultSet = statement.executeQuery(sqlCommand);
			cachedRowSet = new CachedRowSetImpl();
			cachedRowSet.populate(resultSet);
		}
		finally
		{
			if(statement != null)
			{
				try
				{
					statement.close();
				}
				catch(Exception e)
				{
					logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
				}
			}
			
			if(connection != null)
			{
				try
				{
					this.connectionPool.closeConnection(connection);
				}
				catch(Exception e)
				{
					logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
				}
			}
		}
		return cachedRowSet;
	}

	public long executeInsertAndReturnIncrementID(String command)
		throws SQLException
	{
		Connection connection = null;
		Statement statement = null;
		long autoIncrementKey = 0;
		try
		{
			connection = this.connectionPool.getConnection();
			statement = connection.createStatement();
			statement.executeUpdate(command, Statement.RETURN_GENERATED_KEYS);

			ResultSet resultSet = statement.getGeneratedKeys();

			if (resultSet.next())
			{
				autoIncrementKey = resultSet.getInt(1);
			}
		}
		finally
		{
			if(statement != null)
			{
				try
				{
					statement.close();
				}
				catch(Exception e)
				{
					logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
				}
			}
			
			if(connection != null)
			{
				try
				{
					this.connectionPool.closeConnection(connection);
				}
				catch(Exception e)
				{
					logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
				}
			}
		}

		return autoIncrementKey;
	}

	public Connection getConnection()
		throws SQLException
	{
		return this.connectionPool.getConnection();
	}

	public void returnConnection(Connection connection)
		throws SQLException
	{
		this.connectionPool.closeConnection(connection);
	}
}
