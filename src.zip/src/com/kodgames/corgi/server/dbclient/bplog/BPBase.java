package com.kodgames.corgi.server.dbclient.bplog;

import java.text.SimpleDateFormat;
import java.util.Date;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.gameconfiguration.AreaData;
import com.kodgames.corgi.gameconfiguration.CfgDB;

public class BPBase
{
	private static final String APPKEY = "1402474128866";// 游戏标识
	private static final String NORMVERSION = "v1.6";// 服务器日志规范版本号

	private static final char delimit = 0X01;

	// 根据参数生成一条记录
	public static String getCommonRecord(String... args)
	{
		StringBuilder builder = new StringBuilder();
		if (args.length > 0)
		{
			builder.append(getTime());
			builder.append(delimit).append(APPKEY);
			builder.append(delimit).append(args[0]);
			builder.append(delimit).append(args[1]);
			builder.append(delimit).append(NORMVERSION);
			builder.append(delimit).append(args[2]);
			builder.append(delimit).append(AreaData.getAreaId());
			for (int i = 3; i < args.length; i++)
			{
				builder.append(delimit).append(args[i]);
			}
		}
		return builder.toString();
	}
	
	//生成serverevent.log
	public static String getCommonRecordServerEvent(String... args)
	{
		StringBuilder builder = new StringBuilder();
		if (args.length > 0)
		{
			
			if(args[2].equals("2001"))
			{
				args[1] = "IOS";
			}
			else if(args[2].equals("4001"))
			{
				args[1] = "all";
			}
			else
			{
				args[1] = "android";
			}
			builder.append(getTime());
			builder.append(delimit).append(APPKEY);	//time
			builder.append(delimit).append(args[0]);//sdkversion
			builder.append(delimit).append(args[1]);//system("IOS","android","all")
			builder.append(delimit).append(args[2]);//gamechannel
			
			if("".equals(args[3]) || "0".equals(args[3]) || "DefaultUDID".equals(args[3]))
			{
				args[3] = "null";
			}
			builder.append(delimit).append(args[3]);//deviceid
			builder.append(delimit).append(args[4]);//userid
			builder.append(delimit).append(args[5]);//user defined  code
		}
		return builder.toString();
	}

	// 获取当前时间
	public static String getTime()
	{
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return format.format(new Date());
	}

	// 获取新手引导服务器步骤号
	public static String getNewStagesStepNumId(Integer tutorialId)
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
		ClientServerCommon.TutorialConfig tutorialCfg = cd.get_TutorialConfig();

		int index = 0;
		for (int i = 0; i < tutorialCfg.Get_tutorialsCount(); i++)
		{
			if (tutorialCfg.Get_tutorialsByIndex(i).get_id() == tutorialId)
			{
				index = i;
			}
		}

		Integer a = Integer.parseInt(BPLog.NEWSTAGES_STEPNUMID);
		return String.valueOf(a + (index * 10));

	}

	// // 根据参数生成一条记录
	// public static String genRecord(List<String> list)
	// {
	// StringBuilder builder = new StringBuilder();
	// if (list.size() > 0)
	// {
	// builder.append(list.get(0));
	// for (int i = 1; i < list.size(); i++)
	// {
	// builder.append("0x01").append(list.get(i));
	// }
	// }
	// return builder.toString();
	// }

}
