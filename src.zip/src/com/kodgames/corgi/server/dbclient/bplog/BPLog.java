package com.kodgames.corgi.server.dbclient.bplog;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

public class BPLog
{
	// 一级
	private static final Logger logger = LoggerFactory.getLogger(BPLog.class);
	private static final Logger BPLog = LoggerFactory.getLogger("BPLogFile");

	// 日志模块名
	private static final String LOGIN = "login";
	private static final String ROLEBUILD = "rolebuild";
	private static final String ROLELOGIN = "rolelogin";
	private static final String NEWSTAGES = "newstages";
	private static final String LOGOUT = "logout";
	private static final String RECHARGE = "recharge";
	private static final String LEVELUP = "levelup";
	private static final String ACQUIRE = "acquire";
	private static final String MONEYCOST = "moneycost";
	private static final String GETITEM = "getitem";
	private static final String REMOVEITEM = "removeitem";
	private static final String GETTASK = "gettask";
	private static final String FINISHTASK = "finishtask";
	private static final String PVEFIGHT = "PVEfight";
	private static final String ACHIEVEMENT = "achievement";
	private static final String ACTIVITY = "activity";
	private static final String HEART = "heart";
	private static final String VIP = "vip";
	private static final String FHLY = "fhly";
	private static final String XKQH = "xkqh";
	private static final String XKTP = "xktp";
	private static final String XKJM = "xkjm";
	private static final String XKBQ = "xkbq";
	private static final String ZBQH = "zbqh";
	private static final String ZBTP = "zbtp";
	private static final String ZMMK = "zmmk";
	private static final String BWC = "bwc";
	private static final String QJL = "qjl";
	private static final String SJCW = "sjcw";
	private static final String XKHH = "xkhh";
	private static final String QYFIGHT = "qyfight";
	private static final String CARDCHANGE = "cardchange";
	private static final String YQSL = "yqsl";
	private static final String BWCRANK = "bwcrank";
	private static final String DANSJ = "dansj";
	private static final String DANTP = "dantp";
	private static final String DANXL = "danxl";
	private static final String GUILD = "guild";
	private static final String GUILDFIGHT = "guildfight";
	// 步骤号
	private static final String LOGIN_STEPNUMID = "2050";
	private static final String ROLEBUILD_STEPNUMID = "3025";
	private static final String ROLELOGIN_STEPNUMID = "3030";
	public static final String NEWSTAGES_STEPNUMID = "4010";// 基础值
	private static final String LOGOUT_STEPNUMID = "9999";
	private static final String RECHARGE_STEPNUMID = "5050";
	private static final String LEVELUP_STEPNUMID = "6010";
	private static final String ACQUIRE_STEPNUMID = "B1010";
	private static final String MONEYCOST_STEPNUMID = "B1150";
	private static final String GETITEM_STEPNUMID = "B2110";
	private static final String REMOVEITEM_STEPNUMID = "B2150";
	private static final String GETTASK_STEPNUMID = "B3110";
	private static final String FINISHTASK_STEPNUMID = "B3120";
	private static final String PVEFIGHT_STEPNUMID = "B4110";
	private static final String ACHIEVEMENT_STEPNUMID = "B5110";
	private static final String ACTIVITY_STEPNUMID = "B6110";
	private static final String HEART_STEPNUMID = "B9990";
	private static final String XKQH_STEPNUMID = "C0100";
	private static final String XKTP_STEPNUMID = "C0200";
	private static final String XKJM_STEPNUMID = "C0300";
	private static final String XKBQ_STEPNUMID = "C0400";
	private static final String ZBQH_STEPNUMID = "C0500";
	private static final String ZBTP_STEPNUMID = "C0600";
	private static final String ZMMK_STEPNUMID = "C0700";
	private static final String BWC_STEPNUMID = "C0800";
	private static final String QJL_STEPNUMID = "C0900";
	private static final String VIP_STEPNUMID = "C1000";
	private static final String FHLY_STEPNUMID = "C1100";
	private static final String SJCW_STEPNUMID = "C1200";
	private static final String XKHH_STEPNUMID = "C1300";
	private static final String QYFIGHT_STEPNUMID = "C1400";
	private static final String CARDCHANGE_STEPNUMID = "C1500";
	private static final String YQSL_STEPNUMID = "C1600";
	private static final String BWCRANK_STEPNUMID = "C1700";
	private static final String DANSJ_STEPNUMID = "C1800";
	private static final String DANTP_STEPNUMID = "C1900";
	private static final String DANXL_STEPNUMID = "C2000";
	private static final String GUILD_STEPNUMID = "C2100";
	private static final String GUILDFIGHT_STEPNUMID = "C2200";

	// 千机楼
	public static void qjl(String version, String userid, String roleid, String rolelevel, String type, String layer,
		String result, String rnum)
	{
		String record =
			BPBase.getCommonRecord(version, QJL, QJL_STEPNUMID, userid, roleid, rolelevel, type, layer, result, rnum);
		MDC.put("filename", "qjl");
		BPLog.debug(record);
	}

	// 比武场
	public static void bwc(String version, String userid, String roleid, String rolelevel, String result, String rank)
	{
		String record = BPBase.getCommonRecord(version, BWC, BWC_STEPNUMID, userid, roleid, rolelevel, result, rank);
		MDC.put("filename", "bwc");
		BPLog.debug(record);
	}

	// 招募门客
	public static void zmmk(String version, String userid, String roleid, String rolelevel, String type, String mkid)
	{
		String record = BPBase.getCommonRecord(version, ZMMK, ZMMK_STEPNUMID, userid, roleid, rolelevel, type, mkid);
		MDC.put("filename", "zmmk");
		BPLog.debug(record);
	}

	// 装备突破
	public static void zbtp(String version, String userid, String roleid, String rolelevel, String zbid,
		String levelupaf, String levelupbf, String cardnum, String dannum)
	{
		String record =
			BPBase.getCommonRecord(version,
				ZBTP,
				ZBTP_STEPNUMID,
				userid,
				roleid,
				rolelevel,
				zbid,
				levelupaf,
				levelupbf,
				cardnum,
				dannum);
		MDC.put("filename", "zbtp");
		BPLog.debug(record);
	}

	// 装备强化
	public static void zbqh(String version, String userid, String roleid, String rolelevel, String zbid,
		String levelupaf, String levelupbf)
	{
		String record =
			BPBase.getCommonRecord(version, ZBQH, ZBQH_STEPNUMID, userid, roleid, rolelevel, zbid, levelupaf, levelupbf);
		MDC.put("filename", "zbqh");
		BPLog.debug(record);
	}

	// 霸气洗练
	public static void xkbq(String version, String userid, String roleid, String rolelevel, String xkid,
		String cardnum, String dannum)
	{
		String record =
			BPBase.getCommonRecord(version, XKBQ, XKBQ_STEPNUMID, userid, roleid, rolelevel, xkid, cardnum, dannum);
		MDC.put("filename", "xkbq");
		BPLog.debug(record);
	}

	// 经脉洗练
	public static void xkjm(String version, String userid, String roleid, String rolelevel, String xkid, String jmid,
		String type)
	{
		String record =
			BPBase.getCommonRecord(version, XKJM, XKJM_STEPNUMID, userid, roleid, rolelevel, xkid, jmid, type);
		MDC.put("filename", "xkjm");
		BPLog.debug(record);
	}

	// 侠客突破
	public static void xktp(String version, String userid, String roleid, String rolelevel, String xkid,
		String levelupaf, String levelupbf, String cardnum, String dannum)
	{
		String record =
			BPBase.getCommonRecord(version,
				XKTP,
				XKTP_STEPNUMID,
				userid,
				roleid,
				rolelevel,
				xkid,
				levelupaf,
				levelupbf,
				cardnum,
				dannum);
		MDC.put("filename", "xktp");
		BPLog.debug(record);
	}

	// 侠客强化
	public static void xkqh(String version, String userid, String roleid, String rolelevel, String xkid,
		String levelupaf, String levelupbf)
	{
		String record =
			BPBase.getCommonRecord(version, XKQH, XKQH_STEPNUMID, userid, roleid, rolelevel, xkid, levelupaf, levelupbf);
		MDC.put("filename", "xkqh");
		BPLog.debug(record);
	}

	// vip
	public static void vip(String version, String userid, String roleid, String rolelevel, String viplevelaf,
		String viplevelbf, String eventid, String amount)
	{
		String record =
			BPBase.getCommonRecord(version,
				VIP,
				VIP_STEPNUMID,
				userid,
				roleid,
				rolelevel,
				viplevelaf,
				viplevelbf,
				eventid,
				amount);
		MDC.put("filename", "vip");
		BPLog.debug(record);
	}

	// 烽火狼烟
	public static void fhly(String version, String userid, String roleid, String rolelevel, String gkid, String result, String rtimes)
	{
		String record = BPBase.getCommonRecord(version, FHLY, FHLY_STEPNUMID, userid, roleid, rolelevel, gkid, result, rtimes);
		MDC.put("filename", "fhly");
		BPLog.debug(record);
	}

	//书籍参悟
	public static void sjcw(String version, String userid, String roleid, String rolelevel, String sjid, String levelupaf, String levelupbf)
	{
		String record = BPBase.getCommonRecord(version, SJCW, SJCW_STEPNUMID, userid, roleid, rolelevel, sjid, levelupaf,levelupbf);
		MDC.put("filename", "sjcw");
		BPLog.debug(record);
	}
	
	//角色幻化
	public static void xkhh(String version, String userid, String roleid, String rolelevel, String xkid, String hhid)
	{
		String record = BPBase.getCommonRecord(version, XKHH, XKHH_STEPNUMID, userid, roleid, rolelevel, xkid, hhid);
		MDC.put("filename", "xkhh");
		BPLog.debug(record);
	}
		
	//奇遇战斗
	public static void qyfight(String version, String userid, String roleid, String rolelevel, String mapid, String stageid, String result)
	{
		String record = BPBase.getCommonRecord(version, QYFIGHT, QYFIGHT_STEPNUMID, userid, roleid, rolelevel, mapid, stageid, result);
		MDC.put("filename", "qyfight");
		BPLog.debug(record);
	}
	
	//卡牌更换
	public static void cardchange(String version, String userid, String roleid, String rolelevel, String zxid, String placeid, String typeid, String bwid, String xkid1, String level1, String tplevel1, String bqlevel1, String xkid2, String level2, String tplevel2, String bqlevel2)
	{
		String record = BPBase.getCommonRecord(version, CARDCHANGE, CARDCHANGE_STEPNUMID, userid, roleid, rolelevel, zxid, placeid, typeid, bwid, xkid1, level1, tplevel1, bqlevel1, xkid2, level2, tplevel2, bqlevel2);
		MDC.put("filename", "cardchange");
		BPLog.debug(record);
	}
	
	// 友情试炼
	public static void yqsl(String version, String userid, String roleid, String rolelevel, String gkid, String result, String rtimes)
	{
		String record = BPBase.getCommonRecord(version, YQSL, YQSL_STEPNUMID, userid, roleid, rolelevel, gkid, result, rtimes);
		MDC.put("filename", "yqsl");
		BPLog.debug(record);
	}
	
	// 内丹升级
	public static void dansj(String version, String userid, String roleid, String rolelevel, String danid, String pzlevel, String levelupbf, String levelupaf)
	{
		String record = BPBase.getCommonRecord(version, DANSJ, DANSJ_STEPNUMID, userid, roleid, rolelevel, danid, pzlevel, levelupbf, levelupaf);
		MDC.put("filename", "dansj");
		BPLog.debug(record);
	}
	
	// 内丹升阶
	public static void dantp(String version, String userid, String roleid, String rolelevel, String danid, String pzlevelbf, String levelbf, String pzlevelaf, String levelaf)
	{
		String record = BPBase.getCommonRecord(version, DANTP, DANTP_STEPNUMID, userid, roleid, rolelevel, danid, pzlevelbf, levelbf, pzlevelaf, levelaf);
		MDC.put("filename", "dantp");
		BPLog.debug(record);
	}
	
	// 内丹洗练
	public static void danxl(String version, String userid, String roleid, String rolelevel, String danid, String pzlevel)
	{
		String record = BPBase.getCommonRecord(version, DANXL, DANXL_STEPNUMID, userid, roleid, rolelevel, danid, pzlevel);
		MDC.put("filename", "danxl");
		BPLog.debug(record);
	}
	
	// 创建门派
	public static void guild(String version, String userid, String roleid, String rolelevel, String guildid, String guildlevel, String action)
	{
		String record = BPBase.getCommonRecord(version, GUILD, GUILD_STEPNUMID, userid, roleid, rolelevel, guildid, guildlevel, action);
		MDC.put("filename", "guild");
		BPLog.debug(record);
	}
	
	// 门派战斗
	public static void guildfight(String version, String userid, String roleid, String rolelevel, String guildid, String guildlevel, String mapid, String type, String result)
	{
		String record = BPBase.getCommonRecord(version, GUILDFIGHT, GUILDFIGHT_STEPNUMID, userid, roleid, rolelevel, guildid, guildlevel, mapid, type, result);
		MDC.put("filename", "guildfight");
		BPLog.debug(record);
	}

	// 心跳日志
	public static void heart(String version, String onlineuser)
	{
		String record = BPBase.getCommonRecord(version, HEART, HEART_STEPNUMID, onlineuser);
		MDC.put("filename", "heart");
		BPLog.debug(record);
	}

	// 参与活动
	public static void activity(String version, String userid, String roleid, String rolelevel, String activityid)
	{
		String record =
			BPBase.getCommonRecord(version, ACTIVITY, ACTIVITY_STEPNUMID, userid, roleid, rolelevel, activityid);
		MDC.put("filename", "activity");
		BPLog.debug(record);
	}

	// 完成成就
	public static void achievement(String version, String userid, String roleid, String rolelevel, String achievementid)
	{
		String record =
			BPBase.getCommonRecord(version,
				ACHIEVEMENT,
				ACHIEVEMENT_STEPNUMID,
				userid,
				roleid,
				rolelevel,
				achievementid);
		logger.debug(record);
	}

	// pve战斗
	public static void pveFight(String version, String userid, String roleid, String rolelevel, String stageid,
		String type, String npcid, String result, String mapid, String star)
	{
		String record =
			BPBase.getCommonRecord(version,
				PVEFIGHT,
				PVEFIGHT_STEPNUMID,
				userid,
				roleid,
				rolelevel,
				stageid,
				type,
				npcid,
				result,
				mapid,
				star);
		MDC.put("filename", "pvefight");
		BPLog.debug(record);
	}

	// 完成任务
	public static void finishTask(String version, String userid, String roleid, String rolelevel, String taskid,
		String result)
	{
		String record =
			BPBase.getCommonRecord(version, FINISHTASK, FINISHTASK_STEPNUMID, userid, roleid, rolelevel, taskid, result);
		logger.debug(record);
	}

	// 接受任务
	public static void getTask(String version, String userid, String roleid, String rolelevel, String taskid,
		String result)
	{
		String record =
			BPBase.getCommonRecord(version, GETTASK, GETTASK_STEPNUMID, userid, roleid, rolelevel, taskid, result);
		logger.debug(record);
	}

	// 物品消耗
	public static void removeItem(String version, String userid, String roleid, String rolelevel, String itemtype,
		String itemid, String causeid, String quantity)
	{
		String record =
			BPBase.getCommonRecord(version,
				REMOVEITEM,
				REMOVEITEM_STEPNUMID,
				userid,
				roleid,
				rolelevel,
				itemtype,
				itemid,
				causeid,
				quantity);
		MDC.put("filename", "removeitem");
		BPLog.debug(record);
	}

	// 物品获得
	public static void getItem(String version, String userid, String roleid, String rolelevel, String itemtypeid,
		String itemid, String causeid, String quantity)
	{
		String record =
			BPBase.getCommonRecord(version,
				GETITEM,
				GETITEM_STEPNUMID,
				userid,
				roleid,
				rolelevel,
				itemtypeid,
				itemid,
				causeid,
				quantity);
		MDC.put("filename", "getitem");
		BPLog.debug(record);
	}

	// 货币消耗
	public static void moneyCost(String version, String userid, String roleid, String rolelevel, String causeid,
		String quantity, String total, String typeid)
	{
		String record =
			BPBase.getCommonRecord(version,
				MONEYCOST,
				MONEYCOST_STEPNUMID,
				userid,
				roleid,
				rolelevel,
				causeid,
				quantity,
				total,
				typeid);
		MDC.put("filename", "moneycost");
		BPLog.debug(record);
	}

	// 经验或货币获得
	public static void acquire(String version, String userid, String roleid, String rolelevel, String causeid,
		String quantity, String total, String typeid)
	{
		String record =
			BPBase.getCommonRecord(version,
				ACQUIRE,
				ACQUIRE_STEPNUMID,
				userid,
				roleid,
				rolelevel,
				causeid,
				quantity,
				total,
				typeid);
		MDC.put("filename", "acquire");
		BPLog.debug(record);
	}

	// 升级
	public static void levelUp(String version, String userid, String roleid, String rolename, String rolelevelaf,
		String rolelevelbf)
	{
		String record =
			BPBase.getCommonRecord(version,
				LEVELUP,
				LEVELUP_STEPNUMID,
				userid,
				roleid,
				rolename,
				rolelevelaf,
				rolelevelbf);
		MDC.put("filename", "levelup");
		BPLog.debug(record);
	}

	// 充值
	public static void recharge(String version, String gamechannel, String userid, String roleid, String rolelevel,
		String amount, String rechargechannel, String valuequantity, String currency, String ip, String valueamount)
	{
		String record =
			BPBase.getCommonRecord(version,
				RECHARGE,
				RECHARGE_STEPNUMID,
				gamechannel,
				userid,
				roleid,
				rolelevel,
				amount,
				rechargechannel,
				valuequantity,
				currency,
				ip,
				valueamount);
		MDC.put("filename", "recharge");
		BPLog.debug(record);
	}

	// 登出
	public static void logout(String version, String gamechannel, String userid, String accname, String roleid,
		String rolename, String rolelevel, String deviceid, String valueamount, String onlinetimes)
	{
		String record =
			BPBase.getCommonRecord(version,
				LOGOUT,
				LOGOUT_STEPNUMID,
				gamechannel,
				userid,
				accname,
				roleid,
				rolename,
				rolelevel,
				deviceid,
				valueamount,
				onlinetimes);
		MDC.put("filename", "logout");
		BPLog.debug(record);
	}

	// 新手引导
	public static void newStages(String version, String gamechannel, String userid, String roleid, String rolelevel,
		Integer tutorialId)
	{
		String eventId = tutorialId.toString();
		String record =
			BPBase.getCommonRecord(version,
				NEWSTAGES,
				BPBase.getNewStagesStepNumId(tutorialId),
				gamechannel,
				userid,
				roleid,
				rolelevel,
				eventId);
		MDC.put("filename", "newstages");
		BPLog.debug(record);
	}

	// 角色登录
	public static void roleLogin(String version, String gamechannel, String userid, String accname, String roleid,
		String rolename, String rolelevel, String deviceid, String valueamount)
	{
		String record =
			BPBase.getCommonRecord(version,
				ROLELOGIN,
				ROLELOGIN_STEPNUMID,
				gamechannel,
				userid,
				accname,
				roleid,
				rolename,
				rolelevel,
				deviceid,
				valueamount);
		MDC.put("filename", "rolelogin");
		BPLog.debug(record);

	}

	// 创建角色
	public static void roleBuild(String version, String gamechannel, String userid, String roleid, String rolename,
		String roletypeid)
	{
		String record =
			BPBase.getCommonRecord(version,
				ROLEBUILD,
				ROLEBUILD_STEPNUMID,
				gamechannel,
				userid,
				roleid,
				rolename,
				roletypeid);
		MDC.put("filename", "rolebuild");
		BPLog.debug(record);

	}

	// 登录
	public static void login(String version, String gamechannel, String userid, String accname, String roleid,
		String rolename, String rolelevel, String deviceid, String ip, String valueamount)
	{
		String record =
			BPBase.getCommonRecord(version,
				LOGIN,
				LOGIN_STEPNUMID,
				gamechannel,
				userid,
				accname,
				roleid,
				rolename,
				rolelevel,
				deviceid,
				ip,
				valueamount);
		MDC.put("filename", "login");
		BPLog.debug(record);
	}

	// 发起token验证
	public static void serverEvent(String version, String system, String gamechannel, String userid, String deviceid,
		String code)
	{
		String record = BPBase.getCommonRecordServerEvent(version, system, gamechannel, deviceid, userid, code);
		MDC.put("filename", "serverevent");
		BPLog.debug(record);
	}
	
	// 比武场排名
	public static void bwcrank(String version, String userId, String roleid, String rolelevel, int bwcrank)
	{
		String record = BPBase.getCommonRecord(version, BWCRANK, BWCRANK_STEPNUMID, userId, roleid, rolelevel, String.valueOf(bwcrank));
		MDC.put("filename", "bwcrank");
		BPLog.debug(record);
	}
}
