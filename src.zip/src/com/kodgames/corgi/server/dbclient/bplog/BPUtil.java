package com.kodgames.corgi.server.dbclient.bplog;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.CorgiUID;
import com.kodgames.corgi.server.gameserver.diner.data.Diner;
import com.kodgames.corgi.server.gameserver.position.data.Location;
import com.kodgames.corgi.server.gameserver.position.data.Position;
import com.kodgames.gamedata.player.GamePlayer;
import com.kodgames.gamedata.player.PlayerInfo;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.ItemType;

public class BPUtil
{
	private static final Logger logger = LoggerFactory.getLogger(BPUtil.class);
	// ++++++++++++++++++++++++++++++一级日志+++++++++++++++++++++++++++++++
	// 登录
	public static void login(PlayerNode playerNode, ClientNode sender)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String gameChannelId = getGameChannelId(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String realMoney_s = String.valueOf(gamePlayer.getRealMoney());
		String userId = getUserId(playerNode);
		String accname = getAccname(playerNode);
		String udid = getUdid(playerNode);
		String ip = doIp(sender.getClientUID().getIpMessage());
		BPLog.login(version,
			gameChannelId,
			userId,
			accname,
			playerId_s,
			gamePlayer.getFixName(),
			level_s,
			udid,
			ip,
			realMoney_s);
		BPLog.roleLogin(version,
			gameChannelId,
			userId,
			accname,
			playerId_s,
			gamePlayer.getFixName(),
			level_s,
			udid,
			realMoney_s);
	}

	// 创建角色
	public static void roleBuild(PlayerNode playerNode)
	{
		CorgiUID corgiUID = playerNode.getPlayerInfo().getClientLoginMessage().getCorgiUID();
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(corgiUID);
		String gameChannelId = getGameChannelId(corgiUID);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String fixName = gamePlayer.getFixName();
		String userId = getUserId(corgiUID);
		BPLog.roleBuild(version, gameChannelId, userId, playerId_s, fixName, "null");
	}

	// 新手引导
	public static void newStages(PlayerNode playerNode, Integer tutorialId)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String gameChannelId = getGameChannelId(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.newStages(version, gameChannelId, userId, playerId_s, level_s, tutorialId);
	}

	// 登出
	public static void logout(PlayerNode playerNode)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String gameChannelId = getGameChannelId(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String fixName = gamePlayer.getFixName();
		String realMoney_s = String.valueOf(gamePlayer.getRealMoney());
		String userId = getUserId(playerNode);
		String accname = getAccname(playerNode);
		String udid = getUdid(playerNode);
		Long loginTime = playerNode.getPlayerInfo().getClientLoginMessage().getLoginTime();
		String onlineTimes = String.valueOf((System.currentTimeMillis() - loginTime) / 1000);
		BPLog.logout(version,
			gameChannelId,
			userId,
			accname,
			playerId_s,
			fixName,
			level_s,
			udid,
			realMoney_s,
			onlineTimes);
	}

	// 升级
	public static void levelUp(PlayerNode playerNode, int oldLevel)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String fixName = gamePlayer.getFixName();
		String userId = getUserId(playerNode);
		BPLog.levelUp(version, userId, playerId_s, fixName, level_s, String.valueOf(oldLevel));
	}

	// 充值
	public static void recharge(PlayerNode playerNode, int rmb, int valuequantity, int valueamount, String userId,
		String marketChannelId)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String gameChannelId_s = marketChannelId;
//		if (gameChannelId_s.equals("0"))
//		{
//			gameChannelId_s = "null";
//		}
		String channelId_s = String.valueOf(gamePlayer.getChannelId());
		if (channelId_s.equals("0"))
		{
			channelId_s = "null";
		}
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String ip = "null";
		if (playerNode.getPlayerInfo().getClientLoginMessage().getCorgiUID() != null)
		{
			ip = playerNode.getPlayerInfo().getClientLoginMessage().getCorgiUID().getIpMessage();
		}
		// String rmb_s = String.valueOf(rmb);
		String valuequantity_s = String.valueOf(valuequantity);
		String valueamount_s = String.valueOf(valueamount);
		BPLog.recharge(version,
			gameChannelId_s,
			userId,
			playerId_s,
			level_s,
			toMoney(rmb),
			channelId_s,
			valuequantity_s,
			"1",
			ip,
			valueamount_s);
	}

	// ++++++++++++++++++++++++++++++二级日志+++++++++++++++++++++++++++++++
	// 经验货币获得
	public static void acquire(PlayerNode playerNode, int causeid, int quantity, int total, int typeid)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.acquire(version,
			userId,
			playerId_s,
			level_s,
			String.valueOf(causeid),
			String.valueOf(quantity),
			String.valueOf(total),
			String.valueOf(typeid));
	}

	// 货币消耗
	public static void moneyCost(PlayerNode playerNode, int causeid, int quantity, int total, int typeid)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.moneyCost(version,
			userId,
			playerId_s,
			level_s,
			String.valueOf(causeid),
			String.valueOf(-quantity),
			String.valueOf(total),
			String.valueOf(typeid));
	}

	// 物品获得
	public static void getItem(PlayerNode playerNode, int itemtypeid, int itemid, int causeid, int quantity)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.getItem(version,
			userId,
			playerId_s,
			level_s,
			String.valueOf(itemtypeid),
			String.valueOf(itemid),
			String.valueOf(causeid),
			String.valueOf(quantity));
	}

	// 物品消耗
	public static void removeItem(PlayerNode playerNode, int itemtypeid, int itemid, int causeid, int quantity)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.removeItem(version,
			userId,
			playerId_s,
			level_s,
			String.valueOf(itemtypeid),
			String.valueOf(itemid),
			String.valueOf(causeid),
			String.valueOf(quantity));
	}

	// 接受任务
	public static void getTask(PlayerNode playerNode, int taskid, int result)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.getTask(version, userId, playerId_s, level_s, String.valueOf(taskid), String.valueOf(result));
	}

	// 完成任务
	public static void finishTask(PlayerNode playerNode, int taskid, int result)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.finishTask(version, userId, playerId_s, level_s, String.valueOf(taskid), String.valueOf(result));
	}

	// 关卡战斗
	public static void pveFight(PlayerNode playerNode, int dungeonId, String type, int npcId, String result, int mapId,
		int star)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.pveFight(version,
			userId,
			playerId_s,
			level_s,
			toStr(dungeonId),
			type,
			toStr(npcId),
			result,
			toStr(mapId),
			String.valueOf(star));
	}

	// 完成成就
	public static void achievement(PlayerNode playerNode, String achievementid)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.achievement(version, userId, playerId_s, level_s, achievementid);
	}

	// 完成活动
	public static void activity(PlayerNode playerNode, Integer activityid)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.activity(version, userId, playerId_s, level_s, String.valueOf(activityid));
	}

	// 心跳日志
	public static void heart(Integer onlineuser)
	{
		BPLog.heart("null", String.valueOf(onlineuser));
	}

	// +++++++++++++++++++++++++++++++三级日志++++++++++++++++++++++++++++++

	// 千机楼
	public static void qjl(PlayerNode playerNode, int type, int layer, int result, int rnum)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.qjl(version, userId, playerId_s, level_s, toStr(type), toStr(layer), toStr(result), toStr(rnum));
	}

	// 比武场
	public static void bwc(PlayerNode playerNode, int result, int rank)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.bwc(version, userId, playerId_s, level_s, toStr(result), toStr(rank));
	}

	// 装备突破
	public static void zmmk(PlayerNode playerNode, int type, int mkid)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.zmmk(version, userId, playerId_s, level_s, toStr(type), toStr(mkid));
	}

	// 装备突破
	public static void zbtp(PlayerNode playerNode, int zbid, int levelupaf, int levelupbf, int cardnum, int dannum)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.zbtp(version,
			userId,
			playerId_s,
			level_s,
			toStr(zbid),
			toStr(levelupaf),
			toStr(levelupbf),
			toStr(cardnum),
			toStr(dannum));
	}

	// 装备强化
	public static void zbqh(PlayerNode playerNode, int zbid, int levelupaf, int levelupbf)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.zbqh(version, userId, playerId_s, level_s, toStr(zbid), toStr(levelupaf), toStr(levelupbf));
	}

	// 霸气洗练
	public static void xkbq(PlayerNode playerNode, int xkid, int cardnum, int dannum)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.xkbq(version, userId, playerId_s, level_s, toStr(xkid), toStr(cardnum), toStr(dannum));
	}

	// 经脉洗练
	public static void xkjm(PlayerNode playerNode, int xkid, int jmid, int type)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.xkjm(version, userId, playerId_s, level_s, toStr(xkid), toStr(jmid), toStr(type));
	}

	// 侠客突破
	public static void xktp(PlayerNode playerNode, int xkid, int levelupaf, int levelupbf, int cardnum, int dannum)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.xktp(version,
			userId,
			playerId_s,
			level_s,
			toStr(xkid),
			toStr(levelupaf),
			toStr(levelupbf),
			toStr(cardnum),
			toStr(dannum));
	}

	// 侠客强化
	public static void xkqh(PlayerNode playerNode, int oldLevel, int xkid, int levelupaf, int levelupbf)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.xkqh(version, userId, playerId_s, level_s, toStr(xkid), toStr(levelupaf), toStr(levelupbf));
	}

	// vip
	public static void vip(PlayerNode playerNode, int viplevelaf, int viplevelbf, int eventid, int amount)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.vip(version,
			userId,
			playerId_s,
			level_s,
			toStr(viplevelaf),
			toStr(viplevelbf),
			toStr(eventid),
			toMoney(amount));
	}

	// 烽火狼烟
	public static void fhly(PlayerNode playerNode, int gkid, int result, int rtimes)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.fhly(version, userId, playerId_s, level_s, toStr(gkid), toStr(result), toStr(rtimes));
	}

	// 书籍参悟
	public static void sjcw(PlayerNode playerNode, int sjid, int levelupaf, int levelupbf)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.sjcw(version, userId, playerId_s, level_s, toStr(sjid), toStr(levelupaf), toStr(levelupbf));
	}
	
	// 角色幻化
	public static void xkhh(PlayerNode playerNode, int xkid, int hhid)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.xkhh(version, userId, playerId_s, level_s, toStr(xkid), toStr(hhid));
	}

	// 奇遇战斗
	public static void qyfight(PlayerNode playerNode, int mapid, int stageid, int result)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.qyfight(version, userId, playerId_s, level_s, toStr(mapid), toStr(stageid), toStr(result));
	}
	
	// 卡牌更换
	public static void cardchange(PlayerNode playerNode, int zxid, int placeid, Location location, int xkid1, Guid xkGuid1, int xkid2, Guid xkGuid2)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		String tplevel1 = "0";
		String bqlevel1 = "0";
		String tplevel2 = "0";
		String bqlevel2 = "0";
		int typeid = 0;
		String bwid = null;
		int level1 = 0;
		int level2 = 0;
		
		try
		{
			if (xkid1 != 0 && xkGuid1 != null)
			{
				if (ItemType.isEquipment(xkid1))
				{
					typeid = 2;
					tplevel1 = toStr(playerNode.getPlayerInfo().getEquipData().getEquipment(xkGuid1).getBreakthoughtLevel());
					bwid = toStr(ConfigDatabase.get_DefaultCfg().get_EquipmentConfig().GetEquipmentById(xkid1).get_type());
					level1 = playerNode.getPlayerInfo().getEquipData().getEquipment(xkGuid1).getLevel();
				}
				else if (ItemType.isSkill(xkid1))
				{
					typeid = 3;
					bwid = toStr(location.getIndex());
					level1 = playerNode.getPlayerInfo().getSkillData().getSkill(xkGuid1).getLevel();
				}
				else if (ItemType.isAvatar(xkid1))
				{
					Position position = playerNode.getPlayerInfo().getPositionData().getPositions().get(zxid);
					if (position != null && location.getLocationId() == position.getEmployLocationId())
					{
						typeid = 4;
						Diner diner = playerNode.getPlayerInfo().getDinerInfoData().getDinerData().getDiner(xkGuid1);
						if (diner != null)
						{
							xkid1 = diner.getDinerId();
						}
					}
					else 
					{
						typeid = 1;
						tplevel1 = toStr(playerNode.getPlayerInfo().getAvatarData().getAvatar(xkGuid1).getBreakthoughtLevel());
						bqlevel1 = toStr(playerNode.getPlayerInfo().getDomineerData().getDomineerLevel(xkGuid1));
						level1 = playerNode.getPlayerInfo().getAvatarData().getAvatar(xkGuid1).getLevel();
					}
				}
				else if (ItemType.isDan(xkid1))
				{
					typeid = 5;
					tplevel1 = toStr(playerNode.getPlayerInfo().getDanData().getDan(xkGuid1).getBreakthoughtLevel());
					bwid = toStr(ConfigDatabase.get_DefaultCfg().get_DanConfig().GetDanById(xkid1).get_Type());
					level1 = playerNode.getPlayerInfo().getDanData().getDan(xkGuid1).getLevel();
				}
			}
			
			if (xkid2 != 0 && xkGuid2 != null)
			{
				if (ItemType.isEquipment(xkid2))
				{
					typeid = 2;
					tplevel2 = toStr(playerNode.getPlayerInfo().getEquipData().getEquipment(xkGuid2).getBreakthoughtLevel());
					bwid = toStr(ConfigDatabase.get_DefaultCfg().get_EquipmentConfig().GetEquipmentById(xkid2).get_type());
					level2 = playerNode.getPlayerInfo().getEquipData().getEquipment(xkGuid2).getLevel();
				}
				else if (ItemType.isSkill(xkid2))
				{
					typeid = 3;
					bwid = toStr(location.getIndex());
					level2 = playerNode.getPlayerInfo().getSkillData().getSkill(xkGuid2).getLevel();
				}
				else if (ItemType.isAvatar(xkid2))
				{
					
					Position position = playerNode.getPlayerInfo().getPositionData().getPositions().get(zxid);
					if (position != null && location.getLocationId() == position.getEmployLocationId())
					{
						typeid = 4;
						Diner diner = playerNode.getPlayerInfo().getDinerInfoData().getDinerData().getDiner(xkGuid2);
						if (diner != null)
						{
							xkid2 = diner.getDinerId();
						}
					}
					else 
					{
						typeid = 1;
						tplevel2 = toStr(playerNode.getPlayerInfo().getAvatarData().getAvatar(xkGuid2).getBreakthoughtLevel());
						bqlevel2 = toStr(playerNode.getPlayerInfo().getDomineerData().getDomineerLevel(xkGuid2));
						level2 = playerNode.getPlayerInfo().getAvatarData().getAvatar(xkGuid2).getLevel();
					}
				}
				else if (ItemType.isDan(xkid2))
				{
					typeid = 5;
					tplevel2 = toStr(playerNode.getPlayerInfo().getDanData().getDan(xkGuid2).getBreakthoughtLevel());
					bwid = toStr(ConfigDatabase.get_DefaultCfg().get_DanConfig().GetDanById(xkid2).get_Type());
					level2 = playerNode.getPlayerInfo().getDanData().getDan(xkGuid2).getLevel();
				}
			}
		}
		catch (Exception e)
		{
			logger.error("BPUtil create cardchange log  failed \n{}", ExceptionUtils.getStackTrace(e));
		}
		
		String zx = null;
		if (zxid == -1)
		{
			zx = "partner";
		}
		else 
		{
			zx = toStr(zxid);
		}
		BPLog.cardchange(version, userId, playerId_s, level_s, zx, toStr(placeid), toStr(typeid), bwid, toStr(xkid1), toStr(level1), tplevel1, bqlevel1, toStr(xkid2), toStr(level2), tplevel2, bqlevel2);
	}
	
	// 友情试炼
	public static void yqsl(PlayerNode playerNode, int gkid, int result, int rtimes)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.yqsl(version, userId, playerId_s, level_s, toStr(gkid), toStr(result), toStr(rtimes));
	}
	
	// 内丹升级
	public static void dansj(PlayerNode playerNode, int danid, int pzlevel, int levelbf, int levelupaf)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.dansj(version, userId, playerId_s, level_s, toStr(danid), toStr(pzlevel), toStr(levelbf), toStr(levelupaf));
	}
	
	// 内丹突破
	public static void dantp(PlayerNode playerNode, int danid, int pzlevelbf, int levelbf, int pzlevelaf, int levelaf)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.dantp(version, userId, playerId_s, level_s, toStr(danid), toStr(pzlevelbf), toStr(levelbf), toStr(pzlevelaf), toStr(levelaf));
	}
	
	// 内丹洗练
	public static void danxl(PlayerNode playerNode, int danid, int pzlevel)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.danxl(version, userId, playerId_s, level_s, toStr(danid), toStr(pzlevel));
	}
	
	// 创建门派
	public static void guild(PlayerNode playerNode, int leftPlayerId, int guildid, int guildlevel, int action)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		// 离开门派
		if (action == -1)
		{
			playerId_s = String.valueOf(leftPlayerId);
		}
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.guild(version, userId, playerId_s, level_s, toStr(guildid), toStr(guildlevel), toStr(action));
	}
	
	// 门派战斗
	public static void guildfight(PlayerNode playerNode, int guildid, int guildlevel, int mapid, int type, int result)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		String version = getVersion(playerNode);
		String playerId_s = String.valueOf(playerNode.getPlayerId());
		String level_s = String.valueOf(gamePlayer.getLevel());
		String userId = getUserId(playerNode);
		BPLog.guildfight(version, userId, playerId_s, level_s, toStr(guildid), toStr(guildlevel), toStr(mapid), toStr(type), toStr(result));
	}
	
	/**
	 * 
	*<table border="0" cellpadding="0" cellspacing="1" width="100%" bgcolor="#000000" align="center">
	*<tr bgcolor="#00FFFF" align="center"><td>序号</td><td>字段名称</td><td>英文名称</td><td>字段类型</td><td>是否必填</td><td>是否必填</td></tr> 
	*<tr bgcolor="#FFFFFF" align="center"><td>1</td><td>时间</td><td>yyyy-mm-dd HH:mi:ss</td><td>字符串</td><td>是</td><td> </td></tr>
	*<tr bgcolor="#FFFFFF" align="center"><td>2</td><td>游戏标识</td><td>appkey</td><td>字符串</td><td>是</td><td> </td></tr>
	*<tr bgcolor="#FFFFFF" align="center"><td>3</td><td>游戏版本</td><td>version</td><td>字符串</td><td>是</td><td> </td></tr>
	*<tr bgcolor="#FFFFFF" align="center"><td>4</td><td>日志模块名</td><td>bwcrank</td><td>字符串</td><td>是</td><td>默认值"bwcrank"  </td></tr>
	*<tr bgcolor="#FFFFFF" align="center"><td>5</td><td>服务器日志规范版本号</td><td>normversion</td><td>字符串</td><td>是</td><td> </td></tr>
	*<tr bgcolor="#FFFFFF" align="center"><td>6</td><td>步骤号</td><td>stepnumid</td><td>字符串</td><td>是</td><td>默认值"C1700"</td></tr>
	*<tr bgcolor="#FFFFFF" align="center"><td>7</td><td>游戏服务器</td><td>idserverid</td><td>字符串</td><td>是</td><td> </td></tr>
	*<tr bgcolor="#FFFFFF" align="center"><td>8</td><td>账号</td><td>iduserid</td><td>字符串</td><td>是</td><td> </td></tr>
	*<tr bgcolor="#FFFFFF" align="center"><td>9</td><td>角色</td><td>idroleid</td><td>字符串</td><td>是</td><td> </td></tr>
	*<tr bgcolor="#FFFFFF" align="center"><td>10 </td><td>角色等级</td><td>rolelevel</td><td>正整数</td><td>是</td><td> </td></tr>
	*<tr bgcolor="#FFFFFF" align="center"><td>11 </td><td>比武场排名</td><td>bwcrank</td><td>字符串</td><td>是</td><td> </td></tr>
	*</table>
	 */
	// 比武场排名
	public static void bwcrank(PlayerNode playerNode, String rolelevel, int bwcrank)
	{
		String version = getVersion(playerNode);
		String userId = getUserId(playerNode);
		String roleId = String.valueOf(playerNode.getPlayerId());
		BPLog.bwcrank(version, userId, roleId, rolelevel, bwcrank);
	}
	/*
	 * 机器人
	 */
	public static void bwcrank(int playerId, String rolelevel, int bwcrank)
	{
		String version = "null";
		String userId = "null";
		String roleId = String.valueOf(playerId);
		BPLog.bwcrank(version, userId, roleId, rolelevel, bwcrank);
	}
	
	// ++++++++++++++++++++++++++++++四级日志+++++++++++++++++++++++++++++++
	public static void serverEvent(String version, String system, String gamechannel, String userid, String deviceid,
		String code)
	{
		BPLog.serverEvent(version, system, gamechannel, userid, deviceid, code);
	}

	public static String doIp(String ip)
	{
		String[] tmp = ip.replace("/", "").split(":");
		if (tmp.length > 0)
		{
			return tmp[0];
		}
		return "null";
	}

	public static String getUserId(PlayerNode playerNode)
	{
		String userId = "null";
		PlayerInfo playerInfo = playerNode.getPlayerInfo();
		if(playerInfo == null)
		{
			return userId;
		}
		CorgiUID corgiUID = playerInfo.getClientLoginMessage().getCorgiUID();
		if (corgiUID != null)
		{
			userId = corgiUID.getChannelUniqueId();
			if ("".equals(userId) || "0".equals(userId))
			{
				userId = "null";
			}
		}
		return userId;
	}

	public static String getUserId(CorgiUID corgiUID)
	{
		String userId = "null";
		if (corgiUID != null)
		{
			userId = corgiUID.getChannelUniqueId();
			if ("".equals(userId) || "0".equals(userId))
			{
				userId = "null";
			}
		}
		return userId;
	}

	public static String getAccname(PlayerNode playerNode)
	{
		String accname = "null";
		PlayerInfo playerInfo = playerNode.getPlayerInfo();
		if(playerInfo == null)
		{
			return accname;
		}
		CorgiUID corgiUID = playerInfo.getClientLoginMessage().getCorgiUID();
		if (corgiUID != null)
		{
			accname = corgiUID.getChannelUniqueId();
			if ("".equals(accname) || "0".equals(accname))
			{
				accname = "null";
			}
		}
		return accname;
	}

	public static String getUdid(PlayerNode playerNode)
	{
		String udid = "null";
		PlayerInfo playerInfo = playerNode.getPlayerInfo();
		if(playerInfo == null)
		{
			return udid;
		}
		CorgiUID corgiUID = playerInfo.getClientLoginMessage().getCorgiUID();
		if (corgiUID != null)
		{
			udid = corgiUID.getDeviceInfo().getUDID();
			if ("".equals(udid) || "0".equals(udid) || "DefaultUDID".equals(udid))
			{
				udid = "null";
			}
		}
		return udid;
	}

	public static String getGameChannelId(PlayerNode playerNode)
	{
		String gameChannelId = "null";
		PlayerInfo playerInfo = playerNode.getPlayerInfo();
		if(playerInfo == null)
		{
			return gameChannelId;
		}
		CorgiUID corgiUID = playerInfo.getClientLoginMessage().getCorgiUID();
		if (corgiUID != null)
		{
			gameChannelId = corgiUID.getMarketChannelId();
			if ("".equals(gameChannelId) || "0".equals(gameChannelId))
			{
				gameChannelId = "null";
			}
		}
		return gameChannelId;
	}

	public static String getGameChannelId(CorgiUID corgiUID)
	{
		String gameChannelId = "null";
		if (corgiUID != null)
		{
			gameChannelId = corgiUID.getMarketChannelId();
			if ("".equals(gameChannelId) || "0".equals(gameChannelId))
			{
				gameChannelId = "null";
			}
		}
		return gameChannelId;
	}

	public static String getVersion(PlayerNode playerNode)
	{
		String version = "null";
		PlayerInfo playerInfo = playerNode.getPlayerInfo();
		if(playerInfo == null)
		{
			return version;
		}
		CorgiUID corgiUID = playerInfo.getClientLoginMessage().getCorgiUID();
		if (corgiUID != null)
		{
			version = corgiUID.getClientVersion();
			if ("".equals(version) || "0".equals(version))
			{
				version = "null";
			}
		}
		return version;
	}

	public static String getVersion(CorgiUID corgiUID)
	{
		String version = "null";
		if (corgiUID != null)
		{
			version = corgiUID.getClientVersion();
			if ("".equals(version) || "0".equals(version))
			{
				version = "null";
			}
		}
		return version;
	}

	// int转string
	public static String toStr(int value)
	{
		return String.valueOf(value);
	}

	// int转string
	public static String toMoney(int value)
	{
		return String.valueOf(value) + ".0";
	}
}
