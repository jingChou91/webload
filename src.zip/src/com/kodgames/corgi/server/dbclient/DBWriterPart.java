package com.kodgames.corgi.server.dbclient;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.server.common.LoopRunnable;
import com.kodgames.gamedata.dbcommon.DBEasy;

public class DBWriterPart extends LoopRunnable
{
	private static final Logger loggerPlayerSqlLog = LoggerFactory.getLogger("PlayerSqlLog");
	private static final Logger logger = LoggerFactory.getLogger(DBWriterPart.class);

	private static final int MaxCount = 20;
	private static final long dMS = 20;
	private static final int MaxRedoCount = 4;

	private DBConnectionPool connectionPool;

	public DBWriterPart(DBConnectionPool connectionPool)
	{
		super(dMS, LoopRunnable.ShutdownLevel.HIGH);
		this.connectionPool = connectionPool;
	}

	ConcurrentLinkedDeque<DBWriterPlayerSql> sqls = new ConcurrentLinkedDeque<>();
	private ConcurrentHashMap<Integer, Long> cacheTime = new ConcurrentHashMap<>();
	private ArrayList<DBWriterPlayerSql> lastSqls = null;
	private int lastSqlDidCount = 0;
	Thread myThread = null;

	public void insertCommand(int playerId, String sql)
	{
		DBWriter.sql_add_count.getAndIncrement();
		long now = System.currentTimeMillis();
		cacheTime.put(playerId, now);
		sqls.add(new DBWriterPlayerSql(playerId, sql, now));
	}

	public boolean isContain(int playerId)
	{
		return cacheTime.containsKey(playerId);
	}

	@Override
	public void shutdownHook()
	{
		while (!sqls.isEmpty() || lastSqls != null)
		{
			this.execute();
		}
	}

	@Override
	public void execute()
	{
		while (lastSqls != null && lastSqlDidCount < MaxRedoCount)
		{
			++lastSqlDidCount;
			excuteList(lastSqls);

			try
			{
				Thread.sleep(dMS);
			}
			catch (InterruptedException ex)
			{
				logger.error("{}", ExceptionUtils.getStackTrace(ex));
			}
		}

		lastSqlDumpError();
		lastSqlReset();

		while (!sqls.isEmpty())
		{
			ArrayList<DBWriterPlayerSql> myList = new ArrayList<DBWriterPlayerSql>();

			for (int i = 0; i < MaxCount; ++i)
			{
				if (!sqls.isEmpty())
				{
					myList.add(sqls.poll());
					DBWriter.sql_poll_count.getAndIncrement();
				}
				else
				{
					break;
				}
			}

			if (myList != null && myList.size() > 0)
			{
				lastSqls = myList;

				lastSqlDidCount = 1;
				excuteList(lastSqls);

				if (lastSqls != null)
				{
					break;
				}
			}
		}
	}

	private void lastSqlReset()
	{
		if (lastSqls != null)
		{
			for (DBWriterPlayerSql sql : lastSqls)
			{
				cacheTime.remove(sql.getPlayerId(), sql.getTime());
			}
		}

		lastSqlDidCount = 0;
		lastSqls = null;
	}

	private void lastSqlDumpError()
	{
		if (lastSqls != null)
		{
			loggerPlayerSqlLog.error("lastSqlDidCount={}", lastSqlDidCount);
			for (DBWriterPlayerSql ps : lastSqls)
			{
				loggerPlayerSqlLog.error("lastSqlDumpError={}", ps.getSql());
			}
		}
	}

	private void excuteList(ArrayList<DBWriterPlayerSql> myList)
	{

		Connection connection = null;
		Statement statement = null;
		try
		{
			connection = this.connectionPool.getConnection();

			try
			{
				connection.setAutoCommit(false);

				try
				{
					statement = connection.createStatement();

					// ---------------------------------------------------------------------
					for (DBWriterPlayerSql playerSql : myList)
					{

						if (playerSql.getSql() == null || playerSql.getSql().equals(""))
						{
							continue;
						}

						if (DBEasy.enableDBLog)
						{
							logger.debug("excuteList[sql]={}", playerSql.getSql());
						}
						statement.addBatch(playerSql.getSql());
					}
					
					int[] result = statement.executeBatch();

					connection.commit();
					lastSqlReset();
					// ---------------------------------------------------------------------
				}
				catch (SQLException e)
				{
					logger.error("Error: {}\n{}", e.getErrorCode(), ExceptionUtils.getStackTrace(e));
					loggerPlayerSqlLog.error("Error: {}\n{}", e.getErrorCode(), ExceptionUtils.getStackTrace(e));
					connection.rollback();
				}
				catch (Exception e)
				{
					logger.error("Error: {}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
					loggerPlayerSqlLog.error("Error: {}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
				}
			}
			catch (SQLException e)
			{
				logger.error("Error: {}\n{}", e.getErrorCode(), ExceptionUtils.getStackTrace(e));
				loggerPlayerSqlLog.error("Error: {}\n{}", e.getErrorCode(), ExceptionUtils.getStackTrace(e));
			}
			finally
			{

				try
				{
					connection.setAutoCommit(true);
				}
				catch (Exception e)
				{
					logger.error("Error: {}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
					loggerPlayerSqlLog.error("Error: {}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
				}

				try
				{
					if (statement != null)
					{
						statement.close();
					}
				}
				catch (Exception e)
				{
					logger.error("Error: {}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
					loggerPlayerSqlLog.error("Error: {}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
				}

				try
				{
					this.connectionPool.closeConnection(connection);
				}
				catch (Exception e)
				{
					logger.error("Error: {}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
					loggerPlayerSqlLog.error("Error: {}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
				}
			}
		}
		catch (SQLException e)
		{
			logger.error("Error: {}\n{}", e.getErrorCode(), ExceptionUtils.getStackTrace(e));
			loggerPlayerSqlLog.error("Error: {}\n{}", e.getErrorCode(), ExceptionUtils.getStackTrace(e));
		}
	}

}
