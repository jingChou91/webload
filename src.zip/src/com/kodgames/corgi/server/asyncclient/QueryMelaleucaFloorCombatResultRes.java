package com.kodgames.corgi.server.asyncclient;

import java.util.LinkedList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.MelaleucaFloorConfig;

import com.kodgames.combat.record.BattleRecord;
import com.kodgames.combat.record.CombatResultAndReward;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols.MelaleucaFloorInfo;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.corgi.protocol.ServersProtocolsForServer.QueryCombatResultRes;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.melaleucaFloor.data.Melaleuca;
import com.kodgames.corgi.server.gameserver.melaleucaFloor.data.MelaleucaFloorData;
import com.kodgames.corgi.server.gameserver.melaleucaFloor.data.MelaleucaMgr;
import com.kodgames.corgi.server.gameserver.melaleucaFloor.data.Rank;
import com.kodgames.corgi.server.gameserver.quest.data.QuestEventFactory;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class QueryMelaleucaFloorCombatResultRes implements AsyncMessager
{
	private static final Logger logger = LoggerFactory.getLogger(QueryArenaCombatResultRes.class);

	private int callback;
	private int playerId;
	private int layers;
	private Rank rank;
	private int week;
	private MelaleucaFloorData data;
	ClientNode sender;
	private long timeNow;
	private ConfigDatabase cd;

	public QueryMelaleucaFloorCombatResultRes(int callback, int playerId, int layers, Rank rank, int week, MelaleucaFloorData data, ClientNode sender, long timeNow,ConfigDatabase cd)
	{
		super();
		this.callback = callback;
		this.playerId = playerId;
		this.layers = layers;
		this.rank = rank;
		this.data = data;
		this.sender = sender;
		this.timeNow = timeNow;
		this.cd = cd;
	}

	@Override
	public void handlerMessage(Protocol message)
	{
		logger.info("recv QueryMelaleucaFloorCombatResultRes, playerId = {}", playerId);
		QueryCombatResultRes request = (QueryCombatResultRes) message.getProtoBufMessage();

		GameProtocolsForClient.GC_MelaleucaFloorCombatRes.Builder builder = GameProtocolsForClient.GC_MelaleucaFloorCombatRes.newBuilder();
		builder.setCallback(callback);

		int result = ClientProtocols.E_GAME_MELALEUCA_FLOOR_COMBAT_SUCCESS;
		int startLayer = rank.getDayLayer();
		CostAndRewardAndSync totalCrs = new CostAndRewardAndSync();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_MELALEUCA_FLOOR_COMBAT_FAILED_LOAD_PLAYER;
					break;
				}

				if (cd == null || cd.get_MelaleucaFloorConfig() == null)
				{
					result = ClientProtocols.E_GAME_MELALEUCA_FLOOR_COMBAT_FAILED_LOAD_CONFIG;
					break;
				}
				MelaleucaFloorConfig config = cd.get_MelaleucaFloorConfig();

				if (request.getResult() != ServerProtocols.E_ALL_QUERY_COMBAT_RESULT_SUCCESS)
				{
					result = request.getResult();
					break;
				}

				int battleRecordsCount = request.getBatttleRecordsCount();
				if (battleRecordsCount <= 0)
				{
					result = ClientProtocols.E_COMBAT_BATTLE_RECORD_ERROR_BAD_BATTLE_RECORD_COUNT;
					break;
				}
				int maxLayer = rank.getDayLayer()+battleRecordsCount;

				// 把多次的战斗结果保存
				LinkedList<BattleRecord> battleRecords = new LinkedList<BattleRecord>();
				CombatResultAndReward combatResultAndReward = new CombatResultAndReward();
				for (int i = 0; i < battleRecordsCount; i++)
				{
					BattleRecord battleRecord = new BattleRecord();
					battleRecord.fromProtoBufClass(request.getBatttleRecords(i));
					battleRecords.add(battleRecord);
				}
				combatResultAndReward.setBattleRecords(battleRecords);
				combatResultAndReward.setCombatNumMax(request.getCombatNumMax());
				combatResultAndReward.setCombatNumReal(request.getCombatNumReal());
				builder.setCombatResultAndReward(combatResultAndReward.toProtobuf());

				// 战斗胜利奖励
				if (request.getBatttleRecordsList().get(battleRecordsCount - 1).getTeamRecord(0).getIsWinner())
				{
					// 每日首次挑战奖励
					if (!rank.isDayChallenged())
					{
						MelaleucaMgr.setDayChallenged(playerId, rank);

						Reward perDayReward = new Reward();
						for (int i = 0; i < cd.get_MelaleucaFloorConfig().Get_ChallengeRewardPerDayCount(); i++)
						{
							perDayReward.fromClientServerCommon(cd.get_MelaleucaFloorConfig().Get_ChallengeRewardPerDayByIndex(i));
						}
						CostAndRewardAndSync perDayCrs = new CostAndRewardAndSync();
						perDayCrs.mergeReward(perDayReward);
						totalCrs.megerCostAndRewardAndSync(perDayCrs);
						builder.setFirstChallengeReward(perDayCrs.toProtobuf());
						
						playerNode.getPlayerInfo().getAssisantData().getMelaleucaDailyPass().notifyObservers();
					}

					int maxPassLayer = data.getMaxPassLayer();
					int maxConfigLayer = config.Get_FloorsCount();
					for (int i = 1; i <= this.layers; i++)
					{
						int floor = (startLayer + i > maxConfigLayer) ? maxConfigLayer : startLayer + i;
						MelaleucaFloorConfig.Floor floorConfig = config.GetFloorByLayer(floor);

						// 通关奖励
						CostAndRewardAndSync passCrs = new CostAndRewardAndSync();
						for (int j = 0; j < floorConfig.Get_PassRewardCount(); j++)
						{
							passCrs.mergeReward(new Reward().fromClientServerCommon(floorConfig.Get_PassRewardByIndex(j)));
						}
						totalCrs.megerCostAndRewardAndSync(passCrs);
						builder.addPassReward(passCrs.toProtobuf());

						// 首次通关奖励
						if (startLayer + i > maxPassLayer)
						{
							maxPassLayer = startLayer + i;
							CostAndRewardAndSync firstPassCrs = new CostAndRewardAndSync();
							for (int j = 0; j < floorConfig.Get_FirstPassRewardCount(); j++)
							{
								firstPassCrs.mergeReward(new Reward().fromClientServerCommon(floorConfig.Get_FirstPassRewardByIndex(j)));
							}
							totalCrs.megerCostAndRewardAndSync(firstPassCrs);
							builder.addFirstPassReward(firstPassCrs.toProtobuf());
							builder.addFirstPassLayers(startLayer + i);
						}
					}

					MelaleucaMgr.updatePlayerMaxPassLayer(playerId, data, maxPassLayer);

					// 积分奖励
					MelaleucaFloorConfig.Challenge challengeConfig = config.GetChallengeByLayers(layers);

					int rewardPoint = challengeConfig.get_Point();
					MelaleucaMgr.addPlayrDayPointAndLayer(playerId, rank, rewardPoint, layers, timeNow);

					if (totalCrs.getRewardForRead() != null)
					{
						CostAndRewardManager.addReward(playerNode, totalCrs.getRewardForRead(), cd, KodLogEvent.MelaleucaFloorLogic_PassReward);
					}

					if (layers == 8)
					{
						// 固定任务
						QuestEventFactory.createMelaleucaChallengeEvent(playerNode, cd);
					}

				}
				else
				{
					int failsCost = config.get_ChallengeCostPerTimes();
					MelaleucaMgr.addPlayerFailsCount(playerId, rank, failsCost);
				}

				MelaleucaFloorInfo info = Melaleuca.genMeleleucaFloorInfo(playerId, week, data, rank, config);
				builder.setMelaleucaFloorInfo(info);

				//Log
				int maxFailsTimes = cd.get_VipConfig().GetVipLimitByVipLevel(playerNode.getGamePlayer().getVipLevel(), ClientServerCommon.VipConfig._VipLimitType.MelaleucaFloorChallengeCount);
				if(request.getBatttleRecordsList().get(battleRecordsCount - 1).getTeamRecord(0).getIsWinner())
				{
					BPUtil.qjl(playerNode, layers, maxLayer, 1, maxFailsTimes-rank.getDayFailsCount());
				}
				else
				{
					BPUtil.qjl(playerNode, layers, maxLayer, 0, maxFailsTimes-rank.getDayFailsCount());
				}
				
				rank.combatUnlock();
			}
			while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		builder.setLayers(layers);
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_MELALEUCA_FLOOR_COMBAT_RES);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);

	}

	@Override
	public String getName()
	{
		return this.getClass().getSimpleName();
	}

}
