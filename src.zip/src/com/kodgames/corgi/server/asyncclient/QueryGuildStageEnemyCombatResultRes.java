package com.kodgames.corgi.server.asyncclient;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.GuildStageConfig;

import com.kodgames.combat.record.BattleRecord;
import com.kodgames.combat.record.CombatResultAndReward;
import com.kodgames.common.ValueRandomer;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CombatData;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_GuildStageExploreRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.corgi.protocol.ServersProtocolsForServer.QueryCombatResultRes;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.email.util.specialemail.EmailGuildUtil;
import com.kodgames.corgi.server.gameserver.guild.data.Guild;
import com.kodgames.corgi.server.gameserver.guild.data.GuildMgr;
import com.kodgames.corgi.server.gameserver.guildstage.data.GuildStageData;
import com.kodgames.corgi.server.gameserver.guildstage.data.GuildStageMgr;
import com.kodgames.corgi.server.gameserver.guildstage.data.struct.Stage;
import com.kodgames.corgi.server.gameserver.guildstage.util.StageMsgUtil;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;
import com.kodgames.gamedata.player.costandreward.RewardDBGroup;

public class QueryGuildStageEnemyCombatResultRes implements AsyncMessager
{

	private int callback;
	private int playerId;
	ClientNode sender;
	CostAndRewardAndSync crsForClient;
	private ConfigDatabase cd;
	private GuildStageConfig.Stage stageCfg;
	private GuildStageConfig.Event eventCfg;
	private Stage stage;
	private Guild guild;
	private int mapNum;
	private int activityNum;
	private static final Logger logger = LoggerFactory.getLogger(QueryGuildStageEnemyCombatResultRes.class);

	public QueryGuildStageEnemyCombatResultRes(int callback, int playerId, ClientNode sender,
		CostAndRewardAndSync crsToclient, ConfigDatabase cd, GuildStageConfig.Stage stageCfg,
		GuildStageConfig.Event eventCfg, Stage stage, Guild guild, int mapNum, int activityNum)
	{
		this.callback = callback;
		this.playerId = playerId;
		this.sender = sender;
		this.crsForClient = crsToclient;
		this.cd = cd;
		this.stageCfg = stageCfg;
		this.eventCfg = eventCfg;
		this.stage = stage;
		this.guild = guild;
		this.mapNum = mapNum;
		this.activityNum = activityNum;
	}

	@Override
	public String getName()
	{
		return this.getClass().getSimpleName();
	}

	@Override
	public void handlerMessage(Protocol message)
	{
		logger.info("recv QueryFriendCombatResultRes, playerId = {}", playerId);
		QueryCombatResultRes request = (QueryCombatResultRes)message.getProtoBufMessage();

		GC_GuildStageExploreRes.Builder builder = GC_GuildStageExploreRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_GUILD_STAGE_EXPLORE_RES);
		builder.setCallback(callback);

		int result = ClientProtocols.E_GAME_GUILD_STAGE_EXPLORE_SUCCESS;

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_GUILD_STAGE_EXPLORE_FAILED_LOAD_PLAYER;
					break;
				}
				if (request.getResult() != ServerProtocols.E_ALL_QUERY_COMBAT_RESULT_SUCCESS)
				{
					result = request.getResult();
					break;
				}
				if (request.getBatttleRecordsCount() <= 0)
				{
					result = ClientProtocols.E_GAME_GUILD_STAGE_EXPLORE_FAILED_ERROR_BAD_BATTLE_RECORD_COUNT;
					break;
				}

				// 判断战斗结果数据是否有问题.
				BattleRecord battleRecordtemp = new BattleRecord();
				battleRecordtemp.fromProtoBufClass(request.getBatttleRecords(0));
				if (battleRecordtemp.getTeamRecords() == null && battleRecordtemp.getTeamRecords().size() <= 0)
				{
					result = ClientProtocols.E_GAME_GUILD_STAGE_EXPLORE_FAILED_ERROR_BAD_TEAM_RECORD;
					break;
				}
				// 转换战斗结果
				LinkedList<BattleRecord> battleRecords = new LinkedList<BattleRecord>();
				for (CombatData.BattleRecord combatbattleRecord : request.getBatttleRecordsList())
				{
					BattleRecord battleRecord = new BattleRecord();
					battleRecord.fromProtoBufClass(combatbattleRecord);
					battleRecords.add(battleRecord);
				}
				// 保存战斗结果
				CombatResultAndReward combatResultAndReward = new CombatResultAndReward();
				combatResultAndReward.setBattleRecords(battleRecords);
				combatResultAndReward.setCombatNumMax(1);

				// 如果战败,增加失败次数
				int battleRecordsCount = battleRecords.size();
				boolean isWinner = battleRecords.get(battleRecordsCount - 1).getTeamRecords().get(0).isWinner();
				GuildMgr.lockGuild(guild);
				try
				{
					GuildStageData stageData = playerNode.getPlayerInfo().getGuildStageData();
					GuildStageMgr guildStageMgr = guild.getGuildStageMgr();
					// 战胜
					if (isWinner)
					{
						// 生成奖励
						List<ClientServerCommon.Reward> results = new ArrayList<ClientServerCommon.Reward>();
						for (int j = 0; j < eventCfg.Get_RewardGroupsCount(); j++)
						{
							ValueRandomer random = new ValueRandomer();
							GuildStageConfig.RewardGroup rewardGroup = eventCfg.Get_RewardGroupsByIndex(j);
							for (int k = 0; k < rewardGroup.Get_RewardWeightsCount(); k++)
							{
								GuildStageConfig.RewardWeight rewardWeight = rewardGroup.Get_RewardWeightsByIndex(k);
								random.addValue(rewardWeight.get_Weight(), rewardWeight.get_Reward());
							}
							random.SetTotalValue();
							Object data = random.RandomData();
							if (data != null)
							{
								results.add((ClientServerCommon.Reward)data);
							}
						}

						// 生成奖励
						Reward reward = new Reward();
						{
							for (ClientServerCommon.Reward tmp : results)
							{
								reward.megerReward(new Reward().fromClientServerCommon(tmp));
							}
						}
						combatResultAndReward.setDungeonReward(reward);

						// 邮件和消息
						if (stage.getEventType() == GuildStageConfig._EventType.Enemy)
						{
							// 合并各项通过奖励
							Reward rewardAll = new Reward();
							rewardAll.megerReward(reward);
							// 把奖励存入内存
							CostAndRewardAndSync crsForReward = new CostAndRewardAndSync();
							crsForReward.mergeReward(rewardAll);
							CostAndRewardManager.addReward(playerNode,
								rewardAll,
								cd,
								KodLogEvent.GuildStage_CombatEnemy);
							crsForClient.megerCostAndRewardAndSync(crsForReward);
							// 消息
							StageMsgUtil.personKillEnemyMsg(cd, playerId, reward, eventCfg);
						}
						else if (stage.getEventType() == GuildStageConfig._EventType.HiddenEnemy)
						{
							// 邮件
							String fmt =
								cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_Guild_KillHiddenEnemy");
							fmt = String.format(fmt, eventCfg.get_Name(), reward.genRewardNameStr(cd));
							EmailGuildUtil.sendPlayerEmail(playerNode.getPlayerId(), fmt, reward);
							// 消息
							StageMsgUtil.personKillHiddenEnemyMsg(cd, playerId, reward, eventCfg);
							StageMsgUtil.guildKillHiddenEnemyMsg(cd, playerNode, guildStageMgr, reward, eventCfg);
						}

						// 修改内存
						stage.setCompletePlayerId(playerId);
						stage.setStatus(GuildStageConfig._StageStatus.Complete);
						stage.setRewardDBGroup(RewardDBGroup.genRewardDBGroup(results));
						int mapNum = playerNode.getPlayerInfo().getGuildStageData().getMapNum();
						stageData.updateIndex(mapNum, stage.getIndex());
					}
					else
					{
						// 修改内存
						stage.setStatus(GuildStageConfig._StageStatus.Searching);
					}
					// 处理地图100%探索完成奖励
					guildStageMgr.isMapComplete(playerNode, cd, guild, mapNum, activityNum);
					// 更新数据库
					GuildStageMgr.updateDB(playerNode, guild.getGuildId());

					// 返回客户端
					combatResultAndReward.setCombatNumMax(request.getCombatNumMax());
					combatResultAndReward.setCombatNumReal(request.getCombatNumReal());
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					builder.setCombatResultAndReward(combatResultAndReward.toProtobuf());
					// 返回节点详细信息
					builder.setOperateType(GuildStageConfig._ExploreOperateType.Explore);
					builder.setStageInfo(stage.toStageInfoProto(cd,
						playerId,
						cd.get_GuildStageConfig(),
						stageCfg,
						eventCfg,
						guildStageMgr,
						activityNum,
						mapNum));

					// 埋点日志
					{
						int type = 0; // 事件类型 0未知
						int isWin = isWinner ? 1 : 0; // 战斗结果 1胜利 0失败
						if (stage.getEventType() == GuildStageConfig._EventType.Enemy)
						{
							type = 1;
						}
						else if (stage.getEventType() == GuildStageConfig._EventType.HiddenEnemy)
						{
							type = 2;
						}
						BPUtil.guildfight(playerNode, guild.getGuildId(), guild.getGuildLevel(), mapNum, type, isWin);
					}
				}
				finally
				{
					GuildMgr.unlockGuild(guild);
				}

			} while (false);
		}
		catch (Exception e)
		{
			logger.error(ExceptionUtils.getStackTrace(e));
			result = ClientProtocols.E_SERVER_PROC_ERROR;
		}
		finally
		{
			// 解锁(无论出现什么错误,都要解锁)
			stage.unCombatLock();
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
	}
}
