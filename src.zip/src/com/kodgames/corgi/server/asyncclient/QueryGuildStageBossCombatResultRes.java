package com.kodgames.corgi.server.asyncclient;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.GuildStageConfig;

import com.kodgames.combat.record.BattleRecord;
import com.kodgames.combat.record.CombatAvatarData;
import com.kodgames.combat.record.CombatPlayer;
import com.kodgames.combat.record.CombatResultAndReward;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CombatData;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_GuildStageCombatBossRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.corgi.protocol.ServersProtocolsForServer.QueryCombatResultRes;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.email.util.specialemail.EmailGuildUtil;
import com.kodgames.corgi.server.gameserver.guild.data.Guild;
import com.kodgames.corgi.server.gameserver.guild.data.GuildManager;
import com.kodgames.corgi.server.gameserver.guild.data.GuildMgr;
import com.kodgames.corgi.server.gameserver.guild.data.GuildMemberMgr.GuildMember;
import com.kodgames.corgi.server.gameserver.guildstage.data.GuildStageData;
import com.kodgames.corgi.server.gameserver.guildstage.data.GuildStageMgr;
import com.kodgames.corgi.server.gameserver.guildstage.data.struct.BossHurtRank;
import com.kodgames.corgi.server.gameserver.guildstage.data.struct.MapInfo;
import com.kodgames.corgi.server.gameserver.guildstage.data.struct.Stage;
import com.kodgames.corgi.server.gameserver.guildstage.util.GuildShopUtil;
import com.kodgames.corgi.server.gameserver.guildstage.util.StageMsgUtil;
import com.kodgames.corgi.server.gameserver.guildstage.util.StageUtil;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.Reward;

public class QueryGuildStageBossCombatResultRes implements AsyncMessager
{

	private int callback;
	private int playerId;
	ClientNode sender;
	CostAndRewardAndSync crsForClient;
	private ConfigDatabase cd;
	private GuildStageConfig.Event eventCfg;
	private Stage stage;
	private Guild guild;
	private int activityNum;
	private CombatPlayer enemyPlayer;
	private MapInfo mapInfo;
	private static final Logger logger = LoggerFactory.getLogger(QueryGuildStageBossCombatResultRes.class);

	public QueryGuildStageBossCombatResultRes(int callback, int playerId, ClientNode sender,
		CostAndRewardAndSync crsToclient, ConfigDatabase cd, GuildStageConfig.Event eventCfg, Stage stage, Guild guild,
		int activityNum, CombatPlayer enemyPlayer, MapInfo mapInfo)
	{
		this.callback = callback;
		this.playerId = playerId;
		this.sender = sender;
		this.crsForClient = crsToclient;
		this.cd = cd;
		this.eventCfg = eventCfg;
		this.stage = stage;
		this.guild = guild;
		this.activityNum = activityNum;
		this.enemyPlayer = enemyPlayer;
		this.mapInfo = mapInfo;
	}

	@Override
	public String getName()
	{
		return this.getClass().getSimpleName();
	}

	@Override
	public void handlerMessage(Protocol message)
	{
		logger.info("recv QueryFriendCombatResultRes, playerId = {}", playerId);
		QueryCombatResultRes request = (QueryCombatResultRes)message.getProtoBufMessage();

		GC_GuildStageCombatBossRes.Builder builder = GC_GuildStageCombatBossRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_GUILD_STAGE_COMBAT_BOSS_RES);
		builder.setCallback(callback);

		int result = ClientProtocols.E_GAME_GUILD_STAGE_COMBAT_BOSS_SUCCESS;

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_GUILD_STAGE_COMBAT_BOSS_FAILED_LOAD_PLAYER;
					break;
				}
				if (request.getResult() != ServerProtocols.E_ALL_QUERY_COMBAT_RESULT_SUCCESS)
				{
					result = request.getResult();
					break;
				}
				if (request.getBatttleRecordsCount() <= 0)
				{
					result = ClientProtocols.E_GAME_GUILD_STAGE_COMBAT_BOSS_FAILED_BAD_BATTLE_RECORD_COUNT;
					break;
				}

				// 判断战斗结果数据是否有问题.
				BattleRecord battleRecordtemp = new BattleRecord();
				battleRecordtemp.fromProtoBufClass(request.getBatttleRecords(0));
				if (battleRecordtemp.getTeamRecords() == null && battleRecordtemp.getTeamRecords().size() <= 0)
				{
					result = ClientProtocols.E_GAME_GUILD_STAGE_COMBAT_BOSS_FAILED_BAD_TEAM_RECORD;
					break;
				}
				// 转换战斗结果
				LinkedList<BattleRecord> battleRecords = new LinkedList<BattleRecord>();
				for (CombatData.BattleRecord combatbattleRecord : request.getBatttleRecordsList())
				{
					BattleRecord battleRecord = new BattleRecord();
					battleRecord.fromProtoBufClass(combatbattleRecord);
					battleRecords.add(battleRecord);
				}
				// 保存战斗结果
				CombatResultAndReward combatResultAndReward = new CombatResultAndReward();
				combatResultAndReward.setBattleRecords(battleRecords);
				combatResultAndReward.setCombatNumMax(1);

				// 如果战败,增加失败次数
				int battleRecordsCount = battleRecords.size();
				boolean isWinner = battleRecords.get(battleRecordsCount - 1).getTeamRecords().get(0).isWinner();
				GuildMgr.lockGuild(guild);
				try
				{
					GuildStageConfig guildStageCfg = cd.get_GuildStageConfig();
					GuildStageData stageData = playerNode.getPlayerInfo().getGuildStageData();
					GuildStageMgr guildStageMgr = guild.getGuildStageMgr();
					int mapNum = playerNode.getPlayerInfo().getGuildStageData().getMapNum();
					GuildStageConfig.MapBaseInfo mapBaseInfo =
						StageUtil.getMapBaseInfo(guildStageCfg, activityNum, mapNum);
					if (mapBaseInfo == null)
					{
						result = ClientProtocols.E_GAME_GUILD_STAGE_COMBAT_BOSS_FAILED_ERROR_MAP_NUM;
						break;
					}

					// 更新Boss伤害排行榜
					{
						Double totalHp = StageUtil.getTotalHp(cd, enemyPlayer);
						// 原剩余总血量
						Double oldTotalLeftHp = StageUtil.getTotalLeftHp(stage.getBossHPLeft(), cd, enemyPlayer);
						// 新剩余血量百分比
						HashMap<Integer, Double> bossLeftHps = StageUtil.getEnemyLeftHP(battleRecords);
						// 新剩余总血量
						Double newTotalLeftHp = StageUtil.getTotalLeftHp(bossLeftHps, cd, enemyPlayer);

						double hurtValue = oldTotalLeftHp - newTotalLeftHp;
						if (hurtValue < 0)
						{
							hurtValue = 0;
						}
						double hurtPercent = oldTotalLeftHp / totalHp - newTotalLeftHp / totalHp;
						if (hurtPercent < 0)
						{
							hurtPercent = 0;
						}
						logger.debug("___________stage combat Boss  index:" + stage.getIndex() + "  eventId:"
							+ stage.getEventId() + " oldToaltHp:" + oldTotalLeftHp + " newTtalHp:" + newTotalLeftHp
							+ "  hurtPercent:" + hurtPercent + " hurtVAlue" + hurtValue);
						// 更新Boss伤害排行榜
						guildStageMgr.addBossHurtRank(mapNum,
							stage.getIndex(),
							stage.getEventId(),
							playerId,
							hurtPercent,
							hurtValue,
							cd);

						builder.setThisData(StageUtil.genRankPro(hurtPercent, hurtValue));
					}
					// 保存敌方血量
					StageUtil.saveEnemyLeftHP(stage, battleRecords);

					// boss伤害排行榜
					BossHurtRank bossHurtRank = guildStageMgr.getBossHurtRank(cd, mapNum, stage.getIndex());
					
					// boss天赋削弱前的总血量，查询boss伤害排行榜明细时使用
					double bossTotalHP = 0;
					for (CombatAvatarData tmpAvatarData : enemyPlayer.getCombatAvatarDatas())
					{
						bossTotalHP += tmpAvatarData.getTotalHPFotGSRank();
					}
					if (bossTotalHP != 0 && bossHurtRank != null)
					{
						bossHurtRank.setTotalHP(bossTotalHP);
					}
					
					// 战胜
					if (isWinner)
					{
						// 先修改内存,后发奖
						stage.setCompletePlayerId(playerId);
						stage.setStatus(GuildStageConfig._StageStatus.Complete);
						stageData.updateIndex(mapNum, stage.getIndex());
						// boss修改为已死亡
						stage.setIsBossDead(1);
						if (stage.getEventType() == GuildStageConfig._EventType.PassBoss)
						{
							guildStageMgr.addWeekKillPassBossCount();
							mapInfo.addKilledPassBossCount();
						}
						else if (stage.getEventType() == GuildStageConfig._EventType.ChallengeBoss)
						{
							guildStageMgr.addWeekKillChallengeBossCount();
							mapInfo.addKilledChallengeBossCount();
						}

						// // 邮件
						// for (Map.Entry<Integer, GuildMember> entry : guild.getGuildMemberMgr()
						// .getPlayerId_members()
						// .entrySet())
						// {
						// String fmt = cd.get_StringsConfig().GetString("UI",
						// "ServerText_EmailBody_Guild_WhenKillBoss");
						// fmt = String.format(fmt, mapNum, eventCfg.get_Name());
						// EmailGuildUtil.sendPlayerEmail(entry.getKey(), fmt, null);
						// }

						// 发送奖励邮件
						GuildStageConfig.BossReward bossRewardCfg = null;
						if (stage.getEventType() == GuildStageConfig._EventType.PassBoss)
						{
							bossRewardCfg = guildStageCfg.GetPassBossReward(mapBaseInfo.get_PassBossRewardId());
						}
						else if (stage.getEventType() == GuildStageConfig._EventType.ChallengeBoss)
						{
							bossRewardCfg =
								guildStageCfg.GetChallengeBossReward(mapBaseInfo.get_ChallengeBossRewardId());
						}
						if (bossRewardCfg == null)
						{
							result = ClientProtocols.E_GAME_GUILD_STAGE_COMBAT_BOSS_FAILED_LOAD_BOSS_CONFIG;
							break;
						}

						int emailType = ClientServerCommon._MailType.GuildBossKilledNoShop;
						if (GuildShopUtil.isActiviteShopGoods(playerNode, cd, stage.getEventType()))
						{
							emailType = ClientServerCommon._MailType.GuildBossKilledWithShop;
							builder.setHasActivateGoods(true);
						}
						// 公共奖励
						Reward commonReward = new Reward();
						for (int i = 0; i < bossRewardCfg.Get_RewardsCount(); i++)
						{
							commonReward.megerReward(new Reward().fromClientServerCommon(bossRewardCfg.Get_RewardsByIndex(i)));
						}
						// 公共奖励邮件和消息
						{
							String fmt =
								cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_Guild_BossKillReward");
							fmt = String.format(fmt, eventCfg.get_Name(), commonReward.genRewardNameStr(cd));
							// 所有玩过门派关卡的玩家id
							HashSet<Integer> playerIds = new HashSet<Integer>();
							for (Entry<Integer, MapInfo> entry : guild.getGuildStageMgr().getMapInfoMaps().entrySet())
							{
								playerIds.addAll(entry.getValue().getPlayerIds());
							}
							// 给所有当前门派中,当前在门派中的人发奖
							ConcurrentHashMap<Integer, GuildMember> members =
								guild.getGuildMemberMgr().getPlayerId_members();
							for (Map.Entry<Integer, GuildMember> entry : members.entrySet())
							{
								int id = entry.getKey();
								if (playerIds.contains(id))
								{
									EmailGuildUtil.sendPlayerEmail(id, emailType, fmt, commonReward);
								}
							}
							StageMsgUtil.guildKillBossMsg(cd, guildStageMgr, commonReward, eventCfg, mapNum);
							combatResultAndReward.setDungeonReward(commonReward);
						}
						// 排行奖励邮件和消息
						for (int i = 0; i < bossRewardCfg.Get_RankRewardsCount(); i++)
						{
							GuildStageConfig.RankReward rankRewardCfg = bossRewardCfg.Get_RankRewardsByIndex(i);
							int rankPlayerId = bossHurtRank.getPlayerIdByRank(cd, rankRewardCfg.get_Rank());
							if (rankPlayerId != 0)
							{
								Reward reward = new Reward();
								reward.megerReward(new Reward().fromClientServerCommon(rankRewardCfg.get_Reward()));
								String fmt =
									cd.get_StringsConfig().GetString("UI",
										"ServerText_EmailBody_Guild_BossKillRankReward");
								fmt =
									String.format(fmt,
										eventCfg.get_Name(),
										rankRewardCfg.get_Rank(),
										reward.genRewardNameStr(cd));
								EmailGuildUtil.sendPlayerEmail(rankPlayerId, fmt, reward);
								StageMsgUtil.personKillBossRankMsg(cd,
									rankPlayerId,
									reward,
									eventCfg,
									mapNum,
									rankRewardCfg.get_Rank());
								if (playerId == rankPlayerId)
								{
									combatResultAndReward.setFirstpassReward(reward);
								}
							}
						}

						// 更新进度和竞速积分
						GuildStageConfig.MapBaseInfo mapBaseCfg =
							StageUtil.getMapBaseInfo(guildStageCfg, activityNum, mapNum);
						if (mapBaseCfg == null)
						{
							result = ClientProtocols.E_GAME_GUILD_STAGE_COMBAT_BOSS_FAILED_ERROR_MAP_NUM;
							break;
						}
						int value = 0;
						if (stage.getEventType() == GuildStageConfig._EventType.PassBoss)
						{
							value = mapBaseCfg.get_CombatValuePerPassBoss();
							// 门派进度总积分
							GuildStageConfig.ValueFix valueFixCfg =
								StageUtil.getFixValue(guildStageCfg, GuildStageConfig._RankType.Progress, activityNum);
							if (valueFixCfg == null)
							{
								result =
									ClientProtocols.E_GAME_GUILD_STAGE_COMBAT_BOSS_FAILED_PROGRESS_VALUEFIX_CONFIG_ERROR;
								break;
							}
							int progressValue = (int)Math.ceil(value * valueFixCfg.get_PassBossValue());
							guildStageMgr.addGuildFixProgressValue(progressValue);
							// 门派竞速总积分
							valueFixCfg =
								StageUtil.getFixValue(guildStageCfg, GuildStageConfig._RankType.Speed, activityNum);
							if (valueFixCfg == null)
							{
								result =
									ClientProtocols.E_GAME_GUILD_STAGE_COMBAT_BOSS_FAILED_SPEED_VALUEFIX_CONFIG_ERROR;
								break;
							}
							int speedValue = (int)Math.ceil(value * valueFixCfg.get_PassBossValue());
							guildStageMgr.addGuildFixSpeedValue(speedValue);
						}
						else if (stage.getEventType() == GuildStageConfig._EventType.ChallengeBoss)
						{
							value = mapBaseCfg.get_CombatValuePerChallengeBoss();
							// 门派进度总积分
							GuildStageConfig.ValueFix valueFixCfg =
								StageUtil.getFixValue(guildStageCfg, GuildStageConfig._RankType.Progress, activityNum);
							if (valueFixCfg == null)
							{
								result =
									ClientProtocols.E_GAME_GUILD_STAGE_COMBAT_BOSS_FAILED_PROGRESS_VALUEFIX_CONFIG_ERROR;
								break;
							}
							int progressValue = (int)Math.ceil(value * valueFixCfg.get_ChallengeBossValue());
							guildStageMgr.addGuildFixProgressValue(progressValue);
							// 门派竞速总积分
							valueFixCfg =
								StageUtil.getFixValue(guildStageCfg, GuildStageConfig._RankType.Speed, activityNum);
							if (valueFixCfg == null)
							{
								result =
									ClientProtocols.E_GAME_GUILD_STAGE_COMBAT_BOSS_FAILED_SPEED_VALUEFIX_CONFIG_ERROR;
								break;
							}
							int speedValue = (int)Math.ceil(value * valueFixCfg.get_ChallengeBossValue());
							guildStageMgr.addGuildFixSpeedValue(speedValue);
						}
						GuildMember guildMember = guild.getGuildMemberMgr().getGuildMemberById(playerId);
						if (guildMember != null)
						{
							GuildManager.genGuildNewsKillBoss(guild, guildMember, mapNum, eventCfg.get_Name());
						}
					}
					else
					{
						// 修改内存
						stage.setStatus(GuildStageConfig._StageStatus.Searching);
					}

					// 处理地图100%探索完成奖励
					guildStageMgr.isMapComplete(playerNode, cd, guild, mapNum, activityNum);

					// 更新数据库
					GuildStageMgr.updateDB(playerNode, guild.getGuildId());

					combatResultAndReward.setCombatNumMax(request.getCombatNumMax());
					combatResultAndReward.setCombatNumReal(request.getCombatNumReal());
					// 返回Stage信息
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					builder.setCombatResultAndReward(combatResultAndReward.toProtobuf());
					// 返回排行榜信息
					builder.setBossRank(bossHurtRank.genBossRank(cd, activityNum, stage.getEventType()));
					builder.setMyRank(bossHurtRank.getBossRankPlayer(cd, playerId));

					// 埋点日志
					{
						int type = 0; // 事件类型 0未知
						int isWin = isWinner ? 1 : 0; // 战斗结果 1胜利 0失败
						if (stage.getEventType() == GuildStageConfig._EventType.PassBoss)
						{
							type = 3;
						}
						else if (stage.getEventType() == GuildStageConfig._EventType.ChallengeBoss)
						{
							type = 4;
						}
						BPUtil.guildfight(playerNode, guild.getGuildId(), guild.getGuildLevel(), mapNum, type, isWin);
					}
				}
				finally
				{
					GuildMgr.unlockGuild(guild);
				}
			} while (false);
		}
		catch (Exception e)
		{
			logger.error(ExceptionUtils.getStackTrace(e));
			result = ClientProtocols.E_SERVER_PROC_ERROR;
		}
		finally
		{
			// 解锁boss(无论出现什么错误,都要解锁boss)
			stage.unCombatLock();
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
	}
}
