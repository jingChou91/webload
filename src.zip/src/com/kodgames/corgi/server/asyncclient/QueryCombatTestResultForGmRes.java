package com.kodgames.corgi.server.asyncclient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.ServerNode;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.corgi.protocol.ServersProtocolsForServer.QueryCombatResultRes;
import com.kodgames.corgi.protocol.ServersProtocolsForServer.Sync_GX_QueryCombatTestRes;
import com.kodgames.corgi.server.gameserver.ServerDataGS;

public class QueryCombatTestResultForGmRes implements AsyncMessager
{
	private int callback;
	private ServerNode serverNode;

	private static final Logger logger = LoggerFactory.getLogger(QueryCombatTestResultForGmRes.class);

	public QueryCombatTestResultForGmRes(int callback, ServerNode serverNode)
	{
		super();
		this.callback = callback;
		this.serverNode = serverNode;
	}

	@Override
	public void handlerMessage(Protocol message)
	{
		logger.info("recv QueryCombatTestResultForGmRes ");
		QueryCombatResultRes request = (QueryCombatResultRes) message.getProtoBufMessage();

		Sync_GX_QueryCombatTestRes.Builder builder = Sync_GX_QueryCombatTestRes.newBuilder();
		builder.setCallback(callback);
		if (request.getResult() == ServerProtocols.E_ALL_QUERY_COMBAT_RESULT_SUCCESS)
		{
			builder.setResult(ServerProtocols.E_SYNC_XG_QUERY_COMBAT_TEST_SUCCESS);
		}
		else
		{
			builder.setResult(ServerProtocols.E_SYNC_XG_QUERY_COMBAT_TEST_FAILED);
		}

		ServerDataGS.transmitter.sendToServer(serverNode, ServerProtocols.P_SYNC_GX_QUERY_COMBAT_TEST_RES,
				builder.build());

	}

	@Override
	public String getName()
	{
		return this.getClass().getSimpleName();
	}

}
