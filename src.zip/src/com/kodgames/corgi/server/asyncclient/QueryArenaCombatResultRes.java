package com.kodgames.corgi.server.asyncclient;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ArenaConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.combat.record.BattleRecord;
import com.kodgames.combat.record.CombatResultAndReward;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_ArenaCombatRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.corgi.protocol.ServersProtocolsForServer.QueryCombatResultRes;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.arena.data.ArenaManager;
import com.kodgames.corgi.server.gameserver.email.util.specialemail.EmailCombatUtil;
import com.kodgames.corgi.server.gameserver.marquee.data.FlowMessageBroadcaster;
import com.kodgames.corgi.server.gameserver.marquee.data.FlowMessageBroadcaster.BroadcastType;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class QueryArenaCombatResultRes implements AsyncMessager
{
	private static final Logger logger = LoggerFactory.getLogger(QueryArenaCombatResultRes.class);

	private int callback;
	private int arenaGradeId;
	private int playerIdA;
	private int wantRank; // A要抢夺的排名
	private ClientNode sender;
	private CostAndRewardAndSync crsToClient;
	private ConfigDatabase cd;

	public QueryArenaCombatResultRes(int callback, int arenaGradeId, int playerIdA, int wantRank, ClientNode sender, CostAndRewardAndSync crsToClient,ConfigDatabase cd)
	{
		this.arenaGradeId = arenaGradeId;
		this.callback = callback;
		this.playerIdA = playerIdA;
		this.wantRank = wantRank;
		this.sender = sender;
		this.crsToClient = crsToClient;
		this.cd = cd;
	}

	@Override
	public String getName()
	{
		return this.getClass().getSimpleName();
	}

	@Override
	public void handlerMessage(Protocol message)
	{
		logger.info("recv QueryArenaCombatResultRes, PlayerA is {}, wantRank is {}", playerIdA, wantRank);
		QueryCombatResultRes request = (QueryCombatResultRes)message.getProtoBufMessage();

		GC_ArenaCombatRes.Builder builder = GC_ArenaCombatRes.newBuilder();
		Protocol arenaCombatProtocol = new Protocol(ClientProtocols.P_GAME_GC_ARENA_COMBAT_RES);
		builder.setCallback(this.callback);

		if (request.getResult() == ClientProtocols.E_SERVER_PROC_ERROR)
		{
			builder.setResult(ClientProtocols.E_SERVER_PROC_ERROR);
			arenaCombatProtocol.setProtoBufMessage(builder.build());
			ServerDataGS.transmitter.sendToClient(this.sender, arenaCombatProtocol);
			return;
		}

		int result = ClientProtocols.E_GAME_ARENA_COMBAT_SUCCESS;

		// 读取配置文件
		ArenaConfig arenaConf = cd.get_ArenaConfig();
		ArenaConfig.ArenaGrade arenaGradeConfig = arenaConf.GetArenaGradeById(this.arenaGradeId);
		CostAndRewardAndSync crsHere = new CostAndRewardAndSync();
		Reward combatReward = new Reward();

		if(request.getResult() == ServerProtocols.E_ALL_QUERY_COMBAT_RESULT_SUCCESS)
		{
			int Count = request.getBatttleRecordsCount();
			if (Count >= 1)
			{
				BattleRecord battleRecord = new BattleRecord();
				battleRecord.fromProtoBufClass(request.getBatttleRecords(0));
				if (battleRecord.getTeamRecords() != null && battleRecord.getTeamRecords().size() > 0)
				{
					// 交换名次,只有一个榜,不存在取不出playerIdB的情况,A 赢了才交换名次
					int playerIdB = 0;
					boolean tempFlowMessage = false;
					
					boolean tempEmail = false;
					if(battleRecord.getTeamRecords().get(0).isWinner())
					{
						int rankOri = ArenaManager.getInstance().getPlayerRank(playerIdA, arenaGradeId);
						if(rankOri > wantRank && wantRank <=5 )
						{
							tempFlowMessage = true;
						}
						
						if(rankOri > wantRank )
						{
							tempEmail = true;
						}
						playerIdB = ArenaManager.getInstance().changeRank(this.arenaGradeId, this.playerIdA, this.wantRank);
					}
					else
					{
						playerIdB =ArenaManager.getInstance().getPlayerIdByRank(this.arenaGradeId, this.wantRank);
					}
					int rankA = ArenaManager.getInstance().getPlayerRank(this.playerIdA, this.arenaGradeId);
					int rankB = ArenaManager.getInstance().getPlayerRank(playerIdB, this.arenaGradeId);
					builder.setRank(rankA);

					ServerDataGS.playerManager.lockPlayer(this.playerIdA, playerIdB);
					try
					{
						do{
							PlayerNode playerNodeA = ServerDataGS.playerManager.getPlayerNode(playerIdA);
							//跑马灯
							if(tempFlowMessage)
							{
								FlowMessageBroadcaster.prepareBroadcastMsg(playerNodeA, 0, BroadcastType.ARENARANK, wantRank);
							}
							PlayerNode playerNodeB = null;
							if(!ArenaManager.isRobot(playerIdB))
							{
								playerNodeB = ServerDataGS.playerManager.getPlayerNode(playerIdB);
								
								if (playerNodeA == null || playerNodeA.getPlayerInfo() == null || playerNodeB == null || playerNodeB.getPlayerInfo() == null) 
								{
									result = ClientProtocols.E_GAME_ARENA_COMBAT_FAILED_PLAYERA_IS_NULL;
									break;
								}
							}
							//刷新奖励次数
							playerNodeA.getGamePlayer().getArenaPlayerData().refreshRewardRewardMax(cd);
							
							for (int i = 0; i < arenaGradeConfig.Get_challengeRewardsCount(); i++)
							{
								int rewardCount =arenaGradeConfig.Get_challengeRewardsByIndex(i).Get_rewardsCount();

								for (int j = 0; j < rewardCount; j++)
								{
									Reward rewardTemp = new Reward();
									rewardTemp = rewardTemp.fromClientServerCommon(arenaGradeConfig.Get_challengeRewardsByIndex(i).Get_rewardsByIndex(j));
									combatReward.megerReward(rewardTemp);
								}
								
								if(arenaGradeConfig.Get_challengeRewardsByIndex(i).get_maxCount() <= playerNodeA.getGamePlayer().getArenaPlayerData().getArenaRewardTimes())
								{
									combatReward.clear();
								}
								
							}
							
							//获得奖励
							CostAndRewardManager.addReward(playerNodeA, combatReward, cd,  KodLogEvent.Arena_Combat);
							crsHere.mergeReward(combatReward);
							
							ArenaManager.addArenaRewardTimes(cd, arenaGradeId, playerNodeA);
							
							//小助手
							playerNodeA.getPlayerInfo().getAssisantData().getArenaCombat().notifyObservers();

							CombatResultAndReward combatResultAndReward = new CombatResultAndReward();
							combatResultAndReward.addBattleRecords(battleRecord);
							combatResultAndReward.getRewards().add(combatReward);
							combatResultAndReward.setCombatNumMax(request.getCombatNumMax());
							combatResultAndReward.setCombatNumReal(request.getCombatNumReal());
							builder.setCombatResultAndReward(combatResultAndReward.toProtobuf());

							// 计算并保存积分 
							int interval = arenaGradeConfig.get_keepRandInterval();
							ArenaConfig.RankSetting rankSettingA = arenaConf.GetRankSettingByRankLevel(arenaGradeId, rankA);
							ArenaConfig.RankSetting rankSettingB = arenaConf.GetRankSettingByRankLevel(arenaGradeId, rankB);
							// 计算新的积分 修改内存和数据库
							ArenaManager.computeGradePoint(playerNodeA, interval, rankSettingB.get_reward().get_count());
							// 计算新的积分 修改内存和数据库
							if(!ArenaManager.isRobot(playerIdB))
							{
								ArenaManager.computeGradePoint(playerNodeB, interval, rankSettingA.get_reward().get_count());
							}
							
							if(!ArenaManager.isRobot(playerIdB))
							{
								//邮件
								EmailCombatUtil.sendPlayerEmailsForArena(playerIdB, "比武场邮件", playerIdA, playerNodeA.getGamePlayer().getFixName(), tempEmail, rankB);
							}
							if(battleRecord.getTeamRecords().get(0).isWinner())
							{
								BPUtil.bwc(playerNodeA, 1, rankA);
							}
							else
							{
								BPUtil.bwc(playerNodeA, 0, rankA);
							}
						}
						while (false);

					}
					catch (Exception e)
					{
						logger.error(ExceptionUtils.getStackTrace(e));
						result = ClientProtocols.E_SERVER_PROC_ERROR;
					}
					finally
					{
						ServerDataGS.playerManager.unlockPlayer(this.playerIdA, playerIdB);
					}
				}
				else
				{
					// A1 teamRecord
					result = ClientProtocols.E_COMBAT_BATTLE_RECORD_ERROR_BAD_TEAM_RECORD;
					logger.error("CombatFailed : E_COMBAT_BATTLE_RECORD_ERROR_BAD_TEAM_RECORD");
				}
			}
			else
			{
				// A2 battleRecord
				result = ClientProtocols.E_COMBAT_BATTLE_RECORD_ERROR_BAD_BATTLE_RECORD_COUNT;
				logger.error("CombatFailed : E_COMBAT_BATTLE_RECORD_ERROR_BAD_BATTLE_RECORD_COUNT");
			}
		}
		else
		{
			// A3 combatData
			result = request.getResult();
			logger.error("CombatFailed : result={}", result);
		}

		// 返回消耗and reward
		if (crsHere != null)
		{
			crsToClient.megerCostAndRewardAndSync(crsHere);
		}
		builder.setCostAndRewardAndSync(crsToClient.toProtobuf());

		builder.setResult(result);
		arenaCombatProtocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, arenaCombatProtocol);
	}
}
