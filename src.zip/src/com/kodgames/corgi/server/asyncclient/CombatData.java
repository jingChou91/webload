package com.kodgames.corgi.server.asyncclient;

import java.util.ArrayList;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.combat.record.CombatPlayer;

public class CombatData
{
	private int isLoseAutoSkip; // 1表示输了自动结束计算 0表示输了还要继续计算
	private ArrayList<CombatPlayer> players = new ArrayList<>(); // 对战主动方
	private ArrayList<CombatPlayer> passivePlayers = new ArrayList<>();// 对战被动方
	private ArrayList<Integer> rounds = new ArrayList<>(); // 回合数列表
	private int sceneId;
	private ConfigDatabase cd;
	private int sequenceId;
	private boolean isMaxRoundWin = false;
	private int maxRecordCount;

	public int getMaxRecordCount()
	{
		return maxRecordCount;
	}

	public void setMaxRecordCount(int maxRecordCount)
	{
		this.maxRecordCount = maxRecordCount;
	}

	public boolean isMaxRoundWin()
	{
		return isMaxRoundWin;
	}

	public void setMaxRoundWin(boolean isMaxRoundWin)
	{
		this.isMaxRoundWin = isMaxRoundWin;
	}

	public int getSequenceId()
	{
		return sequenceId;
	}

	public void setSequenceId(int sequenceId)
	{
		this.sequenceId = sequenceId;
	}

	public int getIsLoseAutoSkip()
	{
		return isLoseAutoSkip;
	}

	public void setIsLoseAutoSkip(int isLoseAutoSkip)
	{
		this.isLoseAutoSkip = isLoseAutoSkip;
	}

	public ArrayList<CombatPlayer> getPlayers()
	{
		return players;
	}

	public void setPlayers(ArrayList<CombatPlayer> players)
	{
		this.players = players;
	}

	public ArrayList<CombatPlayer> getPassivePlayers()
	{
		return passivePlayers;
	}

	public void addPlayer(CombatPlayer combatPlayer)
	{
		this.players.add(combatPlayer);
	}

	public void addPassivePlayers(CombatPlayer combatPlayer)
	{
		this.passivePlayers.add(combatPlayer);
	}

	public void setPassivePlayers(ArrayList<CombatPlayer> passivePlayers)
	{
		this.passivePlayers = passivePlayers;
	}

	public int getSceneId()
	{
		return sceneId;
	}

	public void setSceneId(int sceneId)
	{
		this.sceneId = sceneId;
	}

	public ConfigDatabase getCd()
	{
		return cd;
	}

	public void setCd(ConfigDatabase cd)
	{
		this.cd = cd;
	}

	public ArrayList<Integer> getRounds()
	{
		return rounds;
	}

	public void setRounds(ArrayList<Integer> rounds)
	{
		this.rounds = rounds;
	}
}
