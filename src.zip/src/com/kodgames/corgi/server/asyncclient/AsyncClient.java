package com.kodgames.corgi.server.asyncclient;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.server.gameserver.thread.CombatRunnable;

public class AsyncClient 
{
	private static final Logger logger = LoggerFactory.getLogger(AsyncClient.class);

	private ConcurrentHashMap<Integer, AsyncMessager> hashContext = new ConcurrentHashMap<Integer, AsyncMessager>();
	private AtomicInteger sequenceSeed = new AtomicInteger();
	private static ExecutorService threadPool = Executors.newCachedThreadPool();

	private QueryCombatResultResHandler queryCombatResultResHandler = new QueryCombatResultResHandler(this);

	public QueryCombatResultResHandler getQueryCombatResultResHandler() {
		return queryCombatResultResHandler;
	}

	public int getSequenceId() {
		return sequenceSeed.incrementAndGet();
	}

	public AsyncMessager getMessager(int seqId) {

		AsyncMessager amsg = hashContext.get(seqId);
		if (amsg == null)
		{
			logger.error("null == AsyncMessager : seqId={}\n{}", seqId, ExceptionUtils.getStackTrace(new Throwable()));
		}
		return amsg;
	}

	public void removeMessager(int sequenceId)
	{
		hashContext.remove(sequenceId);
	}

	public void send(CombatData combatData, AsyncMessager handlerMessage)
	{
		hashContext.put(combatData.getSequenceId(), handlerMessage);
		logger.info("Send to CombatRunnable, sequenceId = {}", combatData.getSequenceId());
		threadPool.execute(new CombatRunnable(combatData));
	}
}
