package com.kodgames.corgi.server.asyncclient;

import java.util.LinkedList;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.combat.record.BattleRecord;
import com.kodgames.combat.record.CombatResultAndReward;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.corgi.protocol.ServersProtocolsForServer.QueryCombatResultRes;
import com.kodgames.corgi.server.gameserver.ServerDataGS;

public class QueryNoviceCombatResultRes implements AsyncMessager
{
	private int callback;
	ClientNode sender;
	private int playerId;
	private ConfigDatabase cd;
	private static final Logger logger = LoggerFactory.getLogger(QueryNoviceCombatResultRes.class);

	public QueryNoviceCombatResultRes(int callback, int playerId, ClientNode sender,ConfigDatabase cd)
	{
		this.callback = callback;
		this.sender = sender;
		this.playerId = playerId;
		this.cd = cd;
	}

	@Override
	public String getName()
	{
		return this.getClass().getSimpleName();
	}

	@Override
	public void handlerMessage(Protocol message)
	{
		logger.info("recv QueryNoviceCombatResultRes, playerId = {}", playerId);
		QueryCombatResultRes request = (QueryCombatResultRes)message.getProtoBufMessage();

		GameProtocolsForClient.GC_NoviceCombatRes.Builder gc_NoviceCombatBuilder =
			GameProtocolsForClient.GC_NoviceCombatRes.newBuilder();
		Protocol combatProtocol = new Protocol(ClientProtocols.P_GAME_GC_NOVICECOMBAT_RES);
		gc_NoviceCombatBuilder.setCallback(callback);

		if (request.getResult() == ClientProtocols.E_SERVER_PROC_ERROR)
		{
			gc_NoviceCombatBuilder.setResult(ClientProtocols.E_SERVER_PROC_ERROR);
			combatProtocol.setProtoBufMessage(gc_NoviceCombatBuilder.build());
			ServerDataGS.transmitter.sendToClient(sender, combatProtocol);
			return;
		}
		int result = ClientProtocols.E_GAME_NOVICECOMBAT_SUCCESS;

		// Add lock
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{

			do
			{

				if (request.getResult() != ServerProtocols.E_ALL_QUERY_COMBAT_RESULT_SUCCESS)
				{
					result = request.getResult();
					logger.error("CombatFailed : result={}", result);
					break;
				}
				int Count = request.getBatttleRecordsCount();
				if (Count < 1)
				{
					result = ClientProtocols.E_COMBAT_BATTLE_RECORD_ERROR_BAD_BATTLE_RECORD_COUNT;
					logger.error("CombatFailed : E_COMBAT_BATTLE_RECORD_ERROR_BAD_BATTLE_RECORD_COUNT");
					break;
				}
				// 计算星级
				BattleRecord battleRecordTemp = new BattleRecord();
				battleRecordTemp.fromProtoBufClass(request.getBatttleRecords(0));

				if (battleRecordTemp.getTeamRecords() == null || battleRecordTemp.getTeamRecords().size() <= 0)
				{
					result = ClientProtocols.E_COMBAT_BATTLE_RECORD_ERROR_BAD_TEAM_RECORD;
					logger.error("CombatFailed : E_COMBAT_BATTLE_RECORD_ERROR_BAD_TEAM_RECORD");
					break;
				}

				CombatResultAndReward combatResultAndReward = new CombatResultAndReward();
				LinkedList<BattleRecord> battleRecords = new LinkedList<>();
				BattleRecord battleRecord = new BattleRecord();
				battleRecord.fromProtoBufClass(request.getBatttleRecords(0));
				battleRecords.add(battleRecord);
				combatResultAndReward.setBattleRecords(battleRecords);
				combatResultAndReward.setCombatNumMax(request.getCombatNumMax());
				combatResultAndReward.setCombatNumReal(request.getCombatNumReal());
				gc_NoviceCombatBuilder.setCombatResultAndReward(combatResultAndReward.toProtobuf());

			} while (false);
		}
		catch (Exception e)
		{
			logger.error(ExceptionUtils.getStackTrace(e));
			result = ClientProtocols.E_SERVER_PROC_ERROR;
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		gc_NoviceCombatBuilder.setResult(result);
		combatProtocol.setProtoBufMessage(gc_NoviceCombatBuilder.build());
		ServerDataGS.transmitter.sendToClient(sender, combatProtocol);
	}

}
