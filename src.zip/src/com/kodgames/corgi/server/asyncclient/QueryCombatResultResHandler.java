package com.kodgames.corgi.server.asyncclient;

import java.util.ArrayList;
import java.util.List;

import org.perf4j.StopWatch;
import org.perf4j.slf4j.Slf4JStopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon._ConditionValueCompareType;

import com.kodgames.combat.record.AvatarResult;
import com.kodgames.combat.record.BattleRecord;
import com.kodgames.combat.record.TeamRecord;
import com.kodgames.corgi.protocol.CombatData;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.ServersProtocolsForServer.QueryCombatResultRes;

public class QueryCombatResultResHandler
{

	private static final Logger logger = LoggerFactory.getLogger(QueryCombatResultResHandler.class);

	private AsyncClient asyncClient;

	public QueryCombatResultResHandler(AsyncClient asyncClient)
	{
		this.asyncClient = asyncClient;
	}

	public void handleServerMessage(Protocol message)
	{
		QueryCombatResultRes request = (QueryCombatResultRes)message.getProtoBufMessage();

		int sequenceId = request.getCallback();
		
		logger.info("recv QueryCombatResultRes, sequenceId = {}", sequenceId);
		AsyncMessager messager = asyncClient.getMessager(sequenceId);
		if (messager != null)
		{
			StopWatch watch_combat = new Slf4JStopWatch(messager.getName());
			messager.handlerMessage(message);
			watch_combat.stop();
		}
		asyncClient.removeMessager(sequenceId);
	}

	public static List<Integer> getStarCompleteIndexs(List<CombatData.BattleRecord> combatbattleRecords,
		CampaignConfig.Dungeon dungeonCfg, int npcResourceId)
	{
		List<Integer> completeIndexs = new ArrayList<Integer>();

		List<BattleRecord> battleRecords = new ArrayList<BattleRecord>();
		for (CombatData.BattleRecord combatbattleRecord : combatbattleRecords)
		{
			BattleRecord battleRecord = new BattleRecord();
			battleRecord.fromProtoBufClass(combatbattleRecord);
			battleRecords.add(battleRecord);
		}

		int battleRecordsCount = battleRecords.size();
		// 计算星级,如果没有通关,直接返回空的completeIndexs
		if (battleRecordsCount >= 1 && battleRecords.get(battleRecordsCount - 1).getTeamRecords().get(0).isWinner())
		{

			// 获取最后一节战斗的信息
			BattleRecord battleRecord = battleRecords.get(battleRecordsCount - 1);
			TeamRecord teamRecord = battleRecord.getTeamRecords().get(0);

			// 每个评价条件
			for (int i = 0; i < dungeonCfg.Get_startConditionCount(); i++)
			{
				CampaignConfig.StarCondition starConditonCfg = dungeonCfg.Get_startConditionByIndex(i);
				switch (starConditonCfg.get_type())
				{
				// 是否通关
					case ClientServerCommon._StarRewardEvaType.Pass:
						completeIndexs.add(i);
						break;
					// npc是否存活
					case ClientServerCommon._StarRewardEvaType.NpcCountLeft:
						for (AvatarResult avatarResult : teamRecord.getAvatarResults())
						{
							if (avatarResult.getCombatAvatarData().getResourceId() == npcResourceId)
							{
								if (avatarResult.getLeftHP() > 0)
								{
									completeIndexs.add(i);
									break;
								}
							}
						}
						break;
					// 使用回合数
					case ClientServerCommon._StarRewardEvaType.RoundCount:
						if (getCompareResult(battleRecord.getCombatRecord().getMaxRoundIndex(),
							starConditonCfg.get_compareType(),
							starConditonCfg.get_compareIntValue()))

						{
							completeIndexs.add(i);
						}
						break;
					// 角色存活数
					case ClientServerCommon._StarRewardEvaType.AvatarCountLeft:
						// 计算角色存活数
						int leftCount = 0;
						for (AvatarResult avatarResult : teamRecord.getAvatarResults())
						{
							if (avatarResult.getLeftHP() > 0)
							{
								leftCount++;
							}
						}
						// 判断角色存活数是否满足条件
						if (getCompareResult(leftCount,
							starConditonCfg.get_compareType(),
							starConditonCfg.get_compareIntValue()))
						{
							completeIndexs.add(i);
						}
						break;
					// 角色剩余血量
					case ClientServerCommon._StarRewardEvaType.AvatarHpLeft:
						boolean complete = true;
						int leftHp = 0;
						double totalHp = 0;
						for (AvatarResult avatarResult : teamRecord.getAvatarResults())
						{
							leftHp += avatarResult.getLeftHP();
							totalHp += avatarResult.getCombatAvatarData().getAttributeValue(1);
						}
						if (!getCompareResult(leftHp,
							starConditonCfg.get_compareType(),
							(int)(starConditonCfg.get_compareFloatValue() * totalHp)))
						{
							complete = false;
						}
						if (complete)
						{
							completeIndexs.add(i);
						}
						break;

				}
			}

		}
		return completeIndexs;
	}

	public static boolean getCompareResult(int leftValue, int compareType, int rightValue)
	{
		switch (compareType)
		{
			case _ConditionValueCompareType.Less:
				return leftValue < rightValue;
			case _ConditionValueCompareType.LessEqual:
				return leftValue <= rightValue;
			case _ConditionValueCompareType.Equal:
				return leftValue == rightValue;
			case _ConditionValueCompareType.GreaterEqual:
				return leftValue >= rightValue;
			case _ConditionValueCompareType.Greater:
				return leftValue > rightValue;
			case _ConditionValueCompareType.NotEqual:
				return leftValue != rightValue;
		}
		return false;
	}

}
