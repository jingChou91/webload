package com.kodgames.corgi.server.asyncclient;

import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.WolfSmokeConfig;
import ClientServerCommon.WolfSmokeConfig.WolfStage;

import com.kodgames.combat.record.BattleRecord;
import com.kodgames.combat.record.CombatResultAndReward;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CombatData;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.DBProtocolsForServer.IllusionDB;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.corgi.protocol.ServersProtocolsForServer.QueryCombatResultRes;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.illusion.util.IllusionUtil;
import com.kodgames.corgi.server.gameserver.wolfsmoke.data.WolfSmokeData;
import com.kodgames.corgi.server.gameserver.wolfsmoke.data.WolfSmokeMgr;
import com.kodgames.corgi.server.gameserver.wolfsmoke.util.WolfCoreUtil;
import com.kodgames.corgi.server.gameserver.wolfsmoke.util.WolfSmokeUtil;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Consume;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class QueryWolfSmokeCombatResultRes implements AsyncMessager
{

	private int callback;
	private int playerId;
	ClientNode sender;
	CostAndRewardAndSync crsForClient;
	CommonProtocols.Position battlePosition;
	int additionId;
	CombatResultAndReward combatResultAndReward = new CombatResultAndReward();
	ConfigDatabase cd;
	private static final Logger logger = LoggerFactory.getLogger(QueryWolfSmokeCombatResultRes.class);

	public QueryWolfSmokeCombatResultRes(int callback, int playerId, ClientNode sender,
		CostAndRewardAndSync crsToclient, CommonProtocols.Position battlePosition, int additionId, ConfigDatabase cd)
	{
		this.callback = callback;
		this.playerId = playerId;
		this.sender = sender;
		this.crsForClient = crsToclient;
		this.battlePosition = battlePosition;
		this.additionId = additionId;
		this.cd = cd;
	}

	@Override
	public String getName()
	{
		return this.getClass().getSimpleName();
	}

	@Override
	public void handlerMessage(Protocol message)
	{
		logger.info("recv QueryWolfSmokeCombatResultRes, playerId = {}", playerId);
		QueryCombatResultRes request = (QueryCombatResultRes)message.getProtoBufMessage();

		GameProtocolsForClient.GC_CombatWolfSmokeRes.Builder builder =
			GameProtocolsForClient.GC_CombatWolfSmokeRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_COMBAT_WOLF_SMOKE_RES);
		builder.setCallback(callback);

		int result = ClientProtocols.E_GAME_COMBAT_WOLF_SMOKE_SUCCESS;

		boolean isWin = true;
		int enemyPlayerId = 0;
		PlayerNode enemyPlayerNode = null;

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_WOLF_SMOKE_FAILED_LOAD_PLAYER;
					break;
				}
				WolfSmokeConfig wolfSmokeCfg = cd.get_WolfSmokeConfig();
				if (wolfSmokeCfg == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_WOLF_SMOKE_FAILED_CONFIG_ERROR;
					break;
				}
				if (request.getResult() != ServerProtocols.E_ALL_QUERY_COMBAT_RESULT_SUCCESS)
				{
					result = request.getResult();
					break;
				}
				if (request.getBatttleRecordsCount() <= 0)
				{
					result = ClientProtocols.E_GAME_COMBAT_WOLF_SMOKE_ERROR_BAD_BATTLE_RECORD_COUNT;
					break;
				}
				WolfSmokeData wolfSmokeData = playerNode.getPlayerInfo().getWolfSmokeData();
				int stageId = wolfSmokeData.getStageId();
				WolfStage stageCfg = wolfSmokeCfg.GetStageById(stageId);
				if (stageCfg == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_WOLF_SMOKE_FAILED_CONFIG_ERROR;
					break;
				}

				// 判断战斗结果数据是否有问题.
				BattleRecord battleRecordtemp = new BattleRecord();
				battleRecordtemp.fromProtoBufClass(request.getBatttleRecords(0));
				if (battleRecordtemp.getTeamRecords() == null && battleRecordtemp.getTeamRecords().size() <= 0)
				{
					result = ClientProtocols.E_GAME_COMBAT_WOLF_SMOKE_ERROR_BAD_TEAM_RECORD;
					break;
				}
				// 转换战斗结果
				LinkedList<BattleRecord> battleRecords = new LinkedList<BattleRecord>();
				for (CombatData.BattleRecord combatbattleRecord : request.getBatttleRecordsList())
				{
					BattleRecord battleRecord = new BattleRecord();
					battleRecord.fromProtoBufClass(combatbattleRecord);
					battleRecords.add(battleRecord);
				}
				// 保存战斗结果
				combatResultAndReward.setBattleRecords(battleRecords);
				combatResultAndReward.setCombatNumMax(1);

				// 如果战败,增加失败次数
				int battleRecordsCount = battleRecords.size();
				boolean isWinner = battleRecords.get(battleRecordsCount - 1).getTeamRecords().get(0).isWinner();
				if (battleRecordsCount < 1 || !isWinner)
				{
					isWin = false;
					// 增加失败次数
					wolfSmokeData.addFailedTimes();
					// 更新数据库
					WolfSmokeMgr.updateWolfSmoke(playerNode);
					// 返回战斗结果

					builder.setAlreadyFailedTimes(wolfSmokeData.getFailedTimes());
					builder.setAlreadyResetTimes(wolfSmokeData.getResetTimes());
					builder.setCombatResultAndReward(combatResultAndReward.toProtobuf());

					// 埋点日志
					BPUtil.fhly(playerNode, stageId, 0, wolfSmokeData.getResetTimes());
					break;
				}
				// 保存剩余血量
				WolfCoreUtil.saveAvatarLeftHP(wolfSmokeData, battleRecords);
				// 返回上一关显示的地方角色卡id
				builder.setShowAvatar(WolfSmokeUtil.getShowAvatar(cd, wolfSmokeData));
			} while (false);
		}
		catch (Exception e)
		{
			logger.error(ExceptionUtils.getStackTrace(e));
			result = ClientProtocols.E_SERVER_PROC_ERROR;
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		do
		{
			if (result != ClientProtocols.E_GAME_COMBAT_WOLF_SMOKE_SUCCESS)
			{
				break;
			}
			if (!isWin)
			{
				break;
			}
			WolfSmokeConfig wolfSmokeCfg = cd.get_WolfSmokeConfig();
			WolfSmokeData wolfSmokeData = playerNode.getPlayerInfo().getWolfSmokeData();

			// 获取下一关关卡Id
			int nextSatgeId = WolfSmokeUtil.getNextStageId(wolfSmokeCfg, wolfSmokeData.getStageId());
			// 如果还有下一关,生成下一关敌人阵容镜像
			if (nextSatgeId != -1)
			{
				enemyPlayerId = WolfCoreUtil.randomEnemyPlayerId(playerNode, cd, nextSatgeId);
				if (enemyPlayerId == 0)
				{
					logger.debug("gen wolf smoke enemyPlayer faild, playerId = " + playerId + "enemyPlsyerId = "
						+ enemyPlayerId);
					result = ClientProtocols.E_GAME_COMBAT_WOLF_SMOKE_FAILD_LOAD_ENEMYCOMBAT1;
					break;
				}
				if (!WolfSmokeUtil.isRobot(enemyPlayerId))
				{
					enemyPlayerNode = ServerDataGS.playerManager.getPlayerNode(enemyPlayerId);
					if (enemyPlayerNode == null || enemyPlayerNode.getPlayerInfo() == null)
					{
						logger.debug("gen wolf smoke enemyPlayer faild, playerId = " + playerId + "enemyPlsyerId = "
							+ enemyPlayerId);
						result = ClientProtocols.E_GAME_COMBAT_WOLF_SMOKE_FAILD_LOAD_ENEMYCOMBAT2;
						break;
					}
				}

			}
		} while (false);

		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				if (result != ClientProtocols.E_GAME_COMBAT_WOLF_SMOKE_SUCCESS)
				{
					break;
				}
				if (!isWin)
				{
					break;
				}
				WolfSmokeConfig wolfSmokeCfg = cd.get_WolfSmokeConfig();
				WolfSmokeData wolfSmokeData = playerNode.getPlayerInfo().getWolfSmokeData();
				int stageId = wolfSmokeData.getStageId();
				WolfStage stageCfg = wolfSmokeCfg.GetStageById(stageId);

				// 获取下一关关卡Id
				int nextSatgeId = WolfSmokeUtil.getNextStageId(wolfSmokeCfg, wolfSmokeData.getStageId());

				if (nextSatgeId != -1)
				{
					// 更新敌方阵容镜像
					wolfSmokeData.genEnemyPlayer(playerNode, enemyPlayerNode, enemyPlayerId, cd);
					if (!WolfSmokeUtil.isRobot(enemyPlayerId))
					{
						// 保存敌方幻化信息
						IllusionUtil.autoUpdateStatus(enemyPlayerNode);
						wolfSmokeData.setEnemyIllusionDB(IllusionUtil.genIllusionDB(enemyPlayerNode, cd));
					}
					else
					{
						wolfSmokeData.setEnemyIllusionDB(IllusionDB.newBuilder().build());
					}
				}

				// 保存所选增益
				wolfSmokeData.getAdditions().put(stageId, additionId);
				// 保存新的关卡id
				wolfSmokeData.setStageId(nextSatgeId);
				// 更新今日已通关关卡
				wolfSmokeData.addThisTimePassStageId(stageId);

				// 计算通关奖励
				Reward rewardAll = new Reward();// -------------------------------------------
				// 普通通关奖励
				Reward passReward = new Reward();
				// 首次通关奖励
				Reward firstPassReward = new Reward();
				{
					// 通关奖励
					for (int i = 0; i < stageCfg.Get_PassRewardsCount(); i++)
					{
						passReward.megerReward(new Reward().fromClientServerCommon(stageCfg.Get_PassRewardsByIndex(i)));
					}
					// 首次通关奖励
					if (!wolfSmokeData.getPassStageIds().contains(stageId))
					{
						for (int i = 0; i < stageCfg.Get_FirstPassRewardsCount(); i++)
						{
							firstPassReward.megerReward(new Reward().fromClientServerCommon(stageCfg.Get_FirstPassRewardsByIndex(i)));
						}
						// 保存新的已通关关卡id
						wolfSmokeData.getPassStageIds().add(stageId);
					}
				}
				combatResultAndReward.setDungeonReward(passReward);
				combatResultAndReward.setFirstpassReward(firstPassReward);
				combatResultAndReward.setCombatNumMax(request.getCombatNumMax());
				combatResultAndReward.setCombatNumReal(request.getCombatNumReal());

				// 合并各项通过奖励
				rewardAll.megerReward(passReward).megerReward(firstPassReward);
				// 把奖励存入内存
				CostAndRewardAndSync crsForReward = new CostAndRewardAndSync();
				crsForReward.mergeReward(rewardAll);
				CostAndRewardManager.addReward(playerNode,
					rewardAll,
					cd,
					KodLogEvent.WolfSmokeLogic_QueryWolfSmokeCombatResult);
				crsForClient.megerCostAndRewardAndSync(crsForReward);

				// 随机生成各位置彩蛋奖励ID和数量
				Map<Integer, Consume> placeIndex_Reward = WolfSmokeUtil.randomEggsPlaceIndexAndReward(stageCfg);
				// 生成彩蛋奖励reward
				Reward eggsReward = new Reward();
				for (Entry<Integer, Consume> entry : placeIndex_Reward.entrySet())
				{
					Consume consume = entry.getValue();
					eggsReward.megerReward(new Reward().fromIdAndCount(consume.getId(), consume.getAmount(), 1, 1,0));
				}

				// 把彩蛋奖励存入内存
				CostAndRewardAndSync crsForEggsReward = new CostAndRewardAndSync();
				crsForEggsReward.mergeReward(eggsReward);
				CostAndRewardManager.addReward(playerNode,
					eggsReward,
					cd,
					KodLogEvent.WolfSmokeLogic_QueryWolfSmokeCombatResult);

				// 更新数据库
				WolfSmokeMgr.updateWolfSmoke(playerNode);
				// 返回客户端
				for (Entry<Integer, Consume> entry : placeIndex_Reward.entrySet())
				{
					Consume consume = entry.getValue();
					CommonProtocols.WolfEggs.Builder eggsBuilder = CommonProtocols.WolfEggs.newBuilder();
					eggsBuilder.setRewardId(consume.getId());
					eggsBuilder.setRewardCount(consume.getAmount());
					builder.addWolfEggs(eggsBuilder.build());
				}

				builder.setIsJoin(wolfSmokeData.isJoin());
				builder.setAlreadyFailedTimes(wolfSmokeData.getFailedTimes());
				builder.setAlreadyResetTimes(wolfSmokeData.getResetTimes());
				builder.setStageId(nextSatgeId);
				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
				builder.setEggsCostAndRewardAndSync(crsForEggsReward.toProtobuf());
				builder.setCombatResultAndReward(combatResultAndReward.toProtobuf());

				// 埋点日志
				BPUtil.fhly(playerNode, stageId, 1, wolfSmokeData.getResetTimes());

			} while (false);
		}
		catch (Exception e)
		{
			logger.error(ExceptionUtils.getStackTrace(e));
			result = ClientProtocols.E_SERVER_PROC_ERROR;
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
	}
}
