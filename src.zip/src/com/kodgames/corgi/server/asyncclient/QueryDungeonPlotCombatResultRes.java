package com.kodgames.corgi.server.asyncclient;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._DungeonDifficulity;
import ClientServerCommon._DungeonType;
import ClientServerCommon._ZoneStatus;

import com.kodgames.combat.record.BattleRecord;
import com.kodgames.combat.record.CombatResultAndReward;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.KodLogUtil;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dungeon.data.Dungeon;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonData;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonMgr;
import com.kodgames.corgi.server.gameserver.dungeon.util.DungeonUtil;
import com.kodgames.corgi.server.gameserver.marquee.data.FlowMessageBroadcaster;
import com.kodgames.corgi.server.gameserver.marquee.data.FlowMessageBroadcaster.Position;
import com.kodgames.corgi.server.gameserver.tutorial.data.TutorialManager;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;
import com.kodgames.gamedata.player.costandreward.RewardGen;

public class QueryDungeonPlotCombatResultRes
{

	private int callback;
	private int playerId;
	private int zoneId;
	private int dungeonId;
	private int dungeonType;
	ClientNode sender;
	CostAndRewardAndSync crsForClient;
	CampaignConfig.Dungeon dungeonCfg;
	CombatResultAndReward combatResultAndReward = null;
	ConfigDatabase cd;
	private static final Logger logger = LoggerFactory.getLogger(QueryDungeonPlotCombatResultRes.class);

	public QueryDungeonPlotCombatResultRes(int callback, int playerId, int zoneId, int dungeonId, int dungeonType,
		ClientNode sender, CostAndRewardAndSync crsToclient, CampaignConfig.Dungeon dungeon,
		CombatResultAndReward combatResultAndReward,ConfigDatabase cd)
	{
		this.callback = callback;
		this.playerId = playerId;
		this.dungeonId = dungeonId;
		this.zoneId = zoneId;
		this.sender = sender;
		this.dungeonType = dungeonType;
		this.crsForClient = crsToclient;
		this.dungeonCfg = dungeon;
		this.combatResultAndReward = combatResultAndReward;
		this.cd = cd;
	}

	public void handlerMessage()
	{
		logger.info("recv QueryDungeonPlotCombatResultRes, playerId = {}", playerId);
		GameProtocolsForClient.GC_CombatRes.Builder builder = GameProtocolsForClient.GC_CombatRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_COMBAT_RES);
		builder.setCallback(callback);

		int result = ClientProtocols.E_GAME_COMBAT_SUCCESS;

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FAILED_GET_PLAYER_FAILED;
					break;
				}
				CampaignConfig campaignCfg = cd.get_CampaignConfig();
				if (campaignCfg == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FAILED_LOAD_CAMPAIGN_CONFIG_FAILED;
					break;
				}
				DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
				Dungeon dungeon = dungeonData.getDungeonById(dungeonId);
				int logEventId = this.getLogEventId(campaignCfg, zoneId);

				// 读取战斗结果
				LinkedList<BattleRecord> battleRecords = combatResultAndReward.getBattleRecords();
				boolean isWinner = battleRecords.get(battleRecords.size() - 1).getTeamRecords().get(0).isWinner();
				int starNum = 0;
				List<Integer> starCompleteIndexs = new ArrayList<Integer>();
				if (isWinner)
				{
					starCompleteIndexs.add(0);
					starCompleteIndexs.add(1);
					starCompleteIndexs.add(2);
					starNum = 3;
				}

				// 表示有为观看完成的战斗记录
				dungeonData.getDungeonById(dungeonId).setStatus(1);

				// 如果输了的话，进入条件扣的物品，还给玩家
				Reward rewardAll = new Reward();
				if (starNum <= 0)
				{
					// 消耗信息
					ArrayList<Cost> costs = new ArrayList<Cost>();
					for (int i = 0; i < dungeonCfg.Get_enterCostsCount(); i++)// GetEnterCostCount()
					{
						int costItemId = dungeonCfg.Get_enterCostsByIndex(i).get_id();// GetEnterCost(i)
						int costItemCount = dungeonCfg.Get_enterCostsByIndex(i).get_count();
						Cost cost = new Cost(costItemId, costItemCount);
						costs.add(cost);
					}
					Reward reward = Reward.getRewardFromCosts(costs);
					rewardAll.megerReward(reward);
				}

				// 计算副本通关奖励
				Reward rewardFix = new Reward();
				Reward reward = new Reward();
				if (starNum > 0)
				{
					// 固定奖励:经验和银币
					for (int i = 0; i < dungeonCfg.Get_fixedRewardsCount(); i++)// getFixRewardCount()
					{
						Reward temp = new Reward();
						temp.fromClientServerCommon(dungeonCfg.Get_fixedRewardsByIndex(i));// getFixReward(i)
						rewardFix.megerReward(temp);
					}
					// 通关奖励
					reward.megerReward(RewardGen.getRewardFromRewardSetId(dungeonCfg.get_passRewardSetId(), cd));
					// 首次通关奖励
					if (starNum > 0 && dungeonData.getDungeonById(dungeonId).getBestRecord() == 0)
					{
						if (dungeonCfg.get_firstPassRewardSetId() != 0)
						{
							reward.megerReward(RewardGen.getRewardFromRewardSetId(dungeonCfg.get_firstPassRewardSetId(),
								cd));
						}

					}
					// 首次三星通关奖励
					if (starNum == 3 && dungeonData.getDungeonById(dungeonId).getBestRecord() != 3)
					{
						if (dungeonCfg.get_firstThreeStarRewardSetId() != 0)
						{
							reward.megerReward(RewardGen.getRewardFromRewardSetId(dungeonCfg.get_firstThreeStarRewardSetId(),
								cd));
						}

					}
				}
				combatResultAndReward.setDungeonReward_ExpSilver(rewardFix);
				combatResultAndReward.setDungeonReward(reward);
				combatResultAndReward.setStarCompleteIndexs(starCompleteIndexs);
				combatResultAndReward.setStarNum(starNum);
				rewardAll.megerReward(reward);
				rewardAll.megerReward(rewardFix);

				// 把奖励存入内存
				CostAndRewardAndSync crsForReward = new CostAndRewardAndSync();
				crsForReward.mergeReward(rewardAll);
				CostAndRewardManager.addReward(playerNode, rewardAll, cd, logEventId);
				crsForClient.megerCostAndRewardAndSync(crsForReward);

				// 当天副本进入次数加1
				if (starNum > 0)
				{
					dungeon.addTodayCompleteTimes();
					{
						KodLogUtil.campaign_record(playerNode, dungeon);
					}
				}

				// 如果比历史成绩好，保存
				if (starNum > dungeonData.getDungeonById(dungeonId).getBestRecord())
				{
					dungeon.setBestRecord(starNum);
				}

				// 判断是否需要更新zone状态
				if (dungeonType == _DungeonType.Common
					&& dungeonCfg.get_DungeonDifficulty() == _DungeonDifficulity.Common
					&& (dungeonData.getZones().get(zoneId) == null || dungeonData.getZones().get(zoneId) != _ZoneStatus.ZoneComplete))
				{
					if (starNum > 0)
					{

						CampaignConfig.Zone zone = cd.get_CampaignConfig().GetZoneById(zoneId);

						// 判断该关卡是否是普通关卡中的最后一个关卡
						boolean testResult = true;
						for (int i = 0; i < zone.GetDungeonDifficultyByDifficulty(_DungeonDifficulity.Common)
							.Get_dungeonsCount(); i++)// GetDungeonCount()
						{
							if (dungeonId < zone.GetDungeonDifficultyByDifficulty(_DungeonDifficulity.Common)
								.Get_dungeonsByIndex(i)
								.get_dungeonId())// GetDungeon(i)
							{
								testResult = false;
							}
						}
						// 如果是,那么章节状态修改为 已完成,否则改为进行中.
						if (testResult)
						{
							DungeonMgr.updateZoneStatus(playerNode, zoneId, _ZoneStatus.ZoneComplete);
						}
						else
						{
							DungeonMgr.updateZoneStatus(playerNode, zoneId, _ZoneStatus.ZoneProceed);
						}
					}
				}

				// 激活对应的云游商人
				if (starNum > 0)
				{
					CampaignConfig.TravelTrader travelTraderCfg = campaignCfg.GetTravelTradeByDungeonId(dungeonId);
					if (travelTraderCfg != null)
					{
						if (starNum >= travelTraderCfg.get_openNeedStars())
						{
							// 激活云游商人
							DungeonMgr.openTravel(playerNode, dungeonId);
							// 返回云游商人信息
							builder.setTravelData(dungeonData.getTravels()
								.get(dungeonId)
								.toProtoBuffer(campaignCfg, dungeonId));
						}
					}
				}
				// 修改数据库中副本和玩家信息
				DungeonMgr.updateDungeon(playerNode, zoneId);
				DungeonMgr.updatePlayerDungeonData(playerNode);

				playerNode.getPlayerInfo().getAssisantData().getDungeonCombat().notifyObservers();

				builder.setZoneStatus(dungeonData.getZones().get(zoneId));
				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
				builder.setCombatResultAndReward(combatResultAndReward.toProtobuf());
				builder.setDungeon(dungeon.toProtoBuffer());

				if (starNum > 0)
				{
					BPUtil.pveFight(playerNode,
						dungeonId,
						"1",
						DungeonUtil.getDungeonType(campaignCfg, zoneId),
						"1",
						zoneId,
						starNum);
				}
				else
				{
					BPUtil.pveFight(playerNode,
						dungeonId,
						"1",
						DungeonUtil.getDungeonType(campaignCfg, zoneId),
						"0",
						zoneId,
						starNum);
				}
				//为新手引导bug临时写的代码.版本更新后删除@路遥
				{
					if (dungeonId == campaignCfg.Get_zonesByIndex(0)
						.GetDungeonDifficultyByDifficulty(ClientServerCommon._DungeonDifficulity.Common)
						.Get_dungeonsByIndex(0)
						.get_dungeonId())
					{
						TutorialManager.addTutorialId(playerNode, 335548417);
					}
					else if (dungeonId == campaignCfg.Get_zonesByIndex(0)
						.GetDungeonDifficultyByDifficulty(ClientServerCommon._DungeonDifficulity.Common)
						.Get_dungeonsByIndex(1)
						.get_dungeonId())
					{
						TutorialManager.addTutorialId(playerNode, 335548418);
					}
				}

				// 跑马灯
				FlowMessageBroadcaster.prepareBroadcastRewardMsg(playerNode, reward, Position.DUNGEON);
				
				logger.info("dungeon combat do  success ! dungeonId ="+dungeonId+" starNum ="+starNum);
			} while (false);
		}
		catch (Exception e)
		{
			logger.error(ExceptionUtils.getStackTrace(e));
			result = ClientProtocols.E_SERVER_PROC_ERROR;
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
	}

	private int getLogEventId(CampaignConfig campaignCfg, int zoneId)
	{
		if (campaignCfg.IsActivityZoneId(zoneId))
		{
			return KodLogEvent.DungeonLogic_QueryDungeonCombatResult_Secret;
		}
		else
		{
			return KodLogEvent.DungeonLogic_QueryDungeonCombatResult;
		}
	}

}
