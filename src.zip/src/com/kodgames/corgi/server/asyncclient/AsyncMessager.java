package com.kodgames.corgi.server.asyncclient;

import com.kodgames.corgi.protocol.Protocol;

public interface AsyncMessager {
	void handlerMessage(Protocol message);
	String getName();
}
