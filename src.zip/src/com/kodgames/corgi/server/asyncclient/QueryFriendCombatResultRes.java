package com.kodgames.corgi.server.asyncclient;

import java.util.LinkedList;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.FriendConfig;
import ClientServerCommon.FriendConfig.FriendCombatInfo;
import ClientServerCommon.FriendConfig.FriendCombatReward;

import com.kodgames.combat.record.BattleRecord;
import com.kodgames.combat.record.CombatResultAndReward;
import com.kodgames.common.ValueRandomer;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CombatData;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.corgi.protocol.ServersProtocolsForServer.QueryCombatResultRes;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.friend.data.FriendData;
import com.kodgames.corgi.server.gameserver.friend.data.FriendMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class QueryFriendCombatResultRes implements AsyncMessager
{

	private int callback;
	private int playerId;
	ClientNode sender;
	CostAndRewardAndSync crsForClient;
	private ConfigDatabase cd;
	private static final Logger logger = LoggerFactory.getLogger(QueryFriendCombatResultRes.class);

	public QueryFriendCombatResultRes(int callback, int playerId, ClientNode sender, CostAndRewardAndSync crsToclient,
		ConfigDatabase cd)
	{
		this.callback = callback;
		this.playerId = playerId;
		this.sender = sender;
		this.crsForClient = crsToclient;
		this.cd = cd;
	}

	@Override
	public String getName()
	{
		return this.getClass().getSimpleName();
	}

	@Override
	public void handlerMessage(Protocol message)
	{
		logger.info("recv QueryFriendCombatResultRes, playerId = {}", playerId);
		QueryCombatResultRes request = (QueryCombatResultRes)message.getProtoBufMessage();

		GameProtocolsForClient.GC_CombatFriendRes.Builder builder =
			GameProtocolsForClient.GC_CombatFriendRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_COMBAT_FRIEND_RES);
		builder.setCallback(callback);

		int result = ClientProtocols.E_GAME_COMBAT_FRIEND_SUCCESS;

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FRIEND_FAILED_LOAD_PLAYER;
					break;
				}
				FriendConfig friendCfg = cd.get_FriendConfig();
				if (friendCfg == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FRIEND_FAILED_LOAD_CONFIG;
					break;
				}
				FriendCombatInfo friendCombatCfg = friendCfg.get_FriendCombat();
				if (friendCombatCfg == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FRIEND_FAILED_LOAD_CONFIG;
					break;
				}
				if (request.getResult() != ServerProtocols.E_ALL_QUERY_COMBAT_RESULT_SUCCESS)
				{
					result = request.getResult();
					break;
				}
				if (request.getBatttleRecordsCount() <= 0)
				{
					result = ClientProtocols.E_GAME_COMBAT_FRIEND_FAILED_ERROR_BAD_BATTLE_RECORD_COUNT;
					break;
				}
				FriendData friendData = playerNode.getPlayerInfo().getFriendData();

				// 判断战斗结果数据是否有问题.
				BattleRecord battleRecordtemp = new BattleRecord();
				battleRecordtemp.fromProtoBufClass(request.getBatttleRecords(0));
				if (battleRecordtemp.getTeamRecords() == null && battleRecordtemp.getTeamRecords().size() <= 0)
				{
					result = ClientProtocols.E_GAME_COMBAT_FRIEND_FAILED_ERROR_BAD_TEAM_RECORD;
					break;
				}
				// 转换战斗结果
				LinkedList<BattleRecord> battleRecords = new LinkedList<BattleRecord>();
				for (CombatData.BattleRecord combatbattleRecord : request.getBatttleRecordsList())
				{
					BattleRecord battleRecord = new BattleRecord();
					battleRecord.fromProtoBufClass(combatbattleRecord);
					battleRecords.add(battleRecord);
				}
				// 保存战斗结果
				CombatResultAndReward combatResultAndReward = new CombatResultAndReward();
				combatResultAndReward.setBattleRecords(battleRecords);
				combatResultAndReward.setCombatNumMax(1);

				int combatRewardId = -1;
				// 判断本次是否有奖励
				if (friendData.getGetFriendCombatRewardCount() < friendCombatCfg.get_MaxGetCombatRewardCount())
				{
					if (Math.random() <= friendCombatCfg.get_GetCombatRewardPercent())
					{
						ValueRandomer random = new ValueRandomer();
						for (int i = 0; i < friendCombatCfg.Get_FriendCombatRewardsCount(); i++)
						{
							FriendCombatReward combatRewardCfg = friendCombatCfg.Get_FriendCombatRewardsByIndex(i);
							random.addValue(combatRewardCfg.get_Weight(), combatRewardCfg.get_RewardId());
						}
						random.SetTotalValue();
						combatRewardId = (int)random.RandomData();
					}
				}
				if (combatRewardId != -1)
				{
					// 生成奖励
					FriendCombatReward friendCombatRewardCfg = friendCombatCfg.GetCombatRewardById(combatRewardId);
					Reward rewardAll = new Reward();
					Reward passReward = new Reward();
					{
						for (int i = 0; i < friendCombatRewardCfg.Get_RewardsCount(); i++)
						{
							passReward.megerReward(new Reward().fromClientServerCommon(friendCombatRewardCfg.Get_RewardsByIndex(i)));
						}
					}
					combatResultAndReward.setDungeonReward(passReward);

					// 合并各项通过奖励
					rewardAll.megerReward(passReward);
					// 把奖励存入内存
					CostAndRewardAndSync crsForReward = new CostAndRewardAndSync();
					crsForReward.mergeReward(rewardAll);
					CostAndRewardManager.addReward(playerNode,
						rewardAll,
						cd,
						KodLogEvent.FriendLogic_CombatFriend);
					crsForClient.megerCostAndRewardAndSync(crsForReward);

					// 增加已领取奖励次数
					friendData.addGetFriendCombatRewardCount();
				}

				combatResultAndReward.setCombatNumMax(request.getCombatNumMax());
				combatResultAndReward.setCombatNumReal(request.getCombatNumReal());

				// 更新数据库
				FriendMgr.updateFriend(playerNode);

				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
				builder.setCombatResultAndReward(combatResultAndReward.toProtobuf());

			} while (false);
		}
		catch (Exception e)
		{
			logger.error(ExceptionUtils.getStackTrace(e));
			result = ClientProtocols.E_SERVER_PROC_ERROR;
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
	}
}
