package com.kodgames.corgi.server.asyncclient;


import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.MarvellousAdventureConfig.CombatEvent;
import ClientServerCommon.MarvellousAdventureConfig.RewardEvent;
import ClientServerCommon.MarvellousAdventureConfig._MarvellousType;

import com.kodgames.combat.record.BattleRecord;
import com.kodgames.combat.record.CombatResultAndReward;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols.DelayReward;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_MarvellousNextMarvellousRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.corgi.protocol.ServersProtocolsForServer.QueryCombatResultRes;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.marvellous.data.Marvellous;
import com.kodgames.corgi.server.gameserver.marvellous.data.MarvellousEnum;
import com.kodgames.corgi.server.gameserver.marvellous.data.MarvellousMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;

public class QueryMarvellousCombatResultRes implements AsyncMessager
{
	private static final Logger logger = LoggerFactory.getLogger(QueryMarvellousCombatResultRes.class);

	private int callback;
	private int playerId;
	private ClientNode sender;
	private CostAndRewardAndSync crsForClient;
	private CostAndRewardAndSync fixRewardPackage;
	private CostAndRewardAndSync randRewardPackage;
	private CostAndRewardAndSync normalTipsReward;
	private ConfigDatabase cd;
	private ClientServerCommon.MarvellousAdventureConfig.CombatEvent combatEvent;
	private int marvellousScenarioId;

	public QueryMarvellousCombatResultRes(int callback, int playerId, CombatEvent combatEvent, ClientNode sender, CostAndRewardAndSync crsForClient, CostAndRewardAndSync fixRewardPackage, CostAndRewardAndSync randRewardPackage,CostAndRewardAndSync normalTipsReward, ConfigDatabase cd, int marvellousScenarioId)
	{
		this.callback = callback;
		this.playerId = playerId;
		this.sender = sender;
		this.crsForClient = crsForClient;
		this.fixRewardPackage = fixRewardPackage;
		this.randRewardPackage = randRewardPackage;
		this.normalTipsReward = normalTipsReward;
		this.cd = cd;
		this.combatEvent = combatEvent;
		this.marvellousScenarioId = marvellousScenarioId;
	}

	@Override
	public String getName()
	{
		return this.getClass().getSimpleName();
	}

	@Override
	public void handlerMessage(Protocol message)
	{
		logger.info("recv QueryMarvellousCombatResultRes, Player is {}", playerId);
		QueryCombatResultRes request = (QueryCombatResultRes)message.getProtoBufMessage();

		GC_MarvellousNextMarvellousRes.Builder builder = GC_MarvellousNextMarvellousRes.newBuilder();
		Protocol marvellousNextProtocol = new Protocol(ClientProtocols.P_GAME_GC_MARVELLOUSNEXTRES);
		builder.setCallBack(callback);
		if (request.getResult() == ClientProtocols.E_SERVER_PROC_ERROR)
		{
			builder.setResult(ClientProtocols.E_SERVER_PROC_ERROR);
			marvellousNextProtocol.setProtoBufMessage(builder.build());
			ServerDataGS.transmitter.sendToClient(this.sender, marvellousNextProtocol);
			return;
		}

		int result = ClientProtocols.E_GAME_MARVELLOUSNEXTRE_SUCCESS;
		PlayerNode playerNode = null;
		List<DelayReward> delayRewardList = new ArrayList<DelayReward>();
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_MARVELLOUS_NEXT_RESULT_FAILED_LOAD_PLAYER;
					break;
				}
				
				if (request.getResult() != ServerProtocols.E_ALL_QUERY_COMBAT_RESULT_SUCCESS)
				{
					result = request.getResult();
					break;
				}
				
				if (request.getBatttleRecordsCount() <= 0)
				{
					result = ClientProtocols.E_COMBAT_BATTLE_RECORD_ERROR_BAD_BATTLE_RECORD_COUNT;
					break;
				}
				
				Marvellous marvellous = playerNode.getPlayerInfo().getMarvellous();
				// 判断战斗结果数据是否有问题.
				BattleRecord battleRecordtemp = new BattleRecord();
				battleRecordtemp.fromProtoBufClass(request.getBatttleRecords(0));
				if (battleRecordtemp.getTeamRecords() == null && battleRecordtemp.getTeamRecords().size() <= 0)
				{
					result = ClientProtocols.E_COMBAT_BATTLE_RECORD_ERROR_BAD_TEAM_RECORD;
					break;
				}
				boolean isWinner = battleRecordtemp.getTeamRecords().get(0).isWinner();
				
				int nextEventId;
				if (!isWinner)
				{
					nextEventId = combatEvent.get_CombatLoserGoToEventId();		
					BPUtil.qyfight(playerNode, marvellous.getWorldId(), combatEvent.get_EventId(), 0);
				}
				else
				{
					nextEventId = combatEvent.get_CombatWinnerGoToEventId();
					BPUtil.qyfight(playerNode, marvellous.getWorldId(), combatEvent.get_EventId(), 1);
				}
				
				if(nextEventId <= 0)
				{
					MarvellousMgr.setFinishEvent(playerNode, marvellousScenarioId);
				}
				
				//如果事件是奖励事件，那么一直进行下去.
				long nowTime = System.currentTimeMillis();
				
				boolean isNeedFresh = false;
				while(cd.get_MarvellousAdventureConfig().GetEventTypeById(nextEventId) == _MarvellousType.RewardTypeEvent)
				{
					Object object = cd.get_MarvellousAdventureConfig().GetEventById(nextEventId);
					if(null == object)
					{
						isNeedFresh = true;
						break;
					}
					
					RewardEvent rewardEvent =  (RewardEvent)object;
					MarvellousMgr.processRewardTypeEvent(crsForClient, fixRewardPackage, randRewardPackage, normalTipsReward, playerNode, rewardEvent, cd, delayRewardList, nowTime);
					nextEventId = rewardEvent.get_GoToEventId();
					if(nextEventId == 0)
					{
						MarvellousMgr.setFinishEvent(playerNode, playerNode.getPlayerInfo().getMarvellous().getCurrentmarvellousScenario());
					}
					
					nowTime++;
				}
				if(!isNeedFresh)
				{
					playerNode.getPlayerInfo().getMarvellous().setCurrentEventId(nextEventId);
				}
				
				MarvellousEnum marvellousEnumNew = MarvellousMgr.getMarvellousStatus(playerNode, cd);
				if(MarvellousEnum.NEED_REFRESH == marvellousEnumNew || isNeedFresh)
				{
					MarvellousMgr.initMarvellous(playerNode, cd);
				}
				
				// 更新数据库
				MarvellousMgr.replaceToDB(playerNode);
				builder.setMarvellousProto(marvellous.toProtoBuf());
				CombatResultAndReward combatResultAndReward = new CombatResultAndReward();
				combatResultAndReward.addBattleRecords(battleRecordtemp);
				combatResultAndReward.setCombatNumMax(request.getCombatNumMax());
				combatResultAndReward.setCombatNumReal(request.getCombatNumReal());
				builder.setCombatResultAndReward(combatResultAndReward.toProtobuf());
				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
				builder.setFixRewardPackage(fixRewardPackage.toProtobuf());
				builder.setRandRewardPackage(randRewardPackage.toProtobuf());
				builder.setNormalTipsReward(normalTipsReward.toProtobuf());
			} while (false);
		}
		catch (Exception e)
		{
			logger.error(ExceptionUtils.getStackTrace(e));
			result = ClientProtocols.E_SERVER_PROC_ERROR;
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		marvellousNextProtocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, marvellousNextProtocol);
	}
}
