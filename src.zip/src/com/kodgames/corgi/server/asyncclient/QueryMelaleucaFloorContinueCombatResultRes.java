package com.kodgames.corgi.server.asyncclient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.MelaleucaFloorConfig;

import com.kodgames.combat.record.BattleRecord;
import com.kodgames.combat.record.CombatPlayer;
import com.kodgames.combat.record.CombatResultAndReward;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols.MelaleucaFloorInfo;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_MelaleucaFloorConsequentCombatRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.corgi.protocol.ServersProtocolsForServer.QueryCombatResultRes;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.melaleucaFloor.data.Melaleuca;
import com.kodgames.corgi.server.gameserver.melaleucaFloor.data.MelaleucaFloorData;
import com.kodgames.corgi.server.gameserver.melaleucaFloor.data.MelaleucaMgr;
import com.kodgames.corgi.server.gameserver.melaleucaFloor.data.Rank;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class QueryMelaleucaFloorContinueCombatResultRes implements AsyncMessager
{
	private static final Logger logger = LoggerFactory.getLogger(QueryArenaCombatResultRes.class);

	private int callback;
	private int playerId;
	private int layers;
	private Rank rank;
	private int week;
	private MelaleucaFloorData data;
	ClientNode sender;
	private long timeNow;
	private int combatCount;
	private ConfigDatabase cd;

	public QueryMelaleucaFloorContinueCombatResultRes(int callback, int playerId, int layers, Rank rank, int week, MelaleucaFloorData data, ClientNode sender, long timeNow,
			int combatCount, CombatPlayer combatPlayer, ConfigDatabase cd)
	{
		super();
		this.callback = callback;
		this.playerId = playerId;
		this.layers = layers;
		this.rank = rank;
		this.data = data;
		this.sender = sender;
		this.timeNow = timeNow;
		this.combatCount = combatCount;
		this.cd = cd;
	}

	@Override
	public void handlerMessage(Protocol message)
	{
		logger.info("recv QueryMelaleucaFloorCombatResultRes, playerId = {}", playerId);
		QueryCombatResultRes request = (QueryCombatResultRes) message.getProtoBufMessage();

		GC_MelaleucaFloorConsequentCombatRes.Builder builder = GC_MelaleucaFloorConsequentCombatRes.newBuilder();

		int result = ClientProtocols.E_GAME_MELALEUCA_FLOOR_CONSEQUENT_COMBAT_SUCCESS;

		PlayerNode playerNode = null;
		MelaleucaFloorConfig config = cd.get_MelaleucaFloorConfig();
		ServerDataGS.playerManager.lockPlayer(playerId);

		// 战斗结果相关
		CostAndRewardAndSync totalCrs = new CostAndRewardAndSync();
		int maxPassLayer = data.getMaxPassLayer();
		int startLayer = rank.getDayLayer();

		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_MELALEUCA_FLOOR_CONSEQUENT_COMBAT_FAILED_LOAD_PLAYER;
					break;
				}

				if (cd == null || cd.get_MelaleucaFloorConfig() == null)
				{
					result = ClientProtocols.E_GAME_MELALEUCA_FLOOR_CONSEQUENT_COMBAT_FAILED_LOAD_CONFIG;
					break;
				}

				if (request.getResult() != ServerProtocols.E_ALL_QUERY_COMBAT_RESULT_SUCCESS)
				{
					result = request.getResult();
					break;
				}

				int battleRecordsCount = request.getBatttleRecordsCount();
				if (battleRecordsCount <= 0)
				{
					result = ClientProtocols.E_COMBAT_BATTLE_RECORD_ERROR_BAD_BATTLE_RECORD_COUNT;
					break;
				}

				int arrivalLayer = startLayer + battleRecordsCount;
				int maxLayer = arrivalLayer;
				// 战斗中有失败
				if (!request.getBatttleRecordsList().get(battleRecordsCount - 1).getTeamRecord(0).getIsWinner())
				{
					// 战斗失败， 保存 战斗结果 , 只保存失败的一组
					CombatResultAndReward combatResultAndReward = new CombatResultAndReward();
					combatResultAndReward.setCombatNumMax(request.getCombatNumMax());
					combatResultAndReward.setCombatNumReal(request.getCombatNumReal());

					int failLayer = battleRecordsCount % layers;
					// 为0表示打layers层的倍数层失败，回退layers
					if (failLayer == 0)
					{
						failLayer = layers;
					}
					for (int i = battleRecordsCount - failLayer; i < battleRecordsCount; i++)
					{
						BattleRecord battleRecord = new BattleRecord();
						battleRecord.fromProtoBufClass(request.getBatttleRecords(i));
						combatResultAndReward.addBattleRecords(battleRecord);
						builder.setCombatResultAndReward(combatResultAndReward.toProtobuf());
					}

					int failsCost = config.get_ChallengeCostPerTimes();
					MelaleucaMgr.addPlayerFailsCount(playerId, rank, failsCost);

					// 失败回退层数
					arrivalLayer -= failLayer;
					// 第一次就失败无奖励,直接退出
					if (arrivalLayer <= startLayer)
					{
						break;
					}
				}

				// 每日首次挑战奖励
				if (!rank.isDayChallenged())
				{
					MelaleucaMgr.setDayChallenged(playerId, rank);

					Reward perDayReward = new Reward();
					for (int i = 0; i < cd.get_MelaleucaFloorConfig().Get_ChallengeRewardPerDayCount(); i++)
					{
						perDayReward.megerReward(new Reward().fromClientServerCommon(cd.get_MelaleucaFloorConfig().Get_ChallengeRewardPerDayByIndex(i)));
					}
					CostAndRewardAndSync crsForReward = new CostAndRewardAndSync();
					crsForReward.mergeReward(perDayReward);
					totalCrs.megerCostAndRewardAndSync(crsForReward);
					builder.setFirstChallengeReward(crsForReward.toProtobuf());

					playerNode.getPlayerInfo().getAssisantData().getMelaleucaDailyPass().notifyObservers();
				}

				for (int i = startLayer + 1; i <= arrivalLayer; i++)
				{
					int floor = (i > config.Get_FloorsCount()) ? config.Get_FloorsCount() : i;
					MelaleucaFloorConfig.Floor floorConfig = config.GetFloorByLayer(floor);

					// 通关奖励
					CostAndRewardAndSync passCrs = new CostAndRewardAndSync();
					for (int j = 0; j < floorConfig.Get_PassRewardCount(); j++)
					{
						passCrs.mergeReward(new Reward().fromClientServerCommon(floorConfig.Get_PassRewardByIndex(j)));
					}
					totalCrs.megerCostAndRewardAndSync(passCrs);
					builder.addPassReward(passCrs.toProtobuf());

					// 首次通关奖励
					if (i > maxPassLayer)
					{
						maxPassLayer = i;
						CostAndRewardAndSync firstPassCrs = new CostAndRewardAndSync();
						for (int j = 0; j < floorConfig.Get_FirstPassRewardCount(); j++)
						{
							firstPassCrs.mergeReward(new Reward().fromClientServerCommon(floorConfig.Get_FirstPassRewardByIndex(j)));
						}
						totalCrs.megerCostAndRewardAndSync(firstPassCrs);
						builder.addFirstPassReward(firstPassCrs.toProtobuf());
						builder.addFirstPassLayers(i);
					}
				}

				MelaleucaMgr.updatePlayerMaxPassLayer(playerId, data, maxPassLayer);

				// 积分奖励
				int rewardPointCount = 0;
				for (int i = 0, count = (arrivalLayer - startLayer) / layers; i < count; i++)
				{
					MelaleucaFloorConfig.Challenge challengeConfig = config.GetChallengeByLayers(layers);
					rewardPointCount += challengeConfig.get_Point();
				}

				if (totalCrs.getRewardForRead() != null)
				{
					CostAndRewardManager.addReward(playerNode, totalCrs.getRewardForRead(), cd, KodLogEvent.MelaleucaFloorLogic_PassReward);
				}

				MelaleucaMgr.addPlayrDayPointAndLayer(playerId, rank, rewardPointCount, arrivalLayer - startLayer, timeNow);

				// Log
				int maxFailsTimes = cd.get_VipConfig().GetVipLimitByVipLevel(playerNode.getGamePlayer().getVipLevel(),
						ClientServerCommon.VipConfig._VipLimitType.MelaleucaFloorChallengeCount);
				if (request.getBatttleRecordsList().get(battleRecordsCount - 1).getTeamRecord(0).getIsWinner())
				{
					BPUtil.qjl(playerNode, layers, maxLayer, 1, maxFailsTimes - rank.getDayFailsCount());
				}
				else
				{
					BPUtil.qjl(playerNode, layers, maxLayer, 0, maxFailsTimes - rank.getDayFailsCount());
				}
				
				rank.combatUnlock();
			}
			while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}
		
		if(result == ClientProtocols.E_GAME_MELALEUCA_FLOOR_CONSEQUENT_COMBAT_SUCCESS)
		{
			MelaleucaFloorInfo info = Melaleuca.genMeleleucaFloorInfo(playerId, week, data, rank, config);
			builder.setMelaleucaFloorInfo(info);
		}

		builder.setCallback(callback);
		builder.setResult(result);
		builder.setLayers(layers);
		builder.setCombatCount(combatCount);

		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_MELALEUCA_FLOOR_CONSEQUENT_COMBAT_RES);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);

	}

	@Override
	public String getName()
	{
		return this.getClass().getSimpleName();
	}

}
