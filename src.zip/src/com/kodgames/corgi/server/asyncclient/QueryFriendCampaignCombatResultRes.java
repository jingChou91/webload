package com.kodgames.corgi.server.asyncclient;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.FriendCampaignConfig;
import ClientServerCommon.Npc;
import ClientServerCommon.RobotConfig;
import ClientServerCommon.RobotConfig.Robot;

import com.kodgames.combat.record.BattleRecord;
import com.kodgames.combat.record.CombatResultAndReward;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CombatData;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.DBProtocolsForServer.ContributeFCScoreInfo.FCScoreInfo;
import com.kodgames.corgi.protocol.DBProtocolsForServer.IllusionDB;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.corgi.protocol.ServersProtocolsForServer.QueryCombatResultRes;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.friendcampaign.data.FriendCampaignData;
import com.kodgames.corgi.server.gameserver.friendcampaign.data.FriendCampaignMgr;
import com.kodgames.corgi.server.gameserver.friendcampaign.data.struct.FriendAvatar;
import com.kodgames.corgi.server.gameserver.friendcampaign.data.struct.FriendCampaignPlayer;
import com.kodgames.corgi.server.gameserver.friendcampaign.util.FCHPUtil;
import com.kodgames.corgi.server.gameserver.friendcampaign.util.FCUtil;
import com.kodgames.corgi.server.gameserver.friendcampaignrank.data.FCRankMgr;
import com.kodgames.corgi.server.gameserver.friendcampaignrank.util.FCRankTimeUtil;
import com.kodgames.corgi.server.gameserver.illusion.util.IllusionUtil;
import com.kodgames.corgi.server.gameserver.marquee.data.FlowMessageMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class QueryFriendCampaignCombatResultRes implements AsyncMessager
{

	private int callback;
	private int playerId;
	ClientNode sender;
	CostAndRewardAndSync crsForClient;
	CommonProtocols.Position battlePosition;
	int friendId;
	CombatResultAndReward combatResultAndReward = new CombatResultAndReward();
	LinkedList<BattleRecord> battleRecords = new LinkedList<BattleRecord>();
	ConfigDatabase cd;
	private static final Logger logger = LoggerFactory.getLogger(QueryFriendCampaignCombatResultRes.class);

	public QueryFriendCampaignCombatResultRes(int callback, int playerId, ClientNode sender,
		CostAndRewardAndSync crsToclient, CommonProtocols.Position battlePosition, int friendId, ConfigDatabase cd)
	{
		this.callback = callback;
		this.playerId = playerId;
		this.sender = sender;
		this.crsForClient = crsToclient;
		this.battlePosition = battlePosition;
		this.friendId = friendId;
		this.cd = cd;
	}

	@Override
	public String getName()
	{
		return this.getClass().getSimpleName();
	}

	@Override
	public void handlerMessage(Protocol message)
	{
		logger.info("recv QueryFriendCampaignCombatResultRes, playerId = {}", playerId);
		QueryCombatResultRes request = (QueryCombatResultRes)message.getProtoBufMessage();

		GameProtocolsForClient.GC_CombatFriendCampaignRes.Builder builder =
			GameProtocolsForClient.GC_CombatFriendCampaignRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_COMBAT_FRIEND_CAMPAIGN_RES);
		builder.setCallback(callback);

		int result = ClientProtocols.E_GAME_COMBAT_FRIEND_CAMPAIGN_SUCCESS;

		boolean isWin = true;
		// 敌方阵容镜像
		FriendCampaignPlayer enemyPlayer = new FriendCampaignPlayer();
		// 敌方剩余血量信息
		List<FriendAvatar> enemyAvatars = new ArrayList<FriendAvatar>();

		PlayerNode playerNode = null;
		PlayerNode enemyPlayerNode = null;
		int enemyPlayerId = 0;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FRIEND_CAMPAIGN_FAILED_LOAD_PLAYER;
					break;
				}
				FriendCampaignConfig friendCampaignCfg = cd.get_FriendCampaignConfig();
				if (friendCampaignCfg == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FRIEND_CAMPAIGN_FAILED_LOAD_CONFIG;
					break;
				}
				if (request.getResult() != ServerProtocols.E_ALL_QUERY_COMBAT_RESULT_SUCCESS)
				{
					result = request.getResult();
					break;
				}
				if (request.getBatttleRecordsCount() <= 0)
				{
					result = ClientProtocols.E_GAME_COMBAT_FRIEND_CAMPAIGN_FAILED_BATTLE_RECORD_COUNT;
					break;
				}
				FriendCampaignData fcData = playerNode.getPlayerInfo().getFriendCampaignData();
				int satgeId = FCUtil.getNextStageId(friendCampaignCfg, fcData.getPassStageId());
				FriendCampaignConfig.Stage stageCfg = friendCampaignCfg.GetStageById(satgeId);
				if (stageCfg == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FRIEND_CAMPAIGN_FAILED_LOAD_CONFIG;
					break;
				}

				// 判断战斗结果数据是否有问题.
				BattleRecord battleRecordtemp = new BattleRecord();
				battleRecordtemp.fromProtoBufClass(request.getBatttleRecords(0));
				if (battleRecordtemp.getTeamRecords() == null && battleRecordtemp.getTeamRecords().size() <= 0)
				{
					result = ClientProtocols.E_GAME_COMBAT_FRIEND_CAMPAIGN_FAILED_TEAM_RECORD_COUNT;
					break;
				}
				// 转换战斗结果
				for (CombatData.BattleRecord combatbattleRecord : request.getBatttleRecordsList())
				{
					BattleRecord battleRecord = new BattleRecord();
					battleRecord.fromProtoBufClass(combatbattleRecord);
					battleRecords.add(battleRecord);
				}
				// 保存战斗结果
				combatResultAndReward.setBattleRecords(battleRecords);
				combatResultAndReward.setCombatNumMax(1);

				// 如果战败,增加失败次数
				int battleRecordsCount = battleRecords.size();
				boolean isWinner = battleRecords.get(battleRecordsCount - 1).getTeamRecords().get(0).isWinner();
				if (battleRecordsCount < 1 || !isWinner)
				{
					isWin = false;
					// 保存敌方剩余血量(包括血量恢复算法)
					FCHPUtil.saveEnemyLeftHP(fcData, battleRecords, stageCfg.get_EnemyRecoverHp());
					// 保存我方剩余血量
					FCHPUtil.saveFriendDeadHP(fcData, friendId);
					// 更新数据库
					FriendCampaignMgr.updateFriendCampaign(playerNode);
					// 返回阵容和剩余血量
					if (fcData.getEnemyPlayer(playerNode).hasFriendPlayer())
					{
						if (fcData.getEnemyPlayer(playerNode).isRobot())
						{
							RobotConfig.Robot robot =
								cd.get_RobotConfig().getRobotByRobotId(fcData.getEnemyPlayer(playerNode).getRobotId());
//							builder.setEnemyPlayer(FCProtoUtil.genPlayerProtoByRobot(cd, robot));
							//机器人信息
							builder.setRobotInfo(FCUtil.genRobotInfo(true, cd, robot, stageCfg.get_RobotName()));
						}
						else
						{
							//机器人信息
							builder.setRobotInfo(FCUtil.genRobotInfo(false, null, null,null));
							builder.setEnemyPlayer(fcData.getEnemyPlayer(playerNode).getPlayerPro());
						}
						for (FriendAvatar enemyAvatar : fcData.getCopyEnemyAvatars())
						{
							CommonProtocols.HpInfo.Builder enemyHpBuilder = CommonProtocols.HpInfo.newBuilder();
							enemyHpBuilder.setLeftHP(enemyAvatar.getLeftHP());
							enemyHpBuilder.setLocationId(enemyAvatar.getBattlePosition());
							builder.addEnemyHpInfo(enemyHpBuilder.build());
						}

					}

					// 返回上一关卡id
					builder.setPassStageId(fcData.getPassStageId());
					builder.setIsJoin(fcData.isJoin());
					// 返回战斗结果
					builder.setCombatResultAndReward(combatResultAndReward.toProtobuf());
					
					// 埋点日志
					BPUtil.yqsl(playerNode, satgeId, 0, fcData.getResetTimes());
					break;
				}

			} while (false);
		}
		catch (Exception e)
		{
			logger.error(ExceptionUtils.getStackTrace(e));
			result = ClientProtocols.E_SERVER_PROC_ERROR;
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		do
		{
			if (result != ClientProtocols.E_GAME_COMBAT_FRIEND_CAMPAIGN_SUCCESS)
			{
				break;
			}
			if (!isWin)
			{
				break;
			}
			
			FriendCampaignData fcData = playerNode.getPlayerInfo().getFriendCampaignData();
			FriendCampaignConfig friendCampaignCfg = cd.get_FriendCampaignConfig();
			int stageId = FCUtil.getNextStageId(friendCampaignCfg, fcData.getPassStageId());
			int nextSatgeId = FCUtil.getNextStageId(friendCampaignCfg, stageId);
			FriendCampaignConfig.Stage nextStageCfg = friendCampaignCfg.GetStageById(nextSatgeId);
			
			//添加FC排行榜信息
			int point = friendCampaignCfg.GetStageById(stageId).get_Point();
			FCRankTimeUtil.insertToRankList(playerNode, point, fcData.getLastFriendIds());
			
			// 如果还有下一关,生成下一关敌人阵容镜像
			if (nextSatgeId != -1)
			{
				// 配置文件配置该关卡是否使用机器人
				if (nextStageCfg.get_IsUseRobot())
				{
					enemyPlayerId = nextStageCfg.get_RobotId();
				}
				else
				{
					// 敌方玩家id
					enemyPlayerId = FCUtil.randomEnemyPlayerId(playerNode, cd, nextSatgeId);
				}
				if (FCUtil.isRobot(enemyPlayerId))
				{
					RobotConfig robotConfig = cd.get_RobotConfig();
					Robot robot = robotConfig.getRobotByRobotId(enemyPlayerId);
					if (robot == null)
					{
						result = ClientProtocols.E_GAME_COMBAT_FRIEND_CAMPAIGN_FAILED_ROBOT_INFO_ERROR;
						break;
					}
					for (int i = 0; i < robot.Get_npcsCount(); i++)
					{
						FriendAvatar robotAvatar = new FriendAvatar();
						Npc npc = robot.Get_npcsByIndex(i);
						robotAvatar.setBattlePosition(npc.get_battlePosition());
						robotAvatar.setLeftHP(1);
						enemyAvatars.add(robotAvatar);
					}
					enemyPlayer.setRobotId(enemyPlayerId);
				}
				else
				{
					enemyPlayerNode = ServerDataGS.playerManager.getPlayerNode(enemyPlayerId);
					if (enemyPlayerNode == null || enemyPlayerNode.getPlayerInfo() == null)
					{
						result = ClientProtocols.E_GAME_COMBAT_FRIEND_CAMPAIGN_FAILED_GET_ENEMY_PLAYERNODE_ERROR;
						break;
					}

					// 生成敌方阵容镜像
					enemyPlayer = FCUtil.genEnemyPlayer(enemyPlayerNode, enemyPlayerId, cd);
					// 生成敌方敌方剩余血量信息
					enemyAvatars =
						FCUtil.genEnemyAvatarList(enemyPlayerNode, enemyPlayerNode.getPlayerInfo()
							.getPositionData()
							.getMasterPositionId());
				}
			}
		} while (false);

		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				if (result != ClientProtocols.E_GAME_COMBAT_FRIEND_CAMPAIGN_SUCCESS)
				{
					break;
				}
				if (!isWin)
				{
					break;
				}
				FriendCampaignData fcData = playerNode.getPlayerInfo().getFriendCampaignData();
				FriendCampaignConfig friendCampaignCfg = cd.get_FriendCampaignConfig();
				int satgeId = FCUtil.getNextStageId(friendCampaignCfg, fcData.getPassStageId());
				FriendCampaignConfig.Stage stageCfg = friendCampaignCfg.GetStageById(satgeId);
				int nextSatgeId = FCUtil.getNextStageId(friendCampaignCfg, satgeId);
				// FriendCampaignConfig.Stage nextStageCfg = friendCampaignCfg.GetStageById(nextSatgeId);
				if (nextSatgeId != -1)
				{
					// 更新敌方阵容镜像
					fcData.setEnemyPlayer(enemyPlayer);
					if (!FCUtil.isRobot(enemyPlayerId))
					{
						// 保存敌方幻化信息
						IllusionUtil.autoUpdateStatus(enemyPlayerNode);
						fcData.setEnemyIllusionDB(IllusionUtil.genIllusionDB(enemyPlayerNode, cd));
					}
					else
					{
						fcData.setEnemyIllusionDB(IllusionDB.newBuilder().build());
					}
				}
				else
				{
					fcData.setEnemyPlayer(new FriendCampaignPlayer());
				}
				
				// 更新敌方剩余血量
				fcData.setEnemyAvatars(enemyAvatars);
				// 更新关卡id
				fcData.setPassStageId(satgeId);
				// 保存我方剩余血量
				FCHPUtil.saveFriendLeftHP(fcData, friendId, battleRecords);

				// 计算通关奖励
				Reward rewardAll = new Reward();// -------------------------------------------
				// 普通通关奖励
				Reward passReward = new Reward();
				// 首次通关奖励
				Reward firstPassReward = new Reward();
				{
					// 通关奖励
					for (int i = 0; i < stageCfg.Get_PassRewardsCount(); i++)
					{
						passReward.megerReward(new Reward().fromClientServerCommon(stageCfg.Get_PassRewardsByIndex(i)));
					}
					// 首次通关奖励
					if (!fcData.getHistoryStageIds().contains(satgeId))
					{
						for (int i = 0; i < stageCfg.Get_FirstPassRewardsCount(); i++)
						{
							firstPassReward.megerReward(new Reward().fromClientServerCommon(stageCfg.Get_FirstPassRewardsByIndex(i)));
						}
						// 保存新的已通关关卡id
						fcData.getHistoryStageIds().add(satgeId);
					}
				}
				combatResultAndReward.setDungeonReward(passReward);
				combatResultAndReward.setFirstpassReward(firstPassReward);
				combatResultAndReward.setCombatNumMax(request.getCombatNumMax());
				combatResultAndReward.setCombatNumReal(request.getCombatNumReal());

				// 合并各项通过奖励
				rewardAll.megerReward(passReward).megerReward(firstPassReward);
				// 把奖励存入内存
				CostAndRewardAndSync crsForReward = new CostAndRewardAndSync();
				crsForReward.mergeReward(rewardAll);
				CostAndRewardManager.addReward(playerNode,
					rewardAll,
					cd,
					KodLogEvent.FriendCampaignLogic_CombatResult);
				crsForClient.megerCostAndRewardAndSync(crsForReward);

				// 更新数据库
				FriendCampaignMgr.updateFriendCampaign(playerNode);

				builder.setIsJoin(fcData.isJoin());
				builder.setPassStageId(satgeId);
				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
				builder.setCombatResultAndReward(combatResultAndReward.toProtobuf());

				// 跑马灯
				if (nextSatgeId == -1)
				{
					String fmt = cd.get_StringsConfig().GetString("UI", "ServerText_FlowMessage_Friend");
					String content = String.format(fmt, playerNode.getGamePlayer().getFixName());
					FlowMessageMgr.getInstance().prepareBrodcastFlowMessage(content);
				}
				
				// 埋点日志
				BPUtil.yqsl(playerNode, satgeId, 1, fcData.getResetTimes());

			} while (false);
		}
		catch (Exception e)
		{
			logger.error(ExceptionUtils.getStackTrace(e));
			result = ClientProtocols.E_SERVER_PROC_ERROR;
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
	}
}
