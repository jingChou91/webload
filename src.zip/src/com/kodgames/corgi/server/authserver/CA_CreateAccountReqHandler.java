/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.authserver;

import java.net.SocketAddress;

import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.CA_CreateAccountReq;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.authserver.local.CA_CreateAccountReqHandler_Local;

/**
 * 
 * @author ZHD
 */
public class CA_CreateAccountReqHandler extends MessageHandler {
	
	private static final Logger logger = LoggerFactory.getLogger(CA_CreateAccountReqHandler.class);

	@Override
	public HandlerAction handleMessage(Channel channel, SocketAddress remoteAddress, Protocol message) {

		CA_CreateAccountReq request = (CA_CreateAccountReq) message.getProtoBufMessage();
		
		if(request.hasLocalCreateAccountReq())
		{
			return CA_CreateAccountReqHandler_Local.handleMessage(channel, remoteAddress, message);
		}
		else
		{
			logger.warn("recv CA_CreateAccountReq, unKnowPlatform");
			return HandlerAction.TERMINAL;
		}
	}
}
