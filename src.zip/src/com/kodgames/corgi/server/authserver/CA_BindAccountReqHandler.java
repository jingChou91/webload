package com.kodgames.corgi.server.authserver;

import java.net.SocketAddress;

import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.CA_BindAccountReq;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.authserver.local.CA_BindAccountReqHandler_Local;

public class CA_BindAccountReqHandler extends MessageHandler {

	private static final Logger logger = LoggerFactory.getLogger(CA_BindAccountReqHandler.class);

	@Override
	public HandlerAction handleMessage(Channel channel, SocketAddress remoteAddress, Protocol message) {

		CA_BindAccountReq request = (CA_BindAccountReq) message.getProtoBufMessage();
		
		if(request.hasLocalBindAccountReq())
		{
			return CA_BindAccountReqHandler_Local.handleMessage(channel, remoteAddress, message);
		}
		else
		{
			logger.warn("recv CA_BindAccountReq, unKnowPlatform");
			return HandlerAction.TERMINAL;
		}
	}
}
