/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.authserver;

import java.net.SocketAddress;

import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.CA_LoginReq;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.authserver.cmge.CA_LoginReqHandler_Cmge;
import com.kodgames.corgi.server.authserver.efun.CA_LoginReqHandler_EFun;
import com.kodgames.corgi.server.authserver.cyaggregate.CA_LoginReqHandler_CyAggregate;
import com.kodgames.corgi.server.authserver.local.CA_LoginReqHandler_Local;

/**
 * 
 * @author Elvin
 */
public class CA_LoginReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CA_LoginReqHandler.class);

	@Override
	public HandlerAction handleMessage(Channel channel, SocketAddress remoteAddress, Protocol message)
	{
		CA_LoginReq request = (CA_LoginReq)message.getProtoBufMessage();
		if (request.hasLocalLoginReq())
		{
			return CA_LoginReqHandler_Local.handleMessage(channel, remoteAddress, message);
		}
		else if (request.hasCyAggregateLoginReq())
		{
			return CA_LoginReqHandler_CyAggregate.handleMessage(channel, remoteAddress, message);
		}
		else if (request.hasCmgeLoginReq())
		{
			return CA_LoginReqHandler_Cmge.handleMessage(channel, remoteAddress, message);
		}
		else if(request.hasEfunLoginReq()){
			return CA_LoginReqHandler_EFun.handlerMessage(channel, remoteAddress, message);
		}
		else
		{
			logger.warn("recv CA_LoginReq, unKnowPlatform");
			return HandlerAction.TERMINAL;
		}
	}
}
