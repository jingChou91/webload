/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.authserver;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.dom4j.DocumentException;
import org.hyperic.sigar.SigarException;
import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.ServerNode;
import com.kodgames.corgi.gameconfiguration.AreaData;
import com.kodgames.corgi.gameconfiguration.KodThreadName;
import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.protocol.ManageProtocolsForServer.ReloadConfigRes;
import com.kodgames.corgi.protocol.ManageProtocolsForServer.StreamObject;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.Protocols;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.corgi.server.common.CommonServerConfig;
import com.kodgames.corgi.server.common.DBCluster;
import com.kodgames.corgi.server.common.ServerConfigParser;
import com.kodgames.corgi.server.common.Statistics;
import com.kodgames.corgi.server.common.StatisticsRunnable;
import com.kodgames.corgi.server.common.StreamLoaderDispatchMgr;
import com.kodgames.corgi.server.common.ZipUtil;
import com.kodgames.corgi.server.dbclient.KodLog;
import com.kodgames.corgi.server.manageserver.ManageClientHandler;
import com.kodgames.gamedata.area.AreaConfigMgr;
/**
 * 
 * @author marui
 */
public class AuthServerManageClientHandler extends ManageClientHandler 
{
	public AuthServerManageClientHandler() 
	{
		super(ServerDataAS.transmitter);
	}

	private static final Logger logger = LoggerFactory.getLogger(AuthServerManageClientHandler.class);

	@Override
	public void processServerLoginRes(ServerNode sender, int result, int serverID, String ServerCfg, String dbServerCfg, List<StreamObject> serverStreamObjects, List<StreamObject> clientsObjects,int areaId, int timeZone) {
		logger.warn("serverID = 0x{}",Integer.toHexString(serverID));
		TimeZoneData.setTimezone(timeZone);
		AreaData.setAreaId(-2);

		if (result == ServerProtocols.E_MANAGE_LOGIN_SUCCESS) 
		{
			//加载所有的配置文件
			for(StreamObject streamObject : serverStreamObjects)
			{
				try
				{
					StreamLoaderDispatchMgr.getInstance().loadFromMeomry(streamObject.getName(), ZipUtil.uncompress(streamObject.getStreamBuffer()));
				}
				catch (IOException e)
				{
					logger.error("zipUnCompress {} failed, {}", streamObject.getName(), ExceptionUtils.getStackTrace(e));
				}
			}

			ServerConfigParser parser = null;
			try 
			{
				parser = new ServerConfigParser(ServerCfg);
			} 
			catch (DocumentException ex)
			{
				logger.error("create ServerConfigParser failed, cfg: \n{}\n{}", ServerCfg ,ExceptionUtils.getStackTrace(ex));
				return;
			}
			int portForServer = parser.parseInt("PortForServer");
			int portForClient = parser.parseInt("PortForClient");
			int miniPortForClient = parser.parseInt("MiniPortForClient");

			ServerDataAS.transmitter.setLocalServerID(serverID);

			try 
			{
				ServerDataAS.dbCluster = new DBCluster(dbServerCfg,AreaData.getAreaId(),Protocols.SERVER_TYPE_AUTH);
			} 
			catch (Exception ex) 
			{
				logger.error("create DBCluster failed, {} dbServerCfg:\n{}",ExceptionUtils.getStackTrace(ex), dbServerCfg);
				return;
			}

			KodLog.Init(ServerDataAS.dbCluster);			
			try
			{
				ServerDataAS.statistics = new Statistics(CommonServerConfig.getInstance().getServerName());
			} 
			catch (SigarException ex)
			{
				logger.error("create Statistics failed \n{}",ExceptionUtils.getStackTrace(ex));
				return;
			}

			Thread statisticsThread = new Thread(new StatisticsRunnable(),KodThreadName.genName("KOD_StatisticsRunnable"));
			statisticsThread.start();

			try
			{
				logger.info("authServer openPort portForServer={}",portForServer);
				boolean portForServerOpen = ServerDataAS.authServer.openPort(new InetSocketAddress(portForServer));

				boolean portForClientOpen = true;
				if(portForClient != 0)
				{
					logger.info("authClient openPort portForClient={}",portForClient);
					portForClientOpen = ServerDataAS.authClient.openPort(new InetSocketAddress(portForClient));
				}
				
				boolean miniPortOpenForClient = true;
				if(miniPortForClient != 0)
				{
					logger.info("authClient openPort miniPortForClient={}",miniPortForClient);
					miniPortOpenForClient = ServerDataAS.authClient.openPort(new InetSocketAddress(miniPortForClient));
				}

				if(portForClientOpen && portForServerOpen && miniPortOpenForClient)
				{
					serverLoginConfirm(sender.getServerID(), 2);
					logger.warn("AuthServer start success!!!");
				}
			} 
			catch (Exception e)
			{
				logger.error("Bind port failed !!! {}", ExceptionUtils.getStackTrace(e));
				System.exit(0);
			}
		}
	}

	@Override
	/*
	 * 热更新配置文件
	 */
	public void processReloadConfigRes(Channel channel,List<StreamObject> streamObjects, List<StreamObject> clientsObjects, boolean needAddVersion ,boolean isServerConfig)
	{
		int result = ServerProtocols.E_MANAGE_RELOAD_CONFIG_SUCCESS;
        logger.warn("AuthServer Receive Reload Config !!!");
		for(StreamObject streamObject : streamObjects)
		{
			try
			{
				StreamLoaderDispatchMgr.getInstance().loadFromMeomry(streamObject.getName(), ZipUtil.uncompress(streamObject.getStreamBuffer()));
			}
			catch (IOException e)
			{
				result = ServerProtocols.E_MANAGE_RELOAD_CONFIG_FAILED;
				logger.error("zipUnCompress {} failed, {}", streamObject.getName(), ExceptionUtils.getStackTrace(e));
			}
		}
		logger.warn("AuthServer areaConfig whitelist : {}", AreaConfigMgr.getInstance().getWhiteIpRanges());

		ReloadConfigRes.Builder builder = ReloadConfigRes.newBuilder();
		Protocol protocol = new Protocol(ServerProtocols.P_MANAGE_SERVER_RELOAD_CONFIG_RES);
		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataAS.transmitter.send(channel, protocol);
	}
}
