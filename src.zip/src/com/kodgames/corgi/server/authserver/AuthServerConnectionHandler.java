/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kodgames.corgi.server.authserver;

import static com.kodgames.corgi.protocol.Protocols.PROTOCOL_TYPE_AUTH;
import static com.kodgames.corgi.protocol.Protocols.SERVER_TYPE_AUTH;

import java.util.LinkedList;
import java.util.List;

import org.jboss.netty.channel.ChannelHandlerContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.ConnectionEvent;
import com.kodgames.corgi.protocol.Protocols;
import com.kodgames.corgi.server.SimpleConnectionHandler;
import com.kodgames.corgi.server.common.CommonServerConfig;
import com.kodgames.corgi.server.manageserver.ManageClientHandler;

/**
 * 
 * @author zhaohaidi
 */
public class AuthServerConnectionHandler extends SimpleConnectionHandler
{
	private static final Logger logger = LoggerFactory.getLogger(AuthServerConnectionHandler.class);
	ManageClientHandler loginResHandler;

	AuthServerConnectionHandler(ManageClientHandler loginResHandler)
	{
		this.loginResHandler = loginResHandler;
	}

	@Override
	public ManageClientHandler getLoginResHandler()
	{
		return this.loginResHandler;
	}

	@Override
	public List<Integer> getSupportProtocols()
	{
		List<Integer> supportProtocols = new LinkedList<Integer>();
		supportProtocols.add(PROTOCOL_TYPE_AUTH);
		return supportProtocols;
	}

	@Override
	public List<Integer> getCareServers() 
	{
		List<Integer> careServers = new LinkedList<Integer>();
		careServers.add(Protocols.SERVER_TYPE_GAME);
		return careServers;
	}

	@Override
	public int getLocalServerType() 
	{
		return SERVER_TYPE_AUTH;
	}

	@Override
	public String getServerName() 
	{
		return CommonServerConfig.getInstance().getServerName();
	}
	
	@Override
	public void connectionClose(ChannelHandlerContext ctx, ConnectionEvent e) throws Exception
	{
        super.connectionClose(ctx, e);
	}
	
	@Override
	public void connectionOpen(ChannelHandlerContext ctx, ConnectionEvent e) throws Exception 
	{
		super.connectionOpen(ctx, e);
	}
}
