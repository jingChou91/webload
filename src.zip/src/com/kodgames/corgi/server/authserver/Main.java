/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.authserver;

import java.net.InetSocketAddress;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sun.misc.Signal;

import com.kodgames.corgi.core.ConnectionHandler;
import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.core.DefaultController;
import com.kodgames.corgi.gameconfiguration.AppPath;
import com.kodgames.corgi.gameconfiguration.LogBackConfigLoader;
import com.kodgames.corgi.gameconfiguration.ShutdownReqHandler;
import com.kodgames.corgi.server.SimpleConnectionHandler;
import com.kodgames.corgi.server.common.CommonServerConfig;
import com.kodgames.corgi.server.common.ManagerAddressConfigMgr;
import com.kodgames.corgi.server.common.StreamLoaderDispatchMgr;
import com.kodgames.corgi.server.manageserver.ManageClientHandler;
import com.kodgames.corgi.server.manageserver.SvnVersionManager;
import com.kodgames.gamedata.appurl.AppURLConfigMgr;
import com.kodgames.gamedata.area.AreaConfigMgr;
import com.kodgames.gamedata.baseinfo.BaseInfoConfigMgr;
import com.kodgames.gamedata.clientmanifest.ClientManifestConfigMgr;
import com.kodgames.gamedata.commonconfig.CommonConfigMgr;

/**
 * 
 * @author mrui
 */
public class Main
{
	private static final Logger logger = LoggerFactory.getLogger(Main.class);

	public static void main(String[] args) throws Exception
	{
		LogBackConfigLoader.load();
		
		//svn version
		String version  = new SvnVersionManager().loadVersion();
		logger.warn("AuthServer Svn version  :"+   (null == version ? 0 : version));
		
		ManagerAddressConfigMgr.getInstance().load();
		registerStream();

		String serverName = "AuthServer";
		if (0 == args.length)
		{

		}
		else
		{
			serverName = args[0];
		}

		CommonServerConfig.getInstance().setServerName(serverName);
		logger.warn("Server Name: {}", CommonServerConfig.getInstance().getServerName());

		Controller controller = new DefaultController();
		AuthClient authClient = new AuthClient();
		ServerDataAS.authClient = authClient;
		ConnectionHandler connectionHandler = new SimpleConnectionHandler();
		authClient.initialize(controller, ServerDataAS.transmitter, connectionHandler, CommonServerConfig.OPT_serverThreadNum);

		AuthServer authServer = new AuthServer();
		ServerDataAS.authServer = authServer;
		ManageClientHandler loginResHandler = new AuthServerManageClientHandler();
		ConnectionHandler serverConnectionHandler = new AuthServerConnectionHandler(loginResHandler);
		authServer.initialize(controller, ServerDataAS.transmitter, serverConnectionHandler, loginResHandler, CommonServerConfig.OPT_serverThreadNum);

		logger.warn("authserver connecting manager server  ip={} port={}", ManagerAddressConfigMgr.getInstance()
			.getManagerServerIP(), ManagerAddressConfigMgr.getInstance().getManagerServerPort());
		authServer.connectTo(new InetSocketAddress(ManagerAddressConfigMgr.getInstance().getManagerServerIP(),
			ManagerAddressConfigMgr.getInstance().getManagerServerPort()));
		
		Signal.handle(new Signal("TERM"), new ShutdownReqHandler());
	}

	public static void registerStream()
	{
		StreamLoaderDispatchMgr instance = StreamLoaderDispatchMgr.getInstance();
		instance.register(AppPath.file_AreaConfig, AreaConfigMgr.getInstance());
		instance.register(AppPath.file_common, CommonConfigMgr.getInstance());
		instance.register(AppPath.file_BaseInfo, BaseInfoConfigMgr.getInstance());
		instance.register(AppPath.file_AppURL, AppURLConfigMgr.getInstance());

		instance.register(AppPath.file_ClientManifest_Android, ClientManifestConfigMgr.getInstance(ClientManifestConfigMgr.andriod));
		instance.register(AppPath.file_ClientManifest_iPhone, ClientManifestConfigMgr.getInstance(ClientManifestConfigMgr.iphone));
	}
}
