package com.kodgames.corgi.server.authserver.local;

import java.net.SocketAddress;

import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.AC_ResetPasswordRes;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.CA_ResetPasswordReq;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.CA_ResetPasswordReq.LocalResetPasswordReq;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.authserver.ServerDataAS;
import com.kodgames.corgi.server.common.CheckEmail;
import com.kodgames.gamedata.account.Account_Local;
import com.kodgames.gamedata.commonconfig.CommonConfigMgr;

public class CA_ResetPasswordReqHandler extends MessageHandler {

	private static final Logger logger = LoggerFactory.getLogger(CA_ResetPasswordReqHandler.class);

	@Override
	public HandlerAction handleMessage(Channel channel, SocketAddress remoteAddress, Protocol message) {
		
		CA_ResetPasswordReq ca_request = (CA_ResetPasswordReq) message.getProtoBufMessage();
		AC_ResetPasswordRes.Builder resetPasswordBuilder = AC_ResetPasswordRes.newBuilder();

		LocalResetPasswordReq request = ca_request.getLocalResetPasswordReq();
		int result = ClientProtocols.E_AUTH_RESET_PASSWORD_SUCCESS;

		do {
			logger.debug("recv CA_ResetPasswordReq, Email = {}", request.getEmail());

			// Check email length
			if (false == CheckEmail.emailLength(request.getEmail(), CommonConfigMgr.getInstance().getCfg().getAccountMax())) {
				result = ClientProtocols.E_AUTH_RESET_PASSWORD_FAILED_EMAIL_LENGTH_NOT_VALID;
				break;
			}

			// Insure email is Format
			if (false == CheckEmail.emailFormat(request.getEmail())) {
				result = ClientProtocols.E_AUTH_RESET_PASSWORD_FAILED_EMAIL_FORMAT_NOT_VALID;
				break;
			}

			if (false == CheckEmail.passwordFormat(request.getNewPassword())) {
				result = ClientProtocols.E_AUTH_RESET_PASSWORD_FAILED_PASSWORD_NOT_VALID;
				break;
			}

			if (result == ClientProtocols.E_AUTH_RESET_PASSWORD_SUCCESS) {
				result = Account_Local.resetPassword(request.getEmail(), request.getOldPassword(), request.getNewPassword());
			}
		}
		while (false);

		resetPasswordBuilder.setCallback(ca_request.getCallback());
		resetPasswordBuilder.setResult(result);
		ServerDataAS.transmitter.sendAndClose(channel, ClientProtocols.P_AUTH_AC_RESET_PASSWORD_RES, resetPasswordBuilder.build());
		return HandlerAction.TERMINAL;
	}
}
