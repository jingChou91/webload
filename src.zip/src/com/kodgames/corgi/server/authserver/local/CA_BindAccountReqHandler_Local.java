package com.kodgames.corgi.server.authserver.local;

import java.net.SocketAddress;

import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.MessageHandler.HandlerAction;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.AC_BindAccountRes;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.CA_BindAccountReq;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.authserver.ServerDataAS;
import com.kodgames.corgi.server.common.CheckEmail;
import com.kodgames.gamedata.account.Account_Local;
import com.kodgames.gamedata.commonconfig.CommonConfigMgr;

public class CA_BindAccountReqHandler_Local{

	private static final Logger logger = LoggerFactory.getLogger(CA_BindAccountReqHandler_Local.class);

	public static HandlerAction handleMessage(Channel channel, SocketAddress remoteAddress, Protocol message) {

		CA_BindAccountReq bindAccountRequest = (CA_BindAccountReq) message.getProtoBufMessage();
		AC_BindAccountRes.Builder bindAccountBuilder = AC_BindAccountRes.newBuilder();
		bindAccountBuilder.setCallback(bindAccountRequest.getCallback());
		
		CA_BindAccountReq.LocalBindAccountReq request = bindAccountRequest.getLocalBindAccountReq();
		
		logger.debug("recv CA_BindAccountReq, Email = {} ,password = {}", request.getEmail(), request.getPassword());
		int result = ClientProtocols.E_AUTH_BIND_ACCOUNT_SUCCESS;

		do {
			
			if (request == null) {
				result = ClientProtocols.E_AUTH_BIND_ACCOUNT_FAILED_BAD_PARAM;
				break;
			}
			
			// Check email length
			if (false == CheckEmail.emailLength(request.getEmail(), CommonConfigMgr.getInstance().getCfg().getAccountMax())) {
				logger.warn("E_AUTH_BIND_ACCOUNT_FAILED_EMAIL_LENGTH_NOT_VALID, email = {}",
						request.getEmail());
				result = ClientProtocols.E_AUTH_BIND_ACCOUNT_FAILED_EMAIL_LENGTH_NOT_VALID;
				break;
			}

			// Insure email is Format
			if (false == CheckEmail.emailFormat(request.getEmail())) {
				logger.warn("E_AUTH_BIND_ACCOUNT_FAILED_EMAIL_FORMAT_NOT_VALID, email = {}",
						request.getEmail());
				result = ClientProtocols.E_AUTH_BIND_ACCOUNT_FAILED_EMAIL_FORMAT_NOT_VALID;
				break;
			}
			
			if(false == CheckEmail.passwordFormat(request.getPassword()))
			{
				result = ClientProtocols.E_AUTH_BIND_ACCOUNT_FAILED_PASSWORD_NOT_VALID;
				break;
			}

			// Insure UDID is NOT NULL
			if (request.getDeviceInfo()==null || request.getDeviceInfo().getUDID()==null || request.getDeviceInfo().getUDID().length() == 0) {
				logger.warn("E_AUTH_BIND_ACCOUNT_FAILED_UDID_IS_NULL");
				result = ClientProtocols.E_AUTH_BIND_ACCOUNT_FAILED_UDID_IS_NULL;
				break;
			}

			// 绑定账号 
			result = Account_Local.bindAccount(request.getEmail(), request.getPassword(), request.getDeviceInfo().getUDID());

		} while (false);

		bindAccountBuilder.setResult(result);
		ServerDataAS.transmitter.sendAndClose(channel,
				ClientProtocols.P_AUTH_AC_BIND_ACCOUNT_RES,bindAccountBuilder.build());
		return HandlerAction.TERMINAL;
	}
}
