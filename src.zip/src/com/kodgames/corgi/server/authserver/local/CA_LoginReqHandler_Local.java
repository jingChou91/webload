/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.authserver.local;

import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon._ServerAreaStatus;

import com.kodgames.corgi.core.MessageHandler.HandlerAction;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.AC_LoginRes;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.CA_LoginReq;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.authserver.ServerDataAS;
import com.kodgames.corgi.server.authserver.ServerDataAS.TokenSession;
import com.kodgames.corgi.server.common.AccountType;
import com.kodgames.corgi.server.common.CheckEmail;
import com.kodgames.corgi.server.dbclient.KodLog;
import com.kodgames.corgi.server.manageserver.ServerInfo;
import com.kodgames.gamedata.account.AccountActivate;
import com.kodgames.gamedata.account.Account_Local;
import com.kodgames.gamedata.area.Area;
import com.kodgames.gamedata.area.AreaConfigMgr;
import com.kodgames.gamedata.baseinfo.BaseInfoConfigMgr;
import com.kodgames.gamedata.commonconfig.CommonConfigMgr;

/**
 * 
 * @author Elvin
 */
public class CA_LoginReqHandler_Local {

	private static final Logger logger = LoggerFactory.getLogger(CA_LoginReqHandler_Local.class);
	
	public static HandlerAction handleMessage(Channel channel, SocketAddress remoteAddress, Protocol message) {


		CA_LoginReq request = (CA_LoginReq) message.getProtoBufMessage();
		AC_LoginRes.Builder ac_LoginResBuilder = AC_LoginRes.newBuilder();
		ac_LoginResBuilder.setCallback(request.getCallback());
		ac_LoginResBuilder.setIsShowActivityInterface(BaseInfoConfigMgr.getInstance().getCfg().isOpenWarmUpActivity());

		CA_LoginReq.LocalLoginReq myReq = request.getLocalLoginReq(); // local
		int result = ClientProtocols.E_AUTH_LOGIN_SUCCESS;
		HashMap<Integer, Integer> areaList = new HashMap<Integer, Integer>();

		do {

			if (myReq == null) 
			{
				result = ClientProtocols.E_AUTH_LOGIN_FAILED_BAD_PARAM;
				break;
			}

			logger.debug("recv CA_LoginReq, Email = {}", myReq.getEmail());

			// Check randSeed length
			if (36 < myReq.getRandomSeed().length()) {
				logger.warn("RANDOM_SEED_LENGTH_INVALID :{}", myReq.getRandomSeed());
				result = ClientProtocols.E_AUTH_LOGIN_FAILED_RANDOM_SEED_LENGTH_INVALID;
				break;
			}

			// Check email length
			if (false == CheckEmail.emailLength(myReq.getEmail(), CommonConfigMgr.getInstance().getCfg().getAccountMax())) {
				logger.warn("EMAIL_LENGTH_NOT_VALID :{}", myReq.getEmail());
				result = ClientProtocols.E_AUTH_LOGIN_FAILED_EMAIL_LENGTH_NOT_VALID;
				break;
			}

			// Insure email is Format
			if (false == CheckEmail.emailFormat(myReq.getEmail())) {
				logger.warn("EMAIL_FORMAT_NOT_VALID :{}", myReq.getEmail());
				result = ClientProtocols.E_AUTH_LOGIN_FAILED_EMAIL_FORMAT_NOT_VALID;
				break;
			}

			// Insure password is not null
			if (myReq.hasPassword() == false) {
				logger.warn("PASSWORD_IS_NULL");
				result = ClientProtocols.E_AUTH_LOGIN_FAILED_PASSWORD_IS_NULL;
				break;
			}

			if (false == CheckEmail.passwordFormat(myReq.getPassword())) {
				result = ClientProtocols.E_AUTH_LOGIN_FAILED_PASSWORD_NOT_VALID;
				break;
			}

			// Insure UDID is NOT NULL
			if (myReq.getDeviceInfo() == null || myReq.getDeviceInfo().getUDID() == null || myReq.getDeviceInfo().getUDID().length() == 0) {
				result = ClientProtocols.E_AUTH_LOGIN_FAILED_UDID_IS_NULL;
				break;
			}

			Account_Local.login(myReq.getEmail(), myReq.getPassword(), ac_LoginResBuilder, areaList);

			if (ac_LoginResBuilder.getResult() != ClientProtocols.E_AUTH_LOGIN_SUCCESS) 
			{
				result = ac_LoginResBuilder.getResult();
				break;
			}
		}
		while (false);

		if (result == ClientProtocols.E_AUTH_LOGIN_SUCCESS) {
			ArrayList<Area> areas = AreaConfigMgr.getInstance().getSpecifiedAreas(myReq.getChannelID());
			for (int i = areas.size() - 1; i >= 0; --i)
			{
				Area area = areas.get(i);
				if (area.getStatus() == _ServerAreaStatus.Unknown)
				{
					continue;
				}
				
				int areaId = area.getAreaId();
				CommonProtocols.Area.Builder areaBuild = CommonProtocols.Area.newBuilder();
				areaBuild.setAreaID(areaId);
				areaBuild.setShowAreaID(area.getClientShowAreaId());
				areaBuild.setAreaAvatarNumber(0);
				areaBuild.setName(area.getAreaName());
				areaBuild.setStatus(area.getStatus());

				// 这里用AccountID% this area interface Count
				List<ServerInfo> serverInfos = ServerDataAS.transmitter.getGameServers(areaId);
				if (null == serverInfos)
				{
					areaBuild.setInterfaceServerIP("");
					areaBuild.setInterfaceServerPort(0);
					ac_LoginResBuilder.addAreas(areaBuild);
					continue;
				}

				int index = ac_LoginResBuilder.getAccountID() % serverInfos.size();
				ServerInfo serverInfo = serverInfos.get(index);
				if (null == serverInfo)
				{
					areaBuild.setInterfaceServerIP("");
					areaBuild.setInterfaceServerPort(0);
					ac_LoginResBuilder.addAreas(areaBuild);
					continue;
				}
				areaBuild.setInterfaceServerIP(serverInfo.getIpForClient());
				areaBuild.setInterfaceServerPort(serverInfo.getPortForClient());
				areaBuild.setKunLunAreaId(0);

				if (areaList.containsKey(areaId))
				{
					if (areaList.get(areaId) == 0)
					{
						continue;
					}
					else
					{
						areaBuild.setAreaAvatarNumber(1);
					}
				}

				ac_LoginResBuilder.addAreas(areaBuild);
			}
			String uuid = UUID.randomUUID().toString();
			String token = myReq.getRandomSeed() + uuid;
			int account_idx = ac_LoginResBuilder.getAccountID();

			// send uuid token to client
			ac_LoginResBuilder.setToken(uuid);

			// save token
			TokenSession tokensession = new TokenSession(token, false, myReq.getEmail(), (InetSocketAddress) remoteAddress, myReq.getDeviceInfo(), channel.getRemoteAddress().toString(),"", myReq.getVersion(),"",0);
			ServerDataAS.tokensessions.put(account_idx, tokensession);

			// KODLOG
			{
				int iAccountId = ac_LoginResBuilder.getAccountID();
				String vClientIp = channel.getRemoteAddress().toString();
				KodLog.account_login(KodLog.getDatetime(System.currentTimeMillis()), iAccountId, myReq.getChannelID(), vClientIp, myReq.getDeviceInfo().getUDID(), myReq.getDeviceInfo().getOSType(), myReq.getDeviceInfo().getOSVersion(), myReq.getDeviceInfo().getDeviceName(), myReq.getDeviceInfo().getDeviceType(),AccountType.LOCAL_ACCOUNT);
			}
		}
		
		int iAccountId = ac_LoginResBuilder.getAccountID();
		if(ac_LoginResBuilder.getIsShowActivityInterface() && AccountActivate.hasActivated(iAccountId))
		{
			ac_LoginResBuilder.setIsShowActivityInterface(false);
		}

		ac_LoginResBuilder.setResult(result);
		ServerDataAS.transmitter.sendAndClose(channel, ClientProtocols.P_AUTH_AC_LOGIN_RES, ac_LoginResBuilder.build());
		return HandlerAction.TERMINAL;
	}
}
