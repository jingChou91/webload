/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kodgames.corgi.server.authserver;

import java.net.InetSocketAddress;

import com.googlecode.concurrentlinkedhashmap.ConcurrentLinkedHashMap;
import com.kodgames.corgi.protocol.CommonProtocols.DeviceInfo;
import com.kodgames.corgi.server.common.BaseServerData;

/**
 *
 * @author marui
 */
public class ServerDataAS extends BaseServerData
{
	public static class TokenSession
	{
		private String token;
		private long createTime;
		private boolean isQuickLogin;
		private InetSocketAddress clientAddress;
		private long loginTime;//登陆时间
		private DeviceInfo deviceInfo;//设备信息
		private String ipMessage;
		private String channelUniqueId;
		private String channelUserName;
		private String clientVersion;
		private String marketChannelId;//推广渠道Id 畅游使用
		private int channnelId;        //渠道ID
		
		public TokenSession(String token,boolean isQuickLogin, String channelUserName,InetSocketAddress clientAddress,DeviceInfo deviceInfo, String ipMessage,String channelUniqueId,String clientVersion,String marketChannelId, int channelId)
		{
			this.token = token;
			this.createTime = System.currentTimeMillis();
			this.isQuickLogin = isQuickLogin;
			this.channelUserName = channelUserName;
			this.clientAddress = clientAddress;
			this.deviceInfo = deviceInfo;
			this.loginTime = System.currentTimeMillis();
			this.ipMessage = ipMessage;
			this.channelUniqueId = channelUniqueId;
			this.clientVersion = clientVersion;
			this.marketChannelId = marketChannelId;
			this.channnelId = channelId;
		}
		
		public String getMarketChannelId()
		{
			return marketChannelId;
		}

		public int getChannnelId()
		{
			return channnelId;
		}

		public String getIpMessage()
		{
			return ipMessage;
		}
		
		public String getChannelUniqueId()
		{
			return channelUniqueId;
		}

		public void setChannelUniqueId(String channelUniqueId)
		{
			this.channelUniqueId = channelUniqueId;
		}
		
		public long getLoginTime() 
		{
			return loginTime;
		}

		public DeviceInfo getDeviceInfo()
		{
			return deviceInfo;
		}
		
		public InetSocketAddress getClientAddress()
		{
			return clientAddress;
		}
		public long getCreateTime()
		{
			return createTime;
		}

		public String getToken()
		{
			return token;
		}
		public boolean getIsQuickLogin()
		{
			return isQuickLogin;
		}

		public String getChannelUserName() 
		{
			return channelUserName;
		}

		public void setChannelUserName(String channelUserName)
		{
			this.channelUserName = channelUserName;
		}

		public String getClientVersion()
		{
			return clientVersion;
		}
		
	}
	
	public static AuthServer authServer = null;
	public static AuthClient authClient = null;
    public static ConcurrentLinkedHashMap<Integer,TokenSession> tokensessions = new ConcurrentLinkedHashMap.Builder<Integer,TokenSession>().maximumWeightedCapacity(200000).build();
}
