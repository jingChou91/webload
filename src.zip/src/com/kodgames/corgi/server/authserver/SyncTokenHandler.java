package com.kodgames.corgi.server.authserver;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.core.ServerNode;
import com.kodgames.corgi.protocol.AuthProtocolsForServer.AI_QueryTokenRes;
import com.kodgames.corgi.protocol.AuthProtocolsForServer.IA_QueryTokenReq;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.gamedata.account.Account;

public class SyncTokenHandler extends MessageHandler {

	/**
	 * @param ZHD
	 */
	private static final Logger logger = LoggerFactory.getLogger(SyncTokenHandler.class);
	
	@Override
	public HandlerAction handleServerMessage(ServerNode sender, Protocol message) {

		IA_QueryTokenReq request = (IA_QueryTokenReq) message.getProtoBufMessage();
		AI_QueryTokenRes.Builder builder = AI_QueryTokenRes.newBuilder();		
		Protocol syncTokenResProtocol = new Protocol(ServerProtocols.P_AUTH_SERVER_QUERY_TOKEN_RES);
		builder.setCallback(request.getCallback());
		builder.setPlayerId(request.getPlayerId());
		builder.setSeqId(request.getSeqId());
		logger.info("recv QueryTokenReq, playerId = {}", request.getPlayerId());
		try
		{
			String token = null;
			int accountId = request.getPlayerId();
			
			ServerDataAS.TokenSession session = ServerDataAS.tokensessions.get(accountId);
			
			if (session == null) 
			{
				logger.error("Token expired. PlayerId = {}", accountId);
				builder.setResult(ClientProtocols.E_INTERFACE_AUTH_TOKEN_FAILED_EXPIRED);
			} 
			else 
			{
				token = session.getToken();
				if (token == null || token.equals("")) 
				{
					logger.error("Token expired. PlayerId = {}", accountId);
					builder.setResult(ClientProtocols.E_INTERFACE_AUTH_TOKEN_FAILED_EXPIRED);
				}
				else
				{
					updateLastAreaId(request.getPlayerId(),request.getAreaId());
					
					builder.setToken(session.getToken());
					builder.setPlayerId(request.getPlayerId());
					builder.setResult(ClientProtocols.E_INTERFACE_AUTH_TOKEN_SUCCESS);
					builder.setChannelUserName(session.getChannelUserName());
					builder.setDeviceInfo(session.getDeviceInfo());
					builder.setLoginTime(session.getLoginTime());
					builder.setIpMessage(session.getIpMessage());
                    builder.setChannelUniqueId(session.getChannelUniqueId());
                    builder.setClientVersion(session.getClientVersion());
                    builder.setChannelId(session.getChannnelId());
                    if(session.getMarketChannelId() != null)
                    {
                    	builder.setMarketChannelId(session.getMarketChannelId());
                    }

					if(session.getIsQuickLogin() == true)
					{
						logger.info("QuickLogin query Token!");
					}
					else 
					{
						logger.info("Login query token!");
					}

					if (token.equals(request.getToken())) 
					{
						//AuhtServer判断Token值相等时，会查询account_area，如果没有记录，会插入一条记录
						int result = Account.syncToken(request.getPlayerId(),request.getAreaId());
						builder.setResult(result);
					}
				}
			}			
		}
		catch(Exception ex)
		{
			logger.error(ExceptionUtils.getStackTrace(ex));
			builder.setResult(ClientProtocols.E_SERVER_PROC_ERROR);			
		}
		
		syncTokenResProtocol.setProtoBufMessage(builder.build());
		ServerDataAS.transmitter.sendToServer(sender, syncTokenResProtocol);
		return HandlerAction.TERMINAL;
	}
	
	public static void updateLastAreaId(int accountId,int areaId)
	{
		String sqlCommand = "update account set lastarea_id="+areaId+" where account_idx="+accountId;
		ServerDataAS.dbCluster.getAccountDBClient().executeAsynchronousUpdate(accountId, sqlCommand);
	}
}
