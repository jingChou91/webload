/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kodgames.corgi.server.authserver;

import com.kodgames.corgi.gameconfiguration.ShutdownReqHandler;
import com.kodgames.corgi.protocol.AuthProtocolsForServer;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.corgi.protocol.ServersProtocolsForServer;
import com.kodgames.corgi.server.SimpleServer;
import com.kodgames.corgi.server.common.ServerUtil;

/**
 * 
 * @author marui
 */
public class AuthServer extends SimpleServer 
{
	private SyncTokenHandler syncTokenHandler = new SyncTokenHandler();
	private ShutdownReqHandler shutdownReqHandler = new ShutdownReqHandler();

	@Override
	public void registerProtoBufType() 
	{
		super.registerProtoBufType();
		this.controller.registerMessageLite(ServerProtocols.P_AUTH_SERVER_QUERY_TOKEN_REQ, AuthProtocolsForServer.IA_QueryTokenReq.getDefaultInstance());
		this.controller.registerMessageLite(ServerProtocols.P_ALL_SHUTDOWN_REQ, ServersProtocolsForServer.ShutdownReq.getDefaultInstance());
	}

	@Override
	public void registerMessageHandler() 
	{
		super.registerMessageHandler();
		this.controller.addHandler(ServerProtocols.P_AUTH_SERVER_QUERY_TOKEN_REQ, ServerUtil.getFacilityMessageHandlerFactory(syncTokenHandler));
		this.controller.addHandler(ServerProtocols.P_ALL_SHUTDOWN_REQ, ServerUtil.getFacilityMessageHandlerFactory(shutdownReqHandler));
	}
}
