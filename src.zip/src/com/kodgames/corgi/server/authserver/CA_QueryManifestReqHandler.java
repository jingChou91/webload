/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.authserver;

import java.net.SocketAddress;

import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.protocol.AuthProtocolsForClient;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.gamedata.appurl.AppURLConfigMgr;
import com.kodgames.gamedata.baseinfo.BaseInfoConfigMgr;
import com.kodgames.gamedata.clientmanifest.ClientManifestConfigMgr;
import com.kodgames.gamedata.commonconfig.CommonConfigMgr;

/**
 * 
 * @author Elvin
 */
public class CA_QueryManifestReqHandler extends MessageHandler 
{
	private static final Logger logger = LoggerFactory.getLogger(CA_QueryManifestReqHandler.class);

	@Override
	public HandlerAction handleMessage(Channel channel, SocketAddress remoteAddress, Protocol message)
	{
		handleMessage_Normal(channel,remoteAddress,message);
		return HandlerAction.TERMINAL;
	}

	public static HandlerAction handleMessage_Normal(Channel channel, SocketAddress remoteAddress, Protocol message) {
		AuthProtocolsForClient.CA_QueryManifestReq request = (AuthProtocolsForClient.CA_QueryManifestReq) message.getProtoBufMessage();

		AuthProtocolsForClient.AC_QueryManifestRes.Builder ac_QueryManifestResBuilder = AuthProtocolsForClient.AC_QueryManifestRes.newBuilder();
		ac_QueryManifestResBuilder.setCallback(request.getCallback());
		ac_QueryManifestResBuilder.setTimeZone(TimeZoneData.getTimeZone());
		ac_QueryManifestResBuilder.setIsForcedUpdate(true);
		ac_QueryManifestResBuilder.setIsReconnectOpen(BaseInfoConfigMgr.getInstance().getCfg().isReconnect());

		logger.info("recv CA_QueryManifestReq, channnelId = {}, subId= {}", request.getChannelID(),request.getSubChannelID());

		try 
		{
			CommonProtocols.DeviceInfo deviceInfo = request.getDeviceInfo();
			if (deviceInfo != null)
			{

				int deviceType = deviceInfo.getDeviceType();

				// Client program update
				int appVersion = getAppVersion(deviceType, request.getChannelID(), request.getSubChannelID());
				ac_QueryManifestResBuilder.setAppVersion(appVersion);

				ac_QueryManifestResBuilder.setAppUpdateDesc(CommonConfigMgr.getInstance().getValue("AppUpdateDesc"));

				ac_QueryManifestResBuilder.setGameConfigName(getGameConfigName(deviceType));
				ac_QueryManifestResBuilder.setGameConfigSize(getGameConfigSize(deviceType));
				ac_QueryManifestResBuilder.setGameConfigUncompressedSize(getGameConfigUncompressedSize(deviceType));

				ac_QueryManifestResBuilder.setAppDownloadURL(getAppDownloadURL(deviceType, request.getChannelID(), request.getSubChannelID()));
				ac_QueryManifestResBuilder.setBaseResourceUpdateURL(getBaseResourceUpdateURL(deviceType));

				ac_QueryManifestResBuilder.setResult(ClientProtocols.E_AUTH_QUERY_MANIFEST_SUCCESS);
			}

		}
		catch (Exception e)
		{
			ac_QueryManifestResBuilder.setResult(ClientProtocols.E_SERVER_PROC_ERROR);
		}
		ServerDataAS.transmitter.sendAndClose(channel, ClientProtocols.P_AUTH_AC_QUERY_MANIFEST_RES, ac_QueryManifestResBuilder.build());
		return HandlerAction.TERMINAL;
	}

	// GameConfigName
	private static String getGameConfigName(int device)
	{
		String gameConfigName = "";
		switch (device)
		{
		case ClientServerCommon._DeviceType.iPhone:
			gameConfigName = ClientManifestConfigMgr.getInstance(ClientManifestConfigMgr.iphone).getClientManifest().getGameConfigName();
			break;

		default:
			gameConfigName = ClientManifestConfigMgr.getInstance(ClientManifestConfigMgr.andriod).getClientManifest().getGameConfigName();
			break;
		}

		return gameConfigName;
	}

	private static int getAppVersion(int deviceType, int channelID, int subChannelID)
	{
		int version;
		switch (deviceType)
		{
		case ClientServerCommon._DeviceType.iPhone:
			version = AppURLConfigMgr.getInstance().getCfg(ClientManifestConfigMgr.iphone).getChannelAppVersion(channelID, subChannelID);
			break;
		case ClientServerCommon._DeviceType.Android:
			version = AppURLConfigMgr.getInstance().getCfg(ClientManifestConfigMgr.andriod).getChannelAppVersion(channelID, subChannelID);
			break;
		default:
			version = 0;
			break;
		}
		return version;
	}

	private static int getGameConfigSize(int deviceType)
	{
		int gameConfigSize;
		switch (deviceType)
		{
		case ClientServerCommon._DeviceType.iPhone:
			gameConfigSize = ClientManifestConfigMgr.getInstance(ClientManifestConfigMgr.iphone).getClientManifest().getGameConfigSize();
			break;

		default:
			gameConfigSize = ClientManifestConfigMgr.getInstance(ClientManifestConfigMgr.andriod).getClientManifest().getGameConfigSize();
			break;
		}
		return gameConfigSize;
	}

	private static int getGameConfigUncompressedSize(int deviceType)
	{
		int retSize;
		switch (deviceType)
		{
		case ClientServerCommon._DeviceType.iPhone:
			retSize = ClientManifestConfigMgr.getInstance(ClientManifestConfigMgr.iphone).getClientManifest().getGameConfigUncompressedSize();
			break;
			
		default:
			retSize = ClientManifestConfigMgr.getInstance(ClientManifestConfigMgr.andriod).getClientManifest().getGameConfigUncompressedSize();
			break;
		}
		return retSize;
	}

	// Game apps download URL
	private static String getAppDownloadURL(int deviceType, int channelID, int subChannelID)
	{
		String appDownloadURL = "";
		switch (deviceType)
		{
		case ClientServerCommon._DeviceType.iPhone:
			appDownloadURL = AppURLConfigMgr.getInstance().getCfg(ClientManifestConfigMgr.iphone).getUrl(channelID, subChannelID);
			break;

		case ClientServerCommon._DeviceType.Android:
			appDownloadURL = AppURLConfigMgr.getInstance().getCfg(ClientManifestConfigMgr.andriod).getUrl(channelID, subChannelID);
			break;

		default:
			appDownloadURL = "";
			break;
		}

		return appDownloadURL;
	}

	private static String getBaseResourceUpdateURL(int deviceType)
	{
		String baseResourceUpdateURL;
		switch (deviceType)
		{
		case ClientServerCommon._DeviceType.iPhone:
			baseResourceUpdateURL = AppURLConfigMgr.getInstance().getCfg(ClientManifestConfigMgr.iphone).getConfigDownloadURL();
			break;

		case ClientServerCommon._DeviceType.Android:
			baseResourceUpdateURL = AppURLConfigMgr.getInstance().getCfg(ClientManifestConfigMgr.andriod).getConfigDownloadURL();
			break;

		default:
			baseResourceUpdateURL = "";
			break;
		}

		return baseResourceUpdateURL;
	}
}
