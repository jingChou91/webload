/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.authserver;

import java.net.SocketAddress;

import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.CA_QuickLoginReq;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.authserver.local.CA_QuickLoginReqHandler_Local;

/**
 * 
 * @author Elvin
 */
public class CA_QuickLoginReqHandler extends MessageHandler {

	private static final Logger logger = LoggerFactory.getLogger(CA_QuickLoginReqHandler.class);

	@Override
	public HandlerAction handleMessage(Channel channel, SocketAddress remoteAddress, Protocol message) {
		CA_QuickLoginReq request = (CA_QuickLoginReq) message.getProtoBufMessage();
		if(request.hasLocalQuickLoginReq())
		{
			return CA_QuickLoginReqHandler_Local.handleMessage(channel, remoteAddress, message);
		}
		else
		{
			logger.warn("recv CA_QuickLoginReq, unKnowPlatform");
			return HandlerAction.TERMINAL;
		}
	}
}