package com.kodgames.corgi.server.authserver.cmge;

public class SignInfo
{
	private String userId;
	private String timeStamp;

	public SignInfo()
	{
		super();
	}

	public SignInfo(String userId, String timeStamp)
	{
		super();
		this.userId = userId;
		this.timeStamp = timeStamp;
	}

	public String getUserId()
	{
		return userId;
	}

	public void setUserId(String userId)
	{
		this.userId = userId;
	}

	public String getTimeStamp()
	{
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp)
	{
		this.timeStamp = timeStamp;
	}

	@Override
	public String toString()
	{
		return "SignIno [userId=" + userId + ", timeStamp=" + timeStamp + "]";
	}
}
