package com.kodgames.corgi.server.authserver.cmge;

import java.net.SocketAddress;

import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.MessageHandler.HandlerAction;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.AC_LoginRes;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.CA_LoginReq;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.authserver.ServerDataAS;
import com.kodgames.gamedata.baseinfo.BaseInfoConfigMgr;

public class CA_LoginReqHandler_Cmge
{
	private static final Logger logger = LoggerFactory.getLogger(CA_LoginReqHandler_Cmge.class);

	public static HandlerAction handleMessage(Channel channel, SocketAddress remoteAddress, Protocol message)
	{

		CA_LoginReq request = (CA_LoginReq)message.getProtoBufMessage();
		AC_LoginRes.Builder ac_LoginResBuilder = AC_LoginRes.newBuilder();
		ac_LoginResBuilder.setCallback(request.getCallback());
		ac_LoginResBuilder.setIsShowActivityInterface(BaseInfoConfigMgr.getInstance().getCfg().isOpenWarmUpActivity());
		CA_LoginReq.CMGELoginReq myReq = request.getCmgeLoginReq();
		int result = ClientProtocols.E_AUTH_LOGIN_SUCCESS;

		do
		{
			if (myReq == null)
			{
				result = ClientProtocols.E_AUTH_LOGIN_FAILED_BAD_PARAM;
				break;
			}
			logger.info("recv CA_LoginReq, Email = {}", myReq.getEmail());

			if (myReq.getSign() == null || myReq.getSign().equals("") || myReq.getUserId() == null
				|| myReq.getUserId().equals("") || myReq.getTimeStamp() == null || myReq.getTimeStamp().equals(""))
			{
				logger.error("recv CA_LoginReq, E_AUTH_LOGIN_FAILED_BAD_PARAM");
				result = ClientProtocols.E_AUTH_LOGIN_FAILED_BAD_PARAM;
				break;
			}

			SignInfoMgr check =
				new SignInfoMgr(new CA_LoginReqHandler_CmgeHttp(new SignInfo(myReq.getUserId(), myReq.getTimeStamp()),
					channel, remoteAddress, message));
			check.chenckSign(myReq.getUserId(), myReq.getTimeStamp(), myReq.getSign());
		} while (false);

		if (result != ClientProtocols.E_AUTH_LOGIN_SUCCESS)
		{
			ac_LoginResBuilder.setResult(result);
			ServerDataAS.transmitter.sendAndClose(channel,
				ClientProtocols.P_AUTH_AC_LOGIN_RES,
				ac_LoginResBuilder.build());
		}

		return HandlerAction.TERMINAL;
	}
}
