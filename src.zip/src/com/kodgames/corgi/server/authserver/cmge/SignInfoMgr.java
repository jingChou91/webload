package com.kodgames.corgi.server.authserver.cmge;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.gameconfiguration.ChannelSdk;


public class SignInfoMgr
{
	private static final Logger logger = LoggerFactory.getLogger(SignInfoMgr.class);
	private CA_LoginReqHandler_CmgeHttp httpHandler;
	public enum SignResult
	{
		IS_SUCCESS, IS_FAILED
	};

	private SignResult checkRes = SignResult.IS_FAILED;

	public SignInfoMgr(CA_LoginReqHandler_CmgeHttp httpHandler)
	{
		this.httpHandler = httpHandler;
	}

	public void chenckSign(String userId, String timeStamp, String sign)
	{
		
		if(sign.equals(generateSign(userId, timeStamp, ChannelSdk.CMEG_APP_KEY)))
		{
			this.checkRes = SignResult.IS_SUCCESS;
		}
		else
		{
			this.checkRes = SignResult.IS_FAILED;
			logger.error("---sign is not valid");
		}

		logger.info("--- onReceive");
		httpHandler.onReceive(this.checkRes);
	}
	
	public String generateSign(String userId, String timeStamp, String appKey) {
		String needsignstr = userId + "&" + timeStamp + "&" + appKey;
		MessageDigest md5 = null;
		String sign = "";

		try {
			md5 = MessageDigest.getInstance("MD5");
			byte[] digest = md5.digest(needsignstr.getBytes("utf-8"));
			byte[] encode = Base64.encodeBase64(digest);
			sign = new String(encode, "utf-8"); // 签名字符串
		} catch (NoSuchAlgorithmException e) {
			logger.error("{}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
		} catch (UnsupportedEncodingException e) {
			logger.error("{}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
		}

		return sign;
	}
}
