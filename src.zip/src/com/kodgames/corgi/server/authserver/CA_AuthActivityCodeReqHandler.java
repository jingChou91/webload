package com.kodgames.corgi.server.authserver;

import java.net.SocketAddress;

import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.AC_AuthActivityCodeRes;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.CA_AuthActivityCodeReq;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.gamedata.account.AccountActivate;

public class CA_AuthActivityCodeReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CA_AuthActivityCodeReqHandler.class);

	@Override
	public HandlerAction handleMessage(Channel channel, SocketAddress remoteAddress, Protocol message)
	{
		CA_AuthActivityCodeReq request = (CA_AuthActivityCodeReq)message.getProtoBufMessage();
		AC_AuthActivityCodeRes.Builder builder = AC_AuthActivityCodeRes.newBuilder();
		builder.setCallback(request.getCallback());
		logger.debug("recv CA_AuthActivityCodeReq, account = {} ,token = {}", request.getAccountId(), request.getToken());
		int result = ClientProtocols.E_AUTH_ACTIVITY_CODE_SUCCESS;
		
		do
		{
			if (request == null)
			{
				result = ClientProtocols.E_AUTH_ACTIVITY_CODE_FAILED_BAD_PARAM;
				break;
			}

			if (request.getActivityCode() == null || request.getActivityCode().equals(""))
			{
				logger.warn("E_AUTH_ACTIVITY_CODE_FAILED_ACTIVITY_CODE_ERROR");
				result = ClientProtocols.E_AUTH_ACTIVITY_CODE_FAILED_ACTIVITY_CODE_ERROR;
				break;
			}

			if ((!ServerDataAS.tokensessions.containsKey(request.getAccountId()))
				|| (!ServerDataAS.tokensessions.get(request.getAccountId()).getToken().equals(request.getToken())))
			{
				logger.warn("E_AUTH_ACTIVITY_CODE_FAILED_ACCOUNT_NOT_EXIST");
				result = ClientProtocols.E_AUTH_ACTIVITY_CODE_FAILED_ACCOUNT_NOT_EXIST;
				break;
			}
			
			result = AccountActivate.activateAccount(request.getAccountId(), request.getActivityCode().toUpperCase());
		}
		while (false);

		builder.setResult(result);
		ServerDataAS.transmitter.sendAndClose(channel, ClientProtocols.P_AUTH_AC_AUTH_ACTIVITY_CODE_RES, builder.build());
		return HandlerAction.TERMINAL;
	}
}
