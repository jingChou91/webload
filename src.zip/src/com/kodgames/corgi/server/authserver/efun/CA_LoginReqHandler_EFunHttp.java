package com.kodgames.corgi.server.authserver.efun;

import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon._ServerAreaStatus;

import com.kodgames.corgi.protocol.AuthProtocolsForClient.AC_LoginRes;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.CA_LoginReq;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.authserver.ServerDataAS;
import com.kodgames.corgi.server.authserver.ServerDataAS.TokenSession;
import com.kodgames.corgi.server.authserver.efun.EFunSignInfoMgr.EFunSignResult;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.dbclient.KodLog;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.manageserver.ServerInfo;
import com.kodgames.gamedata.account.AccountActivate;
import com.kodgames.gamedata.account.Account_EFun;
import com.kodgames.gamedata.area.Area;
import com.kodgames.gamedata.area.AreaConfigMgr;
import com.kodgames.gamedata.area.AreaConfigMgr.WhiteIPRange;
import com.kodgames.gamedata.baseinfo.BaseInfoConfigMgr;

public class CA_LoginReqHandler_EFunHttp {
	private static final Logger logger = LoggerFactory.getLogger(CA_LoginReqHandler_EFunHttp.class);
	private EFunSignInfo info;
	private Channel channel;
	private SocketAddress remoteAddress;
	private Protocol message;
	private EFunSignInfoMgr.EFunSignResult signCheckRes = EFunSignResult.IS_FAILED;
	
	private AtomicBoolean retMsgSend = new AtomicBoolean(false);

	public CA_LoginReqHandler_EFunHttp(EFunSignInfo info, Channel channel,
			SocketAddress remoteAddress, Protocol message) {
		super();
		this.info = info;
		this.channel = channel;
		this.remoteAddress = remoteAddress;
		this.message = message;
	}
	
	public void onReceive(EFunSignInfoMgr.EFunSignResult signCheckRes){
		this.signCheckRes = signCheckRes;
		onReceive(info, channel, remoteAddress, message);
	}

	public void onReceive(EFunSignInfo info,Channel channel, SocketAddress remoteAddress , Protocol message){
		retMsgSend.set(true);
		CA_LoginReq request = (CA_LoginReq)message.getProtoBufMessage();
		AC_LoginRes.Builder ac_LoginResBuilder = AC_LoginRes.newBuilder();
		ac_LoginResBuilder.setCallback(request.getCallback());
		ac_LoginResBuilder.setIsShowActivityInterface(BaseInfoConfigMgr.getInstance().getCfg().isOpenWarmUpActivity());
		CA_LoginReq.EFUNLoginReq myReq = request.getEfunLoginReq();
		HashMap<Integer, Integer> areaList = new HashMap<>();
		
		int result = ClientProtocols.E_AUTH_LOGIN_SUCCESS;
		
		do {
			if(this.signCheckRes == EFunSignResult.IS_SUCCESS){
				
			}
			else{
				result = ClientProtocols.E_AUTH_LOGIN_FAILED_CHECK_KLSSO_FAILED;
				break;
			}
			
			AC_LoginRes.ChannelMessage.Builder channelMessage = AC_LoginRes.ChannelMessage.newBuilder();
			channelMessage.setChannelUniqueId(info.getUserId());
			ac_LoginResBuilder.setChannelMessage(channelMessage.build());
			
			Account_EFun.login(info.getUserId(), myReq.getEmail(), ac_LoginResBuilder, areaList, myReq.getDeviceInfo(), myReq.getChannelID());
			
			if(ac_LoginResBuilder.getResult() != ClientProtocols.E_AUTH_LOGIN_SUCCESS){
				result = ac_LoginResBuilder.getResult();
				break;
			}
		} while (false);
		
		if(result == ClientProtocols.E_AUTH_LOGIN_SUCCESS){
			String remoteIp = ServerUtil.getRemoteIP(remoteAddress.toString());
			
			logger.debug("remote Ip: {},whitlist : {}",remoteIp,AreaConfigMgr.getInstance().getWhiteIpRanges());
			
			long ip = ServerUtil.transferIPToLong(remoteIp);
			boolean isWhiteIP = false;
			for(WhiteIPRange whiteIPRange : AreaConfigMgr.getInstance().getWhiteIpRanges()){
				if(ip >= whiteIPRange.getStartIp() && ip <= whiteIPRange.getEndIp()){
					isWhiteIP = true;
					break;
				}
			}
			
			// 客户端是否显示激活码兑换框
				int iAccountId = ac_LoginResBuilder.getAccountID();
				if (ac_LoginResBuilder.getIsShowActivityInterface() && AccountActivate.hasActivated(iAccountId))
				{
					ac_LoginResBuilder.setIsShowActivityInterface(false);
				}

				ArrayList<Area> areas = AreaConfigMgr.getInstance().getSpecifiedAreas(myReq.getChannelID());
				for (int i = areas.size() - 1; i >= 0; --i)
				{
					Area area = areas.get(i);

					// 时间未到,看不到区
					if (!isWhiteIP && area.getAreaStartTime() > System.currentTimeMillis())
					{
						continue;
					}

					if (area.getStatus() == _ServerAreaStatus.Unknown)
					{
						continue;
					}

					int areaStatus = area.getStatus();
					if (area.getStatus() == _ServerAreaStatus.OnlyForWhiteIP && !isWhiteIP)
					{
						continue;
					}
					else if (area.getStatus() == _ServerAreaStatus.OnlyForWhiteIP && isWhiteIP)
					{
						areaStatus = _ServerAreaStatus.New;
					}

					int areaId = area.getAreaId();
					CommonProtocols.Area.Builder areaBuild = CommonProtocols.Area.newBuilder();
					areaBuild.setAreaID(areaId);
					areaBuild.setShowAreaID(area.getClientShowAreaId());
					areaBuild.setAreaAvatarNumber(0);
					areaBuild.setName(area.getAreaName());
					areaBuild.setStatus(areaStatus);

					// 这里用AccountID% this area interface Count
					List<ServerInfo> serverInfos = ServerDataAS.transmitter.getGameServers(areaId);
					if (null == serverInfos)
					{
						areaBuild.setInterfaceServerIP("");
						areaBuild.setInterfaceServerPort(0);
						ac_LoginResBuilder.addAreas(areaBuild);
						continue;
					}

					int index = ac_LoginResBuilder.getAccountID() % serverInfos.size();
					ServerInfo serverInfo = serverInfos.get(index);
					if (null == serverInfo)
					{
						areaBuild.setInterfaceServerIP("");
						areaBuild.setInterfaceServerPort(0);
						ac_LoginResBuilder.addAreas(areaBuild);
						continue;
					}
					areaBuild.setInterfaceServerIP(serverInfo.getIpForClient());
					areaBuild.setInterfaceServerPort(serverInfo.getPortForClient());
					areaBuild.setKunLunAreaId(0);

					if (areaList.containsKey(areaId))
					{
						if (areaList.get(areaId) == 0)
						{
							continue;
						}
						else
						{
							areaBuild.setAreaAvatarNumber(1);
						}
					}

					ac_LoginResBuilder.addAreas(areaBuild);
				}

				String uuid = UUID.randomUUID().toString();
				String token = myReq.getRandomSeed() + uuid;
				int account_idx = ac_LoginResBuilder.getAccountID();

				// send uuid token to client
				ac_LoginResBuilder.setToken(uuid);

				// save token
				TokenSession tokensession =
					new TokenSession(token, false, info.getUserId(), (InetSocketAddress)remoteAddress,
						myReq.getDeviceInfo(), channel.getRemoteAddress().toString(), info.getUserId(), myReq.getVersion(),
						myReq.getEmail(), myReq.getChannelID());
				ServerDataAS.tokensessions.put(account_idx, tokensession);

				// KODLOG
				{
					// int iAccountId = ac_LoginResBuilder.getAccountID();
					String vClientIp = channel.getRemoteAddress().toString();
					KodLog.account_login(KodLog.getDatetime(System.currentTimeMillis()),
						iAccountId,
						myReq.getChannelID(),
						vClientIp,
						myReq.getDeviceInfo().getUDID(),
						myReq.getDeviceInfo().getOSType(),
						myReq.getDeviceInfo().getOSVersion(),
						myReq.getDeviceInfo().getDeviceName(),
						myReq.getDeviceInfo().getDeviceType(),
						myReq.getChannelID());
				}

				// Verify Token result log
				{
					String udid = myReq.getDeviceInfo().getUDID();
					if ("".equals(udid) || "0".equals(udid) || "DefaultUDID".equals(udid))
					{
						udid = "null";
					}

					BPUtil.serverEvent(myReq.getVersion(), "", myReq.getEmail(), info.getUserId(), myReq.getDeviceInfo()
						.getUDID(), "TokenVerifyResult");
					BPUtil.serverEvent(myReq.getVersion(), "", myReq.getEmail(), info.getUserId(), myReq.getDeviceInfo()
						.getUDID(), "ServerList");
				}
			}

			ac_LoginResBuilder.setResult(result);
			ServerDataAS.transmitter.sendAndClose(channel, ClientProtocols.P_AUTH_AC_LOGIN_RES, ac_LoginResBuilder.build());
		}
		
}
