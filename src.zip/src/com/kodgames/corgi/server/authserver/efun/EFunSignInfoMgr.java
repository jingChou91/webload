package com.kodgames.corgi.server.authserver.efun;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.gameconfiguration.ChannelSdk;

public class EFunSignInfoMgr {
	private static final Logger logger = LoggerFactory
			.getLogger(EFunSignInfoMgr.class);
	private static final char HEX_DIGITS[] = { '0', '1', '2', '3', '4', '5',
			'6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
	private CA_LoginReqHandler_EFunHttp httpHandler;

	public enum EFunSignResult {
		IS_SUCCESS, IS_FAILED
	};

	private EFunSignResult checkRes = EFunSignResult.IS_FAILED;

	public EFunSignInfoMgr(CA_LoginReqHandler_EFunHttp httpHandler) {
		super();
		this.httpHandler = httpHandler;
	}

	public void checkSign(String userId, String timeStamp, String sign) {
		if (sign.equals(generateSign(ChannelSdk.EFUN_APP_KEY, userId, timeStamp))) {
			this.checkRes = EFunSignResult.IS_SUCCESS;
		} else {
			this.checkRes = EFunSignResult.IS_FAILED;
			logger.error("efun sign is not valid{}  {}", sign,
					generateSign(ChannelSdk.EFUN_APP_KEY, userId, timeStamp));
			logger.error("efun userId timeStamp {},{}", userId, timeStamp);
		}

		logger.info("check sign --> onReceive");
		httpHandler.onReceive(this.checkRes);
	}

	public String generateSign(String appkey, String userId, String timeStamp) {
		String needsignStr = appkey + userId + timeStamp;
		MessageDigest digest = null;
		try {
			digest = java.security.MessageDigest.getInstance("MD5");
			digest.update(needsignStr.getBytes());
		} catch (NoSuchAlgorithmException e) {
			logger.error("{}\n{}", e.getMessage(),
					ExceptionUtils.getStackTrace(e));
		}
		byte messageDigest[] = digest.digest();
		return toHexString(messageDigest);
	}

	private static String toHexString(byte[] b) {
		StringBuilder sb = new StringBuilder(b.length * 2);
		for (int i = 0; i < b.length; i++) {
			sb.append(HEX_DIGITS[(b[i] & 0xf0) >>> 4]);
			sb.append(HEX_DIGITS[b[i] & 0x0f]);
		}
		return sb.toString();
	}

}
