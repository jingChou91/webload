package com.kodgames.corgi.server.authserver.efun;

import java.net.SocketAddress;

import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.MessageHandler.HandlerAction;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.AC_LoginRes;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.CA_LoginReq;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.authserver.ServerDataAS;
import com.kodgames.gamedata.baseinfo.BaseInfoConfigMgr;

public class CA_LoginReqHandler_EFun {
	
	private static final Logger logger = LoggerFactory.getLogger(CA_LoginReqHandler_EFun.class);
	
	public static HandlerAction handlerMessage(Channel channel,SocketAddress remoteAddress, Protocol message){
		
		logger.info("recv CA_LoginReq...");
		CA_LoginReq request = (CA_LoginReq)message.getProtoBufMessage();
		AC_LoginRes.Builder ac_LoginResBuilder = AC_LoginRes.newBuilder();
		ac_LoginResBuilder.setCallback(request.getCallback());
		ac_LoginResBuilder.setIsShowActivityInterface(BaseInfoConfigMgr.getInstance().getCfg().isOpenWarmUpActivity());
		CA_LoginReq.EFUNLoginReq myReq = request.getEfunLoginReq();
		int result = ClientProtocols.E_AUTH_LOGIN_SUCCESS;
		
		do {
			if(myReq == null){
				result = ClientProtocols.E_AUTH_LOGIN_FAILED_BAD_PARAM;
				break;
			}
			logger.info("--- Email = {}",myReq.getEmail());
			
			if(myReq.getSign() == null || myReq.getSign().equals("") || myReq.getUserId() == null
					|| myReq.getUserId().equals("") || myReq.getTimeStamp() == null || myReq.getTimeStamp().equals("")){
				logger.error("recv CA_LoginReq,E_AUTH_LOGIN_FAILED_BAD_PARAM");
				result = ClientProtocols.E_AUTH_LOGIN_FAILED_BAD_PARAM;
				break;
			}
			
			EFunSignInfoMgr check = new EFunSignInfoMgr(new CA_LoginReqHandler_EFunHttp(new EFunSignInfo(myReq.getUserId(), myReq.getTimeStamp()), 
					channel, remoteAddress, message));
			check.checkSign(myReq.getUserId(), myReq.getTimeStamp(), myReq.getSign());
			
		} while (false);
		
		if (result != ClientProtocols.E_AUTH_LOGIN_SUCCESS) {
			ac_LoginResBuilder.setResult(result);
			ServerDataAS.transmitter.sendAndClose(channel, ClientProtocols.P_AUTH_AC_LOGIN_RES,
					ac_LoginResBuilder.build());
		}
		
		return HandlerAction.TERMINAL;
	}
}
