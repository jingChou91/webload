/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.authserver;

import com.kodgames.corgi.core.ConnectionHandler;
import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.core.Transmitter;
import com.kodgames.corgi.protocol.AuthProtocolsForClient;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.server.SimpleClient;
import com.kodgames.corgi.server.authserver.local.CA_ResetPasswordReqHandler;
import com.kodgames.corgi.server.common.ServerUtil;

/**
 *
 * @author Elvin
 */
public class AuthClient extends SimpleClient {
	private CA_LoginReqHandler ca_LoginReqHandler = new CA_LoginReqHandler();
	private CA_CreateAccountReqHandler ca_CreateAccountReqHandler = new CA_CreateAccountReqHandler();
	private CA_QueryManifestReqHandler ca_QueryManifestReqHandler = new CA_QueryManifestReqHandler();
	private CA_QuickLoginReqHandler ca_QuickLoginReqHandler = new CA_QuickLoginReqHandler();
    private CA_ResetPasswordReqHandler ca_ResetPasswordReqHandler = new CA_ResetPasswordReqHandler();
    private CA_BindAccountReqHandler ca_BindAccountReqHandler = new CA_BindAccountReqHandler();
    private CA_AuthActivityCodeReqHandler ca_AuthActivityCodeReqHandler = new CA_AuthActivityCodeReqHandler();
    
	public AuthClient() 
	{
		super();
	}
	
    @Override
    public void initialize(Controller controller, Transmitter transmitter, ConnectionHandler connectionHandler, int executeThreadNum )
    {
        super.initialize(controller, transmitter, connectionHandler, executeThreadNum);
    }
    
    
	@Override
    public void registerProtoBufType(){
		super.registerProtoBufType();
        this.controller.registerMessageLite(ClientProtocols.P_AUTH_CA_LOGIN_REQ, AuthProtocolsForClient.CA_LoginReq.getDefaultInstance());
		this.controller.registerMessageLite(ClientProtocols.P_AUTH_CA_CREATE_ACCOUNT_REQ, AuthProtocolsForClient.CA_CreateAccountReq.getDefaultInstance());
		this.controller.registerMessageLite(ClientProtocols.P_AUTH_CA_QUERY_MANIFEST_REQ, AuthProtocolsForClient.CA_QueryManifestReq.getDefaultInstance());
		this.controller.registerMessageLite(ClientProtocols.P_AUTH_CA_QUICK_LOGIN_REQ, AuthProtocolsForClient.CA_QuickLoginReq.getDefaultInstance());
		this.controller.registerMessageLite(ClientProtocols.P_AUTH_CA_BIND_ACCOUNT_REQ, AuthProtocolsForClient.CA_BindAccountReq.getDefaultInstance());
		this.controller.registerMessageLite(ClientProtocols.P_AUTH_CA_RESET_PASSWORD_REQ, AuthProtocolsForClient.CA_ResetPasswordReq.getDefaultInstance());
        this.controller.registerMessageLite(ClientProtocols.P_AUTH_CA_AUTH_ACTIVITY_CODE_REQ, AuthProtocolsForClient.CA_AuthActivityCodeReq.getDefaultInstance());
	}

	@Override
	public void registerMessageHandler() {
		super.registerMessageHandler();
		this.controller.addHandler(ClientProtocols.P_AUTH_CA_LOGIN_REQ, ServerUtil.getFacilityMessageHandlerFactory(ca_LoginReqHandler));
		this.controller.addHandler(ClientProtocols.P_AUTH_CA_CREATE_ACCOUNT_REQ, ServerUtil.getFacilityMessageHandlerFactory(ca_CreateAccountReqHandler));
		this.controller.addHandler(ClientProtocols.P_AUTH_CA_QUERY_MANIFEST_REQ, ServerUtil.getFacilityMessageHandlerFactory(ca_QueryManifestReqHandler));
		this.controller.addHandler(ClientProtocols.P_AUTH_CA_QUICK_LOGIN_REQ, ServerUtil.getFacilityMessageHandlerFactory(ca_QuickLoginReqHandler));
		this.controller.addHandler(ClientProtocols.P_AUTH_CA_BIND_ACCOUNT_REQ, ServerUtil.getFacilityMessageHandlerFactory(ca_BindAccountReqHandler));
		this.controller.addHandler(ClientProtocols.P_AUTH_CA_RESET_PASSWORD_REQ, ServerUtil.getFacilityMessageHandlerFactory(ca_ResetPasswordReqHandler));
	    this.controller.addHandler(ClientProtocols.P_AUTH_CA_AUTH_ACTIVITY_CODE_REQ, ServerUtil.getFacilityMessageHandlerFactory(ca_AuthActivityCodeReqHandler));
	}
}
