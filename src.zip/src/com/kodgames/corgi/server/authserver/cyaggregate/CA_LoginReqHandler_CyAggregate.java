/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.authserver.cyaggregate;

import java.net.SocketAddress;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.MessageHandler.HandlerAction;
import com.kodgames.corgi.gameconfiguration.ChannelSdk;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.AC_LoginRes;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.CA_LoginReq;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.ThirdPlatformSDKHelper;
import com.kodgames.corgi.server.authserver.ServerDataAS;
import com.kodgames.gamedata.baseinfo.BaseInfoConfigMgr;

/**
 * 
 * @author Elvin function:入口，执行sendRequest
 */
public class CA_LoginReqHandler_CyAggregate
{

	private static final Logger logger = LoggerFactory.getLogger(CA_LoginReqHandler_CyAggregate.class);

	public static HandlerAction handleMessage(Channel channel, SocketAddress remoteAddress, Protocol message)
	{
		CA_LoginReq request = (CA_LoginReq)message.getProtoBufMessage();
		AC_LoginRes.Builder ac_LoginResBuilder = AC_LoginRes.newBuilder();
		ac_LoginResBuilder.setCallback(request.getCallback());
		ac_LoginResBuilder.setIsShowActivityInterface(BaseInfoConfigMgr.getInstance().getCfg().isOpenWarmUpActivity());
		
		CA_LoginReq.CyAggregateLoginReq myReq = request.getCyAggregateLoginReq();
		int result = ClientProtocols.E_AUTH_LOGIN_SUCCESS;

		do
		{
			// 检查 myReq
			if (myReq == null)
			{
				result = ClientProtocols.E_AUTH_LOGIN_FAILED_BAD_PARAM;
				break;
			}

			logger.info("recv CA_LoginReq, Email = {}", myReq.getEmail());

			CyAggregate_SessionIdInfo temp_CyAggregate_SessionIdInfo = new CyAggregate_SessionIdInfo();
			CA_LoginReqHandler_CyAggregate_HttpHandler temp_CA_LoginReqHandler_CyAggregate_HttpHandler 
				= new CA_LoginReqHandler_CyAggregate_HttpHandler(temp_CyAggregate_SessionIdInfo, channel, remoteAddress, message);
			// 检查 操作类型
			CyAggregate_HttpClient httpClient =new CyAggregate_HttpClient(temp_CA_LoginReqHandler_CyAggregate_HttpHandler, message);
			try
			{
				// CYCYAGGREGATE_LOGINVERIFY_OPCODE 登陆验证操作码，唯一固定的ID
				httpClient.sendRequest(ChannelSdk.CYCYAGGREGATE_LOGINVERIFY_OPCODE,
					myReq.getData(),
					ThirdPlatformSDKHelper.getAppKeyByChannelId(myReq.getChannelID()),
					ThirdPlatformSDKHelper.getSecretKeyByChannelId(myReq.getChannelID()),
					ChannelSdk.CYCYAGGREGATE_Tag,
					myReq.getChannelID());
			}
			catch (Exception e)
			{
				logger.error("sessionId sendRequest error : {}", ExceptionUtils.getStackTrace(e));
				result = ClientProtocols.E_AUTH_LOGIN_FAILED_CHECK_SESSIONID_FAILED;
				break;
			}
		} while (false);
			
		if (result != ClientProtocols.E_AUTH_LOGIN_SUCCESS)
		{
			ac_LoginResBuilder.setResult(result);
			ServerDataAS.transmitter.sendAndClose(channel,
				ClientProtocols.P_AUTH_AC_LOGIN_RES,
				ac_LoginResBuilder.build());
		}
		return HandlerAction.TERMINAL;
	}
}
