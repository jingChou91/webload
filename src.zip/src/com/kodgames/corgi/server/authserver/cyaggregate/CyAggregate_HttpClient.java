/*
 * Copyright 2009 Red Hat, Inc.
 *
 * Red Hat licenses this file to you under the Apache License, version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License.  You may obtain a copy of the License at:
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
package com.kodgames.corgi.server.authserver.cyaggregate;

import java.net.InetSocketAddress;
import java.nio.charset.Charset;
import java.util.concurrent.Executors;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.jboss.netty.bootstrap.ClientBootstrap;
import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffers;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelFuture;
import org.jboss.netty.channel.socket.nio.NioClientSocketChannelFactory;
import org.jboss.netty.handler.codec.http.DefaultHttpRequest;
import org.jboss.netty.handler.codec.http.HttpHeaders;
import org.jboss.netty.handler.codec.http.HttpMethod;
import org.jboss.netty.handler.codec.http.HttpRequest;
import org.jboss.netty.handler.codec.http.HttpVersion;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.protocol.AuthProtocolsForClient.CA_LoginReq;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.authserver.HttpClientPipelineFactory;
import com.kodgames.corgi.server.common.FutureComplete_Connect_Ex;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.gamedata.baseinfo.BaseInfoConfigMgr;

/*
 * function:Auth Server 发送登陆验证数据到 Billing Server, 
 */
public class CyAggregate_HttpClient
{
	private static final Logger logger = LoggerFactory.getLogger(CyAggregate_HttpClient.class);

	boolean mode = BaseInfoConfigMgr.getInstance().getCfg().isCyHttpMode();
	private static String sign = "";
	private static boolean ssl = false;
	private static int port = 80;
	private Protocol message;
	private CA_LoginReqHandler_CyAggregate_HttpHandler httpClient;
	
	public CyAggregate_HttpClient(CA_LoginReqHandler_CyAggregate_HttpHandler httpClient,Protocol message)
	{
		this.message = message;
		this.httpClient = httpClient;
	}

	private static ClientBootstrap bootstrap = new ClientBootstrap(new NioClientSocketChannelFactory(
		Executors.newCachedThreadPool(), Executors.newCachedThreadPool()));
	
	static{
		// Set up the event pipeline factory.
		bootstrap.setPipelineFactory(new HttpClientPipelineFactory(ssl, new CA_LoginReqHandler_CyAggregate_Pipeline(null,null,null,null)));
	}

	public Channel sendRequest(Integer opcode, String data, String appkey, String appsecret, Integer tag,
		Integer channelId)
	{

		// 设置POST请求方式
		HttpRequest request =
			new DefaultHttpRequest(HttpVersion.HTTP_1_1, HttpMethod.POST, getSessionID_http_prefix(mode));

		// 产生签名
		String param =
			String.valueOf(opcode) + data + appkey + appsecret + String.valueOf(tag) + String.valueOf(channelId);

		logger.info("param = {}" , param);
		try
		{
			sign = GenerateSign.createSign(param);
			logger.info("sign = {}", sign);
		}
		catch (Exception e)
		{
			logger.error("MD5 Encrypt  error : {}", ExceptionUtils.getStackTrace(e));
		}

		// 设置参数
		ChannelBuffer channelBuffer = ChannelBuffers.copiedBuffer("", Charset.forName("UTF-8"));
		request.setUri(getSessionID_http_prefix(mode) + "?data=" + data);
		request.setHeader(HttpHeaders.Names.HOST, getSessionID_httpHost(mode));
		request.setHeader(HttpHeaders.Names.CONNECTION, HttpHeaders.Values.CLOSE);
		request.setHeader(HttpHeaders.Names.ACCEPT_ENCODING, HttpHeaders.Values.GZIP);
		request.setHeader(HttpHeaders.Names.CONTENT_LENGTH, Integer.toString(channelBuffer.readableBytes()));

		request.setHeader("opcode", String.valueOf(opcode));
		request.setHeader("appkey", appkey);
		request.setHeader("sign", sign);
		request.setHeader("tag", String.valueOf(tag));
		request.setHeader("channelId", String.valueOf(channelId));
		request.setContent(channelBuffer);

		
		CA_LoginReq.CyAggregateLoginReq myReq = ((CA_LoginReq)message.getProtoBufMessage()).getCyAggregateLoginReq(); // cy


		// Start the connection attempt.
		ChannelFuture future = bootstrap.connect(new InetSocketAddress(getSessionID_httpHost(mode), port));
		
		//Verify Token Log
		{
			BPUtil.serverEvent(myReq.getVersion(), "", myReq.getEmail(), "null", myReq.getDeviceInfo().getUDID(), "TokenVerify");
		}

		this.httpClient.initHttpChannel(future.getChannel());
		future.addListener(new FutureComplete_Connect_Ex(request,this.httpClient));
		return future.getChannel();
	}

	private String getSessionID_httpHost(boolean mode)
	{
		if (mode == false)
		{
			logger.info("USE TEST BILLING MODE.....................");
			return "tmobilebilling.changyou.com";
		}
		else
		{
			logger.info("USE official BILLING MODE.....................");
			return "mobilebilling.changyou.com";
		}
	}

	private String getSessionID_http_prefix(boolean mode)
	{
		if (mode == false)
		{
			return "http://tmobilebilling.changyou.com/billing";
		}
		else
		{
			return "http://mobilebilling.changyou.com/billing";
		}
	}
}
