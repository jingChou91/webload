package com.kodgames.corgi.server.authserver.cyaggregate;

/*
 * Billing 返回数据的结果
 * data {"tataus:status", "userid":"userid", "oid":"oid"},
 *
 *status: 1 login success
 *		  0	login auth failed
 *userid: chagnyou uid
 *oid: third_channel origional id
 * 
 */
import net.sf.json.JSONObject;

public class CyAggregate_SessionIdInfo
{
	// 操作码
	private int opcode;

	// 事务标示
	private int tag;

	// 请求返回状态
	private int state;

	// 畅游平台唯一用户标识
	private String userid = "";
	
	private String oid = "";
	
	private String errorDesc = "";
	
	private int userstatus;

	private int status;
	
	private int channelId;
	
	private String accessToken = "";

	// 返回错误码
	private int result;

	public int getResult()
	{
		return result;
	}

	public void setResult(int result)
	{
		this.result = result;
	}

	public String getUserid()
	{
		return userid;
	}

	public void setUserid(String userid)
	{
		this.userid = userid;
	}

	public String getOid()
	{
		return oid;
	}

	public void setOid(String oid)
	{
		this.oid = oid;
	}

	public int getChannelId()
	{
		return channelId;
	}

	public int getUserstatus()
	{
		return userstatus;
	}

	public void setUserstatus(int userstatus)
	{
		this.userstatus = userstatus;
	}

	public void setChannelId(int channelId)
	{
		this.channelId = channelId;
	}

	public int getOpcode()
	{
		return opcode;
	}

	public void setOpcode(int opcode)
	{
		this.opcode = opcode;
	}

	public int getTag()
	{
		return tag;
	}

	public void setTag(int tag)
	{
		this.tag = tag;
	}

	public int getState()
	{
		return state;
	}

	public void setState(int state)
	{
		this.state = state;
	}
	
	public int getStatus()
	{
		return status;
	}

	public void setStatus(int status)
	{
		this.status = status;
	}
	
	public String getErrorDesc()
	{
		return errorDesc;
	}
	
	public void setErrorDesc(String errorDesc)
	{
		this.errorDesc = errorDesc;
	}
	
	public String getAccessToken()
	{
		return this.accessToken;
	}

	public void setAccessToken(String accessToken)
	{
		this.accessToken = accessToken;
	}

	
	public boolean fromJsonObject(String contentString) throws Exception
	{
		JSONObject obj = JSONObject.fromObject(contentString);
		if (obj == null)
			return false;
		this.setState(obj.getInt("state"));
		if (this.getState() != 200)
			return false;
		JSONObject dataObj = JSONObject.fromObject(obj.getString("data"));
		if (dataObj == null)
			return false;
		this.setOpcode(obj.getInt("opcode"));
		this.setTag(obj.getInt("tag"));
		this.setChannelId(obj.getInt("channelId"));
		this.setStatus(dataObj.getInt("status"));
		this.setUserid(dataObj.getString("userid"));
		
		if(dataObj.containsKey("oid"))
		{
			this.setOid(dataObj.getString("oid"));
		}
		
		if(dataObj.containsKey("access_token"))
		{
			this.setAccessToken(dataObj.getString("access_token"));	
		}
		
		if(dataObj.containsKey("userstatus"))
		{
			this.setUserstatus(dataObj.getInt("userstatus"));
		}
		
		if(dataObj.containsKey("errorDesc"))
		{
			this.setErrorDesc(dataObj.getString("errorDesc"));
		}
		
		return true;
	}
}
