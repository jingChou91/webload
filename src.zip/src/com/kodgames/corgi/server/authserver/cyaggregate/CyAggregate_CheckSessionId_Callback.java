package com.kodgames.corgi.server.authserver.cyaggregate;

import java.net.SocketAddress;

import org.jboss.netty.channel.Channel;

import com.kodgames.corgi.protocol.Protocol;

public interface CyAggregate_CheckSessionId_Callback
{
	public void onReceive(CyAggregate_SessionIdInfo info, Channel channel, SocketAddress remoteAddress, Protocol message);

	public void onDisconnected(CyAggregate_SessionIdInfo info, Channel channel, SocketAddress remoteAddress,
		Protocol message);

	public void onExceptionCaught(CyAggregate_SessionIdInfo info, Channel channel, SocketAddress remoteAddress,
		Protocol message);
}
