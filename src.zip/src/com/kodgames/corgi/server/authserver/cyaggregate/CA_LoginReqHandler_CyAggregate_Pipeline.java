package com.kodgames.corgi.server.authserver.cyaggregate;

import java.net.SocketAddress;
import java.util.concurrent.atomic.AtomicBoolean;

import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelFutureListener;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.ChannelStateEvent;
import org.jboss.netty.channel.ExceptionEvent;
import org.jboss.netty.channel.MessageEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.protocol.Protocol;

/*
 *具体类的收到信息的进一步处理
 */
public class CA_LoginReqHandler_CyAggregate_Pipeline extends AbstractCyAggregate_CheckSessionId_HttpHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CA_LoginReqHandler_CyAggregate_Pipeline.class);

	public CA_LoginReqHandler_CyAggregate_Pipeline(CyAggregate_SessionIdInfo info, Channel channel,
		SocketAddress remoteAddress, Protocol message)
	{
		super(info, channel, remoteAddress, message);
	}
	
	@Override
	public void messageReceived(ChannelHandlerContext ctx, MessageEvent e){
		CA_LoginReqHandler_CyAggregate_HttpHandler httpClient=(CA_LoginReqHandler_CyAggregate_HttpHandler)ctx.getChannel().getAttachment();
		if(httpClient!=null){
			httpClient.messageReceived(ctx, e);
		}
	}

	@Override
	public void onReceive(CyAggregate_SessionIdInfo info, Channel channel, SocketAddress remoteAddress, Protocol message)
	{
		CA_LoginReqHandler_CyAggregate_HttpHandler httpClient=(CA_LoginReqHandler_CyAggregate_HttpHandler)channel.getAttachment();
		if(httpClient!=null){
			httpClient.onReceive(info, channel, remoteAddress, message);
		}
	}

	@Override
	public void onDisconnected(CyAggregate_SessionIdInfo info, Channel channel, SocketAddress remoteAddress,
		Protocol message)
	{
		CA_LoginReqHandler_CyAggregate_HttpHandler httpClient=(CA_LoginReqHandler_CyAggregate_HttpHandler)channel.getAttachment();
		if(httpClient!=null){
			httpClient.onDisconnected(info, channel, remoteAddress, message);
		}
	}

	@Override
	public void onExceptionCaught(CyAggregate_SessionIdInfo info, Channel channel, SocketAddress remoteAddress,
		Protocol message)
	{
		CA_LoginReqHandler_CyAggregate_HttpHandler httpClient=(CA_LoginReqHandler_CyAggregate_HttpHandler)channel.getAttachment();
		if(httpClient!=null){
			httpClient.onExceptionCaught(info, channel, remoteAddress, message);
		}
	}
	
	@Override
	public void channelDisconnected(ChannelHandlerContext ctx, ChannelStateEvent e)
		throws Exception
	{
		CA_LoginReqHandler_CyAggregate_HttpHandler httpClient=(CA_LoginReqHandler_CyAggregate_HttpHandler)ctx.getChannel().getAttachment();
		if(httpClient!=null){
			httpClient.channelDisconnected(ctx,e);
		}
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, ExceptionEvent e)
		throws Exception
	{
		CA_LoginReqHandler_CyAggregate_HttpHandler httpClient=(CA_LoginReqHandler_CyAggregate_HttpHandler)ctx.getChannel().getAttachment();
		if(httpClient!=null){
			httpClient.exceptionCaught(ctx,e);
		}
	}
}
