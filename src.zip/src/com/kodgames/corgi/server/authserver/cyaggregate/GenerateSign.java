package com.kodgames.corgi.server.authserver.cyaggregate;

import java.security.MessageDigest;

public class GenerateSign
{
	/*
	 * function:产生签名 /*usage:createSign(opcode + data + appkey + appsecret + tag + channelId)
	 */
	public static String createSign(String param)
		throws Exception
	{
		StringBuffer result = new StringBuffer();
		MessageDigest md5 = MessageDigest.getInstance("MD5");
		md5.update(param.getBytes("UTF-8"));
		byte[] b = md5.digest();
		for (int i = 0; i < b.length; ++i)
		{
			int x = b[i] & 0xFF;
			int h = x >>> 4;
			int l = x & 0x0F;
			result.append((char)(h + ((h < 10) ? '0' : 'a' - 10)));
			result.append((char)(l + ((l < 10) ? '0' : 'a' - 10)));
		}
		return result.toString().substring(8, 24);
	}
}
