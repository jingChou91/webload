package com.kodgames.corgi.server.authserver.cyaggregate;

import java.net.SocketAddress;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelFutureListener;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.ChannelStateEvent;
import org.jboss.netty.channel.ExceptionEvent;
import org.jboss.netty.channel.MessageEvent;
import org.jboss.netty.channel.SimpleChannelUpstreamHandler;
import org.jboss.netty.handler.codec.http.HttpResponse;
import org.jboss.netty.handler.codec.http.HttpResponseStatus;
import org.jboss.netty.util.CharsetUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.Protocol;

/*
 *function:虚类函数，用于处理接收消息后,通用的错误判断 
 */
public abstract class AbstractCyAggregate_CheckSessionId_HttpHandler extends SimpleChannelUpstreamHandler implements
	CyAggregate_CheckSessionId_Callback
{

	private static final Logger logger = LoggerFactory.getLogger(AbstractCyAggregate_CheckSessionId_HttpHandler.class);

	private CyAggregate_SessionIdInfo info;
	private Channel channel;
	private SocketAddress remoteAddress;
	private Protocol message;
	private Channel httpChannel;

	public AbstractCyAggregate_CheckSessionId_HttpHandler(CyAggregate_SessionIdInfo info, Channel channel,
		SocketAddress remoteAddress, Protocol message)
	{


		this.info = info;
		if(this.info!=null){
			this.info.setResult(ClientProtocols.E_CHECK_SESSIONID_FAILED);
		}
		this.channel = channel;
		this.remoteAddress = remoteAddress;
		this.message = message;
	}

	public CyAggregate_SessionIdInfo getInfo()
	{
		return info;
	}

	public void initHttpChannel(Channel httpChannel)
	{
		this.httpChannel = httpChannel;
	}

	@Override
	public void messageReceived(ChannelHandlerContext ctx, MessageEvent e)
	{

		int result = ClientProtocols.E_CHECK_SESSIONID_SUCCESS;
		boolean validContent = false;
		try
		{

			// Http的一般错误判断
			HttpResponse response = (HttpResponse)e.getMessage();
			do
			{
				if (!response.getStatus().equals(HttpResponseStatus.OK))
				{
					logger.error("STATUS: " + response.getStatus().toString());
					result = ClientProtocols.E_CHECK_SESSIONID_ERROR_BAD_STATUS;
					break;
				}

				ChannelBuffer content = response.getContent();
				if (!content.readable())
				{
					logger.error("not readable STATUS: " + response.getStatus().toString());
					result = ClientProtocols.E_CHECK_SESSIONID_ERROR_IS_NOT_READABLE;
					break;
				}

				String contentString = content.toString(CharsetUtil.UTF_8);
				logger.debug(contentString);
				try
				{
					validContent = info.fromJsonObject(contentString);
				}
				catch (Exception ex)
				{
					logger.error("invalid content contentString={}", contentString);
					result = ClientProtocols.E_CHECK_SESSIONID_ERROR_INVALID_CONTENT1;
					break;
				}

				if (!validContent)
				{
					logger.error("invalid content contentString={}", contentString);
					result = ClientProtocols.E_CHECK_SESSIONID_ERROR_INVALID_CONTENT2;
					break;
				}

				try
				{
					// 判断是否验证登陆成功
					if (info.getStatus() == 1)
					{
						logger.debug("ErrorDesc=success");
						// success
					}
					else
					{
						result = ClientProtocols.E_CHECK_SESSIONID_FAILED_COMMON_ERROR;
						logger.error("ErrorDesc=failed, contentString = {}", contentString);
						break;
					}
				}
				catch (Exception ex)
				{
					logger.error("fetch jsonObject value failed={} \n{}",
						contentString,
						ExceptionUtils.getStackTrace(ex));
					result = ClientProtocols.E_CHECK_SESSIONID_ERROR_INVALID_DATA;
					break;
				}
			} while (false);
		}
		catch (Exception ex)
		{
			result = ClientProtocols.E_CHECK_SESSIONID_FAILED;
			logger.error("E_CHECK_SESSIONID_FAILED \n{}", ExceptionUtils.getStackTrace(ex));
		}
		info.setResult(result);
		// logger.error("--- onReceive");
		onReceive(info, channel, remoteAddress, message);
		if (httpChannel != null)
		{
			httpChannel.close().addListener(ChannelFutureListener.CLOSE);
		}
	}

	@Override
	public void channelDisconnected(ChannelHandlerContext ctx, ChannelStateEvent e)
		throws Exception
	{
		// logger.error("--- channelDisconnected");
		onDisconnected(info, channel, remoteAddress, message);
		if (httpChannel != null)
		{
			httpChannel.close().addListener(ChannelFutureListener.CLOSE);
		}
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, ExceptionEvent e)
		throws Exception
	{
		logger.error("--- exceptionCaught {}", e.toString());
		onExceptionCaught(info, channel, remoteAddress, message);
		if (httpChannel != null)
		{
			httpChannel.close().addListener(ChannelFutureListener.CLOSE);
		}
	}
}