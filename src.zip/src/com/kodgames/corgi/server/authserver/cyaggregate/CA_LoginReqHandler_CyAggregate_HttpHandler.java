package com.kodgames.corgi.server.authserver.cyaggregate;

import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon._ServerAreaStatus;

import com.kodgames.corgi.protocol.AuthProtocolsForClient.AC_LoginRes;
import com.kodgames.corgi.protocol.AuthProtocolsForClient.CA_LoginReq;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.authserver.ServerDataAS;
import com.kodgames.corgi.server.authserver.ServerDataAS.TokenSession;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.dbclient.KodLog;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.manageserver.ServerInfo;
import com.kodgames.gamedata.account.AccountActivate;
import com.kodgames.gamedata.account.Account_CyAggregate;
import com.kodgames.gamedata.area.Area;
import com.kodgames.gamedata.area.AreaConfigMgr;
import com.kodgames.gamedata.area.AreaConfigMgr.WhiteIPRange;
import com.kodgames.gamedata.baseinfo.BaseInfoConfigMgr;

/*
 *具体类的收到信息的进一步处理
 */
public class CA_LoginReqHandler_CyAggregate_HttpHandler extends AbstractCyAggregate_CheckSessionId_HttpHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CA_LoginReqHandler_CyAggregate_HttpHandler.class);

	private AtomicBoolean retMsgSend = new AtomicBoolean(false);

	public CA_LoginReqHandler_CyAggregate_HttpHandler(CyAggregate_SessionIdInfo info, Channel channel,
		SocketAddress remoteAddress, Protocol message)
	{
		super(info, channel, remoteAddress, message);
	}

	@Override
	public void onReceive(CyAggregate_SessionIdInfo info, Channel channel, SocketAddress remoteAddress, Protocol message)
	{
		retMsgSend.set(true);
		CA_LoginReq request = (CA_LoginReq)message.getProtoBufMessage();
		AC_LoginRes.Builder ac_LoginResBuilder = AC_LoginRes.newBuilder();
		ac_LoginResBuilder.setCallback(request.getCallback());
		ac_LoginResBuilder.setIsShowActivityInterface(BaseInfoConfigMgr.getInstance().getCfg().isOpenWarmUpActivity());

		CA_LoginReq.CyAggregateLoginReq myReq = request.getCyAggregateLoginReq(); // cy
		HashMap<Integer, Integer> areaList = new HashMap<>();

		int result = ClientProtocols.E_AUTH_LOGIN_SUCCESS;

		do
		{
			if (info.getResult() == ClientProtocols.E_CHECK_SESSIONID_SUCCESS)
			{
				if (info.getStatus() == 1)
				{
					// sessionId is valid
				}
				else
				{
					// sessionId is not valid
					result = ClientProtocols.E_AUTH_LOGIN_FAILED_CHECK_SESSIONID_FAILED;
					break;
				}
			}
			else
			{
				// get sessionId failed
				result = ClientProtocols.E_AUTH_LOGIN_FAILED_CHECK_SESSIONID_FAILED;
				break;
			}

			AC_LoginRes.ChannelMessage.Builder channelMessage = AC_LoginRes.ChannelMessage.newBuilder();
			
			channelMessage.setChannelUniqueId(info.getUserid());
			channelMessage.setOid(info.getOid()); //某些特殊平台参数, 如360支付平台使用
			channelMessage.setAccessToken(info.getAccessToken()); //某些特殊平台参数, 如360支付平台使用
			
			ac_LoginResBuilder.setChannelMessage(channelMessage.build());

			Account_CyAggregate.login(info.getUserid(),
				myReq.getEmail(),
				ac_LoginResBuilder,
				areaList,
				myReq.getDeviceInfo(),
				myReq.getChannelID());

			if (ac_LoginResBuilder.getResult() != ClientProtocols.E_AUTH_LOGIN_SUCCESS)
			{
				result = ac_LoginResBuilder.getResult();
				break;
			}
		} while (false);

		if (result == ClientProtocols.E_AUTH_LOGIN_SUCCESS)
		{
			String remoteIP = ServerUtil.getRemoteIP(remoteAddress.toString());
			
			logger.warn("remote Ip : {}, whitelist : {}", remoteIP, AreaConfigMgr.getInstance().getWhiteIpRanges());
			
			long ip = ServerUtil.transferIPToLong(remoteIP);
			boolean isWhiteIP = false;
			for (WhiteIPRange whiteIPRange : AreaConfigMgr.getInstance().getWhiteIpRanges())
			{
				if (ip >= whiteIPRange.getStartIp() && ip <= whiteIPRange.getEndIp())
				{
					isWhiteIP = true;
					break;
				}
			}
			
			//客户端是否显示激活码兑换框
			int iAccountId = ac_LoginResBuilder.getAccountID();
			if(ac_LoginResBuilder.getIsShowActivityInterface() && AccountActivate.hasActivated(iAccountId))
			{
				ac_LoginResBuilder.setIsShowActivityInterface(false);
			}
					
			ArrayList<Area> areas = AreaConfigMgr.getInstance().getSpecifiedAreas(info.getChannelId());
			for (int i = areas.size() - 1; i >= 0; --i)
			{
				Area area = areas.get(i);
				
				//时间未到,看不到区
				if (!isWhiteIP && area.getAreaStartTime() > System.currentTimeMillis())
				{
					continue;
				}
				
				if (area.getStatus() == _ServerAreaStatus.Unknown)
				{
					continue;
				}
				
				int areaStatus = area.getStatus();
				if (area.getStatus() == _ServerAreaStatus.OnlyForWhiteIP && !isWhiteIP)
				{
					continue;
				}
				else if (area.getStatus() == _ServerAreaStatus.OnlyForWhiteIP && isWhiteIP)
				{
					areaStatus = _ServerAreaStatus.New;
				}
				
				int areaId = area.getAreaId();
				CommonProtocols.Area.Builder areaBuild = CommonProtocols.Area.newBuilder();
				areaBuild.setAreaID(areaId);
				areaBuild.setShowAreaID(area.getClientShowAreaId());
				areaBuild.setAreaAvatarNumber(0);
				areaBuild.setName(area.getAreaName());
				areaBuild.setStatus(areaStatus);

				// 这里用AccountID% this area interface Count
				List<ServerInfo> serverInfos = ServerDataAS.transmitter.getGameServers(areaId);
				if (null == serverInfos)
				{
					areaBuild.setInterfaceServerIP("");
					areaBuild.setInterfaceServerPort(0);
					ac_LoginResBuilder.addAreas(areaBuild);
					continue;
				}

				int index = ac_LoginResBuilder.getAccountID() % serverInfos.size();
				ServerInfo serverInfo = serverInfos.get(index);
				if (null == serverInfo)
				{
					areaBuild.setInterfaceServerIP("");
					areaBuild.setInterfaceServerPort(0);
					ac_LoginResBuilder.addAreas(areaBuild);
					continue;
				}
				areaBuild.setInterfaceServerIP(serverInfo.getIpForClient());
				areaBuild.setInterfaceServerPort(serverInfo.getPortForClient());
				areaBuild.setKunLunAreaId(0);

				if (areaList.containsKey(areaId))
				{
					if (areaList.get(areaId) == 0)
					{
						continue;
					}
					else
					{
						areaBuild.setAreaAvatarNumber(1);
					}
				}

				ac_LoginResBuilder.addAreas(areaBuild);
			}

			String uuid = UUID.randomUUID().toString();
			String token = myReq.getRandomSeed() + uuid;
			int account_idx = ac_LoginResBuilder.getAccountID();

			// send uuid token to client
			ac_LoginResBuilder.setToken(uuid);
			
			
			logger.info("Token put into sessions, {}  {}", iAccountId, info.getUserid());
			// save token
			TokenSession tokensession =
				new TokenSession(token, false, info.getUserid(),
					(InetSocketAddress)remoteAddress, myReq.getDeviceInfo(), channel.getRemoteAddress().toString(),
					 info.getUserid(), myReq.getVersion(),myReq.getEmail(), myReq.getChannelID());
			ServerDataAS.tokensessions.put(account_idx, tokensession);

			// KODLOG
			{
				//int iAccountId = ac_LoginResBuilder.getAccountID();
				String vClientIp = channel.getRemoteAddress().toString();
				KodLog.account_login(KodLog.getDatetime(System.currentTimeMillis()),
					iAccountId,
					myReq.getChannelID(),
					vClientIp,
					myReq.getDeviceInfo().getUDID(),
					myReq.getDeviceInfo().getOSType(),
					myReq.getDeviceInfo().getOSVersion(),
					myReq.getDeviceInfo().getDeviceName(),
					myReq.getDeviceInfo().getDeviceType(),
					myReq.getChannelID());
			}
			
			//Verify Token result log
			{
				String udid =  myReq.getDeviceInfo().getUDID();
				if ("".equals(udid) || "0".equals(udid) || "DefaultUDID".equals(udid))
				{
					udid = "null";
				}
				
				BPUtil.serverEvent(myReq.getVersion(), "", myReq.getEmail(), info.getUserid(), myReq.getDeviceInfo().getUDID(), "TokenVerifyResult");
				BPUtil.serverEvent(myReq.getVersion(), "", myReq.getEmail(), info.getUserid(), myReq.getDeviceInfo().getUDID(), "ServerList");
			}
		}
		
		ac_LoginResBuilder.setResult(result);
		ServerDataAS.transmitter.sendAndClose(channel, ClientProtocols.P_AUTH_AC_LOGIN_RES, ac_LoginResBuilder.build());
	}

	@Override
	public void onDisconnected(CyAggregate_SessionIdInfo info, Channel channel, SocketAddress remoteAddress,
		Protocol message)
	{
		logger.info("--- exceptionCaught, {} disconnect" );
	}

	@Override
	public void onExceptionCaught(CyAggregate_SessionIdInfo info, Channel channel, SocketAddress remoteAddress,
		Protocol message)
	{
		if (retMsgSend.get() == false)
		{
			CA_LoginReq request = (CA_LoginReq)message.getProtoBufMessage();
			AC_LoginRes.Builder ac_LoginResBuilder = AC_LoginRes.newBuilder();
			ac_LoginResBuilder.setCallback(request.getCallback());

			int result = ClientProtocols.E_AUTH_LOGIN_FAILED_CHECK_SESSIONID_FAILED;
			ac_LoginResBuilder.setResult(result);
			ServerDataAS.transmitter.sendAndClose(channel,
				ClientProtocols.P_AUTH_AC_LOGIN_RES,
				ac_LoginResBuilder.build());
		}
	}
}
