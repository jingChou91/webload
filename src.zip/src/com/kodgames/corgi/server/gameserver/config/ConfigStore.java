package com.kodgames.corgi.server.gameserver.config;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConfigStore
{
	private static final Logger logger = LoggerFactory.getLogger(ConfigStore.class);
	public static final int CONFIG_NO_CHANGE = 0x0000;
	public static final int CONFIG_CHANGE_RELOAD = 0x0001;		//需要客户端重启
	public static final int CONFIG_CHANGE_HOT = 0x0002;			//客户端不需要重启，主要是为活动文件的更新
	
	private Map<String, String> xmlStoreDatas = new ConcurrentHashMap<String, String>();		//配置文件列表
	private String md5Key = "QinMoonConfigFileKey";
	
	private static ConfigStore store = new ConfigStore();
	
	public static ConfigStore getInstance()
	{
		return store;
	}
	
	public int checkConfigRefresh(String name, String fileContent)
	{
		boolean result = false;
		String findContent = xmlStoreDatas.get(name);
		if (null == findContent)
		{
			result = true;
		}
		else
		{
			try
			{
				MessageDigest md5 = MessageDigest.getInstance("MD5");
				md5.update(fileContent.getBytes());
				byte[] newMD5 = md5.digest(md5Key.getBytes());
				
				md5 = MessageDigest.getInstance("MD5");
				md5.update(findContent.getBytes());
				byte[] oldMD5 = md5.digest(md5Key.getBytes());
				
				if (!newMD5.equals(oldMD5))
				{
					result = true;
				}
			}
			catch (NoSuchAlgorithmException e)
			{
				logger.error("{}", ExceptionUtils.getStackTrace(e));
			}
		}
		
		xmlStoreDatas.put(name, fileContent);
		
		if(result)
		{
			if (!name.endsWith("ActivityConfig.xml"))
			{
				return CONFIG_CHANGE_RELOAD;
			}
			else
			{
				return CONFIG_CHANGE_HOT;
			}
		}
		else
		{
			return CONFIG_NO_CHANGE;
		}
	}
	
	

}
