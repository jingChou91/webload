package com.kodgames.corgi.server.gameserver.dungeon.data;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._DungeonStatus;

import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.gamedata.player.PlayerNode;

public class Dungeon
{
	private int zoneId;
	private int dungeonId;
	private int bestRecord;// 最高星级成就
	private int todayCompleteTimes;// 今日通关次数
	private long lastRefreshTime;// 关卡上次刷新时间
	private int resetCount; // 今天已重置次数
	private long lastResetTime;// 上次重置时间
	private int status;// 关卡状态
	private int dialogState;// 关卡剧情

	public void addTodayCompleteTime(int completeTime)
	{
		this.todayCompleteTimes += completeTime;
	}

	// 判断是否需要刷新关卡重置次数
	public void refresh_DungeonResetCount(ConfigDatabase cd)
	{
		if (ServerUtil.isNeedRefresh(cd.get_GameConfig().get_restoreResetDungeonCompleteDataTime(), lastResetTime))
		{
			resetCount = 0;
			lastResetTime = System.currentTimeMillis();
		}
	}

	// 判断是否需要刷新关卡完成次数
	public void refresh_DungeonCompleteTimes(ConfigDatabase cd, PlayerNode playerNode)
	{
		if (ServerUtil.isNeedRefresh(cd.get_GameConfig().get_restoreResetDungeonCompleteDataTime(), lastRefreshTime))
		{
			this.todayCompleteTimes = 0;
			this.lastRefreshTime = System.currentTimeMillis();
		}
	}

	// 创建一个关卡,并设置状态为开启,设置最高通关星级(一般为GM工具,副本全开使用)
	public static Dungeon createOpenDungeon(int zoneId, int dungeonId, int stars)
	{
		return new Dungeon(zoneId, dungeonId, stars, 0, System.currentTimeMillis(), 0, 0L, _DungeonStatus.UnLockState,
			0);
	}

	// 创建一个全新的,没有任何操作过的关卡(一般为首次攻打某关卡时创建)
	public static Dungeon createDungeonWithStatus(int zoneId, int dungeonId, int status)
	{
		return new Dungeon(zoneId, dungeonId, 0, 0, System.currentTimeMillis(), 0, 0L, status, 0);
	}

	public Dungeon(int zoneId, int dungeonId, int bestRecord, int todayCompleteTimes, long lastRefreshTime,
		int resetCount, long lastResetTime, int status, int dialogState)
	{
		super();
		this.zoneId = zoneId;
		this.dungeonId = dungeonId;
		this.bestRecord = bestRecord;
		this.todayCompleteTimes = todayCompleteTimes;
		this.lastRefreshTime = lastRefreshTime;
		this.resetCount = resetCount;
		this.lastResetTime = lastResetTime;
		this.status = status;
		this.dialogState = dialogState;
	}

	public void addTodayCompleteTimes()
	{
		todayCompleteTimes++;
	}

	public com.kodgames.corgi.protocol.CommonProtocols.Dungeon toProtoBuffer()
	{
		CommonProtocols.Dungeon.Builder builder = CommonProtocols.Dungeon.newBuilder();
		builder.setDungeonId(dungeonId);
		builder.setTodayCompleteTimes(todayCompleteTimes);
		builder.setTodayAlreadyResetTimes(resetCount);
		builder.setBestRecord(bestRecord);
		builder.setDungeonStatus(status);
		builder.setDialogState(dialogState);
		return builder.build();
	}

	public int getZoneId()
	{
		return zoneId;
	}

	public void setZoneId(int zoneId)
	{
		this.zoneId = zoneId;
	}

	public int getDungeonId()
	{
		return dungeonId;
	}

	public void setDungeonId(int dungeonId)
	{
		this.dungeonId = dungeonId;
	}

	public int getBestRecord()
	{
		return bestRecord;
	}

	public void setBestRecord(int bestRecord)
	{
		this.bestRecord = bestRecord;
	}

	public int getTodayCompleteTimes()
	{
		return todayCompleteTimes;
	}

	public void setTodayCompleteTimes(int todayCompleteTimes)
	{
		this.todayCompleteTimes = todayCompleteTimes;
	}

	public long getLastRefreshTime()
	{
		return lastRefreshTime;
	}

	public void setLastRefreshTime(long lastRefreshTime)
	{
		this.lastRefreshTime = lastRefreshTime;
	}

	public int getResetCount()
	{
		return resetCount;
	}

	public void setResetCount(int resetCount)
	{
		this.resetCount = resetCount;
	}

	public long getLastResetTime()
	{
		return lastResetTime;
	}

	public void setLastResetTime(long lastResetTime)
	{
		this.lastResetTime = lastResetTime;
	}

	public int getStatus()
	{
		return status;
	}

	public void setStatus(int status)
	{
		this.status = status;
	}

	public int getDialogState()
	{
		return dialogState;
	}

	public void setDialogState(int dialogState)
	{
		this.dialogState = dialogState;
	}

}