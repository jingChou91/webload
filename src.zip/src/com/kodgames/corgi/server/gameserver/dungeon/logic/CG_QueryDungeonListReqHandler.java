package com.kodgames.corgi.server.gameserver.dungeon.logic;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._DungeonDifficulity;
import ClientServerCommon._DungeonStatus;
import ClientServerCommon._ZoneStatus;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryDungeonListReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryDungeonListRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dungeon.ActivityHandleSecretManager;
import com.kodgames.corgi.server.gameserver.dungeon.data.Dungeon;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonData;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonMgr;
import com.kodgames.corgi.server.gameserver.dungeon.data.Travel;
import com.kodgames.corgi.server.gameserver.dungeon.util.DungeonUtil;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_QueryDungeonListReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_QueryDungeonListReqHandler.class);
	public CG_QueryDungeonListReqHandler(ActivityHandleSecretManager activityHandleSecretManager)
	{
	}

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_QueryDungeonListReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_QueryDungeonListReq request = (CG_QueryDungeonListReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryDungeonListRes.Builder builder = GC_QueryDungeonListRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_DUNGEON_LIST_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_QUERY_DUNGEON_LIST_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{

				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DUNGEON_LIST_FAILED_GET_PLAYERNODE_FAILED;
					break;
				}
				CampaignConfig campaignCfg = cd.get_CampaignConfig();
				if (campaignCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DUNGEON_LIST_FAILED_CAMPAIGNCONF_ERROR;
					break;
				}
				DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();

				// 判断是否需要刷新关卡完成次数
				dungeonData.refresh_DungeonCompleteTimes(cd, playerNode);

				// 如果是第一次登陆,修改序章状态,序章副本全开,在内存中初始化其他章节状态
				if (dungeonData.getZones().size() == 0)
				{
					// 历练章节
					{
						int minZoneId = campaignCfg.Get_zonesByIndex(0).get_zoneId();
						for (int i = 0; i < campaignCfg.Get_zonesCount(); i++)
						{
							int zoneId = campaignCfg.Get_zonesByIndex(i).get_zoneId();
							DungeonMgr.initZoneStatus(playerNode, zoneId, _ZoneStatus.UnlockAnimation);
							if (minZoneId > zoneId)
							{
								minZoneId = zoneId;
							}
						}
						// 修改第一个章节的状态(因为序章副本全开有此副作用,所以暂时注释)
						DungeonMgr.updateZoneStatus(playerNode, minZoneId, _ZoneStatus.ZoneProceed);
					}
					// 秘境章节
					{
						for (int i = 0; i < campaignCfg.Get_secretZonesCount(); i++)
						{
							int zoneId = campaignCfg.Get_secretZonesByIndex(i).get_zoneId();
							DungeonMgr.initZoneStatus(playerNode, zoneId, _ZoneStatus.PlotDialogue);
						}
					}
					// // 序章默认通关
					// DungeonGMUtil.openAllDungeon(playerId, 3, campaignConfig.Get_zonesByIndex(0).get_zoneId(), 0);

				}
				else
				// 不是第一次登陆,内存中初始化未打过的章节的状态
				{
					// 历练章节
					{
						for (int i = 0; i < campaignCfg.Get_zonesCount(); i++)
						{
							int zoneId = campaignCfg.Get_zonesByIndex(i).get_zoneId();
							if (dungeonData.getZones().get(zoneId) == null)
							{
								DungeonMgr.initZoneStatus(playerNode, zoneId, _ZoneStatus.UnlockAnimation);
							}
						}
					}
					// 秘境章节
					{
						for (int i = 0; i < campaignCfg.Get_secretZonesCount(); i++)
						{
							int zoneId = campaignCfg.Get_secretZonesByIndex(i).get_zoneId();
							if (dungeonData.getZones().get(zoneId) == null)
							{
								DungeonMgr.initZoneStatus(playerNode, zoneId, _ZoneStatus.PlotDialogue);
							}
						}
					}
				}

				// 生成客户端需要的数据
				// 历练副本
				for (int i = 0; i < campaignCfg.Get_zonesCount(); i++)
				{
					CommonProtocols.Zone.Builder zoneBuilder = CommonProtocols.Zone.newBuilder();

					// 章节信息
					Integer zoneId = (Integer)campaignCfg.Get_zonesByIndex(i).get_zoneId();
					zoneBuilder.setZoneId(zoneId);
					if (dungeonData.getZones().get(zoneId) == null)
					{
						DungeonMgr.updateZoneStatus(playerNode, zoneId, _ZoneStatus.UnlockAnimation);
					}
					zoneBuilder.setStatus(dungeonData.getZones().get(zoneId));
					// 每个难度信息
					for (int j = 0; j < campaignCfg.Get_zonesByIndex(i).Get_dungeonDifficultiesCount(); j++)// GetDungeonDifficultyCount()
					{
						CommonProtocols.DungeonDifficulty.Builder difficultyBuilder =
							CommonProtocols.DungeonDifficulty.newBuilder();
						ClientServerCommon.CampaignConfig.DungeonDifficulty dungeonDifficulty =
							campaignCfg.Get_zonesByIndex(i).Get_dungeonDifficultiesByIndex(j);// GetDungeonDifficulty(j)
						if (dungeonDifficulty != null)
						{
							int difficultyType = dungeonDifficulty.get_difficultyType();
							difficultyBuilder.setDifficultyType(difficultyType);
							// 每个关卡信息
							for (int k = 0; k < dungeonDifficulty.Get_dungeonsCount(); k++)
							{
								Integer dungeonId = dungeonDifficulty.Get_dungeonsByIndex(k).get_dungeonId();
								// 只返回有数据的关卡信息.
								if (dungeonData.getDungeonById(dungeonId) != null)
								{
									difficultyBuilder.addDungeons(dungeonData.getDungeonById(dungeonId).toProtoBuffer());
								}
								// 返回云游商人信息
								Travel travel = dungeonData.getTravels().get(dungeonId);
								if (travel != null)
								{
									difficultyBuilder.addTravelDatas(travel.toProtoBuffer(campaignCfg, dungeonId));
								}
							}
							// 每个难度下宝箱领取记录
							if (dungeonData.checkBoxRewardPicked(zoneId, difficultyType, null))
							{
								List<Integer> list = dungeonData.getBoxRecords().get(zoneId).get(difficultyType);
								for (Integer index : list)
								{
									difficultyBuilder.addBoxPickedIndexs(index);
								}
							}
							zoneBuilder.addDungeonDifficulties(difficultyBuilder.build());
						}
					}

					builder.addZones(zoneBuilder.build());
				}

				// 秘境副本
				for (int i = 0; i < campaignCfg.Get_secretZonesCount(); i++)
				{
					CommonProtocols.Zone.Builder zoneBuilder = CommonProtocols.Zone.newBuilder();

					// 章节信息
					Integer zoneId = (Integer)campaignCfg.Get_secretZonesByIndex(i).get_zoneId();
					zoneBuilder.setZoneId(zoneId);
					if (dungeonData.getZones().get(zoneId) == null)
					{
						DungeonMgr.updateZoneStatus(playerNode, zoneId, _ZoneStatus.UnlockAnimation);
					}
					zoneBuilder.setStatus(dungeonData.getZones().get(zoneId));
					// 每个难度信息
					for (int j = 0; j < campaignCfg.Get_secretZonesByIndex(i).Get_dungeonDifficultiesCount(); j++)// GetDungeonDifficultyCount()
					{
						CommonProtocols.DungeonDifficulty.Builder difficultyBuilder =
							CommonProtocols.DungeonDifficulty.newBuilder();
						ClientServerCommon.CampaignConfig.DungeonDifficulty dungeonDifficulty =
							campaignCfg.Get_secretZonesByIndex(i).Get_dungeonDifficultiesByIndex(j);// GetDungeonDifficulty(j)
						if (dungeonDifficulty != null)
						{
							int difficultyType = dungeonDifficulty.get_difficultyType();
							difficultyBuilder.setDifficultyType(difficultyType);
							// 每个关卡信息
							for (int k = 0; k < dungeonDifficulty.Get_dungeonsCount(); k++)
							{
								Integer dungeonId = dungeonDifficulty.Get_dungeonsByIndex(k).get_dungeonId();
								// 只返回有数据的关卡信息.
								if (dungeonData.getDungeonById(dungeonId) != null)
								{
									difficultyBuilder.addDungeons(dungeonData.getDungeonById(dungeonId).toProtoBuffer());
								}
							}
							// 每个难度下宝箱领取记录
							if (dungeonData.checkBoxRewardPicked(zoneId, difficultyType, null))
							{
								List<Integer> list = dungeonData.getBoxRecords().get(zoneId).get(difficultyType);
								for (Integer index : list)
								{
									difficultyBuilder.addBoxPickedIndexs(index);
								}
							}
							zoneBuilder.addDungeonDifficulties(difficultyBuilder.build());
						}
					}

					builder.addSecretZones(zoneBuilder.build());
				}
				builder.setLastZoneId(dungeonData.getLastZoneId());
				builder.setLastDungeonId(dungeonData.getLastDungeonId());
				builder.setLastSecretZoneId(dungeonData.getLastSecretZoneId());
				builder.setLastSecretDungeonId(dungeonData.getLastSecretDungeonId());
				builder.setPositionId(DungeonUtil.getLastPositionId(playerNode));
				builder.setLastResetDungeonTime(dungeonData.getLastRefreshDungeonTime());

				// openAllDungeon(playerNode.getPlayerId());

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}

	// 副本全开
	public void openAllDungeon(Integer playerId)
	{
		int stars = 3;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CampaignConfig campaignConfig = cd.get_CampaignConfig();
		PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
		if (playerNode != null && playerNode.getPlayerInfo() != null)
		{
			DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
			// 历练
			for (int i = 0; i < campaignConfig.Get_zonesCount(); i++)
			{
				// 设置章节状态
				Integer zoneId = (Integer)campaignConfig.Get_zonesByIndex(i).get_zoneId();
				DungeonMgr.updateZoneStatus(playerNode, zoneId, _ZoneStatus.ZoneComplete);
				// 每个难度信息
				ClientServerCommon.CampaignConfig.DungeonDifficulty dungeonDifficulty =
					campaignConfig.Get_zonesByIndex(i).GetDungeonDifficultyByDifficulty(_DungeonDifficulity.Common);
				if (dungeonDifficulty != null)
				{
					// 每个关卡信息
					for (int k = 0; k < dungeonDifficulty.Get_dungeonsCount(); k++)
					{
						Integer dungeonId = dungeonDifficulty.Get_dungeonsByIndex(k).get_dungeonId();
						Dungeon dungeon = dungeonData.getDungeonById(dungeonId);
						if (dungeon != null && dungeon.getBestRecord() < stars)
						{
							dungeon.setBestRecord(stars);
							dungeon.setStatus(_DungeonStatus.UnLockState);
						}
						else
						{
							dungeon = Dungeon.createOpenDungeon(zoneId, dungeonId, stars);
							DungeonMgr.updateDungeon(playerNode, dungeon);
						}
						DungeonMgr.updateDungeon(playerNode, dungeon);
					}
				}
			}
		}

	}
}
