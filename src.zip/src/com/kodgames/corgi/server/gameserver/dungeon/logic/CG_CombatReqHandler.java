package com.kodgames.corgi.server.gameserver.dungeon.logic;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._DungeonDifficulity;
import ClientServerCommon._DungeonStatus;
import ClientServerCommon._ZoneStatus;

import com.kodgames.combat.record.CombatPlayer;
import com.kodgames.combat.record.CombatResultAndReward;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_CombatReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_CombatRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.asyncclient.CombatData;
import com.kodgames.corgi.server.asyncclient.QueryDungeonCombatResultRes;
import com.kodgames.corgi.server.asyncclient.QueryDungeonPlotCombatResultRes;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dungeon.ActivityHandleSecretManager;
import com.kodgames.corgi.server.gameserver.dungeon.data.Dungeon;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonData;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonGlobeMgr;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonMgr;
import com.kodgames.corgi.server.gameserver.dungeon.util.DungeonUtil;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.genplayer.GenCombatNormalPlayer;
import com.kodgames.gamedata.player.genplayer.GenCombatNpcPlayer;

public class CG_CombatReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_CombatReqHandler.class);
	private ActivityHandleSecretManager activityHandleSecretManager = null;

	public CG_CombatReqHandler(ActivityHandleSecretManager activityHandleSecretManager)
	{
		this.activityHandleSecretManager = activityHandleSecretManager;
	}

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_CombatReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_CombatReq request = (CG_CombatReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_CombatRes.Builder builder = GC_CombatRes.newBuilder();
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_COMBAT_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_COMBAT_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		int dungeonId = request.getDungeonId();
		int npcId = request.getNpcId();
		CommonProtocols.Position position = request.getPosition();

		logger.info("recv CG_CombatReq, dungeonId = {}", dungeonId);

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FAILED_GET_PLAYER_FAILED;
					break;
				}
				CampaignConfig campaignCfg = cd.get_CampaignConfig();
				if (campaignCfg == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FAILED_LOAD_CAMPAIGN_CONFIG_FAILED;
					break;
				}
				CampaignConfig.Dungeon dungeonCfg = campaignCfg.GetDungeonById(dungeonId);
				if (dungeonCfg == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FAILED_LOAD_DUNGEON_CONFIG_FAILED;
					break;
				}
				int zoneId = dungeonCfg.get_ZoneId();
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Secret))
					{
						result = ClientProtocols.E_GAME_SECRET_FUNCTION_NOT_OPEN;
						break;
					}
				}
				else
				{
					if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Dungeon))
					{
						result = ClientProtocols.E_GAME_DUNGEON_FUNCTION_NOT_OPEN;
						break;
					}
				}
				CampaignConfig.Zone zoneCfg = campaignCfg.GetZoneById(zoneId);
				if (zoneCfg == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FAILED_LOAD_ZONE_CONFIG_FAILED;
					break;
				}
				// 如果是秘境,判断秘境是否开启
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!activityHandleSecretManager.isActivityActivate(zoneCfg.get_activityId(), playerNode))
					{
						result = ClientProtocols.E_GAME_COMBAT_FAILED_SECRET_ZONE_NOT_OPEN_FAILD;
						break;
					}
				}
				CampaignConfig.DungeonDifficulty difficultyCfg =
					zoneCfg.GetDungeonDifficultyByDifficulty(dungeonCfg.get_DungeonDifficulty());
				if (difficultyCfg == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FAILED_LOAD_DIFFICULT_CONFIG_FAILED;
					break;
				}
				int difficultyType = difficultyCfg.get_difficultyType();
				DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
				if (dungeonData.getZones().get(zoneId) == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FAILED_NOT_HAVE_ZONE_INFO_FAILED;
					break;
				}
				int zoneStatus = dungeonData.getZones().get(zoneId);

				// 难度开启等级
				int level = playerNode.getGamePlayer().getLevel();
				if (level < difficultyCfg.get_levelLimit())
				{
					result = ClientProtocols.E_GAME_GET_FIXEDTIME_ACTIVITY_REWARD_FAILED_LEVEL_WRONG;
//					result = ClientProtocols.E_GAME_COMBAT_FAILED_DUNGEON_LEVEL_LEVEL_NOT_MATCH;
					break;
				}
				// 如果是副本,判断前置关卡是否开启
				if (!campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!DungeonUtil.isPreDungeonComplete(campaignCfg, dungeonData, dungeonId))
					{
						result = ClientProtocols.E_GAME_COMBAT_FAILED_SECRET_ZONE_NOT_OPEN_FAILD;
						break;
					}
				}
				// 判断除了剧情npc外,是否有上阵角色
				int locationCount = position.getAvatarLocationsCount();
				if (!DungeonUtil.isPlotCombat(dungeonCfg))
				{
					if (locationCount <= 1)
					{
						result = ClientProtocols.E_GAME_COMBAT_FAILED_NOT_HAVE_AVATAR_ON_POSITION;
						break;
					}
				}

				// 达到最大回合数谁赢
				boolean maxRoundWhoWin = false; // 默认false表示防守方胜利
				if (dungeonCfg.get_maxRoundWhoWin() == ClientServerCommon._CampType.Attacker)
				{
					maxRoundWhoWin = true;
				}

				// 检查章节状态
				if (!DungeonUtil.checkZoneStatus(zoneStatus, campaignCfg.IsActivityZoneId(zoneId)))
				{
					result = ClientProtocols.E_GAME_COMBAT_FAILED_ZONE_STATUS_ERROR;
					break;
				}

				// 进入Hard难度的前提是common完成
				if (dungeonCfg.get_DungeonDifficulty() == _DungeonDifficulity.Hard
					|| dungeonCfg.get_DungeonDifficulty() == _DungeonDifficulity.Nightmare)
				{
					if (zoneStatus != _ZoneStatus.ZoneComplete)
					{
						result = ClientProtocols.E_GAME_COMBAT_FAILED_ZONE_STATUS_ERROR;
						break;
					}
				}

				// 进入Nightmare难度的前提是其他难度完成
				if (dungeonCfg.get_DungeonDifficulty() == _DungeonDifficulity.Nightmare)
				{
					CampaignConfig.DungeonDifficulty difficulty =
						zoneCfg.GetDungeonDifficultyByDifficulty(_DungeonDifficulity.Hard);
					if (difficulty != null)
					{
						for (int i = 0; i < difficulty.Get_dungeonsCount(); i++)// GetDungeonCount()
						{
							if (!DungeonUtil.checkDungeonPass(playerNode, difficulty.Get_dungeonsByIndex(i)
								.get_dungeonId()))// GetDungeon(i)
							{
								result = ClientProtocols.E_GAME_COMBAT_FAILED_ZONE_STATUS_ERROR;
								break;
							}
						}
						if (result != ClientProtocols.E_GAME_COMBAT_SUCCESS)
						{
							break;
						}
					}
				}

				// 判断副本记录中该副本信息是否存在，存在则看是否需要更新，不存在则创建
				Dungeon dungeon = null;
				if (dungeonData.getDungeonById(dungeonId) == null)
				{
					dungeon = Dungeon.createDungeonWithStatus(zoneId, dungeonId, _DungeonStatus.LockState);
					DungeonMgr.updateDungeon(playerNode, dungeon);
				}
				else
				{
					dungeon = dungeonData.getDungeonById(dungeonId);
					// 判断是否需要刷新
					dungeon.refresh_DungeonCompleteTimes(cd, playerNode);
					DungeonMgr.updateDungeon(playerNode, zoneId);

				}
				// 如果超过当天最大进入次数，则报错
				if (dungeon.getTodayCompleteTimes() >= dungeonCfg.get_enterCount())
				{
					result = ClientProtocols.E_GAME_COMBAT_FAILED_DUNGEON_EXCEED_MAX_ENTER_TIMES;
					break;
				}

				// 消耗信息
				ArrayList<Cost> costs = new ArrayList<Cost>();
				Cost notEnoughCost = new Cost();
				for (int i = 0; i < dungeonCfg.Get_enterCostsCount(); i++)// GetEnterCostCount()
				{
					int costItemId = dungeonCfg.Get_enterCostsByIndex(i).get_id();// GetEnterCost(i)
					int costItemCount = dungeonCfg.Get_enterCostsByIndex(i).get_count();
					Cost cost = new Cost(costItemId, costItemCount);
					costs.add(cost);
				}
				int logEventId = this.getLogEventId(campaignCfg, zoneId);
				// 执行消耗
				if (!CostAndRewardManager.checkCosts(playerNode, costs, cd, logEventId, notEnoughCost))
				{
					crsForClient.setNotEnoughCost(notEnoughCost);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_COMBAT_FAILED_CONSUMABLE_NOT_ENOUGH;
					break;
				}

				CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
				crsForCost.setCosts(costs);
				CostAndRewardManager.consumeCosts(playerNode, costs, cd, logEventId, 0, 0);
				crsForClient.megerCostAndRewardAndSync(crsForCost);

				// 保存最后一场副本Id
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					dungeonData.setLastSecretZoneId(zoneId);
					dungeonData.setLastSecretDungeonId(dungeonId);
				}
				else
				{
					dungeonData.setLastZoneId(zoneId);
					dungeonData.setLastDungeonId(dungeonId);
				}
				dungeonData.setLastPositionId(position.getPositionId());
				DungeonMgr.updatePlayerDungeonData(playerNode);

				// 如果是剧情战斗
				if (DungeonUtil.isPlotCombat(dungeonCfg))
				{
					// 取出战斗结果
					CombatResultAndReward combatResultAndReward =
						DungeonGlobeMgr.getInstance().getCombatResult(dungeonCfg.get_plotCombatFile());
					if (combatResultAndReward == null)
					{
						result = ClientProtocols.E_COMBAT_BATTLE_RECORD_ERROR_BAD_BATTLE_RECORD_COUNT;
						break;
					}
					else
					{
						QueryDungeonPlotCombatResultRes queryDungeonPlotCombatResultRes =
							new QueryDungeonPlotCombatResultRes(request.getCallback(), playerId, zoneId, dungeonId,
								difficultyType, sender, crsForClient, dungeonCfg, combatResultAndReward,cd);
						queryDungeonPlotCombatResultRes.handlerMessage();
						return HandlerAction.TERMINAL;

					}
				}

				// 构造player的战斗数据
				// int npcId = DungeonUtil.getNpcIdByPosition(position);
				CombatPlayer combatPlayer =
					GenCombatNormalPlayer.loadCombatPlayerForDongeon(playerNode, cd, position, npcId);
				if (combatPlayer == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FAILED_CREATE_COMBAT_PLAYER_FAILED;
					break;
				}
				// 构造NPC的战斗数据
				List<CombatPlayer> combatNpcs = GenCombatNpcPlayer.loadCombatNpc(zoneId, dungeonId, difficultyType, cd);
				if (combatNpcs == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FAILED_CREATE_COMBAT_NPCS_FAILED;
					break;
				}
				// 创建QueryDungeonCombatResultRes
				QueryDungeonCombatResultRes queryDungeonCombatResultRes =
					new QueryDungeonCombatResultRes(request.getCallback(), playerId, zoneId, dungeonId, difficultyType,
						sender, crsForClient, dungeonCfg, npcId, cd);
				int sequenceId = ServerDataGS.asyncClient.getSequenceId();
				// 构建CombatData
				CombatData combatData = new CombatData();
				for (CombatPlayer combatNpc : combatNpcs)
				{
					// add player
					combatData.addPlayer(combatPlayer);
					// add npcs
					String displayName = cd.get_AssetDescConfig().GetAssetDescById(request.getDungeonId()).get_name();
					combatNpc.setDisplayName(displayName);
					combatData.addPassivePlayers(combatNpc);
				}
				combatData.setSequenceId(sequenceId);
				combatData.setIsLoseAutoSkip(1);
				combatData.setSceneId(dungeonCfg.get_sceneId());
				combatData.setMaxRoundWin(maxRoundWhoWin);
				combatData.setMaxRecordCount(dungeonCfg.get_maxRound());
				combatData.setCd(cd);
				// 向战斗服务器发送数据
				ServerDataGS.asyncClient.send(combatData, queryDungeonCombatResultRes);

				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					BPUtil.activity(playerNode, zoneCfg.get_activityId());
				}

				return HandlerAction.TERMINAL;
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}
		builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}

	private int getLogEventId(CampaignConfig campaignCfg, int zoneId)
	{
		if (campaignCfg.IsActivityZoneId(zoneId))
		{
			return KodLogEvent.DungeonLogic_Combat_Secret;
		}
		else
		{
			return KodLogEvent.DungeonLogic_Combat;
		}
	}
}
