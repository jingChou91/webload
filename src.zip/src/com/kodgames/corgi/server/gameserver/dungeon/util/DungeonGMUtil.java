package com.kodgames.corgi.server.gameserver.dungeon.util;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._DungeonStatus;
import ClientServerCommon._ZoneStatus;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dungeon.data.Dungeon;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonData;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonMgr;
import com.kodgames.gamedata.player.PlayerNode;

public class DungeonGMUtil
{
	// GM工具开启副本()
	public static boolean openAllDungeon(Integer playerId, Integer stars, int zoneId, int difficulty)
	{
		if (stars != 1 && stars != 2 && stars != 3)
		{
			stars = 1;
		}
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CampaignConfig campaignConfig = cd.get_CampaignConfig();
		PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
		// 开启所有章节
		if (zoneId == 0)
		{
			// 历练
			for (int i = 0; i < campaignConfig.Get_zonesCount(); i++)
			{
				// 开启指定章节
				Integer zoneId_tmp = (Integer)campaignConfig.Get_zonesByIndex(i).get_zoneId();
				if (!openZone(playerNode, campaignConfig, zoneId_tmp, difficulty, stars))
				{
					return false;
				}
			}
			// 秘境
			for (int i = 0; i < campaignConfig.Get_secretZonesCount(); i++)
			{
				// 开启指定章节
				Integer zoneId_tmp = (Integer)campaignConfig.Get_secretZonesByIndex(i).get_zoneId();
				if (!openZone(playerNode, campaignConfig, zoneId_tmp, difficulty, stars))
				{
					return false;
				}
			}
		}
		// 指定章节
		else
		{
			// 开启指定章节 历练/秘境二合一(因为通过zoneId可直接取得章节)
			if (!openZone(playerNode, campaignConfig, zoneId, difficulty, stars))
			{
				return false;
			}
		}
		return true;
	}

	// 开启指定章节
	private static boolean openZone(PlayerNode playerNode, CampaignConfig campaignConfig, Integer zoneId,
		Integer difficulty, Integer stars)
	{
		CampaignConfig.Zone zoneCfg = campaignConfig.GetZoneById(zoneId);
		if (zoneCfg == null)
		{
			return false;
		}
		DungeonMgr.updateZoneStatus(playerNode, zoneId, _ZoneStatus.ZoneComplete);
		// 所有难度
		if (difficulty == 0)
		{
			// 每个难度信息
			for (int j = 0; j < zoneCfg.Get_dungeonDifficultiesCount(); j++)
			{
				// 开启指定章节和难度下的所有关卡
				CampaignConfig.DungeonDifficulty dungeonDifficulty = zoneCfg.Get_dungeonDifficultiesByIndex(j);
				openDifficulty(playerNode, campaignConfig, zoneCfg, dungeonDifficulty, stars);
			}
		}
		// 指定难度
		else
		{
			// 开启指定章节和难度下的所有关卡
			CampaignConfig.DungeonDifficulty dungeonDifficulty = zoneCfg.GetDungeonDifficultyByDifficulty(difficulty);
//			if (dungeonDifficulty == null)
//			{
//				return false;
//			}
			openDifficulty(playerNode, campaignConfig, zoneCfg, dungeonDifficulty, stars);
		}
		return true;
	}

	// 开启指定难度
	private static void openDifficulty(PlayerNode playerNode, CampaignConfig campaignConfig,
		CampaignConfig.Zone zoneCfg, CampaignConfig.DungeonDifficulty dungeonDifficulty, Integer stars)
	{
		if (dungeonDifficulty != null)
		{
			// 每个关卡信息
			for (int k = 0; k < dungeonDifficulty.Get_dungeonsCount(); k++)
			{
				// 开启指定关卡
				Integer dungeonId = dungeonDifficulty.Get_dungeonsByIndex(k).get_dungeonId();
				openDungeon(playerNode, zoneCfg.get_zoneId(), dungeonId, stars, campaignConfig);
			}
		}
	}

	// 开启指定关卡
	private static void openDungeon(PlayerNode playerNode, int zoneId, Integer dungeonId, Integer stars,
		CampaignConfig campaignConfig)
	{
		DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
		Dungeon dungeon = dungeonData.getDungeonById(dungeonId);
		if (dungeon != null && dungeon.getBestRecord() < stars)
		{
			dungeon.setBestRecord(stars);
			dungeon.setStatus(_DungeonStatus.UnLockState);
		}
		else
		{
			dungeon =Dungeon.createOpenDungeon(zoneId, dungeonId, stars);
		}
		DungeonMgr.updateDungeon(playerNode, dungeon);
		// 激活云游商人
		CampaignConfig.TravelTrader travelTraderCfg = campaignConfig.GetTravelTradeByDungeonId(dungeonId);
		if (travelTraderCfg != null)
		{
			if (stars >= travelTraderCfg.get_openNeedStars())
			{
				DungeonMgr.openTravel(playerNode, dungeonId);
			}
		}
	}
}
