package com.kodgames.corgi.server.gameserver.dungeon.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryTravelReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryTravelRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dungeon.ActivityHandleSecretManager;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonData;
import com.kodgames.corgi.server.gameserver.dungeon.data.Travel;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_QueryTravelReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_QueryTravelReqHandler.class);
	private ActivityHandleSecretManager activityHandleSecretManager = null;
	public CG_QueryTravelReqHandler(ActivityHandleSecretManager activityHandleSecretManager)
	{
		this.activityHandleSecretManager = activityHandleSecretManager;
	}
	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_QueryTravelReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_QueryTravelReq request = (CG_QueryTravelReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryTravelRes.Builder builder = GC_QueryTravelRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_TRAVEL_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_QUERY_TRAVEL_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		int dungeonId = request.getDungeonId();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_TRAVEL_LOAD_PLAYER_FAILED;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.TravelTrader))
				{
					result = ClientProtocols.E_GAME_TRAVEL_TRADER_FUNCTION_NOT_OPEN;
					break;
				}
				CampaignConfig campaignCfg = cd.get_CampaignConfig();
				if (campaignCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_TRAVEL_LOAD_CAMPAIGN_CONFIG_FAILED;
					break;
				}
				CampaignConfig.Dungeon dungeonCfg = campaignCfg.GetDungeonById(dungeonId);
				if (dungeonCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_TRAVEL_LOAD_DUNGEON_CONFIG_FAILED;
					break;
				}
				int zoneId = dungeonCfg.get_ZoneId();
				CampaignConfig.Zone zoneCfg = cd.get_CampaignConfig().GetZoneById(zoneId);
				if (zoneCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_TRAVEL_LOAD_ZONE_CONFIG_FAILED;
					break;
				}
				//判断秘境是否开启
				if(campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!activityHandleSecretManager.isActivityActivate(zoneCfg.get_activityId(), playerNode))
					{
						result = ClientProtocols.E_GAME_QUERY_TRAVEL_SECRET_ZONE_NOT_OPEN_FAILED;
						break;
					}
				}
				CampaignConfig.TravelTrader travelTraderCfg = campaignCfg.GetTravelTradeByDungeonId(dungeonId);
				if (travelTraderCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_TRAVEL_LOAD_TRAVEL_TRADER_CONFIG_FAILED;
					break;
				}
				if (!playerNode.getPlayerInfo().getDungeonData().getZones().containsKey(zoneId))
				{
					result = ClientProtocols.E_GAME_QUERY_TRAVEL_NOT_HAVE_ZONE_INFO_FAILED;
					break;
				}
				DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
				// 返回云游商人信息
				Travel travel = dungeonData.getTravels().get(dungeonId);
				if (travel != null)
				{
					builder.setTravelData(travel.toProtoBuffer(campaignCfg,dungeonId));
				}

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
