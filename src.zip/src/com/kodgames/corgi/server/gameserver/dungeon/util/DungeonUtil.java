package com.kodgames.corgi.server.gameserver.dungeon.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.GameConfig;
import ClientServerCommon.VipConfig;
import ClientServerCommon._DungeonDifficulity;
import ClientServerCommon._ZoneStatus;

import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.dungeon.data.Dungeon;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonData;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class DungeonUtil
{
	// 补偿首次通关奖励---(因为上线后修改过首通奖励)
	public static void firstPassCompensate(PlayerNode playerNode, ConfigDatabase cd)
	{
		CampaignConfig campaignCfg = cd.get_CampaignConfig();
		DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
		Reward reward = new Reward();
		for (int i = 0; i < campaignCfg.Get_zonesCount(); i++)
		{
			Integer zoneId = (Integer)campaignCfg.Get_zonesByIndex(i).get_zoneId();
			if (dungeonData.getZones().get(zoneId) == null)
			{
				continue;
			}
			// 每个难度信息
			for (int j = 0; j < campaignCfg.Get_zonesByIndex(i).Get_dungeonDifficultiesCount(); j++)
			{
				ClientServerCommon.CampaignConfig.DungeonDifficulty dungeonDifficulty =
					campaignCfg.Get_zonesByIndex(i).Get_dungeonDifficultiesByIndex(j);
				if (dungeonDifficulty == null)
				{
					continue;
				}
				for (int k = 0; k < dungeonDifficulty.Get_dungeonsCount(); k++)
				{
					int difficultyType = dungeonDifficulty.get_difficultyType();
					Integer dungeonId = dungeonDifficulty.Get_dungeonsByIndex(k).get_dungeonId();
					Dungeon dungeon = dungeonData.getDungeonById(dungeonId);
					// 只返回有数据的关卡信息.
					if (dungeon != null && dungeon.getBestRecord() > 0)
					{
						// 获得奖励
						switch (difficultyType)
						{
							case _DungeonDifficulity.Common:
							{
								reward.megerReward(new Reward().fromIdAndCount(117506050, 2, 0, 0, 0));
								break;
							}
							case _DungeonDifficulity.Hard:
							{
								reward.megerReward(new Reward().fromIdAndCount(117506049, 1, 0, 0, 0));
								break;
							}
							case _DungeonDifficulity.Nightmare:
							{
								reward.megerReward(new Reward().fromIdAndCount(117571666, 1, 0, 0, 0));
								break;
							}
						}

					}
				}

			}
		}
		CostAndRewardManager.addReward(playerNode,
			reward,
			cd,
			KodLogEvent.DungeonLogic_DungeonFirstPassRewardCompensate);

	}

	// 判断前置关卡是否已经通关(只判断前置关卡知否通关,没有前置关卡的直接返回true(比如序章第一关,各章hard难度的第一关))
	public static boolean isPreDungeonComplete(CampaignConfig campaignCfg, DungeonData dungeonData, int dungeonId)
	{
		CampaignConfig.Dungeon dungeonCfg = campaignCfg.GetDungeonById(dungeonId);
		{
			if (dungeonCfg == null)
			{
				return false;
			}
		}
		int difficulty = dungeonCfg.get_DungeonDifficulty();
		boolean isPreDungeonOpen = true;// 默认true,表示没有前置关卡时,直接返回true(比如序章第一关,各章hard难度的第一关)
		for (int i = 0; i < campaignCfg.Get_zonesCount(); i++)
		{
			// 如果不是普通难度,那么每章单独初始化
			if (difficulty != _DungeonDifficulity.Common)
			{
				isPreDungeonOpen = true;// 默认true,表示没有前置关卡时,直接返回true(比如序章第一关,各章hard难度的第一关)
			}
			ClientServerCommon.CampaignConfig.Zone zoneCfg = campaignCfg.Get_zonesByIndex(i);
			ClientServerCommon.CampaignConfig.DungeonDifficulty dungeonDifficulty =
				zoneCfg.GetDungeonDifficultyByDifficulty(difficulty);
			if (dungeonDifficulty != null)
			{
				for (int k = 0; k < dungeonDifficulty.Get_dungeonsCount(); k++)
				{
					ClientServerCommon.CampaignConfig.Dungeon dungeonCfg_tmp = dungeonDifficulty.Get_dungeonsByIndex(k);
					if (dungeonId == dungeonCfg_tmp.get_dungeonId())
					{
						return isPreDungeonOpen;
					}
					Dungeon dungeon = dungeonData.getDungeonById(dungeonCfg_tmp.get_dungeonId());
					// 无信息或者未通关都返回false
					if (dungeon == null || dungeon.getBestRecord() < 1)
					{
						isPreDungeonOpen = false;
					}
					else
					{
						isPreDungeonOpen = true;
					}
				}
			}
		}
		return false;
	}

	public static int getFirstDungeonId(CampaignConfig campaignCfg)
	{
		return campaignCfg.Get_zonesByIndex(0).Get_dungeonDifficultiesByIndex(0).Get_dungeonsByIndex(0).get_dungeonId();
	}

	/**
	 * 历练返回2,秘境返回1
	 */
	public static int getDungeonType(CampaignConfig campaignCfg, int zoneId)
	{
		return campaignCfg.IsActivityZoneId(zoneId) ? 1 : 2;
	}

	/**
	 * 判断关卡是否剧情战斗关卡
	 */
	public static boolean isPlotCombat(CampaignConfig.Dungeon dungeonCfg)
	{
		String fileName = dungeonCfg.get_plotCombatFile();
		if (fileName != null && !fileName.equals(""))
		{
			return true;
		}
		return false;
	}

	public static boolean checkZoneStatus(int zoneStatus, boolean isActivity)
	{
		if (isActivity)
		{
			if (zoneStatus == _ZoneStatus.UnlockAnimation)
			{
				return false;
			}
			return true;
		}
		else
		{
			if (zoneStatus == _ZoneStatus.UnlockAnimation || zoneStatus == _ZoneStatus.PlotDialogue)
			{
				return false;
			}
			return true;
		}
	}

	// 根据vip等级和关卡id计算出该关卡的最大可重置次数
	public static int getMaxDungeonResetCount(ClientServerCommon.VipConfig vipCfg, CampaignConfig.Dungeon dungeonCfg,
		PlayerNode playerNode, int dungeonId, boolean isSecret)
	{
		int vipLevel = playerNode.getGamePlayer().getVipLevel();
		int count = dungeonCfg.get_resetCount();
		if (isSecret)
		{
			switch (dungeonCfg.get_DungeonDifficulty())
			{
				case _DungeonDifficulity.Common:
					count +=
						vipCfg.GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.DungeonSecretAddCommonResetCount);
					break;
				case _DungeonDifficulity.Hard:
					count +=
						vipCfg.GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.DungeonSecretAddHardResetCount);
					break;
				case _DungeonDifficulity.Nightmare:
					count +=
						vipCfg.GetVipLimitByVipLevel(vipLevel,
							VipConfig._VipLimitType.DungeonSecretAddNightmareResetCount);
					break;
			}
		}
		else
		{
			switch (dungeonCfg.get_DungeonDifficulty())
			{
				case _DungeonDifficulity.Common:
					count += vipCfg.GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.DungeonAddCommonResetCount);
					break;
				case _DungeonDifficulity.Hard:
					count += vipCfg.GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.DungeonAddHardResetCount);
					break;
				case _DungeonDifficulity.Nightmare:
					count +=
						vipCfg.GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.DungeonAddNightmareResetCount);
					break;
			}
		}
		return count;

	}

	// 获取副本上次使用的阵容id
	public static int getLastPositionId(PlayerNode playerNode)
	{
		int positionId = playerNode.getPlayerInfo().getDungeonData().getLastPositionId();
		if (positionId == 0)
		{
			positionId = playerNode.getPlayerInfo().getPositionData().getMasterPositionId();
		}
		return positionId;
	}

	// 根据阵容查询npcId
	public static int getNpcAvatarIdByPosition(CommonProtocols.Position position)
	{
		for (CommonProtocols.Location location : position.getAvatarLocationsList())
		{
			if (location.getGuid() == null || location.getGuid() == "")
			{
				return location.getRecourseId();
			}
		}
		return 0;
	}

	// 判断该关卡是否已通关
	public static boolean checkDungeonPass(PlayerNode playerNode, int dungeonId)
	{
		Dungeon dungeon = playerNode.getPlayerInfo().getDungeonData().getDungeonById(dungeonId);
		if (dungeon == null || dungeon.getBestRecord() <= 0)
		{
			return false;
		}
		return true;
	}

	// 计算可扫荡次数
	public static int getContinueCombatCount(CampaignConfig.Dungeon dungeonCfg,
		GameConfig.ContinueCombat continueCombatCfg, Dungeon dungeon, PlayerNode playerNode)
	{
		List<Integer> continueCount = new ArrayList<Integer>();
		// 配置最大可扫荡次数
		continueCount.add(continueCombatCfg.get_maxContinueCombatCount());
		// 剩余可进入次数
		continueCount.add(dungeonCfg.get_enterCount() - dungeon.getTodayCompleteTimes());
		// 剩余体力
		for (int i = 0; i < dungeonCfg.Get_enterCostsCount(); i++)
		{
			ClientServerCommon.Cost costCfg = dungeonCfg.Get_enterCostsByIndex(i);
			int costId = costCfg.get_id();
			int typeId = ClientServerCommon.IDSeg.ToAssetType(costId);
			switch (typeId)
			{
				case ClientServerCommon.IDSeg._AssetType.Special:
					if (costId == ClientServerCommon.IDSeg._SpecialId.Stamina)
					{
						continueCount.add(playerNode.getGamePlayer().getStamina().getStamina() / costCfg.get_count());
					}
					break;
				case ClientServerCommon.IDSeg._AssetType.Item:
					int amount = playerNode.getPlayerInfo().getConsumableData().getConsumableAmount(costId);
					continueCount.add(amount / costCfg.get_count());
					break;

				default:
					break;
			}
		}

		if (continueCount.size() > 0)
		{
			return Collections.min(continueCount);
		}
		return 0;
	}

	// 检测消耗是否足够
	public static boolean checkCost(CampaignConfig.Dungeon dungeonCfg, PlayerNode playerNode, Cost cost)
	{
		// 检测消耗
		for (int i = 0; i < dungeonCfg.Get_enterCostsCount(); i++)
		{
			ClientServerCommon.Cost costCfg = dungeonCfg.Get_enterCostsByIndex(i);
			int costId = costCfg.get_id();
			int typeId = ClientServerCommon.IDSeg.ToAssetType(costId);
			switch (typeId)
			{
				case ClientServerCommon.IDSeg._AssetType.Special:
					if (costId == ClientServerCommon.IDSeg._SpecialId.Stamina)
					{
						if (playerNode.getGamePlayer().getStamina().getStamina() < costCfg.get_count())
						{
							cost.setId(costCfg.get_id());
							cost.setCount(costCfg.get_count());
							return false;
						}
					}
					break;

				case ClientServerCommon.IDSeg._AssetType.Item:
					int amount = playerNode.getPlayerInfo().getConsumableData().getConsumableAmount(costId);
					if (amount < costCfg.get_count())
					{
						cost.setId(costCfg.get_id());
						cost.setCount(costCfg.get_count());
						return false;
					}
					break;

				default:
					break;
			}
		}
		return true;
	}
}

// // 秘境章节
// {
// int minZoneId = campaignConfig.Get_secretZonesByIndex(0).get_zoneId();
// for (int i = 0; i < campaignConfig.Get_secretZonesCount(); i++)
// {
// int zoneId = campaignConfig.Get_secretZonesByIndex(i).get_zoneId();
// DungeonMgr.updateZoneStatus(playerNode, zoneId, _ZoneStatus.UnlockAnimation);
// if (minZoneId > zoneId)
// {
// minZoneId = zoneId;
// }
// }
// // 修改第一个章节的状态
// DungeonMgr.updateZoneStatus(playerNode, minZoneId, _ZoneStatus.PlotDialogue);
// }
