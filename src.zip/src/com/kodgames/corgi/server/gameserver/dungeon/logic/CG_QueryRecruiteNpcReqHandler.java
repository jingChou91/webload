package com.kodgames.corgi.server.gameserver.dungeon.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.AvatarConfig;
import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.combat.record.Attribute;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols.RecruiteNpc;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryRecruiteNpcReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryRecruiteNpcRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dungeon.ActivityHandleSecretManager;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_QueryRecruiteNpcReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_QueryRecruiteNpcReqHandler.class);
	private ActivityHandleSecretManager activityHandleSecretManager = null;
	public CG_QueryRecruiteNpcReqHandler(ActivityHandleSecretManager activityHandleSecretManager)
	{
		this.activityHandleSecretManager = activityHandleSecretManager;
	}
	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_QueryRecruiteNpcReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_QueryRecruiteNpcReq request = (CG_QueryRecruiteNpcReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryRecruiteNpcRes.Builder builder = GC_QueryRecruiteNpcRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_RECRUITE_NPC_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_QUERY_RECRUITE_NPC_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		int dungeonId = request.getDungeonId();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_RECRUITE_NPC_LOAD_PLAYER_INFO_FAILED;
					break;
				}
				CampaignConfig campaignCfg = cd.get_CampaignConfig();
				if (campaignCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_RECRUITE_NPC_LOAD_CAMPAIGN_CONFIG_FAILED;
					break;
				}
				CampaignConfig.Dungeon dungeonCfg = campaignCfg.GetDungeonById(dungeonId);
				if (dungeonCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_RECRUITE_NPC_LOAD_DUNGEON_CONFIG_FAILED;
					break;
				}
				int zoneId = dungeonCfg.get_ZoneId();
				CampaignConfig.Zone zoneCfg = cd.get_CampaignConfig().GetZoneById(zoneId);
				if (zoneCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_RECRUITE_NPC_LOAD_ZONE_CONFIG_FAILED;
					break;
				}
				// 判断秘境是否开启
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!activityHandleSecretManager.isActivityActivate(zoneCfg.get_activityId(), playerNode))
					{
						result = ClientProtocols.E_GAME_QUERY_RECRUITE_NPC_SECRET_NOT_OPEN_FAILED;
						break;
					}
				}
                //处理每一个剧情npc
				ClientServerCommon.NpcConfig npcConfig = cd.get_NpcConfig();
				for (int i = 0; i < dungeonCfg.Get_employableNpcsCount(); i++)
				{
					int npcId = dungeonCfg.Get_employableNpcsByIndex(i);
					ClientServerCommon.NpcConfig.Npc npcCfg = npcConfig.GetNpcById(npcId);
					if(npcCfg == null)
					{
						logger.error("NPCId = {} error------------------------------------------------------------error----------------------error", npcId);
						result = ClientProtocols.E_GAME_QUERY_RECRUITE_NPC_LOAD_DUNGEON_CONFIG_FAILED;
						break;
					}
					RecruiteNpc.Builder recruiteNpcBuilder = RecruiteNpc.newBuilder();
					recruiteNpcBuilder.setNpcId(npcId);
					recruiteNpcBuilder.setAvatarId(npcCfg.get_avatarId());
					recruiteNpcBuilder.setLevel(npcCfg.get_level());
					recruiteNpcBuilder.setName(npcCfg.get_name());
					recruiteNpcBuilder.setTraitType(npcCfg.get_traitType());
					recruiteNpcBuilder.setBreakthroughLevel(npcCfg.get_breakthroughLevel());
					recruiteNpcBuilder.setQualityType(npcCfg.get_qualityType());
					
					AvatarConfig.Avatar avatarCfg = cd.get_AvatarConfig().GetAvatarById(npcCfg.get_avatarId());
					recruiteNpcBuilder.setNpcDesc(avatarCfg.get_npcDesc());
					for (int j = 0; j < npcCfg.Get_skillsCount(); j++)
					{
						recruiteNpcBuilder.addSkillIds(npcCfg.Get_skillsByIndex(j).get_id());
					}
					for (int j = 0; j < npcCfg.Get_attribsCount(); j++)
					{
						ClientServerCommon.Attribute attributeCfg = npcCfg.Get_attribsByIndex(j);
						Attribute attribute = new Attribute();
						attribute.setType(attributeCfg.get_type());
						attribute.setValue(attributeCfg.get_value());
						recruiteNpcBuilder.addAttributes(attribute.toProtobuf());
					}
					recruiteNpcBuilder.build();
					builder.addRecruiteNpcs(recruiteNpcBuilder);
				}
				if(result != ClientProtocols.E_GAME_QUERY_RECRUITE_NPC_SUCCESS)
				{
					break;
				}

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}

}
