package com.kodgames.corgi.server.gameserver.dungeon.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_SetDungeonDialogStateReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_SetDungeonDialogStateRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dungeon.ActivityHandleSecretManager;
import com.kodgames.corgi.server.gameserver.dungeon.data.Dungeon;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonData;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonMgr;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_SetDungeonDialogStateReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_SetDungeonDialogStateReqHandler.class);

	private ActivityHandleSecretManager activityHandleSecretManager = null;
	public CG_SetDungeonDialogStateReqHandler(ActivityHandleSecretManager activityHandleSecretManager)
	{
		this.activityHandleSecretManager = activityHandleSecretManager;
	}
	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_SetDungeonDialogStateReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_SetDungeonDialogStateReq request = (CG_SetDungeonDialogStateReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_SetDungeonDialogStateRes.Builder builder = GC_SetDungeonDialogStateRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_SET_DUNGEON_DIALOG_STATE_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_SET_DUNGEON_DIALOG_STATE_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		int dungeonId = request.getDungeonId();
		int dialogState = request.getDialogState();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_SET_DUNGEON_DIALOG_STATE_LOAD_PLAYER_FAILED;
					break;
				}
				CampaignConfig campaignCfg = cd.get_CampaignConfig();
				if (campaignCfg == null)
				{
					result = ClientProtocols.E_GAME_SET_DUNGEON_DIALOG_STATE_LOAD_CAMPAIGN_CONFIG_FAILED;
					break;
				}
				CampaignConfig.Dungeon dungeonCfg = campaignCfg.GetDungeonById(dungeonId);
				if (dungeonCfg == null)
				{
					result = ClientProtocols.E_GAME_SET_DUNGEON_DIALOG_STATE_LOAD_DUNGEON_CONFIG_FAILED;
					break;
				}
				int zoneId = dungeonCfg.get_ZoneId();
				CampaignConfig.Zone zoneCfg = cd.get_CampaignConfig().GetZoneById(zoneId);
				if (null == zoneCfg)
				{
					result = ClientProtocols.E_GAME_SET_DUNGEON_DIALOG_STATE_LOAD_ZONE_CONFIG_FAILED;
					break;
				}
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Secret))
					{
						result = ClientProtocols.E_GAME_SECRET_FUNCTION_NOT_OPEN;
						break;
					}
				}
				else
				{
					if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Dungeon))
					{
						result = ClientProtocols.E_GAME_DUNGEON_FUNCTION_NOT_OPEN;
						break;
					}
				}
				//判断秘境是否开启
				if(campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!activityHandleSecretManager.isActivityActivate(zoneCfg.get_activityId(), playerNode))
					{
						result = ClientProtocols.E_GAME_SET_DUNGEON_DIALOG_STATE_SECRET_ZONE_NOT_OPEN_FAILED;
						break;
					}
				}
				if (!playerNode.getPlayerInfo().getDungeonData().getZones().containsKey(zoneId))
				{
					result = ClientProtocols.E_GAME_SET_DUNGEON_DIALOG_STATE_NOT_HAVE_ZONE_INFO_FAILED;
					break;
				}
				DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();

				// 修改player表上的信息
				// 保存最后一场副本Id
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					dungeonData.setLastSecretZoneId(zoneId);
					dungeonData.setLastSecretDungeonId(dungeonId);
				}
				else
				{
					dungeonData.setLastZoneId(zoneId);
					dungeonData.setLastDungeonId(dungeonId);
				}
				DungeonMgr.updatePlayerDungeonData(playerNode);
				// 如果是第一次进入副本初始数据
				if (dungeonData.getDungeonById(dungeonId) == null)
				{
					result = ClientProtocols.E_GAME_SET_DUNGEON_DIALOG_STATE_NOT_HAVE_DUNGEON_INFO_FAILED;
					break;
				}
				else
				{
					// 执行更新
					Dungeon dungeon = dungeonData.getDungeonById(dungeonId);
					dungeon.setDialogState(dialogState);
					DungeonMgr.updateDungeon(playerNode, dungeon);
				}

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}

}
