package com.kodgames.corgi.server.gameserver.dungeon.util;

import java.util.ArrayList;
import java.util.List;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._ActivityType;
import ClientServerCommon._DungeonDifficulity;
import ClientServerCommon._ZoneStatus;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityMgr;
import com.kodgames.corgi.server.gameserver.dungeon.data.Dungeon;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonData;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;

public class DungeonAssistantUtil
{
	/*
	 * 有未通关关卡,无法挑战新关卡(等级不够,章节未开启等),体力足够挑战最后一章节的第一关. (返回0表示不满足条件,非0则为可打关卡ID)
	 */
	public static Integer isDungeonLittleGod(PlayerNode playerNode, int stamina)
	{
		// 所有关卡全部通关,直接返回0
		if (canCombatEveryDungeon(playerNode, stamina))
		{
			return 0;
		}
		// 获取副本相关信息
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerNode.getPlayerId());
		CampaignConfig campaignCfg = cd.get_CampaignConfig();
		DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
		if (dungeonData.getZones().size() == 0)
		{
			return 0;
		}
		// 需要挑战的关卡id
		Integer needDungeonId = 0;
		// 是否无法挑战新关卡
		boolean canCombatLastZoneFirstDungeon = true;
		// 循环处理每一个章节
		for (int i = 0; i < campaignCfg.Get_zonesCount(); i++)
		{
			// 章节信息
			ClientServerCommon.CampaignConfig.Zone zoneCfg = campaignCfg.Get_zonesByIndex(i);
			for (int j = 0; j < zoneCfg.Get_dungeonDifficultiesCount(); j++)
			{
				// 难度信息
				ClientServerCommon.CampaignConfig.DungeonDifficulty dungeonDifficulty =
					zoneCfg.Get_dungeonDifficultiesByIndex(j);
				if (dungeonDifficulty != null)
				{
					// 普通关卡的第一关特殊对待(需要额外判断该章节是否开启)
					int k = 0;
					int difficulty = dungeonDifficulty.get_difficultyType();
					if (difficulty == _DungeonDifficulity.Nightmare)
					{
						break;
					}
					if (difficulty == _DungeonDifficulity.Common)
					{
						ClientServerCommon.CampaignConfig.Dungeon dungeonCfg = dungeonDifficulty.Get_dungeonsByIndex(k);
						Dungeon dungeon = dungeonData.getDungeonById(dungeonCfg.get_dungeonId());
						if (dungeon == null || dungeon.getBestRecord() < 1)
						{
							// 判断章节是否开启
							Integer zoneStatus = dungeonData.getZones().get(zoneCfg.get_zoneId());
							if (zoneStatus == null
								|| (zoneStatus != _ZoneStatus.PlotDialogue && zoneStatus != _ZoneStatus.ZoneProceed))
							{
								// 章节尚未开启,直接返回上一个章节的处理结果************出口a
								if (canCombatLastZoneFirstDungeon)
								{
									return needDungeonId;
								}
								return 0;

							}
							// 判断体力和级别是否满足进入关卡要求
							if (checkStaminaAndLevel(dungeonCfg, stamina, playerNode.getGamePlayer().getLevel()))
							{
								return 0;
							}
							else
							{
								// 如果章节开启,第一关未通关,且不满足挑战条件****************出口b
								if (canCombatLastZoneFirstDungeon)
								{
									return needDungeonId;
								}
								return 0;
							}

						}
						// 如果关卡已通关,并且满足体力和等级要求,刷新neetDungeonId
						if (checkStaminaAndLevel(dungeonCfg, stamina, playerNode.getGamePlayer().getLevel()))
						{
							needDungeonId = dungeonCfg.get_dungeonId();
						}
						else
						{
							// 如果关卡已通关,但是体力或者等级不满足需求
							canCombatLastZoneFirstDungeon = false;
						}
						k++;
					}
					// 每个关卡信息
					for (; k < dungeonDifficulty.Get_dungeonsCount(); k++)
					{
						ClientServerCommon.CampaignConfig.Dungeon dungeonCfg = dungeonDifficulty.Get_dungeonsByIndex(k);
						Dungeon dungeon = dungeonData.getDungeonById(dungeonCfg.get_dungeonId());
						// 无信息或者未通关都返回false
						if (dungeon == null || dungeon.getBestRecord() < 1)
						{
							// 进入Hard难度的前提是common完成
							if (difficulty == _DungeonDifficulity.Hard)
							{
								Integer zoneStatus = dungeonData.getZones().get(zoneCfg.get_zoneId());
								if (zoneStatus == null || zoneStatus != _ZoneStatus.ZoneComplete)
								{
									// 章节未通关,忽略精英难度处理
									break;
								}
							}
							// 判断体力和级别是否满足进入关卡要求
							if (checkStaminaAndLevel(dungeonCfg, stamina, playerNode.getGamePlayer().getLevel()))
							{
								// 有可挑战的新关卡,返回0
								return 0;
							}
							// 未打关卡不满足攻打条件,忽略该难度其他关卡处理
							break;
						}
					}
				}
			}

		}
		if (canCombatLastZoneFirstDungeon)
		{
			return needDungeonId;
		}
		return 0;

	}

	// 判断玩家是否已经通关所有普通和精英历练
	public static boolean canCombatEveryDungeon(PlayerNode playerNode, int stamina)
	{
		// 获取副本相关信息
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerNode.getPlayerId());
		CampaignConfig campaignCfg = cd.get_CampaignConfig();
		DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
		if (dungeonData.getZones() == null || dungeonData.getZones().size() == 0)
		{
			return false;
		}
		// 最大章节信息
		ClientServerCommon.CampaignConfig.Zone maxZoneCfg = null;
		Integer maxZoneId = 0;
		// 循环处理每一个章节(如果所有章节的普通和精英关卡都通关,获取最大章节信息)
		for (int i = 0; i < campaignCfg.Get_zonesCount(); i++)
		{
			// 章节信息
			ClientServerCommon.CampaignConfig.Zone zoneCfg = campaignCfg.Get_zonesByIndex(i);
			Integer zoneId = (Integer)zoneCfg.get_zoneId();
			// 保存最大章节信息
			if (dungeonData.getZones().get(zoneId) == null)
			{
				return false;
			}
			if (maxZoneId < zoneId)
			{
				maxZoneId = zoneId;
				maxZoneCfg = zoneCfg;
			}
			// 每个难度信息
			for (int j = 0; j < zoneCfg.Get_dungeonDifficultiesCount(); j++)// GetDungeonDifficultyCount()
			{
				ClientServerCommon.CampaignConfig.DungeonDifficulty dungeonDifficulty =
					zoneCfg.Get_dungeonDifficultiesByIndex(j);// GetDungeonDifficulty(j)
				if (dungeonDifficulty != null)
				{
					// 忽略宗师难度
					if (dungeonDifficulty.get_difficultyType() == _DungeonDifficulity.Nightmare)
					{
						continue;
					}
					// 每个关卡信息
					for (int k = 0; k < dungeonDifficulty.Get_dungeonsCount(); k++)
					{
						Integer dungeonId = dungeonDifficulty.Get_dungeonsByIndex(k).get_dungeonId();
						Dungeon dungeon = dungeonData.getDungeonById(dungeonId);
						// 无信息或者未通关都返回false
						if (dungeon == null || dungeon.getBestRecord() < 1)
						{
							return false;
						}
					}
				}
			}

		}
		// 最大章节的最小关卡信息
		ClientServerCommon.CampaignConfig.Dungeon minDungeonCfg = getMinDungeonCfg(maxZoneCfg);
		// 判断体力和级别是否满足进入关卡要求
		if (checkStaminaAndLevel(minDungeonCfg, stamina, playerNode.getGamePlayer().getLevel()))
		{
			return true;
		}
		return false;
	}

	// 获取最大可挑战历练关卡的Id
	public static int getMaxCanCombatDungeonId(PlayerNode playerNode, int stamina, int difficulty)
	{
		// 获取副本相关信息
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerNode.getPlayerId());
		CampaignConfig campaignCfg = cd.get_CampaignConfig();
		DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
		if (dungeonData.getZones().size() == 0)
		{
			if (difficulty == _DungeonDifficulity.Common)
			{
				return campaignCfg.Get_zonesByIndex(0)
					.GetDungeonDifficultyByDifficulty(_DungeonDifficulity.Common)
					.Get_dungeonsByIndex(0)
					.get_dungeonId();
			}
			return 0;
		}

		// 循环处理每一个章节(如果所有章节的普通和精英关卡都通关,获取最大章节信息)
		for (int i = 0; i < campaignCfg.Get_zonesCount(); i++)
		{
			// 章节信息
			ClientServerCommon.CampaignConfig.Zone zoneCfg = campaignCfg.Get_zonesByIndex(i);
			// 难度信息
			ClientServerCommon.CampaignConfig.DungeonDifficulty dungeonDifficulty =
				zoneCfg.GetDungeonDifficultyByDifficulty(difficulty);
			if (dungeonDifficulty != null)
			{
				// 普通关卡的第一关特殊对待(需要额外判断该章节是否开启)
				int k = 0;
				if (difficulty == _DungeonDifficulity.Common)
				{

					ClientServerCommon.CampaignConfig.Dungeon dungeonCfg = dungeonDifficulty.Get_dungeonsByIndex(k);
					Dungeon dungeon = dungeonData.getDungeonById(dungeonCfg.get_dungeonId());
					if (dungeon == null || dungeon.getBestRecord() < 1)
					{
						// 判断章节是否开启
						Integer zoneStatus = dungeonData.getZones().get(zoneCfg.get_zoneId());
						if (zoneStatus == null
							|| (zoneStatus != _ZoneStatus.PlotDialogue && zoneStatus != _ZoneStatus.ZoneProceed))
						{
							return 0;
						}
						// 判断体力和级别是否满足进入关卡要求
						if (checkStaminaAndLevel(dungeonCfg, stamina, playerNode.getGamePlayer().getLevel()))
						{
							return dungeonCfg.get_dungeonId();
						}
						return 0;
					}
					k++;

				}
				// 每个关卡信息
				for (; k < dungeonDifficulty.Get_dungeonsCount(); k++)
				{
					ClientServerCommon.CampaignConfig.Dungeon dungeonCfg = dungeonDifficulty.Get_dungeonsByIndex(k);
					Dungeon dungeon = dungeonData.getDungeonById(dungeonCfg.get_dungeonId());
					// 无信息或者未通关都返回false
					if (dungeon == null || dungeon.getBestRecord() < 1)
					{
						// 进入Hard难度的前提是common完成
						if (difficulty == _DungeonDifficulity.Hard || difficulty == _DungeonDifficulity.Nightmare)
						{
							Integer zoneStatus = dungeonData.getZones().get(zoneCfg.get_zoneId());
							if (zoneStatus == null || zoneStatus != _ZoneStatus.ZoneComplete)
							{
								return 0;
							}
						}
						// 进入Hard难度的前提是common完成
						if (difficulty == _DungeonDifficulity.Nightmare)
						{
							CampaignConfig.DungeonDifficulty hardDifficulty =
								zoneCfg.GetDungeonDifficultyByDifficulty(_DungeonDifficulity.Hard);
							for (int m = 0; m < hardDifficulty.Get_dungeonsCount(); m++)// GetDungeonCount()
							{
								if (!DungeonUtil.checkDungeonPass(playerNode, hardDifficulty.Get_dungeonsByIndex(m)
									.get_dungeonId()))// GetDungeon(i)
								{
									return 0;
								}
							}
						}
						// 判断体力和级别是否满足进入关卡要求
						if (checkStaminaAndLevel(dungeonCfg, stamina, playerNode.getGamePlayer().getLevel()))
						{
							return dungeonCfg.get_dungeonId();
						}
						return 0;
					}
				}
			}
		}
		return 0;
	}

	// 某章节有可挑战且未通关的关卡
	public static int getCanCombatSecretDifficulty(PlayerNode playerNode, int stamina, int zoneId, int easyDungeonId,
		int commonDungeonId)
	{
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerNode.getPlayerId());
		CampaignConfig campaignCfg = cd.get_CampaignConfig();
		DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
		if (dungeonData.getZones() == null || dungeonData.getZones().size() == 0)
		{
			return 0;
		}

		ClientServerCommon.CampaignConfig.Zone zoneCfg = campaignCfg.GetZoneById(zoneId);
		// 如果秘境活动开启中
		if (ActivityMgr.getInstance().checkIsStart(_ActivityType.SECRETACTIVIYT, zoneCfg.get_activityId(), playerNode))
		{
			int difficulty = 0;
			// 普通难度
			{
				difficulty = getCanCombatSecretDifficulty(zoneCfg, dungeonData, playerNode, cd, easyDungeonId, ClientServerCommon._DungeonDifficulity.Common);
				if (difficulty == ClientServerCommon._DungeonDifficulity.Common)
					return difficulty;

			}
			// 精英难度
			{
				difficulty = getCanCombatSecretDifficulty(zoneCfg, dungeonData, playerNode, cd, commonDungeonId, ClientServerCommon._DungeonDifficulity.Hard);
				if (difficulty == ClientServerCommon._DungeonDifficulity.Hard)
					return difficulty;

			}
		}
		return 0;

	}
	
	private static int getCanCombatSecretDifficulty(ClientServerCommon.CampaignConfig.Zone zoneCfg, DungeonData dungeonData, PlayerNode playerNode, ConfigDatabase cd, int dungeonId, int difficulty)
	{

		// 难度信息
		ClientServerCommon.CampaignConfig.DungeonDifficulty dungeonDifficulty =
			zoneCfg.GetDungeonDifficultyByDifficulty(difficulty);

		if (dungeonDifficulty != null)
		{
			//判断章节中所有挑战次数都已经用完
			boolean isMeet = false;
			for(int i = 0 ; i < dungeonDifficulty.Get_dungeonsCount() ; i++)
			{
				CampaignConfig.Dungeon dungeonCfg = dungeonDifficulty.Get_dungeonsByIndex(i);//GetDungeon(i)
				if (dungeonData.getDungeonById(dungeonCfg.get_dungeonId()) == null)
				{
					isMeet = true;
				}
				else
				{
					Dungeon dungeon = dungeonData.getDungeonById(dungeonCfg.get_dungeonId());
					// 判断是否需要刷新
					dungeon.refresh_DungeonCompleteTimes(cd, playerNode);
					if(dungeon.getTodayCompleteTimes() < dungeonCfg.get_enterCount())
					{
						isMeet = true;
					}
				}
			}
			
			if(isMeet )
			{
				ClientServerCommon.CampaignConfig.Dungeon dungeonCfg =
					dungeonDifficulty.GetDungeonById(dungeonId);

				if (dungeonCfg != null && dungeonCfg.get_levelLimit() <= playerNode.getGamePlayer().getLevel())
				{
					List<Cost> costs = new ArrayList<Cost>();
					for (int i = 0; i < dungeonCfg.Get_enterCostsCount(); i++)//GetEnterCostCount()
					{
						Cost cost = Cost.fromClientServerCommon(dungeonCfg.Get_enterCostsByIndex(i), 1, 1);
						costs.add(cost);
					}

					if (CostAndRewardManager.checkCosts(playerNode,
						costs,
						cd,
						KodLogEvent.AssistantLogic_Check,
						new Cost()))
					{
						return difficulty;
					}
				}
			}
			
		}
		return 0;

	
	}

	// 获取某个难度下有可领取宝箱时的zoneId
	public static int getZoneIdForPickBox(PlayerNode playerNode, int difficulty)
	{
		// 获取副本相关信息
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerNode.getPlayerId());
		CampaignConfig campaignCfg = cd.get_CampaignConfig();
		DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
		if (dungeonData.getZones() == null || dungeonData.getZones().size() == 0)
		{
			return 0;
		}
		// 循环处理每一个章节
		for (int i = 0; i < campaignCfg.Get_zonesCount(); i++)
		{
			ClientServerCommon.CampaignConfig.Zone zoneCfg = campaignCfg.Get_zonesByIndex(i);
			int zoneId = zoneCfg.get_zoneId();

			// 计算该难度的总星星数
			int totalStars = 0;
			ClientServerCommon.CampaignConfig.DungeonDifficulty dungeonDifficulty =
				zoneCfg.GetDungeonDifficultyByDifficulty(difficulty);
			if (dungeonDifficulty != null)
			{
				for (int k = 0; k < dungeonDifficulty.Get_dungeonsCount(); k++)
				{
					Integer dungeonId = dungeonDifficulty.Get_dungeonsByIndex(k).get_dungeonId();
					Dungeon dungeon = dungeonData.getDungeonById(dungeonId);
					// 无信息或者未通关都返回false
					if (dungeon != null)
					{
						totalStars += dungeon.getBestRecord();
					}
				}
				// 判断是否满足领取宝箱条件,并且是否已经领取
				for (int k = 0; k < dungeonDifficulty.Get_starRewardConditionsCount(); k++)
				{
					if (totalStars >= dungeonDifficulty.Get_starRewardConditionsByIndex(k).get_requireStarCount())
					{
						if (!dungeonData.checkBoxRewardPicked(zoneId, dungeonDifficulty.get_difficultyType(), k))
						{
							return zoneId;
						}
					}
				}
			}
		}
		return 0;
	}

	// 获取某个难度下有可领取宝箱时的index
	public static int getIndexForPickBox(PlayerNode playerNode, int difficulty, int zoneId)
	{
		if (zoneId == 0)
		{
			return -1;
		}
		// 获取副本相关信息
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerNode.getPlayerId());
		CampaignConfig campaignCfg = cd.get_CampaignConfig();
		DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
		if (dungeonData.getZones() == null || dungeonData.getZones().size() == 0)
		{
			return -1;
		}
		// 循环处理每一个章节
		ClientServerCommon.CampaignConfig.Zone zoneCfg = campaignCfg.GetZoneById(zoneId);
		if (zoneCfg == null)
		{
			return -1;
		}

		// 计算该难度的总星星数
		int totalStars = 0;
		ClientServerCommon.CampaignConfig.DungeonDifficulty dungeonDifficulty =
			zoneCfg.GetDungeonDifficultyByDifficulty(difficulty);
		if (dungeonDifficulty != null)
		{
			for (int k = 0; k < dungeonDifficulty.Get_dungeonsCount(); k++)
			{
				Integer dungeonId = dungeonDifficulty.Get_dungeonsByIndex(k).get_dungeonId();
				Dungeon dungeon = dungeonData.getDungeonById(dungeonId);
				// 无信息或者未通关都返回false
				if (dungeon != null)
				{
					totalStars += dungeon.getBestRecord();
				}
			}
			// 判断是否满足领取宝箱条件,并且是否已经领取
			for (int k = 0; k < dungeonDifficulty.Get_starRewardConditionsCount(); k++)
			{
				if (totalStars >= dungeonDifficulty.Get_starRewardConditionsByIndex(k).get_requireStarCount())
				{
					if (!dungeonData.checkBoxRewardPicked(zoneId, dungeonDifficulty.get_difficultyType(), k))
					{
						return k;
					}
				}
			}
		}

		return -1;
	}

	// 获取一个章节的最小可战斗关卡
	private static ClientServerCommon.CampaignConfig.Dungeon getMinDungeonCfg(
		ClientServerCommon.CampaignConfig.Zone zoneCfg)
	{
		ClientServerCommon.CampaignConfig.DungeonDifficulty dungeonDifficulty =
			zoneCfg.GetDungeonDifficultyByDifficulty(_DungeonDifficulity.Common);
		// 最小副本信息
		ClientServerCommon.CampaignConfig.Dungeon minDungeonCfg = null;
		int minDungeonId = 0;
		// 循环检索
		for (int i = 0; i < dungeonDifficulty.Get_dungeonsCount(); i++)
		{
			ClientServerCommon.CampaignConfig.Dungeon dungeonCfg = dungeonDifficulty.Get_dungeonsByIndex(i);
			if (minDungeonId == 0)
			{
				minDungeonId = dungeonCfg.get_dungeonId();
				minDungeonCfg = dungeonCfg;
			}
			if (minDungeonId > dungeonCfg.get_dungeonId())
			{
				minDungeonId = dungeonCfg.get_dungeonId();
				minDungeonCfg = dungeonCfg;
			}
		}
		return minDungeonCfg;
	}

	// 判断体力和玩家级别是否满足进入关卡条件
	private static boolean checkStaminaAndLevel(ClientServerCommon.CampaignConfig.Dungeon dungeonCfg, int stamina,
		int level)
	{
		if (!checkStamina(dungeonCfg, stamina))
		{
			return false;
		}
		if (!checkLevel(dungeonCfg, level))
		{
			return false;
		}
		return true;
	}

	// 判断体力是否满足进入关卡条件
	private static boolean checkStamina(ClientServerCommon.CampaignConfig.Dungeon dungeonCfg, int stamina)
	{
		for (int i = 0; i < dungeonCfg.Get_enterCostsCount(); i++)
		{
			ClientServerCommon.Cost cost = dungeonCfg.Get_enterCostsByIndex(i);
			if (cost.get_id() == ClientServerCommon.IDSeg._SpecialId.Stamina)
			{
				if (cost.get_count() > stamina)
				{
					return false;
				}
			}
		}
		return true;
	}

	// 判断级别是否满足进入关卡条件
	private static boolean checkLevel(ClientServerCommon.CampaignConfig.Dungeon dungeonCfg, int level)
	{
		if (dungeonCfg.get_levelLimit() > level)
		{
			return false;
		}
		return true;
	}
}
