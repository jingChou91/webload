package com.kodgames.corgi.server.gameserver.dungeon.data;

import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.combat.record.CombatResultAndReward;
import com.kodgames.corgi.gameconfiguration.AppPath;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.gamedata.xml.IXmlLoader;

public class DungeonGlobeMgr implements IXmlLoader
{
	private static final Logger logger = LoggerFactory.getLogger(DungeonGlobeMgr.class);
	private ConcurrentHashMap<String, CombatResultAndReward> plotCombatResult = new ConcurrentHashMap<>();

	public CombatResultAndReward getCombatResult(String fileName)
	{
		return plotCombatResult.get(fileName);
	}

	private static DungeonGlobeMgr dungeonGlobeMgr = new DungeonGlobeMgr();

	private DungeonGlobeMgr()
	{
	}

	public static DungeonGlobeMgr getInstance()
	{
		return dungeonGlobeMgr;
	}

	@Override
	public boolean reload(Element root)
	{
		return true;
	}

	@Override
	public boolean reloadFromMemory(String path, String content)
	{
		String fileName = path.replaceAll(AppPath.PATH_conf_client,"").replace(".bytes", "");

		com.kodgames.corgi.protocol.CombatData.CombatResultAndReward combatResultPro;
		try
		{
			combatResultPro = com.kodgames.corgi.protocol.CombatData.CombatResultAndReward.parseFrom(ServerUtil.fromHexString(content));
			CombatResultAndReward combatResult = new CombatResultAndReward();
			this.plotCombatResult.put(fileName, combatResult.fromProtobuf(combatResultPro));
		}
		catch (Exception e)
		{
			logger.error("{}", ExceptionUtils.getStackTrace(e));
		}
		return true;
	}
}
