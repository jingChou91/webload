package com.kodgames.corgi.server.gameserver.dungeon.data;

import java.util.HashMap;
import java.util.Map;

import com.kodgames.corgi.protocol.CommonProtocols;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.CampaignConfig.TravelTrader;

public class Travel
{
	private int dungeonId;
	private long openTime;
	private Map<Integer, Long> travelBuys = new HashMap<Integer, Long>();// goodId_buyTime

	// 判断商品是否已经购买
	public boolean checkGoodAlreadyBuy(Integer goodId)
	{
		for (Map.Entry<Integer, Long> entry : travelBuys.entrySet())
		{
			if (entry.getKey().equals(goodId))
			{
				return true;
			}
		}
		return false;
	}

	public com.kodgames.corgi.protocol.CommonProtocols.TravelData toProtoBuffer(CampaignConfig campaignCfg,
		int dungeonId)
	{
		TravelTrader travelTrader = campaignCfg.GetTravelTradeByDungeonId(dungeonId);
		CommonProtocols.TravelData.Builder builder = CommonProtocols.TravelData.newBuilder();
		builder.setDungeonId(dungeonId);
		builder.setOpenTime(openTime);
		for (Map.Entry<Integer, Long> entry : travelBuys.entrySet())
		{
			if (travelTrader.ContainGoodsId(entry.getKey()))
			{
				builder.addAlreadyBuyGoodIds(entry.getKey());
			}
		}
		return builder.build();
	}

	public Travel()
	{

	}

	public Travel(int dungeonId, long openTime, Map<Integer, Long> travelBuys)
	{
		super();
		this.dungeonId = dungeonId;
		this.openTime = openTime;
		this.travelBuys = travelBuys;
	}

	public long getOpenTime()
	{
		return openTime;
	}

	public void setOpenTime(long openTime)
	{
		this.openTime = openTime;
	}

	public Map<Integer, Long> getTravelBuys()
	{
		return travelBuys;
	}

	public void setTravelBuys(Map<Integer, Long> travelBuys)
	{
		this.travelBuys = travelBuys;
	}

	public int getDungeonId()
	{
		return dungeonId;
	}

	public void setDungeonId(int dungeonId)
	{
		this.dungeonId = dungeonId;
	}

}
