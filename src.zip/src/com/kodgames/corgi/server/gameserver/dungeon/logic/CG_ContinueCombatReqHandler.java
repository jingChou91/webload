package com.kodgames.corgi.server.gameserver.dungeon.logic;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.GameConfig;

import com.kodgames.combat.record.CombatResultAndReward;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_ContinueCombatReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_ContinueCombatRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dungeon.ActivityHandleSecretManager;
import com.kodgames.corgi.server.gameserver.dungeon.data.Dungeon;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonData;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonMgr;
import com.kodgames.corgi.server.gameserver.dungeon.util.DungeonUtil;
import com.kodgames.corgi.server.gameserver.marquee.data.FlowMessageBroadcaster;
import com.kodgames.corgi.server.gameserver.marquee.data.FlowMessageBroadcaster.Position;
import com.kodgames.corgi.server.gameserver.quest.data.QuestEventFactory;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;
import com.kodgames.gamedata.player.costandreward.RewardGen;

public class CG_ContinueCombatReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_ContinueCombatReqHandler.class);
	private ActivityHandleSecretManager activityHandleSecretManager = null;

	public CG_ContinueCombatReqHandler(ActivityHandleSecretManager activityHandleSecretManager)
	{
		this.activityHandleSecretManager = activityHandleSecretManager;
	}

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_ContinueCombatReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_ContinueCombatReq request = (CG_ContinueCombatReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_ContinueCombatRes.Builder builder = GC_ContinueCombatRes.newBuilder();
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_CONTINUE_COMBAT_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_CONTINUE_COMBAT_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		int dungeonId = request.getDungeonId();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_CONTINUE_COMBAT_FAILED_LOAD_PLAYER;
					break;
				}
				CampaignConfig campaignCfg = cd.get_CampaignConfig();
				if (campaignCfg == null)
				{
					result = ClientProtocols.E_GAME_CONTINUE_COMBAT_FAILED_CAMPAIGNCONFIG_ERROR;
					break;
				}
				CampaignConfig.Dungeon dungeonCfg = campaignCfg.GetDungeonById(dungeonId);
				if (null == dungeonCfg)
				{
					result = ClientProtocols.E_GAME_CONTINUE_COMBAT_FAILED_LOAD_DUNGEON_CONFIG_ERROR;
					break;
				}
				int zoneId = dungeonCfg.get_ZoneId();
				int logEventId = this.getLogEventId(campaignCfg, zoneId);
				CampaignConfig.Zone zoneCfg = campaignCfg.GetZoneById(zoneId);
				if (null == zoneCfg)
				{
					result = ClientProtocols.E_GAME_CONTINUE_COMBAT_FAILED_LOAD_ZONE_CONFIG_ERROR;
					break;
				}
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Secret))
					{
						result = ClientProtocols.E_GAME_SECRET_FUNCTION_NOT_OPEN;
						break;
					}
				}
				else
				{
					if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Dungeon))
					{
						result = ClientProtocols.E_GAME_DUNGEON_FUNCTION_NOT_OPEN;
						break;
					}
				}
				// 判断秘境是否开启
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!activityHandleSecretManager.isActivityActivate(zoneCfg.get_activityId(), playerNode))
					{
						result = ClientProtocols.E_GAME_CONTINUE_COMBAT_FAILED_SECRET_ZONE_NOT_OPEN_ERROR;
						break;
					}
				}
				CampaignConfig.DungeonDifficulty difficultyCfg =
					zoneCfg.GetDungeonDifficultyByDifficulty(dungeonCfg.get_DungeonDifficulty());
				if (difficultyCfg == null)
				{
					result = ClientProtocols.E_GAME_COMBAT_FAILED_LOAD_DIFFICULT_CONFIG_FAILED;
					break;
				}
				GameConfig.ContinueCombat continueCombatCfg = cd.get_GameConfig().get_continueCombat();
				if (continueCombatCfg == null || continueCombatCfg.get_maxContinueCombatCount() <= 0)
				{
					result = ClientProtocols.E_GAME_CONTINUE_COMBAT_FAILED_GAMECONFIG_ERROR;
					break;
				}
				// 开启等级
				if (playerNode.getGamePlayer().getLevel() < continueCombatCfg.get_continueCombatOpenLevel())
				{
					result = ClientProtocols.E_GAME_CONTINUE_COMBAT_FAILED_LEVEL_NOT_MEET;
					break;
				}
				// 难度开启等级
				int level = playerNode.getGamePlayer().getLevel();
				if (level < difficultyCfg.get_levelLimit())
				{
					result = ClientProtocols.E_GAME_GET_FIXEDTIME_ACTIVITY_REWARD_FAILED_LEVEL_WRONG;
//					result = ClientProtocols.E_GAME_CONTINUE_COMBAT_FAILED_DUNGEON_LEVEL_LEVEL_NOT_MATCH;
					break;
				}
				if (!DungeonUtil.checkDungeonPass(playerNode, dungeonId))
				{
					result = ClientProtocols.E_GAME_CONTINUE_COMBAT_FAILED_DUNGEON_NOT_CLEARANCE;
					break;
				}
				DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
				Dungeon dungeon = dungeonData.getDungeonById(dungeonId);

				// 判断是否需要刷新关卡
				dungeon.refresh_DungeonCompleteTimes(cd, playerNode);
				if (dungeon.getTodayCompleteTimes() >= dungeonCfg.get_enterCount())
				{
					result = ClientProtocols.E_GAME_CONTINUE_COMBAT_FAILED_DUNGEON_EXCEED_MAX_ENTER_TIMES;
					break;
				}
				// 检测体力
				Cost notEnoughStamina = new Cost();
				if (!DungeonUtil.checkCost(dungeonCfg, playerNode, notEnoughStamina))
				{
					crsForClient.setNotEnoughCost(notEnoughStamina);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_CONTINUE_COMBAT_FAILED_CONSUMABLE_NOT_ENOUGH;
					break;
				}
				// 获取扫荡次数
				int continueCount =
					DungeonUtil.getContinueCombatCount(dungeonCfg, continueCombatCfg, dungeon, playerNode);

				if (continueCount <= 0)
				{
					result = ClientProtocols.E_GAME_CONTINUE_COMBAT_FAILED_CONSUMABLE_NOT_ENOUGH;
					break;
				}

				// 消耗信息
				ArrayList<Cost> costs = new ArrayList<Cost>();
				Cost notEnoughCost = new Cost();
				for (int i = 0; i < dungeonCfg.Get_enterCostsCount(); i++)// GetEnterCostCount()
				{
					int costItemId = dungeonCfg.Get_enterCostsByIndex(i).get_id();// GetEnterCost(i)
					int costItemCount = dungeonCfg.Get_enterCostsByIndex(i).get_count() * continueCount;
					Cost cost = new Cost(costItemId, costItemCount);
					costs.add(cost);
				}
				// 执行消耗
				if (!CostAndRewardManager.checkCosts(playerNode,
					costs,
					cd,
					KodLogEvent.DungeonLogic_ContinueCombat,
					notEnoughCost))
				{
					crsForClient.setNotEnoughCost(notEnoughCost);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_CONTINUE_COMBAT_FAILED_CONSUMABLE_NOT_ENOUGH;
					break;
				}

				CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
				crsForCost.setCosts(costs);
				CostAndRewardManager.consumeCosts(playerNode, costs, cd, logEventId, 0, 0);
				crsForClient.megerCostAndRewardAndSync(crsForCost);

				// 计算奖励
				Reward rewardAll = new Reward();
				for (int i = 0; i < continueCount; i++)
				{
					Reward rewardFix = new Reward();
					Reward reward = new Reward();

					// 固定奖励:经验和银币
					for (int j = 0; j < dungeonCfg.Get_fixedRewardsCount(); j++)// getFixRewardCount()
					{
						Reward temp = new Reward();
						temp.fromClientServerCommon(dungeonCfg.Get_fixedRewardsByIndex(j));// getFixReward(j)
						rewardFix.megerReward(temp);
					}
					// 通关奖励
					reward = RewardGen.getRewardFromRewardSetId(dungeonCfg.get_passRewardSetId(), cd);

					CombatResultAndReward combatResultAndReward = new CombatResultAndReward();
					combatResultAndReward.setDungeonReward_ExpSilver(rewardFix);
					combatResultAndReward.setDungeonReward(reward);
					builder.addRewards(combatResultAndReward.toProtobuf());

					rewardAll.megerReward(rewardFix);
					rewardAll.megerReward(reward);
				}

				// 把奖励存入内存
				CostAndRewardAndSync crsForReward = new CostAndRewardAndSync();
				CostAndRewardManager.addReward(playerNode, rewardAll, cd, logEventId);
				crsForReward.mergeReward(rewardAll);
				crsForClient.megerCostAndRewardAndSync(crsForReward);

				// 增加完成次数
				dungeon.addTodayCompleteTime(continueCount);
				DungeonMgr.updateDungeon(playerNode, zoneId);

				// 保存最后一场副本Id
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					dungeonData.setLastSecretZoneId(zoneId);
					dungeonData.setLastSecretDungeonId(dungeonId);
				}
				else
				{
					dungeonData.setLastZoneId(zoneId);
					dungeonData.setLastDungeonId(dungeonId);
				}
				DungeonMgr.updatePlayerDungeonData(playerNode);

				builder.setDungeon(dungeon.toProtoBuffer());

				BPUtil.pveFight(playerNode,
					dungeonId,
					"3",
					DungeonUtil.getDungeonType(campaignCfg, zoneId),
					"1",
					zoneId,
					dungeon.getBestRecord());
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					BPUtil.activity(playerNode, zoneCfg.get_activityId());
				}

				// 跑马灯
				FlowMessageBroadcaster.prepareBroadcastRewardMsg(playerNode, rewardAll, Position.DUNGEON);

				// 副本每日任务
				QuestEventFactory.createCombatEvent(playerNode,
					ClientServerCommon._CombatType.Campaign,
					dungeonCfg.get_DungeonDifficulty(),
					dungeonId,
					continueCount,
					cd);

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);

		return HandlerAction.TERMINAL;
	}

	private int getLogEventId(CampaignConfig campaignCfg, int zoneId)
	{
		if (campaignCfg.IsActivityZoneId(zoneId))
		{
			return KodLogEvent.DungeonLogic_ContinueCombat_Secret;
		}
		else
		{
			return KodLogEvent.DungeonLogic_ContinueCombat;
		}
	}

}
