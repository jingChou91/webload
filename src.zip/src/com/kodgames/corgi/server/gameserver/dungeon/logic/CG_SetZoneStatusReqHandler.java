package com.kodgames.corgi.server.gameserver.dungeon.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._ZoneStatus;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_SetZoneStatusReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_SetZoneStatusRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dungeon.ActivityHandleSecretManager;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonData;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonMgr;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_SetZoneStatusReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_SetZoneStatusReqHandler.class);

	private ActivityHandleSecretManager activityHandleSecretManager = null;
	public CG_SetZoneStatusReqHandler(ActivityHandleSecretManager activityHandleSecretManager)
	{
		this.activityHandleSecretManager = activityHandleSecretManager;
	}

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_SetZoneStatusReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_SetZoneStatusReq request = (CG_SetZoneStatusReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_SetZoneStatusRes.Builder builder = GC_SetZoneStatusRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_SET_ZONE_STATUS_RES);
		builder.setCallback(request.getCallback());

		int result = ClientProtocols.E_GAME_SET_ZONE_STATUS_SUCCESS;
		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		int zoneId = request.getZoneId();
		int status = request.getStatus();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_SET_ZONE_STATUS_LOAD_PLAYER_FAILED;
					break;
				}
				CampaignConfig campaignCfg = cd.get_CampaignConfig();
				if (campaignCfg == null)
				{
					result = ClientProtocols.E_GAME_SET_ZONE_STATUS_LOAD_CAMPAIGN_CONFIG_FAILED;
					break;
				}
				CampaignConfig.Zone zoneCfg = cd.get_CampaignConfig().GetZoneById(zoneId);
				if (zoneCfg == null)
				{
					result = ClientProtocols.E_GAME_SET_ZONE_STATUS_LOAD_ZONE_CONFIG_FAILED;
					break;
				}
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Secret))
					{
						result = ClientProtocols.E_GAME_SECRET_FUNCTION_NOT_OPEN;
						break;
					}
				}
				else
				{
					if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Dungeon))
					{
						result = ClientProtocols.E_GAME_DUNGEON_FUNCTION_NOT_OPEN;
						break;
					}
				}
				//判断秘境是否开启
				if(campaignCfg.IsActivityZoneId(zoneId))
				{
					if(!activityHandleSecretManager.isActivityActivate(zoneCfg.get_activityId(), playerNode))
					{
						result = ClientProtocols.E_GAME_SET_ZONE_STATUS_SECRET_ZONE_NOT_OPEN_FAILED;
						break;
					}
				}
				// **为新手引导写的特殊逻辑(当客户端要将第一章状态设置为剧情对话时,清空上次章节和上次关卡)
				DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
				if (zoneId == campaignCfg.Get_zonesByIndex(1).get_zoneId() && status == _ZoneStatus.PlotDialogue)
				{
					dungeonData.setLastZoneId(0);
					dungeonData.setLastDungeonId(0);
				}
				DungeonMgr.updatePlayerDungeonData(playerNode);
				// 修改章节状态
				DungeonMgr.updateZoneStatus(playerNode, zoneId, status);
				
				playerNode.getPlayerInfo().getAssisantData().getDungeonCombat().notifyObservers();

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}

}
