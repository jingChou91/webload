package com.kodgames.corgi.server.gameserver.dungeon.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.kodgames.corgi.server.gameserver.dungeon.db.DungeonDB;
import com.kodgames.gamedata.player.PlayerNode;

public class DungeonMgr
{
	// 初始化Zone状态(不存入数据库)
	public static void initZoneStatus(PlayerNode playerNode, int zoneId, int status)
	{
		playerNode.getPlayerInfo().getDungeonData().getZones().put(zoneId, status);
	}

	// 修改Zone状态
	public static void updateZoneStatus(PlayerNode playerNode, int zoneId, int status)
	{
		playerNode.getPlayerInfo().getDungeonData().getZones().put(zoneId, status);
		DungeonDB.updateDungeon(playerNode, zoneId);
	}

	// 更新player表
	public static void updatePlayerDungeonData(PlayerNode playerNode)
	{
		DungeonDB.updatePlayerDungeonData(playerNode.getPlayerId(), playerNode.getPlayerInfo().getDungeonData());
	}

	// 修改章节信息
	public static void updateDungeon(PlayerNode playerNode, Dungeon dungeon)
	{
		Map<Integer, Map<Integer, Dungeon>> dungeons = playerNode.getPlayerInfo().getDungeonData().getDungeons();
		if (dungeons.get(dungeon.getZoneId()) != null)
		{
			dungeons.get(dungeon.getZoneId()).put(dungeon.getDungeonId(), dungeon);
		}
		else
		{
			Map<Integer, Dungeon> map = new HashMap<Integer, Dungeon>();
			map.put(dungeon.getDungeonId(), dungeon);
			dungeons.put(dungeon.getZoneId(), map);
		}
		DungeonDB.updateDungeon(playerNode, dungeon.getZoneId());

	}

	// 修改章节信息
	public static void updateDungeon(PlayerNode playerNode, int zoneId)
	{
		DungeonDB.updateDungeon(playerNode, zoneId);
	}

	// 更新宝箱领取记录
	public static void addBoxRewardRecord(PlayerNode playerNode, Integer zoneId, Integer difficultyType, Integer index)
	{
		Map<Integer, Map<Integer, List<Integer>>> boxRecords =
			playerNode.getPlayerInfo().getDungeonData().getBoxRecords();
		if (boxRecords.get(zoneId) == null)
		{
			Map<Integer, List<Integer>> map = new HashMap<Integer, List<Integer>>();
			List<Integer> list = new ArrayList<Integer>();
			list.add(index);
			map.put(difficultyType, list);
			boxRecords.put(zoneId, map);
		}
		else if (boxRecords.get(zoneId).get(difficultyType) == null)
		{
			Map<Integer, List<Integer>> map = boxRecords.get(zoneId);
			List<Integer> list = new ArrayList<Integer>();
			list.add(index);
			map.put(difficultyType, list);
		}
		else
		{
			boxRecords.get(zoneId).get(difficultyType).add(index);
		}

		DungeonDB.updateDungeon(playerNode, zoneId);
	}

	// 修改云游商人信息
	public static void updateTravel(PlayerNode playerNode, Integer dungeonId, Integer goodId)
	{
		Travel travel = playerNode.getPlayerInfo().getDungeonData().getTravels().get(dungeonId);
		if (travel != null)
		{
			travel.getTravelBuys().put(goodId, System.currentTimeMillis());
			DungeonDB.updateTravel(playerNode);
		}
	}

	// 激活关卡对应云游商人
	public static void openTravel(PlayerNode playerNode, Integer dungeonId)
	{
		// 如果成功激活云游商人,那么修改数据库
		if (playerNode.getPlayerInfo().getDungeonData().openTravel(dungeonId))
		{
			DungeonDB.updateTravel(playerNode);
		}

	}

}
