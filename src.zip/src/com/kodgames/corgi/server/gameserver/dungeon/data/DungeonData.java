package com.kodgames.corgi.server.gameserver.dungeon.data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.gamedata.player.PlayerNode;

public class DungeonData
{
	private int lastDungeonId;
	private int lastZoneId;
	private int lastSecretDungeonId;
	private int lastSecretZoneId;
	private int lastPositionId;
	private long lastRefreshDungeonTime;
	private Map<Integer, Integer> zones = new HashMap<Integer, Integer>();// zoneId_status
	private Map<Integer, Map<Integer, Dungeon>> dungeons = new HashMap<Integer, Map<Integer, Dungeon>>();// zoneId_(dungeon_id_dungeon)
	private Map<Integer, Map<Integer, List<Integer>>> boxRecords = new HashMap<Integer, Map<Integer, List<Integer>>>();// zoneId_difficulty_boxIndexs
	private Map<Integer, Travel> travels = new HashMap<Integer, Travel>();// dungeonId_TravelBuy

	// 更新关卡信息(直接替换)
	public void putDungeon(int zoneId, Dungeon dungeon)
	{
		if (dungeons.containsKey(zoneId))
		{
			dungeons.get(zoneId).put(dungeon.getDungeonId(), dungeon);
		}
		else
		{
			Map<Integer, Dungeon> id_Dungeon = new HashMap<Integer, Dungeon>();
			id_Dungeon.put(dungeon.getDungeonId(), dungeon);
			dungeons.put(zoneId, id_Dungeon);
		}
	}

	// 激活关卡对应云游商人
	public boolean openTravel(Integer dungeonId)
	{
		// 如果该云游商人尚未激活
		if (!travels.containsKey(dungeonId))
		{
			Travel travel = new Travel();
			travel.setDungeonId(dungeonId);
			travel.setOpenTime(System.currentTimeMillis());
			travels.put(dungeonId, travel);
			return true;
		}
		return false;
	}

	// 获得某个难度下的星星总数
	public int getStarsCount(Integer zoneId, Integer difficultyType, CampaignConfig.DungeonDifficulty difficultyCfg)
	{
		int stars = 0;
		for (int i = 0; i < difficultyCfg.Get_dungeonsCount(); i++)
		{
			Dungeon dungeon = getDungeonById(difficultyCfg.Get_dungeonsByIndex(i).get_dungeonId());
			if (dungeon != null)
			{
				stars += dungeon.getBestRecord();
			}
		}
		return stars;
	}

	// 检测该宝箱奖励是否已经领取 或者某个难度下是否有宝箱领取记录 (看参数传入情况而定.)
	public boolean checkBoxRewardPicked(Integer zoneId, Integer difficultyType, Integer index)
	{
		if (zoneId != null && boxRecords.get(zoneId) == null)
		{
			return false;
		}
		if (difficultyType != null && boxRecords.get(zoneId).get(difficultyType) == null)
		{
			return false;
		}
		if (index != null && !boxRecords.get(zoneId).get(difficultyType).contains(index))
		{
			return false;
		}
		return true;
	}

	// 查询指定章节 和 难度 下的宝箱领取记录
	public List<Integer> getBoxRewardPicked(Integer zoneId, Integer difficultyType)
	{
		if (zoneId != null && boxRecords.get(zoneId) == null)
		{
			return null;
		}
		if (difficultyType != null && boxRecords.get(zoneId).get(difficultyType) == null)
		{
			return null;
		}
		return boxRecords.get(zoneId).get(difficultyType);
	}

	// 判断是否需要刷新各关卡进入次数
	public void refresh_DungeonCompleteTimes(ConfigDatabase cd, PlayerNode playerNode)
	{
		if (ServerUtil.isNeedRefresh(cd.get_GameConfig().get_restoreResetDungeonCompleteDataTime(),
			lastRefreshDungeonTime))
		{
			this.lastRefreshDungeonTime = System.currentTimeMillis();
			for (Map.Entry<Integer, Map<Integer, Dungeon>> kvv : dungeons.entrySet())
			{
				for (Map.Entry<Integer, Dungeon> kv : kvv.getValue().entrySet())
				{
					kv.getValue().refresh_DungeonCompleteTimes(cd, playerNode);
					kv.getValue().refresh_DungeonResetCount(cd);
				}

			}
		}

	}

	// 根据关卡id获得关卡信息
	public Dungeon getDungeonById(int dungeonId)
	{
		for (Map.Entry<Integer, Map<Integer, Dungeon>> kvv : dungeons.entrySet())
		{
			for (Map.Entry<Integer, Dungeon> kv : kvv.getValue().entrySet())
			{
				if (kv.getValue().getDungeonId() == dungeonId)
				{
					return kv.getValue();
				}

			}

		}
		return null;
	}

	// 生成DungeonInfos
	public DBProtocolsForServer.TravelInfos genTravelInfos()
	{
		DBProtocolsForServer.TravelInfos.Builder builder = DBProtocolsForServer.TravelInfos.newBuilder();
		for (Map.Entry<Integer, Travel> kv : travels.entrySet())
		{
			DBProtocolsForServer.TravelInfo.Builder travelInfo = DBProtocolsForServer.TravelInfo.newBuilder();
			Travel travel = kv.getValue();
			travelInfo.setDungeonId(kv.getKey());
			travelInfo.setOpenTime(travel.getOpenTime());
			for (Map.Entry<Integer, Long> entry : travel.getTravelBuys().entrySet())
			{
				DBProtocolsForServer.TravelBuy.Builder travelBuy = DBProtocolsForServer.TravelBuy.newBuilder();
				travelBuy.setGoodId(entry.getKey());
				travelBuy.setBuyTime(entry.getValue());
				travelInfo.addTravelBuy(travelBuy.build());
			}
			builder.addTravelInfo(travelInfo.build());
		}
		return builder.build();
	}

	// 生成DungeonInfos
	public DBProtocolsForServer.DungeonInfos genDungeonInfos(Integer zoneId)
	{
		DBProtocolsForServer.DungeonInfos.Builder builder = DBProtocolsForServer.DungeonInfos.newBuilder();
		if (dungeons.get(zoneId) != null)
		{
			for (Map.Entry<Integer, Dungeon> kv : dungeons.get(zoneId).entrySet())
			{
				DBProtocolsForServer.DungeonInfo.Builder dungeonInfo = DBProtocolsForServer.DungeonInfo.newBuilder();
				Dungeon dungeon = kv.getValue();
				dungeonInfo.setDungeonId(dungeon.getDungeonId());
				dungeonInfo.setBestRecord(dungeon.getBestRecord());
				dungeonInfo.setTodayCompleteTimes(dungeon.getTodayCompleteTimes());
				dungeonInfo.setLastRefreshTime(dungeon.getLastRefreshTime());
				dungeonInfo.setResetCount(dungeon.getResetCount());
				dungeonInfo.setLastResetTime(dungeon.getLastResetTime());
				dungeonInfo.setStatus(dungeon.getStatus());
				dungeonInfo.setDialogState(dungeon.getDialogState());
				builder.addDungeonInfos(dungeonInfo.build());
			}
		}
		return builder.build();
	}

	// 生成BoxRewardRecords
	public DBProtocolsForServer.BoxRewardRecords genBoxRewardRecords(Integer zoneId)
	{
		DBProtocolsForServer.BoxRewardRecords.Builder builder = DBProtocolsForServer.BoxRewardRecords.newBuilder();
		if (boxRecords.get(zoneId) != null)
		{
			for (Map.Entry<Integer, List<Integer>> kv : boxRecords.get(zoneId).entrySet())
			{
				DBProtocolsForServer.BoxRewardRecord.Builder boxRewardRecord =
					DBProtocolsForServer.BoxRewardRecord.newBuilder();
				List<Integer> indexs = kv.getValue();
				boxRewardRecord.setDifficulty(kv.getKey());

				String indexsString = "";
				for (Integer index : indexs)
				{
					indexsString += index + ",";
				}
				boxRewardRecord.setRecord(indexsString);
				builder.addBoxRewardRecords(boxRewardRecord.build());
			}
		}
		return builder.build();
	}

	public int getLastDungeonId()
	{
		return lastDungeonId;
	}

	public void setLastDungeonId(int lastDungeonId)
	{
		this.lastDungeonId = lastDungeonId;
	}

	public int getLastZoneId()
	{
		return lastZoneId;
	}

	public void setLastZoneId(int lastZoneId)
	{
		this.lastZoneId = lastZoneId;
	}

	public Map<Integer, Integer> getZones()
	{
		return zones;
	}

	public void setZones(Map<Integer, Integer> zones)
	{
		this.zones = zones;
	}

	public Map<Integer, Map<Integer, List<Integer>>> getBoxRecords()
	{
		return boxRecords;
	}

	public void setBoxRecords(Map<Integer, Map<Integer, List<Integer>>> boxRecords)
	{
		this.boxRecords = boxRecords;
	}

	public Map<Integer, Map<Integer, Dungeon>> getDungeons()
	{
		return dungeons;
	}

	public void setDungeons(Map<Integer, Map<Integer, Dungeon>> dungeons)
	{
		this.dungeons = dungeons;
	}

	public long getLastRefreshDungeonTime()
	{
		return lastRefreshDungeonTime;
	}

	public void setLastRefreshDungeonTime(long lastRefreshDungeonTime)
	{
		this.lastRefreshDungeonTime = lastRefreshDungeonTime;
	}

	public int getLastPositionId()
	{
		return lastPositionId;
	}

	public void setLastPositionId(int lastPositionId)
	{
		this.lastPositionId = lastPositionId;
	}

	public Map<Integer, Travel> getTravels()
	{
		return travels;
	}

	public void setTravels(Map<Integer, Travel> travels)
	{
		this.travels = travels;
	}

	public int getLastSecretDungeonId()
	{
		return lastSecretDungeonId;
	}

	public void setLastSecretDungeonId(int lastSecretDungeonId)
	{
		this.lastSecretDungeonId = lastSecretDungeonId;
	}

	public int getLastSecretZoneId()
	{
		return lastSecretZoneId;
	}

	public void setLastSecretZoneId(int lastSecretZoneId)
	{
		this.lastSecretZoneId = lastSecretZoneId;
	}

}
