package com.kodgames.corgi.server.gameserver.dungeon;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ActivityConfig.Activity;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.TaskConfig._TaskType;
import ClientServerCommon._ActivityTimerStatus;
import ClientServerCommon._ActivityType;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityEnviroment;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityHandler;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivitySpecialTimeInfo;
import com.kodgames.corgi.server.gameserver.activity.data.ActivityTimerStatus;
import com.kodgames.corgi.server.gameserver.dungeon.logic.CG_BuyTravelReqHandler;
import com.kodgames.corgi.server.gameserver.dungeon.logic.CG_CombatReqHandler;
import com.kodgames.corgi.server.gameserver.dungeon.logic.CG_ContinueCombatReqHandler;
import com.kodgames.corgi.server.gameserver.dungeon.logic.CG_DungeonGetRewardReqHandler;
import com.kodgames.corgi.server.gameserver.dungeon.logic.CG_QueryDungeonGuideReqHandler;
import com.kodgames.corgi.server.gameserver.dungeon.logic.CG_QueryDungeonListReqHandler;
import com.kodgames.corgi.server.gameserver.dungeon.logic.CG_QueryRecruiteNpcReqHandler;
import com.kodgames.corgi.server.gameserver.dungeon.logic.CG_QueryTravelReqHandler;
import com.kodgames.corgi.server.gameserver.dungeon.logic.CG_ResetDungeonCompleteTimesReqHandler;
import com.kodgames.corgi.server.gameserver.dungeon.logic.CG_SetDungeonDialogStateReqHandler;
import com.kodgames.corgi.server.gameserver.dungeon.logic.CG_SetDungeonStatusReqHandler;
import com.kodgames.corgi.server.gameserver.dungeon.logic.CG_SetZoneStatusReqHandler;
import com.kodgames.corgi.server.gameserver.task.timer.GlobalTimerMgr;
import com.kodgames.gamedata.player.PlayerNode;

public class ActivityHandleSecretManager extends ActivityHandler
{
	public ActivityHandleSecretManager()
	{
		super(_ActivityType.SECRETACTIVIYT);
	}

	private static final Logger logger = LoggerFactory.getLogger(ActivityHandleSecretManager.class);
	
	public Map<Integer, Long> timeMap = new ConcurrentHashMap<Integer, Long>();
	public Map<Integer, Integer> statusMap = new ConcurrentHashMap<Integer, Integer>() ;
	
	private CG_ResetDungeonCompleteTimesReqHandler cg_ResetDungeonCompleteTimesReqHandler = null;
	private CG_SetZoneStatusReqHandler cg_SetZoneStatusReqHandler = null;
	private CG_SetDungeonStatusReqHandler cg_SetDungeonStatusReqHandler = null;
	private CG_SetDungeonDialogStateReqHandler cg_SetDungeonDialogStateReqHandler = null;
	private CG_QueryDungeonGuideReqHandler cg_QueryDungeonGuideReqHandler = null;
	private CG_QueryDungeonListReqHandler cg_QueryDungeonListReqHandler = null;
	private CG_CombatReqHandler cg_CombatReqHandler = null;
	private CG_DungeonGetRewardReqHandler cg_DungeonGetRewardReqHandler = null;
	private CG_ContinueCombatReqHandler cg_ContinueCombatReqHandler = null;
	private CG_QueryTravelReqHandler cg_QueryTravelReqHandler = null; 
	private CG_BuyTravelReqHandler cg_BuyTravelReqHandler = null;
	private CG_QueryRecruiteNpcReqHandler cg_QueryRecruiteNpcReqHandler = null;

	@Override
	public boolean handleActivity(int activityID, long openTime, long closeTime, int specialIndex, int timerStatus,
		int timerIndex, int playerId, boolean startOnce)
	{
		if (!super.handleActivity(activityID, openTime, closeTime, specialIndex, timerStatus, timerIndex, playerId, startOnce))
		{
			return false;
		}
		
		if(timerStatus != _ActivityTimerStatus.DurationStart && timerStatus != _ActivityTimerStatus.DurationEnd)
		{
			ActivitySpecialTimeInfo timeInfo = todayTimerList.get(activityID);
			if (timeInfo == null || timeInfo.getTimerList() == null)
			{
				logger.warn("SecretActivityManager can't found id {} timeInfo but super found", activityID);
				return false;
			}
			ActivityTimerStatus activityTimerStatus = (ActivityTimerStatus)(timeInfo.getTimerList().toArray()[timerIndex]);
			timeMap.put(activityID, activityTimerStatus.getTimer());
			statusMap.put(activityID, timerStatus);
			//小助手
			GlobalTimerMgr.getInstance().execute(_TaskType.SecretDungeonAssistant, activityID);
		}
		
		return true;
	}
	
	public boolean init(Controller controller)
	{
		this.cg_ResetDungeonCompleteTimesReqHandler = new CG_ResetDungeonCompleteTimesReqHandler(this);
		this.cg_SetZoneStatusReqHandler = new CG_SetZoneStatusReqHandler(this);
		this.cg_SetDungeonStatusReqHandler = new CG_SetDungeonStatusReqHandler(this);
		this.cg_SetDungeonDialogStateReqHandler = new CG_SetDungeonDialogStateReqHandler(this);
		this.cg_QueryDungeonGuideReqHandler = new CG_QueryDungeonGuideReqHandler(this);
		this.cg_QueryDungeonListReqHandler = new CG_QueryDungeonListReqHandler(this);
		this.cg_CombatReqHandler = new CG_CombatReqHandler(this);
		this.cg_DungeonGetRewardReqHandler = new CG_DungeonGetRewardReqHandler(this);
		this.cg_ContinueCombatReqHandler = new CG_ContinueCombatReqHandler(this);
		this.cg_QueryTravelReqHandler = new CG_QueryTravelReqHandler(this);
		this.cg_BuyTravelReqHandler = new CG_BuyTravelReqHandler(this);
		this.cg_QueryRecruiteNpcReqHandler = new CG_QueryRecruiteNpcReqHandler(this);
		
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_RESET_DUNGEON_COMPLETE_TIMES_REQ, GameProtocolsForClient.CG_ResetDungeonCompleteTimesReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_SET_ZONE_STATUS_REQ, GameProtocolsForClient.CG_SetZoneStatusReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_SET_DUNGEON_STATUS_REQ, GameProtocolsForClient.CG_SetDungeonStatusReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_SET_DUNGEON_DIALOG_STATE_REQ, GameProtocolsForClient.CG_SetDungeonDialogStateReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_DUNGEON_GUIDE_REQ, GameProtocolsForClient.CG_QueryDungeonGuideReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_DUNGEON_LIST_REQ, GameProtocolsForClient.CG_QueryDungeonListReq.getDefaultInstance()); 
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_COMBAT_REQ, GameProtocolsForClient.CG_CombatReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_DUNGEON_GET_REWARD_REQ, GameProtocolsForClient.CG_DungeonGetRewardReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_CONTINUE_COMBAT_REQ, GameProtocolsForClient.CG_ContinueCombatReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_TRAVEL_REQ, GameProtocolsForClient.CG_QueryTravelReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_BUY_TRAVEL_REQ, GameProtocolsForClient.CG_BuyTravelReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_RECRUITE_NPC_REQ, GameProtocolsForClient.CG_QueryRecruiteNpcReq.getDefaultInstance());
	
		controller.addHandler(ClientProtocols.P_GAME_CG_RESET_DUNGEON_COMPLETE_TIMES_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_ResetDungeonCompleteTimesReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_SET_ZONE_STATUS_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_SetZoneStatusReqHandler));		
		controller.addHandler(ClientProtocols.P_GAME_CG_SET_DUNGEON_STATUS_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_SetDungeonStatusReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_SET_DUNGEON_DIALOG_STATE_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_SetDungeonDialogStateReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_DUNGEON_GUIDE_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryDungeonGuideReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_DUNGEON_LIST_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryDungeonListReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_COMBAT_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_CombatReqHandler ));
		controller.addHandler(ClientProtocols.P_GAME_CG_DUNGEON_GET_REWARD_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_DungeonGetRewardReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_CONTINUE_COMBAT_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_ContinueCombatReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_TRAVEL_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryTravelReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_BUY_TRAVEL_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_BuyTravelReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_RECRUITE_NPC_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryRecruiteNpcReqHandler));
		return true;
	}

	public boolean start(ActivityEnviroment activityEnv)
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
		
		for (int i = 0; i < cd.get_ActivityConfig().GetSecretActivityCount(); i++)
		{
			registerActivity(activityEnv, cd.get_ActivityConfig().GetSecretActivityByIndex(i));
		}
		
		return true;
	}
	
	public Long getNoticeTimeByActivityId(int activityId)
	{
		if(getNoticeStatusByActivityId(activityId) != _ActivityTimerStatus.DurationStart && getNoticeStatusByActivityId(activityId) != _ActivityTimerStatus.DurationEnd)
		{
			return timeMap.get(activityId);
		}
		return 0l;
	}
	
	public Integer getNoticeStatusByActivityId(int activityId)
	{
		if(statusMap.containsKey(activityId))
		{
			return statusMap.get(activityId);
		}
		return _ActivityTimerStatus.Unknown;
	}

	@Override
	public boolean isActivityActivate(int activityId, PlayerNode playerNode)
	{
		boolean result = checkIsStart(activityId, playerNode);
		if (!result)
		{
			return result;
		}
		return (getNoticeStatusByActivityId(activityId) & _ActivityTimerStatus.Start) > 0;
	}

	public void handleConfigRefresh(ConfigDatabase newCfg, ActivityEnviroment activityEnv)
	{
		int secretCount = newCfg.get_ActivityConfig().GetSecretActivityCount();
		for (int i = 0; i < secretCount; i++)
		{
			Activity secretActivity = newCfg.get_ActivityConfig().GetSecretActivityByIndex(i);
			checkActivityTimeChanged(activityEnv, secretActivity);
		}
	}
}
