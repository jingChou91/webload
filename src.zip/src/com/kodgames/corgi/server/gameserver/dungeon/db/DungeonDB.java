package com.kodgames.corgi.server.gameserver.dungeon.db;

import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.dbclient.TableChangeEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonData;
import com.kodgames.gamedata.player.PlayerNode;

public class DungeonDB
{
	// 更新章节信息
	public static void updateDungeon(PlayerNode playerNode, int zoneId)
	{
		DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
		String sqlCommand =
			String.format("replace into dungeon (player_id, zone_id, zone_status,dungeon_info,box_reward_record) VALUES (%d,%d,%d,%s,%s)",
				playerNode.getPlayerId(),
				zoneId,
				dungeonData.getZones().get(zoneId),
				ServerUtil.toHexString(dungeonData.genDungeonInfos(zoneId).toByteArray()),
				ServerUtil.toHexString(dungeonData.genBoxRewardRecords(zoneId).toByteArray()));
		ServerDataGS.dbCluster.getGameDBClient()
			.executeAsynchronousUpdate(TableChangeEvent.getKey(playerNode.getPlayerId(),
				TableChangeEvent.DUNGEON_UPDATEDUNGEON,
				zoneId),
				playerNode.getPlayerId(),
				sqlCommand);
	}

	// 更新palyer的副本状态以及最后一场战斗结果
	public static void updatePlayerDungeonData(int playerId, DungeonData dungeonData)
	{
		String sqlCommand =
			String.format("update player set last_dungeon_id = %d,last_zone_id = %d,last_secret_dungeon_id = %d,last_secret_zone_id = %d,last_position_id = %d where player_id = %d",
				dungeonData.getLastDungeonId(),
				dungeonData.getLastZoneId(),
				dungeonData.getLastSecretDungeonId(),
				dungeonData.getLastSecretZoneId(),
				dungeonData.getLastPositionId(),
				playerId);
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(TableChangeEvent.getKey(playerId,
			TableChangeEvent.PLAYER_UPDATEPLAYERDUNGEONDATA),
			playerId,
			sqlCommand);
	}

	// 更新云游商人
	public static void updateTravel(PlayerNode playerNode)
	{
		DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
		String sqlCommand =
			String.format("replace into travel_trader(player_id, travel_info)" + " VALUES (%d,%s)",
				playerNode.getPlayerId(),
				ServerUtil.toHexString(dungeonData.genTravelInfos().toByteArray()));
		ServerDataGS.dbCluster.getGameDBClient()
			.executeAsynchronousUpdate(TableChangeEvent.getKey(playerNode.getPlayerId(),
				TableChangeEvent.TRAVEL_TRADER_UPDATETRAVEL),
				playerNode.getPlayerId(),
				sqlCommand);
	}

}
