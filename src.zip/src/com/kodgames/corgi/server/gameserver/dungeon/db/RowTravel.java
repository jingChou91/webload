package com.kodgames.corgi.server.gameserver.dungeon.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.rowset.CachedRowSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;

import com.google.protobuf.InvalidProtocolBufferException;
import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.corgi.server.gameserver.dungeon.data.Travel;
import com.kodgames.gamedata.dbcommon.DBEasy;
import com.kodgames.gamedata.player.PlayerNode;

public class RowTravel
{
	private static final Logger logger = LoggerFactory.getLogger(RowTravel.class);

	// 查询
	public static void selectPrivate(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs,
		PlayerNode playerNode, ConfigDatabase cd)
		throws SQLException
	{
		String sql = "select * from travel_trader where player_id=?";
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, new Object[] {playerNode.getPlayerId()});

		Map<Integer, Travel> travels = new HashMap<Integer, Travel>();// dungeonId_TravelBuy

		if (vrs[queryIndex] != null)
		{
			CachedRowSet rs = vrs[queryIndex];
			while (rs.next())
			{
				byte[] travel_info = rs.getBytes("travel_info");
				DBProtocolsForServer.TravelInfos.Builder travelBuilder = DBProtocolsForServer.TravelInfos.newBuilder();

				if(travel_info != null)
				{
					try
					{
						travelBuilder.mergeFrom(travel_info);
					}
					catch (InvalidProtocolBufferException e)
					{
						logger.error("load player travel_trader infomation failed.");
					}
				}

				// 处理travel_info
				for (int i = 0; i < travelBuilder.getTravelInfoCount(); i++)
				{
					DBProtocolsForServer.TravelInfo travelInfo = travelBuilder.getTravelInfo(i);
					int dungeonId = travelInfo.getDungeonId();
					Travel travel = new Travel();
					travel.setDungeonId(dungeonId);
					travel.setOpenTime(travelInfo.getOpenTime());
					for (int j = 0; j < travelInfo.getTravelBuyCount(); j++)
					{
						DBProtocolsForServer.TravelBuy travelBuy = travelInfo.getTravelBuy(j);
						travel.getTravelBuys().put(travelBuy.getGoodId(), travelBuy.getBuyTime());
					}

					// 检测是否存在该关卡
					if (cd.get_CampaignConfig().GetTravelTradeByDungeonId(dungeonId) != null)
					{
						travels.put(dungeonId, travel);
					}
				}

			}
		}
		playerNode.getPlayerInfo().getDungeonData().setTravels(travels);
	}

}
