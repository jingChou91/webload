package com.kodgames.corgi.server.gameserver.dungeon.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols.DungeonGuideNpc;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryDungeonGuideReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryDungeonGuideRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dungeon.ActivityHandleSecretManager;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_QueryDungeonGuideReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_QueryDungeonGuideReqHandler.class);

	private ActivityHandleSecretManager activityHandleSecretManager = null;
	public CG_QueryDungeonGuideReqHandler(ActivityHandleSecretManager activityHandleSecretManager)
	{
		this.activityHandleSecretManager = activityHandleSecretManager;
	}
	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_QueryDungeonGuideReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_QueryDungeonGuideReq request = (CG_QueryDungeonGuideReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryDungeonGuideRes.Builder builder = GC_QueryDungeonGuideRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_DUNGEON_GUIDE_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_QUERY_DUNGEON_GUIDE_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		int dungeonId = request.getDungeonId();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DUNGEON_GUIDE_LOAD_PLAYER_FAILED;
					break;
				}
				CampaignConfig campaignCfg = cd.get_CampaignConfig();
				if (campaignCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DUNGEON_GUIDE_LOAD_CANPAIGN_CONFIG_FAILED;
					break;
				}
				CampaignConfig.Dungeon dungeonCfg = campaignCfg.GetDungeonById(dungeonId);
				if (dungeonCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DUNGEON_GUIDE_LOAD_DUNGEON_CONFIG_FAILED;
					break;
				}
				int zoneId = dungeonCfg.get_ZoneId();
				CampaignConfig.Zone zoneCfg = cd.get_CampaignConfig().GetZoneById(zoneId);
				if (zoneCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DUNGEON_GUIDE_LOAD_ZONE_CONFIG_FAILED;
					break;
				}
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Secret))
					{
						result = ClientProtocols.E_GAME_SECRET_FUNCTION_NOT_OPEN;
						break;
					}
				}
				else
				{
					if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Dungeon))
					{
						result = ClientProtocols.E_GAME_DUNGEON_FUNCTION_NOT_OPEN;
						break;
					}
				}
				// 判断秘境是否开启
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!activityHandleSecretManager.isActivityActivate(zoneCfg.get_activityId(), playerNode))
					{
						result = ClientProtocols.E_GAME_QUERY_DUNGEON_GUIDE_SECRET_ZONE_NOT_OPEN_FAILED;
						break;
					}
				}
				boolean hasGuide = dungeonCfg.get_hasGuide();
				// 判断是否有攻略
				if (!hasGuide)
				{
					result = ClientProtocols.E_GAME_QUERY_DUNGEON_GUIDE_DUNGEON_NOT_HAVE_GUIDE_FAILED;
					break;
				}
				// 小节索引
				int guideStageIndex = dungeonCfg.get_guideStageIndex();
				ClientServerCommon.CampaignConfig.Stage stageCfg = dungeonCfg.Get_stagesByIndex(guideStageIndex);
				if (stageCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DUNGEON_GUIDE_LOAD_STAGE_CONFIG_FAILED;
					break;
				}
				// 获取该节战斗npc信息
				ClientServerCommon.NpcConfig npcConfig = cd.get_NpcConfig();
				for (int i = 0; i < stageCfg.Get_npcsCount(); i++)
				{// 获取npc的avatarid
					ClientServerCommon.Npc dungeonNpcCfg = stageCfg.Get_npcsByIndex(i);
					ClientServerCommon.NpcConfig.Npc npcCfg = npcConfig.GetNpcById(dungeonNpcCfg.get_npcId());

					DungeonGuideNpc.Builder guideNpcBuilder = DungeonGuideNpc.newBuilder();
					guideNpcBuilder.setAvatarResourceId(npcCfg.get_avatarId());
					guideNpcBuilder.setBattlePosition(dungeonNpcCfg.get_battlePosition());
					guideNpcBuilder.setLevel(npcCfg.get_level());
					guideNpcBuilder.setTraitType(npcCfg.get_traitType());
					guideNpcBuilder.setName(npcCfg.get_name());
					guideNpcBuilder.setBreakthroughLevel(npcCfg.get_breakthroughLevel());
					guideNpcBuilder.setQualityType(npcCfg.get_qualityType());
					guideNpcBuilder.build();
					builder.addDungeonGuideNpcs(guideNpcBuilder);
				}

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
