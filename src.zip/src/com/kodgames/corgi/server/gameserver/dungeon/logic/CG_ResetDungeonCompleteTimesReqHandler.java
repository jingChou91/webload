package com.kodgames.corgi.server.gameserver.dungeon.logic;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.GameConfig;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_ResetDungeonCompleteTimesReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_ResetDungeonCompleteTimesRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dungeon.ActivityHandleSecretManager;
import com.kodgames.corgi.server.gameserver.dungeon.data.Dungeon;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonData;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonMgr;
import com.kodgames.corgi.server.gameserver.dungeon.util.DungeonUtil;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;

public class CG_ResetDungeonCompleteTimesReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_ResetDungeonCompleteTimesReqHandler.class);

	private ActivityHandleSecretManager activityHandleSecretManager = null;
	public CG_ResetDungeonCompleteTimesReqHandler(ActivityHandleSecretManager activityHandleSecretManager)
	{
		this.activityHandleSecretManager = activityHandleSecretManager;
	}

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_ResetDungeonCompleteTimesReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_ResetDungeonCompleteTimesReq request = (CG_ResetDungeonCompleteTimesReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_ResetDungeonCompleteTimesRes.Builder builder = GC_ResetDungeonCompleteTimesRes.newBuilder();
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_RESET_DUNGEON_COMPLETE_TIMES_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_RESET_DUNGEON_COMPLETE_TIMES_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		int dungeonId = request.getDungeonId();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_RESET_DUNGEON_COMPLETE_TIMES_LOAD_PLAYER_FAILD;
					break;
				}
				CampaignConfig campaignCfg = cd.get_CampaignConfig();
				if (campaignCfg == null)
				{
					result = ClientProtocols.E_GAME_RESET_DUNGEON_COMPLETE_TIMES_LOAD_CAMPAIGN_CONFIG_FAILD;
					break;
				}
				CampaignConfig.Dungeon dungeonCfg = campaignCfg.GetDungeonById(dungeonId);// 普通副本 活动副本都能取出来
				if (dungeonCfg == null)
				{
					result = ClientProtocols.E_GAME_RESET_DUNGEON_COMPLETE_TIMES_LOAD_DUNGEON_CONFIG_FAILD;
					break;
				}
				int zoneId = dungeonCfg.get_ZoneId();
				int logEventId = this.getLogEventId(campaignCfg, zoneId);
				CampaignConfig.Zone zoneCfg = cd.get_CampaignConfig().GetZoneById(zoneId);
				if (null == zoneCfg)
				{
					result = ClientProtocols.E_GAME_RESET_DUNGEON_COMPLETE_TIMES_LOAD_ZONE_CONFIG_FAILD;
					break;
				}
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Secret))
					{
						result = ClientProtocols.E_GAME_SECRET_FUNCTION_NOT_OPEN;
						break;
					}
				}
				else
				{
					if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Dungeon))
					{
						result = ClientProtocols.E_GAME_DUNGEON_FUNCTION_NOT_OPEN;
						break;
					}
				}
				// 判断秘境是否开启
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!activityHandleSecretManager.isActivityActivate(zoneCfg.get_activityId(), playerNode))
					{
						result = ClientProtocols.E_GAME_RESET_DUNGEON_COMPLETE_TIMES_SECRET_ZONE_NOT_OPEN_FAILD;
						break;
					}
				}
				GameConfig gameCfg = cd.get_GameConfig();
				if (null == gameCfg)
				{
					result = ClientProtocols.E_GAME_RESET_DUNGEON_COMPLETE_TIMES_LOAD_GAME_CONFIG_FAILD;
					break;
				}
				DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
				Dungeon dungeon = dungeonData.getDungeonById(dungeonId);
				if (dungeon == null)
				{
					result = ClientProtocols.E_GAME_RESET_DUNGEON_COMPLETE_TIMES_NOT_HAVE_DUNGEON_INFO_FAILD;
					break;
				}
				// 判断是否已经达到最大进入次数
				if (dungeon.getTodayCompleteTimes() < dungeonCfg.get_enterCount())
				{
					result = ClientProtocols.E_GAME_RESET_DUNGEON_COMPLETE_TIMES_STILL_HAVE_ENTER_COUNT_FAILD;
					break;
				}
				// 判断是否需要刷新重置次数
				dungeon.refresh_DungeonResetCount(cd);
				if (dungeon.getResetCount() >= DungeonUtil.getMaxDungeonResetCount(cd.get_VipConfig(),
					dungeonCfg,
					playerNode,
					dungeonId,
					campaignCfg.IsActivityZoneId(zoneId)))
				{
					result = ClientProtocols.E_GAME_RESET_DUNGEON_COMPLETE_TIMES_NOT_HAVE_RESET_COUNT_FAILD;
					break;
				}
				// 消耗信息
				ArrayList<Cost> costs = new ArrayList<Cost>();
				Cost notEnoughCost = new Cost();
				// 读取消耗信息
				for (int i = 0; i < dungeonCfg.Get_resetCostsCount(); i++)// GetResetCostCount()
				{

					int costItemId = dungeonCfg.Get_resetCostsByIndex(i).get_id();// GetResetCost(i)
					int costItemCount = dungeonCfg.Get_resetCostsByIndex(i).get_count();
					Cost cost = new Cost(costItemId, costItemCount);
					costs.add(cost);
				}
				// 执行消耗
				if (!CostAndRewardManager.checkCosts(playerNode,
					costs,
					cd,
					KodLogEvent.DungeonLogic_ResetCompleteTimes,
					notEnoughCost))
				{
					crsForClient.setNotEnoughCost(notEnoughCost);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_RESET_DUNGEON_COMPLETE_TIMES_CONSUME_NOT_ENOUGH_FAILD;
					break;
				}
				CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
				crsForCost.setCosts(costs);
				CostAndRewardManager.consumeCosts(playerNode,costs,cd,logEventId,0,0);
				crsForClient.megerCostAndRewardAndSync(crsForCost);
				
				// 修改内存和数据库
				dungeon.setTodayCompleteTimes(0);
				dungeon.setResetCount(dungeon.getResetCount() + 1);
				DungeonMgr.updateDungeon(playerNode, dungeon);

				builder.setTodayCompleteTimes(dungeon.getTodayCompleteTimes());
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}
		builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
	
	private int getLogEventId(CampaignConfig campaignCfg,int zoneId)
	{
		if(campaignCfg.IsActivityZoneId(zoneId))
		{
			return KodLogEvent.DungeonLogic_ResetCompleteTimes_Secret;
		}else
		{
			return KodLogEvent.DungeonLogic_ResetCompleteTimes;
		}
	}

}
