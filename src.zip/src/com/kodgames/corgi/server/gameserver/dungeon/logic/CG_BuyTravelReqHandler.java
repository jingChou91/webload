package com.kodgames.corgi.server.gameserver.dungeon.logic;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_BuyTravelReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_BuyTravelRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dungeon.ActivityHandleSecretManager;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonData;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonMgr;
import com.kodgames.corgi.server.gameserver.dungeon.data.Travel;
import com.kodgames.corgi.server.gameserver.marquee.data.FlowMessageBroadcaster;
import com.kodgames.corgi.server.gameserver.marquee.data.FlowMessageBroadcaster.Position;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class CG_BuyTravelReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_BuyTravelReqHandler.class);
	private ActivityHandleSecretManager activityHandleSecretManager = null;
	public CG_BuyTravelReqHandler(ActivityHandleSecretManager activityHandleSecretManager)
	{
		this.activityHandleSecretManager = activityHandleSecretManager;
	}
	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_BuyTravelReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_BuyTravelReq request = (CG_BuyTravelReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_BuyTravelRes.Builder builder = GC_BuyTravelRes.newBuilder();
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_BUY_TRAVEL_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_BUY_TRAVEL_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		int dungeonId = request.getDungeonId();
		int goodId = request.getGoodId();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_BUY_TRAVEL_LOAD_PLAYER_FAILED;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.TravelTrader))
				{
					result = ClientProtocols.E_GAME_TRAVEL_TRADER_FUNCTION_NOT_OPEN;
					break;
				}
				CampaignConfig campaignCfg = cd.get_CampaignConfig();
				if (campaignCfg == null)
				{
					result = ClientProtocols.E_GAME_BUY_TRAVEL_LOAD_CAMPAIGN_CONFIG_FAILED;
					break;
				}
				CampaignConfig.Dungeon dungeonCfg = campaignCfg.GetDungeonById(dungeonId);
				if (dungeonCfg == null)
				{
					result = ClientProtocols.E_GAME_BUY_TRAVEL_LOAD_DUNGEON_CONFIG_FAILED;
					break;
				}
				int zoneId = dungeonCfg.get_ZoneId();
				int logEventId = this.getLogEventId(campaignCfg, zoneId);
				CampaignConfig.Zone zoneCfg = campaignCfg.GetZoneById(zoneId);
				if (zoneCfg == null)
				{
					result = ClientProtocols.E_GAME_BUY_TRAVEL_LOAD_ZONE_CONFIG_FAILED;
					break;
				}
				// 判断秘境是否开启
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!activityHandleSecretManager.isActivityActivate(zoneCfg.get_activityId(), playerNode))
					{
						result = ClientProtocols.E_GAME_BUY_TRAVEL_SECRET_ZONE_NOT_OPEN_FAILD;
						break;
					}
				}
				CampaignConfig.TravelTrader travelTraderCfg = campaignCfg.GetTravelTradeByDungeonId(dungeonId);
				if (travelTraderCfg == null)
				{
					result = ClientProtocols.E_GAME_BUY_TRAVEL_LOAD_TRAVEL_TRADER_CONFIG_FAILED;
					break;
				}
				CampaignConfig.TravelGood travelGoodCfg = campaignCfg.GetTravelGoodById(goodId);
				if (travelGoodCfg == null)
				{
					result = ClientProtocols.E_GAME_BUY_TRAVEL_LOAD_TRAVEL_GOOD_CONFIG_FAILED;
					break;
				}
				if (!playerNode.getPlayerInfo().getDungeonData().getZones().containsKey(zoneId))
				{
					result = ClientProtocols.E_GAME_BUY_TRAVEL_NOT_HAVE_ZONE_INFO_FAILED;
					break;
				}
				DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();
				// 判断云游商人是否激活
				Travel travel = dungeonData.getTravels().get(dungeonId);
				if (travel == null || travel.getOpenTime() == 0)
				{
					result = ClientProtocols.E_GAME_BUY_TRAVEL_NOT_HAVE_TRAVEL_INFO_FAILED;
					break;
				}
				// 判断商品是否已经购买
				if (travel.checkGoodAlreadyBuy(goodId))
				{
					result = ClientProtocols.E_GAME_BUY_TRAVEL_GOOD_IS_ALREADY_BUY_FAILED;
					break;
				}
				// 判断是否在购买时间倒计时之内
				long continueTime = travelGoodCfg.get_continueTime() * 1000;
				if (continueTime > 0)
				{
					long openTime = travel.getOpenTime();
					long endTime = openTime + continueTime;
					if (System.currentTimeMillis() > endTime)
					{
						result = ClientProtocols.E_GAME_BUY_TRAVEL_NOT_IN_OPEN_TIME_FAILED;
						break;
					}
				}

				// 消耗信息
				ArrayList<Cost> costs = new ArrayList<Cost>();
				Cost notEnoughCost = new Cost();
				for (int i = 0; i < travelGoodCfg.Get_costsCount(); i++)
				{
					int costItemId = travelGoodCfg.Get_costsByIndex(i).get_id();
					int costItemCount = travelGoodCfg.Get_costsByIndex(i).get_count();
					Cost cost = new Cost(costItemId, costItemCount);
					costs.add(cost);
				}
				// 执行消耗
				if (!CostAndRewardManager.checkCosts(playerNode,
					costs,
					cd,
					logEventId,
					notEnoughCost))
				{
					crsForClient.setNotEnoughCost(notEnoughCost);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_BUY_TRAVEL_CONSUME_NOT_ENOUGH_FAILED;
					break;
				}
				CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
				crsForCost.setCosts(costs);
				crsForClient.megerCostAndRewardAndSync(crsForCost);
				CostAndRewardManager.consumeCosts(playerNode, costs, cd, logEventId, 0, 0);

				// 获得具体商品
				Reward reward = new Reward();
				for (int i = 0; i < travelGoodCfg.Get_rewardsCount(); i++)
				{
					reward.megerReward(new Reward().fromClientServerCommon(travelGoodCfg.Get_rewardsByIndex(i)));
				}

				// 修改内存
				CostAndRewardAndSync crsForReward = new CostAndRewardAndSync();
				CostAndRewardManager.addReward(playerNode, reward, cd, logEventId);
				crsForReward.mergeReward(reward);
				crsForClient.megerCostAndRewardAndSync(crsForReward);

				// 更新云游商人购买信息
				DungeonMgr.updateTravel(playerNode, dungeonId, goodId);
				// 返回云游商人信息
				builder.setTravelData(travel.toProtoBuffer(campaignCfg, dungeonId));
				
				// 跑马灯
				FlowMessageBroadcaster.prepareBroadcastRewardMsg(playerNode, reward, Position.TRAVEL);
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
	
	private int getLogEventId(CampaignConfig campaignCfg,int zoneId)
	{
		if(campaignCfg.IsActivityZoneId(zoneId))
		{
			return KodLogEvent.DungeonLogic_BuyTravel_Secret;
		}else
		{
			return KodLogEvent.DungeonLogic_BuyTravel;
		}
	}

}
