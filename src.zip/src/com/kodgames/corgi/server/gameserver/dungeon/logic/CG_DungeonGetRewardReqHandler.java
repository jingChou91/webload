package com.kodgames.corgi.server.gameserver.dungeon.logic;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_DungeonGetRewardReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_DungeonGetRewardRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dungeon.ActivityHandleSecretManager;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonData;
import com.kodgames.corgi.server.gameserver.dungeon.data.DungeonMgr;
import com.kodgames.corgi.server.gameserver.marquee.data.FlowMessageBroadcaster;
import com.kodgames.corgi.server.gameserver.marquee.data.FlowMessageBroadcaster.Position;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class CG_DungeonGetRewardReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_DungeonGetRewardReqHandler.class);
	private ActivityHandleSecretManager activityHandleSecretManager = null;
	public CG_DungeonGetRewardReqHandler(ActivityHandleSecretManager activityHandleSecretManager)
	{
		this.activityHandleSecretManager = activityHandleSecretManager;
	}
	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_DungeonGetRewardReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_DungeonGetRewardReq request = (CG_DungeonGetRewardReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_DungeonGetRewardRes.Builder builder = GC_DungeonGetRewardRes.newBuilder();
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_DUNGEON_GET_REWARD_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_DUNGEON_GET_REWARD_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		int zoneId = request.getZoneId();
		int difficultyType = request.getDungeonDifficulty();
		int boxIndex = request.getBoxIndex();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_DUNGEON_GET_REWARD_LOAD_PLAYER_FAILD;
					break;
				}
				CampaignConfig campaignCfg = cd.get_CampaignConfig();
				if (campaignCfg == null)
				{
					result = ClientProtocols.E_GAME_DUNGEON_GET_REWARD_LOAD_CAMPAIGN_CONFIG_FAILD;
					break;
				}
				CampaignConfig.Zone zoneCfg = cd.get_CampaignConfig().GetZoneById(zoneId);
				if (zoneCfg == null)
				{
					result = ClientProtocols.E_GAME_DUNGEON_GET_REWARD_LOAD_ZONE_CONFIG_FAILD;
					break;
				}
				int logEventId = this.getLogEventId(campaignCfg, zoneId);
				if (campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Secret))
					{
						result = ClientProtocols.E_GAME_SECRET_FUNCTION_NOT_OPEN;
						break;
					}
				}
				else
				{
					if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Dungeon))
					{
						result = ClientProtocols.E_GAME_DUNGEON_FUNCTION_NOT_OPEN;
						break;
					}
				}
				//判断秘境是否开启
				if(campaignCfg.IsActivityZoneId(zoneId))
				{
					if (!activityHandleSecretManager.isActivityActivate(zoneCfg.get_activityId(), playerNode))
					{
						result = ClientProtocols.E_GAME_DUNGEON_GET_REWARD_SECRET_ZONE_NOT_OPEN_FAILD;
						break;
					}
				}
				CampaignConfig.DungeonDifficulty difficultyCfg =
					zoneCfg.GetDungeonDifficultyByDifficulty(difficultyType);
				if (null == difficultyCfg)
				{
					result = ClientProtocols.E_GAME_DUNGEON_GET_REWARD_LOAD_DIFFICULTY_CONFIG_FAILD;
					break;
				}
				CampaignConfig.StarRewardCondition starRewardConditionCfg =
					difficultyCfg.Get_starRewardConditionsByIndex(boxIndex);
				if (starRewardConditionCfg == null)
				{
					result = ClientProtocols.E_GAME_DUNGEON_GET_REWARD_LOAD_STAR_REWARD_CONDITION_CONFIG_FAILD;
					break;
				}
				int starRewardId = starRewardConditionCfg.get_starRewardId();
				CampaignConfig.StarReward starRewardCfg = cd.get_CampaignConfig().GetStarRewardById(starRewardId);
				if (starRewardCfg == null)
				{
					result = ClientProtocols.E_GAME_DUNGEON_GET_REWARD_LOAD_STAR_REWARD_CONFIG_FAILD;
					break;
				}
				DungeonData dungeonData = playerNode.getPlayerInfo().getDungeonData();

				// 如果奖励已经领取
				if (dungeonData.checkBoxRewardPicked(zoneId, difficultyType, boxIndex))
				{
					result = ClientProtocols.E_GAME_DUNGEON_GET_REWARD_LOAD_REWARD_ALREADY_PICKED_FAILD;
					break;
				}

				// 判断星星数量是否足够
				int stars = dungeonData.getStarsCount(zoneId, difficultyType, difficultyCfg);
				if (stars < starRewardConditionCfg.get_requireStarCount())
				{
					result = ClientProtocols.E_GAME_DUNGEON_GET_REWARD_LOAD_STAR_NOT_ENOUGH_FAILD;
					break;
				}

				// 修改宝箱领取记录
				DungeonMgr.addBoxRewardRecord(playerNode, request.getZoneId(), request.getDungeonDifficulty(), boxIndex);

				// 获得奖励
				Reward reward = new Reward();
				for (int i = 0; i < starRewardCfg.Get_rewardsCount(); i++)
				{
					reward.megerReward(new Reward().fromClientServerCommon(starRewardCfg.Get_rewardsByIndex(i)));
				}

				// 修改内存
				CostAndRewardAndSync crsForReward = new CostAndRewardAndSync();
				CostAndRewardManager.addReward(playerNode, reward, cd, logEventId);
				crsForReward.mergeReward(reward);
				crsForClient.megerCostAndRewardAndSync(crsForReward);


				List<Integer> pickedIndexs = dungeonData.getBoxRewardPicked(zoneId, difficultyType);
				
				for (Integer index : pickedIndexs)
				{
					builder.addBoxPickedIndexs(index);
				}
				
				//小助手
				playerNode.getPlayerInfo().getAssisantData().getDungeonStartReward().notifyObservers();
				
				//跑马灯
				FlowMessageBroadcaster.prepareBroadcastRewardMsg(playerNode, reward, Position.DUNGEON);

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);

		return HandlerAction.TERMINAL;
	}
	
	private int getLogEventId(CampaignConfig campaignCfg,int zoneId)
	{
		if(campaignCfg.IsActivityZoneId(zoneId))
		{
			return KodLogEvent.DungeonLogic_GetReward_Secret;
		}else
		{
			return KodLogEvent.DungeonLogic_GetReward;
		}
	}

}
