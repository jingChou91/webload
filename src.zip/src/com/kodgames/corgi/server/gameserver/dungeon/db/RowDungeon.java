package com.kodgames.corgi.server.gameserver.dungeon.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.rowset.CachedRowSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;

import com.google.protobuf.InvalidProtocolBufferException;
import com.kodgames.corgi.server.gameserver.dungeon.data.Dungeon;
import com.kodgames.gamedata.dbcommon.DBEasy;
import com.kodgames.gamedata.player.PlayerNode;

public class RowDungeon
{
	private static final Logger logger = LoggerFactory.getLogger(RowDungeon.class);

	// 查询
	public static void selectPrivate(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs,
		PlayerNode playerNode, ConfigDatabase cd)
		throws SQLException
	{
		String sql = "select * from dungeon where player_id=?";
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, new Object[] {playerNode.getPlayerId()});

		Map<Integer, Integer> zones = new HashMap<Integer, Integer>();// zoneId_status
		Map<Integer, Map<Integer, Dungeon>> dungeons = new HashMap<Integer, Map<Integer, Dungeon>>();// zoneId_(dungeon_id_dungeon)
		Map<Integer, Map<Integer, List<Integer>>> boxRecords = new HashMap<Integer, Map<Integer, List<Integer>>>();// zoneId_difficulty_boxIndexs

		if (vrs[queryIndex] != null)
		{
			CachedRowSet rs = vrs[queryIndex];
			while (rs.next())
			{
				int zoneId = rs.getInt("zone_id");
				int zoneStatus = rs.getInt("zone_status");
				zones.put(zoneId, zoneStatus);

				byte[] dungeon_info = rs.getBytes("dungeon_info");
				byte[] box_reward_record = rs.getBytes("box_reward_record");

				com.kodgames.corgi.protocol.DBProtocolsForServer.DungeonInfos.Builder dungeonBuilder =
					com.kodgames.corgi.protocol.DBProtocolsForServer.DungeonInfos.newBuilder();
				com.kodgames.corgi.protocol.DBProtocolsForServer.BoxRewardRecords.Builder boxRewardBuilder =
					com.kodgames.corgi.protocol.DBProtocolsForServer.BoxRewardRecords.newBuilder();
				try
				{
					if (dungeon_info != null)
					{
						dungeonBuilder.mergeFrom(dungeon_info);
					}
					if (box_reward_record != null)
					{
						boxRewardBuilder.mergeFrom(box_reward_record);
					}

				}
				catch (InvalidProtocolBufferException e)
				{
					logger.error("load player dungeon infomation failed.");
				}

				// 处理dungeon_info
				for (int i = 0; i < dungeonBuilder.getDungeonInfosCount(); i++)
				{
					com.kodgames.corgi.protocol.DBProtocolsForServer.DungeonInfo dungeonInfo =
						dungeonBuilder.getDungeonInfos(i);
					Integer dungeonId = dungeonInfo.getDungeonId();
					Dungeon dungeon =
						new Dungeon(zoneId, dungeonId, dungeonInfo.getBestRecord(),
							dungeonInfo.getTodayCompleteTimes(), dungeonInfo.getLastRefreshTime(),
							dungeonInfo.getResetCount(), dungeonInfo.getLastResetTime(), dungeonInfo.getStatus(),
							dungeonInfo.getDialogState());

					// 检测是否存在该关卡
					if (cd.get_CampaignConfig().GetDungeonById(dungeonId) != null)
					{
						if (dungeons.containsKey(zoneId))
						{
							dungeons.get(zoneId).put(dungeonId, dungeon);
						}
						else
						{
							Map<Integer, Dungeon> id_Dungeon = new HashMap<Integer, Dungeon>();
							id_Dungeon.put(dungeonId, dungeon);
							dungeons.put(zoneId, id_Dungeon);
						}
					}
				}

				// 处理box_reward_record
				for (int i = 0; i < boxRewardBuilder.getBoxRewardRecordsCount(); i++)
				{
					com.kodgames.corgi.protocol.DBProtocolsForServer.BoxRewardRecord boxRecord =
						boxRewardBuilder.getBoxRewardRecords(i);

					Integer difficulty = boxRecord.getDifficulty();
					String recordInfo = boxRecord.getRecord();
					String[] records = recordInfo.split(",");
					List<Integer> list = new ArrayList<Integer>();
					// 将字符串数组转为list
					for (int j = 0; j < records.length; j++)
					{
						Integer record = Integer.parseInt(records[j]);
						if (!list.contains(record))
						{
							list.add(record);
						}
					}
					if (boxRecords.containsKey(zoneId))
					{
						boxRecords.get(zoneId).put(difficulty, list);
					}
					else
					{
						Map<Integer, List<Integer>> difficulty_Indexs = new HashMap<Integer, List<Integer>>();
						difficulty_Indexs.put(difficulty, list);
						boxRecords.put(zoneId, difficulty_Indexs);
					}

				}

			}
		}
		playerNode.getPlayerInfo().getDungeonData().setZones(zones);
		playerNode.getPlayerInfo().getDungeonData().setDungeons(dungeons);
		playerNode.getPlayerInfo().getDungeonData().setBoxRecords(boxRecords);
	}
}
