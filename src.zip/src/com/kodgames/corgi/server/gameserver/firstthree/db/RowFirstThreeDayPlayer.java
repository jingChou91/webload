package com.kodgames.corgi.server.gameserver.firstthree.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.server.gameserver.firstthree.data.FirstThreeData;
import com.kodgames.gamedata.dbcommon.DBEasy;
import com.kodgames.gamedata.player.PlayerNode;

public class RowFirstThreeDayPlayer
{
	private static final Logger logger = LoggerFactory.getLogger(RowFirstThreeDayPlayer.class);

	// 查询
	public static void selectPrivate(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs,
		PlayerNode playerNode)
		throws SQLException
	{
		String sql = "select is_send_email,normal_tavern_time, ten_tavern_time from first_three_day where player_id=?";
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, new Object[] {playerNode.getPlayerId()});

		FirstThreeData myData = null;

		if (vrs[queryIndex] != null)
		{
			CachedRowSet rs = vrs[queryIndex];
			myData = playerNode.getPlayerInfo().getFirstThreeData();
			
			while (rs.next())
			{
				int is_send_email = rs.getInt("is_send_email");
				if(1== is_send_email)
				{
					myData.setSendEmail(true);
				}
				else
				{
					myData.setSendEmail(false);
				}
				long normal_tavern_time = rs.getLong("normal_tavern_time");
				myData.setNormalTravenActivity(normal_tavern_time);
				long ten_tavern_time = rs.getLong("ten_tavern_time");
				myData.setTenTravenActivity(ten_tavern_time);
			}
		}
	}
}
