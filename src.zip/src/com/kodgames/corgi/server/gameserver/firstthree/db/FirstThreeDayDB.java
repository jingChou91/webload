package com.kodgames.corgi.server.gameserver.firstthree.db;

import com.kodgames.corgi.server.dbclient.KodLog;
import com.kodgames.corgi.server.dbclient.TableChangeEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.firstthree.data.FirstThreeData;
import com.kodgames.gamedata.player.PlayerNode;

public class FirstThreeDayDB
{
	public static void replaceToFirstThree(PlayerNode playerNode )
	{
		int playerId = playerNode.getPlayerId();
		FirstThreeData firstThreeDay = playerNode.getPlayerInfo().getFirstThreeData();
		int sendEmail = firstThreeDay.isSendEmail()? 1 : 0;
		long normalTavernTime = firstThreeDay.getNormalTravenActivity();
		long tenTavernTime = firstThreeDay.getTenTravenActivity();
		
		String currentTime = KodLog.getDatetime(System.currentTimeMillis());
		String sql =  String.format("replace into first_three_day(player_id,is_send_email,normal_tavern_time,ten_tavern_time,last_update_time) values(%d,%d,%d,%d,'%s')", playerId, sendEmail,normalTavernTime,tenTavernTime, currentTime);
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(TableChangeEvent.getKey(playerId, TableChangeEvent.FIRSTTHREEDAY_UPDATE),playerId, sql);
	}

}
