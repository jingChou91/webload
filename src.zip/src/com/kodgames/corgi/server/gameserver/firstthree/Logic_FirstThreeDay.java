package com.kodgames.corgi.server.gameserver.firstthree;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._ActivityType;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityEnviroment;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityHandler;
import com.kodgames.gamedata.player.PlayerNode;

public class Logic_FirstThreeDay extends ActivityHandler 
{

	public Logic_FirstThreeDay() 
	{
		super(_ActivityType.FIRSTTHREEDAY);
	}

	@Override
	public boolean start(ActivityEnviroment activityEnv)
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
		int activityId = cd.get_FirstThreeDayConfig().get_ActivtyId();
		
		ClientServerCommon.ActivityConfig.Activity activityConfig = cd.get_ActivityConfig().GetActivityById(activityId);
		registerActivity(activityEnv, activityConfig);
		return false;
	}

	@Override
	public boolean isActivityActivate(int activityId, PlayerNode playerNode) 
	{
		boolean isStart = checkIsStart(activityId, playerNode);
		return isStart;
	}
	
	public void handleConfigRefresh(ConfigDatabase newCfg, ActivityEnviroment activityEnv)
	{
		int activityId = newCfg.get_FirstThreeDayConfig().get_ActivtyId();
		ClientServerCommon.ActivityConfig.Activity activityConfig = newCfg.get_ActivityConfig().GetActivityById(activityId);
		checkActivityTimeChanged(activityEnv, activityConfig);
	}
}
