package com.kodgames.corgi.server.gameserver.firstthree.data;

import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.AvatarConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.EquipmentConfig;
import ClientServerCommon.FirstThreeDayConfig;
import ClientServerCommon.SkillConfig;
import ClientServerCommon._ActivityType;

import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityMgr;
import com.kodgames.corgi.server.gameserver.email.util.specialemail.EmailFirstThreeDayUtil;
import com.kodgames.corgi.server.gameserver.firstthree.db.FirstThreeDayDB;
import com.kodgames.corgi.server.gameserver.firstthree.db.RowFirstThreeDayPlayer;
import com.kodgames.corgi.server.gameserver.illustration.data.IllustrationData;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Reward;
import com.kodgames.gamedata.player.costandreward.RewardGen;

public class FristThreeDayMgr
{
	private static final Logger logger = LoggerFactory.getLogger(RowFirstThreeDayPlayer.class);

	public static void checkAndSendEmail(ConfigDatabase cd, PlayerNode playerNode)
	{
		if (true == playerNode.getPlayerInfo().getFirstThreeData().isSendEmail())
		{
			logger.debug("playerId={}, alreay send firstThreeDay email", playerNode.getPlayerId());
			return;
		}
		
		try
		{
			FirstThreeDayConfig firstThreeDayConfig = cd.get_FirstThreeDayConfig();
			// 活动Id
			int activityId = firstThreeDayConfig.get_ActivtyId();
			// 需要集齐的数量
			int count = firstThreeDayConfig.get_Count();
			// 卡片类型
			int type = firstThreeDayConfig.get_Type();
			// 卡片品质
			int quantityLevel = firstThreeDayConfig.get_QualityLevel();
			boolean isFirstThreeDayOpen = firstThreeDayConfig.get_IsFirstThreeDayOpen();

			boolean isOpen = ActivityMgr.getInstance().checkIsStart(_ActivityType.FIRSTTHREEDAY, activityId, playerNode);
			logger.debug("FirstThreeDay,playerId={}, isFunctionThreeDayOpen={}, isOpen={}", playerNode.getPlayerId(), isFirstThreeDayOpen, isOpen);
			if (isFirstThreeDayOpen && isOpen)
			{
				IllustrationData illustrationData = playerNode.getPlayerInfo().getIllustrationData();
				List<Integer> cardIds = illustrationData.getCardIds();
				int alreadyCount = 0;
				for (Integer cardId : cardIds)
				{
					int typeId = ClientServerCommon.IDSeg.ToAssetType(cardId);
					// ClientServerCommon.IDSeg._AssetType.Avatar
					if (typeId == type)
					{
						switch (type)
						{
							case ClientServerCommon.IDSeg._AssetType.Avatar:
								AvatarConfig.Avatar avatarCfg = cd.get_AvatarConfig().GetAvatarById(cardId);
								if (avatarCfg.get_qualityLevel() == quantityLevel)
								{
									alreadyCount++;
								}
								break;
							case ClientServerCommon.IDSeg._AssetType.Equipment:
								EquipmentConfig.Equipment equipment = cd.get_EquipmentConfig().GetEquipmentById(cardId);
								if (equipment.get_qualityLevel() == quantityLevel)
								{
									alreadyCount++;
								}
								break;
							case ClientServerCommon.IDSeg._AssetType.CombatTurn:
								SkillConfig.Skill skill = cd.get_SkillConfig().GetSkillById(cardId);
								if (skill.get_qualityLevel() == quantityLevel)
								{
									alreadyCount++;
								}
								break;
						}
					}
				}
				logger.debug("FirstThreeDay playerId={}, alreadyCount={}, alreadyCount={}", playerNode.getPlayerId(), count, alreadyCount);
				if (count <= alreadyCount)
				{
					// 发送奖励
					Reward reward = RewardGen.getRewardFromCfgRewardList(firstThreeDayConfig.get_Rewards());
					EmailFirstThreeDayUtil.sendPlayerEmailsByRewardSetId(playerNode.getPlayerId(),
						reward,
						System.currentTimeMillis());
					playerNode.getPlayerInfo().getFirstThreeData().setSendEmail(true);
					FirstThreeDayDB.replaceToFirstThree(playerNode);
					logger.info("send firstThreeDay email, playerId={}, type={}", playerNode.getPlayerId(), type);
				}
			}
			else
			{
				logger.debug(" firstThreeDay activity is close");
			}
		}
		catch (Exception e)
		{
			logger.error("{}", ExceptionUtils.getStackTrace(e));
		}
	}
}
