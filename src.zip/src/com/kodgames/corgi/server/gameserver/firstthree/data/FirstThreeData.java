package com.kodgames.corgi.server.gameserver.firstthree.data;

public class FirstThreeData 
{

	private boolean isSendEmail = false;//是否已经发送邮件
	private long tenTravenActivity = 0;
	private long normalTravenActivity = 0;
	
	public boolean isSendEmail()
	{
		return isSendEmail;
	}
	
	public void setSendEmail(boolean isSendEmail)
	{
		this.isSendEmail = isSendEmail;
	}

	public long getTenTravenActivity()
	{
		return tenTravenActivity;
	}

	public void setTenTravenActivity(long tenTravenActivity)
	{
		this.tenTravenActivity = tenTravenActivity;
	}

	public long getNormalTravenActivity()
	{
		return normalTravenActivity;
	}

	public void setNormalTravenActivity(long normalTravenActivity)
	{
		this.normalTravenActivity = normalTravenActivity;
	}

}
