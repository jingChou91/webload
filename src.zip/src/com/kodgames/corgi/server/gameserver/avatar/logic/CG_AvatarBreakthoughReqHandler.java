package com.kodgames.corgi.server.gameserver.avatar.logic;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.AvatarConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_AvatarBreakthoughtReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_AvatarBreakthoughtRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.KodLogUtil;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.avatar.data.Avatar;
import com.kodgames.corgi.server.gameserver.avatar.data.AvatarMgr;
import com.kodgames.corgi.server.gameserver.avatar.data.Card;
import com.kodgames.corgi.server.gameserver.marquee.data.FlowMessageBroadcaster;
import com.kodgames.corgi.server.gameserver.position.data.PositionMgr;
import com.kodgames.gamedata.player.PlayerAttributeMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.genplayer.PowerMgr;

public class CG_AvatarBreakthoughReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_AvatarBreakthoughReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		CG_AvatarBreakthoughtReq request = (CG_AvatarBreakthoughtReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_AvatarBreakthoughtRes.Builder builder = GC_AvatarBreakthoughtRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_AVATAR_BREAKTHOUGHT_RES);
		builder.setCallback(request.getCallback());
		int result = ClientProtocols.E_GAME_AVATAR_BREAKTHOUGHT_SUCCESS;
		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		logger.info("recv CG_AvatarBreakthoughtReq , playerId = {}", playerId);

		// 角色GUID
		Guid avatarGUID = Guid.genNewGuid(request.getAvatarGUID());
		// 被销毁的角色的GUID集合
		List<String> destroyAvatarGUIDs = request.getDestroyAvatarGUIDsList();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				// 玩家信息
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_AVATAR_BREAKTHOUGHT_FAILED_GET_PLAYERNODE_FAILED;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd,
					playerNode,
					ClientServerCommon._OpenFunctionType.AvatarBreakThrough))
				{
					result = ClientProtocols.E_GAME_AVATAR_BREAKTHOUGHT_FUNCTION_NOT_OPEN;
					break;
				}

				// 角色信息
				Avatar avatar = AvatarMgr.getAvatar(avatarGUID, playerNode);
				if (avatar == null)
				{
					result = ClientProtocols.E_GAME_AVATAR_BREAKTHOUGHT_FAILED_AVATAR_GUID_WRONG;
					break;
				}

				int breakthoughtLevel = avatar.getBreakthoughtLevel();

				int resourceId = avatar.getResourceId();
				// 角色配置信息
				AvatarConfig.Avatar avatar_cfg = cd.get_AvatarConfig().GetAvatarById(resourceId);
				if (avatar_cfg == null)
				{
					logger.error("E_GAME_AVATAR_BREAKTHOUGHT_FAILED_AVATARCONFIG_ERROR avatar.getResourceId = {}",
						avatar.getResourceId());
					result = ClientProtocols.E_GAME_AVATAR_BREAKTHOUGHT_FAILED_AVATARCONFIG_ERROR;
					break;
				}

				// 角色突破配置信息
				AvatarConfig.AvatarBreakthrough avatarBreakthrough =
					avatar_cfg.GetAvatarBreakthrough(breakthoughtLevel);
				if (null == avatarBreakthrough || avatarBreakthrough.get_breakThrough() == null)
				{
					result = ClientProtocols.E_GAME_AVATAR_BREAKTHOUGHT_FAILED_AVATARCONFIG_ERROR;
					break;
				}

				// 最大突破级别
				int maxBreakThroughLevel = avatar_cfg.GetMaxBreakthoughtLevel();
				if (maxBreakThroughLevel <= avatar.getBreakthoughtLevel())
				{
					result = ClientProtocols.E_GAME_AVATAR_BREAKTHOUGHT_FAILED_EXCEED_MAX_BREAKTHOUGHLEVEL;
					break;
				}
				// 检测角色是否满级
				if (avatar.getLevel() < avatarBreakthrough.get_breakThrough().get_powerUpLevelLimit())
				{
					result = ClientProtocols.E_GAME_AVATAR_BREAKTHOUGHT_FAILED_PLAYER_LEVEL_NOT_ENOUGH;
					break;
				}
				// 检测被销毁的角色卡信息是否正确
				if (!checkDestoryGUIDS(playerNode, destroyAvatarGUIDs, avatarGUID))
				{
					result = ClientProtocols.E_GAME_AVATAR_BREAKTHOUGHT_FAILED_DESTORYGUIDS_WRONG;
					break;
				}

				int costItemId = avatarBreakthrough.get_breakThrough().get_itemCostItemId();
				int leastSameCardCount = avatarBreakthrough.get_leastSameCardCount();

				// 检查消耗是否足够
				ArrayList<Cost> costs = new ArrayList<>();
				int costItemCount = avatarBreakthrough.get_breakThrough().get_itemCostItemCount();
				if (avatarBreakthrough.get_breakThrough().get_isCostSameCardItem())
				{
					// 检查至少需要的同名卡数量是否正确
					if (destroyAvatarGUIDs.size() < leastSameCardCount)
					{
						result = ClientProtocols.E_GAME_AVATAR_BREAKTHOUGHT_FAILED_SAME_CARD_NOT_ENOUGH;
						break;
					}

					if (leastSameCardCount < 0)
					{
						result = ClientProtocols.E_GAME_AVATAR_BREAKTHOUGHT_FAILED_AVATARCONFIG_ERROR;
						break;
					}

					for (int i = 0; i < destroyAvatarGUIDs.size(); i++)
					{
						costs.add(new Cost(avatar.getResourceId(), Guid.genNewGuid(request.getDestroyAvatarGUIDs(i))));
						costItemCount -= avatarBreakthrough.get_breakThrough().get_sameCardDeductItemCount();
						if (costItemCount <= 0)
						{
							break;
						}
					}
					if (costItemCount > 0)
					{
						costs.add(new Cost(costItemId, costItemCount));
					}

				}

				for (int i = 0; i < avatarBreakthrough.get_breakThrough().Get_otherCostsCount(); i++)
				{
					ClientServerCommon.Cost cost = avatarBreakthrough.get_breakThrough().Get_otherCostsByIndex(i);
					Cost otherCost = new Cost(cost.get_id(), cost.get_count());
					costs.add(otherCost);
				}

				Cost notEnoughCost = new Cost();
				if (false == CostAndRewardManager.checkCosts(playerNode,
					costs,
					cd,
					KodLogEvent.AvatarLogic_AvatarBreakthought,
					notEnoughCost))
				{
					crsForClient.setNotEnoughCost(notEnoughCost);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_AVATAR_BREAKTHOUGHT_FAILED_CONSUMABLE_NOT_ENOUGH;
					break;
				}

				CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
				CostAndRewardManager.consumeCosts(playerNode,
					costs,
					cd,
					KodLogEvent.AvatarLogic_AvatarBreakthought,
					0,
					0);
				crsForCost.setCosts(costs);
				crsForClient.megerCostAndRewardAndSync(crsForCost);

				// 更新数据库
				boolean isBasicCardBefore = Card.isBasicCard(playerNode, avatar);
				avatar.setBreakthoughtLevel(avatar.getBreakthoughtLevel() + 1);
				AvatarMgr.updateAvatar(playerNode, avatar, isBasicCardBefore);

				// Log
				KodLogUtil.avatar_breakthought(playerNode, avatar, cd);
				BPUtil.xktp(playerNode,
					avatar.getResourceId(),
					avatar.getBreakthoughtLevel(),
					breakthoughtLevel,
					destroyAvatarGUIDs.size(),
					costItemCount > 0 ? costItemCount : 0);

				builder.setBreakThoughLevel(avatar.getBreakthoughtLevel());
				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());

				if (avatar.getBreakthoughtLevel() > 5)
				{
					FlowMessageBroadcaster.prepareBroadcastMsg(playerNode,
						avatar.getResourceId(),
						FlowMessageBroadcaster.BroadcastType.AVATARBREAKTHROUGH,
						avatar.getBreakthoughtLevel());
				}
				//战力
				float power = PowerMgr.calPower(playerNode, cd);
				PlayerAttributeMgr.setPlayerPower(playerNode, (int)power);

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);

		return HandlerAction.TERMINAL;
	}

	private boolean checkDestoryGUIDS(PlayerNode playerNode, List<String> destoryGUIDs, Guid avatarGUID)
	{
		int resourseId = AvatarMgr.getAvatar(avatarGUID, playerNode).getResourceId();
		HashSet<String> guids = new HashSet<>();
		for (String destroyGUID : destoryGUIDs)
		{
			// 判断角色是或否存在
			if ((AvatarMgr.getAvatar(Guid.genNewGuid(destroyGUID), playerNode) == null))
			{
				return false;
			}
			// 判断资源id是否相同
			if ((resourseId != AvatarMgr.getAvatar(Guid.genNewGuid(destroyGUID), playerNode).getResourceId()))
			{
				return false;
			}

			// 判断是否在上阵
			if (PositionMgr.checkGuid(Guid.genNewGuid(destroyGUID), playerNode) == false)
			{
				return false;
			}

			guids.add(destroyGUID);
		}

		// 判断GUIDS有没有重复
		if (guids.size() != destoryGUIDs.size())
		{
			return false;
		}

		return true;
	}
}
