package com.kodgames.corgi.server.gameserver.avatar.data;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.AvatarConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.EquipmentConfig;
import ClientServerCommon.IMathParser;

import com.kodgames.corgi.gameconfiguration.IExpressionObj;
import com.kodgames.gamedata.player.costandreward.ItemType;

// 卡牌公式适配器，专门用来适配卡牌出售中关于出售价格公式的计算，特别是当出售收益多于1件物品时使用
public class CardExpressionAdapater implements IExpressionObj
{
	private static Logger logger = LoggerFactory.getLogger(CardExpressionAdapater.class);

	private Card card;
	private ClientServerCommon.Reward reward;

	public CardExpressionAdapater(Card card, ClientServerCommon.Reward reward)
	{
		this.card = card;
		this.reward = reward;
	}

	@Override
	public void setupVariable(IMathParser parser, ConfigDatabase cd)
	{
		int resourceId = card.getResourceId();

		if (ItemType.isAvatar(resourceId))
		{
			AvatarConfig.Avatar avatarConfig = cd.get_AvatarConfig().GetAvatarById(resourceId);
			if (avatarConfig == null)
			{
				logger.error("calc AvatarConfig_SellPrice failed avatarConfig is null : avatarResourceId={}", resourceId);
			}
			if (reward == null)
			{
				logger.error("calc AvatarConfig_SellPrice failed SellGeneralRewards is null : avatarResourceId={}", resourceId);
			}

			float basicPrice = reward.get_count();
			float breakthroughLevel = card.getBreakthoughtLevel();

			parser.SetVariable("BasicPrice", basicPrice);
			parser.SetVariable("BreakThrough_Level", breakthroughLevel);
		}
		else if (ItemType.isEquipment(resourceId))
		{
			EquipmentConfig.Equipment equipmentConfig = cd.get_EquipmentConfig().GetEquipmentById(resourceId);

			if (equipmentConfig == null)
			{
				logger.error("calc EquipmentConfig_SellPrice failed equipmentConfig is null : equipResourceId={}", resourceId);
			}
			if (reward == null)
			{
				logger.error("calc EquipmentConfig_SellPrice failed SellGeneralRewards is null : equipResourceId={}", resourceId);
			}

			float basicPrice = reward.get_count();
			float breakthroughLevel = card.getBreakthoughtLevel();

			parser.SetVariable("BasicPrice", basicPrice);
			parser.SetVariable("BreakThrough_Level", breakthroughLevel);
		}

	}

}
