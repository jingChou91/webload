package com.kodgames.corgi.server.gameserver.avatar.data;

import java.util.List;

import ClientServerCommon.AvatarConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.common.Guid;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.server.gameserver.avatar.db.AvatarDB;
import com.kodgames.gamedata.player.PlayerNode;

public class AvatarMgr
{
	// 查角色
	public static Avatar getAvatar(Guid guid, PlayerNode playerNode)
	{
		return playerNode.getPlayerInfo().getAvatarData().getAvatar(guid);
	}

	// 添加avatar
	public static boolean addAvatar(PlayerNode playerNode, Avatar avatar)
	{
		AvatarData avatarData = playerNode.getPlayerInfo().getAvatarData();
		if (avatarData.addAvatar(avatar))
		{
			if (Card.isBasicCard(playerNode, avatar))
			{
				avatarData.addBasicCard(avatar.getResourceId());
				AvatarDB.addBasicAvatar(playerNode.getPlayerId(), avatar.getResourceId(), avatarData.getBasicCardCount(avatar.getResourceId()));
			}
			else
			{
				AvatarDB.addAvatar(playerNode.getPlayerId(), avatar);
			}
			return true;
		}
		return false;
	}

	// 删除avatar
	public static boolean removeAvatar(PlayerNode playerNode, Guid guid, ConfigDatabase cd)
	{
		Avatar avatar = AvatarMgr.getAvatar(guid, playerNode);
		if (null == avatar)
		{
			return false;
		}

		if (playerNode.getPlayerInfo().getAvatarData().removeAvatar(guid))
		{
			if (Card.isBasicCard(playerNode, avatar))
			{
				AvatarMgr.removeBasicAvatar(playerNode, avatar);
			}
			else
			{
				// 不通品质删除方式不通
				AvatarConfig.Avatar avatarCfg = cd.get_AvatarConfig().GetAvatarById(avatar.getResourceId());
				if (avatarCfg != null && (avatarCfg.get_qualityLevel() >= 4 || avatar.getLevel() > 1 || avatar.getBreakthoughtLevel() > 0))
				{
					AvatarDB.removeAvatar(playerNode.getPlayerId(), guid.toString(), false);
				}
				else
				{
					AvatarDB.removeAvatar(playerNode.getPlayerId(), guid.toString(), true);
				}
			}
			return true;
		}
		return false;
	}

	// 更新Avatar
	public static void updateAvatar(PlayerNode playerNode, Avatar avatar, boolean isBasicCardBefore)
	{
		if (isBasicCardBefore && avatar.isFromBasic())
		{
			AvatarMgr.removeBasicAvatar(playerNode, avatar);
			AvatarDB.addAvatar(playerNode.getPlayerId(), avatar);
		}
		else
		{
			AvatarDB.updateAvatar(playerNode.getPlayerId(), avatar);
		}

	}

	/*
	 * 从阵容中卸下一张卡牌后若该卡牌满足基础卡牌条件且以前是从basic表中读取的时， 将该卡牌数据从avatar表中移动到avatar_basic表中
	 */
	public static void moveAvatarToBasic(PlayerNode playerNode, Avatar avatar)
	{
		if (Card.isBasicCard(playerNode, avatar))
		{
			AvatarDB.removeAvatar(playerNode.getPlayerId(), avatar.getGuid().toString(), true);

			AvatarData avatarData = playerNode.getPlayerInfo().getAvatarData();
			avatarData.addBasicCard(avatar.getResourceId());
			AvatarDB.addBasicAvatar(playerNode.getPlayerId(), avatar.getResourceId(), avatarData.getBasicCardCount(avatar.getResourceId()));
		}

	}

	/*
	 * 删除一张基本卡牌
	 */
	private static void removeBasicAvatar(PlayerNode playerNode, Avatar avatar)
	{
		AvatarData avatarData = playerNode.getPlayerInfo().getAvatarData();
		int amount = avatarData.getBasicCardCount(avatar.getResourceId());
		if (amount > 0)
		{
			amount--;
			if (amount > 0)
			{
				avatarData.getBasicAvatarMap().put(avatar.getResourceId(), amount);
			}
			else
			{
				avatarData.getBasicAvatarMap().remove(avatar.getResourceId());
			}
			AvatarDB.removeBasicAvatar(playerNode.getPlayerId(), avatar.getResourceId(), amount);
		}
	}

	/*
	 * 取出CommonProtoAvatar
	 */
	public static CommonProtocols.Avatar getAvatar(List<CommonProtocols.Avatar> avatars, String guid)
	{
		for (CommonProtocols.Avatar avatarProto : avatars)
		{
			if (avatarProto.getGuid().equals(guid))
			{
				return avatarProto;
			}
		}
		return null;
	}
}
