package com.kodgames.corgi.server.gameserver.avatar.logic;

import java.util.ArrayList;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.AvatarConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_AvatarLevelUpReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_AvatarLevelUpRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.KodLogUtil;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.avatar.data.Avatar;
import com.kodgames.corgi.server.gameserver.avatar.data.AvatarMgr;
import com.kodgames.corgi.server.gameserver.avatar.data.Card;
import com.kodgames.gamedata.player.PlayerAttributeMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.genplayer.PowerMgr;

public class CG_AvatarLevelUpReqHandler extends MessageHandler
{

	private static Logger logger = LoggerFactory.getLogger(CG_AvatarLevelUpReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		CG_AvatarLevelUpReq request = (CG_AvatarLevelUpReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_AvatarLevelUpRes.Builder builder = GC_AvatarLevelUpRes.newBuilder();
		int result = ClientProtocols.E_GAME_AVATAR_LEVEL_UP_SUCCESS;
		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		Guid avatarGUID = Guid.genNewGuid(request.getAvatarGUID());
		boolean strengthenType = request.getLevelUpType();
		logger.info("recv CG_AvatarLevelUpReq, playerId = {}", playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_AVATAR_LEVEL_UP_FAILED_LOAD_PLAYER;
					break;
				}
				
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.AvatarLevelUp))
				{
					result = ClientProtocols.E_GAME_AVATAR_LEVEL_UP_FUNCTIONN_NOT_OPEN;
					break;
				}
				Avatar avatar = AvatarMgr.getAvatar(avatarGUID, playerNode);
				if (avatar == null)
				{
					result = ClientProtocols.E_GAME_AVATAR_LEVEL_UP_FAILED_LOAD_EQUIPMENT;
					break;
				}
				int oldLevel = avatar.getLevel();

				AvatarConfig.Avatar avatarConfig = cd.get_AvatarConfig().GetAvatarById(avatar.getResourceId());
				if (avatarConfig == null)
				{
					result = ClientProtocols.E_GAME_AVATAR_LEVEL_UP_FAILED_CONFIG_ERROR;
					break;
				}

				AvatarConfig.AvatarBreakthrough avatarBreakthrough =
					avatarConfig.GetAvatarBreakthrough(avatar.getBreakthoughtLevel());
				if (avatarBreakthrough == null)
				{
					result = ClientProtocols.E_GAME_AVATAR_LEVEL_UP_FAILED_CONFIG_ERROR;
					break;
				}

				int maxLevel = avatarBreakthrough.get_breakThrough().get_powerUpLevelLimit();
				float critFactor = avatarConfig.get_critFactor();
				// 判断角色等级是否符合
				if (avatar.getLevel() >= maxLevel)
				{
					result = ClientProtocols.E_GAME_AVATAR_LEVEL_UP_FAILED_IS_MAX_LEVEL;
					break;
				}
				
				boolean isBasicCardBefore = Card.isBasicCard(playerNode, avatar);

				// 升级一次
				if (strengthenType)
				{
					result =
						procLevelUp(playerNode,
							cd,
							maxLevel,
							critFactor,
							avatarConfig.get_qualityLevel(),
							crsForClient,
							avatar,
							true,
							builder);
				}
				else
				// 一键升级
				{
					// 如果玩家vip级别不够,那么不能一键强化
					int openVipLevel =
						cd.get_VipConfig()
							.GetVipLevelByOpenFunctionType(ClientServerCommon._OpenFunctionType.AvatarLevelUp);
					if (playerNode.getGamePlayer().getVipLevel() < openVipLevel)
					{
						result = ClientProtocols.E_GAME_AVATAR_LEVEL_UP_FAILED_VIPLEVEL_INVALID;
						break;
					}

					int beforeLevel = avatar.getLevel();
					boolean isFirstLevelUp = true;
					// 循环执行升级操作
					while (avatar.getLevel() < maxLevel)
					{
						result =
							procLevelUp(playerNode,
								cd,
								maxLevel,
								critFactor,
								avatarConfig.get_qualityLevel(),
								crsForClient,
								avatar,
								isFirstLevelUp,
								builder);

						if (beforeLevel == avatar.getLevel())
						{
							break;
						}
						isFirstLevelUp = false;
						beforeLevel = avatar.getLevel();
					}
				}

				// 更新数据库数据库
				if (result == ClientProtocols.E_GAME_AVATAR_LEVEL_UP_SUCCESS)
				{
					
					AvatarMgr.updateAvatar(playerNode, avatar, isBasicCardBefore);
				}

				// Log
				KodLogUtil.avatar_levelup(playerNode, avatar, cd, oldLevel);
				BPUtil.xkqh(playerNode, oldLevel, avatar.getResourceId(), avatar.getLevel(), oldLevel);

				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
				builder.setLevelAfter(avatar.getLevel());
				//战力
				float power = PowerMgr.calPower(playerNode, cd);
				PlayerAttributeMgr.setPlayerPower(playerNode, (int)power);
				
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setCallback(request.getCallback());
		builder.setResult(result);
		ServerDataGS.transmitter.sendToClient(sender, ClientProtocols.P_GAME_GC_AVATAR_LEVEL_UP_RES, builder.build());
		return HandlerAction.TERMINAL;
	}

	// 处理升级逻辑
	private int procLevelUp(PlayerNode playerNode, ConfigDatabase cd, int levelMax, float critFactor, int quality,
		CostAndRewardAndSync crsForClient, Avatar avatar, boolean isFirst, GC_AvatarLevelUpRes.Builder builder)
	{
		ClientServerCommon.QualityCost qualityCostCfg =
			cd.get_AvatarConfig().GetQualityCostByLevelAndQuality(avatar.getLevel(), quality);
		if (qualityCostCfg == null)
		{
			return ClientProtocols.E_GAME_AVATAR_LEVEL_UP_FAILED_CONFIG_ERROR;
		}

		ArrayList<Cost> costs = new ArrayList<>();
		for (int i = 0; i < qualityCostCfg.Get_costsCount(); i++)
		{
			costs.add(new Cost(qualityCostCfg.Get_costsByIndex(i).get_id(), qualityCostCfg.Get_costsByIndex(i).get_count()));
		}

		Cost notEnoughCost = new Cost();
		if (CostAndRewardManager.checkCosts(playerNode, costs, cd, KodLogEvent.AvatarLogic_AvatarLevelUp, notEnoughCost) == false)
		{
			if (isFirst)
			{
				crsForClient.setNotEnoughCost(notEnoughCost);
				return ClientProtocols.E_GAME_AVATAR_LEVEL_UP_FAILED_COST_NOT_ENOUGH;
			}
			else
			{
				return ClientProtocols.E_GAME_AVATAR_LEVEL_UP_SUCCESS;
			}
		}

		CostAndRewardAndSync temp = new CostAndRewardAndSync();
		CostAndRewardManager.consumeCosts(playerNode, costs, cd, KodLogEvent.AvatarLogic_AvatarLevelUp, 0, 0);
		temp.setCosts(costs);
		crsForClient.megerCostAndRewardAndSync(temp);

		// 暴级不能超过最高等级
		if ((new Random()).nextFloat() < critFactor && avatar.getLevel() < levelMax - 1)
		{
			builder.setCritCount(builder.getCritCount() + 1);
			avatar.setLevel(avatar.getLevel() + 2);
		}
		else
		{
			avatar.setLevel(avatar.getLevel() + 1);
		}
		
		return ClientProtocols.E_GAME_AVATAR_LEVEL_UP_SUCCESS;
	}
}