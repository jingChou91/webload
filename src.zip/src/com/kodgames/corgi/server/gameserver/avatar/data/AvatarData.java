package com.kodgames.corgi.server.gameserver.avatar.data;

import java.util.ArrayList;
import java.util.HashMap;

import com.kodgames.common.Guid;

public class AvatarData
{
	private ArrayList<Avatar> avatars = new ArrayList<>();
	private HashMap<Integer, Integer> basicAvatarMap = new HashMap<Integer, Integer>();

	public HashMap<Integer, Integer> getBasicAvatarMap()
	{
		return basicAvatarMap;
	}

	public void setBasicAvatarMap(HashMap<Integer, Integer> basicAvatarMap)
	{
		this.basicAvatarMap = basicAvatarMap;
	}

	public ArrayList<Avatar> getAvatars()
	{
		return avatars;
	}

	public void setAvatars(ArrayList<Avatar> avatars)
	{
		this.avatars = avatars;
	}

	// 查角色
	public Avatar getAvatar(Guid guid)
	{
		for (Avatar _avatar : avatars)
		{
			if (_avatar.getGuid().equals(guid))
			{
				return _avatar;
			}
		}
		return null;
	}

	// 加角色
	public boolean addAvatar(Avatar avatar)
	{
		if (getAvatar(avatar.getGuid()) == null)
		{
			return avatars.add(avatar);
		}

		return false;
	}

	// 删角色
	public boolean removeAvatar(Guid guid)
	{
		Avatar _avatar = getAvatar(guid);
		if (_avatar != null)
		{
			return avatars.remove(_avatar);
		}
		return false;
	}
	
	public void addBasicCard(int resourcdId)
	{
		int amount = 1;
		if (basicAvatarMap.containsKey(resourcdId))
		{
			amount = basicAvatarMap.get(resourcdId) + 1;
		}
		
		basicAvatarMap.put(resourcdId, amount);
	}

	public int getBasicCardCount(int resourceId)
	{
		if (basicAvatarMap.containsKey(resourceId))
		{
			return basicAvatarMap.get(resourceId);
		}
		
		return 0;
	}
}
