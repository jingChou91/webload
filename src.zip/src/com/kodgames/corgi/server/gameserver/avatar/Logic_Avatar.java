package com.kodgames.corgi.server.gameserver.avatar;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.avatar.logic.CG_AvatarBreakthoughReqHandler;
import com.kodgames.corgi.server.gameserver.avatar.logic.CG_AvatarLevelUpReqHandler;

public class Logic_Avatar 
{
	private CG_AvatarBreakthoughReqHandler cg_AvatarBreakthoughReqHandler = null;
	private CG_AvatarLevelUpReqHandler cg_AvatarLevelUpReqHandler = null;
	
	public void init() 
	{
		cg_AvatarBreakthoughReqHandler = new CG_AvatarBreakthoughReqHandler();
		cg_AvatarLevelUpReqHandler = new CG_AvatarLevelUpReqHandler();
	}

	public void registerProtoBufType(Controller controller) 
	{
        controller.registerMessageLite(ClientProtocols.P_GAME_CG_AVATAR_BREAKTHOUGHT_REQ, GameProtocolsForClient.CG_AvatarBreakthoughtReq.getDefaultInstance()); 
        controller.registerMessageLite(ClientProtocols.P_GAME_CG_AVATAR_LEVEL_UP_REQ, GameProtocolsForClient.CG_AvatarLevelUpReq.getDefaultInstance()); 
	}

	public void registerMessageHandler(Controller controller) 
	{
		controller.addHandler(ClientProtocols.P_GAME_CG_AVATAR_BREAKTHOUGHT_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_AvatarBreakthoughReqHandler ));
		controller.addHandler(ClientProtocols.P_GAME_CG_AVATAR_LEVEL_UP_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_AvatarLevelUpReqHandler ));
	}
}
