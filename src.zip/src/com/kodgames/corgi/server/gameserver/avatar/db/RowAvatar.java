package com.kodgames.corgi.server.gameserver.avatar.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.sql.rowset.CachedRowSet;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.common.Guid;
import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.common.TableSelect;
import com.kodgames.corgi.server.gameserver.avatar.data.Avatar;
import com.kodgames.corgi.server.gameserver.avatar.data.Card;
import com.kodgames.gamedata.dbcommon.DBEasy;
import com.kodgames.gamedata.player.PlayerNode;

public class RowAvatar
{

	// 插入
	public static boolean insertPrivateList(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, PlayerNode playerNode) throws SQLException
	{
		int playerId = playerNode.getPlayerId();
		String createTimeStr = ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(), System.currentTimeMillis(), ServerUtil.TimeWithoutMills);
		String sql = String.format("insert into " + TableSelect.get_avatar(playerId) + " (" + "player_id,guid,resource_id,level,experience,breakthought_level"
				+ ",status_did_delete,create_time)" + " VALUES (?,?,?,?,?,?,?,'%s')", createTimeStr);

		vps[queryIndex] = con.prepareStatement(sql);

		ArrayList<Avatar> avatars = playerNode.getPlayerInfo().getAvatarData().getAvatars();
		if (avatars != null)
		{
			for (Avatar avatar : avatars)
			{
				if (!Card.isBasicCard(playerNode, avatar))
				{
					Object[] objList = avatar.getObjectListForInsertRow(playerId, 0);
					boolean ret = DBEasy.doPrivateUpdate(vps[queryIndex], sql, objList);
					if (!ret)
					{
						return false;
					}
				}
			}
			return true;
		}
		return false;
	}

	public static boolean insertBasicPrivateList(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, PlayerNode playerNode) throws SQLException
	{
		String sql = String.format("insert into " + TableSelect.get_avatar_basic(playerNode.getPlayerId()) + "(player_id,resource_id,amount) values(?,?,?)");

		vps[queryIndex] = con.prepareStatement(sql);

		HashMap<Integer, Integer> basicAvatarMap = playerNode.getPlayerInfo().getAvatarData().getBasicAvatarMap();
		if (basicAvatarMap != null)
		{
			for (Entry<Integer, Integer> entry : basicAvatarMap.entrySet())
			{
				Object[] objList = new Object[] { playerNode.getPlayerId(), entry.getKey(), entry.getValue() };
				boolean ret = DBEasy.doPrivateUpdate(vps[queryIndex], sql, objList);
				if (!ret)
				{
					return false;
				}
			}
			return true;
		}
		return false;
	}

	// 查询
	public static void selectPrivate(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, PlayerNode playerNode, ConfigDatabase cd) throws SQLException
	{

		String sql = "select * from " + TableSelect.get_avatar(playerNode.getPlayerId()) + " where player_id=? AND status_did_delete=0";
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, new Object[] { playerNode.getPlayerId() });
		ArrayList<Avatar> avatars = new ArrayList<Avatar>();
		avatars.clear();

		if (vrs[queryIndex] != null)
		{
			CachedRowSet rs = vrs[queryIndex];
			while (rs.next())
			{
				Avatar avatar = new Avatar();

				// player_id
				avatar.setGuid(Guid.genNewGuid(rs.getString("guid")));
				avatar.setResourceId(rs.getInt("resource_id"));
				avatar.setLevel(rs.getInt("level"));
				avatar.setExperience(rs.getInt("experience"));
				avatar.setBreakthoughtLevel(rs.getInt("breakthought_level"));
				avatar.setFromBasic(false);;
				// 配置文件验证
				if (cd.get_AvatarConfig().GetAvatarById(avatar.getResourceId()) != null)
				{
					avatars.add(avatar);
				}
			}
		}
		playerNode.getPlayerInfo().getAvatarData().getAvatars().addAll(avatars);

	}

	public static void selectBasicPrivate(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, PlayerNode playerNode, ConfigDatabase cd)
			throws SQLException
	{

		String sql = "select * from " + TableSelect.get_avatar_basic(playerNode.getPlayerId()) + " where player_id=?";
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, new Object[] { playerNode.getPlayerId() });
		ArrayList<Avatar> avatars = new ArrayList<Avatar>();
		avatars.clear();
		HashMap<Integer, Integer> basicAvatarMap = new HashMap<Integer, Integer>();

		if (vrs[queryIndex] != null)
		{
			CachedRowSet rs = vrs[queryIndex];
			while (rs.next())
			{
				int resourceId = rs.getInt("resource_id");
				int amount = rs.getInt("amount");
				// 验证resourceId
				if (cd.get_AvatarConfig().GetAvatarById(resourceId) != null)
				{
					for (int i = 0; i < amount; i++)
					{
						Avatar avatar = Avatar.genNewAvatar(resourceId);
						avatar.setFromBasic(true);
						avatars.add(avatar);
					}
					basicAvatarMap.put(resourceId, amount);
				}

			}
		}
		playerNode.getPlayerInfo().getAvatarData().setBasicAvatarMap(basicAvatarMap);
		playerNode.getPlayerInfo().getAvatarData().getAvatars().addAll(avatars);
	}
}
