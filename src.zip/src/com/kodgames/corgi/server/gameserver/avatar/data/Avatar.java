package com.kodgames.corgi.server.gameserver.avatar.data;

import java.util.HashMap;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.AvatarConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.IMathParser;
import ClientServerCommon.MeridianConfig;

import com.kodgames.common.Guid;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.server.gameserver.diner.data.Diner;
import com.kodgames.corgi.server.gameserver.domineer.data.Domineer;
import com.kodgames.corgi.server.gameserver.meridian.data.Meridian;
import com.kodgames.gamedata.player.PlayerNode;


public class Avatar extends Card
{
	private static final Logger logger = LoggerFactory.getLogger(Avatar.class);

	@Override
	public Object[] getObjectListForInsertRow(int playerId, int status_did_delete)
	{
		return new Object[] { playerId, getGuid().toString(), getResourceId(), getLevel(), getExperience(), getBreakthoughtLevel(), status_did_delete };
	}

	@Override
	public Avatar copy(Card card)
	{
		setGuid(Guid.genNewGuid(card.getGuid().toString()));
		setResourceId(card.getResourceId());
		setLevel(card.getLevel());
		setExperience(card.getExperience());
		setBreakthoughtLevel(card.getBreakthoughtLevel());

		return this;
	}

	public static Avatar genNewAvatar(int recourceId)
	{
		Avatar avatar = new Avatar();
		avatar.setGuid(new Guid());
		avatar.setResourceId(recourceId);
		avatar.setLevel(1);
		avatar.setExperience(0);
		avatar.setBreakthoughtLevel(0);
		return avatar;
	}

	public CommonProtocols.Avatar toProtoBuffer(PlayerNode playerNode, ConfigDatabase cd)
	{
		CommonProtocols.Avatar.Builder avatarBuilder = CommonProtocols.Avatar.newBuilder();

		avatarBuilder.setGuid(getGuid().toString());
		avatarBuilder.setResourceId(getResourceId());
		CommonProtocols.LevelAttrib.Builder levelAttributeBuilder = CommonProtocols.LevelAttrib.newBuilder();
		levelAttributeBuilder.setLevel(getLevel());
		levelAttributeBuilder.setExperience(getExperience());
		avatarBuilder.setLevelAttrib(levelAttributeBuilder.build());
		avatarBuilder.setBreakthoughtLevel(getBreakthoughtLevel());

		Domineer domineer = playerNode.getPlayerInfo().getDomineerData().getDomineer(getGuid());
		if (domineer != null)
		{
			CommonProtocols.DomineerData.Builder builder = CommonProtocols.DomineerData.newBuilder();
			for (Integer domineerId : domineer.getDomineers())
			{
				CommonProtocols.Domineer.Builder domineerBuilder = CommonProtocols.Domineer.newBuilder();
				domineerBuilder.setDomineerId(domineerId);
				domineerBuilder.setLevel(domineer.getLevel());
				builder.addDomineers(domineerBuilder.build());
			}

			for (Integer domineerId : domineer.getUnsaveDomineer())
			{
				CommonProtocols.Domineer.Builder domineerBuilder = CommonProtocols.Domineer.newBuilder();
				domineerBuilder.setDomineerId(domineerId);
				AvatarConfig.Avatar avatarCfg = cd.get_AvatarConfig().GetAvatarById(getResourceId());
				if (avatarCfg != null)
				{
					int donmineerSkillLevel = domineer.getLevel() >= avatarCfg.get_qualityLevel() ? avatarCfg.get_qualityLevel() : (domineer.getLevel() + 1);
					domineerBuilder.setLevel(donmineerSkillLevel);
				}

				builder.addUnsaveDomineers(domineerBuilder.build());
			}

			avatarBuilder.setDomineerData(builder.build());
		}

		// 经脉
		HashMap<Integer, Meridian> meridanInfo = playerNode.getPlayerInfo().getMeridianData().getMeridianDatas().get(getGuid());
		if (meridanInfo != null)
		{
			for (Entry<Integer, Meridian> entry : meridanInfo.entrySet())
			{
				Meridian data = entry.getValue();
				avatarBuilder.addMeridianData(data.toProtoBuf());
			}
		}

		avatarBuilder.setIsAvatar(true);

		return avatarBuilder.build();
	}

	public Avatar fromProtoBuffer(CommonProtocols.Avatar proto)
	{
		setGuid(Guid.genNewGuid(proto.getGuid()));
		setResourceId(proto.getResourceId());
		setLevel(proto.getLevelAttrib().getLevel());
		setExperience(proto.getLevelAttrib().getExperience());
		setBreakthoughtLevel(proto.getBreakthoughtLevel());

		return this;
	}

	@Override
	public CommonProtocols.Avatar toProtoBuffer()
	{
		CommonProtocols.Avatar.Builder avatarBuilder = CommonProtocols.Avatar.newBuilder();

		avatarBuilder.setGuid(getGuid().toString());
		avatarBuilder.setResourceId(getResourceId());
		CommonProtocols.LevelAttrib.Builder levelAttributeBuilder = CommonProtocols.LevelAttrib.newBuilder();
		levelAttributeBuilder.setLevel(getLevel());
		levelAttributeBuilder.setExperience(getExperience());
		avatarBuilder.setLevelAttrib(levelAttributeBuilder.build());
		avatarBuilder.setBreakthoughtLevel(getBreakthoughtLevel());
		avatarBuilder.setIsAvatar(true);

		return avatarBuilder.build();
	}
	
	/**
	 * 生成带 肉攻辅 数据的Avatar
	 */
	public CommonProtocols.Avatar toProtoBuffer(int traitType, String name)
	{
		CommonProtocols.Avatar.Builder avatarBuilder = CommonProtocols.Avatar.newBuilder();

		avatarBuilder.setGuid(getGuid().toString());
		avatarBuilder.setResourceId(getResourceId());
		CommonProtocols.LevelAttrib.Builder levelAttributeBuilder = CommonProtocols.LevelAttrib.newBuilder();
		levelAttributeBuilder.setLevel(getLevel());
		levelAttributeBuilder.setExperience(getExperience());
		avatarBuilder.setLevelAttrib(levelAttributeBuilder.build());
		avatarBuilder.setBreakthoughtLevel(getBreakthoughtLevel());
		avatarBuilder.setIsAvatar(true);
		avatarBuilder.setTraitType(traitType);
		avatarBuilder.setName(name);

		return avatarBuilder.build();
	}

	public CommonProtocols.Avatar toProtoBuffer(ConfigDatabase cd, Diner diner)
	{
		CommonProtocols.Avatar.Builder avatarBuilder = CommonProtocols.Avatar.newBuilder();
		avatarBuilder.setGuid(diner.getAvatarGuid().toString());
		avatarBuilder.setIsAvatar(false);
		ClientServerCommon.DinerConfig.AvatarSlice avatarSlice = cd.get_DinerConfig().GetDinerById(diner.getDinerId()).get_AvatarSlice();
		avatarBuilder.setResourceId(avatarSlice.get_AvatarId());

		CommonProtocols.LevelAttrib.Builder levelAttributeBuilder = CommonProtocols.LevelAttrib.newBuilder();
		levelAttributeBuilder.setLevel(avatarSlice.get_AvatarLevel());
		// levelAttributeBuilder.setExperience(getExperience());
		avatarBuilder.setLevelAttrib(levelAttributeBuilder.build());
		avatarBuilder.setBreakthoughtLevel(avatarSlice.get_BreakThroughLevel());

		CommonProtocols.DomineerData.Builder domineerDatabuilder = CommonProtocols.DomineerData.newBuilder();
		for (int i = 0; i < avatarSlice.Get_DomineeringMapCount(); ++i)
		{
			ClientServerCommon.DinerConfig.ItemTuple itemTuple = avatarSlice.Get_DomineeringMapByIndex(i);
			CommonProtocols.Domineer.Builder domineerBuilder = CommonProtocols.Domineer.newBuilder();
			domineerBuilder.setDomineerId(itemTuple.get_Key());
			domineerBuilder.setLevel(itemTuple.get_Value());
			domineerDatabuilder.addDomineers(domineerBuilder.build());
		}
		avatarBuilder.setDomineerData(domineerDatabuilder.build());

		for (int i = 0; i < avatarSlice.Get_MeridiansMapCount(); ++i)
		{
			CommonProtocols.MeridianData.Builder meridianDataBuilder = CommonProtocols.MeridianData.newBuilder();
			ClientServerCommon.DinerConfig.ItemTuple itemTuple = avatarSlice.Get_MeridiansMapByIndex(i);
			meridianDataBuilder.setId(itemTuple.get_Key());

			MeridianConfig.Meridian meridianCfg = cd.get_MeridianConfig().GetMeridianById(itemTuple.get_Key());

			MeridianConfig.Buff buffCfg = cd.get_MeridianConfig().GetBuffById(itemTuple.get_Value());
			if (meridianCfg != null && buffCfg != null)
			{
				for (int j = 0; j < buffCfg.get_modifierSet().Get_modifiersCount(); j++)
				{
					ClientServerCommon.PropertyModifier modifierCfg = buffCfg.get_modifierSet().Get_modifiersByIndex(j);
					CommonProtocols.PropertyModifier.Builder modifierBuilder = CommonProtocols.PropertyModifier.newBuilder();

					modifierBuilder.setType(modifierCfg.get_type());
					modifierBuilder.setModifyType(modifierCfg.get_modifyType());
					modifierBuilder.setAttributeType(modifierCfg.get_attributeType());
					modifierBuilder.setAttributeValue(modifierCfg.get_attributeValue());
					meridianDataBuilder.addModifiers(modifierBuilder);
				}
			}
			avatarBuilder.addMeridianData(meridianDataBuilder.build());
		}
		return avatarBuilder.build();
	}

	@Override
	public void setupVariable(IMathParser parser, ConfigDatabase cd)
	{

	}
}
