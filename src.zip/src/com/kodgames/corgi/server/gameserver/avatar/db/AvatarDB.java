package com.kodgames.corgi.server.gameserver.avatar.db;

import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.common.TableSelect;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.avatar.data.Avatar;

public class AvatarDB
{
	// Avatar表的数据库异步操作
	// ：增删改-----------------------------------------------------------------------------------
	// 添加avatar
	public static void addAvatar(int playerId, Avatar avatar)
	{
		String createTimeStr = ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(), System.currentTimeMillis(), ServerUtil.TimeWithoutMills);

		String sql = String.format("insert into " + TableSelect.get_avatar(playerId) + " (player_id,guid,resource_id,level,experience,breakthought_level"
				+ ",status_did_delete,create_time)  VALUES ( %d,'%s',%d,%d,%d,%d,0,'%s')", playerId, avatar.getGuid(), avatar.getResourceId(), avatar.getLevel(),
				avatar.getExperience(), avatar.getBreakthoughtLevel(), createTimeStr);
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId, sql);
	}

	// 删除avatar (更新Avatar 标记：删除字段)
	public static void removeAvatar(int playerId, String avatarGuid, boolean realDel)
	{
		if (realDel)
		{
			String sql = String.format("delete from " + TableSelect.get_avatar(playerId) + "  where player_id=%d AND guid='%s'", playerId, avatarGuid);
			ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId, sql);
		}
		else
		{
			String sql = String.format("update " + TableSelect.get_avatar(playerId) + " set status_did_delete=1 where player_id=%d AND guid='%s'", playerId, avatarGuid);
			ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId, sql);
		}
	}

	// 更新Avatar
	public static void updateAvatar(int playerId, Avatar avatar)
	{
		String sql = String
				.format("update " + TableSelect.get_avatar(playerId) + " set resource_id=%d, level=%d, experience=%d, breakthought_level=%d" + " where player_id=%d AND guid='%s'",
						avatar.getResourceId(), avatar.getLevel(), avatar.getExperience(), avatar.getBreakthoughtLevel(), playerId, avatar.getGuid());
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId, sql);
	}

	// 添加basicAvatar
	public static void addBasicAvatar(int playerId, int resourceId, int amount)
	{
		if (amount > 0)
		{
			String sql = String.format("replace into " + TableSelect.get_avatar_basic(playerId) + " (player_id,resource_id,amount) VALUES(%d,%d,%d)", playerId, resourceId, amount);
			ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId, sql);
		}
	}

	// 删除更新BasicAvatar
	public static void removeBasicAvatar(int playerId, int resourceId, int amount)
	{
		if (amount > 0)
		{
			String sql = String.format("update " + TableSelect.get_avatar_basic(playerId) + " set amount=%d where player_id=%d and resource_id=%d", amount, playerId, resourceId);
			ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId, sql);
		}
		else
		{
			String sql = String.format("delete from " + TableSelect.get_avatar_basic(playerId) + " where player_id=%d and resource_id=%d", playerId, resourceId);
			ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId, sql);
		}
		
	}
}
