package com.kodgames.corgi.server.gameserver.beast.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;
import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.corgi.server.gameserver.beast.data.BeastData;
import com.kodgames.gamedata.dbcommon.DBEasy;
import com.kodgames.gamedata.player.PlayerNode;

public class RowBeastInfo
{
	private static final Logger logger = LoggerFactory.getLogger(RowBeastInfo.class);

	// 查询
	public static void selectPrivate(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs,
		PlayerNode playerNode)
		throws SQLException
	{
		String sql = "select * from beast_info where player_id=? limit 1";
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, new Object[] {playerNode.getPlayerId()});
		BeastData beastData = new BeastData();
		if (vrs[queryIndex] != null)
		{
			CachedRowSet rs = vrs[queryIndex];
			if (rs.next())
			{
				beastData.setShopLastRefreshTime(rs.getLong("shop_last_refresh_time"));
				byte[] beastInfo = rs.getBytes("beast_infos");
				if (beastInfo != null)
				{
					DBProtocolsForServer.BeastInfoDB.Builder builder = DBProtocolsForServer.BeastInfoDB.newBuilder();
					try
					{
						builder.mergeFrom(beastInfo);
					}
					catch (InvalidProtocolBufferException e1)
					{
						logger.error("playerId={} load BeastInfoDB failed.", playerNode.getPlayerId());
					}
					beastData.fromBeastInfoDBProtolBuf(builder.build());
				}

				byte[] exchangeInfo = rs.getBytes("beast_exchange_infos");
				if (exchangeInfo != null)
				{
					DBProtocolsForServer.BeastExchangeInfoDB.Builder builder =
						DBProtocolsForServer.BeastExchangeInfoDB.newBuilder();
					try
					{
						builder.mergeFrom(exchangeInfo);
					}
					catch (InvalidProtocolBufferException e1)
					{
						logger.error("playerId={} load BeastExchangeInfoDB failed.", playerNode.getPlayerId());
					}
					beastData.fromExchangeInfoDBProtolBuf(builder.build());
				}
			}
		}
		playerNode.getPlayerInfo().setBeastData(beastData);
	}
}
