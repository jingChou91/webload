package com.kodgames.corgi.server.gameserver.beast.logic;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.BeastConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_BeastBreakthoughtReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_BeastBreakthoughtRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.beast.data.Beast;
import com.kodgames.corgi.server.gameserver.beast.data.BeastMgr;
import com.kodgames.gamedata.player.PlayerAttributeMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.genplayer.PowerMgr;

public class CG_BeastBreakthoughtReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_BeastBreakthoughtReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_BeastBreakthoughtReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_BeastBreakthoughtReq request = (CG_BeastBreakthoughtReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_BeastBreakthoughtRes.Builder builder = GC_BeastBreakthoughtRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_BEAST_BREAKTHOUGHT_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_BEAST_BREAKTHOUGHT_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();

		Guid guid = Guid.genNewGuid(request.getGuid());
		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_BEAST_BREAKTHOUGHT_FAILED_LOAD_PLAYER;
					break;
				}

				BeastConfig beastCfg = cd.get_BeastConfig();
				if (beastCfg == null)
				{
					result = ClientProtocols.E_GAME_BEAST_BREAKTHOUGHT_FAILED_LOAD_CONFIG;
					break;
				}

				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Beast))
				{
					result = ClientProtocols.E_GAME_BEAST_FUNCTION_NOT_OPEN;
					break;
				}

				Beast beast = BeastMgr.getBeast(guid, playerNode);
				if (beast == null)
				{
					result = ClientProtocols.E_GAME_BEAST_BREAKTHOUGHT_FAILED_NOT_ACTIVED;
					break;
				}

				BeastConfig.BaseInfo baseInfoCfg = beastCfg.GetBaseInfoByBeastId(beast.getResourceId());
				if (baseInfoCfg == null)
				{
					result = ClientProtocols.E_GAME_BEAST_BREAKTHOUGHT_FAILED_LOAD_BASEINFO_CONFIG;
					break;
				}

				// npc专用
				if (!baseInfoCfg.get_IsShow())
				{
					result = ClientProtocols.E_GAME_ACTIVE_BEAST_FAILED_ONLY_FOR_NPC;
					break;
				}

				// 是否已达最高星级（突破）
				if (beast.getBreakthoughtLevel() >= beastCfg.get_MaxBreakthought())
				{
					result = ClientProtocols.E_GAME_BEAST_BREAKTHOUGHT_FAILED_ALREADY_MAX_BREAK;
					break;
				}

				BeastConfig.BeastBreakthought breakthoughtCfg =
					beastCfg.GetBeastBreakthoughtByBreakthoughtNow(beast.getBreakthoughtLevel());
				if (breakthoughtCfg == null)
				{
					result = ClientProtocols.E_GAME_BEAST_BREAKTHOUGHT_FAILED_LOAD_BREAKTHOUGHT_CONFIG;
					break;
				}

				ArrayList<Cost> costs = new ArrayList<Cost>();
				Cost costNotEnough = new Cost();
				CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
				// 强化货币消耗
				ClientServerCommon.Cost moneyCost = breakthoughtCfg.get_UpItemCost();
				if (moneyCost == null)
				{
					result = ClientProtocols.E_GAME_BEAST_BREAKTHOUGHT_FAILED_LOAD_MONEY_CONFIG;
					break;
				}
				costs.add(new Cost(moneyCost.get_id(), moneyCost.get_count()));
				// 货币是否足够
				if (!CostAndRewardManager.checkCosts(playerNode,
					costs,
					cd,
					KodLogEvent.Beast_Breakthought,
					costNotEnough))
				{
					crsForClient.setNotEnoughCost(costNotEnough);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_BEAST_BREAKTHOUGHT_FAILED_MONEY_NOT_ENOUGH;
					break;
				}

				// 升阶魂魄消耗
				costs.add(new Cost(baseInfoCfg.get_FragmentId(), breakthoughtCfg.get_UpCostFragmentCount()));
				// 魂魄是否足够
				if (!CostAndRewardManager.checkCosts(playerNode,
					costs,
					cd,
					KodLogEvent.Beast_Breakthought,
					costNotEnough))
				{
					crsForClient.setNotEnoughCost(costNotEnough);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_BEAST_BREAKTHOUGHT_FAILED_COSTS_NOT_ENOUGH;
					break;
				}

				// 修改内存
				crsForCost.setCosts(costs);
				CostAndRewardManager.consumeCosts(playerNode, costs, cd, KodLogEvent.Beast_Breakthought, 0, 0);
				crsForClient.megerCostAndRewardAndSync(crsForCost);
				// 升星（强化）
				BeastMgr.beastBreakthought(playerNode, beast, breakthoughtCfg);
				builder.setBeast(beast.toProtoBuffer());
				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());

				// 小助手
				playerNode.getPlayerInfo().getAssisantData().getBeast().notifyObservers();
				//战力
				float power = PowerMgr.calPower(playerNode, cd);
				PlayerAttributeMgr.setPlayerPower(playerNode, (int)power);
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
