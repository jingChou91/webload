package com.kodgames.corgi.server.gameserver.beast.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.BeastConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_BeastLevelUpReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_BeastLevelUpRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.beast.data.Beast;
import com.kodgames.corgi.server.gameserver.beast.data.BeastMgr;
import com.kodgames.corgi.server.gameserver.beast.util.BeastUtil;
import com.kodgames.gamedata.player.PlayerAttributeMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.genplayer.PowerMgr;

public class CG_BeastLevelUpReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_BeastLevelUpReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_BeastLevelUpReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_BeastLevelUpReq request = (CG_BeastLevelUpReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_BeastLevelUpRes.Builder builder = GC_BeastLevelUpRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_BEAST_LEVEL_UP_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_BEAST_LEVEL_UP_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		Guid guid = Guid.genNewGuid(request.getGuid());
		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_BEAST_LEVEL_UP_FAILED_LOAD_PLAYER;
					break;
				}

				BeastConfig beastCfg = cd.get_BeastConfig();
				if (beastCfg == null)
				{
					result = ClientProtocols.E_GAME_BEAST_LEVEL_UP_FAILED_LOAD_CONFIG;
					break;
				}

				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Beast))
				{
					result = ClientProtocols.E_GAME_BEAST_FUNCTION_NOT_OPEN;
					break;
				}

				Beast beast = BeastMgr.getBeast(guid, playerNode);
				if (beast == null)
				{
					result = ClientProtocols.E_GAME_BEAST_LEVEL_UP_FAILED_NOT_ACTIVED;
					break;
				}

				BeastConfig.BaseInfo baseInfoCfg = beastCfg.GetBaseInfoByBeastId(beast.getResourceId());
				if (baseInfoCfg == null)
				{
					result = ClientProtocols.E_GAME_ACTIVE_BEAST_FAILED_LOAD_BASEINFO_CONFIG;
					break;
				}

				// npc专用
				if (!baseInfoCfg.get_IsShow())
				{
					result = ClientProtocols.E_GAME_ACTIVE_BEAST_FAILED_ONLY_FOR_NPC;
					break;
				}

				// 是否已达最高品阶（改造）
				if (beast.getLevel() >= beastCfg.get_MaxLevel())
				{
					result = ClientProtocols.E_GAME_BEAST_LEVEL_UP_FAILED_ALREADY_MAX_LEVEL;
					break;
				}

				BeastConfig.BreakthoughtAndLevel breakAndLevelCfg =
					BeastUtil.getBreakthoughtAndLevelByIdAndBreakAndLevel(beastCfg,
						beast.getResourceId(),
						beast.getBreakthoughtLevel(),
						beast.getLevel());
				if (breakAndLevelCfg == null)
				{
					result = ClientProtocols.E_GAME_BEAST_LEVEL_UP_FAILED_LOAD_BREAKANDLEVEL_CONFIG;
					break;
				}
				
				// 是否可以提升品阶（零件位置是否已经全部装备）
				if (!BeastUtil.canLevelUp(beast, breakAndLevelCfg))
				{
					result = ClientProtocols.E_GAME_BEAST_LEVEL_UP_FAILED_PART_NOT_ALL_EQUIPED;
					break;
				}

				BeastConfig.BeastLevelUp levelUpCfg = beastCfg.GetBeastLevelUpByLevelNow(beast.getLevel());
				if (levelUpCfg == null)
				{
					result = ClientProtocols.E_GAME_BEAST_LEVEL_UP_FAILED_LOAD_BEASTLEVELUP_CONFIG;
					break;
				}

				// 升阶（改造）
				BeastMgr.beastLevelUp(playerNode, beast, levelUpCfg);
				builder.setBeast(beast.toProtoBuffer());

				// 小助手
				playerNode.getPlayerInfo().getAssisantData().getBeast().notifyObservers();
				//战力
				float power = PowerMgr.calPower(playerNode, cd);
				PlayerAttributeMgr.setPlayerPower(playerNode, (int)power);
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
