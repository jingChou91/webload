package com.kodgames.corgi.server.gameserver.beast;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.beast.logic.CG_ActiveBeastReqHandler;
import com.kodgames.corgi.server.gameserver.beast.logic.CG_BeastBreakthoughtReqHandler;
import com.kodgames.corgi.server.gameserver.beast.logic.CG_BeastExchangeShopReqHandler;
import com.kodgames.corgi.server.gameserver.beast.logic.CG_BeastLevelUpReqHandler;
import com.kodgames.corgi.server.gameserver.beast.logic.CG_EquipBeastPartReqHandler;
import com.kodgames.corgi.server.gameserver.beast.logic.CG_QueryBeastExchangeShopReqHandler;
import com.kodgames.corgi.server.gameserver.beast.logic.CG_RefreshBeastExchangeShopReqHandler;

public class Logic_Beast
{
//	private static final Logger logger = LoggerFactory.getLogger(Logic_Beast.class);
	
	public Logic_Beast()
	{
	}

	public void init(Controller controller)
	{
		CG_ActiveBeastReqHandler cg_ActiveBeastReqHandler = new CG_ActiveBeastReqHandler();
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_ACTIVE_BEAST_REQ, GameProtocolsForClient.CG_ActiveBeastReq.getDefaultInstance());
		controller.addHandler(ClientProtocols.P_GAME_CG_ACTIVE_BEAST_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_ActiveBeastReqHandler));
		
		CG_EquipBeastPartReqHandler cg_EquipBeastPartReqHandler = new CG_EquipBeastPartReqHandler();
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_EQUIP_BEAST_PART_REQ, GameProtocolsForClient.CG_EquipBeastPartReq.getDefaultInstance());
		controller.addHandler(ClientProtocols.P_GAME_CG_EQUIP_BEAST_PART_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_EquipBeastPartReqHandler));
		
		CG_BeastLevelUpReqHandler cg_BeastLevelUpReqHandler = new CG_BeastLevelUpReqHandler();
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_BEAST_LEVEL_UP_REQ, GameProtocolsForClient.CG_BeastLevelUpReq.getDefaultInstance());
		controller.addHandler(ClientProtocols.P_GAME_CG_BEAST_LEVEL_UP_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_BeastLevelUpReqHandler));
		
		CG_BeastBreakthoughtReqHandler cg_BeastBreakthoughtReqHandler = new CG_BeastBreakthoughtReqHandler();
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_BEAST_BREAKTHOUGHT_REQ, GameProtocolsForClient.CG_BeastBreakthoughtReq.getDefaultInstance());
		controller.addHandler(ClientProtocols.P_GAME_CG_BEAST_BREAKTHOUGHT_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_BeastBreakthoughtReqHandler));
		
		CG_QueryBeastExchangeShopReqHandler cg_QueryBeastExchangeShopReqHandler = new CG_QueryBeastExchangeShopReqHandler();
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_BEAST_EXCHANGE_SHOP_REQ, GameProtocolsForClient.CG_QueryBeastExchangeShopReq.getDefaultInstance());
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_BEAST_EXCHANGE_SHOP_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryBeastExchangeShopReqHandler));
		
		CG_BeastExchangeShopReqHandler cg_BeastExchangeShopReqHandler = new CG_BeastExchangeShopReqHandler();
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_BEAST_EXCHANGE_SHOP_REQ, GameProtocolsForClient.CG_BeastExchangeShopReq.getDefaultInstance());
		controller.addHandler(ClientProtocols.P_GAME_CG_BEAST_EXCHANGE_SHOP_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_BeastExchangeShopReqHandler));
		
		CG_RefreshBeastExchangeShopReqHandler cg_RefreshBeastExchangeShopReqHandler = new CG_RefreshBeastExchangeShopReqHandler();
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_REFRESH_BEAST_EXCHANGE_SHOP_REQ, GameProtocolsForClient.CG_RefreshBeastExchangeShopReq.getDefaultInstance());
		controller.addHandler(ClientProtocols.P_GAME_CG_REFRESH_BEAST_EXCHANGE_SHOP_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_RefreshBeastExchangeShopReqHandler));
		
	}
}