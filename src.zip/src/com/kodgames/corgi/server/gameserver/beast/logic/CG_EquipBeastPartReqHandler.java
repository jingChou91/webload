package com.kodgames.corgi.server.gameserver.beast.logic;

import java.util.ArrayList;
import java.util.HashSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.BeastConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_EquipBeastPartReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_EquipBeastPartRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.beast.data.Beast;
import com.kodgames.corgi.server.gameserver.beast.data.BeastMgr;
import com.kodgames.corgi.server.gameserver.beast.db.BeastInfoDB;
import com.kodgames.corgi.server.gameserver.beast.util.BeastUtil;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;

public class CG_EquipBeastPartReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_EquipBeastPartReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_EquipBeastPartReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_EquipBeastPartReq request = (CG_EquipBeastPartReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_EquipBeastPartRes.Builder builder = GC_EquipBeastPartRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_EQUIP_BEAST_PART_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_EQUIP_BEAST_PART_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();

		Guid guid = Guid.genNewGuid(request.getGuid());
		int index = request.getIndex();
		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_EQUIP_BEAST_PART_FAILED_LOAD_PLAYER;
					break;
				}

				BeastConfig beastCfg = cd.get_BeastConfig();
				if (beastCfg == null)
				{
					result = ClientProtocols.E_GAME_EQUIP_BEAST_PART_FAILED_LOAD_CONFIG;
					break;
				}

				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Beast))
				{
					result = ClientProtocols.E_GAME_BEAST_FUNCTION_NOT_OPEN;
					break;
				}

				Beast beast = BeastMgr.getBeast(guid, playerNode);
				if (beast == null)
				{
					result = ClientProtocols.E_GAME_EQUIP_BEAST_PART_FAILED_NOT_ACTIVED;
					break;
				}

				BeastConfig.BaseInfo baseInfoCfg = beastCfg.GetBaseInfoByBeastId(beast.getResourceId());
				if (baseInfoCfg == null)
				{
					result = ClientProtocols.E_GAME_ACTIVE_BEAST_FAILED_LOAD_BASEINFO_CONFIG;
					break;
				}

				// npc专用
				if (!baseInfoCfg.get_IsShow())
				{
					result = ClientProtocols.E_GAME_ACTIVE_BEAST_FAILED_ONLY_FOR_NPC;
					break;
				}

				// 检查零件位置是否合法
				if (!BeastUtil.checkPartIndex(index))
				{
					result = ClientProtocols.E_GAME_EQUIP_BEAST_PART_FAILED_PARTINDEX_ERROR;
					break;
				}

				BeastConfig.BreakthoughtAndLevel breakAndLevelCfg =
					BeastUtil.getBreakthoughtAndLevelByIdAndBreakAndLevel(beastCfg,
						beast.getResourceId(),
						beast.getBreakthoughtLevel(),
						beast.getLevel());
				if (breakAndLevelCfg == null)
				{
					result = ClientProtocols.E_GAME_EQUIP_BEAST_PART_FAILED_LOAD_BREAKANDLEVEL_CONFIG;
					break;
				}

				// 不是一键穿装
				if (index != BeastConfig._PartIndex.AllPut)
				{
					if (beast.getPartIndexs().contains(index))
					{
						result = ClientProtocols.E_GAME_EQUIP_BEAST_PART_FAILED_ALREADY_EQUIPED;
						break;
					}

					BeastConfig.BeastPartActive partActiveCfg = breakAndLevelCfg.GetBeastPartActiveByIndex(index);
					if (partActiveCfg == null)
					{
						result = ClientProtocols.E_GAME_EQUIP_BEAST_PART_FAILED_LOAD_BEASTPARTACTIVE_CONFIG;
						break;
					}

					// 装备零件的消耗
					ArrayList<Cost> costs = new ArrayList<Cost>();
					Cost costNotEnough = new Cost();
					CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
					costs.add(new Cost(partActiveCfg.get_PartCost().get_id(), partActiveCfg.get_PartCost().get_count()));
					// 是否足够激活
					if (!CostAndRewardManager.checkCosts(playerNode,
						costs,
						cd,
						KodLogEvent.Beast_EquipPart,
						costNotEnough))
					{
						crsForClient.setNotEnoughCost(costNotEnough);
						builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
						result = ClientProtocols.E_GAME_EQUIP_BEAST_PART_FAILED_COSTS_NOT_ENOUGH;
						break;
					}
					crsForCost.setCosts(costs);
					CostAndRewardManager.consumeCosts(playerNode, costs, cd, KodLogEvent.Beast_EquipPart, 0, 0);
					crsForClient.megerCostAndRewardAndSync(crsForCost);

					// 装备零件
					beast.equipPart(index);
				}
				// 一键穿装
				else
				{
					// 所有未装备零件的零件位置
					HashSet<Integer> unequipPartIndexs = BeastUtil.getUnequipPartIndexs(beast);
					if (unequipPartIndexs.isEmpty())
					{
						result = ClientProtocols.E_GAME_EQUIP_BEAST_PART_FAILED_ALREADY_ALL_EQUIPED;
						break;
					}

					// 本次一键穿装穿上的零件位置
					HashSet<Integer> thisEquipIndexs = new HashSet<Integer>();
					CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();

					// 装备零件的实际消耗
					ArrayList<Cost> realCosts = new ArrayList<Cost>();
					for (int tmpIndex : unequipPartIndexs)
					{
						BeastConfig.BeastPartActive partActiveCfg =
							breakAndLevelCfg.GetBeastPartActiveByIndex(tmpIndex);
						if (partActiveCfg == null)
						{
							logger.error("___get BeastConfig.BeastPartActive failed, beastId={}, breakthought={}, level={}, partIndex={}",
								beast.getResourceId(),
								beast.getBreakthoughtLevel(),
								beast.getLevel(),
								tmpIndex);
							result = ClientProtocols.E_GAME_EQUIP_BEAST_PART_FAILED_LOAD_BEASTPARTACTIVE_CONFIG;
							break;
						}

						Cost costNotEnough = new Cost();
						// 用于验证消耗是否足够
						ArrayList<Cost> tmpCosts = new ArrayList<Cost>();
						Cost tmpCost = new Cost(partActiveCfg.get_PartCost().get_id(), partActiveCfg.get_PartCost().get_count());
						tmpCosts.add(tmpCost);
						// 是否足够激活
						if (!CostAndRewardManager.checkCosts(playerNode,
							tmpCosts,
							cd,
							KodLogEvent.Beast_EquipPart,
							costNotEnough))
						{
							// 不够时跳过本位置的零件，继续激活别的
							continue;
						}

						// 将消耗加入到实际消耗中
						realCosts.add(tmpCost);
						// 装备零件
						thisEquipIndexs.add(tmpIndex);
					}

					if (result != ClientProtocols.E_GAME_EQUIP_BEAST_PART_SUCCESS)
					{
						break;
					}
					
					// 一个也没穿上，说明消耗不足不够
					if (thisEquipIndexs.isEmpty())
					{
						result = ClientProtocols.E_GAME_EQUIP_BEAST_PART_FAILED_COSTS_NOT_ENOUGH;
						break;
					}
					// 扣除消耗
					crsForCost.setCosts(realCosts);
					CostAndRewardManager.consumeCosts(playerNode, realCosts, cd, KodLogEvent.Beast_EquipPart, 0, 0);
					crsForClient.megerCostAndRewardAndSync(crsForCost);
					// 穿零件
					for (int partIndex : thisEquipIndexs)
					{
						beast.equipPart(partIndex);
					}
				}

				// 修改数据库
				BeastInfoDB.updateBeastInfo(playerNode);
				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
				builder.setBeast(beast.toProtoBuffer());
				// 小助手
				playerNode.getPlayerInfo().getAssisantData().getBeast().notifyObservers();
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
