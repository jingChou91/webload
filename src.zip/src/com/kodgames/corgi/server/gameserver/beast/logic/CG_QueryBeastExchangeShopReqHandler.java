package com.kodgames.corgi.server.gameserver.beast.logic;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.BeastConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryBeastExchangeShopReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryBeastExchangeShopRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.beast.data.BeastData;
import com.kodgames.corgi.server.gameserver.beast.data.BeastExchange;
import com.kodgames.corgi.server.gameserver.beast.util.BeastUtil;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;

public class CG_QueryBeastExchangeShopReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_QueryBeastExchangeShopReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_QueryBeastExchangeShopReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_QueryBeastExchangeShopReq request = (CG_QueryBeastExchangeShopReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryBeastExchangeShopRes.Builder builder = GC_QueryBeastExchangeShopRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_BEAST_EXCHANGE_SHOP_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_QUERY_BEAST_EXCHANGE_SHOP_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_BEAST_EXCHANGE_SHOP_FAILED_LOAD_PLAYER;
					break;
				}

				BeastConfig beastCfg = cd.get_BeastConfig();
				if (beastCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_BEAST_EXCHANGE_SHOP_FAILED_LOAD_CONFIG;
					break;
				}

				BeastConfig.BeastPartShop partShopCfg = beastCfg.get_BeastPartShops();
				if (partShopCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_BEAST_EXCHANGE_SHOP_FAILED_LOAD_BEASTPARTSHOP_CONFIG;
					break;
				}

				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Beast))
				{
					result = ClientProtocols.E_GAME_BEAST_FUNCTION_NOT_OPEN;
					break;
				}

				BeastData beastData = playerNode.getPlayerInfo().getBeastData();
				// 当前时间
				long now = System.currentTimeMillis();
				// 系统刷新
				BeastUtil.systemRefresh(playerNode, now, beastCfg, partShopCfg);

				// 返回客户端兑换条目信息
				List<CommonProtocols.ZentiaExchange> beastExchanges = new ArrayList<CommonProtocols.ZentiaExchange>();
				for (BeastExchange beastExchange : beastData.getBeastExchanges())
				{
					beastExchanges.add(beastExchange.toProtoBuf(beastCfg));
				}
				builder.addAllBeastExchanges(beastExchanges);
				// 返回客户端刷新消耗
				builder.setRefreshCost(new Cost(partShopCfg.get_HandRefreshCost().get_id(),
					partShopCfg.get_HandRefreshCost().get_count()).toProtobuf());
				// 系统下次刷新时间
				builder.setNextSystemRefreshTime(BeastUtil.getNextSystemRefreshTime(now, beastCfg, partShopCfg));
				
				// 小助手
				playerNode.getPlayerInfo().getAssisantData().getBeast().notifyObservers();
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
