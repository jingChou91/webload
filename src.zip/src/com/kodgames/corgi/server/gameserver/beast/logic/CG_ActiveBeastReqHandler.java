package com.kodgames.corgi.server.gameserver.beast.logic;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.BeastConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_ActiveBeastReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_ActiveBeastRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.beast.data.Beast;
import com.kodgames.corgi.server.gameserver.beast.data.BeastData;
import com.kodgames.corgi.server.gameserver.beast.db.BeastInfoDB;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class CG_ActiveBeastReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_ActiveBeastReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_ActiveBeastReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_ActiveBeastReq request = (CG_ActiveBeastReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_ActiveBeastRes.Builder builder = GC_ActiveBeastRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_ACTIVE_BEAST_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_ACTIVE_BEAST_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		
		int resourceId = request.getId();
		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_ACTIVE_BEAST_FAILED_LOAD_PLAYER;
					break;
				}
				
				BeastConfig beastCfg = cd.get_BeastConfig();
				if (beastCfg == null)
				{
					result = ClientProtocols.E_GAME_ACTIVE_BEAST_FAILED_LOAD_CONFIG;
					break;
				}
				
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Beast))
				{
					result = ClientProtocols.E_GAME_BEAST_FUNCTION_NOT_OPEN;
					break;
				}
				
				BeastData beastData = playerNode.getPlayerInfo().getBeastData();
				// 已激活
				if (beastData.getBeasts().containsKey(resourceId))
				{
					result = ClientProtocols.E_GAME_ACTIVE_BEAST_FAILED_ALREADY_ACTIVED;
					break;
				}
				
				BeastConfig.BaseInfo baseInfoCfg = beastCfg.GetBaseInfoByBeastId(resourceId);
				if (baseInfoCfg == null)
				{
					result = ClientProtocols.E_GAME_ACTIVE_BEAST_FAILED_LOAD_BASEINFO_CONFIG;
					break;
				}
				
				// npc专用
				if (!baseInfoCfg.get_IsShow())
				{
					result = ClientProtocols.E_GAME_ACTIVE_BEAST_FAILED_ONLY_FOR_NPC;
					break;
				}
				
				BeastConfig.BeastBreakthought breakthoughtCfg = beastCfg.GetBeastBreakthoughtByBreakthoughtNow(baseInfoCfg.get_MinActiveBreakthought());
				if (breakthoughtCfg == null)
				{
					result = ClientProtocols.E_GAME_ACTIVE_BEAST_FAILED_LOAD_BREAKTHOUGHT_CONFIG;
					break;
				}
				
				// 激活的消耗
				ArrayList<Cost> costs = new ArrayList<Cost>();
				Cost costNotEnough = new Cost();
				CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
				costs.add(new Cost(baseInfoCfg.get_FragmentId(), breakthoughtCfg.get_ActiveCostFragmentCount()));
				// 是否足够激活
				if (!CostAndRewardManager.checkCosts(playerNode,
					costs,
					cd,
					KodLogEvent.Beast_Active,
					costNotEnough))
				{
					crsForClient.setNotEnoughCost(costNotEnough);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_ACTIVE_BEAST_FAILED_COSTS_NOT_ENOUGH;
					break;
				}
				crsForCost.setCosts(costs);
				CostAndRewardManager.consumeCosts(playerNode, costs, cd, KodLogEvent.Beast_Active, 0, 0);
				crsForClient.megerCostAndRewardAndSync(crsForCost);
				
				// 激活
				Beast beast = Beast.genNewBeast(resourceId);
				
				Reward reward = new Reward();
				reward.getBeasts().add(beast);
				CostAndRewardAndSync crsForReq = new CostAndRewardAndSync();
				CostAndRewardManager.addReward(playerNode, reward, cd, KodLogEvent.Beast_Active);
				crsForReq.mergeReward(reward);
				crsForClient.megerCostAndRewardAndSync(crsForReq);
				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
				
				// 数据库
				BeastInfoDB.updateBeastInfo(playerNode);
				// 小助手
				playerNode.getPlayerInfo().getAssisantData().getBeast().notifyObservers();
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
