package com.kodgames.corgi.server.gameserver.beast.db;

import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.dbclient.TableChangeEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.beast.data.BeastData;
import com.kodgames.gamedata.player.PlayerNode;

public class BeastInfoDB
{
	public static void updateBeastInfo(PlayerNode playerNode)
	{
		BeastData beastData = playerNode.getPlayerInfo().getBeastData();
		String sql =
			String.format("replace into beast_info (player_id,beast_infos,shop_last_refresh_time,beast_exchange_infos) values (%d,%s,%d,%s)",
				playerNode.getPlayerId(),
				ServerUtil.toHexString(beastData.toBeastInfoDBProtolBuf().toByteArray()),
				beastData.getShopLastRefreshTime(),
				ServerUtil.toHexString(beastData.toExchangeInfoDBProtolBuf().toByteArray()));
		ServerDataGS.dbCluster.getGameDBClient()
			.executeAsynchronousUpdate(TableChangeEvent.getKey(playerNode.getPlayerId(), TableChangeEvent.BEAST),
				playerNode.getPlayerId(), sql);
	}
}
