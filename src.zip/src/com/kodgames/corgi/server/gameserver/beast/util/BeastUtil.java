package com.kodgames.corgi.server.gameserver.beast.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.BeastConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.common.ValueRandomer;
import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.beast.data.Beast;
import com.kodgames.corgi.server.gameserver.beast.data.BeastData;
import com.kodgames.corgi.server.gameserver.beast.data.BeastExchange;
import com.kodgames.corgi.server.gameserver.beast.db.BeastInfoDB;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.consume.ConsumableData;
import com.kodgames.gamedata.player.costandreward.Consume;

public class BeastUtil
{
	private static final Logger logger = LoggerFactory.getLogger(BeastUtil.class);

	/**
	 * 小助手用，是否有机关兽可以激活
	 */
	public static boolean hasBeastCanActive(PlayerNode playerNode, ConfigDatabase cd)
	{
		ConsumableData consumableData = playerNode.getPlayerInfo().getConsumableData();
		BeastConfig beastConfig = cd.get_BeastConfig();
		for (int i = 0; i < beastConfig.Get_BaseInfosCount(); i++)
		{
			BeastConfig.BaseInfo baseInfoCfg = beastConfig.Get_BaseInfosByIndex(i);
			// 机关兽为不显示||该机关兽已激活
			if (!baseInfoCfg.get_IsShow() || isBeastHasActived(playerNode, baseInfoCfg.get_Id()))
			{
				continue;
			}
			BeastConfig.BeastBreakthought breakthoughtCfg =
				beastConfig.GetBeastBreakthoughtByBreakthoughtNow(baseInfoCfg.get_MinActiveBreakthought());
			if (breakthoughtCfg == null)
			{
				logger.error("_____beast active assisstant get breakthoughtCfg failed, breakthoughtlevel={}",
					baseInfoCfg.get_MinActiveBreakthought());
				continue;
			}
			if (consumableData.getConsumableAmount(baseInfoCfg.get_FragmentId()) >= breakthoughtCfg.get_ActiveCostFragmentCount())
			{
				return true;
			}
		}

		return false;
	}

	/**
	 * 小助手用，是否有机关兽可以突破（强化）
	 */
	public static boolean hasBeastCanBreakthought(PlayerNode playerNode, ConfigDatabase cd)
	{
		BeastData beastData = playerNode.getPlayerInfo().getBeastData();
		ConsumableData consumableData = playerNode.getPlayerInfo().getConsumableData();
		BeastConfig beastConfig = cd.get_BeastConfig();
		Beast beast = null;
		for (int i = 0; i < beastConfig.Get_BaseInfosCount(); i++)
		{
			BeastConfig.BaseInfo baseInfoCfg = beastConfig.Get_BaseInfosByIndex(i);
			beast = beastData.getBeasts().get(baseInfoCfg.get_Id());
			// 机关兽为不显示||该机关兽未激活||机关兽已达最高突破
			if (!baseInfoCfg.get_IsShow() || beast == null
				|| beast.getBreakthoughtLevel() >= beastConfig.get_MaxBreakthought())
			{
				continue;
			}

			BeastConfig.BeastBreakthought breakthoughtCfg =
				beastConfig.GetBeastBreakthoughtByBreakthoughtNow(beast.getBreakthoughtLevel());
			if (breakthoughtCfg == null)
			{
				logger.error("_____beast breakthought assisstant get breakthoughtCfg failed, breakthoughtlevel={}",
					beast.getBreakthoughtLevel());
				continue;
			}
			if (consumableData.getConsumableAmount(baseInfoCfg.get_FragmentId()) >= breakthoughtCfg.get_UpCostFragmentCount())
			{
				return true;
			}
		}

		return false;
	}

	/**
	 * 验证玩家是否已激活某一机关兽
	 * 
	 * @param playerNode
	 * @param resourceId 机关兽resourceId
	 * @return
	 */
	public static boolean isBeastHasActived(PlayerNode playerNode, int resourceId)
	{
		HashMap<Integer, Beast> beasts = playerNode.getPlayerInfo().getBeastData().getBeasts();
		if (beasts.containsKey(resourceId))
		{
			return true;
		}
		return false;
	}

	/**
	 * 获取机关兽分解后对应的consume
	 */
	public static Consume getBeastDecomposeConsume(Beast beast, ConfigDatabase cd)
	{
		BeastConfig beastConfig = cd.get_BeastConfig();
		BeastConfig.BaseInfo baseInfoCfg = beastConfig.GetBaseInfoByBeastId(beast.getResourceId());
		if (baseInfoCfg == null)
		{
			logger.error("_____getBeastDecomposeConsume error! can't get BeastConfig.BaseInfo by resourceid={}",
				beast.getResourceId());
			return null;
		}

		BeastConfig.BeastBreakthought breakthoughtCfg =
			beastConfig.GetBeastBreakthoughtByBreakthoughtNow(beast.getBreakthoughtLevel());
		if (breakthoughtCfg == null)
		{
			logger.error("_____getBeastDecomposeConsume error! can't get BeastConfig.BeastBreakthought by breakthoughtNow={}",
				beast.getBreakthoughtLevel());
			return null;
		}

		Consume consume = new Consume(baseInfoCfg.get_FragmentId(), breakthoughtCfg.get_DecomposeCount());
		return consume;
	}

	/**
	 * 根据resourceId、breakthrought和level获取BeastConfig.BreakthoughtAndLevel
	 */
	public static BeastConfig.BreakthoughtAndLevel getBreakthoughtAndLevelByIdAndBreakAndLevel(BeastConfig beastConfig,
		int resourceId, int breakthought, int level)
	{
		for (int i = 0; i < beastConfig.Get_BreakthoughtAndLevelsCount(); i++)
		{
			BeastConfig.BreakthoughtAndLevel breakAndLevelCfg = beastConfig.Get_BreakthoughtAndLevelsByIndex(i);
			if (breakAndLevelCfg.get_Id() == resourceId && breakAndLevelCfg.get_Breakthought() == breakthought
				&& breakAndLevelCfg.get_Level() == level)
			{
				return breakAndLevelCfg;
			}
		}
		return null;
	}

	/**
	 * 是否可以提升品阶（零件位置是否已经全部装备）
	 */
	public static boolean canLevelUp(Beast beast, BeastConfig.BreakthoughtAndLevel breakAndLevelCfg)
	{
		if (beast.getPartIndexs().size() >= breakAndLevelCfg.Get_BeastPartActivesCount())
		{
			return true;
		}

		return false;
	}

	/**
	 * 机关兽商店系统刷新
	 */
	public static void systemRefresh(PlayerNode playerNode, long now, BeastConfig beastCfg,
		BeastConfig.BeastPartShop partShopCfg)
	{
		BeastData beastData = playerNode.getPlayerInfo().getBeastData();
		// 判断是否需要刷新
		if (!BeastUtil.canSystemRefresh(beastData.getShopLastRefreshTime(), now, beastCfg, partShopCfg))
		{
			return;
		}

		// 刷新兑换条目
		refreshExchange(beastData, beastCfg, partShopCfg);
		// 重置系统刷新时间
		beastData.setShopLastRefreshTime(now);
		// 修改数据库
		BeastInfoDB.updateBeastInfo(playerNode);
	}

	/**
	 * 机关兽商店手动刷新
	 */
	public static void handRefresh(PlayerNode playerNode, BeastConfig beastCfg, BeastConfig.BeastPartShop partShopCfg)
	{
		// 刷新兑换条目
		refreshExchange(playerNode.getPlayerInfo().getBeastData(), beastCfg, partShopCfg);
		// 修改数据库
		BeastInfoDB.updateBeastInfo(playerNode);
	}

	/**
	 * 刷新兑换条目
	 */
	private static void refreshExchange(BeastData beastData, BeastConfig beastCfg, BeastConfig.BeastPartShop partShopCfg)
	{
		// 兑换条目id
		ArrayList<Integer> exchangeIds = new ArrayList<Integer>();
		for (int i = 0; i < partShopCfg.Get_RefreshExchangeGroupIdsCount(); i++)
		{
			int groupId = partShopCfg.Get_RefreshExchangeGroupIdsByIndex(i);
			BeastConfig.ExchangeGroup exchangeGroup = beastCfg.GetExchangeGroupByGroupId(groupId);
			if (exchangeGroup == null)
			{
				logger.error("____beast refreshExchange error, wrong exchangeGroupId={}", groupId);
				return;
			}

			// 生成兑换条目id
			int exchangId = genExchangeId(exchangeGroup, exchangeIds);
			exchangeIds.add(exchangId);
		}

		// 洗牌
		Collections.shuffle(exchangeIds);
		logger.debug("_______beast refreshExchange, gen exchangId and shuffle, exchangId:{}", exchangeIds);
		// 清除内存中原有兑换条目
		beastData.getBeastExchanges().clear();
		// 将新生成的兑换条目加到玩家身上
		for (int i = 0; i < exchangeIds.size(); i++)
		{
			BeastExchange beastExchange = new BeastExchange(exchangeIds.get(i), i);
			beastData.getBeastExchanges().add(beastExchange);
		}
	}

	private static int genExchangeId(BeastConfig.ExchangeGroup exchangeGroup, List<Integer> exchangeIds)
	{
		ValueRandomer random = new ValueRandomer();

		for (int i = 0; i < exchangeGroup.Get_GoodsWeightsCount(); i++)
		{
			BeastConfig.GoodsWeight goodsWeight = exchangeGroup.Get_GoodsWeightsByIndex(i);
			int exchangeId = goodsWeight.get_ExchangeId();
			if (exchangeIds.contains(exchangeId))
			{
				continue;
			}
			random.addValue(goodsWeight.get_Weight(), goodsWeight.get_ExchangeId());
		}

		// 为空
		if (random.isEmpty())
		{
			// 说明该组下的商品全都已经随机出来过（不能重复）
			logger.error("_____beast genExchangeId error, all exchangIds of groupId={} has existed.",
				exchangeGroup.get_ExchangeGroupId());
			return 0;
		}
		random.SetTotalValue();
		Object res = random.RandomData();
		if (res != null)
		{
			return (int)res;
		}
		else
		{
			logger.error("________beast genExchangeId error, config BeastConfig.ExchangeGroup wrong, exchangeGroupId={}",
				exchangeGroup.get_ExchangeGroupId());
			return 0;
		}
	}

	/**
	 * 机关兽商店是否需要刷新
	 */
	public static boolean canSystemRefresh(long lastRefreshTime, long now, BeastConfig beastCfg,
		BeastConfig.BeastPartShop partShopCfg)
	{
		ArrayList<Long> nowDates = getThisRefreshTimes(now, beastCfg, partShopCfg);
		for (long nowDate : nowDates)
		{
			long time1 = ServerUtil.getNextRefreshTime(now, nowDate);
			long time2 = ServerUtil.getNextRefreshTime(lastRefreshTime, nowDate);
			if (time1 != time2)
			{
				return true;
			}
		}

		return false;
	}

	private static ArrayList<Long> getThisRefreshTimes(long now, BeastConfig beastCfg,
		BeastConfig.BeastPartShop partShopCfg)
	{
		ArrayList<Long> refreshTimes = new ArrayList<Long>();
		long cfgTime;
		long cfgTimeWithZone;

		for (int i = 0; i < partShopCfg.Get_RefreshInfosCount(); ++i)
		{
			BeastConfig.RefreshInfo rf = partShopCfg.Get_RefreshInfosByIndex(i);
			cfgTime = ClientServerCommon.ConvertTicksToMs.DateTimeToInt64(beastCfg.toDateTime(rf.get_RefreshTime()));
			cfgTimeWithZone = ServerUtil.getLongForJava(cfgTime, TimeZoneData.getTimeZone());// 8区的10:15的long
			refreshTimes.add(cfgTimeWithZone);
		}
		return refreshTimes;
	}

	/**
	 * 根据当前时间获取下次系统刷新时间
	 */
	public static long getNextSystemRefreshTime(long now, BeastConfig beastCfg, BeastConfig.BeastPartShop partShopCfg)
	{
		ArrayList<Long> nowDates = getThisRefreshTimes(now, beastCfg, partShopCfg);
		long nextRefreshTime = ServerUtil.getNextRefreshTime(now, nowDates.get(0));
		for (int i = 1; i < nowDates.size(); ++i)
		{
			long tmpNext = ServerUtil.getNextRefreshTime(now, nowDates.get(i));
			if (nextRefreshTime > tmpNext)
			{
				nextRefreshTime = tmpNext;
			}
		}

		return nextRefreshTime;
	}

	/**
	 * 检查零件位置是否正确
	 */
	public static boolean checkPartIndex(int index)
	{
		if (index == BeastConfig._PartIndex.AllPut || index == BeastConfig._PartIndex.One
			|| index == BeastConfig._PartIndex.Two || index == BeastConfig._PartIndex.Three
			|| index == BeastConfig._PartIndex.Four || index == BeastConfig._PartIndex.Five)
		{
			return true;
		}

		return false;
	}

	/**
	 * 获取未装备零件的零件位置
	 */
	public static HashSet<Integer> getUnequipPartIndexs(Beast beast)
	{
		HashSet<Integer> unequipPartIndexs = new HashSet<Integer>();
		if (!beast.getPartIndexs().contains(BeastConfig._PartIndex.One))
		{
			unequipPartIndexs.add(BeastConfig._PartIndex.One);
		}

		if (!beast.getPartIndexs().contains(BeastConfig._PartIndex.Two))
		{
			unequipPartIndexs.add(BeastConfig._PartIndex.Two);
		}

		if (!beast.getPartIndexs().contains(BeastConfig._PartIndex.Three))
		{
			unequipPartIndexs.add(BeastConfig._PartIndex.Three);
		}

		if (!beast.getPartIndexs().contains(BeastConfig._PartIndex.Four))
		{
			unequipPartIndexs.add(BeastConfig._PartIndex.Four);
		}

		if (!beast.getPartIndexs().contains(BeastConfig._PartIndex.Five))
		{
			unequipPartIndexs.add(BeastConfig._PartIndex.Five);
		}

		return unequipPartIndexs;
	}
}
