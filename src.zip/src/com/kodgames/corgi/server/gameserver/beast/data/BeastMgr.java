package com.kodgames.corgi.server.gameserver.beast.data;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.BeastConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.common.Guid;
import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.corgi.server.gameserver.beast.db.BeastInfoDB;
import com.kodgames.corgi.server.gameserver.beast.util.BeastUtil;
import com.kodgames.gamedata.player.PlayerNode;

public class BeastMgr
{
	private static final Logger logger = LoggerFactory.getLogger(BeastMgr.class);

	/**
	 * 获取机关兽所有已激活零件对应的属性集合
	 */
	public static List<Integer> getBeastPartAttributeIds(Beast beast, ConfigDatabase cd)
	{
		List<Integer> partAttributeIds = new ArrayList<Integer>();
		BeastConfig beastConfig = cd.get_BeastConfig();
		BeastConfig.BreakthoughtAndLevel breakAndLevelCfg =
			BeastUtil.getBreakthoughtAndLevelByIdAndBreakAndLevel(beastConfig,
				beast.getResourceId(),
				beast.getBreakthoughtLevel(),
				beast.getLevel());
		if (breakAndLevelCfg == null)
		{
			logger.error("____getBeastPartAttributeIds failed, can't get BeastConfig.BreakthoughtAndLevel with beastId={},breakthought={};level={}",
				beast.getResourceId(),
				beast.getBreakthoughtLevel(),
				beast.getLevel());
		}

		for (int i = 0; i < breakAndLevelCfg.Get_BeastPartActivesCount(); i++)
		{
			BeastConfig.BeastPartActive partActiveCfg = breakAndLevelCfg.Get_BeastPartActivesByIndex(i);
			// 该机关兽已激活此位置的零件
			if (beast.getPartIndexs().contains(partActiveCfg.get_Index()))
			{
				partAttributeIds.add(partActiveCfg.get_AttributeId());
			}
		}

		return partAttributeIds;
	}
	
	/**
	 * 获取机关兽所有已激活零件对应的属性集合
	 */
	public static List<Integer> getBeastPartAttributeIds(DBProtocolsForServer.BeastDB beast, ConfigDatabase cd)
	{
		List<Integer> partAttributeIds = new ArrayList<Integer>();
		BeastConfig beastConfig = cd.get_BeastConfig();
		BeastConfig.BreakthoughtAndLevel breakAndLevelCfg =
			BeastUtil.getBreakthoughtAndLevelByIdAndBreakAndLevel(beastConfig,
				beast.getResourceId(),
				beast.getBreakthoughtLevel(),
				beast.getLevel());
		if (breakAndLevelCfg == null)
		{
			logger.error("____getBeastPartAttributeIds failed, can't get BeastConfig.BreakthoughtAndLevel with beastId={},breakthought={};level={}",
				beast.getResourceId(),
				beast.getBreakthoughtLevel(),
				beast.getLevel());
		}

		for (int i = 0; i < breakAndLevelCfg.Get_BeastPartActivesCount(); i++)
		{
			BeastConfig.BeastPartActive partActiveCfg = breakAndLevelCfg.Get_BeastPartActivesByIndex(i);
			// 该机关兽已激活此位置的零件
			if (beast.getPartIndexsList().contains(partActiveCfg.get_Index()))
			{
				partAttributeIds.add(partActiveCfg.get_AttributeId());
			}
		}

		return partAttributeIds;
	}

	/**
	 * 查机关兽
	 */
	public static Beast getBeast(Guid guid, PlayerNode playerNode)
	{
		return playerNode.getPlayerInfo().getBeastData().getBeast(guid);
	}
	
	/**
	 * 查机关兽
	 */
	public static DBProtocolsForServer.BeastDB getBeast(List<DBProtocolsForServer.BeastDB> beastDBs, String guid)
	{
		for (DBProtocolsForServer.BeastDB beast : beastDBs)
		{
			if (beast.getGuid().equals(guid))
			{
				return beast;
			}
		}
		return null;
	}

	/**
	 * 添加机关兽
	 */
	public static boolean addBeast(PlayerNode playerNode, Beast beast)
	{
		BeastData beastData = playerNode.getPlayerInfo().getBeastData();
		if (beastData.addBeast(beast))
		{
			BeastInfoDB.updateBeastInfo(playerNode);
			return true;
		}

		return false;
	}

	/**
	 * 机关兽升阶（改造）
	 */
	public static void beastLevelUp(PlayerNode playerNode, Beast beast, BeastConfig.BeastLevelUp levelUpCfg)
	{
		// 升阶
		beast.setLevel(levelUpCfg.get_LevelNext());
		// 升阶之后清除已装备零件位置
		beast.getPartIndexs().clear();
		// 写库
		BeastInfoDB.updateBeastInfo(playerNode);
	}

	/**
	 * 机关兽升星（强化）
	 */
	public static void beastBreakthought(PlayerNode playerNode, Beast beast,
		BeastConfig.BeastBreakthought breakthoughtCfg)
	{
		// 升星
		beast.setBreakthoughtLevel(breakthoughtCfg.get_BreakthoughtAfter());
		// 写库
		BeastInfoDB.updateBeastInfo(playerNode);
	}

}
