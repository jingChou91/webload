package com.kodgames.corgi.server.gameserver.beast.logic;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.BeastConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_BeastExchangeShopReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_BeastExchangeShopRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.beast.data.BeastData;
import com.kodgames.corgi.server.gameserver.beast.data.BeastExchange;
import com.kodgames.corgi.server.gameserver.beast.db.BeastInfoDB;
import com.kodgames.corgi.server.gameserver.beast.util.BeastUtil;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class CG_BeastExchangeShopReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_BeastExchangeShopReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_BeastExchangeShopReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_BeastExchangeShopReq request = (CG_BeastExchangeShopReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_BeastExchangeShopRes.Builder builder = GC_BeastExchangeShopRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_BEAST_EXCHANGE_SHOP_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_BEAST_EXCHANGE_SHOP_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();

		int exchangeId = request.getExchangeId();
		int index = request.getIndex();
		ArrayList<Cost> costs = Cost.generateCostListFromProtoBuf(request.getCostsList());

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_BEAST_EXCHANGE_SHOP_FAILED_LOAD_PLAYER;
					break;
				}

				BeastConfig beastCfg = cd.get_BeastConfig();
				if (beastCfg == null)
				{
					result = ClientProtocols.E_GAME_BEAST_EXCHANGE_SHOP_FAILED_LOAD_CONFIG;
					break;
				}

				BeastConfig.BeastPartShop partShopCfg = beastCfg.get_BeastPartShops();
				if (partShopCfg == null)
				{
					result = ClientProtocols.E_GAME_BEAST_EXCHANGE_SHOP_FAILED_LOAD_BEASTPARTSHOP_CONFIG;
					break;
				}

				BeastConfig.Exchange exchangeCfg = beastCfg.GetExchangeByExchangeId(exchangeId);
				if (exchangeCfg == null)
				{
					result = ClientProtocols.E_GAME_BEAST_EXCHANGE_SHOP_FAILED_LOAD_EXCHANGE_CONFIG;
					break;
				}

				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Beast))
				{
					result = ClientProtocols.E_GAME_BEAST_FUNCTION_NOT_OPEN;
					break;
				}

				BeastData beastData = playerNode.getPlayerInfo().getBeastData();
				// 当前时间
				long now = System.currentTimeMillis();
				// 系统刷新
				BeastUtil.systemRefresh(playerNode, now, beastCfg, partShopCfg);

				// 获取兑换的条目
				BeastExchange beastExchange = beastData.checkAndGetBeastExchange(exchangeId, index);
				// 条目信息错误
				if (beastExchange == null)
				{
					result = ClientProtocols.E_GAME_BEAST_EXCHANGE_SHOP_FAILED_OUT_OF_TIME;
					break;
				}

				// 是否已经兑换过
				if (beastExchange.isAlreadyExchanged())
				{
					result = ClientProtocols.E_GAME_BEAST_EXCHANGE_SHOP_FAILED_ALREADY_EXCHANGED;
					break;
				}

				// 具体消耗品（如2~5突破秦始皇、铜币）
				List<ClientServerCommon.ItemEx> itemExs = new ArrayList<>();
				for (int i = 0; i < exchangeCfg.Get_CostsCount(); i++)
				{
					itemExs.add(exchangeCfg.Get_CostsByIndex(i));
				}

				// 范围消耗品（如2~5突破橙卡）
				List<ClientServerCommon.CostAsset> costAssets = new ArrayList<>();
				for (int i = 0; i < exchangeCfg.Get_CostAssetsCount(); i++)
				{
					costAssets.add(exchangeCfg.Get_CostAssetsByIndex(i));
				}

				// 判断玩家发来的Cost和配置文件中是否相同
				if (!CostAndRewardManager.isMeetCostRequirement(costs, itemExs, costAssets, cd, playerNode))
				{
					result = ClientProtocols.E_GAME_BEAST_EXCHANGE_SHOP_FAILED_COSTS_NOT_MEEET_REQUIREMENT;
					break;
				}

				// 判断消耗是否足够
				Cost notEnoughCost = new Cost();
				CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
				if (!CostAndRewardManager.checkCosts(playerNode, costs, cd, KodLogEvent.Beast_Exchange, notEnoughCost))
				{
					crsForClient.setNotEnoughCost(notEnoughCost);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_BEAST_EXCHANGE_SHOP_FAILED_COSTS_NOT_ENOUGH;
					break;
				}
				// 消耗
				crsForCost.setCosts(costs);
				CostAndRewardManager.consumeCosts(playerNode, costs, cd, KodLogEvent.Beast_Exchange, 0, 0);
				crsForClient.megerCostAndRewardAndSync(crsForCost);

				// 修改该条目状态为已兑换
				beastExchange.setAlreadyExchanged(true);
				// 道具奖励
				Reward reward = new Reward();
				reward.fromClientServerCommon(exchangeCfg.get_Reward());
				CostAndRewardAndSync crsForReq = new CostAndRewardAndSync();
				CostAndRewardManager.addReward(playerNode, reward, cd, KodLogEvent.Beast_Exchange);
				crsForReq.mergeReward(reward);
				crsForClient.megerCostAndRewardAndSync(crsForReq);
				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());

				// 数据库
				BeastInfoDB.updateBeastInfo(playerNode);
				
				// 小助手
				playerNode.getPlayerInfo().getAssisantData().getBeast().notifyObservers();
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
