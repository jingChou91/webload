package com.kodgames.corgi.server.gameserver.beast.data;

import java.util.HashSet;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.IMathParser;

import com.kodgames.common.Guid;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.corgi.server.gameserver.avatar.data.Card;

/**
 * ***************** level表示品阶(改造的等级) breakthought表示星级（强化）
 */
public class Beast extends Card
{

	private HashSet<Integer> partIndexs = new HashSet<Integer>(); // 该品阶已装备碎片的位置

	@Override
	public Object[] getObjectListForInsertRow(int playerId, int status_did_delete)
	{
		return new Object[] {};
	}

	@Override
	/**
	 * 只能传入Beast类型的参数,否则会导致向下转型失败
	 */
	public Beast copy(Card card)
	{
		Beast beast = (Beast)card;
		setGuid(Guid.genNewGuid(beast.getGuid().toString()));
		setResourceId(beast.getResourceId());
		setLevel(beast.getLevel());
		setExperience(beast.getExperience());
		setBreakthoughtLevel(beast.getBreakthoughtLevel());
		for (int partIndex : beast.getPartIndexs())
		{
			this.getPartIndexs().add(partIndex);
		}

		return this;
	}

	public static Beast genNewBeast(int resourceId)
	{
		Beast beast = new Beast();
		beast.setGuid(new Guid());
		beast.setResourceId(resourceId);
		beast.setLevel(1);
		beast.setExperience(0);
		beast.setBreakthoughtLevel(0);
		return beast;
	}

	/**
	 * 装备零件
	 */
	public boolean equipPart(int index)
	{
		return this.getPartIndexs().add(index);
	}

	@Override
	public CommonProtocols.Beast toProtoBuffer()
	{
		CommonProtocols.Beast.Builder builder = CommonProtocols.Beast.newBuilder();

		builder.setGuid(this.getGuid().toString());
		builder.setResourceId(this.getResourceId());
		CommonProtocols.LevelAttrib.Builder levelAttributbuilder = CommonProtocols.LevelAttrib.newBuilder();
		levelAttributbuilder.setLevel(this.getLevel());
		levelAttributbuilder.setExperience(this.getExperience());
		builder.setLevelAttrib(levelAttributbuilder.build());
		builder.setBreakthoughtLevel(this.getBreakthoughtLevel());
		for (int partIndex : this.getPartIndexs())
		{
			builder.addPartIndexs(partIndex);
		}
		return builder.build();
	}

	public Beast fromProtoBuffer(com.kodgames.corgi.protocol.CommonProtocols.Beast protocol)
	{
		this.setGuid(Guid.genNewGuid(protocol.getGuid()));
		this.setResourceId(protocol.getResourceId());
		this.setLevel(protocol.getLevelAttrib().getLevel());
		this.setExperience(protocol.getLevelAttrib().getExperience());
		this.setBreakthoughtLevel(protocol.getBreakthoughtLevel());

		for (int partIndex : protocol.getPartIndexsList())
		{
			this.getPartIndexs().add(partIndex);
		}

		return this;
	}

	public DBProtocolsForServer.BeastDB toDBProtoBuf()
	{
		DBProtocolsForServer.BeastDB.Builder builder = DBProtocolsForServer.BeastDB.newBuilder();
		builder.setGuid(getGuid().toString());
		builder.setResourceId(this.getResourceId());
		builder.setLevel(this.getLevel());
		builder.setExperience(this.getExperience());
		builder.setBreakthoughtLevel(this.getBreakthoughtLevel());
		builder.addAllPartIndexs(this.getPartIndexs());

		return builder.build();
	}

	public void fromDBProtoBuf(DBProtocolsForServer.BeastDB beastDB)
	{
		this.setGuid(Guid.genNewGuid(beastDB.getGuid()));
		this.setResourceId(beastDB.getResourceId());
		this.setLevel(beastDB.getLevel());
		this.setExperience(beastDB.getExperience());
		this.setBreakthoughtLevel(beastDB.getBreakthoughtLevel());
		for (int partIndex : beastDB.getPartIndexsList())
		{
			this.getPartIndexs().add(partIndex);
		}
	}

	@Override
	public void setupVariable(IMathParser parser, ConfigDatabase cd)
	{

	}

	public HashSet<Integer> getPartIndexs()
	{
		return partIndexs;
	}

	public void setPartIndexs(HashSet<Integer> partIndexs)
	{
		this.partIndexs = partIndexs;
	}
}
