package com.kodgames.corgi.server.gameserver.beast.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.kodgames.common.Guid;
import com.kodgames.corgi.protocol.DBProtocolsForServer;

public class BeastData
{
	private HashMap<Integer, Beast> beasts = new HashMap<Integer, Beast>(); // 玩家拥有的机关兽 resourceId_beast

	private long shopLastRefreshTime; // 机关兽商人上一次系统刷新时间
	private List<BeastExchange> beastExchanges = new ArrayList<BeastExchange>(); // 可兑换的商品

	/**
	 * 根据exchangId和index检查并获得要兑换的条目
	 */
	public BeastExchange checkAndGetBeastExchange(int exchangeId, int index)
	{
		for (BeastExchange tmp : beastExchanges)
		{
			if (tmp.getExchangeId() == exchangeId && tmp.getIndex() == index)
			{
				return tmp;
			}
		}

		return null;
	}

	// 查机关兽
	public Beast getBeast(Guid guid)
	{
		for (Beast _beast : beasts.values())
		{
			if (_beast.getGuid().equals(guid))
			{
				return _beast;
			}
		}
		return null;
	}

	// 加机关兽
	public boolean addBeast(Beast beast)
	{
		if (getBeast(beast.getGuid()) == null && !beasts.containsKey(beast.getResourceId()))
		{
			beasts.put(beast.getResourceId(), beast);
			return true;
		}
		return false;
	}

	public DBProtocolsForServer.BeastInfoDB toBeastInfoDBProtolBuf()
	{
		DBProtocolsForServer.BeastInfoDB.Builder builder = DBProtocolsForServer.BeastInfoDB.newBuilder();
		for (Beast beast : beasts.values())
		{
			builder.addBeastDBs(beast.toDBProtoBuf());
		}
		
		return builder.build();
	}

	public void fromBeastInfoDBProtolBuf(DBProtocolsForServer.BeastInfoDB beastInfoDB)
	{
		for (DBProtocolsForServer.BeastDB beastDB : beastInfoDB.getBeastDBsList())
		{
			Beast beast = new Beast();
			beast.fromDBProtoBuf(beastDB);
			this.getBeasts().put(beast.getResourceId(), beast);
		}
	}

	public DBProtocolsForServer.BeastExchangeInfoDB toExchangeInfoDBProtolBuf()
	{
		DBProtocolsForServer.BeastExchangeInfoDB.Builder builder = DBProtocolsForServer.BeastExchangeInfoDB.newBuilder();
		for (BeastExchange beastExchange : beastExchanges)
		{
			builder.addBeastExchangeDBs(beastExchange.toDBProtoBuf());
		}
		
		return builder.build();
	}

	public void fromExchangeInfoDBProtolBuf(DBProtocolsForServer.BeastExchangeInfoDB beastExchangeInfoDB)
	{
		for (DBProtocolsForServer.BeastExchangeDB exchangeDB : beastExchangeInfoDB.getBeastExchangeDBsList())
		{
			BeastExchange beastExchange = new BeastExchange();
			beastExchange.fromDBProtoBuf(exchangeDB);
			this.getBeastExchanges().add(beastExchange);
		}
	}
	
	public HashMap<Integer, Beast> getBeasts()
	{
		return beasts;
	}

	public void setBeasts(HashMap<Integer, Beast> beasts)
	{
		this.beasts = beasts;
	}

	public long getShopLastRefreshTime()
	{
		return shopLastRefreshTime;
	}

	public void setShopLastRefreshTime(long shopLastRefreshTime)
	{
		this.shopLastRefreshTime = shopLastRefreshTime;
	}

	public List<BeastExchange> getBeastExchanges()
	{
		return beastExchanges;
	}

	public void setBeastExchanges(List<BeastExchange> beastExchanges)
	{
		this.beastExchanges = beastExchanges;
	}
}
