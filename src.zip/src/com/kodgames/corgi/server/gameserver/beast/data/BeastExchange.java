package com.kodgames.corgi.server.gameserver.beast.data;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.BeastConfig;
import ClientServerCommon.CostAsset;
import ClientServerCommon.ItemEx;

import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.gamedata.player.costandreward.Reward;

public class BeastExchange
{
	private static final Logger logger = LoggerFactory.getLogger(BeastExchange.class);

	private int exchangeId; // 兑换商品id
	private int index; // 兑换商品位置
	private boolean isAlreadyExchanged = false; // 该商品是否已兑换

	public BeastExchange()
	{

	}

	public BeastExchange(int exchangeId, int index)
	{
		this.exchangeId = exchangeId;
		this.index = index;
		this.isAlreadyExchanged = false;
	}

	public BeastExchange(int exchangeId, int index, boolean isAlreadyExchanged)
	{
		this.exchangeId = exchangeId;
		this.index = index;
		this.isAlreadyExchanged = isAlreadyExchanged;
	}

	public CommonProtocols.ZentiaExchange toProtoBuf(BeastConfig beastCfg)
	{
		CommonProtocols.ZentiaExchange.Builder builder = CommonProtocols.ZentiaExchange.newBuilder();
		builder.setExchangeId(exchangeId);
		builder.setIndex(index);
		builder.setIsAlreadyExchanged(isAlreadyExchanged);
		BeastConfig.Exchange exchangeCfg = beastCfg.GetExchangeByExchangeId(exchangeId);
		if (exchangeCfg != null)
		{
			// 范围类消耗（如2~5突破橙色角色）
			for (int i = 0; i < exchangeCfg.Get_CostAssetsCount(); i++)
			{
				CostAsset costAssetCfg = exchangeCfg.Get_CostAssetsByIndex(i);
				CommonProtocols.CostAsset.Builder costAsset = CommonProtocols.CostAsset.newBuilder();
				costAsset.setCount(costAssetCfg.get_count());
				costAsset.setIconId(costAssetCfg.get_iconId());
				costAsset.setQualityLevel(costAssetCfg.get_qualityLevel());
				costAsset.setSubType(costAssetCfg.get_subType());
				costAsset.setType(costAssetCfg.get_type());
				costAsset.setBreakThroughLevelFrom(costAssetCfg.get_breakThroughLevelFrom());
				costAsset.setBreakThroughLevelTo(costAssetCfg.get_breakThroughLevelTo());
				costAsset.setLevelFrom(costAssetCfg.get_levelFrom());
				costAsset.setLevelTo(costAssetCfg.get_levelTo());
				builder.addCostAssets(costAsset.build());
			}

			// 明确的消耗（如2~5突破秦始皇）
			for (int i = 0; i < exchangeCfg.Get_CostsCount(); i++)
			{
				ItemEx itemExCfg = exchangeCfg.Get_CostsByIndex(i);
				CommonProtocols.ItemEx.Builder itemEx = CommonProtocols.ItemEx.newBuilder();
				itemEx.setId(itemExCfg.get_id());
				itemEx.setCount(itemExCfg.get_count());
				itemEx.setExtensionBreakThroughLevelFrom(itemExCfg.get_extensionBreakThroughLevelFrom());
				itemEx.setExtensionBreakThroughLevelTo(itemExCfg.get_extensionBreakThroughLevelTo());
				itemEx.setExtensionLevelFrom(itemExCfg.get_extensionLevelFrom());
				itemEx.setExtensionLevelTo(itemExCfg.get_extensionLevelTo());
				builder.addCosts(itemEx.build());
			}

			// 获得道具奖励
			Reward reward = new Reward();
			reward.fromClientServerCommon(exchangeCfg.get_Reward());
			builder.setReward(reward.toProtobuf());
			builder.setIconId(exchangeCfg.get_IconId());
		}
		else
		{
			logger.error("BeastExchang toProtoBuf error, BeastConfig.Exchange could not found, exchangId={}",
				exchangeId);
		}
		return builder.build();
	}

	public BeastExchange fromDBProtoBuf(DBProtocolsForServer.BeastExchangeDB exchangeDB)
	{
		this.setExchangeId(exchangeDB.getExchangeId()); // 兑换商品id
		this.setIndex(exchangeDB.getIndex()); // 兑换商品位置
		this.setAlreadyExchanged(exchangeDB.getIsAlreadyExchanged()); // 该商品是否已兑换

		return this;
	}

	public DBProtocolsForServer.BeastExchangeDB toDBProtoBuf()
	{
		DBProtocolsForServer.BeastExchangeDB.Builder builder = DBProtocolsForServer.BeastExchangeDB.newBuilder();
		builder.setExchangeId(this.exchangeId);
		builder.setIndex(this.index);
		builder.setIsAlreadyExchanged(this.isAlreadyExchanged);
		return builder.build();
	}

	public int getExchangeId()
	{
		return exchangeId;
	}

	public void setExchangeId(int exchangeId)
	{
		this.exchangeId = exchangeId;
	}

	public int getIndex()
	{
		return index;
	}

	public void setIndex(int index)
	{
		this.index = index;
	}

	public boolean isAlreadyExchanged()
	{
		return isAlreadyExchanged;
	}

	public void setAlreadyExchanged(boolean isAlreadyExchanged)
	{
		this.isAlreadyExchanged = isAlreadyExchanged;
	}
}
