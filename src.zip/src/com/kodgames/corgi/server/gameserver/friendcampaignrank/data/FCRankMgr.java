package com.kodgames.corgi.server.gameserver.friendcampaignrank.data;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

import javax.sql.rowset.CachedRowSet;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import system.DateTime;
import ClientServerCommon._FCRankType;

import com.google.protobuf.InvalidProtocolBufferException;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.friendcampaignrank.util.FCRankTimeUtil;
import com.kodgames.gamedata.player.PlayerNode;

public class FCRankMgr
{
	private static final Logger logger = LoggerFactory.getLogger(FCRankMgr.class);
	private static final int MAX_PLAYER_RANK = 100;                    //最多显示100个玩家的排行信息
	private TreeSet<SimpleFCScoreInfo>  lastRank = new TreeSet<>();    //上次排名
	private TreeSet<SimpleFCScoreInfo> currentRank = new TreeSet<>();  //本次排名
	private long lastRefreshTime;                                      //用于判断是否应该刷新当前排行和上期排行

	private static FCRankMgr instance = new FCRankMgr();

	private FCRankMgr(){}

	public static FCRankMgr getInstance()
	{
		return instance;
	}
	
	public static void main(String... args)
	{
		SimpleFCScoreInfo temp = new SimpleFCScoreInfo();
		temp.setPlayerId(1);
		temp.setPoint(100);
		
		SimpleFCScoreInfo temp1 = new SimpleFCScoreInfo();
		temp1.setPlayerId(2);
		temp1.setPoint(200);
		
		FCRankMgr.instance.lastRank.add(temp);
		FCRankMgr.instance.lastRank.add(temp1);
		
		for(SimpleFCScoreInfo sss : FCRankMgr.instance.lastRank)
		{
			logger.debug("{}", sss.getPlayerId());
			
		}
		logger.debug("{}", FCRankMgr.instance.lastRank.pollFirst().getPlayerId());
		
	}

	/*
	 * 刷新排行榜
	 */
	private void refreshRankInfo(long now)
	{
		ClientServerCommon.FriendCampaignConfig fcCfg =  CfgDB.getDefautConfig().get_FriendCampaignConfig();		
		DateTime refreshTime =  fcCfg.get_FCRankRefreshDateTime();		
		if (ServerUtil.nextRefreshTime(lastRefreshTime, refreshTime) != ServerUtil.nextRefreshTime(now, refreshTime))
		{
			if(FCRankTimeUtil.inLastCycle(this.lastRefreshTime, now, CfgDB.getDefautConfig().get_FriendCampaignConfig().get_FCRankRefreshDateTime()))
			{
				lastRank = currentRank;
				currentRank = new TreeSet<>();
				lastRefreshTime = now;
			}
			else			//如果多天没有协议触发
			{
				lastRank = new TreeSet<>();
				currentRank = new TreeSet<>();
				lastRefreshTime = now;
			}
		}
	}

	/*
	 * 刷新排行榜(支持本次和上次)
	 */
	public synchronized void addRank(SimpleFCScoreInfo simpleFCScoreInfo, int type)
	{
		if(simpleFCScoreInfo != null)
		{
			if(type == _FCRankType.LastPeriod)
			{
				this.lastRank.add(simpleFCScoreInfo);
				if(this.lastRank.size() > MAX_PLAYER_RANK)
				{
					this.lastRank.pollLast();
				}
			}
			else if(type == _FCRankType.CurrentPeriod)
			{
				refreshRankInfo(simpleFCScoreInfo.getTime());

				if(FCRankTimeUtil.inLastCycle(simpleFCScoreInfo.getTime(), this.lastRefreshTime, CfgDB.getDefautConfig().get_FriendCampaignConfig().get_FCRankRefreshDateTime()))
				{
					Iterator<SimpleFCScoreInfo> it = this.lastRank.iterator();
					while(it.hasNext())
					{
						if(it.next().equals(simpleFCScoreInfo))
						{
							it.remove();
						}
					}

					this.lastRank.add(simpleFCScoreInfo);
					if(this.lastRank.size() > MAX_PLAYER_RANK)
					{
						this.lastRank.pollLast();
					}
				}
				else
				{
					Iterator<SimpleFCScoreInfo> it = this.currentRank.iterator();
					while(it.hasNext())
					{
						if(it.next().equals(simpleFCScoreInfo))
						{
							it.remove();
						}
					}
					this.currentRank.add(simpleFCScoreInfo);
					if(this.currentRank.size() > MAX_PLAYER_RANK)
					{
						this.currentRank.pollLast();
					}
				}
			}
		}
	}

	/*
	 * 取排行榜信息
	 */
	public synchronized ArrayList<SimpleFCScoreInfo> getSubRank(int rankSize, int type, long now)
	{
		refreshRankInfo(now);
		int i = 0;
		ArrayList<SimpleFCScoreInfo> simpleFCScoreInfos = new ArrayList<SimpleFCScoreInfo>();
		if(type == _FCRankType.LastPeriod)
		{
			for(SimpleFCScoreInfo temp : this.lastRank)
			{
				if(i >= rankSize)
				{
					break;
				}
				simpleFCScoreInfos.add(temp);
				i++;
			}
		}
		else if(type == _FCRankType.CurrentPeriod)
		{
			for(SimpleFCScoreInfo temp : this.currentRank)
			{
				if(i >= rankSize)
				{
					break;
				}
				simpleFCScoreInfos.add(temp);
				i++;
			}
		}

		return simpleFCScoreInfos;
	}

	/*
	 * 取上期排行榜排名
	 */
	public synchronized int getRankInLastRank(int playerId, long now)
	{
		refreshRankInfo(now);
		SimpleFCScoreInfo temp = new SimpleFCScoreInfo();
		temp.setPlayerId(playerId);
		int maxRank = CfgDB.getDefautConfig().get_FriendCampaignConfig().get_FcRankRule().get_RankMaxCapacity();

		int rank = 0;
		for(SimpleFCScoreInfo simpleFCScoreInfo : this.lastRank)
		{
			rank++;
			if(rank <= maxRank && simpleFCScoreInfo.equals(temp))
			{
				return rank;
			}
			else if(rank > maxRank)
			{
				break;
			}
		}

		return 0;
	}

	/*
	 * 从DB中加载数据,并重建排行榜
	 */
	public void init(CachedRowSet rs) throws SQLException
	{
		if(rs != null )
		{
			ClientServerCommon.FriendCampaignConfig friendCampaignConfig =  CfgDB.getDefautConfig().get_FriendCampaignConfig();		
			DateTime refreshTime =  friendCampaignConfig.get_FCRankRefreshDateTime();
			long nowTime = System.currentTimeMillis();

			while (rs.next())
			{	
				//加载玩家的数据到玩家内存
				int playerId = rs.getInt("player_id");

				ContributeFCScoreInfos lastFCScoreInfos = new ContributeFCScoreInfos();
				ContributeFCScoreInfos currentFCScoreInfos = new ContributeFCScoreInfos();

				byte[] lastBuffer = rs.getBytes("last_contribute_fc_score_info");
				byte[] currentBuffer = rs.getBytes("current_contribute_fc_score_info");

				DBProtocolsForServer.ContributeFCScoreInfo.Builder lastBuilder = DBProtocolsForServer.ContributeFCScoreInfo.newBuilder();
				DBProtocolsForServer.ContributeFCScoreInfo.Builder currentBuilder = DBProtocolsForServer.ContributeFCScoreInfo.newBuilder();
				try
				{
					if(lastBuffer != null)
					{
						lastBuilder.mergeFrom(lastBuffer);
					}
					if(currentBuffer != null)
					{
						currentBuilder.mergeFrom(currentBuffer);
					}
				}
				catch (InvalidProtocolBufferException e)
				{
					logger.error(ExceptionUtils.getStackTrace(e));
				}

				lastFCScoreInfos.fromDBProtobuf(lastBuilder.build());
				currentFCScoreInfos.fromDBProtobuf(currentBuilder.build());

				if(!FCRankTimeUtil.inLastCycle(lastFCScoreInfos.getLastGetPointTime(), nowTime, refreshTime))
				{
					lastFCScoreInfos = null;
				}

				if(!FCRankTimeUtil.inCurrentCycle(currentFCScoreInfos.getLastGetPointTime(), nowTime, refreshTime))
				{
					if(FCRankTimeUtil.inLastCycle(currentFCScoreInfos.getLastGetPointTime(), nowTime, refreshTime))
					{
						lastFCScoreInfos = currentFCScoreInfos;
					}
					currentFCScoreInfos = null;
				}

				PlayerNode playerNode = ServerDataGS.playerManager.getMemoryPlayerNode(playerId);
				if(playerNode != null && playerNode.getGamePlayer() != null)
				{
					playerNode.getGamePlayer().getFcScoreData().setCurrentContributeFCScoreInfos(currentFCScoreInfos);
					playerNode.getGamePlayer().getFcScoreData().setLastContributeFCScoreInfos(lastFCScoreInfos);
				}

				//重建排行榜数据
				lastRefreshTime = nowTime;
				if(lastFCScoreInfos != null)
				{
					SimpleFCScoreInfo temp = lastFCScoreInfos.getSimpleFCScoreInfo(playerId);
					addRank(temp, _FCRankType.LastPeriod);
				}

				if(currentFCScoreInfos != null)
				{
					SimpleFCScoreInfo temp = currentFCScoreInfos.getSimpleFCScoreInfo(playerId);
					addRank(temp, _FCRankType.CurrentPeriod);
				}
			}
		}
	}
}
