package com.kodgames.corgi.server.gameserver.friendcampaignrank.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.FriendCampaignConfig;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_FCRankGetRewardReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_FCRankGetRewardRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.friendcampaignrank.data.FCRankMgr;
import com.kodgames.corgi.server.gameserver.friendcampaignrank.util.FCRankTimeUtil;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;
import com.kodgames.gamedata.player.costandreward.RewardGen;

public class CG_FCRankGetRewardReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_FCRankGetRewardReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_FCRankGetRewardReq, playerId = {}", sender.getClientUID().getPlayerID());
		CG_FCRankGetRewardReq request = (CG_FCRankGetRewardReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_FCRankGetRewardRes.Builder builder = GC_FCRankGetRewardRes.newBuilder();
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_FC_RANK_GET_REWARD_RES);
		builder.setCallback(request.getCallback());
        long now = System.currentTimeMillis();
		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_FC_RANK_GET_REWARD_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_FC_RANK_GET_REWARD_FAILED_LOAD_PLAYER;
					break;
				}

				FriendCampaignConfig friendCampaignConfig =  cd.get_FriendCampaignConfig();	
				int rank = FCRankMgr.getInstance().getRankInLastRank(playerId, now);
				if(rank <= 0)
				{
					//未上榜，无法领取奖励
					result = ClientProtocols.E_GAME_FC_RANK_GET_REWARD_FAILED_NOT_ON_RANK;
					break;
				}

				playerNode.getGamePlayer().getFcScoreData().refreshContributeFCScoreInfos(now, playerNode.getGamePlayer().getVipLevel());
				
				if(playerNode.getGamePlayer().getFcScoreData().isRewardPicked())
				{
					result = ClientProtocols.E_GAME_FC_RANK_GET_REWARD_FAILED_REWARD_ALREADY_PICKED;
					break;
				}
				//领取奖励更新数据库
				FCRankTimeUtil.pickReward(playerNode);
				
				Reward reward = RewardGen.getRewardFromCfgRewardList(friendCampaignConfig.GetRankRewardByRank(rank));
				CostAndRewardAndSync crsHere = new CostAndRewardAndSync();
				crsHere.mergeReward(reward);
				CostAndRewardManager.addReward(playerNode, reward, cd, KodLogEvent.FCRankRewardLogic_Get);
				crsForClient.megerCostAndRewardAndSync(crsHere);
				builder.setReward(crsForClient.toProtobuf());
				builder.setIsGetReward(true);

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
