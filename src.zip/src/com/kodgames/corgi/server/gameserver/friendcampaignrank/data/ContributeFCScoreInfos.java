package com.kodgames.corgi.server.gameserver.friendcampaignrank.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.corgi.protocol.DBProtocolsForServer.ContributeFCScoreInfo.FCScoreInfo;

public class ContributeFCScoreInfos 
{
	private HashMap<Integer, FCScoreInfo> fCScoreInfos = new HashMap<>();//[playerId : FCScoreInfo]
	private int maxCalcNumber;             //记录当前VIP等级下用于计算的玩家的数目
	private boolean hasPickReward = false; //如果上榜，判断玩家奖励是否领取
	private int point;            //玩家自己所获得的的积分
	private long lastGetPointTime;//玩家最后获得积分的时间（自己打好友副本或者好友帮忙）
	private long time;            //玩家自己最后通关时间
	private int  levelCounts;     //玩家的关卡总数

	public HashMap<Integer, FCScoreInfo> getfCScoreInfos() 
	{
		return fCScoreInfos;
	}
	public void setfCScoreInfos(HashMap<Integer, FCScoreInfo> fCScoreInfos) 
	{
		this.fCScoreInfos = fCScoreInfos;
	}
	public int getMaxCalcNumber() 
	{
		return maxCalcNumber;
	}
	public void setMaxCalcNumber(int maxCalcNumber) 
	{
		this.maxCalcNumber = maxCalcNumber;
	}
	public boolean isHasPickReward()
	{
		return hasPickReward;
	}
	public void setHasPickReward(boolean hasPickReward)
	{
		this.hasPickReward = hasPickReward;
	}
	public int getPoint()
	{
		return point;
	}
	public long getLastGetPointTime()
	{
		return lastGetPointTime;
	}
	
	/*
	 * 增加玩家自己的情义值
	 */
	public void addPoint(int point, long getPointTime)
	{
		this.point += point;
		this.lastGetPointTime = getPointTime;
		this.time = getPointTime;
		this.levelCounts++;
	}
	
	/*
	 * 增加好友贡献的情义值
	 */
	public void addPoint(int playerId, int point, long getPointTime)
	{
		FCScoreInfo.Builder builder = FCScoreInfo.newBuilder();
		if(this.fCScoreInfos.containsKey(playerId))
		{
			FCScoreInfo temp = this.fCScoreInfos.get(playerId);
			
			builder.setPlayerId(temp.getPlayerId());
			builder.setLevelCounts(temp.getLevelCounts() + 1);
			builder.setPoint(temp.getPoint() + point);
			builder.setTime(getPointTime);
		}
		else
		{
			builder.setPlayerId(playerId);
			builder.setLevelCounts(1);
			builder.setPoint(point);
			builder.setTime(getPointTime);
		}
		
		this.fCScoreInfos.put(playerId, builder.build());
		this.lastGetPointTime = getPointTime;
	}

	/*
	 * 计算玩家的总情义值
	 */
	public SimpleFCScoreInfo getSimpleFCScoreInfo(int playerId)
	{
		SimpleFCScoreInfo simpleFCScoreInfo = new SimpleFCScoreInfo();
		simpleFCScoreInfo.setPlayerId(playerId);
		simpleFCScoreInfo.setTime(this.lastGetPointTime);
		int totalPoint = this.point;

		List<Map.Entry<Integer, FCScoreInfo>> temp = new ArrayList<Map.Entry<Integer, FCScoreInfo>>(this.fCScoreInfos.entrySet());

		Collections.sort(temp, new Comparator<Map.Entry<Integer, FCScoreInfo>>() { 
			public int compare(Map.Entry<Integer, FCScoreInfo> o1, Map.Entry<Integer, FCScoreInfo> o2) {
				return (int) (o2.getValue().getPoint() - o1.getValue().getPoint());
			}
		});
		
		for(int i = 0 ; i < temp.size() && i < this.maxCalcNumber ; i++)
		{
			totalPoint += temp.get(i).getValue().getPoint();
		}
		simpleFCScoreInfo.setPoint(totalPoint);
		return simpleFCScoreInfo;
	}

	/*
	 * 返回好友的贡献
	 */
	public ArrayList<FCScoreInfo> getFriendFCScoreInfos(int playerId)
	{
		ArrayList<FCScoreInfo> fcScoreInfos = new ArrayList<>();
		List<Map.Entry<Integer, FCScoreInfo>> temp = new ArrayList<Map.Entry<Integer, FCScoreInfo>>(this.fCScoreInfos.entrySet());

		Collections.sort(temp, new Comparator<Map.Entry<Integer, FCScoreInfo>>() { 
			public int compare(Map.Entry<Integer, FCScoreInfo> o1, Map.Entry<Integer, FCScoreInfo> o2) {
				return (int) (o2.getValue().getPoint() - o1.getValue().getPoint());
			}
		});
		
		for(int i = 0 ; i < temp.size() && i < this.maxCalcNumber ; i++)
		{
			fcScoreInfos.add(temp.get(i).getValue());
		}
		
		//加上玩家自己的信息
		FCScoreInfo.Builder builder = FCScoreInfo.newBuilder();
		builder.setPlayerId(playerId);
		builder.setPoint(this.point);
		builder.setTime(this.time);
		builder.setLevelCounts(this.levelCounts);
		fcScoreInfos.add(builder.build());
		return fcScoreInfos;
	}

	public DBProtocolsForServer.ContributeFCScoreInfo toProtobuf()
	{
		DBProtocolsForServer.ContributeFCScoreInfo.Builder builder = DBProtocolsForServer.ContributeFCScoreInfo.newBuilder();
		builder.setMaxCalcNumber(this.maxCalcNumber);
		builder.setHasPickReward(this.hasPickReward);
		builder.setPoint(this.point);
		builder.setLastGetPointTime(this.lastGetPointTime);
		builder.setTime(this.time);
		builder.setLevelCounts(this.levelCounts);
		for(FCScoreInfo fcScoreInfo : this.fCScoreInfos.values())
		{
			builder.addFcScoreInfo(fcScoreInfo);
		}
		return builder.build();
	}

	public void fromDBProtobuf(DBProtocolsForServer.ContributeFCScoreInfo contributeFCScoreInfo)
	{
		this.maxCalcNumber = contributeFCScoreInfo.getMaxCalcNumber();
		this.hasPickReward = contributeFCScoreInfo.getHasPickReward();
		this.point = contributeFCScoreInfo.getPoint();
		this.lastGetPointTime = contributeFCScoreInfo.getLastGetPointTime();
		this.levelCounts = contributeFCScoreInfo.getLevelCounts();
		this.time = contributeFCScoreInfo.getTime();
		if(contributeFCScoreInfo.getFcScoreInfoList() != null)
		{
			for(FCScoreInfo fcScoreInfo : contributeFCScoreInfo.getFcScoreInfoList())
			{
				this.fCScoreInfos.put(fcScoreInfo.getPlayerId(), fcScoreInfo);
			}
		}
	}
	
//	public static void main(String... args)
//	{
//		ContributeFCScoreInfos contributeFCScoreInfos = new ContributeFCScoreInfos();
//		contributeFCScoreInfos.point = 100;
//		contributeFCScoreInfos.maxCalcNumber = 1;
//		contributeFCScoreInfos.addPoint(1, 20, 0);
//		contributeFCScoreInfos.addPoint(2, 20, 0);
//		
//		System.out.print(contributeFCScoreInfos.getFriendFCScoreInfos());
//		
//	}
}
