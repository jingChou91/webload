package com.kodgames.corgi.server.gameserver.friendcampaignrank.db;

import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.dbclient.TableChangeEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.friendcampaignrank.data.FCScoreData;

public class ContributeFCScoreInofsDB
{
	public static void replaceCurrentFCRankData(int playerId, FCScoreData fcScoreData)
	{
		DBProtocolsForServer.ContributeFCScoreInfo dbCurrentContributeFCScoreInfo = null;
		DBProtocolsForServer.ContributeFCScoreInfo dbLastContributeFCScoreInfo = null;

		if (fcScoreData.getCurrentContributeFCScoreInfos() == null)
		{
			DBProtocolsForServer.ContributeFCScoreInfo.Builder builder =
				DBProtocolsForServer.ContributeFCScoreInfo.newBuilder();
			dbCurrentContributeFCScoreInfo = builder.build();
		}
		else
		{
			dbCurrentContributeFCScoreInfo = fcScoreData.getCurrentContributeFCScoreInfos().toProtobuf();
		}
		
		if (fcScoreData.getLastContributeFCScoreInfos() == null)
		{
			DBProtocolsForServer.ContributeFCScoreInfo.Builder builder =
				DBProtocolsForServer.ContributeFCScoreInfo.newBuilder();
			dbLastContributeFCScoreInfo = builder.build();
		}
		else
		{
			dbLastContributeFCScoreInfo = fcScoreData.getLastContributeFCScoreInfos().toProtobuf();
		}

		String sql =
			String.format("replace into fc_rank_info(player_id, last_contribute_fc_score_info, current_contribute_fc_score_info) values(%d, %s, %s)",
				playerId,
				ServerUtil.toHexString(dbLastContributeFCScoreInfo.toByteArray()),
				ServerUtil.toHexString(dbCurrentContributeFCScoreInfo.toByteArray()));
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(TableChangeEvent.getKey(playerId,
			TableChangeEvent.FCRANK_REPLACE_ONE), playerId, sql);
	}

}
