package com.kodgames.corgi.server.gameserver.friendcampaignrank.logic;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols.FCPointInfo;
import com.kodgames.corgi.protocol.DBProtocolsForServer.ContributeFCScoreInfo.FCScoreInfo;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryFCPointDetailReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryFCPointDetailRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_QueryFCPointDetailReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_QueryFCPointDetailReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_QueryFCPointDetailReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_QueryFCPointDetailReq request = (CG_QueryFCPointDetailReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryFCPointDetailRes.Builder builder = GC_QueryFCPointDetailRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_FC_POINT_DETAIL_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		PlayerNode playerNode = null;
		int result = ClientProtocols.E_GAME_QUERY_FC_POINT_DETAIL_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		int queryType = request.getRankType();
		//刷新排行榜
		long now = System.currentTimeMillis();
		
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_FC_POINT_DETAIL_FAILED_LOAD_PLAYER;
					break;
				}
				
				//刷新玩家内存
				playerNode.getGamePlayer().getFcScoreData().refreshContributeFCScoreInfos(now, playerNode.getGamePlayer().getVipLevel());
				
				Object[] rankDetailInfos = null ;
				rankDetailInfos = playerNode.getGamePlayer().getFcScoreData().getDetailFCInfo(playerId, queryType);
				if(rankDetailInfos == null)
				{
					result= ClientProtocols.E_GAME_QUERY_FC_POINT_DETAIL_FAILED_NO_DETAIL_INFO;
					break;
				}
				
				List<FCScoreInfo> rankInfos = (List<FCScoreInfo>) rankDetailInfos[0];
				int friendMaxCount = (int)rankDetailInfos[1];
				int totalPoint = (int) rankDetailInfos[2];
				
				builder.setFriendMaxCount(friendMaxCount);
				builder.setTotalPoint(totalPoint);
				for(int i = 0; i < rankInfos.size(); ++i)
				{
					FCPointInfo.Builder pointBuilder = FCPointInfo.newBuilder();
					FCScoreInfo rankInfo  = rankInfos.get(i);
					pointBuilder.setPoint(rankInfo.getPoint());
					pointBuilder.setStageCount(rankInfo.getLevelCounts());
					pointBuilder.setTime(rankInfo.getTime());
					int friendId = rankInfo.getPlayerId(); 
					pointBuilder.setPlayerId(friendId);
					
					PlayerNode playerNodeRecord = ServerDataGS.playerManager.getMemoryPlayerNode(friendId);
					if(playerNodeRecord != null && playerNodeRecord.getGamePlayer() != null)
					{
						pointBuilder.setPlayerName(playerNodeRecord.getGamePlayer().getFixName());
					}
					else
					{
						continue;
					}
					
					builder.addPointInfos(pointBuilder);
				}
			} while (false);

		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}
		
		ClientServerCommon.FriendCampaignConfig fcCfg =  cd.get_FriendCampaignConfig();
		builder.setDesc(fcCfg.get_FcRankRule().get_FriendCampaignDesc());
		builder.setNextRefreshTime(ServerUtil.nextRefreshTime(now, fcCfg.get_FCRankRefreshDateTime()));
		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
