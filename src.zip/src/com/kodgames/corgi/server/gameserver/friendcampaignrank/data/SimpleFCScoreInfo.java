package com.kodgames.corgi.server.gameserver.friendcampaignrank.data;


public class SimpleFCScoreInfo implements Comparable<SimpleFCScoreInfo>
{
	private int playerId; //玩家
	private int point;    //情义值
	private long time;    //通关时间, 用于排序

	public int getPlayerId() 
	{
		return playerId;
	}
	public void setPlayerId(int playerId) 
	{
		this.playerId = playerId;
	}
	public int getPoint() 
	{
		return point;
	}
	public void setPoint(int point) 
	{
		this.point = point;
	}
	public long getTime() 
	{
		return time;
	}
	public void setTime(long time) 
	{
		this.time = time;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (obj == null) 
		{
			return false ;
		}

		if (obj instanceof SimpleFCScoreInfo)
		{
			SimpleFCScoreInfo o = (SimpleFCScoreInfo) obj;
			if(o.playerId == this.playerId)
			{
				return true ;
			}
		}

		return false ;
	}

	@Override
	public int hashCode() 
	{
		return Integer.valueOf(playerId).hashCode();
	}
	
    @Override
	public int compareTo(SimpleFCScoreInfo object)
	{
		if(this.playerId == object.getPlayerId())
		{
			return 0;
		}

		if(this.point > object.getPoint())
		{
			return -1;
		}
		else if(this.point == object.getPoint() && this.time <= object.getTime())
		{
			return -1;
		}
		else
		{
			return 1;
		}
	}
}
