package com.kodgames.corgi.server.gameserver.friendcampaignrank.data;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.VipConfig;
import ClientServerCommon._FCRankType;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.server.gameserver.friendcampaignrank.util.FCRankTimeUtil;


public class FCScoreData 
{
	private ContributeFCScoreInfos lastContributeFCScoreInfos;    //玩家上次好友排行榜数据
	private ContributeFCScoreInfos currentContributeFCScoreInfos; //玩家本次好友排行榜数据

	public FCScoreData()
	{
		this.lastContributeFCScoreInfos = null;
		this.currentContributeFCScoreInfos = null;
	}

	public void setLastContributeFCScoreInfos(ContributeFCScoreInfos lastContributeFCScoreInfos) 
	{
		this.lastContributeFCScoreInfos = lastContributeFCScoreInfos;
	}

	public void setCurrentContributeFCScoreInfos(ContributeFCScoreInfos currentContributeFCScoreInfos) 
	{
		this.currentContributeFCScoreInfos = currentContributeFCScoreInfos;
	}

	public ContributeFCScoreInfos getLastContributeFCScoreInfos()
	{
		return lastContributeFCScoreInfos;
	}

	public ContributeFCScoreInfos getCurrentContributeFCScoreInfos()
	{
		return currentContributeFCScoreInfos;
	}

	/*
	 * 刷新玩家内存数据(时间变化,vip变化)
	 */
	public void refreshContributeFCScoreInfos(long now, int viplevel)
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
		if(this.currentContributeFCScoreInfos!= null)
		{
			if(!FCRankTimeUtil.inCurrentCycle(this.currentContributeFCScoreInfos.getLastGetPointTime(), now, cd.get_FriendCampaignConfig().get_FCRankRefreshDateTime()))
			{
				this.lastContributeFCScoreInfos = this.currentContributeFCScoreInfos;
				this.currentContributeFCScoreInfos = null;
			}
		}

		if (this.lastContributeFCScoreInfos != null)
		{
			if(!FCRankTimeUtil.inLastCycle(this.lastContributeFCScoreInfos.getLastGetPointTime(), now, cd.get_FriendCampaignConfig().get_FCRankRefreshDateTime()))
			{
				this.lastContributeFCScoreInfos = null;
			}
		}

		if(this.currentContributeFCScoreInfos != null)
		{
			int friendsCount = cd.get_VipConfig().GetVipLimitByVipLevel(viplevel, VipConfig._VipLimitType.MaxFriendCount);
			this.currentContributeFCScoreInfos.setMaxCalcNumber(friendsCount);
		}
	}

	/*
	 * 增加好友贡献的积分
	 */
	public void addFriendScore(int playerId, int vipLevel, int point, long getPointTime)
	{
		if(point > 0)
		{
			if(this.currentContributeFCScoreInfos == null)
			{
				int friendsCount = CfgDB.getDefautConfig().get_VipConfig().GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.MaxFriendCount);
				this.currentContributeFCScoreInfos = new ContributeFCScoreInfos();
				this.currentContributeFCScoreInfos.setMaxCalcNumber(friendsCount);
			}

			this.currentContributeFCScoreInfos.addPoint(playerId, point, getPointTime);
		}
	}

	/*
	 * 增加自己获得的积分
	 */
	public void addPlayerScore(int vipLevel, int point, long getPointTime)
	{
		if(point > 0)
		{
			if(this.currentContributeFCScoreInfos == null)
			{
				int friendsCount = CfgDB.getDefautConfig().get_VipConfig().GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.MaxFriendCount);
				this.currentContributeFCScoreInfos = new ContributeFCScoreInfos();
				this.currentContributeFCScoreInfos.setMaxCalcNumber(friendsCount);
			}

			this.currentContributeFCScoreInfos.addPoint(point, getPointTime);
		}
	}

	/*
	 * 判断玩家是否在上期具有积分
	 */
	public boolean isOnLastRank(int playerId)
	{
		if(this.lastContributeFCScoreInfos == null)
		{
			return false;
		}
		else if(this.lastContributeFCScoreInfos.getPoint() > 0 || this.lastContributeFCScoreInfos.getfCScoreInfos().size() > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/*
	 * 判断玩家是否在本期具有积分
	 */
	public boolean isOnCurrentRank(int playerId)
	{
		if(this.currentContributeFCScoreInfos == null)
		{
			return false;
		}
		else if(this.currentContributeFCScoreInfos.getPoint() > 0 || this.currentContributeFCScoreInfos.getfCScoreInfos().size() > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/*
	 * 判断玩家上周奖励是否领取
	 */
	public boolean isRewardPicked()
	{
		if(this.lastContributeFCScoreInfos != null && this.lastContributeFCScoreInfos.isHasPickReward() == true)
		{
			return true;
		}
		return false;		
	}

	/*
	 * 领取奖励
	 */
	public void pickReward()
	{
		if(this.lastContributeFCScoreInfos != null)
		{
			this.lastContributeFCScoreInfos.setHasPickReward(true);
		}
	}
	
	/*
	 * 获取玩家当前积分
	 */
	public SimpleFCScoreInfo getCurrentSimpleFCScoreInfo(int playerId)
	{
		if(this.currentContributeFCScoreInfos != null)
		{
			return this.currentContributeFCScoreInfos.getSimpleFCScoreInfo(playerId);
		}
		
		return null;
	}
	
	/*
	 * 获取玩家的积分
	 */
	public int getPoint(int playerId, int type)
	{
		if(this.currentContributeFCScoreInfos != null && type == _FCRankType.CurrentPeriod)
		{
			return this.currentContributeFCScoreInfos.getSimpleFCScoreInfo(playerId).getPoint();
		}
		else if(type == _FCRankType.LastPeriod && this.lastContributeFCScoreInfos != null)
		{
			return this.lastContributeFCScoreInfos.getSimpleFCScoreInfo(playerId).getPoint();
		}
		
		return 0;
	}
	

	/*
	 * 用于获取好友贡献积分的详细信息
	 */
	public Object[] getDetailFCInfo(int playerId, int type)
	{
		Object[] obj = new Object[3];
		if(type == _FCRankType.CurrentPeriod && this.currentContributeFCScoreInfos != null)
		{
			obj[0] = this.currentContributeFCScoreInfos.getFriendFCScoreInfos(playerId);
			obj[1] = this.currentContributeFCScoreInfos.getMaxCalcNumber();
			obj[2] = this.currentContributeFCScoreInfos.getSimpleFCScoreInfo(playerId).getPoint();
			return obj;
		}
		else if(type == _FCRankType.LastPeriod && this.lastContributeFCScoreInfos != null)
		{
			obj[0] = this.lastContributeFCScoreInfos.getFriendFCScoreInfos(playerId);
			obj[1] = this.lastContributeFCScoreInfos.getMaxCalcNumber();
			obj[2] = this.lastContributeFCScoreInfos.getSimpleFCScoreInfo(playerId).getPoint();
			return obj;
		}
		return null;
	}
}
