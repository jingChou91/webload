package com.kodgames.corgi.server.gameserver.friendcampaignrank.db;

import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.friendcampaignrank.data.FCRankMgr;

public class RowContributeFCScoreInfos 
{
	private static final Logger logger = LoggerFactory.getLogger(RowContributeFCScoreInfos.class);

	public static boolean init()
	{
		String sql = "select * from fc_rank_info";
		CachedRowSet rs = null;
		try
		{
			rs = ServerDataGS.dbCluster.getGameDBClient().executeQuery(sql);
			FCRankMgr.getInstance().init(rs);
			return true;
		}
		catch (SQLException e)
		{
			logger.error("load fc rank failed.{}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
		}		
		finally
		{
			if (rs != null)
			{
				try
				{
					rs.close();
				}
				catch (SQLException e)
				{
					logger.error("load fc rank failed.{}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
				}
			}
		}
		return false;
	}
}