package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.gameserver.illustration.data.IllustrationMgr;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;

public class GachaCanOpenObserver extends AssisstantConcreteObserver
{
	private int gachaId;
	
	public GachaCanOpenObserver(int playerId, int taskId, int gachaId)
	{
		super(playerId, taskId);
		this.gachaId = gachaId;
	}
	
	@Override
	public void execute(PlayerNode playerNode,ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		if(IllustrationMgr.checkGacha(playerNode, cd, this.gachaId))
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}
