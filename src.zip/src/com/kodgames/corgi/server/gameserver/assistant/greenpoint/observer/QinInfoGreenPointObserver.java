package com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.qininfo.data.struct.QinInfoAnswerCount;
import com.kodgames.corgi.server.gameserver.qininfo.util.QinInfoUtil;
import com.kodgames.corgi.server.gameserver.task.data.GreenPointConcreteObserver;
import com.kodgames.gamedata.player.PlayerNode;

public class QinInfoGreenPointObserver extends GreenPointConcreteObserver
{
	public QinInfoGreenPointObserver(int playerId, int greenPointId)
	{
		super(playerId, greenPointId);
	}
	
	@Override
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{	
		super.execute(playerNode, cd);
		
		QinInfoAnswerCount qinInfo = playerNode.getPlayerInfo().getQinInfoAnswerCount();
		QinInfoAnswerCount temp = new QinInfoAnswerCount(qinInfo.getAnswerCount(), qinInfo.getAnswerCountRecoverTime());
		temp.refresh(cd);
		
		if(FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.QinInfo))
		{		
			if(temp.getAnswerCount() > 0 ||         // 剩余答题次数大于0
					QinInfoUtil.greenPointReward(playerNode, cd))
			{
				this.setState(true);
				if(this.isStateChanged())
				{
					super.notifyClientGreenPoint(playerNode.getPlayerId(), true);
				}
			}
			else
			{
				this.setState(false);
				if(this.isStateChanged())
				{
					super.notifyClientGreenPoint(playerNode.getPlayerId(), false);
				}
			}
		}
	}

}