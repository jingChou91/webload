package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.Energy;
import com.kodgames.gamedata.player.PlayerNode;

/*
 * 1.玩家精力≥1。
 */
public class MarvellousAdventureNotJoinObserver extends AssisstantConcreteObserver
{

	public MarvellousAdventureNotJoinObserver(int playerId,int taskId)
	{
		super(playerId, taskId);
	}

	@Override
	public void execute(PlayerNode playerNode,ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		Energy energy = playerNode.getGamePlayer().getEnergy();
		Energy energyTemp =	new Energy(energy.getEnergy(), energy.getEnergyLastIntervalTime());
		energyTemp.refresh(cd);
		energyTemp.getEnergy();
		
		if(energyTemp.getEnergy() >= 1  //  玩家精力≥1
			&& FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.MarvellousAdventure))
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}
