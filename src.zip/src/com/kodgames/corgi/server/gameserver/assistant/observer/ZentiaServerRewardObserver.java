package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.corgi.server.gameserver.zentia.util.ZentiaUtil;
import com.kodgames.gamedata.player.PlayerNode;

public class ZentiaServerRewardObserver extends AssisstantConcreteObserver
{
	public ZentiaServerRewardObserver(int playerId, int taskId)
	{
		super(playerId, taskId);
	}
	
	@Override
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		if(ZentiaUtil.isFunctionOpen(cd)	// 东海寻仙总开关开启
			&& ZentiaUtil.hasServerRewardNotGet(cd, playerNode))	// 玩家是否有未领取的已激活的全服奖励(不管个人累计仙缘是否达到要求)
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}