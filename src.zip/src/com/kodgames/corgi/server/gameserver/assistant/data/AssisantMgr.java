package com.kodgames.corgi.server.gameserver.assistant.data;

import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryNotifyRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.gameserver.ServerDataGS;

public class AssisantMgr
{
	public static void notifyAssisantCount(int playerId, int num)
	{
		GC_QueryNotifyRes.Builder builder = GC_QueryNotifyRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_NOTIFY_RES);
		int result = ClientProtocols.E_GAME_QUERY_NOTIFY_SUCCESS;
		builder.setAssisantNum(num);
		builder.setResult(result);
		builder.setCallback(0);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(playerId, protocol);
	}
}
