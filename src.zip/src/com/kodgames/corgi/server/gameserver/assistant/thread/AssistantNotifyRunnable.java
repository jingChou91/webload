package com.kodgames.corgi.server.gameserver.assistant.thread;

import java.util.concurrent.ConcurrentSkipListSet;

import com.kodgames.corgi.server.common.LoopRunnable;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.assistant.data.AssisantMgr;
import com.kodgames.corgi.server.gameserver.assistant.data.ObserverMgr;
import com.kodgames.gamedata.player.PlayerNode;

public class AssistantNotifyRunnable extends LoopRunnable
{
	private static final int FIVE_SECOND = 5000;

	public AssistantNotifyRunnable()
	{
		super(FIVE_SECOND);
	}

	@Override
	public void execute()
	{
		ConcurrentSkipListSet<Integer> onlinePlayerIds = ServerDataGS.playerManager.getOnlinePlayerIdsClone();
		for (Integer playerId : onlinePlayerIds)
		{
			PlayerNode playerNode = ServerDataGS.playerManager.getMemoryPlayerNode(playerId);
			if (playerNode != null && playerNode.getPlayerInfo() != null)
			{
				int num = ObserverMgr.getInstance().getActiveObserverNum(playerNode);
				if (num != playerNode.getPlayerInfo().getAssisantData().getLastNotifyCount())
				{
					playerNode.getPlayerInfo().getAssisantData().setLastNotifyCount(num);
					AssisantMgr.notifyAssisantCount(playerId, num);
				}
			}
		}
	}
}
