package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.guild.data.GuildMgr;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.baseinfo.BaseInfoConfigMgr;
import com.kodgames.gamedata.player.PlayerNode;

public class GuildMoveCountObserver extends AssisstantConcreteObserver
{
	public GuildMoveCountObserver(int playerId, int taskId)
	{
		super(playerId, taskId);
	}
	
	@Override
	// 门派关卡行动力有剩余（即行动力>0）时推送
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		if(FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Guild)	// 门派功能开关开启
			&& BaseInfoConfigMgr.getInstance().getCfg().isShowGuild()									// 门派可见
			&& GuildMgr.getInstance().getGuildByPlayerId(playerNode.getPlayerId()) != null				// 玩家在门派中
			&& playerNode.getPlayerInfo().getConsumableData().getConsumableAmount(cd.get_GuildStageConfig().get_BaseInfos().get_ExploreCostId()) > 0)	// 行动力有剩余														// 行动力有剩余
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}