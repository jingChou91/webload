package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;

/*
 * 1.玩家等级≥好友副本开启等级。  
 * 2.好友副本系统开放中
 * 3.玩家没有报名参战时
 */
public class FriendCampaignNotJoinObserver extends AssisstantConcreteObserver
{

	public FriendCampaignNotJoinObserver(int playerId, int taskId)
	{
		super(playerId, taskId);
	}

	@Override
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{
		super.execute(playerNode, cd);

		if (!playerNode.getPlayerInfo().getFriendCampaignData().isJoin() // 玩家没有参战
			&& FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.FriendCampaign))
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}
