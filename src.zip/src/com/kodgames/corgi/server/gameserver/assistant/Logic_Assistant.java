package com.kodgames.corgi.server.gameserver.assistant;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.assistant.logic.CG_QueryTaskListReqHandler;
import com.kodgames.corgi.server.gameserver.assistant.logic.CG_TaskConditionReqHandler;

public class Logic_Assistant 
{
	private CG_QueryTaskListReqHandler cg_QueryTaskListReqHandler = null;
	private CG_TaskConditionReqHandler cg_TaskConditionReqHandler = null;
	
	public void init() 
	{
		cg_QueryTaskListReqHandler = new CG_QueryTaskListReqHandler();
		cg_TaskConditionReqHandler = new CG_TaskConditionReqHandler();
	}

	public void registerProtoBufType(Controller controller) 
	{
        controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_TASK_LIST_REQ, GameProtocolsForClient.CG_QueryTaskListReq.getDefaultInstance()); 
        controller.registerMessageLite(ClientProtocols.P_GAME_CG_TASK_CONDITION_REQ, GameProtocolsForClient.CG_TaskConditionReq.getDefaultInstance()); 
	}

	public void registerMessageHandler(Controller controller) 
	{
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_TASK_LIST_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryTaskListReqHandler ));
		controller.addHandler(ClientProtocols.P_GAME_CG_TASK_CONDITION_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_TaskConditionReqHandler ));
	}
}
