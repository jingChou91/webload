package com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.gameserver.task.data.GreenPointConcreteObserver;
import com.kodgames.corgi.server.gameserver.zentia.util.ZentiaUtil;
import com.kodgames.gamedata.player.PlayerNode;

public class ZentiaServerRewardGreenPointObserver extends GreenPointConcreteObserver
{
	public ZentiaServerRewardGreenPointObserver(int playerId, int greenPointId)
	{
		super(playerId, greenPointId);
	}
	
	@Override
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{	
		super.execute(playerNode, cd);
		
		if(ZentiaUtil.isFunctionOpen(cd))// 东海寻仙总开关开启
		{		
			if(ZentiaUtil.hasServerRewardCanGet(cd, playerNode))	// 玩家有达到条件的且未领取的全服奖励
			{
				this.setState(true);
				if(this.isStateChanged())
				{
					super.notifyClientGreenPoint(playerNode.getPlayerId(), true);
				}
			}
			else
			{
				this.setState(false);
				if(this.isStateChanged())
				{
					super.notifyClientGreenPoint(playerNode.getPlayerId(), false);
				}
			}
		}
	}

}