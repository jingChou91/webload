package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.gameserver.startserverreward.data.StartServerRewardMgr;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;

public class CreatAccountRewardObserver extends AssisstantConcreteObserver
{

	public CreatAccountRewardObserver(int playerId, int taskId)
	{
		super(playerId, taskId);
	}
	
	@Override
	public void execute(PlayerNode playerNode,ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		int startRewardId = StartServerRewardMgr.getStartRewardId(playerNode, cd);
		if(startRewardId != 0 )
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}

}
