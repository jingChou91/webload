package com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.levelreward.data.LevelRewardMgr;
import com.kodgames.corgi.server.gameserver.task.data.GreenPointConcreteObserver;
import com.kodgames.gamedata.player.PlayerNode;

public class LevelRewardActivityGreenPointObserver extends GreenPointConcreteObserver
{
	public LevelRewardActivityGreenPointObserver(int playerId, int greenPointId)
	{
		super(playerId, greenPointId);
	}

	@Override
	public void execute(PlayerNode playerNode,ConfigDatabase cd)
	{	
		super.execute(playerNode, cd);
		
		if(FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.LevelRewardActivity))
		{
			if(LevelRewardMgr.getCanGetLevelRewardId(playerNode, cd) != 0)	
			{
				this.setState(true);
				if(this.isStateChanged())
				{
					super.notifyClientGreenPoint(playerNode.getPlayerId(), true);
				}
			}
			else
			{
				this.setState(false);
				if(this.isStateChanged())
				{
					super.notifyClientGreenPoint(playerNode.getPlayerId(), false);
				}
			}
		}
	}

}
