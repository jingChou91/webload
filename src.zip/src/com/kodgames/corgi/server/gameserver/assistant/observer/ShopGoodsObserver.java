package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.goods.data.BuyAndUseManager;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;

public class ShopGoodsObserver extends AssisstantConcreteObserver
{
	private int groupId;
	public ShopGoodsObserver(int playerId, int taskId, int groupId)
	{
		super(playerId, taskId);
		this.groupId = groupId;
	}

	@Override
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{
		super.execute(playerNode, cd);

		if (BuyAndUseManager.minLevelGoodsCanBuy(playerNode, cd, this.groupId) != BuyAndUseManager.NO_GOODS_CAN_BUY
			&& FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.GoodsShop))
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}
