package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.dungeon.util.DungeonAssistantUtil;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.Stamina;

public class DungeonNotAchiveObserver extends AssisstantConcreteObserver
{
	private int dungeonDiffity;
	public DungeonNotAchiveObserver(int playerId, int taskId, int dungeonDiffity)
	{
		super(playerId, taskId);
		this.dungeonDiffity = dungeonDiffity;
	}
	
	@Override
	public void execute(PlayerNode playerNode,ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		Stamina stamina = playerNode.getGamePlayer().getStamina();
		Stamina temp = new Stamina(stamina.getStamina(), stamina.getLastIntervalTime());
		temp.setBuyStaminaCount(stamina.getBuyStaminaCount());
		temp.setBuyStaminaCountLastResetTime(stamina.getBuyStaminaCountLastResetTime());
		temp.refresh(cd, playerNode.getGamePlayer().getVipLevel());
		
		int dungeonId = DungeonAssistantUtil.getMaxCanCombatDungeonId(playerNode, temp.getStamina(), this.dungeonDiffity);
		if(dungeonId != 0 && FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Dungeon))
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}

}
