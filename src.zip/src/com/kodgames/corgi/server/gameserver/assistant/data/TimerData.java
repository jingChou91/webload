package com.kodgames.corgi.server.gameserver.assistant.data;

import java.util.ArrayList;
import java.util.HashMap;

import com.kodgames.corgi.server.gameserver.qininfo.data.struct.QinInfoAnswerCount;
import com.kodgames.corgi.server.gameserver.task.timer.TimerSubject;
import com.kodgames.corgi.server.gameserver.tavern.data.Tavern;
import com.kodgames.gamedata.player.Energy;
import com.kodgames.gamedata.player.Stamina;

public class TimerData
{
	private TimerSubject staminaTimer;
	private HashMap<Integer, TimerSubject> tavernFreeTimerMap;// key为tavernId
	private TimerSubject qinInfoTimer;
	private TimerSubject energyTimer;
	private ArrayList<TimerSubject> delayRewardTimers;	//marvellous delayReward

	public void setStaminaTimer(TimerSubject staminaTimer)
	{
		this.staminaTimer = staminaTimer;
	}

	public TimerSubject getStaminaTimer()
	{
		return staminaTimer;
	}

	public HashMap<Integer, TimerSubject> getTavernFreeTimerMap()
	{
		return tavernFreeTimerMap;
	}

	public void setTavernFreeTimerMap(HashMap<Integer, TimerSubject> tavernFreeTimerMap)
	{
		this.tavernFreeTimerMap = tavernFreeTimerMap;
	}

	public TimerSubject getQinInfoTimer()
	{
		return qinInfoTimer;
	}

	public void setQinInfoTimer(TimerSubject qinInfoTimer)
	{
		this.qinInfoTimer = qinInfoTimer;
	}
	
	public TimerSubject getEnergyTimer()
	{
		return energyTimer;
	}

	public void setEnergyTimer(TimerSubject energyTimer)
	{
		this.energyTimer = energyTimer;
	}
	
	public ArrayList<TimerSubject> getDelayRewardTimers()
	{
		return delayRewardTimers;
	}

	public void setDelayRewardTimers(ArrayList<TimerSubject> delayRewardTimers)
	{
		this.delayRewardTimers = delayRewardTimers;
	}

	public void refreshTavernFree(HashMap<Integer, Tavern> taverns)
	{
		for (Tavern tavern : taverns.values())
		{
			if (this.tavernFreeTimerMap.containsKey(tavern.getTavernId()))
			{
				this.tavernFreeTimerMap.get(tavern.getTavernId()).setLastScheDuleTime(tavern.getLastFreeTavernTime());
			}
		}
	}
	
//	public void refreshMarvellousDelayReward(List<DelayReward> delayRewards)
//	{
//		for (int i = 0; i < delayRewards.size() && i < this.delayRewardTimers.size(); i++)
//		{
//			this.delayRewardTimers.get(i).setLastScheDuleTime(delayRewards.get(i).getGainRewardTime());
//		}
//	}
	
	public void refreshStamina(Stamina stamina)
	{
		this.staminaTimer.setLastScheDuleTime(stamina.getLastIntervalTime());
	}

	public void refreshQinInfo(QinInfoAnswerCount qinInfo)
	{
		this.qinInfoTimer.setLastScheDuleTime(qinInfo.getAnswerCountRecoverTime());
	}
	
	public void refreshEnergy(Energy energy)
	{
		this.qinInfoTimer.setLastScheDuleTime(energy.getEnergyLastIntervalTime());
	}

	public void notifyActiveObservers(long now)
	{
		if (this.staminaTimer != null)
		{
			if (this.staminaTimer.isActive(now))
			{
				this.staminaTimer.notifyObservers();
			}
		}

		if (this.tavernFreeTimerMap != null)
		{
			for (TimerSubject tavernFreeTimer : this.tavernFreeTimerMap.values())
			{
				if (tavernFreeTimer.isActive(now))
				{
					tavernFreeTimer.notifyObservers();
					break;
				}
			}
		}
		
		if (this.qinInfoTimer != null)
		{
			if (this.qinInfoTimer.isActive(now))
			{
				this.qinInfoTimer.notifyObservers();
			}
		}
		
		if (this.energyTimer != null)
		{
			if (this.energyTimer.isActive(now))
			{
				this.energyTimer.notifyObservers();
			}
		}
		
		if (this.delayRewardTimers != null)
		{
			for (TimerSubject delayRewardTimer : this.delayRewardTimers)
			{
				if (delayRewardTimer.isActive(now))
				{
					delayRewardTimer.notifyObservers();
					break;
				}
			}
		}
	}
}
