package com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.gameserver.activity.operationactivty.data.OperationActivityMgr;
import com.kodgames.corgi.server.gameserver.task.data.GreenPointConcreteObserver;
import com.kodgames.gamedata.player.PlayerNode;

public class AccumulateActivityGreenPointObserver extends GreenPointConcreteObserver
{
	public AccumulateActivityGreenPointObserver(int playerId, int greenPointId)
	{
		super(playerId,greenPointId);
	}
	
	@Override
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{	
		super.execute(playerNode, cd);
		
//		if(FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.a))
//		{		
			if(OperationActivityMgr.getInstance().isCanGetAnyAccumulateReward(playerNode, cd))		// 有可奖励可领取
			{
				this.setState(true);
				if(this.isStateChanged())
				{
					super.notifyClientGreenPoint(playerNode.getPlayerId(), true);
				}
			}
			else
			{
				this.setState(false);
				if(this.isStateChanged())
				{
					super.notifyClientGreenPoint(playerNode.getPlayerId(), false);
				}
			}
		}
//	}

}