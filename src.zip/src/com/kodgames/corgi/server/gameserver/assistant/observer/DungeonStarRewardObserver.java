package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._DungeonDifficulity;

import com.kodgames.corgi.server.gameserver.dungeon.util.DungeonAssistantUtil;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;

public class DungeonStarRewardObserver extends AssisstantConcreteObserver
{

	public DungeonStarRewardObserver(int playerId, int taskId)
	{
		super(playerId, taskId);
	}

	@Override
	public void execute(PlayerNode playerNode,ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		int zoneId1 = DungeonAssistantUtil.getZoneIdForPickBox(playerNode, _DungeonDifficulity.Common);
		int zoneId2 = DungeonAssistantUtil.getZoneIdForPickBox(playerNode, _DungeonDifficulity.Hard);
		int zoneId3 = DungeonAssistantUtil.getZoneIdForPickBox(playerNode, _DungeonDifficulity.Nightmare);		
		if(zoneId1 !=0 || zoneId2 != 0 || zoneId3 != 0)
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}
