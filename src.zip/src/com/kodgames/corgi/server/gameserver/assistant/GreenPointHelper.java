package com.kodgames.corgi.server.gameserver.assistant;

import java.util.ArrayList;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.GreenPointType;

import com.kodgames.corgi.protocol.CommonProtocols.State;
import com.kodgames.corgi.server.gameserver.assistant.data.ObserverMgr;
import com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer.AccumulateActivityGreenPointObserver;
import com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer.FixedTimeActivityGreenPointObserver;
import com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer.GuildConstructionGreenPointObserver;
import com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer.InvitecodeGreenPointObserver;
import com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer.LevelRewardActivityGreenPointObserver;
import com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer.MonthCardFeedBackGreenPointObserver;
import com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer.MysteryerGreenPointObserver;
import com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer.QinInfoGreenPointObserver;
import com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer.SevenElevenGiftGreenPointObserver;
import com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer.ZentiaServerRewardGreenPointObserver;
import com.kodgames.corgi.server.gameserver.task.data.GreenPointConcreteObserver;
import com.kodgames.gamedata.player.PlayerNode;

public class GreenPointHelper
{
	// 初始化PlayerTimer 初始化Observer
	public static void initPlayerGreenPoint(PlayerNode playerNode, ConfigDatabase cd)
	{
		addQinInfo(playerNode, cd, GreenPointType.QinInfo);
		addLevelRewardActivity(playerNode, cd, GreenPointType.LevelRewardActivity);
		addFixedTimeActivity(playerNode, cd, GreenPointType.FixedTimeActivity);
		addMonthCardActivity(playerNode, cd, GreenPointType.MonthCardFeedBack);
		addAccumulateActivity(playerNode, cd, GreenPointType.RunActivityAccumulative);
		addMysteryerActivity(playerNode, cd, GreenPointType.MySteryer);
		addInvitecodeServer(playerNode, cd, GreenPointType.InviteCodeReward);
		addSevenElevenGift(playerNode, cd, GreenPointType.SEVENELEVENGIFT);		
		addZentiaServerRewardActivity(playerNode, cd, GreenPointType.ZentiaServerReward);
		addGuildConstruction(playerNode, cd, GreenPointType.GuildConstruction);
	}

	// 获取小绿点状态
	public static ArrayList<State> getGreenPointStates(PlayerNode playerNode)
	{
		ArrayList<State> states = new ArrayList<>();
		states.add(generateState(playerNode, GreenPointType.QinInfo));
		states.add(generateState(playerNode, GreenPointType.LevelRewardActivity));
		states.add(generateState(playerNode, GreenPointType.FixedTimeActivity));
		states.add(generateState(playerNode, GreenPointType.MonthCardFeedBack));
		states.add(generateState(playerNode, GreenPointType.RunActivityAccumulative));
		states.add(generateState(playerNode, GreenPointType.MySteryer));
		states.add(generateState(playerNode, GreenPointType.InviteCodeReward));
		states.add(generateState(playerNode, GreenPointType.SEVENELEVENGIFT));		
		states.add(generateState(playerNode, GreenPointType.ZentiaServerReward));
		states.add(generateState(playerNode, GreenPointType.GuildConstruction));
		return states;
	}
	
	private static State generateState(PlayerNode playerNode, int greenPointType)
	{
		State.Builder builder = State.newBuilder();
		GreenPointConcreteObserver observer = (GreenPointConcreteObserver)ObserverMgr.getInstance().getObserver(playerNode.getPlayerId(), greenPointType);
		builder.setId(greenPointType);
		builder.setIsOpen(observer != null ? observer.isCurrentObserverState() : false);
		return builder.build();
	}
	
	// 秦时百科小绿点
	public static void addQinInfo(PlayerNode playerNode, ConfigDatabase cd, int greenPointId)
	{
		QinInfoGreenPointObserver observer = new QinInfoGreenPointObserver(playerNode.getPlayerId(), greenPointId);
		observer.execute(playerNode, cd);
		
		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);
		
		// addPlayerTimer
		playerNode.getPlayerInfo().getAssisantData().getTimerData().getQinInfoTimer().registerObserver(observer);
		
		playerNode.getPlayerInfo().getAssisantData().getQinInfo().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
	}
	
	// 客栈小绿点(活动开关，奖励领取)
	public static void addFixedTimeActivity(PlayerNode playerNode, ConfigDatabase cd, int greenPointId)
	{
		FixedTimeActivityGreenPointObserver observer = new FixedTimeActivityGreenPointObserver(playerNode.getPlayerId(), greenPointId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getFixTime().registerObserver(observer);
	}
	
	// 等级奖励小绿点
	public static void addLevelRewardActivity(PlayerNode playerNode, ConfigDatabase cd, int greenPointId)
	{
		LevelRewardActivityGreenPointObserver observer = new LevelRewardActivityGreenPointObserver(playerNode.getPlayerId(), greenPointId);
		observer.execute(playerNode, cd);
		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);
		
		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getLevelReward().registerObserver(observer);
	   
	}
	
	// 月卡小绿点
	public static void addMonthCardActivity(PlayerNode playerNode, ConfigDatabase cd, int greenPointId)
	{
		MonthCardFeedBackGreenPointObserver observer = new MonthCardFeedBackGreenPointObserver(playerNode.getPlayerId(), greenPointId);
		observer.execute(playerNode, cd);
		
		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);
		
		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getMonthCard().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
	}
	
	// 累计充值小绿点
	public static void addAccumulateActivity(PlayerNode playerNode, ConfigDatabase cd, int greenPointId)
	{
		AccumulateActivityGreenPointObserver observer = new AccumulateActivityGreenPointObserver(playerNode.getPlayerId(), greenPointId);
		observer.execute(playerNode, cd);
		
		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);
		
		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getAccumulateActivity().registerObserver(observer);
	}
	
	// 酒馆神秘商人小绿点
	public static void addMysteryerActivity(PlayerNode playerNode, ConfigDatabase cd, int greenPointId)
	{
		MysteryerGreenPointObserver observer = new MysteryerGreenPointObserver(playerNode.getPlayerId(), greenPointId);
		observer.execute(playerNode, cd);
		
		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);
		
		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getMysteryer().registerObserver(observer);
	}
	
	// 东海寻仙全服奖励小绿点
	public static void addZentiaServerRewardActivity(PlayerNode playerNode, ConfigDatabase cd, int greenPointId)
	{
		ZentiaServerRewardGreenPointObserver observer = new ZentiaServerRewardGreenPointObserver(playerNode.getPlayerId(), greenPointId);
		observer.execute(playerNode, cd);
		
		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);
		
		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getZentiaSystem().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getZentia().registerObserver(observer);
	}
	
	// 门派建设小绿点
	public static void addGuildConstruction(PlayerNode playerNode, ConfigDatabase cd, int greenPointId)
	{
		GuildConstructionGreenPointObserver observer = new GuildConstructionGreenPointObserver(playerNode.getPlayerId(), greenPointId);
	    observer.execute(playerNode, cd);
		
	    ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);
	
	    //addObserver
	    playerNode.getPlayerInfo().getAssisantData().getGuildConstruction().registerObserver(observer);
	}
	// 邀请码
	public static void addInvitecodeServer(PlayerNode playerNode,ConfigDatabase cd,int greenPointId)
	{
		InvitecodeGreenPointObserver observer = new InvitecodeGreenPointObserver(playerNode.getPlayerId(), greenPointId);
		observer.execute(playerNode, cd);
		
		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);
		
		playerNode.getPlayerInfo().getAssisantData().getInviteCode().registerObserver(observer);
	}
	
	// 711礼包
	public static void addSevenElevenGift(PlayerNode playerNode,ConfigDatabase cd,int greenPointId)
	{
		SevenElevenGiftGreenPointObserver observer = new SevenElevenGiftGreenPointObserver(playerNode.getPlayerId(), greenPointId);
		observer.execute(playerNode, cd);
		
		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);
		
		playerNode.getPlayerInfo().getAssisantData().getSevenElevenGift().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
	}


}
