package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.corgi.server.gameserver.wolfsmoke.util.WolfSmokeUtil;
import com.kodgames.gamedata.player.PlayerNode;

/*
 * 1.玩家等级>=烽火狼烟开启等级。  
 * 2.烽火狼烟系统开放中。
 * 3.玩家在烽火狼烟没有阵容记录。
 */
public class WolfSmokeChallengeNotJoinObserver extends AssisstantConcreteObserver
{

	public WolfSmokeChallengeNotJoinObserver(int playerId, int taskId)
	{
		super(playerId, taskId);
	}

	@Override
	public void execute(PlayerNode playerNode,ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
				
		if(!playerNode.getPlayerInfo().getWolfSmokeData().isJoin() // 玩家没有参战 
			&& WolfSmokeUtil.satisfyOpenLimit(cd, playerNode) == 0)
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}
