package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.activity.fixtime.data.PlayerFixedTimeActivityManager;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.Stamina;

public class BuyStaminaObserver extends AssisstantConcreteObserver
{
	public BuyStaminaObserver(int playerId, int taskId)
	{
		super(playerId, taskId);
	}
	
	@Override
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		Stamina stamina = playerNode.getGamePlayer().getStamina();
		Stamina temp = new Stamina(stamina.getStamina(), stamina.getLastIntervalTime());
		temp.setBuyStaminaCount(stamina.getBuyStaminaCount());
		temp.setBuyStaminaCountLastResetTime(stamina.getBuyStaminaCountLastResetTime());
		temp.refresh(cd, playerNode.getGamePlayer().getVipLevel());
		
		if(stamina.getStamina() < 6 &&  // 体力值不够挑战任一历练
           temp.canBuyStamina(cd, playerNode.getGamePlayer().getVipLevel()) &&         // 道具使用次数没有超过限制
		   (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.FixedTimeActivity) || 
		    !PlayerFixedTimeActivityManager.isCanGetRewad(playerNode)))             // 客栈未开启或者不能获得奖励
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}