package com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._ActivityType;

import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityMgr;
import com.kodgames.corgi.server.gameserver.sevenelevengifts.data.SevenElevenGiftMgr;
import com.kodgames.corgi.server.gameserver.task.data.GreenPointConcreteObserver;
import com.kodgames.gamedata.player.PlayerNode;

public class SevenElevenGiftGreenPointObserver extends GreenPointConcreteObserver
{
	public SevenElevenGiftGreenPointObserver(int playerId, int greenPointId)
	{
		super(playerId, greenPointId);
	}

	/**
	 * 1.可领取奖励或可激活随机数 2.活动开启时间段内
	 */
	@Override
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{
		super.execute(playerNode, cd);

		int activityId = cd.get_SevenElevenGiftConfig().get_ActivityId();
		if (ActivityMgr.getInstance().checkIsStart(_ActivityType.SEVENELEVENGIFT, activityId, playerNode) // 活动开启
			&& SevenElevenGiftMgr.canActiveOrGetReward(playerNode, cd)) // 可领取奖励或可激活随机数
		{
			this.setState(true);
			if (this.isStateChanged())
			{
				super.notifyClientGreenPoint(playerNode.getPlayerId(), true);
			}
		}
		else
		{
			this.setState(false);
			if (this.isStateChanged())
			{
				super.notifyClientGreenPoint(playerNode.getPlayerId(), false);
			}
		}
	}
}
