package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.melaleucaFloor.data.MelaleucaMgr;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;

public class MelaleucaDailyPassObserver extends AssisstantConcreteObserver
{

	public MelaleucaDailyPassObserver(int playerId, int taskId)
	{
		super(playerId, taskId);
	}

	/*
	 * 千层楼每日是否挑战
	 */
	@Override
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{
		super.execute(playerNode, cd);

		// 没日首次挑战获胜就推送
		if (!MelaleucaMgr.isDailyFirstPass(playerNode, cd) && FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.MelaleucaFloor))
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}

	}

}
