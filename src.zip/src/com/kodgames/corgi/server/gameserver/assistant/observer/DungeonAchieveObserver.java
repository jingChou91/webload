package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.dungeon.util.DungeonAssistantUtil;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.Stamina;

public class DungeonAchieveObserver extends AssisstantConcreteObserver
{
	public DungeonAchieveObserver(int playerId, int taskId)
	{
		super(playerId, taskId);
	}

	@Override
	public void execute(PlayerNode playerNode,ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		Stamina stamina = playerNode.getGamePlayer().getStamina();
		Stamina temp = new Stamina(stamina.getStamina(), stamina.getLastIntervalTime());
		temp.setBuyStaminaCount(stamina.getBuyStaminaCount());
		temp.setBuyStaminaCountLastResetTime(stamina.getBuyStaminaCountLastResetTime());
		temp.refresh(cd, playerNode.getGamePlayer().getVipLevel());
		
		if(DungeonAssistantUtil.canCombatEveryDungeon(playerNode, temp.getStamina()) && FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Dungeon))
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
		
	}
}
