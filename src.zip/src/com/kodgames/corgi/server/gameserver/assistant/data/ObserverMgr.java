package com.kodgames.corgi.server.gameserver.assistant.data;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.TaskConfig;
import ClientServerCommon.TaskConfig._TaskType;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.GreenPointConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.IObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverExStatus;
import com.kodgames.gamedata.player.PlayerNode;

public class ObserverMgr
{
	private static ObserverMgr instance = new ObserverMgr();
	private static final Logger logger = LoggerFactory.getLogger(ObserverMgr.class);
	
	private ObserverMgr(){}
	public static ObserverMgr getInstance(){return instance;}
	
	private ConcurrentHashMap<Integer, ConcurrentHashMap<Integer,IObserver>> observers = new ConcurrentHashMap<>();
	
	private ObserverExStatus zentiaServerRewardStatus = ObserverExStatus.STATUS_ONE;	// 启服是默认为状态一
	
	/*
	 * 小助手使用该方法添加observer
	 */
	public synchronized void addObserver(int playerId, AssisstantConcreteObserver observer)
	{
		if(this.observers.containsKey(playerId))
		{
			this.observers.get(playerId).put(observer.getTaskId(), observer);
		}
		else
		{
			ConcurrentHashMap<Integer,IObserver> temp = new ConcurrentHashMap<>();
			temp.put(observer.getTaskId(), observer);
			this.observers.put(playerId, temp);
		}
	}
	
	/*
	 * 小绿点使用该方法添加observer
	 */
	public synchronized void addObserver(int playerId, GreenPointConcreteObserver observer)
	{
		if(this.observers.containsKey(playerId))
		{
			this.observers.get(playerId).put(observer.getGreenPointId(), observer);
		}
		else
		{
			ConcurrentHashMap<Integer,IObserver> temp = new ConcurrentHashMap<>();
			temp.put(observer.getGreenPointId(), observer);
			this.observers.put(playerId, temp);
		}
	}
	
	// 获取observer
	public IObserver getObserver(int playerId, int taskId)
	{
		IObserver observer = this.observers.get(playerId).get(taskId);
		return observer;
	}
	
	public void removeObserver(int playerId)
	{
		this.observers.remove(playerId);
	}
	
	public synchronized int getActiveObserverNum(PlayerNode playerNode)
	{
		int num = 0;
		ConcurrentHashMap<Integer,IObserver> temp = this.observers.get(playerNode.getPlayerId());
		if(temp != null)
		{
			ClientServerCommon.TaskConfig taskConfig = CfgDB.getDefautConfig().get_TaskConfig();
			TaskConfig.Task task = null;
			AssisantData assisantData = playerNode.getPlayerInfo().getAssisantData();
			for(IObserver observer : temp.values())
			{
				if(observer.isActive())
				{
					num++;
				}
				else	// 是否全服推送的判断
				{
					task = taskConfig.GetTaskById(observer.getTaskId());
					if (task == null)
					{
						continue;
					}
					
					switch (task.get_TaskType())
					{
						case _TaskType.ZentiaServerReward:
							if (observer.getObserverExStatus() != this.zentiaServerRewardStatus)
							{
								num++;
								observer.setObserverExStatus(this.zentiaServerRewardStatus);
								assisantData.getZentiaSystem().notifyObservers();
							}
							break;
						// 以后若有别的功能需要全服推送，去掉以下代码注释，修改则可
//						case _TaskType.xxx:
//							if (observer.getObserverExStatus() == this.xxxServerRewardStatus)
//							{
//								num++;
//								observer.setObserverExStatus(this.xxxStatus);
//								assisantData.getXXX().notifyObservers();
//							}
//							break;
							
						default:
							break;
					}
				}
			}
		}
			
		return num;
	}
	
	//每隔2s运行一次run
	public synchronized void run()
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
		ConcurrentSkipListSet<Integer> playerIds = ChangePlayerIdMgr.getInstance().getChangePlayerIds();
		for(Integer playerId : playerIds)
		{
			if(ServerDataGS.playerManager.isOnline(playerId))
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getMemoryPlayerNode(playerId);
				ConcurrentHashMap<Integer,IObserver> observers  = this.observers.get(playerId);
				for(IObserver observer : observers.values())
				{
					if(observer.isChange())
					{
						try
						{
							observer.execute(playerNode, cd);
						}
						catch (Exception e)
						{
							logger.error("Assisstant or GreenPoint excute failed \n{}", ExceptionUtils.getStackTrace(e));
						}
						
					}
				}
			}
		}
	}

	public synchronized boolean isAcitive(int playerId, int taskId)
	{
		boolean isActive = false;
		
		if(this.observers.containsKey(playerId))
		{
			IObserver observer = this.observers.get(playerId).get(taskId);
			if(observer != null)
			{
				isActive = observer.isActive();
			}
		}

		return isActive;
	}
	
	public synchronized void notifyByTaskId(int taskId)
	{
		for(Map.Entry<Integer, ConcurrentHashMap<Integer,IObserver>> entry : this.observers.entrySet())
		{
			int playerId = entry.getKey();
			if(ServerDataGS.playerManager.isOnline(playerId))
			{
				IObserver observer = entry.getValue().get(taskId);
				
				PlayerNode playerNode = ServerDataGS.playerManager.getMemoryPlayerNode(playerId);
				if(observer != null && playerNode != null && playerNode.getPlayerInfo() != null)
				{
					observer.update();
				}
			}
		}
	}
	
	public synchronized void changeZentiaServerRewardStatus()
	{
		this.zentiaServerRewardStatus =
			this.zentiaServerRewardStatus == ObserverExStatus.STATUS_ONE ? ObserverExStatus.STATUS_TWO
				: ObserverExStatus.STATUS_ONE;
	}
}