package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.marvellous.data.MarvellousMgr;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;

/*
 * 1.玩家精力≥1。
 */
public class MarvellousDelayRewardObserver extends AssisstantConcreteObserver
{

	public MarvellousDelayRewardObserver(int playerId,int taskId)
	{
		super(playerId, taskId);
	}

	@Override
	public void execute(PlayerNode playerNode,ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		if(MarvellousMgr.couldPickDelayReward(playerNode)    //  有延时奖励未领取
			&& FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.MarvellousAdventure))
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}
