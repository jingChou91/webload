package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.friendcampaign.data.FriendCampaignData;
import com.kodgames.corgi.server.gameserver.friendcampaign.util.FCHPUtil;
import com.kodgames.corgi.server.gameserver.friendcampaign.util.FCUtil;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;

/*
 * 1.玩家等级≥好友副本开启等级。  
 * 2.好友副本系统开放中。
 * 3.玩家已参战好友副本。
 * 4.好友副本中本次没有全部通关（20关未通关）。
 * 5.好友副本中玩家和好友的阵容未全部阵亡
 */
public class FriendCampaignNotAchieveObserver extends AssisstantConcreteObserver
{

	public FriendCampaignNotAchieveObserver(int playerId, int taskId)
	{
		super(playerId, taskId);
	}

	@Override
	public void execute(PlayerNode playerNode,ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		FriendCampaignData friendCampaignData = playerNode.getPlayerInfo().getFriendCampaignData();
		
		if((friendCampaignData.isJoin() 					// 玩家已参战 
			&& FCUtil.getNextStageId(cd.get_FriendCampaignConfig(), friendCampaignData.getPassStageId()) != -1 	// 本次挑战没有全部通关
			&& FCHPUtil.ckeckAllPositioinDead(playerNode)) // 阵容未全部阵亡
			&& FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.FriendCampaign))  //好友副本系统开放
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}
