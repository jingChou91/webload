package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.guild.data.GuildMgr;
import com.kodgames.corgi.server.gameserver.guildstage.util.StageUtil;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.baseinfo.BaseInfoConfigMgr;
import com.kodgames.gamedata.player.PlayerNode;

public class GuildFreeBossChallengeObserver extends AssisstantConcreteObserver
{
	public GuildFreeBossChallengeObserver(int playerId, int taskId)
	{
		super(playerId, taskId);
	}
	
	@Override
	// 门派关卡今日免费boss挑战次数有剩余（即免费boss挑战次数>0）时推送
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		if(FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Guild)	// 门派功能开关开启
			&& BaseInfoConfigMgr.getInstance().getCfg().isShowGuild()									// 门派可见
			&& GuildMgr.getInstance().getGuildByPlayerId(playerNode.getPlayerId()) != null				// 玩家在门派中
			&& StageUtil.getRemainFreeChallengeCount(cd, playerNode) > 0)								// 免费boss挑战次数有剩余
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}