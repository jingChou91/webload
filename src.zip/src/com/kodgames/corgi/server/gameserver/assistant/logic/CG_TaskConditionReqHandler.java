package com.kodgames.corgi.server.gameserver.assistant.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_TaskConditionReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_TaskConditionRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.gameserver.ServerDataGS;

public class CG_TaskConditionReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_TaskConditionReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		CG_TaskConditionReq request = (CG_TaskConditionReq) message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_TaskConditionRes.Builder builder = GC_TaskConditionRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_TASK_CONDITION_RES);
		builder.setCallback(request.getCallback());
		int result = ClientProtocols.E_GAME_TASK_CONDITION_SUCCESS;
		int playerId = sender.getClientUID().getPlayerID();
		logger.info("recv CG_TaskConditionReq , playerId = {}", playerId);

		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{


			}
			while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);

		return HandlerAction.TERMINAL;
	}
}
