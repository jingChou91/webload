package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.dungeon.util.DungeonAssistantUtil;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.Stamina;

public class SecretDungeonCanCombatObserver extends AssisstantConcreteObserver
{
	private int zoneId;
	private int easyDungeonId;
	private int commonDungeonId;
	
	public SecretDungeonCanCombatObserver(int playerId, int taskId, int zoneId, int easyDungeonId, int commonDungeonId)
	{
		super(playerId, taskId);
		this.zoneId = zoneId;
		this.easyDungeonId = easyDungeonId;
		this.commonDungeonId = commonDungeonId;
	}

	@Override
	public void execute(PlayerNode playerNode,ConfigDatabase cd)
	{
		super.execute(playerNode, cd);

		Stamina stamina = playerNode.getGamePlayer().getStamina();
		Stamina temp = new Stamina(stamina.getStamina(), stamina.getLastIntervalTime());
		temp.setBuyStaminaCount(stamina.getBuyStaminaCount());
		temp.setBuyStaminaCountLastResetTime(stamina.getBuyStaminaCountLastResetTime());
		temp.refresh(cd, playerNode.getGamePlayer().getVipLevel());

		int difficulty = DungeonAssistantUtil.getCanCombatSecretDifficulty(playerNode, temp.getStamina(), zoneId,easyDungeonId,commonDungeonId );
		if(difficulty != 0 && FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Secret))
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}
