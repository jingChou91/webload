package com.kodgames.corgi.server.gameserver.assistant.data;

import java.util.concurrent.ConcurrentSkipListSet;

public class ChangePlayerIdMgr
{
	private static ChangePlayerIdMgr instance = new ChangePlayerIdMgr();
	
	private ChangePlayerIdMgr(){}
	public static ChangePlayerIdMgr getInstance(){return instance;}
	
	//有变化的玩家ID
	private ConcurrentSkipListSet<Integer> activePlayerIds = new ConcurrentSkipListSet<>();

	public synchronized void activePlayerId(int playerId)
	{
		activePlayerIds.add(playerId);
	}
	
	public synchronized ConcurrentSkipListSet<Integer> getChangePlayerIds()
	{
		ConcurrentSkipListSet<Integer> temp = this.activePlayerIds.clone();
		this.activePlayerIds.clear();
		return temp;
	}
}
