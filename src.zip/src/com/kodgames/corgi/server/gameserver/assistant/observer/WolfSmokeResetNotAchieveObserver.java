package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.corgi.server.gameserver.wolfsmoke.data.WolfSmokeData;
import com.kodgames.corgi.server.gameserver.wolfsmoke.util.WolfSmokeUtil;
import com.kodgames.gamedata.player.PlayerNode;

/*
 * 1.玩家等级≥烽火狼烟开启等级。  
 * 2.烽火狼烟系统开放中。
 * 3.烽火狼烟没有全部通关（20关未通关）。
 * 4.烽火狼烟【重新开始次数】>= 1
 * 5.烽火狼烟中玩家的【可失败次数】＜【玩家当前可失败次数上限】
 */
public class WolfSmokeResetNotAchieveObserver extends AssisstantConcreteObserver
{

	public WolfSmokeResetNotAchieveObserver(int playerId, int taskId)
	{
		super(playerId, taskId);
	}

	@Override
	public void execute(PlayerNode playerNode,ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		WolfSmokeData wolfSmokeData = playerNode.getPlayerInfo().getWolfSmokeData();
		WolfSmokeUtil.refreshWolfSmoke(playerNode, cd.get_WolfSmokeConfig());
		if(wolfSmokeData.isJoin()   						 // 玩家已参战 
			&& wolfSmokeData.getStageId() != -1				 // 本次挑战未通关
			&& WolfSmokeUtil.hasResetTimes(cd, playerNode)   // 玩家今日可重置次数有剩余
			&& wolfSmokeData.getFailedTimes() > 0			 // 玩家可失败次数<玩家当前可失败次数上限(即玩家本次挑战失败过)
			&& WolfSmokeUtil.satisfyOpenLimit(cd, playerNode) == 0)
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}
