package com.kodgames.corgi.server.gameserver.assistant.data;

import com.kodgames.corgi.server.gameserver.task.data.ConcreteSubject;

public class AssisantData
{
	private int lastNotifyCount = 0;
	private ConcreteSubject playerLevel = new ConcreteSubject();
	private ConcreteSubject playerVipLevel = new ConcreteSubject();
	private ConcreteSubject playerStamina = new ConcreteSubject();
	private ConcreteSubject dungeonCombat = new ConcreteSubject();
	private ConcreteSubject arenaCombat = new ConcreteSubject();
	private ConcreteSubject fixTime = new ConcreteSubject();
	private ConcreteSubject gacha = new ConcreteSubject();
	private ConcreteSubject challengeTimeChange = new ConcreteSubject();
	private ConcreteSubject fragment = new ConcreteSubject();
	private ConcreteSubject createAccount = new ConcreteSubject();
	private ConcreteSubject tavernFree = new ConcreteSubject();
	private ConcreteSubject sign = new ConcreteSubject();
	private ConcreteSubject dungeonStartReward = new ConcreteSubject();
	private ConcreteSubject secretKey = new ConcreteSubject();
	private ConcreteSubject melaleucaDailyPass = new ConcreteSubject();
	private ConcreteSubject wolfSmoke = new ConcreteSubject();
	private ConcreteSubject qinInfo = new ConcreteSubject();
	private ConcreteSubject levelReward = new ConcreteSubject();
	private ConcreteSubject monthCard = new ConcreteSubject();
	private ConcreteSubject melaleucaReward = new ConcreteSubject();
	private ConcreteSubject realMoney = new ConcreteSubject(); // 元宝
	private ConcreteSubject shop = new ConcreteSubject(); // 商店初始化商品
	private ConcreteSubject accumulateActivity = new ConcreteSubject(); // 累计充值
	private ConcreteSubject friendCampaign = new ConcreteSubject(); // 好友副本
	private ConcreteSubject marvellousAdventure = new ConcreteSubject(); // 奇遇
	private ConcreteSubject mysteryer = new ConcreteSubject(); // 酒馆神秘商人
	private ConcreteSubject inviteCode = new ConcreteSubject(); // 邀请码
	private ConcreteSubject sevenElevenGift = new ConcreteSubject(); // 711礼包
	private ConcreteSubject zentiaSystem = new ConcreteSubject(); // 东海寻仙系统
	private ConcreteSubject zentia = new ConcreteSubject(); // 仙缘
	private ConcreteSubject danHome = new ConcreteSubject(); // 丹房
	private ConcreteSubject guildStage = new ConcreteSubject(); // 门派关卡系统
	private ConcreteSubject guildMoveCount = new ConcreteSubject(); // 门派关卡行动力
	private ConcreteSubject guildConstruction = new ConcreteSubject(); // 门派建设次数
	private ConcreteSubject beast = new ConcreteSubject(); // 机关兽系统

	private TimerData timerData = new TimerData();

	public void clearAllData()
	{
		this.lastNotifyCount = 0;
		this.playerLevel = new ConcreteSubject();
		this.playerStamina = new ConcreteSubject();
		this.playerVipLevel = new ConcreteSubject();
		this.dungeonCombat = new ConcreteSubject();
		this.arenaCombat = new ConcreteSubject();
		this.fixTime = new ConcreteSubject();
		this.gacha = new ConcreteSubject();
		this.challengeTimeChange = new ConcreteSubject();
		this.fragment = new ConcreteSubject();
		this.createAccount = new ConcreteSubject();
		this.tavernFree = new ConcreteSubject();
		this.sign = new ConcreteSubject();
		this.dungeonStartReward = new ConcreteSubject();
		this.secretKey = new ConcreteSubject();
		this.timerData = new TimerData();
		this.melaleucaDailyPass = new ConcreteSubject();
		this.wolfSmoke = new ConcreteSubject();
		this.qinInfo = new ConcreteSubject();
		this.levelReward = new ConcreteSubject();
		this.monthCard = new ConcreteSubject();
		this.melaleucaReward = new ConcreteSubject();
		this.realMoney = new ConcreteSubject();
		this.shop = new ConcreteSubject();
		this.accumulateActivity = new ConcreteSubject();
		this.friendCampaign = new ConcreteSubject();
		this.marvellousAdventure = new ConcreteSubject();
		this.mysteryer = new ConcreteSubject();
		this.inviteCode = new ConcreteSubject();
		this.sevenElevenGift = new ConcreteSubject();
		this.zentiaSystem = new ConcreteSubject();
		this.zentia = new ConcreteSubject();
		this.danHome = new ConcreteSubject();
		this.guildStage = new ConcreteSubject();
		this.guildMoveCount = new ConcreteSubject();
		this.guildConstruction = new ConcreteSubject();
		this.beast = new ConcreteSubject();
	}

	public ConcreteSubject getSevenElevenGift()
	{
		return sevenElevenGift;
	}

	public void setSevenElevenGift(ConcreteSubject sevenElevenGift)
	{
		this.sevenElevenGift = sevenElevenGift;
	}

	public ConcreteSubject getGuildStage()
	{
		return guildStage;
	}

	public void setGuildStage(ConcreteSubject guildStage)
	{
		this.guildStage = guildStage;
	}

	public ConcreteSubject getGuildMoveCount()
	{
		return guildMoveCount;
	}

	public void setGuildMoveCount(ConcreteSubject guildMoveCount)
	{
		this.guildMoveCount = guildMoveCount;
	}

	public ConcreteSubject getFriendCampaign()
	{
		return friendCampaign;
	}

	public void setFriendCampaign(ConcreteSubject friendCampaign)
	{
		this.friendCampaign = friendCampaign;
	}

	/**
	 * 获取 accumulateActivity
	 * 
	 * @return 返回 accumulateActivity
	 */
	public ConcreteSubject getAccumulateActivity()
	{
		return accumulateActivity;
	}

	/**
	 * 设置 accumulateActivity
	 * 
	 * @param 对accumulateActivity进行赋值
	 */
	public void setAccumulateActivity(ConcreteSubject accumulateActivity)
	{
		this.accumulateActivity = accumulateActivity;
	}

	/**
	 * 获取 shop
	 * 
	 * @return 返回 shop
	 */
	public ConcreteSubject getShop()
	{
		return shop;
	}

	/**
	 * 设置 shop
	 * 
	 * @param 对shop进行赋值
	 */
	public void setShop(ConcreteSubject shop)
	{
		this.shop = shop;
	}

	/**
	 * 获取 realMoney
	 * 
	 * @return 返回 realMoney
	 */
	public ConcreteSubject getRealMoney()
	{
		return realMoney;
	}

	/**
	 * 设置 realMoney
	 * 
	 * @param 对realMoney进行赋值
	 */
	public void setRealMoney(ConcreteSubject realMoney)
	{
		this.realMoney = realMoney;
	}

	/**
	 * 获取 melaleucaReward
	 * 
	 * @return 返回 melaleucaReward
	 */
	public ConcreteSubject getMelaleucaReward()
	{
		return melaleucaReward;
	}

	/**
	 * 设置 melaleucaReward
	 * 
	 * @param 对melaleucaReward进行赋值
	 */
	public void setMelaleucaReward(ConcreteSubject melaleucaReward)
	{
		this.melaleucaReward = melaleucaReward;
	}

	/**
	 * 获取 monthCard
	 * 
	 * @return 返回 monthCard
	 */
	public ConcreteSubject getMonthCard()
	{
		return monthCard;
	}

	/**
	 * 设置 monthCard
	 * 
	 * @param 对monthCard进行赋值
	 */
	public void setMonthCard(ConcreteSubject monthCard)
	{
		this.monthCard = monthCard;
	}

	/**
	 * 获取 levelUpReward
	 * 
	 * @return 返回 levelUpReward
	 */
	public ConcreteSubject getLevelReward()
	{
		return levelReward;
	}

	/**
	 * 设置 levelUpReward
	 * 
	 * @param 对levelUpReward进行赋值
	 */
	public void setLevelReward(ConcreteSubject levelReward)
	{
		this.levelReward = levelReward;
	}

	public ConcreteSubject getQinInfo()
	{
		return qinInfo;
	}

	public void setQinInfo(ConcreteSubject qinInfo)
	{
		this.qinInfo = qinInfo;
	}

	/**
	 * 获取 wolfSmokeReset
	 * 
	 * @return 返回 wolfSmokeReset
	 */
	public ConcreteSubject getWolfSmoke()
	{
		return wolfSmoke;
	}

	/**
	 * 设置 wolfSmokeReset
	 * 
	 * @param 对wolfSmokeReset进行赋值
	 */
	public void setWolfSmoke(ConcreteSubject wolfSmokeReset)
	{
		this.wolfSmoke = wolfSmokeReset;
	}

	public ConcreteSubject getSecretKey()
	{
		return secretKey;
	}

	public void setSecretKey(ConcreteSubject secretKey)
	{
		this.secretKey = secretKey;
	}

	public ConcreteSubject getDungeonStartReward()
	{
		return dungeonStartReward;
	}

	public void setDungeonStartReward(ConcreteSubject dungeonStartReward)
	{
		this.dungeonStartReward = dungeonStartReward;
	}

	public ConcreteSubject getSign()
	{
		return sign;
	}

	public void setSign(ConcreteSubject sign)
	{
		this.sign = sign;
	}

	public ConcreteSubject getTavernFree()
	{
		return tavernFree;
	}

	public void setTavernFree(ConcreteSubject tavernFree)
	{
		this.tavernFree = tavernFree;
	}

	public ConcreteSubject getCreateAccount()
	{
		return createAccount;
	}

	public void setCreateAccount(ConcreteSubject createAccount)
	{
		this.createAccount = createAccount;
	}

	public ConcreteSubject getPlayerLevel()
	{
		return playerLevel;
	}

	public void setPlayerLevel(ConcreteSubject playerLevel)
	{
		this.playerLevel = playerLevel;
	}

	public ConcreteSubject getPlayerVipLevel()
	{
		return playerVipLevel;
	}

	public void setPlayerVipLevel(ConcreteSubject playerVipLevel)
	{
		this.playerVipLevel = playerVipLevel;
	}

	public ConcreteSubject getPlayerStamina()
	{
		return playerStamina;
	}

	public void setPlayerStamina(ConcreteSubject playerStamina)
	{
		this.playerStamina = playerStamina;
	}

	public ConcreteSubject getDungeonCombat()
	{
		return dungeonCombat;
	}

	public void setDungeonCombat(ConcreteSubject dungeonCombat)
	{
		this.dungeonCombat = dungeonCombat;
	}

	public ConcreteSubject getArenaCombat()
	{
		return arenaCombat;
	}

	public void setArenaCombat(ConcreteSubject arenaCombat)
	{
		this.arenaCombat = arenaCombat;
	}

	public TimerData getTimerData()
	{
		return timerData;
	}

	public void setTimerData(TimerData timerData)
	{
		this.timerData = timerData;
	}

	public ConcreteSubject getFixTime()
	{
		return fixTime;
	}

	public void setFixTime(ConcreteSubject fixTime)
	{
		this.fixTime = fixTime;
	}

	public ConcreteSubject getGacha()
	{
		return gacha;
	}

	public void setGacha(ConcreteSubject gacha)
	{
		this.gacha = gacha;
	}

	public int getLastNotifyCount()
	{
		return lastNotifyCount;
	}

	public void setLastNotifyCount(int lastNotifyCount)
	{
		this.lastNotifyCount = lastNotifyCount;
	}

	public ConcreteSubject getChallengeTimeChange()
	{
		return challengeTimeChange;
	}

	public void setChallengeTimeChange(ConcreteSubject challengeTimeChange)
	{
		this.challengeTimeChange = challengeTimeChange;
	}

	public ConcreteSubject getFragment()
	{
		return fragment;
	}

	public void setFragment(ConcreteSubject fragment)
	{
		this.fragment = fragment;
	}

	public ConcreteSubject getMelaleucaDailyPass()
	{
		return melaleucaDailyPass;
	}

	public void setMelaleucaDailyPass(ConcreteSubject melaleucaDailyPass)
	{
		this.melaleucaDailyPass = melaleucaDailyPass;
	}

	public ConcreteSubject getMarvellousAdventure()
	{
		return marvellousAdventure;
	}

	public void setMarvellousAdventure(ConcreteSubject marvellousAdventure)
	{
		this.marvellousAdventure = marvellousAdventure;
	}

	/**
	 * 获取 mysteryer
	 * 
	 * @return 返回 mysteryer
	 */
	public ConcreteSubject getMysteryer()
	{
		return mysteryer;
	}

	/**
	 * 设置 mysteryer
	 * 
	 * @param 对mysteryer进行赋值
	 */
	public void setMysteryer(ConcreteSubject mysteryer)
	{
		this.mysteryer = mysteryer;
	}

	public ConcreteSubject getInviteCode()
	{
		return inviteCode;
	}

	public void setInviteCode(ConcreteSubject inviteCode)
	{
		this.inviteCode = inviteCode;
	}

	public ConcreteSubject getZentiaSystem()
	{
		return zentiaSystem;
	}

	public void setZentiaSystem(ConcreteSubject zentiaSystem)
	{
		this.zentiaSystem = zentiaSystem;
	}

	public ConcreteSubject getZentia()
	{
		return zentia;
	}

	public void setZentia(ConcreteSubject zentia)
	{
		this.zentia = zentia;
	}

	public ConcreteSubject getDanHome()
	{
		return danHome;
	}

	public void setDanHome(ConcreteSubject danHome)
	{
		this.danHome = danHome;
	}

	public ConcreteSubject getGuildConstruction()
	{
		return guildConstruction;
	}

	public void setGuildConstruction(ConcreteSubject guildConstruction)
	{
		this.guildConstruction = guildConstruction;
	}

	public ConcreteSubject getBeast()
	{
		return beast;
	}

	public void setBeast(ConcreteSubject beast)
	{
		this.beast = beast;
	}
}
