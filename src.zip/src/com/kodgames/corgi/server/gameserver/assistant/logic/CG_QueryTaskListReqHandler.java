package com.kodgames.corgi.server.gameserver.assistant.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.CampaignConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.IDSeg._AssetType;
import ClientServerCommon.TaskConfig;
import ClientServerCommon.TaskConfig._ArenaShopRealMoneyAssistantValueType;
import ClientServerCommon.TaskConfig._DungeonAssistValueType;
import ClientServerCommon.TaskConfig._GachaAssistValueType;
import ClientServerCommon.TaskConfig._MonthCardAssistValueType;
import ClientServerCommon.TaskConfig._SecretAssistValueType;
import ClientServerCommon.TaskConfig._ShopGoodsAssistantValueType;
import ClientServerCommon.TaskConfig._TaskType;
import ClientServerCommon._DungeonDifficulity;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryTaskListReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryTaskListRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.arena.data.ArenaManager;
import com.kodgames.corgi.server.gameserver.assistant.data.ObserverMgr;
import com.kodgames.corgi.server.gameserver.dungeon.util.DungeonAssistantUtil;
import com.kodgames.corgi.server.gameserver.goods.data.BuyAndUseManager;
import com.kodgames.corgi.server.gameserver.illustration.data.IllustrationMgr;
import com.kodgames.corgi.server.gameserver.levelreward.data.LevelRewardMgr;
import com.kodgames.corgi.server.gameserver.monthcard.data.MonthCardManager;
import com.kodgames.corgi.server.gameserver.startserverreward.data.StartServerRewardMgr;
import com.kodgames.corgi.server.gameserver.tavern.data.TavernMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.Stamina;

public class CG_QueryTaskListReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_QueryTaskListReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		CG_QueryTaskListReq request = (CG_QueryTaskListReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryTaskListRes.Builder builder = GC_QueryTaskListRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_TASK_LIST_RES);
		builder.setCallback(request.getCallback());
		int result = ClientProtocols.E_GAME_QUERY_TASK_LIST_SUCCESS;
		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		logger.info("recv CG_QueryTaskListReq , playerId = {}", playerId);

		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				// 玩家信息
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_TASK_LIST_FAILD_GET_PLAYER_FAILED;
					break;
				}

				Stamina stamina = playerNode.getGamePlayer().getStamina();
				Stamina temp = new Stamina(stamina.getStamina(), stamina.getLastIntervalTime());
				temp.setBuyStaminaCount(stamina.getBuyStaminaCount());
				temp.setBuyStaminaCountLastResetTime(stamina.getBuyStaminaCountLastResetTime());
				temp.refresh(cd, playerNode.getGamePlayer().getVipLevel());

				ClientServerCommon.TaskConfig taskConfig = cd.get_TaskConfig();
				int num = taskConfig.Get_TasksCount();
				for (int i = 0; i < num; i++)
				{
					TaskConfig.Task taskCfg = taskConfig.Get_TasksByIndex(i);
					if (taskCfg.get_IsOpen() == true)
					{
						CommonProtocols.Task.Builder task = CommonProtocols.Task.newBuilder();
						task.setTaskId(taskCfg.get_TaskId());
						// 判断该TaskId是否激活
						if (ObserverMgr.getInstance().isAcitive(playerId, taskCfg.get_TaskId()) == false)
						{
							continue;
						}

						int type = taskCfg.get_TaskType();
						switch (type)
						{
							case _TaskType.ArenaAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.DungeonAchieveAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.DungeonCanCombatAssistant:
								int dungeonId =
									DungeonAssistantUtil.getMaxCanCombatDungeonId(playerNode,
										temp.getStamina(),
										taskCfg.GetDataValueByType(_DungeonAssistValueType.Diffity));
								CampaignConfig.Dungeon dungeonCfg = cd.get_CampaignConfig().GetDungeonById(dungeonId);
								if (dungeonCfg != null)
								{
									task.addDatas(dungeonCfg.get_ZoneId());
									task.addDatas(dungeonCfg.get_dungeonId());
									builder.addTasks(task);
								}
								break;
							case _TaskType.DungeonCombatAssistant:
								int dungeonId_ = DungeonAssistantUtil.isDungeonLittleGod(playerNode, temp.getStamina());
								CampaignConfig.Dungeon dungeonCfg_ = cd.get_CampaignConfig().GetDungeonById(dungeonId_);
								if (dungeonCfg_ != null)
								{
									task.addDatas(dungeonCfg_.get_ZoneId());
									task.addDatas(dungeonCfg_.get_dungeonId());
									builder.addTasks(task);
								}
								break;

							case _TaskType.AvatarIllustrationAssistant:
								int avatarResourceId = IllustrationMgr.checkFragment(playerNode, cd, _AssetType.Avatar);
								if (avatarResourceId != 0)
								{
									task.addDatas(avatarResourceId);
									builder.addTasks(task);
								}
								break;

							case _TaskType.EquipIllustrationAssistant:
								int equipResourceId =
									IllustrationMgr.checkFragment(playerNode, cd, _AssetType.Equipment);
								if (equipResourceId != 0)
								{
									task.addDatas(equipResourceId);
									builder.addTasks(task);
								}
								break;

							case _TaskType.SkillIllustrationAssistant:
								int skillResourceId =
									IllustrationMgr.checkFragment(playerNode, cd, _AssetType.CombatTurn);
								if (skillResourceId != 0)
								{
									task.addDatas(skillResourceId);
									builder.addTasks(task);
								}
								break;

							case _TaskType.CreateAccountRewardAssistant:
								int startRewardId = StartServerRewardMgr.getStartRewardId(playerNode, cd);
								if (startRewardId != 0)
								{
									task.addDatas(startRewardId);
									builder.addTasks(task);
								}
								break;

							case _TaskType.FixTimeRewardAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.TavernAssistant:
								int tavernId = TavernMgr.getFreeTavernBuyId(playerNode, cd);
								if (tavernId != 0)
								{
									task.addDatas(tavernId);
									builder.addTasks(task);
								}
								break;

							case _TaskType.LevelRewardAssistant:
								int levelRewardId = LevelRewardMgr.getCanGetLevelRewardId(playerNode, cd);
								if (levelRewardId != 0)
								{
									task.addDatas(levelRewardId);
									builder.addTasks(task);
								}
								break;

							case _TaskType.SecretDungeonAssistant:
								int zoneId = taskCfg.GetDataValueByType(_SecretAssistValueType.ZoneId);
								int difficulty =
									DungeonAssistantUtil.getCanCombatSecretDifficulty(playerNode,
										temp.getStamina(),
										zoneId,
										taskCfg.GetDataValueByType(_SecretAssistValueType.EasyDungeonId),
										taskCfg.GetDataValueByType(_SecretAssistValueType.CommonDungeonId));
								if (difficulty != 0)
								{
									task.addDatas(zoneId);
									task.addDatas(difficulty);
									builder.addTasks(task);
								}
								break;

							case _TaskType.DailySignAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.RemedySignAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.GachaAssistant:

								if (IllustrationMgr.checkGacha(playerNode,
									cd,
									taskCfg.GetDataValueByType(_GachaAssistValueType.GachaId)))
								{
									task.addDatas(taskCfg.GetDataValueByType(_GachaAssistValueType.GachaId));
									builder.addTasks(task);
								}
								break;

							case _TaskType.DungeonStarRewardAssistant:
								int tempZoneId = 0;
								int tempDifficulty = _DungeonDifficulity.Common;
								int zoneId1 =
									DungeonAssistantUtil.getZoneIdForPickBox(playerNode, _DungeonDifficulity.Common);
								int zoneId2 =
									DungeonAssistantUtil.getZoneIdForPickBox(playerNode, _DungeonDifficulity.Hard);
								int zoneId3 =
									DungeonAssistantUtil.getZoneIdForPickBox(playerNode, _DungeonDifficulity.Nightmare);
								tempZoneId = zoneId1;

								if (zoneId2 != 0 && (tempZoneId == 0 || tempZoneId > zoneId2))
								{
									tempZoneId = zoneId2;
									tempDifficulty = _DungeonDifficulity.Hard;
								}

								if (zoneId3 != 0 && (tempZoneId == 0 || tempZoneId > zoneId3))
								{
									tempZoneId = zoneId3;
									tempDifficulty = _DungeonDifficulity.Nightmare;
								}

								if (tempZoneId != 0)
								{
									int index =
										DungeonAssistantUtil.getIndexForPickBox(playerNode, tempDifficulty, tempZoneId);

									if (tempZoneId != 0 || index != -1)
									{
										task.addDatas(tempZoneId);
										task.addDatas(tempDifficulty);
										task.addDatas(index);
										builder.addTasks(task);
									}
								}
								break;

							case _TaskType.BuyStaminaAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.MelaleucaDailyPassAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.WolfSmokeChallengeNotJoinAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.WolfSmokeChallengeNotAchieveAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.WolfSmokeResetAchieveAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.WolfSmokeResetNotAchieveAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.QinInfoAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.MonthCardAssistant:
								if (MonthCardManager.isCanGetMonthCardReward(playerNode,
									cd,
									taskCfg.GetDataValueByType(_MonthCardAssistValueType.MonthCardId)))
								{
									task.addDatas(taskCfg.GetDataValueByType(_MonthCardAssistValueType.MonthCardId));
									builder.addTasks(task);
								}
								break;

							case _TaskType.MelaleucaWeekRankRewardAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.VipLevelGoodsAssistant:
								int vipLevelgoodsId = BuyAndUseManager.minVipLevelGoodsIdCanBuy(playerNode, cd);
								if (vipLevelgoodsId != BuyAndUseManager.NO_GOODS_CAN_BUY)
								{
									task.addDatas(vipLevelgoodsId);
									builder.addTasks(task);
								}
								break;

							case _TaskType.ArenaShopRealMoneyAssistant:
								if (ArenaManager.isRealMoneyCanBuy(playerNode,
									cd,
									taskCfg.GetDataValueByType(_ArenaShopRealMoneyAssistantValueType.GoodsId)))
								{
									task.addDatas(taskCfg.GetDataValueByType(_ArenaShopRealMoneyAssistantValueType.GoodsId));
									builder.addTasks(task);
								}
								break;

							case _TaskType.ShopGoodsAssistant:
								int shopGoodsId =
									BuyAndUseManager.minLevelGoodsCanBuy(playerNode,
										cd,
										taskCfg.GetDataValueByType(_ShopGoodsAssistantValueType.GroupId));
								if (shopGoodsId != BuyAndUseManager.NO_GOODS_CAN_BUY)
								{
									task.addDatas(shopGoodsId);
									builder.addTasks(task);
								}
								break;

							case _TaskType.FriendCampaignNotJoinAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.FriendCampaignResetAchieveAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.FriendCampaignNotAchieveAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.FriendCampaignResetAllDeadAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.MarvellousAdventureNotJoinAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.MarvellousDelayRewardAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.InviteCodeRewardAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.ZentiaGoods:
								builder.addTasks(task);
								break;

							case _TaskType.ZentiaServerReward:
								builder.addTasks(task);
								break;

							case _TaskType.DanHomeReward:
								builder.addTasks(task);
								break;

							case _TaskType.GuildMoveCountAssisstant:
								builder.addTasks(task);
								break;

							case _TaskType.GuildFreeBossChallengeAssisstant:
								builder.addTasks(task);
								break;

							case _TaskType.GuildConstructionAssisstant:
								builder.addTasks(task);
								break;

							case _TaskType.BeastActiveAssistant:
								builder.addTasks(task);
								break;

							case _TaskType.BeastBreakthoughtAssistant:
								builder.addTasks(task);
								break;

							default:
								break;
						}
					}
				}
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);

		return HandlerAction.TERMINAL;
	}
}
