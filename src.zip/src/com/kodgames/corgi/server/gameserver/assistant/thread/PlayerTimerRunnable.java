package com.kodgames.corgi.server.gameserver.assistant.thread;

import com.kodgames.corgi.server.common.LoopRunnable;
import com.kodgames.corgi.server.gameserver.task.timer.PlayerTimerMgr;

public class PlayerTimerRunnable extends LoopRunnable
{
	private static final long SIX_SECOND = 6000L;

	public PlayerTimerRunnable()
	{
		super(SIX_SECOND);
	}

	@Override
	public void execute()
	{
		PlayerTimerMgr.getInstance().execute();
	}
}
