package com.kodgames.corgi.server.gameserver.assistant.thread;

import com.kodgames.corgi.server.common.LoopRunnable;
import com.kodgames.corgi.server.gameserver.assistant.data.ObserverMgr;

public class ObserverRunnable extends LoopRunnable
{
	private static final int TWO_SECOND = 2000;

	public ObserverRunnable()
	{
		super(TWO_SECOND);
	}

	@Override
	public synchronized void execute()
	{
		ObserverMgr.getInstance().run();
	}
}
