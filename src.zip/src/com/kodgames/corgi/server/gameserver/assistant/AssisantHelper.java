package com.kodgames.corgi.server.gameserver.assistant;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.MarvellousAdventureConfig;
import ClientServerCommon.TaskConfig;
import ClientServerCommon.TaskConfig._DungeonAssistValueType;
import ClientServerCommon.TaskConfig._GachaAssistValueType;
import ClientServerCommon.TaskConfig._MonthCardAssistValueType;
import ClientServerCommon.TaskConfig._SecretAssistValueType;
import ClientServerCommon.TaskConfig._ShopGoodsAssistantValueType;
import ClientServerCommon.TaskConfig._TaskType;
import ClientServerCommon.TavernConfig;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.protocol.CommonProtocols.DelayReward;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.assistant.data.ObserverMgr;
import com.kodgames.corgi.server.gameserver.assistant.data.TimerData;
import com.kodgames.corgi.server.gameserver.assistant.observer.ArenaCombatRewardObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.AvatarIllustrationObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.BeastActiveObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.BeastBreakthoughtObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.BuyStaminaObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.CreatAccountRewardObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.DailySignObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.DanHomeRewardObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.DungeonAchieveObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.DungeonCombatObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.DungeonNotAchiveObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.DungeonStarRewardObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.EquipIllustrationObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.FixTimeRewardObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.FriendCampaignNotAchieveObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.FriendCampaignNotJoinObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.FriendCampaignResetAchieveObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.FriendCampaignResetAllDeadObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.GachaCanOpenObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.GuildConstructionObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.GuildFreeBossChallengeObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.GuildMoveCountObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.InviteCodeRewardObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.LevelRewardObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.MarvellousAdventureNotJoinObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.MarvellousDelayRewardObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.MelaleucaDailyPassObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.MelaleucaWeekRankRewardObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.MonthCardObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.QinInfoObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.RemedySignObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.SecretDungeonCanCombatObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.ShopGoodsObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.SkillIllustrationObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.TavernFreeRewardObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.VipLevelGoodsObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.WolfSmokeChallengeNotAchieveObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.WolfSmokeChallengeNotJoinObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.WolfSmokeResetAchieveObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.WolfSmokeResetNotAchieveObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.ZentiaGoodsObserver;
import com.kodgames.corgi.server.gameserver.assistant.observer.ZentiaServerRewardObserver;
import com.kodgames.corgi.server.gameserver.assistant.thread.GlobalTimerRunable;
import com.kodgames.corgi.server.gameserver.qininfo.data.struct.QinInfoAnswerCount;
import com.kodgames.corgi.server.gameserver.task.timer.GlobalTimerMgr;
import com.kodgames.corgi.server.gameserver.task.timer.PlayerTimerMgr;
import com.kodgames.corgi.server.gameserver.task.timer.TimerSubject;
import com.kodgames.corgi.server.gameserver.tavern.data.Tavern;
import com.kodgames.corgi.server.gameserver.tavern.data.TavernData;
import com.kodgames.gamedata.player.Energy;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.Stamina;

public class AssisantHelper
{
	public static void initAssisant()
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
		TaskConfig taskConfig = cd.get_TaskConfig();
		// 遍历配置文件,初始化全局Timer
		for (int i = 0; i < taskConfig.Get_TasksCount(); i++)
		{
			TaskConfig.Task task = taskConfig.Get_TasksByIndex(i);
			if (task.get_TaskType() == _TaskType.ArenaAssistant
				|| task.get_TaskType() == _TaskType.CreateAccountRewardAssistant
				|| task.get_TaskType() == _TaskType.DailySignAssistant
				|| task.get_TaskType() == _TaskType.RemedySignAssistant
				|| task.get_TaskType() == _TaskType.MelaleucaDailyPassAssistant
				|| task.get_TaskType() == _TaskType.WolfSmokeResetAchieveAssistant
				|| task.get_TaskType() == _TaskType.WolfSmokeResetNotAchieveAssistant
				|| task.get_TaskType() == _TaskType.MonthCardAssistant
				|| task.get_TaskType() == _TaskType.FriendCampaignResetAchieveAssistant
				|| task.get_TaskType() == _TaskType.FriendCampaignResetAllDeadAssistant
				|| task.get_TaskType() == _TaskType.DanHomeReward
				|| task.get_TaskType() == _TaskType.GuildConstructionAssisstant)
			{
				GlobalTimerMgr.getInstance().registerGlobalTimerSubjects(task.get_TaskId(), -1);
			}
			else if (task.get_TaskType() == _TaskType.FixTimeRewardAssistant
				|| task.get_TaskType() == _TaskType.SecretDungeonAssistant)
			{
				GlobalTimerMgr.getInstance().registerGlobalTimerSubjects(task.get_TaskId(), task.get_TaskType());
			}
		}

		Calendar now =
			Calendar.getInstance(TimeZone.getTimeZone(ServerUtil.getTimeZoneStringFromInt(TimeZoneData.getTimeZone())));
		// 今天零点
		Calendar temp = Calendar.getInstance();
		temp.set(Calendar.HOUR_OF_DAY, 0);
		temp.set(Calendar.MINUTE, 0);
		temp.set(Calendar.SECOND, 0);
		temp.set(Calendar.MILLISECOND, 0);
		temp.setTimeZone(TimeZone.getTimeZone(ServerUtil.getTimeZoneStringFromInt(TimeZoneData.getTimeZone())));
		long nextDayTime = temp.getTimeInMillis() + 24 * 60 * 60 * 1000;
		long delyTime = nextDayTime - now.getTimeInMillis();
		ServerDataGS.globalTimer.scheduleAtFixedRate(new GlobalTimerRunable(), delyTime, 24 * 60 * 60 * 1000);
	}

	// 初始化PlayerTimer 初始化Observer
	public static void initPlayerAssisant(PlayerNode playerNode, ConfigDatabase cd)
	{
		playerNode.getPlayerInfo().getAssisantData().clearAllData();

		// addPlayerTimerData
		Stamina stamina = playerNode.getGamePlayer().getStamina();
		Stamina temp = new Stamina(stamina.getStamina(), stamina.getLastIntervalTime());
		temp.setBuyStaminaCount(stamina.getBuyStaminaCount());
		temp.setBuyStaminaCountLastResetTime(stamina.getBuyStaminaCountLastResetTime());
		temp.refresh(cd, playerNode.getGamePlayer().getVipLevel());
		TimerSubject staminaTimer =
			new TimerSubject(temp.getLastIntervalTime(), 0, cd.get_GameConfig().get_staminaGenerateTime(),
				temp.getLastIntervalTime());
		playerNode.getPlayerInfo().getAssisantData().getTimerData().setStaminaTimer(staminaTimer);

		// addPlayerTavernTimerData
		HashMap<Integer, TimerSubject> tavernFreeTimerMap = new HashMap<Integer, TimerSubject>();
		TavernData tavernData = playerNode.getPlayerInfo().getTavernData();
		int count = cd.get_TavernConfig().Get_TavernsCount();
		for (int i = 0; i < count; i++)
		{
			TavernConfig.Tavern tavernCfg = cd.get_TavernConfig().Get_TavernsByIndex(i);
			if (tavernCfg == null || tavernCfg.get_IsOpen() == false || tavernCfg.get_CoolDownTime() <= 0)
			{
				continue;
			}

			Tavern tavern = tavernData.getTaverns().get(tavernCfg.get_Id());

			TimerSubject tavernFreeTimer;
			if (tavern != null)
			{
				tavernFreeTimer =
					new TimerSubject(tavern.getLastFreeTavernTime(), 0, tavernCfg.get_CoolDownTime(),
						tavern.getLastFreeTavernTime());
			}
			else
			{
				tavernFreeTimer =
					new TimerSubject(System.currentTimeMillis(), 0, tavernCfg.get_CoolDownTime(),
						System.currentTimeMillis());
			}

			tavernFreeTimerMap.put(tavernCfg.get_Id(), tavernFreeTimer);
		}
		playerNode.getPlayerInfo().getAssisantData().getTimerData().setTavernFreeTimerMap(tavernFreeTimerMap);

		// addQinInfoTimerData
		QinInfoAnswerCount qinInfo = playerNode.getPlayerInfo().getQinInfoAnswerCount();
		QinInfoAnswerCount qinTemp =
			new QinInfoAnswerCount(qinInfo.getAnswerCount(), qinInfo.getAnswerCountRecoverTime());
		qinTemp.refresh(cd);
		TimerSubject qinInfoTimer =
			new TimerSubject(qinTemp.getAnswerCountRecoverTime(), 0, cd.get_QinInfoConfig().get_RecoverTime(),
				qinTemp.getAnswerCountRecoverTime());
		playerNode.getPlayerInfo().getAssisantData().getTimerData().setQinInfoTimer(qinInfoTimer);

		// addEnergyTimerData
		Energy energy = playerNode.getGamePlayer().getEnergy();
		Energy energyTemp = new Energy(energy.getEnergy(), energy.getEnergyLastIntervalTime());
		energyTemp.refresh(cd);
		TimerSubject energyTimer =
			new TimerSubject(energyTemp.getEnergyLastIntervalTime(), 0, cd.get_GameConfig().get_energyGenerateTime(),
				energyTemp.getEnergyLastIntervalTime());
		playerNode.getPlayerInfo().getAssisantData().getTimerData().setEnergyTimer(energyTimer);

		// addDelayRewardTimerData
		ArrayList<TimerSubject> delayRewardTimers = new ArrayList<TimerSubject>();
		List<DelayReward> delayRewards = playerNode.getPlayerInfo().getMarvellous().getDelayRewards();
		for (DelayReward delayReward : delayRewards)
		{
			long now = System.currentTimeMillis();
			MarvellousAdventureConfig.RewardEvent rewardEventCfg =
				(MarvellousAdventureConfig.RewardEvent)cd.get_MarvellousAdventureConfig()
					.GetEventById(delayReward.getEventId());
			// 滤掉配置文件中不存在的和已经可以领取的延迟奖励
			if (rewardEventCfg == null || now >= delayReward.getCouldPickTime())
			{
				continue;
			}
			long coolDownTime = delayReward.getCouldPickTime() - delayReward.getGainRewardTime();
			TimerSubject delayRewardTimer =
				new TimerSubject(delayReward.getGainRewardTime(), 0, coolDownTime, delayReward.getGainRewardTime());
			delayRewardTimers.add(delayRewardTimer);
		}
		playerNode.getPlayerInfo().getAssisantData().getTimerData().setDelayRewardTimers(delayRewardTimers);

		ClientServerCommon.TaskConfig taskConfig = cd.get_TaskConfig();
		int num = taskConfig.Get_TasksCount();
		for (int i = 0; i < num; i++)
		{
			TaskConfig.Task taskCfg = taskConfig.Get_TasksByIndex(i);
			if (taskCfg.get_IsOpen() == true)
			{
				int type = taskCfg.get_TaskType();
				switch (type)
				{
					case _TaskType.ArenaAssistant:
						addArenaCombatAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.DungeonAchieveAssistant:
						addDungeonAchieveAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.DungeonCanCombatAssistant:
						addDungeonNotAchieveAssistant(playerNode,
							cd,
							taskCfg.get_TaskId(),
							taskCfg.GetDataValueByType(_DungeonAssistValueType.Diffity));
						break;

					case _TaskType.AvatarIllustrationAssistant:
						addAvatarIllustrationObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.EquipIllustrationAssistant:
						addEquipIllustrationObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.SkillIllustrationAssistant:
						addSkillIllustrationObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.CreateAccountRewardAssistant:
						addCreatAccountObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.FixTimeRewardAssistant:
						addFixTimeRewardObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.TavernAssistant:
						addTavernFreeObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.LevelRewardAssistant:
						addLevelRewardObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.SecretDungeonAssistant:
						addSecretDungeonObserver(playerNode,
							cd,
							taskCfg.get_TaskId(),
							taskCfg.GetDataValueByType(_SecretAssistValueType.ZoneId),
							taskCfg.GetDataValueByType(_SecretAssistValueType.EasyDungeonId),
							taskCfg.GetDataValueByType(_SecretAssistValueType.CommonDungeonId));
						break;

					case _TaskType.DailySignAssistant:
						addDailySignObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.RemedySignAssistant:
						addRemedySignObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.GachaAssistant:
						addGachaCanOpenObserver(playerNode,
							cd,
							taskCfg.get_TaskId(),
							taskCfg.GetDataValueByType(_GachaAssistValueType.GachaId));
						break;

					case _TaskType.DungeonStarRewardAssistant:
						addDungeonStarRewardObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.BuyStaminaAssistant:
						addBuyStaminaAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.DungeonCombatAssistant:
						addDungeonCombatAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.MelaleucaDailyPassAssistant:
						addMelaleucaDailyPassAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.WolfSmokeChallengeNotJoinAssistant:
						addWolfSmokeChallengeNotJoinAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.WolfSmokeChallengeNotAchieveAssistant:
						addWolfSmokeChallengeNotAchieveAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.WolfSmokeResetAchieveAssistant:
						addWolfSmokeResetAchieveAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.WolfSmokeResetNotAchieveAssistant:
						addWolfSmokeResetNotAchieveAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.QinInfoAssistant:
						addQinInfoAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.MonthCardAssistant:
						addMonthCardBasicAssistant(playerNode,
							cd,
							taskCfg.get_TaskId(),
							taskCfg.GetDataValueByType(_MonthCardAssistValueType.MonthCardId));
						break;

					case _TaskType.MelaleucaWeekRankRewardAssistant:
						addMelaleucaWeekRankRewardAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.VipLevelGoodsAssistant:
						addVipLevelGoodsAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.ShopGoodsAssistant:
						addShopGoodsAssistant(playerNode,
							cd,
							taskCfg.get_TaskId(),
							taskCfg.GetDataValueByType(_ShopGoodsAssistantValueType.GroupId));
						break;

					case _TaskType.FriendCampaignNotJoinAssistant:
						addFriendCampaignNotJoinAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;
					case _TaskType.FriendCampaignResetAchieveAssistant:
						addFriendCampaignResetAchieveAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.FriendCampaignNotAchieveAssistant:
						addFriendCampaignNotAchieveAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.FriendCampaignResetAllDeadAssistant:
						addFriendCampaignResetAllDeadAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.MarvellousAdventureNotJoinAssistant:
						addMarvellousAdventureNotJoinAssistant(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.MarvellousDelayRewardAssistant:
						addMarvellousDelayRewardObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.InviteCodeRewardAssistant:
						addInviteCodeObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.ZentiaGoods:
						addZentiaGoodsObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.ZentiaServerReward:
						addZentiaServerRewardObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.DanHomeReward:
						addDanHomeRewardObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.GuildMoveCountAssisstant:
						addGuildMoveCountRemainObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.GuildFreeBossChallengeAssisstant:
						addGuildFreeBossChallengeObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.GuildConstructionAssisstant:
						addGuildConstructionObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.BeastActiveAssistant:
						addBeastActiveObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					case _TaskType.BeastBreakthoughtAssistant:
						addBeastBreakthoughtObserver(playerNode, cd, taskCfg.get_TaskId());
						break;

					default:
						break;
				}
			}
		}

		// addPlayerTimerData
		TimerData timerData = playerNode.getPlayerInfo().getAssisantData().getTimerData();
		PlayerTimerMgr.getInstance().registerPlayerTimerData(playerNode.getPlayerId(), timerData);
	}

	// 历练星级宝箱助手
	public static void addDungeonStarRewardObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		DungeonStarRewardObserver observer = new DungeonStarRewardObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getDungeonCombat().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getDungeonStartReward().registerObserver(observer);
	}

	// 宝箱助手(宝箱数量变化)
	public static void addGachaCanOpenObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId, int gachaId)
	{
		GachaCanOpenObserver observer = new GachaCanOpenObserver(playerNode.getPlayerId(), taskId, gachaId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getGacha().registerObserver(observer);
	}

	// 补签助手(签到、跨天)
	public static void addRemedySignObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		RemedySignObserver observer = new RemedySignObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getSign().registerObserver(observer);
	}

	// 每日签到助手(签到、跨天)
	public static void addDailySignObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		DailySignObserver observer = new DailySignObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getSign().registerObserver(observer);
	}

	// 秘境助手(跨天，等级变化,副本战斗，体力值变化，体力值随着时间增长,活动开启)
	public static void addSecretDungeonObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId, int zoneId,
		int easyDungeonId, int commonDungeonId)
	{
		SecretDungeonCanCombatObserver observer =
			new SecretDungeonCanCombatObserver(playerNode.getPlayerId(), taskId, zoneId, easyDungeonId, commonDungeonId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addPlayerTimer
		playerNode.getPlayerInfo().getAssisantData().getTimerData().getStaminaTimer().registerObserver(observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getDungeonCombat().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerStamina().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerVipLevel().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getSecretKey().registerObserver(observer);
	}

	// 等级礼包助手(等级变化)
	public static void addLevelRewardObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		LevelRewardObserver observer = new LevelRewardObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);
		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
	}

	// 酒馆免费奖励助手(酒馆领取,免费时间到了)
	public static void addTavernFreeObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		TavernFreeRewardObserver observer = new TavernFreeRewardObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addPlayerTimer
		HashMap<Integer, TimerSubject> tavernFreeTimerMap =
			playerNode.getPlayerInfo().getAssisantData().getTimerData().getTavernFreeTimerMap();
		for (TimerSubject tavernFreeTimer : tavernFreeTimerMap.values())
		{
			tavernFreeTimer.registerObserver(observer);
		}

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getTavernFree().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
	}

	// 客栈助手(活动开关，奖励领取)
	public static void addFixTimeRewardObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		FixTimeRewardObserver observer = new FixTimeRewardObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getFixTime().registerObserver(observer);
	}

	// 建号礼包助手(跨天 领取礼包)
	public static void addCreatAccountObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		CreatAccountRewardObserver observer = new CreatAccountRewardObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getCreateAccount().registerObserver(observer);
	}

	// 图鉴助手(碎片变化)
	public static void addAvatarIllustrationObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		AvatarIllustrationObserver observer = new AvatarIllustrationObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getFragment().registerObserver(observer);
	}

	// 图鉴助手(碎片变化)
	public static void addEquipIllustrationObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		EquipIllustrationObserver observer = new EquipIllustrationObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getFragment().registerObserver(observer);
	}

	// 图鉴助手(碎片变化)
	public static void addSkillIllustrationObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		SkillIllustrationObserver observer = new SkillIllustrationObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getFragment().registerObserver(observer);
	}

	// 去历练看看
	public static void addDungeonCombatAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		DungeonCombatObserver observer = new DungeonCombatObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addPlayerTimer
		playerNode.getPlayerInfo().getAssisantData().getTimerData().getStaminaTimer().registerObserver(observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getDungeonCombat().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerStamina().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerVipLevel().registerObserver(observer);
	}

	// 副本普通精英完成助手(跨天，等级变化,副本战斗，体力值变化，体力值随着时间增长)
	public static void addDungeonNotAchieveAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId,
		int dungeonDiffity)
	{
		DungeonNotAchiveObserver observer =
			new DungeonNotAchiveObserver(playerNode.getPlayerId(), taskId, dungeonDiffity);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addPlayerTimer
		playerNode.getPlayerInfo().getAssisantData().getTimerData().getStaminaTimer().registerObserver(observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getDungeonCombat().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerStamina().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerVipLevel().registerObserver(observer);
	}

	// 副本普通精英完成助手(跨天，等级变化,副本战斗，体力值变化，体力值随着时间增长)
	public static void addDungeonAchieveAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		DungeonAchieveObserver observer = new DungeonAchieveObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addPlayerTimer
		playerNode.getPlayerInfo().getAssisantData().getTimerData().getStaminaTimer().registerObserver(observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getDungeonCombat().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerStamina().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerVipLevel().registerObserver(observer);
	}

	// 竞技场助手(会受 打竞技 跨天 VIP 挑战次数变化 四种条件的影响)
	public static void addArenaCombatAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		ArenaCombatRewardObserver observer = new ArenaCombatRewardObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		playerNode.getPlayerInfo().getAssisantData().getArenaCombat().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerVipLevel().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getChallengeTimeChange().registerObserver(observer);
	}

	// 购买体力助手
	public static void addBuyStaminaAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		BuyStaminaObserver observer = new BuyStaminaObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addPlayerTimer
		playerNode.getPlayerInfo().getAssisantData().getTimerData().getStaminaTimer().registerObserver(observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getPlayerStamina().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerVipLevel().registerObserver(observer);
	}

	// 千机楼助手
	public static void addMelaleucaDailyPassAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		MelaleucaDailyPassObserver observer = new MelaleucaDailyPassObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		playerNode.getPlayerInfo().getAssisantData().getMelaleucaDailyPass().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
	}

	// 烽火狼烟挑战助手（未参战）
	public static void addWolfSmokeChallengeNotJoinAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		WolfSmokeChallengeNotJoinObserver observer =
			new WolfSmokeChallengeNotJoinObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		playerNode.getPlayerInfo().getAssisantData().getWolfSmoke().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
	}

	// 烽火狼烟挑战助手（已参战未通关）
	public static void addWolfSmokeChallengeNotAchieveAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		WolfSmokeChallengeNotAchieveObserver observer =
			new WolfSmokeChallengeNotAchieveObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		playerNode.getPlayerInfo().getAssisantData().getWolfSmoke().registerObserver(observer);
	}

	// 烽火狼烟重置助手（通关）
	public static void addWolfSmokeResetAchieveAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		WolfSmokeResetAchieveObserver observer = new WolfSmokeResetAchieveObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		playerNode.getPlayerInfo().getAssisantData().getWolfSmoke().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerVipLevel().registerObserver(observer);
	}

	// 烽火狼烟重置助手（未通关）
	public static void addWolfSmokeResetNotAchieveAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		WolfSmokeResetNotAchieveObserver observer =
			new WolfSmokeResetNotAchieveObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		playerNode.getPlayerInfo().getAssisantData().getWolfSmoke().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerVipLevel().registerObserver(observer);
	}

	// 秦时百科助手
	public static void addQinInfoAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		QinInfoObserver observer = new QinInfoObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addPlayerTimer
		playerNode.getPlayerInfo().getAssisantData().getTimerData().getQinInfoTimer().registerObserver(observer);

		playerNode.getPlayerInfo().getAssisantData().getQinInfo().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
	}

	// 月卡助手
	public static void addMonthCardBasicAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId, int monthCardId)
	{
		MonthCardObserver observer = new MonthCardObserver(playerNode.getPlayerId(), taskId, monthCardId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		playerNode.getPlayerInfo().getAssisantData().getMonthCard().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
	}

	// 千机楼排名奖励助手
	public static void addMelaleucaWeekRankRewardAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		MelaleucaWeekRankRewardObserver observer =
			new MelaleucaWeekRankRewardObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		playerNode.getPlayerInfo().getAssisantData().getMelaleucaReward().registerObserver(observer);
	}

	// Vip等级礼包购买助手
	public static void addVipLevelGoodsAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		VipLevelGoodsObserver observer = new VipLevelGoodsObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		playerNode.getPlayerInfo().getAssisantData().getPlayerVipLevel().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getRealMoney().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getShop().registerObserver(observer);
	}

	// 商城突破丹、精炼石、霸气丹购买助手
	public static void addShopGoodsAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId, int groupId)
	{
		ShopGoodsObserver observer = new ShopGoodsObserver(playerNode.getPlayerId(), taskId, groupId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		playerNode.getPlayerInfo().getAssisantData().getRealMoney().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getShop().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
	}

	// 好友副本参战助手（未参战）
	public static void addFriendCampaignNotJoinAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		FriendCampaignNotJoinObserver observer = new FriendCampaignNotJoinObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		playerNode.getPlayerInfo().getAssisantData().getFriendCampaign().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
	}

	// 好友副本重置助手（通关）
	public static void addFriendCampaignResetAchieveAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		FriendCampaignResetAchieveObserver observer =
			new FriendCampaignResetAchieveObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		playerNode.getPlayerInfo().getAssisantData().getFriendCampaign().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerVipLevel().registerObserver(observer);
	}

	// 好友挑战助手（已参战未通关）
	public static void addFriendCampaignNotAchieveAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		FriendCampaignNotAchieveObserver observer =
			new FriendCampaignNotAchieveObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		playerNode.getPlayerInfo().getAssisantData().getFriendCampaign().registerObserver(observer);
	}

	// 好友重置助手（已参战未通关）
	public static void addFriendCampaignResetAllDeadAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		FriendCampaignResetAllDeadObserver observer =
			new FriendCampaignResetAllDeadObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		playerNode.getPlayerInfo().getAssisantData().getFriendCampaign().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerVipLevel().registerObserver(observer);
	}

	// 奇遇助手
	public static void addMarvellousAdventureNotJoinAssistant(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		MarvellousAdventureNotJoinObserver observer =
			new MarvellousAdventureNotJoinObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addPlayerTimer
		playerNode.getPlayerInfo().getAssisantData().getTimerData().getEnergyTimer().registerObserver(observer);

		playerNode.getPlayerInfo().getAssisantData().getMarvellousAdventure().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
	}

	// 奇遇延时奖励助手(可以领奖了)
	public static void addMarvellousDelayRewardObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		MarvellousDelayRewardObserver observer = new MarvellousDelayRewardObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// delayRewardTimer
		ArrayList<TimerSubject> delayRewardTimers =
			playerNode.getPlayerInfo().getAssisantData().getTimerData().getDelayRewardTimers();
		for (TimerSubject delayRewardTimer : delayRewardTimers)
		{
			delayRewardTimer.registerObserver(observer);
		}

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getMarvellousAdventure().registerObserver(observer);
	}

	// 东海寻仙仙缘兑换(仙缘值有能购买的商品)
	public static void addZentiaGoodsObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		ZentiaGoodsObserver observer = new ZentiaGoodsObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getZentiaSystem().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getZentia().registerObserver(observer);
	}

	// 东海寻仙全服奖励(玩家有未领取的已激活的全服奖励(不管个人累计仙缘是否达到要求))
	public static void addZentiaServerRewardObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		ZentiaServerRewardObserver observer = new ZentiaServerRewardObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getZentiaSystem().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getZentia().registerObserver(observer);
	}

	// 内丹炼丹次数奖励
	public static void addDanHomeRewardObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		DanHomeRewardObserver observer = new DanHomeRewardObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getDanHome().registerObserver(observer);
	}

	// 门派关卡行动力有剩余
	public static void addGuildMoveCountRemainObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		GuildMoveCountObserver observer = new GuildMoveCountObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getGuildStage().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getGuildMoveCount().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
	}

	// 门派关卡免费boss挑战次数有剩余
	public static void addGuildFreeBossChallengeObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		GuildFreeBossChallengeObserver observer = new GuildFreeBossChallengeObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getGuildStage().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
	}

	// 门派建设助手 玩家当前为门派成员，当前可完成建设数大于0时，小助手中有建设提示
	public static void addGuildConstructionObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		GuildConstructionObserver observer = new GuildConstructionObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getGuildConstruction().registerObserver(observer);
	}

	// 邀请码
	public static void addInviteCodeObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		InviteCodeRewardObserver observer = new InviteCodeRewardObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getInviteCode().registerObserver(observer);
	}

	// 机关兽激活助手
	public static void addBeastActiveObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		BeastActiveObserver observer = new BeastActiveObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getBeast().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
	}

	// 机关兽强化助手
	public static void addBeastBreakthoughtObserver(PlayerNode playerNode, ConfigDatabase cd, int taskId)
	{
		BeastBreakthoughtObserver observer = new BeastBreakthoughtObserver(playerNode.getPlayerId(), taskId);
		observer.execute(playerNode, cd);

		ObserverMgr.getInstance().addObserver(playerNode.getPlayerId(), observer);

		// addObserver
		playerNode.getPlayerInfo().getAssisantData().getBeast().registerObserver(observer);
		playerNode.getPlayerInfo().getAssisantData().getPlayerLevel().registerObserver(observer);
	}
}