package com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.activity.fixtime.data.PlayerFixedTimeActivityManager;
import com.kodgames.corgi.server.gameserver.task.data.GreenPointConcreteObserver;
import com.kodgames.gamedata.player.PlayerNode;

public class FixedTimeActivityGreenPointObserver extends GreenPointConcreteObserver
{
	public FixedTimeActivityGreenPointObserver(int playerId,int greenPointId)
	{
		super(playerId, greenPointId);
	}
	
	
	@Override
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		if(FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.FixedTimeActivity))  // 客栈开启
		{
			if(PlayerFixedTimeActivityManager.isCanGetRewad(playerNode)) //能获得奖励
			{
				this.setState(true);
				if(this.isStateChanged())
				{
					super.notifyClientGreenPoint(playerNode.getPlayerId(), true);
				}
			}
			else 
			{
				this.setState(false);
				if(this.isStateChanged())
				{
					super.notifyClientGreenPoint(playerNode.getPlayerId(), false);
				}
			}
		}
	}
}
