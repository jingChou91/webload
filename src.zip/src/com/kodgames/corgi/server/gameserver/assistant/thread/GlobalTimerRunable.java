package com.kodgames.corgi.server.gameserver.assistant.thread;

import java.util.TimerTask;

import com.kodgames.corgi.server.gameserver.task.timer.GlobalTimerMgr;

public class GlobalTimerRunable extends TimerTask
{
	@Override
	public void run()
	{
		GlobalTimerMgr.getInstance().execute(-1, 0);
	}
}
