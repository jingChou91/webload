package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.qininfo.data.struct.QinInfoAnswerCount;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;

public class QinInfoObserver extends AssisstantConcreteObserver
{
	public QinInfoObserver(int playerId, int taskId)
	{
		super(playerId, taskId);
	}
	
	@Override
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		QinInfoAnswerCount qinInfo = playerNode.getPlayerInfo().getQinInfoAnswerCount();
		QinInfoAnswerCount temp = new QinInfoAnswerCount(qinInfo.getAnswerCount(), qinInfo.getAnswerCountRecoverTime());
		temp.refresh(cd);
		
		if(temp.getAnswerCount() > 0 &&         // 剩余答题次数大于0
		   FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.QinInfo))
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}