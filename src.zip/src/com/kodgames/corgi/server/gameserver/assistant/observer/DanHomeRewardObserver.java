package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.DHUtil;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;

public class DanHomeRewardObserver extends AssisstantConcreteObserver
{
	public DanHomeRewardObserver(int playerId, int taskId)
	{
		super(playerId, taskId);
	}
	
	@Override
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		if(FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.DanHome)	// 内丹开启
			&& cd.get_DanConfig().get_IsDanHomeOpen()				// 丹房开启
			&& DHUtil.hasRewardCanGet(cd, playerNode))				// 玩家是否有可领取的炼丹次数奖励
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}