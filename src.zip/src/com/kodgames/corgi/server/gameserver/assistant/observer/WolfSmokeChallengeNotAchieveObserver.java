package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.corgi.server.gameserver.wolfsmoke.data.WolfSmokeData;
import com.kodgames.corgi.server.gameserver.wolfsmoke.util.WolfSmokeUtil;
import com.kodgames.gamedata.player.PlayerNode;

/*
 * 1.玩家等级≥烽火狼烟开启等级。  
 * 2.烽火狼烟系统开放中。
 * 3.玩家在烽火狼烟有阵容记录。
 * 4.烽火狼烟本次没有全部通关（20关未通关）。
 * 5.烽火狼烟中玩家的【可失败次数】>=【玩家当前可失败次数上限】
 */
public class WolfSmokeChallengeNotAchieveObserver extends AssisstantConcreteObserver
{

	public WolfSmokeChallengeNotAchieveObserver(int playerId, int taskId)
	{
		super(playerId, taskId);
	}

	@Override
	public void execute(PlayerNode playerNode,ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		WolfSmokeData wolfSmokeData = playerNode.getPlayerInfo().getWolfSmokeData();
		
		if((wolfSmokeData.isJoin() 					// 玩家已参战 
			&& wolfSmokeData.getStageId() != -1 	// 本次挑战没有全部通关
			&& wolfSmokeData.getFailedTimes() == 0) // 本次挑战已失败次数为0
			&& WolfSmokeUtil.satisfyOpenLimit(cd, playerNode) == 0)
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}
