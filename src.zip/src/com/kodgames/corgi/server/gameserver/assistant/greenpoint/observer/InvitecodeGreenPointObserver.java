package com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.task.data.GreenPointConcreteObserver;
import com.kodgames.gamedata.player.PlayerNode;

public class InvitecodeGreenPointObserver extends GreenPointConcreteObserver
{
	public InvitecodeGreenPointObserver(int playerId, int greenPointId) {
		super(playerId, greenPointId);
		// TODO Auto-generated constructor stub
	}

	
	@Override
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{	
		super.execute(playerNode, cd);
		
		if(FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.InviteCode))// 邀请码功能开启
		{		
			if(playerNode.getPlayerInfo().getInviteData().hasRewrdPick(playerNode.getPlayerId(), cd))	// 有达到条件的奖励未领取
			{
				this.setState(true);
				if(this.isStateChanged())
				{
					super.notifyClientGreenPoint(playerNode.getPlayerId(), true);
				}
			}
			else
			{
				this.setState(false);
				if(this.isStateChanged())
				{
					super.notifyClientGreenPoint(playerNode.getPlayerId(), false);
				}
			}
		}
	}

}