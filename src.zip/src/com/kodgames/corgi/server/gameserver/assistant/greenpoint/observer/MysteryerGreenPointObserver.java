package com.kodgames.corgi.server.gameserver.assistant.greenpoint.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.mysteryer.data.MysteryerData;
import com.kodgames.corgi.server.gameserver.mysteryer.util.MysteryerActivityUtil;
import com.kodgames.corgi.server.gameserver.task.data.GreenPointConcreteObserver;
import com.kodgames.gamedata.player.PlayerNode;

public class MysteryerGreenPointObserver extends GreenPointConcreteObserver
{
	public MysteryerGreenPointObserver(int playerId, int greenPointId)
	{
		super(playerId, greenPointId);
	}
	
	@Override
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{	
		super.execute(playerNode, cd);
		
		MysteryerData myData = playerNode.getPlayerInfo().getMysteryerData();
		
		if(FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Tavern))
		{		
			if(MysteryerActivityUtil.isActivityOpen(cd)	// 活动开启
				&& myData.hasActivityGoods(cd))			// 商品列表中有本期活动专属商品（即酒馆页面上显示的那三个）且未被购买
			{
				this.setState(true);
				if(this.isStateChanged())
				{
					super.notifyClientGreenPoint(playerNode.getPlayerId(), true);
				}
			}
			else
			{
				this.setState(false);
				if(this.isStateChanged())
				{
					super.notifyClientGreenPoint(playerNode.getPlayerId(), false);
				}
			}
		}
	}

}