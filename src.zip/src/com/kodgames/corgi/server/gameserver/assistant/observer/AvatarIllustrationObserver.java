package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.IDSeg._AssetType;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.illustration.data.IllustrationMgr;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;

public class AvatarIllustrationObserver extends AssisstantConcreteObserver
{

	public AvatarIllustrationObserver(int playerId,int taskId)
	{
		super(playerId, taskId);
	}
	
	@Override
	public void execute(PlayerNode playerNode,ConfigDatabase cd)
	{
		super.execute(playerNode, cd);
		
		int resourceId = IllustrationMgr.checkFragment(playerNode, cd, _AssetType.Avatar);
		if(resourceId != 0 && FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.CardPicture))
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}

}
