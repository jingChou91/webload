package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.melaleucaFloor.data.MelaleucaMgr;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;

public class MelaleucaWeekRankRewardObserver extends AssisstantConcreteObserver
{

	public MelaleucaWeekRankRewardObserver(int playerId, int taskId)
	{
		super(playerId, taskId);
	}

	/*
	 * 千层楼排名奖励是否可领取
	 */
	@Override
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{
		super.execute(playerNode, cd);

		// 千机楼排名奖励没有领取
		if (MelaleucaMgr.canPickWeekReward(playerNode, cd) && FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.MelaleucaFloor))
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}

	}

}
