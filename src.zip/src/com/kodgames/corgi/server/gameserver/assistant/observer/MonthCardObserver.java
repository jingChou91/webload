package com.kodgames.corgi.server.gameserver.assistant.observer;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.monthcard.data.MonthCardManager;
import com.kodgames.corgi.server.gameserver.task.data.AssisstantConcreteObserver;
import com.kodgames.corgi.server.gameserver.task.data.ObserverStatus;
import com.kodgames.gamedata.player.PlayerNode;

public class MonthCardObserver extends AssisstantConcreteObserver
{
	private int monthCardId;

	public MonthCardObserver(int playerId, int taskId, int monthCardId)
	{
		super(playerId, taskId);
		this.monthCardId = monthCardId;
	}

	@Override
	public void execute(PlayerNode playerNode, ConfigDatabase cd)
	{
		super.execute(playerNode, cd);

		if (MonthCardManager.isCanGetMonthCardReward(playerNode, cd, this.monthCardId)
			&& FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.MonthCardFeedback))
		{
			this.setObserverStatus(ObserverStatus.ACTIVE);
		}
		else
		{
			this.setObserverStatus(ObserverStatus.NOACTIVE);
		}
	}
}
