package com.kodgames.corgi.server.gameserver.email.util.specialemail;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.email.data.EmailData;
import com.kodgames.corgi.server.gameserver.email.data.GroupEmailMgr;
import com.kodgames.corgi.server.gameserver.email.data.struct.GroupEmail;
import com.kodgames.corgi.server.gameserver.email.data.struct.PlayerEmail;
import com.kodgames.corgi.server.gameserver.email.util.EmailUtil;
import com.kodgames.corgi.server.gameserver.email.util.SendEmailBase;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Reward;

public class EmailGMUtil
{
	private static final Logger logger = LoggerFactory.getLogger(EmailGMUtil.class);

	/**
	 * 获取所有群邮件的深克隆
	 */
	public static Map<Long, GroupEmail> getCopyGroupEmails()
	{
		return GroupEmailMgr.getInstance().getCopyGroupEmails();
	}

	/**
	 * 删除群邮件
	 */
	public static boolean delteGroupEmail(long emailId)
	{
		return GroupEmailMgr.getInstance().deleteGroupEmail(emailId);
	}

	/**
	 * 获取玩家指定类型的所有邮件
	 */
	public static List<PlayerEmail> getPlayerEmails(int playerId, int emailType)
	{
		// emailType=ClientServerCommon._EmailDisplayType.System;
		PlayerNode playerNode = ServerDataGS.playerManager.getMemoryPlayerNode(playerId);
		if (playerNode == null)
		{
			return null;
		}
		playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
		EmailData emailData = playerNode.getPlayerInfo().getEmailData();
		// 获取邮件信息
		Map<Long, PlayerEmail> playerEmails = emailData.getPlayerEmailsByEmailType(emailType);
		// 获取需要展示给客户端的邮件id,并判断是否需要删除多余邮件
		List<Long> showEmailIds = EmailUtil.testAndDeletePlayerEmail(playerNode, emailType);
		// 将邮件信息返回给客户端
		List<PlayerEmail> emails = new ArrayList<PlayerEmail>();
		for (Long emailId : showEmailIds)
		{
			emails.add(playerEmails.get(emailId).copy());
		}
		return emails;
	}

	// 使用gm工具发送邮件
	public static void sendPlayerEmailsByRewardSetIdForGM(int receiverId, String emailTitle, String emailBody,
			int rewardSetId, int count, Reward reward)
	{
		// 邮件字体默认颜色
		emailBody = EmailUtil.rightWithColor(emailBody, ClientServerCommon._MailType.System);

		ConfigDatabase cd = CfgDB.getDefautConfig();
		SendEmailBase.sendPlayerEmailsByRewardSetId(receiverId, ClientServerCommon._MailType.System, emailTitle,
				emailBody, System.currentTimeMillis(), -1, "GM", -1L, 0, 0, rewardSetId, count, cd, reward);
	}

	// gm工具发送群邮件
	public static void sendGroupEmailForGM(String title, String emailBody, int rewardSetId, int count, int minLevel,
			int maxLevel, long startTime, long endTime, long createPlayerDataStartTime, long createPlayerDataEndTime,
			Reward reward)
	{
		logger.error("Send Group Email Time :" + System.currentTimeMillis() + "    emailBody:   " + emailBody);

		// 邮件字体默认颜色
		emailBody = EmailUtil.rightWithColor(emailBody, ClientServerCommon._MailType.System);

		ConfigDatabase cd = CfgDB.getDefautConfig();
		SendEmailBase.sendGroupEmail(title, emailBody, rewardSetId, count, minLevel, maxLevel, startTime, endTime,
				createPlayerDataStartTime, createPlayerDataEndTime, cd, reward);
	}

}
