package com.kodgames.corgi.server.gameserver.email.util.specialemail;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._MailType;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.server.gameserver.email.data.EmailData;
import com.kodgames.corgi.server.gameserver.email.data.EmailMgr;
import com.kodgames.corgi.server.gameserver.email.data.struct.PlayerEmail;
import com.kodgames.corgi.server.gameserver.email.util.EmailUtil;
import com.kodgames.corgi.server.gameserver.email.util.SendEmailBase;
import com.kodgames.gamedata.player.PlayerNode;

public class EmailFriendUtil
{
	// 修改邮件附件领取状态(内存+数据库)
	public static void updateEmailStatus(PlayerNode playerNode, long emailId, int statusPicked)
	{
		EmailMgr.updatePlayerEmailStatusPicked(playerNode, emailId, statusPicked);
	}

	// 删除好友邀请邮件
	public static Long delFriendEmail(PlayerNode playerNode, int receiverId)
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
		// 获取邮件类型
		int emailType = _MailType.FriendDel;
		// 获取邮件内容
		String fmt = cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_Friend_DelFriend");
		// 邮件字体默认颜色
		fmt = EmailUtil.rightWithColor(fmt, emailType);
		// 邮件关键字颜色
		String email_body =
			String.format(fmt, EmailUtil.wrappedWithColor(playerNode.getGamePlayer().getFixName(), emailType));
		return SendEmailBase.sendPlayerEmailsByRewardSetId(receiverId,
			emailType,
			"同意好友邀请",
			email_body,
			System.currentTimeMillis(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			-1L,
			0,
			0,
			0,
			0,
			cd,
			null);
	}

	// 同意好友邀请邮件
	public static Long agreeFriendEmail(PlayerNode playerNode, int receiverId)
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
		// 获取邮件类型
		int emailType = _MailType.FriendAdd;
		// 获取邮件内容
		String fmt = cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_Friend_AddFriend");
		// 邮件字体默认颜色
		fmt = EmailUtil.rightWithColor(fmt, emailType);
		// 邮件关键字颜色
		String email_body =
			String.format(fmt, EmailUtil.wrappedWithColor(playerNode.getGamePlayer().getFixName(), emailType));
		return SendEmailBase.sendPlayerEmailsByRewardSetId(receiverId,
			emailType,
			"同意好友邀请",
			email_body,
			System.currentTimeMillis(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			-1L,
			0,
			0,
			0,
			0,
			cd,
			null);
	}

	// 拒绝好友邀请邮件
	public static Long refuseFriendEmail(PlayerNode playerNode, int receiverId)
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
		// 获取邮件类型
		int emailType = _MailType.FriendReceiveRefuse;
		// 获取邮件内容
		String fmt = cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_Friend_RefuseFriend");
		// 邮件字体默认颜色
		fmt = EmailUtil.rightWithColor(fmt, emailType);
		// 邮件关键字颜色
		String email_body =
			String.format(fmt, EmailUtil.wrappedWithColor(playerNode.getGamePlayer().getFixName(), emailType));
		return SendEmailBase.sendPlayerEmailsByRewardSetId(receiverId,
			emailType,
			"拒绝好友邀请",
			email_body,
			System.currentTimeMillis(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			-1L,
			0,
			0,
			0,
			0,
			cd,
			null);
	}

	// 邀请好友邮件
	public static Long inviteFriendEmail(PlayerNode playerNode, int receiverId)
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
		// 获取邮件类型
		int emailType = _MailType.AddFriendRequrst;
		// 获取邮件内容
		String fmt = cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_Friend_InviteFriend");
		// 邮件字体默认颜色
		fmt = EmailUtil.rightWithColor(fmt, emailType);
		// 邮件关键字颜色
		String email_body =
			String.format(fmt, EmailUtil.wrappedWithColor(playerNode.getGamePlayer().getFixName(), emailType));
		return SendEmailBase.sendPlayerEmailsByRewardSetId(receiverId,
			emailType,
			"邀请好友",
			email_body,
			System.currentTimeMillis(),
			playerNode.getPlayerId(),
			playerNode.getGamePlayer().getFixName(),
			-1L,
			0,
			0,
			0,
			0,
			cd,
			null);
	}

	// 邀请好友邮件
		public static Long inviteFriendEmailOfInviteCode(PlayerNode playerNode, int receiverId)
		{
			ConfigDatabase cd = CfgDB.getDefautConfig();
			// 获取邮件类型
			int emailType = _MailType.AddFriendRequrst;
			// 获取邮件内容
			String fmt = cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_Friend_InviteFriend_Of_Invitecode");
			// 邮件字体默认颜色
			fmt = EmailUtil.rightWithColor(fmt, emailType);
			// 邮件关键字颜色
			String email_body =
				String.format(fmt, EmailUtil.wrappedWithColor(playerNode.getGamePlayer().getFixName(), emailType));
			return SendEmailBase.sendPlayerEmailsByRewardSetId(receiverId,
				emailType,
				"邀请好友",
				email_body,
				System.currentTimeMillis(),
				playerNode.getPlayerId(),
				playerNode.getGamePlayer().getFixName(),
				-1L,
				0,
				0,
				0,
				0,
				cd,
				null);
		}
	public static Integer getEmailPickStatus(PlayerNode playerNode, Long emailId)
	{
		EmailData emailData = playerNode.getPlayerInfo().getEmailData();
		PlayerEmail playerEmail = emailData.getPlayerEmailById(emailId);
		if (playerEmail != null)
		{
			return playerEmail.getStatusPicked();
		}
		return -1;
	}

}
