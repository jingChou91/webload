package com.kodgames.corgi.server.gameserver.email.logic;

import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_SyncEmailCount;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.gamedata.player.PlayerNode;

public class SyncEmailCount
{
	// 通知玩家有新的未读邮件
	public static void synUnreadEmailCount(int playerId, int emailType)
	{
		// 如果玩家在线,那么通知玩家有新邮件
		PlayerNode playerNode = ServerDataGS.playerManager.getMemoryPlayerNode(playerId);
		if (playerNode != null && playerNode.getPlayerInfo() != null)
		{
			GC_SyncEmailCount.Builder builder = GC_SyncEmailCount.newBuilder();
			Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_SYNC_UN_READ_EMAIL_COUNT);
			int unReadEmailCount = playerNode.getPlayerInfo().getEmailData().getUnReadEmailCount(emailType);
			builder.setCount(unReadEmailCount);
			builder.setEmailType(emailType);
			protocol.setProtoBufMessage(builder.build());
			ServerDataGS.transmitter.sendToClient(playerId, protocol);
		}
	}

	// 通知玩家有新的未读邮件(未解决客户端线上bug临时写的方法,该方法返回客户端的新邮件count一定>=1)
	public static void synUnreadEmailFixCount(int playerId, int emailType)
	{
		// 转换为大类型
		emailType = ClientServerCommon._MailType.GetTabEmailTypeFromDBEmailType(emailType);
		// 如果玩家在线,通知玩家有新邮件
		if (ServerDataGS.playerManager.isOnline(playerId))
		{
			// 如果玩家在线,那么通知玩家有新邮件
			PlayerNode playerNode = ServerDataGS.playerManager.getMemoryPlayerNode(playerId);
			if (playerNode != null && playerNode.getPlayerInfo() != null)
			{
				GC_SyncEmailCount.Builder builder = GC_SyncEmailCount.newBuilder();
				Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_SYNC_UN_READ_EMAIL_COUNT);
				int unReadEmailCount = playerNode.getPlayerInfo().getEmailData().getUnReadEmailCount(emailType);
				if (unReadEmailCount < 1)
				{
					unReadEmailCount = 1;
				}
				builder.setCount(unReadEmailCount);
				builder.setEmailType(emailType);
				protocol.setProtoBufMessage(builder.build());
				ServerDataGS.transmitter.sendToClient(playerId, protocol);
			}
		}

	}
}
