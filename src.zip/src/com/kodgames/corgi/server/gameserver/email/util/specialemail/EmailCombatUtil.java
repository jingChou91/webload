package com.kodgames.corgi.server.gameserver.email.util.specialemail;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._MailType;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.server.gameserver.email.util.EmailUtil;
import com.kodgames.corgi.server.gameserver.email.util.SendEmailBase;

public class EmailCombatUtil
{
	// 竞技场战斗邮件
	public static void sendPlayerEmailsForArena(int receiverId, String emailTitle, int senderId, String senderName, boolean senderIsWinner, int rank)
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
		// 获取邮件类型
		int emailType = _MailType.CombatArena;
		String email_body = "";
		if(senderIsWinner)
		{
			String fmt = cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_Arena_Loser");
			// 邮件字体默认颜色
			fmt = EmailUtil.rightWithColor(fmt, emailType);
			// // 邮件关键字颜色
			email_body = String.format(fmt, EmailUtil.wrappedWithColor(senderName, emailType), EmailUtil.wrappedWithColor(Integer.toString(rank), emailType));
		}
		else
		{
			// 获取邮件内容
			String fmt = cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_Arena_Winner");
			// 邮件字体默认颜色
			fmt = EmailUtil.rightWithColor(fmt, emailType);
			// // 邮件关键字颜色
			email_body = String.format(fmt, EmailUtil.wrappedWithColor(senderName, emailType));
		}
		SendEmailBase.sendPlayerEmailsByRewardSetId(receiverId,
			emailType,
			emailTitle,
			email_body,
			System.currentTimeMillis(),
			senderId,
			senderName,
			-1L,
			0,
			0,
			0,
			0,
			cd,
			null);
	}

}
