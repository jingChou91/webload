package com.kodgames.corgi.server.gameserver.email.util;

import java.util.ArrayList;
import java.util.List;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.email.data.EmailMgr;
import com.kodgames.corgi.server.gameserver.email.data.struct.Attachment;
import com.kodgames.corgi.server.gameserver.email.data.struct.GroupEmail;
import com.kodgames.corgi.server.gameserver.email.data.struct.PlayerEmail;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Reward;
import com.kodgames.gamedata.player.costandreward.RewardGen;

public class SendEmailBase
{
	// 发送群邮件(只修改群邮件在数据库和内存中的数据,并不真正发给具体玩家.发给具体玩家queryInitInfo时触发)
	public static void sendGroupEmail(String title, String emailBody, int rewardSetId, int count, int minLevel,
		int maxLevel, long startTime, long endTime, long createPlayerDataStartTime, long createPlayerDataEndTime,
		ConfigDatabase cd, Reward reward)
	{
		// 每组附件生成一个群邮件
		List<GroupEmail> groupEmails = new ArrayList<GroupEmail>();
		if (rewardSetId == 0 && reward == null)
		{
			GroupEmail email = new GroupEmail();

			// 生成并赋予groupId
			EmailUtil.genAndGiveGroupEmailId(email);

			email.setEmailType(ClientServerCommon._MailType.System);
			email.setEmailTitle(title);
			email.setEmailBody(emailBody);
			email.setSendTime(System.currentTimeMillis());
			email.setSenderName("系统邮件");
			email.setSenderId(-1);
			email.setReceiverPlayerId(-1);
			email.setAttachments(new ArrayList<Attachment>());
			email.setReceiverLevelMin(minLevel);
			email.setReceiverLevelMax(maxLevel);
			email.setStartTime(startTime);
			email.setEndTime(endTime);
			email.setCreatePlayerStartTime(createPlayerDataStartTime);
			email.setCreatePlayerEndTime(createPlayerDataEndTime);

			groupEmails.add(email);
		}
		else
		{
			// 所有附件(数量可能大于10)
			if (reward == null)
			{
				reward = RewardGen.getRewardFromRewardSetId(rewardSetId, cd);
			}
			List<Attachment> attachments = Attachment.rewardToAttachments(reward, count);

			// 将附件拆分为10个一组
			List<List<Attachment>> attachmentsList = EmailUtil.turnToGroup(attachments);

			if (attachmentsList.size() > 0)
			{
				for (int i = 0; i < attachmentsList.size(); i++)
				{
					GroupEmail email = new GroupEmail();

					// 生成并赋予groupId
					EmailUtil.genAndGiveGroupEmailId(email);

					email.setEmailType(ClientServerCommon._MailType.System);
					email.setEmailTitle(title);
					email.setEmailBody(emailBody);
					email.setSendTime(System.currentTimeMillis());
					email.setSenderName("系统邮件");
					email.setSenderId(-1);
					email.setReceiverPlayerId(-1);
					email.setAttachments(attachmentsList.get(i));
					email.setReceiverLevelMin(minLevel);
					email.setReceiverLevelMax(maxLevel);
					email.setStartTime(startTime);
					email.setEndTime(endTime);
					email.setCreatePlayerStartTime(createPlayerDataStartTime);
					email.setCreatePlayerEndTime(createPlayerDataEndTime);

					groupEmails.add(email);
				}
			}
			else
			{
				GroupEmail email = new GroupEmail();

				// 生成并赋予groupId
				EmailUtil.genAndGiveGroupEmailId(email);

				email.setEmailType(ClientServerCommon._MailType.System);
				email.setEmailTitle(title);
				email.setEmailBody(emailBody);
				email.setSendTime(System.currentTimeMillis());
				email.setSenderName("系统邮件");
				email.setSenderId(-1);
				email.setReceiverPlayerId(-1);
				email.setAttachments(new ArrayList<Attachment>());
				email.setReceiverLevelMin(minLevel);
				email.setReceiverLevelMax(maxLevel);
				email.setStartTime(startTime);
				email.setEndTime(endTime);
				email.setCreatePlayerStartTime(createPlayerDataStartTime);
				email.setCreatePlayerEndTime(createPlayerDataEndTime);

				groupEmails.add(email);
			}
		}

		// 发送群邮件(内存+数据库)
		for (GroupEmail groupEmail : groupEmails)
		{
			EmailMgr.addGroupEmail(groupEmail);
		}
	}

	// 发送带有附件的玩家邮件,基础方法的第二层封装,根据rewardSedid生成附件,如果附件数量大于10,拆分为多封邮件,循环调用第一层封装发送邮件
	public static Long sendPlayerEmailsByRewardSetId(int receiverId, int emailType, String emailTitle,
		String emailBody, Long sendTime, int senderId, String senderName, Long groupId, int statusPicked,
		int statusDelete, int rewardSetId, int count, ConfigDatabase cd, Reward reward)
	{
		// 如果没有奖励,那么直接调用下一层封装, 如果有奖励,那么生成附件,根据附件数量循环调用下一层
		if (rewardSetId == 0 && reward == null)
		{
			return sendPlayerEmail(receiverId,
				emailType,
				emailTitle,
				emailBody,
				sendTime,
				senderId,
				senderName,
				groupId,
				statusPicked,
				statusDelete,
				new ArrayList<Attachment>(),
				cd);
		}
		else
		{
			// 所有附件(数量可能大于10)
			if (reward == null)
			{
				reward = RewardGen.getRewardFromRewardSetId(rewardSetId, cd);
			}
			List<Attachment> attachments = Attachment.rewardToAttachments(reward, count);
			// 将附件拆分为10个一组
			List<List<Attachment>> attachmentsList = EmailUtil.turnToGroup(attachments);

			Long emailId = 0L;
			if (attachmentsList.size() > 0)
			{
				// 每组附件生成一个邮件
				for (int i = 0; i < attachmentsList.size(); i++)
				{
					emailId =
						sendPlayerEmail(receiverId,
							emailType,
							emailTitle,
							emailBody,
							sendTime,
							senderId,
							senderName,
							groupId,
							statusPicked,
							statusDelete,
							attachmentsList.get(i),
							cd);
				}
			}
			else
			{
				return sendPlayerEmail(receiverId,
					emailType,
					emailTitle,
					emailBody,
					sendTime,
					senderId,
					senderName,
					groupId,
					statusPicked,
					statusDelete,
					new ArrayList<Attachment>(),
					cd);
			}

			return emailId;// 返回最后一个邮件的emailId
		}
	}

	// 发送玩家邮件,基础方法的第一层封装,生成没有没有emailId的邮件.然后调用基础方法
	public static Long sendPlayerEmail(int receiverId, int emailType, String emailTitle, String emailBody,
		Long sendTime, int senderId, String senderName, Long groupId, int statusPicked, int statusDelete,
		List<Attachment> attachments, ConfigDatabase cd)
	{
		PlayerEmail email = new PlayerEmail();
		email.setEmailType(emailType);
		email.setEmailTitle(emailTitle);
		email.setEmailBody(emailBody);
		email.setSendTime(sendTime);
		email.setSenderId(senderId);
		email.setSenderName(senderName);
		email.setReceiverId(receiverId);
		email.setGroupId(groupId);
		email.setStatusPicked(statusPicked);
		email.setStatusDelete(statusDelete);
		email.setAttachments(attachments);
		return sendPlayerEmailBase(email);
	}

	// *发送玩家邮件*基础方法*(内涵生成邮件id,判断收件人是否在线,主动通知收件人有新邮件等逻辑,修改内存,修改数据库)
	public static Long sendPlayerEmailBase(PlayerEmail email)
	{
		// 获取收件人在内存中的数据(可能为null)
		PlayerNode playerNode = ServerDataGS.playerManager.getMemoryPlayerNode(email.getReceiverId());
		// 发送邮件
		return EmailMgr.addPlayerEmailSync(playerNode, email);
	}

}
