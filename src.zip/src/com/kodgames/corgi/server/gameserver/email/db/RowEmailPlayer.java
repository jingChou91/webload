package com.kodgames.corgi.server.gameserver.email.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.rowset.CachedRowSet;

import org.perf4j.StopWatch;
import org.perf4j.slf4j.Slf4JStopWatch;

import com.kodgames.corgi.server.gameserver.email.data.struct.Attachment;
import com.kodgames.corgi.server.gameserver.email.data.struct.PlayerEmail;
import com.kodgames.gamedata.dbcommon.DBEasy;
import com.kodgames.gamedata.player.PlayerNode;

public class RowEmailPlayer
{
	// 查询私人邮件，所有未删除的
	public static void selectPrivate(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs,
		PlayerNode playerNode)
		throws SQLException
	{

		String sql = "select * from email_player where receiver_id=? AND status_delete=0";
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, new Object[] {playerNode.getPlayerId()});

		// index_PlayerEmail
		Map<Long, PlayerEmail> combatEmails = new HashMap<Long, PlayerEmail>();
		Map<Long, PlayerEmail> friendEmails = new HashMap<Long, PlayerEmail>();
		Map<Long, PlayerEmail> systemEmails = new HashMap<Long, PlayerEmail>();
		Map<Long, PlayerEmail> guildEmails = new HashMap<Long, PlayerEmail>();

		if (vrs[queryIndex] != null)
		{
			StopWatch why1 = new Slf4JStopWatch("why1");
			CachedRowSet rs = vrs[queryIndex];
			while (rs.next())
			{
				StopWatch why2 = new Slf4JStopWatch("why2");
				PlayerEmail email = new PlayerEmail();

				email.setEmailId(rs.getLong("email_id"));
				email.setEmailType(rs.getInt("email_type"));
				email.setEmailTitle(rs.getString("email_title"));
				email.setEmailBody(rs.getString("email_body"));
				email.setSendTime(rs.getDate("send_time").getTime());
				email.setSenderName(rs.getString("sender_name"));
				email.setSenderId(rs.getInt("sender_id"));
				email.setReceiverId(rs.getInt("receiver_id"));
				email.setGroupId(rs.getLong("group_id"));
				email.setStatusDelete(rs.getInt("status_delete"));
				email.setStatusPicked(rs.getInt("status_picked"));
				why2.stop();

				StopWatch why3 = new Slf4JStopWatch("why3");
				List<Attachment> attachments = new ArrayList<Attachment>();
				if (rs.getInt("obj0_id") != 0)
				{
					attachments.add(new Attachment(rs.getInt("obj0_id"), rs.getInt("obj0_data1"),
						rs.getInt("obj0_data2"), rs.getInt("obj0_count")));
					email.setAttachments(attachments);
				}
				if (rs.getInt("obj1_id") != 0)
				{
					attachments.add(new Attachment(rs.getInt("obj1_id"), rs.getInt("obj1_data1"),
						rs.getInt("obj1_data2"), rs.getInt("obj1_count")));
					email.setAttachments(attachments);
				}
				if (rs.getInt("obj2_id") != 0)
				{
					attachments.add(new Attachment(rs.getInt("obj2_id"), rs.getInt("obj2_data1"),
						rs.getInt("obj2_data2"), rs.getInt("obj2_count")));
					email.setAttachments(attachments);
				}
				if (rs.getInt("obj3_id") != 0)
				{
					attachments.add(new Attachment(rs.getInt("obj3_id"), rs.getInt("obj3_data1"),
						rs.getInt("obj3_data2"), rs.getInt("obj3_count")));
					email.setAttachments(attachments);
				}
				if (rs.getInt("obj4_id") != 0)
				{
					attachments.add(new Attachment(rs.getInt("obj4_id"), rs.getInt("obj4_data1"),
						rs.getInt("obj4_data2"), rs.getInt("obj4_count")));
					email.setAttachments(attachments);
				}
				if (rs.getInt("obj5_id") != 0)
				{
					attachments.add(new Attachment(rs.getInt("obj5_id"), rs.getInt("obj5_data1"),
						rs.getInt("obj5_data2"), rs.getInt("obj5_count")));
					email.setAttachments(attachments);
				}
				if (rs.getInt("obj6_id") != 0)
				{
					attachments.add(new Attachment(rs.getInt("obj6_id"), rs.getInt("obj6_data1"),
						rs.getInt("obj6_data2"), rs.getInt("obj6_count")));
					email.setAttachments(attachments);
				}
				if (rs.getInt("obj7_id") != 0)
				{
					attachments.add(new Attachment(rs.getInt("obj7_id"), rs.getInt("obj7_data1"),
						rs.getInt("obj7_data2"), rs.getInt("obj7_count")));
					email.setAttachments(attachments);
				}

				switch (ClientServerCommon._MailType.GetTabEmailTypeFromDBEmailType(email.getEmailType()))
				{
					case ClientServerCommon._EmailDisplayType.Combat:
						combatEmails.put(email.getEmailId(), email);
						break;
					case ClientServerCommon._EmailDisplayType.Friend:
						friendEmails.put(email.getEmailId(), email);
						break;
					case ClientServerCommon._EmailDisplayType.System:
						systemEmails.put(email.getEmailId(), email);
						break;
					case ClientServerCommon._EmailDisplayType.Guild:
						guildEmails.put(email.getEmailId(), email);
						break;
					default:
						break;
				}

				why3.stop();
			}

			why1.stop();
		}
		playerNode.getPlayerInfo().getEmailData().setCombatEmails(combatEmails);
		playerNode.getPlayerInfo().getEmailData().setFriendEmails(friendEmails);
		playerNode.getPlayerInfo().getEmailData().setSystemEmails(systemEmails);
		playerNode.getPlayerInfo().getEmailData().setGuildEmails(guildEmails);
	}
}
