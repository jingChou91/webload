package com.kodgames.corgi.server.gameserver.email.data;

import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.email.data.struct.GroupEmail;
import com.kodgames.corgi.server.gameserver.email.data.struct.PlayerEmail;
import com.kodgames.corgi.server.gameserver.email.db.EmailDB;
import com.kodgames.corgi.server.gameserver.email.logic.SyncEmailCount;
import com.kodgames.corgi.server.gameserver.email.util.EmailUtil;
import com.kodgames.gamedata.player.PlayerInfo;
import com.kodgames.gamedata.player.PlayerNode;

public class EmailMgr
{
	// 发送群邮件(内存+数据库)
	public static void addGroupEmail(GroupEmail email)
	{
		// 刷新内存
		GroupEmailMgr.getInstance().addGroupEmail(email);
		// 修改数据库
		EmailDB.addEmailGroup(email);
	}

	// 修改邮件附件领取状态(内存+数据库)
	public static void updatePlayerEmailStatusPicked(PlayerNode playerNode, long emailId, int statusPicked)
	{
		if (playerNode != null && playerNode.getPlayerInfo() != null)
		{
			EmailData emailData = playerNode.getPlayerInfo().getEmailData();
			emailData.updatePlayerEmailStatusPicked(emailId, statusPicked);
		}
		EmailDB.updatePlayerEmailStatusPicked(playerNode, emailId, statusPicked);
	}

	// 发送新邮件(尝试修改内存并向客户端发送有新未读邮件协议)
	public static Long addPlayerEmailSync(PlayerNode playerNode, PlayerEmail email)
	{
		EmailData emailData = null;
		// 生成并赋予emailId
		EmailUtil.genAndGivePlayerEmailId(email);
		// 如果内存中有收件人信息,修改内存
		PlayerInfo playerInfo = playerNode.getPlayerInfo();
		if (playerInfo != null)
		{
			emailData = playerInfo.getEmailData();
			int emailType = email.getEmailType();
			// 转换为大类型
			emailType = ClientServerCommon._MailType.GetTabEmailTypeFromDBEmailType(emailType);
			// 修改内存(发送邮件&&更新未读邮件数量)
			emailData.addPlayerEmail(email);
			// 如果玩家在线,通知玩家有新邮件
			if (ServerDataGS.playerManager.isOnline(playerNode.getPlayerId()))
			{
				// 通知玩家有新的未读邮件
				SyncEmailCount.synUnreadEmailCount(playerNode.getPlayerId(), emailType);
			}
		}

		// 修改数据库(发送邮件&&更新未读邮件数量)
		EmailDB.addEmailPlayer(playerNode.getPlayerId(), email);
		return email.getEmailId();

	}

	// 群邮件转换成的玩家邮件(因为是登录时触发,会在返回playerInfo之前修改未读邮件数量,所以不向客户端发送有新未读邮件协议)
	public static void addPlayerEmailFromGroupEmail(PlayerNode playerNode, PlayerEmail email, Long groupId)
	{
		EmailData emailData = playerNode.getPlayerInfo().getEmailData();
		// 生成并赋予emailId
		EmailUtil.genAndGivePlayerEmailId(email);
		int emailType = email.getEmailType();
		emailType = ClientServerCommon._MailType.GetTabEmailTypeFromDBEmailType(emailType);
		// 修改内存(发送邮件&&更新未读邮件数量)
		emailData.addPlayerEmail(email);
		emailData.getReceiveGroupIds().add(groupId);
		// 修改数据库(发送邮件&&更新未读邮件数量)
		EmailDB.addEmailPlayer(playerNode.getPlayerId(), email);
		EmailDB.updateEmailUnRead(playerNode);
	}

	// 更新某类型邮件的上次查询时间(内存+数据库)
	public static void updateEmailTypeLastQueryTime(PlayerNode playerNode, int emailType)
	{
		// 修改内存
		EmailData emailData = playerNode.getPlayerInfo().getEmailData();
		long now = System.currentTimeMillis();
		switch (emailType)
		{
			case ClientServerCommon._EmailDisplayType.Combat:
				emailData.setLastQueryCombatTime(now);
				break;
			case ClientServerCommon._EmailDisplayType.Friend:
				emailData.setLastQueryFriendTime(now);
				break;
			case ClientServerCommon._EmailDisplayType.System:
				emailData.setLastQuerySystemTime(now);
				break;
			case ClientServerCommon._EmailDisplayType.Guild:
				emailData.setLastQueryGuildTime(now);
				break;
		}
		// 修改数据库
		EmailDB.updateEmailUnRead(playerNode);
	}

}
