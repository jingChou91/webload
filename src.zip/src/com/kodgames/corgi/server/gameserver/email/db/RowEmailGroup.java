package com.kodgames.corgi.server.gameserver.email.db;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.sql.rowset.CachedRowSet;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.email.data.GroupEmailMgr;
import com.kodgames.corgi.server.gameserver.email.data.struct.Attachment;
import com.kodgames.corgi.server.gameserver.email.data.struct.GroupEmail;

public class RowEmailGroup
{
	private static final Logger logger = LoggerFactory.getLogger(RowEmailGroup.class);

	// 获得全部emailGroups,返回最大的id
	public static void loadAllGroupEmails()
	{
		long maxGroupId = 0;
		String sql = "select * from email_group where status_delete=0 order by group_id desc";
		CachedRowSet rs = null;
		try
		{
			rs = ServerDataGS.dbCluster.getGameDBClient().executeQuery(sql);

			Map<Long, GroupEmail> groupEmails = new ConcurrentHashMap<Long, GroupEmail>();
			while (rs.next())
			{
				GroupEmail email = new GroupEmail();
				long id = rs.getLong("group_id");
				maxGroupId = id > maxGroupId ? id : maxGroupId;
				email.setGroupId(id);
				email.setEmailType(rs.getInt("email_type"));
				email.setEmailTitle(rs.getString("email_title"));
				email.setEmailBody(rs.getString("email_body"));
				if (rs.getString("send_time") != null)
				{
					email.setSendTime(ServerUtil.convertTimeStringWithTimezoneToLong(TimeZoneData.getTimeZone(),
						rs.getString("send_time")));
				}
				email.setSenderName(rs.getString("sender_name"));
				email.setSenderId(rs.getInt("sender_id"));
				email.setReceiverPlayerId(rs.getInt("receiver_id"));
				email.setReceiverLevelMin(rs.getInt("receiver_level_min"));
				email.setReceiverLevelMax(rs.getInt("receiver_level_max"));

				if (rs.getString("start_time") != null)
				{
					email.setStartTime(ServerUtil.convertTimeStringWithTimezoneToLong(TimeZoneData.getTimeZone(),
						rs.getString("start_time")));
				}
				if (rs.getString("end_time") != null)
				{
					email.setEndTime(ServerUtil.convertTimeStringWithTimezoneToLong(TimeZoneData.getTimeZone(),
						rs.getString("end_time")));
				}
				if (rs.getString("create_player_start_time") != null)
				{
					email.setCreatePlayerStartTime(ServerUtil.convertTimeStringWithTimezoneToLong(TimeZoneData.getTimeZone(),
						rs.getString("create_player_start_time")));
				}
				if (rs.getString("create_player_end_time") != null)
				{
					email.setCreatePlayerEndTime(ServerUtil.convertTimeStringWithTimezoneToLong(TimeZoneData.getTimeZone(),
						rs.getString("create_player_end_time")));
				}

				List<Attachment> attachments = new ArrayList<Attachment>();
				if (rs.getInt("obj0_id") != 0)
				{
					attachments.add(new Attachment(rs.getInt("obj0_id"), rs.getInt("obj0_data1"),
						rs.getInt("obj0_data2"),  rs.getInt("obj0_count")));
					email.setAttachments(attachments);
				}
				if (rs.getInt("obj1_id") != 0)
				{
					attachments.add(new Attachment(rs.getInt("obj1_id"), rs.getInt("obj1_data1"),
						rs.getInt("obj1_data2"),  rs.getInt("obj1_count")));
					email.setAttachments(attachments);
				}
				if (rs.getInt("obj2_id") != 0)
				{
					attachments.add(new Attachment(rs.getInt("obj2_id"), rs.getInt("obj2_data1"),
						rs.getInt("obj2_data2"), rs.getInt("obj2_count")));
					email.setAttachments(attachments);
				}
				if (rs.getInt("obj3_id") != 0)
				{
					attachments.add(new Attachment(rs.getInt("obj3_id"), rs.getInt("obj3_data1"),
						rs.getInt("obj3_data2"),  rs.getInt("obj3_count")));
					email.setAttachments(attachments);
				}
				if (rs.getInt("obj4_id") != 0)
				{
					attachments.add(new Attachment(rs.getInt("obj4_id"), rs.getInt("obj4_data1"),
						rs.getInt("obj4_data2"), rs.getInt("obj4_count")));
					email.setAttachments(attachments);
				}
				if (rs.getInt("obj5_id") != 0)
				{
					attachments.add(new Attachment(rs.getInt("obj5_id"), rs.getInt("obj5_data1"),
						rs.getInt("obj5_data2"), rs.getInt("obj5_count")));
					email.setAttachments(attachments);
				}
				if (rs.getInt("obj6_id") != 0)
				{
					attachments.add(new Attachment(rs.getInt("obj6_id"), rs.getInt("obj6_data1"),
						rs.getInt("obj6_data2"), rs.getInt("obj6_count")));
					email.setAttachments(attachments);
				}
				if (rs.getInt("obj7_id") != 0)
				{
					attachments.add(new Attachment(rs.getInt("obj7_id"), rs.getInt("obj7_data1"),
						rs.getInt("obj7_data2"),  rs.getInt("obj7_count")));
					email.setAttachments(attachments);
				}

				groupEmails.put(email.getGroupId(), email);
			}
			// 将群邮件信息保存在内存中
			GroupEmailMgr.getInstance().setGroupEmails(groupEmails);
			// 当前最大群邮件id
			GroupEmailMgr.getInstance().groupEmailId.set(maxGroupId);
		}
		catch (SQLException e)
		{
			logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
		}
		finally
		{
			if (rs != null)
				try
				{
					rs.close();
				}
				catch (SQLException e)
				{
					logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
				}
		}

		long maxEmailId = 0;
		sql = "select email_id from email_player order by email_id desc limit 1";
		CachedRowSet rs_tmp = null;
		try
		{
			rs_tmp = ServerDataGS.dbCluster.getGameDBClient().executeQuery(sql);
			while (rs_tmp.next())
			{
				maxEmailId = rs_tmp.getLong("email_id");
			}
			// 当前最大玩家邮件id
			GroupEmailMgr.getInstance().playerEmailId.set(maxEmailId);
		}
		catch (SQLException e)
		{
			logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
		}
		finally
		{
			if (rs_tmp != null)
				try
				{
					rs_tmp.close();
				}
				catch (SQLException e)
				{
					logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
				}
		}

	}
}
