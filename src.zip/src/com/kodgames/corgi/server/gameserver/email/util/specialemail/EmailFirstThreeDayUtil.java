package com.kodgames.corgi.server.gameserver.email.util.specialemail;

import java.util.ArrayList;
import java.util.List;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._MailType;
import ClientServerCommon.TavernConfig._TavernType;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.server.gameserver.avatar.data.Avatar;
import com.kodgames.corgi.server.gameserver.email.util.EmailUtil;
import com.kodgames.corgi.server.gameserver.email.util.SendEmailBase;
import com.kodgames.gamedata.player.costandreward.Reward;

public class EmailFirstThreeDayUtil {
	
	public static void sendPlayerEmailsByRewardSetId(int playerId, Reward reward, long nowTime)
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
	
		//邮件类型
		int emailType = ClientServerCommon._MailType.System;
		
		//邮件内容
		String fmt = cd.get_StringsConfig().GetString("UI", "ServerText_FirstThreeDay");
		
		//邮件默认字体颜色
		fmt = EmailUtil.rightWithColor(fmt,  _MailType.System);
		
		// 邮件关键字颜色
		String email_body =	String.format(fmt);
		
		SendEmailBase.sendPlayerEmailsByRewardSetId(playerId,
			emailType,
			"first_three_day_email",
			email_body,
			nowTime,
			-1,
			"FirstThreeDay",
			-1L,
			0,
			0,
			0,
			1,
			cd,
			reward);
	}
	public static void sendPlayerEmailsBuyTavernRewardList(int playerId, List<Avatar> avatarList, long nowTime, int tavernType)
	{
		
		// 邮件关键字颜色
		List<Avatar> avatarFive = new ArrayList<>();
		for(int i = 0; i < avatarList.size(); i++)
		{
			avatarFive.add(avatarList.get(i));
			if((i+1)%5 == 0)
			{
				sendPlayerEmailsTavernFive(playerId, avatarFive, nowTime, tavernType);
				avatarFive.clear();
			}
		}
		if(avatarFive.size()>0)
		{
			
			sendPlayerEmailsTavernFive(playerId, avatarFive, nowTime, tavernType);
		}
	}
	
	private static void sendPlayerEmailsTavernFive(int playerId, List<Avatar> avatarFive, long nowTime, int tavernType)
	{
		Reward reward = new Reward();
		for(Avatar avatar : avatarFive)
		{
			reward.getAvatars().add(avatar);
		}
		ConfigDatabase cd = CfgDB.getDefautConfig();
	
		//邮件类型
		int emailType = ClientServerCommon._MailType.System;
		
		//
		String fmt = null;
		if(_TavernType.NormalTavern == tavernType)
		{
			//邮件内容
			fmt = cd.get_StringsConfig().GetString("UI", "ServerText_BuyTavernNormal");
		}
		if(_TavernType.TenTavern == tavernType)
		{
			fmt = cd.get_StringsConfig().GetString("UI", "ServerText_BuyTavernTen");
		}
		
		//邮件默认字体颜色
		fmt = EmailUtil.rightWithColor(fmt,  _MailType.System);
		
		// 邮件关键字颜色
		String email_body =	String.format(fmt);
		
		SendEmailBase.sendPlayerEmailsByRewardSetId(playerId,
			emailType,
			"buy_tavern_email",
			email_body,
			nowTime,
			-1,
			"BuyTavern",
			-1L,
			0,
			0,
			0,
			1,
			cd,
			reward);
	}
}

