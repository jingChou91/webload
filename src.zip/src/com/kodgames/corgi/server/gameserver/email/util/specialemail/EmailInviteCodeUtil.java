package com.kodgames.corgi.server.gameserver.email.util.specialemail;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._MailType;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.server.gameserver.email.util.EmailUtil;
import com.kodgames.corgi.server.gameserver.email.util.SendEmailBase;
import com.kodgames.gamedata.player.costandreward.Reward;

public class EmailInviteCodeUtil {
	public static void sendPlayerEmailsByReward(int playerId, int rmb, int gameMoney, long nowTime, String name)
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
		
		Reward reward = new Reward();
		reward.fromIdAndCount(cd.get_InviteCodeConfig().get_FirstMoneyRewardId(), gameMoney, 0, 0,0);
		//邮件类型
		int emailType = ClientServerCommon._MailType.System;
		
		//邮件内容
		String fmt = cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_Invite");
		
		//邮件默认字体颜色
		fmt = EmailUtil.rightWithColor(fmt,  _MailType.System);
		
		// 邮件关键字颜色
		String email_body =	String.format(fmt, EmailUtil.wrappedWithColor(name,  _MailType.System),  EmailUtil.wrappedWithColor(String.valueOf(rmb),  _MailType.System), EmailUtil.wrappedWithColor(String.valueOf(gameMoney),  _MailType.System));
		
		SendEmailBase.sendPlayerEmailsByRewardSetId(playerId,
			emailType,
			"invite_email",
			email_body,
			nowTime,
			-1,
			"Invite",
			-1L,
			0,
			0,
			0,
			1,
			cd,
			reward);
	}
}

