package com.kodgames.corgi.server.gameserver.email.util.specialemail;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._MailType;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.server.gameserver.email.util.EmailUtil;
import com.kodgames.corgi.server.gameserver.email.util.SendEmailBase;
import com.kodgames.gamedata.player.costandreward.Reward;

public class EmailGuildUtil
{
	/**
	 * 门派邮件
	 */
	public static void sendPlayerEmail(int playerId, String fmt, Reward reward)
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();

		// 邮件类型
		int emailType = ClientServerCommon._MailType.Guild;

		// 邮件内容
		// String fmt = cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_Zentia545545");

		// 邮件默认字体颜色
		fmt = EmailUtil.rightWithColor(fmt, _MailType.System);

		// 邮件关键字颜色
		String email_body = String.format(fmt, EmailUtil.wrappedWithColor("", _MailType.System));

		SendEmailBase.sendPlayerEmailsByRewardSetId(playerId,
			emailType,
			"Guild_email",
			email_body,
			System.currentTimeMillis(),
			-1,
			"Guild",
			-1L,
			0,
			0,
			0,
			1,
			cd,
			reward);
	}

	/**
	 * 门派邮件
	 */
	public static void sendPlayerEmail(int playerId, int type, String fmt, Reward reward)
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();

		// 邮件类型
		// int emailType = ClientServerCommon._MailType.System;
		int emailType = type;

		// 邮件内容
		// String fmt = cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_Zentia545545");

		// 邮件默认字体颜色
		fmt = EmailUtil.rightWithColor(fmt, _MailType.System);

		// 邮件关键字颜色
		String email_body = String.format(fmt, EmailUtil.wrappedWithColor("", _MailType.System));

		SendEmailBase.sendPlayerEmailsByRewardSetId(playerId,
			emailType,
			"Guild_email",
			email_body,
			System.currentTimeMillis(),
			-1,
			"Guild",
			-1L,
			0,
			0,
			0,
			1,
			cd,
			reward);
	}
}
