package com.kodgames.corgi.server.gameserver.email.db;

import java.util.ArrayList;
import java.util.List;

import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.dbclient.TableChangeEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.email.data.EmailData;
import com.kodgames.corgi.server.gameserver.email.data.struct.Attachment;
import com.kodgames.corgi.server.gameserver.email.data.struct.GroupEmail;
import com.kodgames.corgi.server.gameserver.email.data.struct.PlayerEmail;
import com.kodgames.gamedata.player.PlayerNode;

public class EmailDB
{
	// 增加群邮件
	public static void addEmailGroup(GroupEmail groupEmail)
	{
		int size = groupEmail.getAttachmentsClone().size();
		List<Attachment> tempAttachments = new ArrayList<Attachment>();
		Attachment tmp = null;

		for (int i = 0; i < 8; i++)
		{
			if (i < size)
			{
				tmp = groupEmail.getAttachmentsClone().get(i);
				tempAttachments.add(new Attachment(tmp.getId(), tmp.getData1(), tmp.getData2(), tmp.getCount()));
			}
			else
			{
				tempAttachments.add(new Attachment(0, 0, 0, 0));
			}
		}

		String emailTimeStr =
			ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(),
				groupEmail.getSendTime(),
				ServerUtil.TimeWithoutMills);
		String startTimeStr =
			ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(),
				groupEmail.getStartTime(),
				ServerUtil.TimeWithoutMills);
		String endTimeStr =
			ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(),
				groupEmail.getEndTime(),
				ServerUtil.TimeWithoutMills);
		String creatPlayerStartTimeStr =
			ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(),
				groupEmail.getCreatePlayerStartTime(),
				ServerUtil.TimeWithoutMills);
		String creatPlayerEndTimeStr =
			ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(),
				groupEmail.getCreatePlayerEndTime(),
				ServerUtil.TimeWithoutMills);

		String sqlCommand =
			String.format("INSERT INTO email_group"
				+ "(group_id,email_type, email_title , email_body , send_time , sender_name , sender_id , receiver_id , receiver_level_min, receiver_level_max ,start_time, end_time,create_player_start_time,create_player_end_time,"
				+ "obj0_id , obj0_data1 , obj0_data2, obj0_count , "
				+ "obj1_id , obj1_data1 , obj1_data2, obj1_count , "
				+ "obj2_id , obj2_data1 , obj2_data2, obj2_count , "
				+ "obj3_id , obj3_data1 , obj3_data2, obj3_count , "
				+ "obj4_id , obj4_data1 , obj4_data2, obj4_count , "
				+ "obj5_id , obj5_data1 , obj5_data2, obj5_count , "
				+ "obj6_id , obj6_data1 , obj6_data2, obj6_count , "
				+ "obj7_id , obj7_data1 , obj7_data2, obj7_count )" + "values"
				+ "(%d,%d,'%s','%s','%s','%s', %d, %d, %d, %d, '%s' , '%s', '%s' , '%s' " + ",%d,%d,%d,%d"
				+ ",%d,%d,%d,%d" + ",%d,%d,%d,%d" + ",%d,%d,%d,%d" + ",%d,%d,%d,%d" + ",%d,%d,%d,%d" + ",%d,%d,%d,%d"
				+ ",%d,%d,%d,%d" + ")",
				groupEmail.getGroupId(),
				groupEmail.getEmailType(),
				groupEmail.getEmailTitle(),
				groupEmail.getEmailBody(),
				emailTimeStr,
				groupEmail.getSenderName(),
				groupEmail.getSenderId(),
				groupEmail.getReceiverPlayerId(),
				groupEmail.getReceiverLevelMin(),
				groupEmail.getReceiverLevelMax(),
				startTimeStr,
				endTimeStr,
				creatPlayerStartTimeStr,
				creatPlayerEndTimeStr,
				tempAttachments.get(0).getId(),
				tempAttachments.get(0).getData1(),
				tempAttachments.get(0).getData2(),
				tempAttachments.get(0).getCount(),
				tempAttachments.get(1).getId(),
				tempAttachments.get(1).getData1(),
				tempAttachments.get(1).getData2(),
				tempAttachments.get(1).getCount(),
				tempAttachments.get(2).getId(),
				tempAttachments.get(2).getData1(),
				tempAttachments.get(2).getData2(),
				tempAttachments.get(2).getCount(),
				tempAttachments.get(3).getId(),
				tempAttachments.get(3).getData1(),
				tempAttachments.get(3).getData2(),
				tempAttachments.get(3).getCount(),
				tempAttachments.get(4).getId(),
				tempAttachments.get(4).getData1(),
				tempAttachments.get(4).getData2(),
				tempAttachments.get(4).getCount(),
				tempAttachments.get(5).getId(),
				tempAttachments.get(5).getData1(),
				tempAttachments.get(5).getData2(),
				tempAttachments.get(5).getCount(),
				tempAttachments.get(6).getId(),
				tempAttachments.get(6).getData1(),
				tempAttachments.get(6).getData2(),
				tempAttachments.get(6).getCount(),
				tempAttachments.get(7).getId(),
				tempAttachments.get(7).getData1(),
				tempAttachments.get(7).getData2(),
				tempAttachments.get(7).getCount());

		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(0, sqlCommand);

		tempAttachments.clear();
	}

	// 增加玩家邮件
	public static void addEmailPlayer(int playerId, PlayerEmail playerEmail)
	{
		int size = playerEmail.getAttachments().size();
		int num = 0;
		for (int i = 0; i < 8 - size; ++i)
		{

			++num;
			playerEmail.getAttachments().add(new Attachment(0, 0, 0, 0));
		}

		List<Attachment> attachments = playerEmail.getAttachments();
		String emailTimeStr =
			ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(),
				playerEmail.getSendTime(),
				ServerUtil.TimeWithoutMills);

		String sqlCommand =
			String.format("INSERT INTO email_player"
				+ "(email_id,email_type, email_title , email_body , send_time , sender_name , sender_id , receiver_id , group_id, status_picked ,status_delete, "
				+ "obj0_id , obj0_data1 , obj0_data2,  obj0_count ,"
				+ "obj1_id , obj1_data1 , obj1_data2,  obj1_count ,"
				+ "obj2_id , obj2_data1 , obj2_data2,  obj2_count ,"
				+ "obj3_id , obj3_data1 , obj3_data2,  obj3_count ,"
				+ "obj4_id , obj4_data1 , obj4_data2,  obj4_count ,"
				+ "obj5_id , obj5_data1 , obj5_data2,  obj5_count ,"
				+ "obj6_id , obj6_data1 , obj6_data2,  obj6_count ,"
				+ "obj7_id , obj7_data1 , obj7_data2,  obj7_count )" + "values" + "(%d,%d,'%s','%s','%s','%s',%d,%d,"
				+ playerEmail.getGroupId() + ",%d,%d" + ",%d,%d,%d,%d" + ",%d,%d,%d,%d" + ",%d,%d,%d,%d"
				+ ",%d,%d,%d,%d" + ",%d,%d,%d,%d" + ",%d,%d,%d,%d" + ",%d,%d,%d,%d" + ",%d,%d,%d,%d" + ")",
				playerEmail.getEmailId(),
				playerEmail.getEmailType(),
				playerEmail.getEmailTitle(),
				playerEmail.getEmailBody(),
				emailTimeStr,
				playerEmail.getSenderName(),
				playerEmail.getSenderId(),
				playerEmail.getReceiverId(),
				playerEmail.getStatusPicked(),
				playerEmail.getStatusDelete(),
				attachments.get(0).getId(),
				attachments.get(0).getData1(),
				attachments.get(0).getData2(),
				attachments.get(0).getCount(),
				attachments.get(1).getId(),
				attachments.get(1).getData1(),
				attachments.get(1).getData2(),
				attachments.get(1).getCount(),
				attachments.get(2).getId(),
				attachments.get(2).getData1(),
				attachments.get(2).getData2(),
				attachments.get(2).getCount(),
				attachments.get(3).getId(),
				attachments.get(3).getData1(),
				attachments.get(3).getData2(),
				attachments.get(3).getCount(),
				attachments.get(4).getId(),
				attachments.get(4).getData1(),
				attachments.get(4).getData2(),
				attachments.get(4).getCount(),
				attachments.get(5).getId(),
				attachments.get(5).getData1(),
				attachments.get(5).getData2(),
				attachments.get(5).getCount(),
				attachments.get(6).getId(),
				attachments.get(6).getData1(),
				attachments.get(6).getData2(),
				attachments.get(6).getCount(),
				attachments.get(7).getId(),
				attachments.get(7).getData1(),
				attachments.get(7).getData2(),
				attachments.get(7).getCount());
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId, sqlCommand);

		for (int i = 0; i < num; ++i)
		{
			playerEmail.getAttachments().remove(7 - i);
		}
	}

	// 更新邮件领取状态
	public static void updatePlayerEmailStatusPicked(PlayerNode playerNode, long emailId, int statusPicked)
	{
		String sqlCommand =
			String.format("update email_player set status_picked = %d where email_id = %d", statusPicked, emailId);
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerNode.getPlayerId(), sqlCommand);
	}

	// 更新邮件删除状态
	public static void updatePlayerEmailStatusDelete(PlayerNode playerNode, List<Long> emailIds, int statusPicked)
	{
		StringBuilder sql = new StringBuilder();
		sql.append("update email_player set status_delete = 1 where email_id in ( ");
		sql.append(emailIds.get(0));
		for (int i = 1; i < emailIds.size(); i++)
		{
			sql.append(" , " + emailIds.get(i));
		}
		sql.append(" )");
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerNode.getPlayerId(), sql.toString());
	}

	// 更新群邮件删除状态
	public static void updateGroupEmailStatusDelete(List<Long> emailIds)
	{
		StringBuilder sql = new StringBuilder();
		sql.append("update email_group set status_delete = 1 where group_id in ( ");
		sql.append(emailIds.get(0));
		for (int i = 1; i < emailIds.size(); i++)
		{
			sql.append(" , " + emailIds.get(i));
		}
		sql.append(" )");
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(0, sql.toString());
	}

	// 更新未读邮件信息
	public static void updateEmailUnRead(PlayerNode playerNode)
	{
		EmailData emailData = playerNode.getPlayerInfo().getEmailData();
		String sqlCommand =
			String.format("replace into email_un_read (player_id,last_query_combat_time,last_query_friend_time,last_query_system_time,last_query_guild_time,receive_group_ids) VALUES (%d,%d,%d,%d,%d,'%s')",
				playerNode.getPlayerId(),
				emailData.getLastQueryCombatTime(),
				emailData.getLastQueryFriendTime(),
				emailData.getLastQuerySystemTime(),
				emailData.getLastQueryGuildTime(),
				ServerUtil.hashSetToString(emailData.getReceiveGroupIds()));
		ServerDataGS.dbCluster.getGameDBClient()
			.executeAsynchronousUpdate(TableChangeEvent.getKey(playerNode.getPlayerId(),
				TableChangeEvent.EMAIL_UN_READ_UPDATEEMAILUNREAD),
				playerNode.getPlayerId(),
				sqlCommand);
	}
}
