package com.kodgames.corgi.server.gameserver.email.util.specialemail;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._MailType;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.server.gameserver.email.util.EmailUtil;
import com.kodgames.corgi.server.gameserver.email.util.SendEmailBase;
import com.kodgames.gamedata.player.costandreward.Reward;

public class EmailZentiaUtil {
	public static void sendPlayerEmailsByReward(int playerId, int rank, Reward reward, long nowTime)
		{
			ConfigDatabase cd = CfgDB.getDefautConfig();
		
			//邮件类型
			int emailType = ClientServerCommon._MailType.System;
			
			//邮件内容
			String fmt = cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_Zentia");
			
			//邮件默认字体颜色
			fmt = EmailUtil.rightWithColor(fmt,  _MailType.System);
			
			// 邮件关键字颜色
			String email_body =	String.format(fmt, EmailUtil.wrappedWithColor(String.valueOf(rank),  _MailType.System));
			
			SendEmailBase.sendPlayerEmailsByRewardSetId(playerId,
				emailType,
				"zentia_email",
				email_body,
				nowTime,
				-1,
				"Zentia",
				-1L,
				0,
				0,
				0,
				1,
				cd,
				reward);
		}
}

