package com.kodgames.corgi.server.gameserver.email.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import com.kodgames.corgi.server.gameserver.email.data.struct.GroupEmail;
import com.kodgames.corgi.server.gameserver.email.db.EmailDB;
import com.kodgames.corgi.server.gameserver.email.db.RowEmailGroup;

public class GroupEmailMgr
{

	public AtomicLong groupEmailId = new AtomicLong(0);
	public AtomicLong playerEmailId = new AtomicLong(0);

	// groupId_groupInfo
	private Map<Long, GroupEmail> groupEmails = new ConcurrentHashMap<Long, GroupEmail>();// 内存中系统邮件

	// 单例模式
	private static GroupEmailMgr groupEmailMgr = new GroupEmailMgr();

	private GroupEmailMgr()
	{
	}

	public synchronized static GroupEmailMgr getInstance()
	{
		return groupEmailMgr;
	}

	public synchronized boolean init()
	{
		RowEmailGroup.loadAllGroupEmails();
		return true;
	}

	// 增加群邮件(多封)
	public void addGroupEmails(List<GroupEmail> emails)
	{
		for (GroupEmail email : emails)
		{
			addGroupEmail(email);
		}

	}

	// 增加群邮件(一封)
	public void addGroupEmail(GroupEmail email)
	{
		if (!groupEmails.containsKey(email.getGroupId()))
		{
			groupEmails.put(email.getGroupId(), email);
		}
	}

	/**
	 * 获取所有群邮件的深克隆
	 */
	public Map<Long, GroupEmail> getCopyGroupEmails()
	{
		Map<Long, GroupEmail> copyGroupEmails = new ConcurrentHashMap<Long, GroupEmail>();
		for (Map.Entry<Long, GroupEmail> entry : groupEmails.entrySet())
		{
			copyGroupEmails.put(entry.getKey(), entry.getValue().copy());
		}
		return copyGroupEmails;
	}
	
	/**
	 * 删除群邮件
	 */
	public boolean deleteGroupEmail(long emailId)
	{
		List<Long> emailIds = new ArrayList<Long>();
		emailIds.add(emailId);
		if(groupEmails.containsKey(emailId))
		{
			groupEmails.remove(emailId);
			EmailDB.updateGroupEmailStatusDelete(emailIds);
			return true;
		}
		return false;
	}

//	public Map<Long, GroupEmail> getGroupEmails()
//	{
//		return groupEmails;
//	}

	public void setGroupEmails(Map<Long, GroupEmail> groupEmails)
	{
		this.groupEmails = groupEmails;
	}

}
