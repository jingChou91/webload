package com.kodgames.corgi.server.gameserver.email.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.server.gameserver.email.data.EmailMgr;
import com.kodgames.corgi.server.gameserver.email.data.GroupEmailMgr;
import com.kodgames.corgi.server.gameserver.email.data.struct.Attachment;
import com.kodgames.corgi.server.gameserver.email.data.struct.GroupEmail;
import com.kodgames.corgi.server.gameserver.email.data.struct.PlayerEmail;
import com.kodgames.corgi.server.gameserver.email.db.EmailDB;
import com.kodgames.gamedata.commonconfig.CommonConfigMgr;
import com.kodgames.gamedata.player.PlayerNode;

public class EmailUtil
{
	private static final Logger logger = LoggerFactory.getLogger(EmailUtil.class);

	// 删除多余邮件
	public static List<Long> testAndDeletePlayerEmail(PlayerNode palyerNode, int emailType)
	{
		int maxShowSize = CommonConfigMgr.getInstance().getCfg().getEmailMaxShowNum();
		int maxLiveSize = CommonConfigMgr.getInstance().getCfg().getEmailMaxLiveNum();
		Map<Long, PlayerEmail> playerEmails =
			palyerNode.getPlayerInfo().getEmailData().getPlayerEmailsByEmailType(emailType);
		// 将邮件分为三类
		Map<Long, PlayerEmail> normalEmails = new HashMap<Long, PlayerEmail>();// 无附件邮件|无需操作邮件
		Map<Long, PlayerEmail> pickedEmails = new HashMap<Long, PlayerEmail>();// 附件已领取邮件|已操作邮件
		Map<Long, PlayerEmail> unPickedEmails = new HashMap<Long, PlayerEmail>();// 附件未领取邮件|未操作邮件

		// 显示给客户端的邮件和待删除的邮件
		List<Long> showEmailIds = new ArrayList<Long>();
		List<Long> deleteEmailIds = new ArrayList<Long>();
		if (playerEmails.size() > maxShowSize)
		{
			if (emailType == ClientServerCommon._EmailDisplayType.Friend)
			{
				for (Map.Entry<Long, PlayerEmail> entry : playerEmails.entrySet())
				{
					PlayerEmail email = entry.getValue();
					if (email.getEmailType() != ClientServerCommon._MailType.AddFriendRequrst)
					{
						normalEmails.put(email.getEmailId(), email);
						showEmailIds.add(email.getEmailId());
					}
					else if (email.getEmailType() == ClientServerCommon._MailType.AddFriendRequrst
						&& email.getStatusPicked() != 0)
					{
						pickedEmails.put(email.getEmailId(), email);
						showEmailIds.add(email.getEmailId());
					}
					else if (email.getEmailType() == ClientServerCommon._MailType.AddFriendRequrst
						&& email.getStatusPicked() == 0)
					{
						unPickedEmails.put(email.getEmailId(), email);
						showEmailIds.add(email.getEmailId());
					}
				}
			}
			else
			{
				for (Map.Entry<Long, PlayerEmail> entry : playerEmails.entrySet())
				{
					PlayerEmail email = entry.getValue();

					if (email.getAttachments().size() == 0)
					{
						normalEmails.put(email.getEmailId(), email);
						showEmailIds.add(email.getEmailId());
					}
					else if (email.getAttachments().size() > 0 && email.getStatusPicked() == 1)
					{
						pickedEmails.put(email.getEmailId(), email);
						showEmailIds.add(email.getEmailId());
					}
					else if (email.getAttachments().size() > 0 && email.getStatusPicked() == 0)
					{
						unPickedEmails.put(email.getEmailId(), email);
						showEmailIds.add(email.getEmailId());
					}
				}
			}
			// 按邮件删除逻辑进行删除
			while (showEmailIds.size() > maxShowSize)
			{
				Long emailId = 0L;
				if (normalEmails.size() > 0)
				{
					emailId = getDeleteEmailIdBySendTime(normalEmails);
					normalEmails.remove(emailId);
				}
				else if (pickedEmails.size() > 0)
				{
					emailId = getDeleteEmailIdBySendTime(pickedEmails);
					pickedEmails.remove(emailId);
				}
				else
				{
					emailId = getDeleteEmailIdBySendTime(unPickedEmails);
					unPickedEmails.remove(emailId);
				}
				showEmailIds.remove(emailId);
				deleteEmailIds.add(emailId);
			}
			if (playerEmails.size() > maxLiveSize)
			{
				for (Long deleteEmailId : deleteEmailIds)
				{
					playerEmails.remove(deleteEmailId);
				}
				EmailDB.updatePlayerEmailStatusDelete(palyerNode, deleteEmailIds, 1);
			}
		}
		else
		{
			for (Map.Entry<Long, PlayerEmail> entry : playerEmails.entrySet())
			{
				showEmailIds.add(entry.getKey());
			}
		}
		return showEmailIds;
	}

	// 根据邮件发送时间,获取一封待删除邮件的id
	public static Long getDeleteEmailIdBySendTime(Map<Long, PlayerEmail> playerEmails)
	{
		Long deleteEmailId = 0L;
		Long minTime = System.currentTimeMillis();
		boolean hasInit = false;
		for (Map.Entry<Long, PlayerEmail> entry : playerEmails.entrySet())
		{
			if (entry.getValue().getSendTime() < minTime || !hasInit)
			{
				hasInit = true;
				minTime = entry.getValue().getSendTime();
				deleteEmailId = entry.getValue().getEmailId();
			}
		}
		return deleteEmailId;
	}

	/*
	 * 删除曾经收到过的超过四个月的群邮件id (对应email_un_read表中receive_group_ids字段内的值)
	 */
	private static void deleteFourMonthGroupEmailReceiveId(PlayerNode playerNode)
	{
		final long fourMonth = 4 * 30 * 24 * 3600 * 1000L; // 四个月(120天)
		// 已经接收过的群邮件id
		HashSet<Long> receiveGroupIds = playerNode.getPlayerInfo().getEmailData().getReceiveGroupIds();
		int receiveGroupCount = receiveGroupIds.size();
		// 所有当前可接收的群邮件id
		Map<Long, GroupEmail> groupEmails = GroupEmailMgr.getInstance().getCopyGroupEmails();
		Iterator<Long> iterator = receiveGroupIds.iterator();
		while (iterator.hasNext())
		{
			// null表示群邮件已被删除.........邮件已经发送的时间（系统时间减去发送时间）
			GroupEmail groupEmail = groupEmails.get(iterator.next());
			if (groupEmail == null || (System.currentTimeMillis() - groupEmail.getSendTime()) >= fourMonth)
			{
				iterator.remove();
			}
		}

		// 数量发生了变化
		if (receiveGroupCount != receiveGroupIds.size())
		{
			// 更新数据库
			EmailDB.updateEmailUnRead(playerNode);
		}
	}

	// 判断是否有群邮件需要接收,同时接收群邮件
	public static void ReceiveGroupEmail(PlayerNode playerNode)
	{
		try
		{
			final long threeMonth = 3 * 30 * 24 * 3600 * 1000L; // 三个月(90天)
			// 删除曾经收到过的超过四个月的群邮件id
			deleteFourMonthGroupEmailReceiveId(playerNode);
			// 已经接收过的群邮件id
			HashSet<Long> receiveGroupIds = playerNode.getPlayerInfo().getEmailData().getReceiveGroupIds();
			int playerLevel = playerNode.getGamePlayer().getLevel();
			long accountCreateTime = playerNode.getPlayerInfo().getClientLoginMessage().getCreateTime();
			// 所有当前可接收的群邮件id
			Map<Long, GroupEmail> groupEmails = GroupEmailMgr.getInstance().getCopyGroupEmails();
			// 所有当前可接收的群邮件 id_是否满足接收条件
			Map<Long, Boolean> unReadGroupIds = new HashMap<Long, Boolean>();
			for (Map.Entry<Long, GroupEmail> entry : groupEmails.entrySet())
			{
				unReadGroupIds.put(entry.getKey(), true);
			}
			// 剔除已经接收的群邮件
			for (Map.Entry<Long, Boolean> entry : unReadGroupIds.entrySet())
			{
				if (receiveGroupIds.contains(entry.getKey()))
				{
					entry.setValue(false);
				}
			}
			// 判断未接收的群邮件是否满足接收条件,如果满足,发送邮件
			if (unReadGroupIds.size() > 0)
			{
				// 将unReadGroupIds中不满足接收条件的删除
				EmailUtil.getSatisfyGroupEmail(unReadGroupIds, groupEmails, playerLevel, accountCreateTime);

				for (Map.Entry<Long, Boolean> entry : unReadGroupIds.entrySet())
				{

					if (entry.getValue())
					{
						// 邮件已经发送的时间（系统时间减去发送时间）
						GroupEmail groupEmail = groupEmails.get(entry.getKey());
						if (groupEmail == null)
						{
							continue;
						}
						long alreadySendTime = System.currentTimeMillis() - groupEmail.getSendTime();
						// 将大于三个月的设为false（不再收取超过三个月的群邮件）
						if (alreadySendTime >= threeMonth)
						{
							entry.setValue(false);
							continue;
						}
						PlayerEmail email = new PlayerEmail(groupEmail, playerNode);
						// 发新邮件
						EmailMgr.addPlayerEmailFromGroupEmail(playerNode, email, entry.getKey());
					}

				}
			}
		}
		catch (Exception e)
		{
			logger.error("{}", ExceptionUtils.getStackTrace(e));
		}
	}

	// 获取玩家满足接收条件的群邮件
	public static void getSatisfyGroupEmail(Map<Long, Boolean> unReadGroupIds, Map<Long, GroupEmail> groupEmails,
		int playerLevel, long createPlayerDataTime)
	{
		for (Map.Entry<Long, Boolean> entry : unReadGroupIds.entrySet())
		{
			GroupEmail email = groupEmails.get(entry.getKey());
			if (email == null)
			{
				continue;
			}
			int levelMax = email.getReceiverLevelMax();
			int levelMin = email.getReceiverLevelMin();
			long startTime = email.getStartTime();
			long endTime = email.getEndTime();
			long createStartTime = email.getCreatePlayerStartTime();
			long createEndTime = email.getCreatePlayerEndTime();
			Date dt = new Date();

			if (!(playerLevel >= levelMin && playerLevel <= levelMax && dt.getTime() >= startTime && createPlayerDataTime >= createStartTime))
			{
				entry.setValue(false);
			}
			if (endTime != 0 && dt.getTime() > endTime)
			{
				entry.setValue(false);
			}
			if (createEndTime != 0 && createPlayerDataTime > createEndTime)
			{
				entry.setValue(false);
			}
		}
	}

	// 将附件分为size个一组
	public static List<List<Attachment>> turnToGroup(List<Attachment> attachments)
	{
		int size = 8;
		List<List<Attachment>> attachmentsList = new ArrayList<List<Attachment>>();
		for (int i = 0; i * size < attachments.size(); i++)
		{
			// 一组附件
			List<Attachment> attachments_tmp = new ArrayList<Attachment>();
			for (int j = 0; j < size; j++)
			{
				int obj_index = i * size + j;
				if (obj_index < attachments.size())
				{
					attachments_tmp.add(attachments.get(obj_index));
				}

			}
			attachmentsList.add(attachments_tmp);
		}
		return attachmentsList;
	}

	// 生成并赋予emailId
	public static void genAndGivePlayerEmailId(PlayerEmail email)
	{
		long emailId = GroupEmailMgr.getInstance().playerEmailId.addAndGet(1);
		email.setEmailId(emailId);
	}

	// 生成并赋予emailId
	public static void genAndGiveGroupEmailId(GroupEmail email)
	{
		long groupId = GroupEmailMgr.getInstance().groupEmailId.addAndGet(1);
		email.setGroupId(groupId);
	}

	// 为字符串添加颜色
	public static String wrappedWithColor(String text, int type)
	{
		return QualityColor.wrappedWithColor(text, type);
	}

	// 为字符串添加颜色
	public static String rightWithColor(String text, int type)
	{
		return QualityColor.rightWithColor(text, type);
	}

	// private static ConfigDatabase cd = CfgDB.getDefautConfig();
	public enum QualityColor
	{
		DEFAULT(1.0f, 1.0f, 1.0f, 1.0f), EMAIL_IMPORTANT(1.0f, 0.93f, 0.816f, 1.0f), EMAIL_COMMON(0.941f, 0.816f,
			0.557f, 1.0f);

		private String colorStr = "RGBA(1,1,1,1)";

		private QualityColor(float r, float g, float b, float a)
		{
			this.colorStr = "RGBA(" + r + "," + g + "," + b + "," + a + ")";
		}

		public String getColorString()
		{
			return this.colorStr;
		}

		public static String rightWithColor(String resourceName, int type)
		{
			return EMAIL_COMMON.getColorString() + resourceName;
		}

		public static String wrappedWithColor(String resourceName, int type)
		{
			// if (type == ClientServerCommon._MailType.CombatArena)
			// {
			return EMAIL_IMPORTANT.getColorString() + resourceName + EMAIL_COMMON.getColorString();
			// }
			// return "";

		}
	}

}
