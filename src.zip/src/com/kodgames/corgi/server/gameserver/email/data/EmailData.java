package com.kodgames.corgi.server.gameserver.email.data;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import com.kodgames.corgi.server.gameserver.email.data.struct.PlayerEmail;

public class EmailData
{
	private long lastQuerySystemTime;
	private long lastQueryFriendTime;
	private long lastQueryCombatTime;
	private long lastQueryGuildTime;

	// groupIds
	private HashSet<Long> receiveGroupIds = new HashSet<Long>(); // 已经接受的群邮件id

	// id_PlayerEmail
	private Map<Long, PlayerEmail> combatEmails = new HashMap<Long, PlayerEmail>();
	private Map<Long, PlayerEmail> friendEmails = new HashMap<Long, PlayerEmail>();
	private Map<Long, PlayerEmail> systemEmails = new HashMap<Long, PlayerEmail>();
	private Map<Long, PlayerEmail> guildEmails = new HashMap<Long, PlayerEmail>();

	public int getUnReadEmailCount(int emailType)
	{
		int unReadCount = 0;
		switch (emailType)
		{
			case ClientServerCommon._EmailDisplayType.Combat:
				for (Map.Entry<Long, PlayerEmail> entry : combatEmails.entrySet())
				{
					if (entry.getValue().getSendTime() > lastQueryCombatTime)
					{
						unReadCount++;
					}
				}
				break;
			case ClientServerCommon._EmailDisplayType.Friend:
				for (Map.Entry<Long, PlayerEmail> entry : friendEmails.entrySet())
				{
					if (entry.getValue().getSendTime() > lastQueryFriendTime)
					{
						unReadCount++;
					}
				}
				break;
			case ClientServerCommon._EmailDisplayType.System:
				for (Map.Entry<Long, PlayerEmail> entry : systemEmails.entrySet())
				{
					if (entry.getValue().getSendTime() > lastQuerySystemTime)
					{
						unReadCount++;
					}
				}
				break;
			case ClientServerCommon._EmailDisplayType.Guild:
				for (Map.Entry<Long, PlayerEmail> entry : guildEmails.entrySet())
				{
					if (entry.getValue().getSendTime() > lastQueryGuildTime)
					{
						unReadCount++;
					}
				}
				break;
			default:
				break;
		}
		return unReadCount;
	}

	public boolean hasUnDoInviteEmial(Integer playerId)
	{
		for (Map.Entry<Long, PlayerEmail> entry : friendEmails.entrySet())
		{
			PlayerEmail email = entry.getValue();
			if (email.getSenderId() == playerId
				&& email.getEmailType() == ClientServerCommon._MailType.AddFriendRequrst
				&& email.getStatusPicked() == 0)
			{
				return true;
			}
		}
		return false;
	}

	public long getUnDoInviteEmialId(Integer playerId)
	{
		for (Map.Entry<Long, PlayerEmail> entry : friendEmails.entrySet())
		{
			PlayerEmail email = entry.getValue();
			if (email.getSenderId() == playerId
				&& email.getEmailType() == ClientServerCommon._MailType.AddFriendRequrst
				&& email.getStatusPicked() == 0)
			{
				return email.getEmailId();
			}
		}
		return -1;
	}

	// 获取上次查询时间
	public Long getLastQueryTime(int emailType)
	{
		switch (emailType)
		{
			case ClientServerCommon._EmailDisplayType.Combat:
				return lastQueryCombatTime;
			case ClientServerCommon._EmailDisplayType.Friend:
				return lastQueryFriendTime;
			case ClientServerCommon._EmailDisplayType.System:
				return lastQuerySystemTime;
			case ClientServerCommon._EmailDisplayType.Guild:
				return lastQueryGuildTime;
			default:
				return 0L;
		}
	}

	// 获取指定类型的邮件
	public Map<Long, PlayerEmail> getPlayerEmailsByEmailType(int emailType)
	{
		switch (emailType)
		{
			case ClientServerCommon._EmailDisplayType.Combat:
				return combatEmails;
			case ClientServerCommon._EmailDisplayType.Friend:
				return friendEmails;
			case ClientServerCommon._EmailDisplayType.System:
				return systemEmails;
			case ClientServerCommon._EmailDisplayType.Guild:
				return guildEmails;
			default:
				return null;
		}
	}

	// 增加一封新邮件
	public void addPlayerEmail(PlayerEmail email)
	{
		int bigEmailType = ClientServerCommon._MailType.GetTabEmailTypeFromDBEmailType(email.getEmailType());
		switch (bigEmailType)
		{
			case ClientServerCommon._EmailDisplayType.Combat:
				combatEmails.put(email.getEmailId(), email);
				break;
			case ClientServerCommon._EmailDisplayType.Friend:
				friendEmails.put(email.getEmailId(), email);
				break;
			case ClientServerCommon._EmailDisplayType.System:
				systemEmails.put(email.getEmailId(), email);
				break;
			case ClientServerCommon._EmailDisplayType.Guild:
				guildEmails.put(email.getEmailId(), email);
				break;
			default:
				break;
		}
	}

	// 修改邮件附件领取状态
	public boolean updatePlayerEmailStatusPicked(long emailId, int statusPicked)
	{
		PlayerEmail playerEmail = getPlayerEmailById(emailId);
		if (playerEmail != null)
		{
			playerEmail.setStatusPicked(statusPicked);
			return true;
		}
		return false;
	}

	// 根据Id查询邮件
	public PlayerEmail getPlayerEmailById(long emailId)
	{
		for (PlayerEmail email : combatEmails.values())
		{
			if (email.getEmailId() == emailId)
			{
				return email;
			}
		}
		for (PlayerEmail email : friendEmails.values())
		{
			if (email.getEmailId() == emailId)
			{
				return email;
			}
		}
		for (PlayerEmail email : systemEmails.values())
		{
			if (email.getEmailId() == emailId)
			{
				return email;
			}
		}
		for (PlayerEmail email : guildEmails.values())
		{
			if (email.getEmailId() == emailId)
			{
				return email;
			}
		}
		return null;
	}

	public long getLastQuerySystemTime()
	{
		return lastQuerySystemTime;
	}

	public void setLastQuerySystemTime(long lastQuerySystemTime)
	{
		this.lastQuerySystemTime = lastQuerySystemTime;
	}

	public long getLastQueryFriendTime()
	{
		return lastQueryFriendTime;
	}

	public void setLastQueryFriendTime(long lastQueryFriendTime)
	{
		this.lastQueryFriendTime = lastQueryFriendTime;
	}

	public long getLastQueryCombatTime()
	{
		return lastQueryCombatTime;
	}

	public void setLastQueryCombatTime(long lastQueryCombatTime)
	{
		this.lastQueryCombatTime = lastQueryCombatTime;
	}

	public Map<Long, PlayerEmail> getCombatEmails()
	{
		return combatEmails;
	}

	public void setCombatEmails(Map<Long, PlayerEmail> combatEmails)
	{
		this.combatEmails = combatEmails;
	}

	public Map<Long, PlayerEmail> getFriendEmails()
	{
		return friendEmails;
	}

	public void setFriendEmails(Map<Long, PlayerEmail> friendEmails)
	{
		this.friendEmails = friendEmails;
	}

	public Map<Long, PlayerEmail> getSystemEmails()
	{
		return systemEmails;
	}

	public void setSystemEmails(Map<Long, PlayerEmail> systemEmails)
	{
		this.systemEmails = systemEmails;
	}

	public HashSet<Long> getReceiveGroupIds()
	{
		return receiveGroupIds;
	}

	public void setReceiveGroupIds(HashSet<Long> receiveGroupIds)
	{
		this.receiveGroupIds = receiveGroupIds;
	}

	public long getLastQueryGuildTime()
	{
		return lastQueryGuildTime;
	}

	public void setLastQueryGuildTime(long lastQueryGuildTime)
	{
		this.lastQueryGuildTime = lastQueryGuildTime;
	}

	public Map<Long, PlayerEmail> getGuildEmails()
	{
		return guildEmails;
	}

	public void setGuildEmails(Map<Long, PlayerEmail> guildEmails)
	{
		this.guildEmails = guildEmails;
	}

}