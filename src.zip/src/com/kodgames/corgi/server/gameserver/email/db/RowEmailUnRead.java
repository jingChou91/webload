package com.kodgames.corgi.server.gameserver.email.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashSet;

import javax.sql.rowset.CachedRowSet;

import com.kodgames.corgi.server.gameserver.email.data.EmailData;
import com.kodgames.gamedata.dbcommon.DBEasy;
import com.kodgames.gamedata.player.PlayerNode;

public class RowEmailUnRead
{
	// 查询私人邮件，所有未删除的
	public static void selectPrivate(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs,
		PlayerNode playerNode)
		throws SQLException
	{

		String sql = "select * from email_un_read where player_id=?";
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, new Object[] {playerNode.getPlayerId()});

		EmailData emailData = playerNode.getPlayerInfo().getEmailData();

		if (vrs[queryIndex] != null)
		{

			CachedRowSet rs = vrs[queryIndex];
			if (rs.next())
			{
				emailData.setLastQueryCombatTime(rs.getLong("last_query_combat_time"));
				emailData.setLastQueryFriendTime(rs.getLong("last_query_friend_time"));
				emailData.setLastQuerySystemTime(rs.getLong("last_query_system_time"));
				emailData.setLastQueryGuildTime(rs.getLong("last_query_guild_time"));

				String receiveGroupIds = rs.getString("receive_group_ids");
				if (receiveGroupIds != null && !receiveGroupIds.trim().equals(""))
				{
					String[] groupIds = receiveGroupIds.split(",");
					HashSet<Long> list = new HashSet<>();
					// 将字符串数组转为list
					for (int j = 0; j < groupIds.length; j++)
					{
						Long groupId = Long.parseLong(groupIds[j]);
						list.add(groupId);
					}
					emailData.setReceiveGroupIds(list);
				}

			}
		}
	}
}
