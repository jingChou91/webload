package com.kodgames.corgi.server.gameserver.email.util.specialemail;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._MailType;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.server.gameserver.email.util.EmailUtil;
import com.kodgames.corgi.server.gameserver.email.util.SendEmailBase;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Reward;

public class FiveStarEvaluateEmailUtil {
	public static void sendPlayerEmailsByRewardSetId(PlayerNode playerNode, int receiverId,
			int rewardSetId, int count, Reward reward)
		{
			ConfigDatabase cd = CfgDB.getDefautConfig();
		
			//邮件类型
			int emailType = ClientServerCommon._MailType.System;
			
			//邮件内容
			String fmt = cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_GiveFiveStarsEvaluate");
			
			//邮件默认字体颜色
			fmt = EmailUtil.rightWithColor(fmt,  _MailType.System);
			
			// 邮件关键字颜色
			String email_body =
				String.format(fmt, EmailUtil.wrappedWithColor(playerNode.getGamePlayer().getFixName(),  _MailType.System));
			
			SendEmailBase.sendPlayerEmailsByRewardSetId(receiverId,
				emailType,
				"five_star_reward_email",
				email_body,
				System.currentTimeMillis(),
				-1,
				"FiveStarEvaluate",
				-1L,
				0,
				0,
				rewardSetId,
				count,
				cd,
				reward);
		}
}
