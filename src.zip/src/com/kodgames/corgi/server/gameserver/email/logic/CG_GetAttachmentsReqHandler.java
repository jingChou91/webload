package com.kodgames.corgi.server.gameserver.email.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_GetAttachmentsReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_GetAttachmentsRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.email.data.EmailData;
import com.kodgames.corgi.server.gameserver.email.data.EmailMgr;
import com.kodgames.corgi.server.gameserver.email.data.struct.PlayerEmail;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class CG_GetAttachmentsReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_GetAttachmentsReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_GetAttachmentsReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_GetAttachmentsReq request = (CG_GetAttachmentsReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_GetAttachmentsRes.Builder builder = GC_GetAttachmentsRes.newBuilder();
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_GET_ATTACHMENTS_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_GET_ATTACHMENTS_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		long emailId = request.getEmailId();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_GET_ATTACHMENTS_LOAD_PLAYER_FAILD;
					break;
				}
				EmailData emailData = playerNode.getPlayerInfo().getEmailData();

				PlayerEmail playerEmail = emailData.getPlayerEmailById(emailId);
				if (null == playerEmail)
				{
					result = ClientProtocols.E_GAME_GET_ATTACHMENTS_NOT_HAVE_EMAIL_INFO;
					break;
				}
				// 邮件是否有附件
				if (!playerEmail.isHasAttachment())
				{
					result = ClientProtocols.E_GAME_GET_ATTACHMENTS_EMAIL_NOT_HAVE_ATTACHMENT;
					break;
				}
				// 附件是否已经收取
				if (playerEmail.getStatusPicked() != 0)
				{
					result = ClientProtocols.E_GAME_GET_ATTACHMENTS_EMAIL_ALREADY_PICKED;
					break;
				}
				// 获取邮件附件
				Reward reward = playerEmail.getReward();
				CostAndRewardAndSync crsForReward = new CostAndRewardAndSync();
				crsForReward.mergeReward(reward);
				// 修改内存
				CostAndRewardManager.addReward(playerNode, reward, cd, KodLogEvent.Email_GetAttachments);
				crsForClient.megerCostAndRewardAndSync(crsForReward);
				// 更改邮件状态
				EmailMgr.updatePlayerEmailStatusPicked(playerNode, emailId, 1);

				// 让客户端强制刷新(修复线上bug用)
				SyncEmailCount.synUnreadEmailFixCount(playerId, playerEmail.getEmailType());

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}
		builder.setResult(result);
		builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
