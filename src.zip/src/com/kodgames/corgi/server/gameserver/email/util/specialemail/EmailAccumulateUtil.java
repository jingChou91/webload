package com.kodgames.corgi.server.gameserver.email.util.specialemail;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._MailType;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.server.gameserver.email.util.EmailUtil;
import com.kodgames.corgi.server.gameserver.email.util.SendEmailBase;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Reward;

public class EmailAccumulateUtil {
	public static void sendPlayerEmailsByRewardSetId(PlayerNode playerNode, 
			int rewardSetId, int count, Reward reward, int itemMoney, long nowTime)
		{
			ConfigDatabase cd = CfgDB.getDefautConfig();
		
			//邮件类型
			int emailType = ClientServerCommon._MailType.System;
			
			//邮件内容
			String fmt = cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_Accumulate");
			
			//邮件默认字体颜色
			fmt = EmailUtil.rightWithColor(fmt,  _MailType.System);
			
			// 邮件关键字颜色
			String email_body =
				String.format(fmt, EmailUtil.wrappedWithColor(String.valueOf(itemMoney),  _MailType.System), EmailUtil.wrappedWithColor(String.valueOf(count),  _MailType.System));
			
			SendEmailBase.sendPlayerEmailsByRewardSetId(playerNode.getPlayerId(),
				emailType,
				"accumulate_email",
				email_body,
				nowTime,
				-1,
				"Accumulate",
				-1L,
				0,
				0,
				rewardSetId,
				count,
				cd,
				reward);
		}
}

