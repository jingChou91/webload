package com.kodgames.corgi.server.gameserver.email.util.specialemail;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.MarvellousAdventureConfig.RewardEvent;

import com.kodgames.corgi.server.gameserver.email.util.EmailUtil;
import com.kodgames.corgi.server.gameserver.email.util.SendEmailBase;
import com.kodgames.gamedata.player.costandreward.Reward;

public class EmailPickDelayRewardUtil
{
	private static Logger logger = LoggerFactory.getLogger(EmailPickDelayRewardUtil.class);
	public static void sendPlayerEmailsByRewardForPickDelayReward(int receiverId, int eventId, ConfigDatabase cd)
	{
		try
		{
			Object object = cd.get_MarvellousAdventureConfig().GetEventById(eventId);
			if(object!=null && object instanceof RewardEvent)
			{
				RewardEvent rewardEvent = (RewardEvent)object;
				
				Reward reward = new Reward();
				for(int i = 0; i < rewardEvent.Get_DelayRewardsCount(); ++i)
				{
					ClientServerCommon.Reward rewardCfg = rewardEvent.Get_DelayRewardsByIndex(i);
					reward.megerReward(new Reward().fromClientServerCommon(rewardCfg));
				}
				
				String emailBody = cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_PickDelayReward");
				// 邮件字体默认颜色
				emailBody = EmailUtil.rightWithColor(emailBody, ClientServerCommon._MailType.System);
				SendEmailBase.sendPlayerEmailsByRewardSetId(receiverId,
						ClientServerCommon._MailType.System,
						"PickDelayReward",
						emailBody,
						System.currentTimeMillis(),
						-1,
						"PickDelayReward",
						-1L,
						0,
						0,
						0,
						1,
						cd,
						reward);
			}
		}
		catch(Exception e)
		{
			logger.error("send DelayReward error,playerId ={}, eventId={}", receiverId, eventId);
		}
		
	}

}
