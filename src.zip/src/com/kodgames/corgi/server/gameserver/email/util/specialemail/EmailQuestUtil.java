package com.kodgames.corgi.server.gameserver.email.util.specialemail;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.server.gameserver.email.util.EmailUtil;
import com.kodgames.corgi.server.gameserver.email.util.SendEmailBase;
import com.kodgames.gamedata.player.costandreward.Reward;

public class EmailQuestUtil
{
	public static void sendPlayerEmailsByRewardForQuest(int receiverId, Reward reward, ConfigDatabase cd, String questName)
	{
		
		String emailBody = cd.get_StringsConfig().GetString("UI", "ServerText_EmailBody_Repeated_Quest_Finished");	
		// 邮件字体默认颜色
		emailBody = EmailUtil.rightWithColor(emailBody, ClientServerCommon._MailType.System);
		
		emailBody = String.format(emailBody, EmailUtil.wrappedWithColor(questName, ClientServerCommon._MailType.System));
		SendEmailBase.sendPlayerEmailsByRewardSetId(receiverId,
			ClientServerCommon._MailType.System,
			"quest_email",
			emailBody,
			System.currentTimeMillis(),
			-1,
			"SYS",
			-1L,
			0,
			0,
			0,
			1,
			cd,
			reward);
	}

}
