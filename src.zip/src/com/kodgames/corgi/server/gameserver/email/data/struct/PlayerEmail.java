package com.kodgames.corgi.server.gameserver.email.data.struct;

import java.util.ArrayList;
import java.util.List;

import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Reward;

public class PlayerEmail
{
	private long emailId;
	private int emailType = 0;
	private String emailTitle;
	private String emailBody;
	private long sendTime;
	private String senderName;
	private int senderId;
	private int receiverId;
	private long groupId;
	private int statusPicked;
	private int statusDelete;
	private List<Attachment> attachments = new ArrayList<Attachment>();

	private Reward reward = null;// reward格式的附件

	public PlayerEmail copy()
	{
		PlayerEmail copy = new PlayerEmail();
		copy.setEmailId(emailId);
		copy.setEmailType(emailType);
		copy.setEmailTitle(emailTitle);
		copy.setEmailBody(emailBody);
		copy.setSendTime(sendTime);
		copy.setSenderName(senderName);
		copy.setSenderId(senderId);
		copy.setReceiverId(receiverId);
		copy.setGroupId(groupId);
		copy.setStatusPicked(statusPicked);
		copy.setStatusDelete(statusDelete);
		copy.setAttachments(this.getAttachmentsClone());
		return copy;
	}

	public List<Attachment> getAttachmentsClone()
	{
		List<Attachment> attachments_tmp = new ArrayList<Attachment>();
		for (Attachment attachment : attachments)
		{
			attachments_tmp.add(attachment.clone_NoReward());
		}
		return attachments_tmp;
	}

	public PlayerEmail()
	{
	}

	public PlayerEmail(GroupEmail groupEmail, PlayerNode playerNode)
	{
		this();
		this.emailType = groupEmail.getEmailType();
		this.emailTitle = groupEmail.getEmailTitle();
		this.emailBody = groupEmail.getEmailBody();
		this.sendTime = System.currentTimeMillis();// 这里取当前时间(把群邮件当成一个人,此时玩家满足收取该邮件的条件,所以等价于此时向玩家发该邮件)
		this.senderName = groupEmail.getSenderName();
		this.senderId = groupEmail.getSenderId();
		this.receiverId = playerNode.getPlayerId();
		this.groupId = groupEmail.getGroupId();
		this.statusPicked = 0;
		this.statusDelete = 0;
		this.attachments = groupEmail.getAttachmentsClone();
	}

	// 判断邮件是否有附件
	public boolean isHasAttachment()
	{
		if (attachments.size() > 0)
		{
			return true;
		}
		return false;
	}

	// 获取附件的reward格式
	public Reward getReward()
	{
		if (attachments.size() > 0)
		{
			if (reward == null)
			{
				reward = new Reward();
				for (Attachment attachment : attachments)
				{
					reward.megerReward(attachment.genReward());
				}
			}
		}
		return reward;
	}

	public CommonProtocols.EmailPlayer toProtoBuffer()
	{
		CommonProtocols.EmailPlayer.Builder builder = CommonProtocols.EmailPlayer.newBuilder();
		builder.setEmailId(emailId);
		builder.setEmailType(emailType);
		builder.setEmailTitle(emailTitle);
		builder.setSenderId(senderId);
		builder.setSenderName(senderName);
		builder.setSendTime(sendTime);
		builder.setReceiverId(receiverId);
		builder.setEmailBody(emailBody);
		builder.setEmailGroupId(groupId);
		builder.setStatusDidPick(statusPicked);
		{
			Reward reward = getReward();
			if (reward != null)
			{
				builder.setAttachmentRewards(reward.toProtobuf());
			}
		}
		return builder.build();
	}

	public int getEmailType()
	{
		return emailType;
	}

	public void setEmailType(int emailType)
	{
		this.emailType = emailType;
	}

	public String getEmailTitle()
	{
		return emailTitle;
	}

	public void setEmailTitle(String emailTitle)
	{
		this.emailTitle = emailTitle;
	}

	public String getEmailBody()
	{
		return emailBody;
	}

	public void setEmailBody(String emailBody)
	{
		this.emailBody = emailBody;
	}

	public long getSendTime()
	{
		return sendTime;
	}

	public void setSendTime(long sendTime)
	{
		this.sendTime = sendTime;
	}

	public String getSenderName()
	{
		return senderName;
	}

	public void setSenderName(String senderName)
	{
		this.senderName = senderName;
	}

	public int getSenderId()
	{
		return senderId;
	}

	public void setSenderId(int senderId)
	{
		this.senderId = senderId;
	}

	public int getReceiverId()
	{
		return receiverId;
	}

	public void setReceiverId(int receiverId)
	{
		this.receiverId = receiverId;
	}

	public long getGroupId()
	{
		return groupId;
	}

	public void setGroupId(long groupId)
	{
		this.groupId = groupId;
	}

	public int getStatusPicked()
	{
		return statusPicked;
	}

	public void setStatusPicked(int statusPicked)
	{
		this.statusPicked = statusPicked;
	}

	public int getStatusDelete()
	{
		return statusDelete;
	}

	public void setStatusDelete(int statusDelete)
	{
		this.statusDelete = statusDelete;
	}

	public List<Attachment> getAttachments()
	{
		return attachments;
	}

	public void setAttachments(List<Attachment> attachments)
	{
		this.attachments = attachments;
	}

	public void setReward(Reward reward)
	{
		this.reward = reward;
	}

	public long getEmailId()
	{
		return emailId;
	}

	public void setEmailId(long emailId)
	{
		this.emailId = emailId;
	}

}
