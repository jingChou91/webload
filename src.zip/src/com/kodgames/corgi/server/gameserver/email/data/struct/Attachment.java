package com.kodgames.corgi.server.gameserver.email.data.struct;

import java.util.ArrayList;
import java.util.List;

import com.kodgames.corgi.server.gameserver.avatar.data.Avatar;
import com.kodgames.corgi.server.gameserver.equipment.data.Equipment;
import com.kodgames.corgi.server.gameserver.skill.data.Skill;
import com.kodgames.gamedata.player.costandreward.Consume;
import com.kodgames.gamedata.player.costandreward.ItemType;
import com.kodgames.gamedata.player.costandreward.Reward;

public class Attachment
{
	private int id;
	private int data1;
	private int data2;
	private int count;

	private Reward reward = null;

	public Attachment clone_NoReward()
	{
		return new Attachment(id, data1, data2, count);
	}

	// 将reward转换为多个attachment结构
	public static List<Attachment> rewardToAttachments(Reward reward, int count)
	{
		List<Attachment> attachments = new ArrayList<Attachment>();

		for (Avatar avatar : reward.getAvatars())
		{
			Attachment attachment = new Attachment();
			attachment.setId(avatar.getResourceId());
			attachment.setCount(count);
			attachment.setData1(avatar.getBreakthoughtLevel());
			attachment.setData2(avatar.getLevel());
			attachments.add(attachment);
		}

		for (Skill skill : reward.getSkills())
		{
			Attachment attachment = new Attachment();
			attachment.setId(skill.getResourceId());
			attachment.setCount(count);
			attachment.setData1(skill.getLevel());
			attachments.add(attachment);
		}

		for (Equipment equipment : reward.getEquipments())
		{
			Attachment attachment = new Attachment();
			attachment.setId(equipment.getResourceId());
			attachment.setCount(count);
			attachment.setData1(equipment.getBreakthoughtLevel());
			attachment.setData2(equipment.getLevel());
			attachments.add(attachment);
		}

		for (Consume consumable : reward.getConsumables())
		{
			Attachment attachment = new Attachment();
			attachment.setId(consumable.getId());
			attachment.setCount(consumable.getAmount() * count);
			attachments.add(attachment);
		}
		return attachments;
	}

	// 根据id生成并返回reward
	public Reward genReward()
	{
		if (reward == null)
		{
			this.reward = new Reward();
		}
		else
		{
			return this.reward;
		}

		if (ItemType.isAvatar(id))
		{
			for (int i = 0; i < count; ++i)
			{
				Avatar avatar = Avatar.genNewAvatar(id);
				avatar.setBreakthoughtLevel(this.data1);
				avatar.setLevel(this.data2);
				reward.getAvatars().add(avatar);
			}
		}
		else if (ItemType.isEquipment(id))
		{
			for (int i = 0; i < count; ++i)
			{
				Equipment equipment = Equipment.genNewEquip(id);
				equipment.setBreakthoughtLevel(data1);
				equipment.setLevel(data2);
				reward.getEquipments().add(equipment);
			}
		}
		else if (ItemType.isSkill(id))
		{
			for (int i = 0; i < count; ++i)
			{
				Skill skill = Skill.genNewSkill(id);
				skill.setLevel(data1);
				reward.getSkills().add(skill);
			}
		}
		else
		{
			reward.getConsumables().add(new Consume(id, count));
		}
		return this.reward;
	}

	public Attachment()
	{
	}

	public Attachment(int id, int data1, int data2, int count)
	{
		this.id = id;
		this.data1 = data1;
		this.data2 = data2;
		this.count = count;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public int getData1()
	{
		return data1;
	}

	public void setData1(int data1)
	{
		this.data1 = data1;
	}

	public int getData2()
	{
		return data2;
	}

	public void setData2(int data2)
	{
		this.data2 = data2;
	}

	public int getCount()
	{
		return count;
	}

	public void setCount(int count)
	{
		this.count = count;
	}

	public Reward getReward()
	{
		return reward;
	}

	public void setReward(Reward reward)
	{
		this.reward = reward;
	}

}
