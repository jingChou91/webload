package com.kodgames.corgi.server.gameserver.email.data.struct;

import java.util.ArrayList;
import java.util.List;

public class GroupEmail
{
	private long groupId;
	private int emailType;
	private String emailTitle;
	private String emailBody;
	private long sendTime;
	private String senderName;
	private int senderId;
	private int receiverPlayerId;
	private int receiverLevelMin;
	private int receiverLevelMax;
	private long startTime;
	private long endTime;
	private long createPlayerStartTime;
	private long createPlayerEndTime;
	private List<Attachment> attachments = new ArrayList<Attachment>();

	public GroupEmail copy()
	{
		GroupEmail copy = new GroupEmail();
		copy.setGroupId(groupId);
		copy.setEmailType(emailType);
		copy.setEmailTitle(emailTitle);
		copy.setEmailBody(emailBody);
		copy.setSendTime(sendTime);
		copy.setSenderName(senderName);
		copy.setSenderId(senderId);
		copy.setReceiverPlayerId(receiverPlayerId);
		copy.setReceiverLevelMin(receiverLevelMin);
		copy.setReceiverLevelMax(receiverLevelMax);
		copy.setStartTime(startTime);
		copy.setEndTime(endTime);
		copy.setCreatePlayerStartTime(createPlayerStartTime);
		copy.setCreatePlayerEndTime(createPlayerEndTime);
		copy.setAttachments(this.getAttachmentsClone());
		return copy;

	}

	public List<Attachment> getAttachmentsClone()
	{
		List<Attachment> attachments_tmp = new ArrayList<Attachment>();
		for (Attachment attachment : attachments)
		{
			attachments_tmp.add(attachment.clone_NoReward());
		}
		return attachments_tmp;
	}

	public GroupEmail()
	{
	}

	public GroupEmail(long groupId, int emailType, String emailTitle, String emailBody, long sendTime,
		String senderName, int senderPlayerId, int receiverPlayerId, int receiverLevelMin, int receiverLevelMax,
		long startTime, long endTime, long createPlayerStartTime, long createPlayerEndTime, List<Attachment> attachments)
	{
		super();
		this.groupId = groupId;
		this.emailType = emailType;
		this.emailTitle = emailTitle;
		this.emailBody = emailBody;
		this.sendTime = sendTime;
		this.senderName = senderName;
		this.senderId = senderPlayerId;
		this.receiverPlayerId = receiverPlayerId;
		this.receiverLevelMin = receiverLevelMin;
		this.receiverLevelMax = receiverLevelMax;
		this.startTime = startTime;
		this.endTime = endTime;
		this.createPlayerStartTime = createPlayerStartTime;
		this.createPlayerEndTime = createPlayerEndTime;
		this.attachments = attachments;
	}

	public long getGroupId()
	{
		return groupId;
	}

	public void setGroupId(long groupId)
	{
		this.groupId = groupId;
	}

	public int getEmailType()
	{
		return emailType;
	}

	public void setEmailType(int emailType)
	{
		this.emailType = emailType;
	}

	public String getEmailTitle()
	{
		return emailTitle;
	}

	public void setEmailTitle(String emailTitle)
	{
		this.emailTitle = emailTitle;
	}

	public String getEmailBody()
	{
		return emailBody;
	}

	public void setEmailBody(String emailBody)
	{
		this.emailBody = emailBody;
	}

	public long getSendTime()
	{
		return sendTime;
	}

	public void setSendTime(long sendTime)
	{
		this.sendTime = sendTime;
	}

	public String getSenderName()
	{
		return senderName;
	}

	public void setSenderName(String senderName)
	{
		this.senderName = senderName;
	}

	public int getSenderId()
	{
		return senderId;
	}

	public void setSenderId(int senderId)
	{
		this.senderId = senderId;
	}

	public int getReceiverPlayerId()
	{
		return receiverPlayerId;
	}

	public void setReceiverPlayerId(int receiverPlayerId)
	{
		this.receiverPlayerId = receiverPlayerId;
	}

	public int getReceiverLevelMin()
	{
		return receiverLevelMin;
	}

	public void setReceiverLevelMin(int receiverLevelMin)
	{
		this.receiverLevelMin = receiverLevelMin;
	}

	public int getReceiverLevelMax()
	{
		return receiverLevelMax;
	}

	public void setReceiverLevelMax(int receiverLevelMax)
	{
		this.receiverLevelMax = receiverLevelMax;
	}

	public long getStartTime()
	{
		return startTime;
	}

	public void setStartTime(long startTime)
	{
		this.startTime = startTime;
	}

	public long getEndTime()
	{
		return endTime;
	}

	public void setEndTime(long endTime)
	{
		this.endTime = endTime;
	}

	public long getCreatePlayerStartTime()
	{
		return createPlayerStartTime;
	}

	public void setCreatePlayerStartTime(long createPlayerStartTime)
	{
		this.createPlayerStartTime = createPlayerStartTime;
	}

	public long getCreatePlayerEndTime()
	{
		return createPlayerEndTime;
	}

	public void setCreatePlayerEndTime(long createPlayerEndTime)
	{
		this.createPlayerEndTime = createPlayerEndTime;
	}

	public void setAttachments(List<Attachment> attachments)
	{
		this.attachments = attachments;
	}

}
