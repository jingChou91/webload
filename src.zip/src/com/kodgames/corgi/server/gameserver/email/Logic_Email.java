package com.kodgames.corgi.server.gameserver.email;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.email.logic.CG_GetAttachmentsReqHandler;
import com.kodgames.corgi.server.gameserver.email.logic.CG_QueryEmailListInfoReqHandler;

public class Logic_Email
{
	private CG_QueryEmailListInfoReqHandler cg_QueryEmailListInfoReqHandler = null;
	private CG_GetAttachmentsReqHandler cg_GetAttachmentsReqHandler = null;

	public void init()
	{
		this.cg_QueryEmailListInfoReqHandler = new CG_QueryEmailListInfoReqHandler();
		this.cg_GetAttachmentsReqHandler = new CG_GetAttachmentsReqHandler();
	}

	public void registerProtoBufType(Controller controller)
	{
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_EMAIL_LIST_INFO_REQ, GameProtocolsForClient.CG_QueryEmailListInfoReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_GET_ATTACHMENTS_REQ, GameProtocolsForClient.CG_GetAttachmentsReq.getDefaultInstance());
		
	
	}

	public void registerMessageHandler(Controller controller)
	{
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_EMAIL_LIST_INFO_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryEmailListInfoReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_GET_ATTACHMENTS_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_GetAttachmentsReqHandler));
		
	}
}