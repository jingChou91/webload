package com.kodgames.corgi.server.gameserver.email.logic;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryEmailListInfoReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryEmailListInfoRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.email.data.EmailData;
import com.kodgames.corgi.server.gameserver.email.data.EmailMgr;
import com.kodgames.corgi.server.gameserver.email.data.struct.PlayerEmail;
import com.kodgames.corgi.server.gameserver.email.util.EmailUtil;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_QueryEmailListInfoReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_QueryEmailListInfoReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_QueryEmailListInfoReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_QueryEmailListInfoReq request = (CG_QueryEmailListInfoReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryEmailListInfoRes.Builder builder = GC_QueryEmailListInfoRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_EMAIL_LIST_INFO_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_QUERY_EMAIL_LIST_INFO_SUCCESS;

		int emailType = request.getEmailType();
		Map<Long, PlayerEmail> playerEmails = new HashMap<Long, PlayerEmail>();
		long lastQueryTime = 0;

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_EMAIL_LIST_INFO_LOAD_PLAYER_FAILD;
					break;
				}
				EmailData emailData = playerNode.getPlayerInfo().getEmailData();
				if (emailType != ClientServerCommon._EmailDisplayType.Combat
					&& emailType != ClientServerCommon._EmailDisplayType.Friend
					&& emailType != ClientServerCommon._EmailDisplayType.System
					&& emailType != ClientServerCommon._EmailDisplayType.Guild)
				{
					result = ClientProtocols.E_GAME_QUERY_EMAIL_LIST_INFO_EMAIL_TYPE_NOT_RIGHT;
				}
				// 获取需要展示给客户端的邮件id,并判断是否需要删除多余邮件
				List<Long> showEmailIds = EmailUtil.testAndDeletePlayerEmail(playerNode, emailType);
				// 获取邮件信息
				playerEmails = emailData.getPlayerEmailsByEmailType(emailType);
				// 获取上次查询时间
				lastQueryTime = emailData.getLastQueryTime(emailType);
				// 清空未读邮件数量信息
				EmailMgr.updateEmailTypeLastQueryTime(playerNode, emailType);
				// 将邮件信息返回给客户端
				for (Long emailId : showEmailIds)
				{
					builder.addEmailPlayers(playerEmails.get(emailId).toProtoBuffer());
				}
				builder.setLastQueryTime(lastQueryTime);

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
