package com.kodgames.corgi.server.gameserver.firstpurchase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class FirstPurchase 
{
	private Set<Integer> firstPurchaseSet = Collections.synchronizedSet(new HashSet());
	/**
	 * 是否是首冲
	 * @param apple_good_id
	 * @return
	 */
	public boolean isContainValue(int apple_good_id)
	{
		return firstPurchaseSet.contains(apple_good_id);
	}
	
	public void addData(int apple_good_id)
	{
		firstPurchaseSet.add(apple_good_id);
	}	
	/**
	 * 从数据库读数据
	 * @param dbStr
	 */
	public void mergeFrom(String dbStr)
	{
		firstPurchaseSet.clear();
		String[] apple_good_datas = dbStr.split(",");
		for(int i = 0; i < apple_good_datas.length; i++)
		{
			String apple_good_id = apple_good_datas[i];
			firstPurchaseSet.add(Integer.valueOf(apple_good_id));
		}
	}
	
	public String toDB()
	{
		StringBuffer stringBuffer = new StringBuffer();
		Iterator<Integer> iterator = firstPurchaseSet.iterator();
		int size = firstPurchaseSet.size();
		int i = 0;
		while(iterator.hasNext())
		{
			stringBuffer.append(iterator.next());
			if(i != size -1 )
			{
				stringBuffer.append(",");
			}
			i++;
		}
		return stringBuffer.toString();
	}
	
	public List<Integer> getFirstPurchaseList()
	{
		List<Integer> fristPurchaseList = new ArrayList<Integer>();
		Iterator<Integer> iterator = firstPurchaseSet.iterator();
		while(iterator.hasNext())
		{
			fristPurchaseList.add(iterator.next());
		}
		return fristPurchaseList;
	}
	
	
}
