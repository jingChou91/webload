package com.kodgames.corgi.server.gameserver.firstpurchase;

import com.kodgames.gamedata.player.PlayerNode;

public class FirstPurchaseManger 
{
	
	public static boolean isContainValue(PlayerNode playerNode, int apple_good_id)
	{
		return playerNode.getPlayerInfo().getFirstPurchase().isContainValue(apple_good_id);
	}
	
	public static void addData(PlayerNode playerNode, int apple_good_id)
	{
		playerNode.getPlayerInfo().getFirstPurchase().addData(apple_good_id);
		FirstPurchaseDB.replace(playerNode);
	}	
}
