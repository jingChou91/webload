package com.kodgames.corgi.server.gameserver.firstpurchase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.gamedata.dbcommon.DBEasy;
import com.kodgames.gamedata.player.PlayerNode;

//运营活动初始化
public class RowFirstPurchase
{
	private static final Logger logger = LoggerFactory.getLogger(RowFirstPurchase.class);
	
	//游戏初始化，加载玩家游戏累计充值活动数据
	public static void selectFirstPurchase(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, PlayerNode playerNode)
		throws SQLException
	{
		String sql = "select player_id, apple_good_ids from first_purchase where player_id = " + playerNode.getPlayerId();
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, null);
		if (vrs[queryIndex] != null)
		{
			CachedRowSet rs = vrs[queryIndex];
			if(null !=rs &&rs.next())
			{
				String apple_good_ids = rs.getString("apple_good_ids");
				if(null != apple_good_ids)
				{
					playerNode.getPlayerInfo().getFirstPurchase().mergeFrom(apple_good_ids);
				}
			}
		}
	}
}
