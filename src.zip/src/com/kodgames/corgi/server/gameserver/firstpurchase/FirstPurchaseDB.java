package com.kodgames.corgi.server.gameserver.firstpurchase;

import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.gamedata.player.PlayerNode;

public class FirstPurchaseDB 
{
	public static void replace(PlayerNode playerNode)
	{
		String sql = String.format("replace into first_purchase (player_id, apple_good_ids) values (%d, '%s')", playerNode.getPlayerId(), playerNode.getPlayerInfo().getFirstPurchase().toDB());
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerNode.getPlayerId(), sql);
	}
	
}
