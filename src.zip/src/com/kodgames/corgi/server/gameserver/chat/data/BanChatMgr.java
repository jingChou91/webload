/*
 * 文 件 名:  ChatBanManager.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:  聊天禁言管理器 
 * 创 建 人:  zhangdebo@kodgames.com
 * 创建时间:  2014-4-24
 * 修 改 人:  <修改人>
 * 修改时间:  2014-4-24
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.chat.data;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 聊天禁言管理器 在聊天中，如果玩家发言中含有禁言关键字并重复发言两次，则禁止其发言
 * 
 * @author zhangdebo@kodgames.com
 * @version [1.0, 2014-4-24]
 */
public class BanChatMgr
{

	// 存放playerId和其禁言信息
	private ConcurrentHashMap<Integer, BanInfo> banChatPlayers = new ConcurrentHashMap<Integer, BanInfo>();

	private static BanChatMgr instance = new BanChatMgr();

	// 需要考虑何时清理数据
	public static BanChatMgr getInstance()
	{
		return instance;
	}

	private BanChatMgr()
	{
	}

	public void setGagTime(int playerId)
	{
		if (banChatPlayers.get(playerId) != null)
		{
			banChatPlayers.get(playerId).setGagTime(System.currentTimeMillis());;
		}
	}

	public long getGagTime(int playerId)
	{
		if (banChatPlayers.get(playerId) != null)
		{
			return banChatPlayers.get(playerId).gagTime;
		}
		// 0表示未被禁言
		return 0;
	}
	
	public long getLastChatWithBanWordsTime(int playerId)
	{
		if (banChatPlayers.get(playerId) != null)
		{
			return banChatPlayers.get(playerId).lastTime;
		}
		return 0;
	}
	
	// 检查本次是否禁言并设置最后一次说禁言词时间
	public boolean isGagAndSetLastChatWithBanWordsTime(int playerId)
	{
		BanInfo banInfo = banChatPlayers.get(playerId);
		if (banInfo == null)
		{
			banInfo = new BanInfo();
			banChatPlayers.put(playerId, banInfo);
		}
		long now = System.currentTimeMillis();
		// 表示在刷新时间内第二次说禁言词
		if (banInfo.lastTime != 0)
		{
			banInfo.setLastChatWithBanWordsTime(System.currentTimeMillis());
			banInfo.setGagTime(now);
			return true;
		}
		banInfo.setLastChatWithBanWordsTime(System.currentTimeMillis());
		return false;
	}
	
	// 删除过时的禁言信息
	public void checkUpAndRemoveBanInfo(int playerId)
	{
		if (banChatPlayers.get(playerId) != null)
		{
			banChatPlayers.remove(playerId);
		}
	}

	public class BanInfo
	{
		// 禁言时间
		public long gagTime;
		// 上一次出现禁言列表关键字的时间
		public long lastTime;
		
		/**
		 * 设置禁言时间（什么时候被禁言）
		 */
		public void setGagTime(long gagTime)
		{
			this.gagTime = gagTime;
		}
		
		/**
		 * 设置最后一次说禁言关键词的时间
		 */
		public void setLastChatWithBanWordsTime(long lastTime)
		{
			this.lastTime = lastTime;
		}
	}
}
