/*
 * 文 件 名:  BroadcastWorldMessageTask.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:  世界聊天广播线程
 * 创 建 人:  zhangdebo@kodgames.com
 * 创建时间:  2014-5-6
 * 修 改 人:  <修改人>
 * 修改时间:  2014-5-6
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.chat.thread;

import java.util.concurrent.ConcurrentSkipListSet;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols.ChatMessage;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_SyncWorldAndFlowMessages;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.LoopRunnable;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.chat.data.ShowDialogPlayerIdMgr;
import com.kodgames.corgi.server.gameserver.chat.data.WorldMessageMgr;
import com.kodgames.gamedata.player.PlayerNode;

public class BroadcastWorldMessageRunnable extends LoopRunnable
{
	// 广播周期，即每隔TIME_DELAY时间线程启动一次
	private static int TIME_DELAY = CfgDB.getDefautConfig().get_ChatAndMarqueeConfig().get_worldChatBroadcastTimeDelay() * 1000;

	public BroadcastWorldMessageRunnable()
	{
		super(TIME_DELAY);
	}

	@Override
	public void execute()
	{
		GC_SyncWorldAndFlowMessages.Builder builder = GC_SyncWorldAndFlowMessages.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_SYNC_WORLD_AND_FLOW_MESSAGE);
		PlayerNode senderNode = null;

		for (ChatMessage.Builder message : WorldMessageMgr.getInstance().getBroadcastWorldMessageList())
		{
			senderNode = ServerDataGS.playerManager.getMemoryPlayerNode(message.getSenderId());
			if (senderNode == null || senderNode.getGamePlayer() == null)
			{
				continue;
			}
			message.setSenderName(senderNode.getGamePlayer().getFixName());
			message.setSenderVipLevel(senderNode.getGamePlayer().getVipLevel());
			builder.addMessages(message.build());
		}

		if (builder.getMessagesCount() >=1 )
		{
			ConcurrentSkipListSet<Integer> playerIds = ShowDialogPlayerIdMgr.getInstance().getShowDialogPlayerIds();
			GameProtocolsForClient.GC_SyncWorldAndFlowMessages messages = builder.build();
			for(Integer playerId : playerIds)
			{
				protocol.setProtoBufMessage(messages);
				ServerDataGS.transmitter.sendToClient(playerId, protocol);
			}
		}

		// 检查是否清理数据库
		WorldMessageMgr.getInstance().checkUpAndClearWorldMessageDB();
	}

}
