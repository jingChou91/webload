/*
 * 文 件 名:  GagMgr.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:   GM禁言管理器 
 * 创 建 人:  zhangdebo@kodgames.com
 * 创建时间:  2014-6-5
 * 修 改 人:  <修改人>
 * 修改时间:  2014-6-5
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.chat.data;

import java.util.concurrent.ConcurrentHashMap;

import com.kodgames.corgi.server.gameserver.chat.db.GagDB;

/**
 * GM禁言管理器，GM主动禁言玩家
 * 
 * @author  zhangdebo@kodgames.com
 * @version  [1.0, 2014-6-5]
 */
public class GagMgr
{
	public static final int GAG_UDID = 0;
	public static final int GAG_PLAYER_ID = 1;

	// 存储禁言玩家设备UDID和解除禁言时间
	private ConcurrentHashMap<String, Long> gagUDIDs = new ConcurrentHashMap<>();
	// 存储禁言玩家playerId和解除禁言时间
	private ConcurrentHashMap<Integer, Long> gagPlayerIds = new ConcurrentHashMap<>();

	private static GagMgr instance = new GagMgr();

	private GagMgr()
	{
	}

	public static GagMgr getInstance()
	{
		return instance;
	}

	// 根据playerID禁言玩家
	public void gag(int playerId, long time)
	{
		this.gagPlayerIds.put(playerId, time);
		GagDB.updateForbidTalkByPlayerId(playerId, time);
	}

	// 根据设备UDID禁言玩家，玩家更换账号也将禁言
	public void gag(String udid, long time)
	{
		this.gagUDIDs.put(udid, time);
		GagDB.updateForbidTalkByUdid(udid, time);
	}

	// 解除禁言
	public void release(int playerId)
	{
		this.gagPlayerIds.remove(playerId);
		GagDB.deleteForbidTalkByPlayerId(playerId);
	}

	// 解除禁言
	public void release(String udid)
	{
		this.gagUDIDs.remove(udid);
		GagDB.deleteForbidTalkByUdid(udid);
	}

	// 玩家是否被禁言，包括禁言playerID和设备UDID
	public boolean isGagged(int playerId, String udid)
	{
		return isGagged(playerId) || isGagged(udid);
	}

	// 玩家playerID是否被禁言
	public boolean isGagged(int playerId)
	{
		if (this.gagPlayerIds.containsKey(playerId) && this.gagPlayerIds.get(playerId) > System.currentTimeMillis())
			return true;
		return false;
	}

	// 玩家设备UDID是否被禁言
	public boolean isGagged(String udid)
	{
		if (this.gagUDIDs.containsKey(udid) && this.gagUDIDs.get(udid) > System.currentTimeMillis())
			return true;
		return false;
	}

	// 初始化，启动服务器时从数据库加载禁言玩家数据
	public boolean init()
	{
		gagUDIDs = GagDB.selectAllForbidTalkByUdid();
		gagPlayerIds = GagDB.selectAllForbidTalkByPlayerId();
		return true;
	}

	public ConcurrentHashMap<String, Long> getGagUDIDs()
	{
		return gagUDIDs;
	}

	public ConcurrentHashMap<Integer, Long> getGagPlayerIds()
	{
		return gagPlayerIds;
	}
}
