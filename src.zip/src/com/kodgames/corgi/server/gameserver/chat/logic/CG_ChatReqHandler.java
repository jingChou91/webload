/*
 * 文 件 名:  ChatHandler.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:  聊天请求，对私聊和世界聊天进行处理
 * 创 建 人:  zhangdebo@kodgames.com
 * 创建时间:  2014-4-24
 * 修 改 人:  <修改人>
 * 修改时间:  2014-4-24
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.chat.logic;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ChatAndMarqueeConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._ChatType;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols.ChatMessage;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_ChatReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_ChatRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.common.SQLFilter;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.KodLogUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.chat.data.BanChatMgr;
import com.kodgames.corgi.server.gameserver.chat.data.GagMgr;
import com.kodgames.corgi.server.gameserver.chat.data.PrivateMessageMgr;
import com.kodgames.corgi.server.gameserver.chat.data.ShowDialogPlayerIdMgr;
import com.kodgames.corgi.server.gameserver.chat.data.WorldMessageMgr;
import com.kodgames.corgi.server.gameserver.guild.data.Guild;
import com.kodgames.corgi.server.gameserver.guild.data.GuildManager;
import com.kodgames.corgi.server.gameserver.guild.data.GuildMemberMgr.GuildMember;
import com.kodgames.corgi.server.gameserver.guild.data.GuildMgr;
import com.kodgames.gamedata.baseinfo.BaseInfoConfigMgr;
import com.kodgames.gamedata.player.GamePlayer;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.sensitivewords.SensitiveworldsMgr;

/**
 * 聊天请求，对私聊和世界聊天进行处理
 * 
 * @author zhangdebo@kodgames.com
 * @version [1.0, 2014-4-24]
 */
public class CG_ChatReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_ChatReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_ChatHandler, playerId = {}", sender.getClientUID().getPlayerID());

		CG_ChatReq request = (CG_ChatReq) message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_ChatRes.Builder builder = GC_ChatRes.newBuilder();
		ChatMessage.Builder msgBuilder = ChatMessage.newBuilder(request.getChatMessage());
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();

		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		int result = ClientProtocols.E_GAME_CHAT_SUCCESS;

		do
		{
			if (msgBuilder == null)
			{
				result = ClientProtocols.E_GAME_CHAT_ERROR_CHAT_TYPE_INVALID;
				break;
			}

			PlayerNode senderNode = null;
			GamePlayer sendPlayer = null;
			senderNode = ServerDataGS.playerManager.getMemoryPlayerNode(playerId);
			if (cd == null || senderNode == null || senderNode.getGamePlayer() == null)
			{
				result = ClientProtocols.E_GAME_CHAT_FAILED_LOAD_SENDER;
				break;
			}

			if (!FunctionOpenUtil.isFunctionOpen(cd, senderNode, ClientServerCommon._OpenFunctionType.Chat))
			{
				result = ClientProtocols.E_GAME_CHAT_FUNCTION_NOT_OPEN;
				break;
			}

			sendPlayer = senderNode.getGamePlayer();
			msgBuilder.setSenderId(playerId);

			if (msgBuilder.getMessageType() != _ChatType.Guild)
			{
				result = checkBanChatRule(msgBuilder, sendPlayer, cd, sender.getClientUID().getDeviceInfo().getUDID());
				if (result != ClientProtocols.E_GAME_CHAT_SUCCESS)
				{
					break;
				}
			}

			msgBuilder.setSenderName(sendPlayer.getFixName());
			msgBuilder.setSenderVipLevel(sendPlayer.getVipLevel());
			msgBuilder.setTime(System.currentTimeMillis());

			if (msgBuilder.getMessageType() == _ChatType.Private)
			{
				int receiverId = msgBuilder.getReceiverId();
				PlayerNode receiverNode = ServerDataGS.playerManager.getMemoryPlayerNode(receiverId);
				if (receiverNode == null || receiverNode.getGamePlayer() == null)
				{
					result = ClientProtocols.E_GAME_CHAT_FAILED_LOAD_RECEIVER;
					break;
				}
				GamePlayer receivePlayer = receiverNode.getGamePlayer();
				msgBuilder.setReceiverName(receivePlayer.getFixName());
				msgBuilder.setReceiverVipLevel(receivePlayer.getVipLevel());

				// 接收者是否在线
				if (ServerDataGS.playerManager.isOnline(receiverId))
				{
					// IsReceiverOnline用来标记消息是否已读
					if (ShowDialogPlayerIdMgr.getInstance().getShowDialogPlayerIds().contains(receiverId))
					{
						msgBuilder.setIsReceiverOnline(true);
					}
					else
					{
						msgBuilder.setIsReceiverOnline(false);
					}

					PrivateMessageMgr.sentToReceiver(request.getCallback(), receiverId, msgBuilder.build());
					builder.setMessage(msgBuilder.build());
					result = ClientProtocols.E_GAME_CHAT_SUCCESS_PRIVATE_SUCCESS;
				}
				else
				{
					msgBuilder.setIsReceiverOnline(false);
					builder.setMessage(msgBuilder.build());
					result = ClientProtocols.E_GAME_CHAT_SUCCESS_PRIVATE_SUCCESS_RECEIVER_NOT_ONLINE;
				}

				PrivateMessageMgr.addPrivateMessage(msgBuilder.build(), receiverId);

				// KODLOG
				{
					KodLogUtil.private_chat(senderNode, receiverNode, msgBuilder.getContent());
				}
			}
			else if (msgBuilder.getMessageType() == _ChatType.World)
			{
				// 敏感词修正
				String fixedContent = SensitiveworldsMgr.getInstance().getNameStringNoBanWords(msgBuilder.getContent(),
						null);
				msgBuilder.setContent(fixedContent);
				msgBuilder.setIsDisplayOnMarquee(cd.get_ChatAndMarqueeConfig().get_isMarqueeDisplayWorldChat());

				Cost notEnoughCost = new Cost();
				ServerDataGS.playerManager.lockPlayer(playerId);
				try
				{
					// 消耗每天的世界聊天次数
					ArrayList<Cost> worldChatCosts = new ArrayList<Cost>();
					worldChatCosts.add(Cost.fromClientServerCommon(cd.get_ChatAndMarqueeConfig()
							.get_worldChatFreeCost(), 1, 1));
					if (CostAndRewardManager.checkCosts(senderNode, worldChatCosts, cd, KodLogEvent.ChatLogic_Chat,
							notEnoughCost))
					{
						CostAndRewardManager.consumeCosts(senderNode, worldChatCosts, cd, KodLogEvent.ChatLogic_Chat,
								0, 0);
						crsForClient.setCosts(worldChatCosts);
						builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
						builder.setMessage(msgBuilder.build());
						WorldMessageMgr.getInstance().prepareBroadcastWorldMessage(msgBuilder);
						result = ClientProtocols.E_GAME_CHAT_SUCCESS_WORLD_SUCCESS;
						break;

					}

					// 消耗喇叭数
					ArrayList<Cost> worldChatItems = new ArrayList<Cost>();
					worldChatItems.add(Cost.fromClientServerCommon(cd.get_ChatAndMarqueeConfig()
							.get_worldChatItemCost(), 1, 1));
					if (CostAndRewardManager.checkCosts(senderNode, worldChatItems, cd, KodLogEvent.ChatLogic_Chat,
							notEnoughCost) == false)
					{
						crsForClient.setNotEnoughCost(notEnoughCost);
						builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
						result = ClientProtocols.E_GAME_CHAT_FAILED_CONSUMABLE_NOT_ENOUGH; // 消耗品不够
						break;
					}

					CostAndRewardManager.consumeCosts(senderNode, worldChatItems, cd, KodLogEvent.ChatLogic_Chat, 0, 0);
					crsForClient.setCosts(worldChatItems);

					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					builder.setMessage(msgBuilder.build());
					WorldMessageMgr.getInstance().prepareBroadcastWorldMessage(msgBuilder);
					result = ClientProtocols.E_GAME_CHAT_SUCCESS_WORLD_SUCCESS;
				}
				finally
				{
					ServerDataGS.playerManager.unlockPlayer(playerId);
				}
				// KODLOG
				KodLogUtil.world_chat(senderNode, fixedContent);
			}
			else if (msgBuilder.getMessageType() == _ChatType.Guild)
			{
				ServerDataGS.playerManager.lockPlayer(playerId);
				try
				{
					if (BaseInfoConfigMgr.getInstance().getCfg().isShowGuild() == false)
					{
						result = ClientProtocols.E_GAME_GUILD_NOT_OPEN;
						break;
					}

					// 门派功能开关是否开启
					if (!FunctionOpenUtil.isFunctionOpen(cd, senderNode, ClientServerCommon._OpenFunctionType.Guild))
					{
						result = ClientProtocols.E_GAME_GUILD_NOT_OPEN_BY_LEVEL_LIMIT;
						break;
					}

					// 玩家是否在门派中
					Guild guild = GuildMgr.getInstance().getGuildByPlayerId(playerId);
					if (guild == null)
					{
						result = ClientProtocols.E_GAME_CHAT_FAILED_NOT_IN_GUILD;
						break;
					}

					// 敏感词修正
					String fixedContent = SensitiveworldsMgr.getInstance().getNameStringNoBanWords(
							msgBuilder.getContent(), null);
					// 聊天内容长度超过限制
					String msg = SQLFilter.sql_inj(fixedContent);
					if (msg.length() > cd.get_GuildConfig().get_MsgLengthLimit())
					{
						result = ClientProtocols.E_GAME_CHAT_FAILED_MSG_LENGTH_TOO_LONG;
						break;
					}
					msgBuilder.setContent(msg);

					GuildMember member = guild.getGuildMemberMgr().getGuildMemberById(playerId);
					// roleId不赋值表示玩家已经离开该门派
					int roleCount = cd.get_GuildConfig().Get_RolesCount();
					int roleDefault = cd.get_GuildConfig().Get_RolesByIndex(roleCount-1).get_Id();
					if (member != null)
					{
						msgBuilder.setSenderRoleId(member.getRoleId());
					}
					else
					{
						msgBuilder.setSenderRoleId(roleDefault);
					}

					msgBuilder.setSenderLevel(sendPlayer.getLevel());
					builder.setMessage(msgBuilder.build());

					// 增加一条聊天
					GuildManager.addGuildChat(playerId, guild, msgBuilder, senderNode.getGamePlayer().getGuildPlayer());

					result = ClientProtocols.E_GAME_CHAT_SUCCESS_GUILD_SUCCESS;
				}
				finally
				{
					ServerDataGS.playerManager.unlockPlayer(playerId);
				}
			}

		}
		while (false);

		builder.setCallback(request.getCallback());
		builder.setResult(result);
		ServerDataGS.transmitter.sendToClient(sender, ClientProtocols.P_GAME_GC_CHAT_RES, builder.build());

		return HandlerAction.TERMINAL;
	}

	/**
	 * 禁言规则检查
	 * 
	 * @param chatMessage
	 * @return 对应的错误码
	 */
	private int checkBanChatRule(ChatMessage.Builder message, GamePlayer gamePlayer, ConfigDatabase cd, String udid)
	{
		// GM禁言
		int playerId = message.getSenderId();
		if (GagMgr.getInstance().isGagged(playerId, udid))
		{
			return ClientProtocols.E_GAME_CHAT_FAILED_PRIVATE_ALREADY_GAGED_BY_GM;
		}

		ChatAndMarqueeConfig config = cd.get_ChatAndMarqueeConfig();
		int openLevel = config.get_worldChatOpenLevel();
		int openVipLevel = config.get_worldChatOpenVipLevel();
		if (message.getMessageType() == _ChatType.World && gamePlayer.getLevel() < openLevel
				&& gamePlayer.getVipLevel() < openVipLevel)
		{
			return ClientProtocols.E_GAME_CHAT_FAILED_WORLD_FAILED_LEVEL_OR_VIP_TOO_LOW;
		}

		int talkNoForbidVipLevel = config.get_worldChatNoForbidVipLevel();
		if (gamePlayer.getVipLevel() >= talkNoForbidVipLevel)
		{
			return ClientProtocols.E_GAME_CHAT_SUCCESS;
		}

		// 还在禁言结束时间之前
		long talkForbidEndTimeSeconds = config.get_talkForbidEndTimeSeconds();
		long gagTime = BanChatMgr.getInstance().getGagTime(playerId);
		if (System.currentTimeMillis() < gagTime + talkForbidEndTimeSeconds * 1000L)
		{
			return ClientProtocols.E_GAME_CHAT_FAILED_PRIVATE_IN_GAGINGTIME;
		}

		// 最后一次说禁言词的时间
		long lastChatWithBanWordsTime = BanChatMgr.getInstance().getLastChatWithBanWordsTime(playerId);
		long talkContentRefreshTimeSeconds = config.get_talkContentRefreshTimeSeconds();
		if (System.currentTimeMillis() >= lastChatWithBanWordsTime + talkContentRefreshTimeSeconds * 1000L)
		{
			// 禁言信息已经达到禁言词刷新时间，主动触发一次BanInfo的清理
			BanChatMgr.getInstance().checkUpAndRemoveBanInfo(playerId);
		}

		// 没有禁言关键词
		ArrayList<String> banWords = new ArrayList<String>();
		SensitiveworldsMgr.getInstance().getGagStringNoBanWords(preDoContent(message.getContent()), banWords);
		if (banWords.size() < 1)
		{
			return ClientProtocols.E_GAME_CHAT_SUCCESS;
		}

		// 含有敏感词，记下当前时间,判断是否禁言
		boolean isGag = BanChatMgr.getInstance().isGagAndSetLastChatWithBanWordsTime(playerId);
		if (isGag)
		{
			return ClientProtocols.E_GAME_CHAT_FAILED_PRIVATE_IN_GAGINGTIME;
		}

		return ClientProtocols.E_GAME_CHAT_SUCCESS;
	}

	// 聊天内容预处理，过滤除了汉子的所有字符 \u4e00-\u9fa5 表示汉子字符
	private String preDoContent(String preText)
	{
		return preText.replaceAll("[^\u4e00-\u9fa5a-zA-Z0-9]", "").toLowerCase();
	}

}
