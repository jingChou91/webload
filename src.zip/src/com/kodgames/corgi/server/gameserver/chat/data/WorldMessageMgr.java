/*

 * 文 件 名:  ChatMessageManager.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:  世界聊天管理器
 * 创 建 人:  zhangdebo@kodgames.com
 * 创建时间:  2014-4-23
 * 修 改 人:  <修改人>
 * 修改时间:  2014-4-23
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.chat.data;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicLong;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.CommonProtocols.ChatMessage;
import com.kodgames.corgi.server.gameserver.chat.db.WorldMessageDB;
import com.kodgames.corgi.server.gameserver.chat.db.WorldMessageDB.Messenger;

/**
 * 世界聊天管理器 管理世界聊天信息
 * 
 * @author zhangdebo@kodgames.com
 * @version [1.0, 2014-4-23]
 */
public class WorldMessageMgr
{

	// 存储世界聊天的队列，该队列中的世界聊天消息将由BroadcastWorldMessageRunnable广播
	private ConcurrentLinkedQueue<ChatMessage.Builder> WorldChatMessageQueue = new ConcurrentLinkedQueue<ChatMessage.Builder>();
	// 世界聊天消息缓存队列，登陆上线的玩家将从该队列中取得下发的世界聊天消息
	private ConcurrentLinkedQueue<ChatMessage.Builder> WorldChatMessageQueueCache = new ConcurrentLinkedQueue<ChatMessage.Builder>();

	// 世界聊天的内存存储数量
	private static final int CACHE_SIZE = CfgDB.getDefautConfig().get_ChatAndMarqueeConfig().get_worldChatCacheSize();

	// 计数世界聊天消息，决定何时进行数据库清理
	private int message_count = 0;
	// 数据库清理频次，当消息增加至该频次执行清理
	private static final int DB_CLEAR_FREQUENCY = 1000;
	// 数据库存储数量
	private static final int DB_STORE_NUM = 10000;

	// 世界聊天消息索引 用于标示聊天消息，并用于异步写数据库
	private static AtomicLong World_Message_Index = new AtomicLong();

	private static WorldMessageMgr instance = new WorldMessageMgr();

	private WorldMessageMgr()
	{
	}

	public static WorldMessageMgr getInstance()
	{
		return instance;
	}

	/**
	 * 世界聊天队列中增加一条世界聊天信息
	 * 
	 */
	public synchronized boolean prepareBroadcastWorldMessage(ChatMessage.Builder message)
	{
		message.setMessageId(World_Message_Index.incrementAndGet());

		WorldChatMessageQueue.add(message);
		WorldMessageDB.addWorldMessage(message.getSenderId(), message);

		// 消息计数，用于决定是否进行数据库清理
		message_count += 1;
		return true;
	}

	private void cachedWorldMessage(ChatMessage.Builder message)
	{
		if (WorldChatMessageQueueCache.size() <= CACHE_SIZE)
		{
			WorldChatMessageQueueCache.add(message);
		}
		else
		{
			WorldChatMessageQueueCache.poll();
			WorldChatMessageQueueCache.add(message);
		}
	}

	public void checkUpAndClearWorldMessageDB()
	{

		if (message_count >= DB_CLEAR_FREQUENCY)
		{
			long index = World_Message_Index.get() - DB_STORE_NUM;
			if (index > 0)
			{
				WorldMessageDB.deleteWorldMessage(index);
				message_count = 0;
			}
		}
	}

	/**
	 * 将内存中的世界聊天消息队列转换为列表形式
	 * 
	 * @return
	 * @see [类、类#方法、类#成员]
	 */
	public synchronized List<ChatMessage.Builder> getBroadcastWorldMessageList()
	{
		ArrayList<ChatMessage.Builder> list = new ArrayList<ChatMessage.Builder>();
		ChatMessage.Builder message = null;
		int i = 0;
		while (!WorldChatMessageQueue.isEmpty())
		{
			// 每次最多广播CACHE_SIZE条消息，超过则下一个周期广播
			if (++i > CACHE_SIZE)
			{
				break;
			}
			message = WorldChatMessageQueue.poll();
			list.add(message);
			cachedWorldMessage(message);
		}
		return list;
	}

	public synchronized List<ChatMessage.Builder> getCachedWorldMessageList()
	{
		return new ArrayList<ChatMessage.Builder>(WorldChatMessageQueueCache);
	}

	/**
	 * 从数据库初始化世界聊天队列,并初始化世界聊天消息和私聊消息的索引值
	 * 
	 * @see [类、类#方法、类#成员]
	 */
	public boolean init()
	{
		Messenger msger = WorldMessageDB.queryMessageList(CACHE_SIZE);
		World_Message_Index.set(msger.maxIndex);
		WorldChatMessageQueueCache.addAll(msger.messages);
		return true;
	}

}
