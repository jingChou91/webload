package com.kodgames.corgi.server.gameserver.chat.db;

import java.sql.SQLException;
import java.util.concurrent.ConcurrentHashMap;

import javax.sql.rowset.CachedRowSet;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;

public class GagDB
{
	private static final Logger logger = LoggerFactory.getLogger(GagDB.class);

	// 禁言playerID
	public static void updateForbidTalkByPlayerId(int playerId, long time)
	{
		String gagTime = ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(), time, ServerUtil.TimeWithoutMills);
		String sqlCommand = String.format("replace into gm_forbid_talk_by_account_idx(account_idx, talk_forbid_end_time) values(%d, '%s')", playerId, gagTime);
		ServerDataGS.dbCluster.getManagerDbClient().executeAsynchronousUpdate(0, sqlCommand);
	}

	// 禁言设备UDID
	public static void updateForbidTalkByUdid(String udid, long time)
	{
		String gagTime = ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(), time, ServerUtil.TimeWithoutMills);
		String sqlCommand = String.format("replace into gm_forbid_talk_by_udid(udid, talk_forbid_end_time) values('%s', '%s')", udid, gagTime);
		ServerDataGS.dbCluster.getManagerDbClient().executeAsynchronousUpdate(0, sqlCommand);
	}

	// 解除禁言
	public static void deleteForbidTalkByPlayerId(int playerId)
	{
		String sql = String.format("delete from gm_forbid_talk_by_account_idx where account_idx = %d", playerId);
		ServerDataGS.dbCluster.getManagerDbClient().executeAsynchronousUpdate(0, sql);
	}

	// 解除禁言
	public static void deleteForbidTalkByUdid(String udid)
	{
		String sql = String.format("delete from gm_forbid_talk_by_udid where udid = '%s'", udid);
		ServerDataGS.dbCluster.getManagerDbClient().executeAsynchronousUpdate(0, sql);
	}

	// 初始化取得禁言玩家列表
	public static ConcurrentHashMap<String, Long> selectAllForbidTalkByUdid()
	{
		ConcurrentHashMap<String, Long> datas = new ConcurrentHashMap<>();
		String sql = "select * from gm_forbid_talk_by_udid";
		CachedRowSet rs = null;
		try
		{
			rs = ServerDataGS.dbCluster.getManagerDbClient().executeQuery(sql);
			while (rs.next())
			{
				String udid = rs.getString("udid");
				long gagTime = ServerUtil.convertTimeStringWithTimezoneToLong(TimeZoneData.getTimeZone(), rs.getString("talk_forbid_end_time"));
				if (gagTime > System.currentTimeMillis())
				{
					datas.put(udid, gagTime);
				}

			}
		}
		catch (SQLException e)
		{
			logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
		}
		finally
		{
			if (rs != null)
				try
				{
					rs.close();
				}
				catch (SQLException e)
				{
					logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
				}
		}
		return datas;
	}

	// 初始化取得禁言玩家列表
	public static ConcurrentHashMap<Integer, Long> selectAllForbidTalkByPlayerId()
	{
		String sql = "select * from gm_forbid_talk_by_account_idx";
		ConcurrentHashMap<Integer, Long> datas = new ConcurrentHashMap<>();
		CachedRowSet rs = null;
		try
		{
			rs = ServerDataGS.dbCluster.getManagerDbClient().executeQuery(sql);
			while (rs.next())
			{
				Integer playerId = rs.getInt("account_idx");
				long gagTime = ServerUtil.convertTimeStringWithTimezoneToLong(TimeZoneData.getTimeZone(), rs.getString("talk_forbid_end_time"));
				if (gagTime > System.currentTimeMillis())
				{
					datas.put(playerId, gagTime);
				}

			}
		}
		catch (SQLException e)
		{
			logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
		}
		finally
		{
			if (rs != null)
				try
				{
					rs.close();
				}
				catch (SQLException e)
				{
					logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
				}
		}

		return datas;
	}
}
