package com.kodgames.corgi.server.gameserver.chat.data;

import java.util.concurrent.ConcurrentSkipListSet;

public class ShowDialogPlayerIdMgr
{
	private static ShowDialogPlayerIdMgr instance = new ShowDialogPlayerIdMgr();
	
	private ShowDialogPlayerIdMgr(){}
	public static ShowDialogPlayerIdMgr getInstance(){return instance;}
	
	//有变化的玩家ID
	private ConcurrentSkipListSet<Integer> showDialogPlayerIds = new ConcurrentSkipListSet<>();

	public void showDialogPlayerId(int playerId)
	{
		showDialogPlayerIds.add(playerId);
	}
	
	public void removeShowPlayerId(int playerId)
	{
		showDialogPlayerIds.remove(playerId);
	}
	
	public ConcurrentSkipListSet<Integer> getShowDialogPlayerIds()
	{
		return showDialogPlayerIds;
	}
}
