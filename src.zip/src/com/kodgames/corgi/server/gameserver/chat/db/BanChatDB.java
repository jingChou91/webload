package com.kodgames.corgi.server.gameserver.chat.db;

import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;

public class BanChatDB
{

	// 更新player
	public static void updatePlayer(int playerId, long talk_forbid_end_time)
	{
		String sqlCommand = null;
		if (talk_forbid_end_time <= 0)
		{
			sqlCommand = String.format("update player set talk_forbid_end_time=null where player_id=%d", playerId);
		}
		else
		{
			String strNextTime = ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(), talk_forbid_end_time, ServerUtil.TimeWithoutMills);
			sqlCommand = String.format("update player set talk_forbid_end_time='%s' where player_id=%d", strNextTime, playerId);
		}

		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId, sqlCommand);
	}

}
