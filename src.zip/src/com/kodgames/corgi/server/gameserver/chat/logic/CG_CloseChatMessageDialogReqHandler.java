package com.kodgames.corgi.server.gameserver.chat.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_CloseChatMessageDialogReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_CloseChatMessageDialogRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.chat.data.ShowDialogPlayerIdMgr;

public class CG_CloseChatMessageDialogReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_CloseChatMessageDialogReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_CloseChatMessageDialogReqHandler, playerId = {}", sender.getClientUID().getPlayerID());

		CG_CloseChatMessageDialogReq request = (CG_CloseChatMessageDialogReq) message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_CloseChatMessageDialogRes.Builder builder = GC_CloseChatMessageDialogRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_CLOSECHATMESSAGEDIALOG_RES);

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_QUERY_CLOSECHATMESSAGEDIALOG_SUCCESS;
		
		// 从接收世界聊天消息的队列中删除该玩家
		ShowDialogPlayerIdMgr.getInstance().removeShowPlayerId(playerId);
		
		builder.setResult(result);
		builder.setCallback(request.getCallback());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}

}
