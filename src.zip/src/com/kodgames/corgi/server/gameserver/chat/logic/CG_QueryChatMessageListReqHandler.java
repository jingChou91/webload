/*
 * 文 件 名:  QueryChatMessageListHandler.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:  请求聊天消息列表，初次打开聊天面板时请求
 * 创 建 人:  zhangdebo@kodgames.com
 * 创建时间:  2014-4-24
 * 修 改 人:  <修改人>
 * 修改时间:  2014-4-24
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.chat.logic;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._ChatType;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols.ChatMessage;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryChatMessageListReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryChatMessageListRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.chat.data.PrivateMessageMgr;
import com.kodgames.corgi.server.gameserver.chat.data.ShowDialogPlayerIdMgr;
import com.kodgames.corgi.server.gameserver.chat.data.WorldMessageMgr;
import com.kodgames.corgi.server.gameserver.chat.db.PrivateChatMessageDB;
import com.kodgames.corgi.server.gameserver.guild.data.Guild;
import com.kodgames.corgi.server.gameserver.guild.data.GuildManager;
import com.kodgames.corgi.server.gameserver.guild.data.GuildMemberMgr.GuildMember;
import com.kodgames.corgi.server.gameserver.guild.data.GuildMgr;
import com.kodgames.gamedata.player.GamePlayer;
import com.kodgames.gamedata.player.PlayerNode;

/**
 * 请求聊天消息列表，初次打开聊天面板时请求
 * 
 * @author zhangdebo@kodgames.com
 * @version [1.0, 2014-4-24]
 */
public class CG_QueryChatMessageListReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_QueryChatMessageListReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_QueryChatMessageListHandler, playerId = {}", sender.getClientUID().getPlayerID());

		CG_QueryChatMessageListReq request = (CG_QueryChatMessageListReq) message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryChatMessageListRes.Builder builder = GC_QueryChatMessageListRes.newBuilder();

		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		List<ChatMessage> chatMessages = new ArrayList<ChatMessage>();
		int privateMessageCount = 0;
		int result = ClientProtocols.E_GAME_QUERY_CHATMESSAGE_SUCCESS;
		do
		{
			PlayerNode playerNode = ServerDataGS.playerManager.getMemoryPlayerNode(playerId);
			if (playerNode == null || playerNode.getGamePlayer() == null)
			{
				result = ClientProtocols.E_GAME_CHAT_FAILED_LOAD_SENDER;
				break;
			}
			if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Chat))
			{
				result = ClientProtocols.E_GAME_CHAT_FUNCTION_NOT_OPEN;
				break;
			}
			ShowDialogPlayerIdMgr.getInstance().showDialogPlayerId(playerId);
			// 获取私聊列表
			ArrayList<ChatMessage.Builder> privateMessages = PrivateChatMessageDB.getPrivateMessages(playerId, cd
					.get_ChatAndMarqueeConfig().get_loginQueryMessagesNumber());
			for (ChatMessage.Builder msg : privateMessages)
			{
				PlayerNode senderNode = ServerDataGS.playerManager.getMemoryPlayerNode(msg.getSenderId());
				if (senderNode == null || senderNode.getGamePlayer() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_CHATMESSAGE_FAILED;
					break;
				}
				GamePlayer senderPlayer = senderNode.getGamePlayer();
				if (msg.getSenderId() != playerId && !msg.getIsReceiverOnline())
				{
					privateMessageCount++;
				}
				msg.setSenderName(senderPlayer.getFixName());
				msg.setSenderVipLevel(senderPlayer.getVipLevel());

				PlayerNode receiverNode = ServerDataGS.playerManager.getMemoryPlayerNode(msg.getReceiverId());
				if (receiverNode == null || receiverNode.getGamePlayer() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_CHATMESSAGE_FAILED;
					break;
				}
				msg.setReceiverName(receiverNode.getGamePlayer().getFixName());
				msg.setReceiverVipLevel(receiverNode.getGamePlayer().getVipLevel());

				chatMessages.add(msg.build());
			}

			if (result != ClientProtocols.E_GAME_QUERY_CHATMESSAGE_SUCCESS)
			{
				break;
			}

			// 未在线消息数据库更新为接收者已收到
			PrivateMessageMgr.updatePrivateMessage(playerNode);

			int worldMsgCount = 0;
			for (ChatMessage.Builder msg : WorldMessageMgr.getInstance().getCachedWorldMessageList())
			{
				worldMsgCount++;
				PlayerNode senderNode = ServerDataGS.playerManager.getMemoryPlayerNode(msg.getSenderId());
				if (senderNode == null || senderNode.getGamePlayer() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_CHATMESSAGE_FAILED;
					break;
				}
				msg.setSenderName(senderNode.getGamePlayer().getFixName());
				msg.setSenderVipLevel(senderNode.getGamePlayer().getVipLevel());
				chatMessages.add(msg.build());
			}
			builder.setWorldMsgCount(worldMsgCount);

			// 门派聊天
			Guild guild = GuildMgr.getInstance().getGuildByPlayerId(playerId);
			long chatView = 0;
			if (guild != null)
			{
				int guildMsgCount = 0;
				for (ChatMessage.Builder chat : guild.getGuildChatMgr().getMsgs().getCopyArray())
				{
					guildMsgCount++;
					GuildMember member = guild.getGuildMemberMgr().getGuildMemberById(chat.getSenderId());
					int roleCount = cd.get_GuildConfig().Get_RolesCount();
					int roleDefault = cd.get_GuildConfig().Get_RolesByIndex(roleCount-1).get_Id();
					if (member != null)
						chat.setSenderRoleId(member.getRoleId());
					else
						chat.setSenderRoleId(roleDefault);
					chat.setMessageType(_ChatType.Guild);
					PlayerNode senderNode = ServerDataGS.playerManager.getMemoryPlayerNode(chat.getSenderId());
					if (senderNode == null || senderNode.getGamePlayer() == null)
					{
						result = ClientProtocols.E_GAME_QUERY_CHATMESSAGE_FAILED;
						break;
					}

					GamePlayer gamePlayer = senderNode.getGamePlayer();
					if (gamePlayer != null)
					{
						chat.setSenderName(gamePlayer.getFixName());
						chat.setSenderLevel(gamePlayer.getLevel());
						chat.setSenderVipLevel(gamePlayer.getVipLevel());
					}

					chatView = (chat.getMessageId() > chatView) ? chat.getMessageId() : chatView;
					chatMessages.add(chat.build());
				}

				// 当前消息已读
				GuildManager.setGuildChatView(playerId, playerNode.getGamePlayer().getGuildPlayer(), (int) chatView);// 设置该ID为最近已读
				builder.setGuildMsgCount(guildMsgCount);
			}
		}
		while (false);

		builder.setCallback(request.getCallback());
		builder.setResult(result);
		builder.setPrivateMsgCount(privateMessageCount);
		for (ChatMessage msg : chatMessages)
		{
			builder.addMessages(msg);
		}
		ServerDataGS.transmitter.sendToClient(sender, ClientProtocols.P_GAME_GC_QUERY_CHATMESSAGE_RES, builder.build());

		return MessageHandler.HandlerAction.TERMINAL;
	}
}
