package com.kodgames.corgi.server.gameserver.chat.db;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.rowset.CachedRowSet;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon._ChatType;

import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.protocol.CommonProtocols.ChatMessage;
import com.kodgames.corgi.server.common.SQLFilter;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;

public class WorldMessageDB
{
	private static final Logger logger = LoggerFactory.getLogger(WorldMessageDB.class);

	// 数据库添加一条世界聊天消息
	public static void addWorldMessage(int playerId, ChatMessage.Builder message)
	{
		String sendTimeString = ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(), message.getTime(),
				ServerUtil.TimeWithoutMills);
		String sql = String.format("insert into chat_world_message(idx, player_id, content, send_time) values (%d, %d,'%s','%s')", message.getMessageId(),
				message.getSenderId(), StringEscapeUtils.escapeSql(SQLFilter.grepSpecialString(message.getContent())), sendTimeString);

		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId, sql);
	}

	// 删除数据库世界聊天消息
	public static void deleteWorldMessage(long idx)
	{
		String sql = "delete from chat_world_message where idx < " + idx;
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(0, sql);
	}

	// 开服时查询,返回最新的idx
	public static Messenger queryMessageList(int size)
	{
		ArrayList<ChatMessage.Builder> messages = new ArrayList<ChatMessage.Builder>();
		String sql = "select * from chat_world_message  order by idx desc limit " + size;
		CachedRowSet rs = null;
		long maxIndex = 0;
		try
		{
			rs = ServerDataGS.dbCluster.getGameDBClient().executeQuery(sql);
			while (rs.next())
			{
				ChatMessage.Builder message = ChatMessage.newBuilder();
				message.setMessageType(_ChatType.World);
				message.setMessageId(rs.getLong("idx"));
				message.setContent(rs.getString("content"));
				message.setSenderId(rs.getInt("player_id"));
				message.setTime(rs.getDate("send_time").getTime());
				messages.add(message);
				if (maxIndex == 0)
				{
					maxIndex = message.getMessageId();
				}

			}
		}
		catch (SQLException e)
		{
			logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
		}
		finally
		{
			if (rs != null)
				try
				{
					rs.close();
				}
				catch (SQLException e)
				{
					logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
				}
		}
		return new Messenger(maxIndex, messages);
	}

	// 信使 保存最大的索引值和消息列表
	public static class Messenger
	{
		public final long maxIndex;
		public final List<ChatMessage.Builder> messages;

		public Messenger(long maxIndex, List<ChatMessage.Builder> messages)
		{
			this.maxIndex = maxIndex;
			this.messages = messages;
		}
	}

}
