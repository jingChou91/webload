package com.kodgames.corgi.server.gameserver.chat.data;

import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols.ChatMessage;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_ChatRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.chat.db.PrivateChatMessageDB;
import com.kodgames.gamedata.player.PlayerNode;

public class PrivateMessageMgr
{
	public static void updatePrivateMessage(PlayerNode playerNode)
	{
		ChatData chatData = playerNode.getPlayerInfo().getChatData();
		chatData.setUnreadPrivateMsgCount(0);
		PrivateChatMessageDB.updatePrivateMessage(playerNode.getPlayerId());
		PrivateChatMessageDB.deleteUnreadMsgCount(playerNode.getPlayerId());
	}

	// isReceiverOnline 字段表示为 消息是否已读 不在表示接收者是否在线
	public static void addPrivateMessage(ChatMessage message, int receiverPlayerId)
	{
		PrivateChatMessageDB.addPrivateMessage(message.getSenderId(), message);
		if (message.getIsReceiverOnline() == false)
		{
			PlayerNode receiverNode = ServerDataGS.playerManager.getMemoryPlayerNode(receiverPlayerId);
			if (receiverNode != null && receiverNode.getPlayerInfo() != null)
			{
				// 玩家在缓存中则更新缓存中的数据
				receiverNode.getPlayerInfo().getChatData().addUnreadPrivateMsgCount();
			}
			PrivateChatMessageDB.updateUnreadMsgCount(receiverPlayerId);
		}
	}

	public static void sentToReceiver(int callback, int receiverId, ChatMessage message)
	{
		GC_ChatRes.Builder builder = GC_ChatRes.newBuilder();
		builder.setCallback(callback);
		builder.setResult(ClientProtocols.E_GAME_CHAT_SUCCESS_PRIVATE_SUCCESS);
		builder.setMessage(message);
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_CHAT_RES);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(receiverId, protocol);
	}
}
