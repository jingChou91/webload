package com.kodgames.corgi.server.gameserver.chat.db;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.rowset.CachedRowSet;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon._ChatType;

import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.protocol.CommonProtocols.ChatMessage;
import com.kodgames.corgi.server.common.SQLFilter;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;

public class PrivateChatMessageDB
{
	private static final Logger logger = LoggerFactory.getLogger(PrivateChatMessageDB.class);

	// 增加一条privatemessage
	public static void addPrivateMessage(int playerId, ChatMessage message)
	{
		String sendTimeString = ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(), message.getTime(),
				ServerUtil.TimeWithoutMills);
		String sql = String.format(
				"insert into chat_private_message(receiver_player_id, sender_player_id, content,is_receiver_online, send_time) values (%d,%d,'%s',%d,'%s')",
				message.getReceiverId(), message.getSenderId(), StringEscapeUtils.escapeSql(SQLFilter.grepSpecialString(message.getContent())), message.getIsReceiverOnline() ? 1 : 0,
				sendTimeString);
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId, sql);
	}
	

	// 更新玩家不在线收到的私聊消息为一度
	public static void updatePrivateMessage(int playerId)
	{
		String sql = String.format("update chat_private_message set is_receiver_online = 1 where receiver_player_id = %d", playerId);
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId, sql);
	}
	
	public static void updateUnreadMsgCount(int playerId)
	{
		String sql = String.format("update player set unread_msg_count = unread_msg_count + 1 where player_id=%d", playerId);
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId, sql);
	}
	
	public static void deleteUnreadMsgCount(int playerId)
	{
		String sql = String.format("update player set unread_msg_count = 0 where player_id=%d", playerId);
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId, sql);
	}

	// 获取玩家最新count条私聊信息
	public static ArrayList<ChatMessage.Builder> getPrivateMessages(int playerId, int messageCount)
	{
		ArrayList<ChatMessage.Builder> list = new ArrayList<ChatMessage.Builder>();
		String sql = String.format("select * from chat_private_message where receiver_player_id = %d or sender_player_id = %d "
				+ " order by idx  desc limit %d", playerId, playerId, messageCount);
		CachedRowSet rs = null;
		try
		{
			rs = ServerDataGS.dbCluster.getGameDBClient().executeQuery(sql);
			if (rs != null)
			{
				while (rs.next())
				{
					ChatMessage.Builder builder = ChatMessage.newBuilder();
					builder.setMessageType(_ChatType.Private);
					builder.setReceiverId(rs.getInt("receiver_player_id"));
					builder.setSenderId(rs.getInt("sender_player_id"));
					builder.setIsReceiverOnline((rs.getInt("is_receiver_online") == 1) ? true : false);
					builder.setTime(rs.getDate("send_time").getTime());
					builder.setContent(rs.getString("content"));

					list.add(builder);
				}
			}
		}
		catch (SQLException e)
		{
			logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
		}
		finally
		{
			if (rs != null)
				try
				{
					rs.close();
				}
				catch (SQLException e)
				{
					logger.error("{}\n{}",e.getMessage(),ExceptionUtils.getStackTrace(e));
				}
		}
		return list;
	}

}
