/*
 * 文 件 名:  Logic_Chat.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:  <描述>
 * 创 建 人:  <创建人>
 * 创建时间:  2014-4-25
 * 修 改 人:  <修改人>
 * 修改时间:  2014-4-25
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.chat;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.chat.logic.CG_ChatReqHandler;
import com.kodgames.corgi.server.gameserver.chat.logic.CG_CloseChatMessageDialogReqHandler;
import com.kodgames.corgi.server.gameserver.chat.logic.CG_QueryChatMessageListReqHandler;

/**
 * <一句话功能简述> <功能详细描述>
 * 
 * @author 姓名
 * @version [版本号, 2014-4-25]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
public class Logic_Chat
{
	private CG_ChatReqHandler cg_ChatHandler = null;
	private CG_QueryChatMessageListReqHandler cg_QueryChatMessageListHandler = null;
	private CG_CloseChatMessageDialogReqHandler cg_CloseChatMessageDialogHandler = null;

	public void init()
	{
		cg_ChatHandler = new CG_ChatReqHandler();
		cg_QueryChatMessageListHandler = new CG_QueryChatMessageListReqHandler();
		cg_CloseChatMessageDialogHandler = new CG_CloseChatMessageDialogReqHandler();
	}

	public void registerProtoBufType(Controller controller)
	{
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_CHAT_REQ, GameProtocolsForClient.CG_ChatReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_CHATMESSAGE_REQ, GameProtocolsForClient.CG_QueryChatMessageListReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_CLOSECHATMESSAGEDIALOG_REQ, GameProtocolsForClient.CG_CloseChatMessageDialogReq.getDefaultInstance());
	}

	public void registerMessageHandler(Controller controller)
	{
		controller.addHandler(ClientProtocols.P_GAME_CG_CHAT_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_ChatHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_CHATMESSAGE_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryChatMessageListHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_CLOSECHATMESSAGEDIALOG_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_CloseChatMessageDialogHandler));
	}

}
