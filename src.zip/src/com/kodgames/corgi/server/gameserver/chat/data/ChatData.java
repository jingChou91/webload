package com.kodgames.corgi.server.gameserver.chat.data;

public class ChatData
{
	// 目前该数据只在加载playerNode时赋值，queryInitInfo时传给客户端
	private int unreadPrivateMsgCount;

	public int getUnreadPrivateMsgCount()
	{
		return unreadPrivateMsgCount;
	}

	public void setUnreadPrivateMsgCount(int unreadPrivateMsgCount)
	{
		this.unreadPrivateMsgCount = unreadPrivateMsgCount;
	}

	public void addUnreadPrivateMsgCount()
	{
		this.unreadPrivateMsgCount++;
	}
}
