/*
 * 文 件 名:  Logic_FiveStaEvaluateReward.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:  <描述>
 * 创 建 人:  <创建人>
 * 创建时间:  2014年6月3日
 * 修 改 人:  <修改人>
 * 修改时间:  2014年6月3日
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.fivestarevaluatereward;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.fivestarevaluatereward.logic.CG_GiveFiveStarsEvaluateReqHandler;

/**
 * <一句话功能简述> <功能详细描述>
 * 
 * @author 姓名
 * @version [版本号, 2014年6月3日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
public class Logic_FiveStarEvaluateReward
{
	private CG_GiveFiveStarsEvaluateReqHandler cg_GiveFiveStarsEvaluateReqHandler = null;

	public void init()
	{
		this.cg_GiveFiveStarsEvaluateReqHandler = new CG_GiveFiveStarsEvaluateReqHandler();
	}

	public void registerProtoBufType(Controller controller)
	{
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_GIVE_FIVE_STARS_EVALUATE_REQ,
			GameProtocolsForClient.CG_GiveFiveStarsEvaluateReq.getDefaultInstance());
	}

	public void registerMessageHandler(Controller controller)
	{
		controller.addHandler(ClientProtocols.P_GAME_CG_GIVE_FIVE_STARS_EVALUATE_REQ,
			ServerUtil.getFacilityMessageHandlerFactory(cg_GiveFiveStarsEvaluateReqHandler));
	}
}
