package com.kodgames.corgi.server.gameserver.fivestarevaluatereward.data;

public class EvaluateData
{
	private boolean hasEvaluate = false;
	private int cancelEvaluateLevel;

	public int getCancelEvaluateLevel()
	{
		return cancelEvaluateLevel;
	}

	public void setCancelEvaluateLevel(int cancelEvaluateLevel)
	{
		this.cancelEvaluateLevel = cancelEvaluateLevel;
	}

	public boolean isHasEvaluate()
	{
		return hasEvaluate;
	}

	public void setHasEvaluate(boolean hasEvaluate)
	{
		this.hasEvaluate = hasEvaluate;
	}
}
