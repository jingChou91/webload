package com.kodgames.corgi.server.gameserver.fivestarevaluatereward.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.LevelConfig;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_GiveFiveStarsEvaluateReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_GiveFiveStarsEvaluateRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.email.util.specialemail.FiveStarEvaluateEmailUtil;
import com.kodgames.gamedata.baseinfo.BaseInfoConfigMgr;
import com.kodgames.gamedata.player.PlayerDB;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_GiveFiveStarsEvaluateReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_GiveFiveStarsEvaluateReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		CG_GiveFiveStarsEvaluateReq request = (CG_GiveFiveStarsEvaluateReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_GiveFiveStarsEvaluateRes.Builder builder = GC_GiveFiveStarsEvaluateRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_GIVE_FIVE_STARS_EVALUATE_RES);
		builder.setCallback(request.getCallback());
		int playerId = sender.getClientUID().getPlayerID();

		int result = ClientProtocols.E_GAME_GIVE_FIVE_STARS_EVALUATE_SUCCESS;
		logger.info("recv CG_GiveFiveStarsEvaluateReq, playerId = {}", playerId);
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		// Add lock
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_GIVE_FIVE_STARS_EVALUATE_FAILED_LOAD_PLAYER;
					break;
				}

				if (BaseInfoConfigMgr.getInstance().getCfg().isShowGiveMeFive() == false)
				{
					result = ClientProtocols.E_GAME_GIVE_FIVE_STARS_EVALUATE_FAILED_NOT_OPEN;
					break;
				}

				LevelConfig.GiveMeFiveConfig giveMeFiveConfig = cd.get_LevelConfig().get_giveMeFiveConfig();
				if (giveMeFiveConfig == null)
				{
					result = ClientProtocols.E_GAME_GIVE_FIVE_STARS_EVALUATE_ERROR_LEVELCONF_ERROR;
					break;
				}

				if (request.hasIsEvaluate())
				{
					playerNode.getPlayerInfo().getEvaluateData().setHasEvaluate(true);
					PlayerDB.giveFiveEvaluate(playerId, playerNode.getPlayerInfo().getEvaluateData().isHasEvaluate(), playerNode.getPlayerInfo().getEvaluateData().getCancelEvaluateLevel());
					FiveStarEvaluateEmailUtil.sendPlayerEmailsByRewardSetId(playerNode, playerId, giveMeFiveConfig.get_rewardSetId(), 1, null);
				}
				else
				{
					 playerNode.getPlayerInfo().getEvaluateData().setCancelEvaluateLevel(playerNode.getGamePlayer().getLevel());
					 PlayerDB.giveFiveEvaluate(playerId, playerNode.getPlayerInfo().getEvaluateData().isHasEvaluate(),  playerNode.getPlayerInfo().getEvaluateData().getCancelEvaluateLevel());
				}
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);

		return HandlerAction.TERMINAL;
	}

}
