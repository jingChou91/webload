package com.kodgames.corgi.server.gameserver.exchange.data;

import com.kodgames.corgi.protocol.CommonProtocols;

public class ItemEx {
	private int id;
	private int count;
	private int breakThroughLevelFrom = -1;//-1表示没有限制
	private int breakThroughLevelTo = -1;  //-1表示没有限制
	private int levelFrom = -1; //-1表示没有限制
	private int levelTo = -1;	//-1表示没有限制
	
	public ItemEx(int id, int count)
	{
		this.id = id;
		this.count = count;
	}

	public ItemEx(int id, int count, int breakThroughlevelFrom, int breakThroughlevelTo)
	{
		this.id = id;
		this.count = count;
		this.breakThroughLevelFrom = breakThroughlevelFrom;
		this.breakThroughLevelTo = breakThroughlevelTo;
	}
	
	public ItemEx(int id, int count,  int breakThroughlevelFrom, int breakThroughlevelTo, int levelFrom, int levelTo)
	{
		this.id = id;
		this.count = count;
		this.breakThroughLevelFrom = breakThroughlevelFrom;
		this.breakThroughLevelTo = breakThroughlevelTo;
		this.levelFrom = levelFrom;
		this.levelTo = levelTo;
	}
	

	public com.kodgames.corgi.protocol.CommonProtocols.ItemEx toProtobuf()
	{
		CommonProtocols.ItemEx.Builder builder = CommonProtocols.ItemEx.newBuilder();

		builder.setCount(count);
		builder.setId(id);
		builder.setExtensionBreakThroughLevelFrom(breakThroughLevelFrom);
		builder.setExtensionBreakThroughLevelTo(breakThroughLevelTo);
		builder.setExtensionLevelFrom(levelFrom);
		builder.setExtensionLevelTo(levelTo);
		return builder.build();
	}

	public ItemEx fromProtobuf(com.kodgames.corgi.protocol.CommonProtocols.ItemEx costProtoBuf)
	{
		this.id = costProtoBuf.getId();
		this.count = costProtoBuf.getCount();
		this.breakThroughLevelFrom = costProtoBuf.getExtensionBreakThroughLevelFrom();
		this.breakThroughLevelTo= costProtoBuf.getExtensionBreakThroughLevelTo();
		this.levelFrom = costProtoBuf.getExtensionLevelFrom();
		this.levelTo= costProtoBuf.getExtensionLevelTo();		
		return this;
	}
}
