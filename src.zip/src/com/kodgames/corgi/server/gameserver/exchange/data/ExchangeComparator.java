package com.kodgames.corgi.server.gameserver.exchange.data;

import java.util.Comparator;

import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.CommonProtocols.Exchange;

public class ExchangeComparator implements Comparator<CommonProtocols.Exchange> {

	public int compare(Exchange o1, Exchange o2) {
		int a = o1.getSortIndex();
		int b = o2.getSortIndex();
		return a - b;
	}
}