package com.kodgames.corgi.server.gameserver.exchange.db;

import com.kodgames.corgi.server.dbclient.TableChangeEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.exchange.data.Exchange;

public class ExchangeDB 
{
	public static void updateExchange(int playerId, Exchange exchange)
	{
		String sqlCommand = String.format("replace into exchange (player_id,exchange_id, next_open_time, exchange_count, exchange_resetcount) VALUES (%d,%d,%d,%d,%d)", playerId, exchange.getId(),exchange.getNextOpenTime(),exchange.getAlreadyExchangeCount(),exchange.getResetCount());
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(TableChangeEvent.getKey(playerId, TableChangeEvent.EXCHANGE_UPDATEEXCHANGE,exchange.getId()),playerId,sqlCommand);
	}

}
