package com.kodgames.corgi.server.gameserver.exchange.data;

import java.util.HashMap;

public class ExchangeData {
	private HashMap<Integer, Exchange> exchanges = new HashMap<>(); // 兑换数据

	public HashMap<Integer, Exchange> getExchanges() {
		return exchanges;
	}

	public void setExchanges(HashMap<Integer, Exchange> exchanges) {
		this.exchanges = exchanges;
	}

}
