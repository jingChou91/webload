package com.kodgames.corgi.server.gameserver.exchange.data;

import com.kodgames.corgi.server.gameserver.exchange.db.ExchangeDB;

public class ExchangeMgr {
	public static void updateExchange(int playerId, Exchange exchange) {
		ExchangeDB.updateExchange(playerId, exchange);
	}
}
