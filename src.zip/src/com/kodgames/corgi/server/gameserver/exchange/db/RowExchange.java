package com.kodgames.corgi.server.gameserver.exchange.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;

import javax.sql.rowset.CachedRowSet;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.ExchangeConfig;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.server.gameserver.exchange.data.Exchange;
import com.kodgames.gamedata.dbcommon.DBEasy;
import com.kodgames.gamedata.player.PlayerNode;


public class RowExchange 
{
	// 查询
	public static void selectPrivate(int queryIndex, Connection con, PreparedStatement[] vps,
		CachedRowSet[] vrs, PlayerNode playerNode) throws SQLException {

		String sql = "select * from exchange where player_id= "+playerNode.getPlayerId() ;
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, null);
		ConfigDatabase cd = CfgDB.getDefautConfig();
		HashMap<Integer, Exchange> exchanges = new HashMap<>();
		ExchangeConfig exchangeConfig = cd.get_ExchangeConfig();

		if (vrs[queryIndex] != null) {
			CachedRowSet rs = vrs[queryIndex];
			while (rs.next())
			{
				Exchange exchange = new Exchange();
				int exchangeId = rs.getInt("exchange_id");
				if(exchangeConfig.GetExchangeById(exchangeId) != null)
				{
					exchange.setId(exchangeId);
					exchange.setAlreadyExchangeCount(rs.getInt("exchange_count"));
					exchange.setNextOpenTime(rs.getLong("next_open_time"));
					exchange.setResetCount(rs.getLong("exchange_resetcount"));
					exchanges.put(exchange.getId(), exchange);
				}
			}
		}

		playerNode.getPlayerInfo().getExchangeData().setExchanges(exchanges);
	}
}
