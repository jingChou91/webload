package com.kodgames.corgi.server.gameserver.exchange;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.exchange.logic.CG_ExchangeReqHandler;
import com.kodgames.corgi.server.gameserver.exchange.logic.CG_QueryExchangeListReqHandler;

public class Logic_Exchange 
{
	private CG_ExchangeReqHandler cg_ExchangeReqHandler = null;
	private CG_QueryExchangeListReqHandler cg_QueryExchangeListReqHandler = null;

	public void init() 
	{
		this.cg_ExchangeReqHandler = new CG_ExchangeReqHandler();
		this.cg_QueryExchangeListReqHandler = new CG_QueryExchangeListReqHandler();
	}

	public void registerProtoBufType(Controller controller) 
	{
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_EXCHANGE_REQ, GameProtocolsForClient.CG_ExchangeReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_EXCHANGE_LIST_REQ, GameProtocolsForClient.CG_QueryExchangeListReq.getDefaultInstance());
	}

	public void registerMessageHandler(Controller controller) 
	{
		controller.addHandler(ClientProtocols.P_GAME_CG_EXCHANGE_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_ExchangeReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_EXCHANGE_LIST_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryExchangeListReqHandler));
	}

}
