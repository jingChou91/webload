package com.kodgames.corgi.server.gameserver.exchange.data;

import com.kodgames.corgi.protocol.CommonProtocols;


public class Exchange 
{
	private int id;
	private int alreadyExchangeCount;
	private long nextOpenTime;
	private long resetCount;
	
	public void refresh(long resetCount)
	{
		this.resetCount = resetCount;
		this.alreadyExchangeCount = 0;
		this.nextOpenTime = 0;
	}
	
	public long getResetCount() {
		return resetCount;
	}

	public void setResetCount(long resetCount) {
		this.resetCount = resetCount;
	}

	public int getId() 
	{
		return id;
	}
	public void setId(int id) 
	{
		this.id = id;
	}
	public int getAlreadyExchangeCount() 
	{
		return alreadyExchangeCount;
	}
	public void setAlreadyExchangeCount(int alreadyExchangeCount) 
	{
		this.alreadyExchangeCount = alreadyExchangeCount;
	}
	public long getNextOpenTime() 
	{
		return nextOpenTime;
	}
	public void setNextOpenTime(long nextOpenTime) 
	{
		this.nextOpenTime = nextOpenTime;
	}
	
	public static CommonProtocols.CostAsset fromServerCommon(ClientServerCommon.CostAsset costAssetServerCommon)
	{
		CommonProtocols.CostAsset.Builder costAsset  =CommonProtocols.CostAsset.newBuilder();
		costAsset.setCount(costAssetServerCommon.get_count());
		costAsset.setIconId(costAssetServerCommon.get_iconId());
		costAsset.setQualityLevel(costAssetServerCommon.get_qualityLevel());
		costAsset.setSubType(costAssetServerCommon.get_subType());
		costAsset.setType(costAssetServerCommon.get_type());
		costAsset.setBreakThroughLevelFrom(costAssetServerCommon.get_breakThroughLevelFrom());
		costAsset.setBreakThroughLevelTo(costAssetServerCommon.get_breakThroughLevelTo());
		costAsset.setLevelFrom(costAssetServerCommon.get_levelFrom());
		costAsset.setLevelTo(costAssetServerCommon.get_levelTo());
		return costAsset.build();
	}
}
