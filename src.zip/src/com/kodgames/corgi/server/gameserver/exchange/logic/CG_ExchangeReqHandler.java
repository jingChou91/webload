package com.kodgames.corgi.server.gameserver.exchange.logic;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.ExchangeConfig;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_ExchangeReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_ExchangeRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.common.TimeRange;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.exchange.data.Exchange;
import com.kodgames.corgi.server.gameserver.exchange.data.ExchangeMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class CG_ExchangeReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_ExchangeReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		CG_ExchangeReq request = (CG_ExchangeReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);
		CostAndRewardAndSync crsToclient = new CostAndRewardAndSync();

		GC_ExchangeRes.Builder builder = GC_ExchangeRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_EXCHANGE_RES);
		builder.setCallback(request.getCallback());
		builder.setExchangeId(request.getExchangeId());

		int playerId = sender.getClientUID().getPlayerID();
		int groupId = request.getGroupId();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		int result = ClientProtocols.E_GAME_EXCHANGE_SUCCESS;
		logger.info("CG_ExchangeReq, playerId = {}", playerId);
		// Add lock
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					logger.warn("get player failed");
					result = ClientProtocols.E_GAME_EXCHANGE_FAILED_GET_PLAYER_FAILED;
					break;
				}

				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Exchange))
				{
					result = ClientProtocols.E_GAME_EXCHANGE_FUNCTION_NOT_OPEN;
					break;
				}

				ExchangeConfig.Exchange exchangeConfig =
					cd.get_ExchangeConfig().GetExchangeById(request.getExchangeId());
				if (null == exchangeConfig)
				{
					result = ClientProtocols.E_GAME_EXCHANGE_ERROR_EXCHANGE_CONFIG_ERROR;
					break;
				}

				// 判断VIP等级是否满足
				if (playerNode.getGamePlayer().getVipLevel() < exchangeConfig.get_vipLevel())
				{
					result = ClientProtocols.E_GAME_EXCHANGE_FAILED_VIPLEVEL_NOT_MEET;
					break;
				}

				if (playerNode.getGamePlayer().getLevel() < exchangeConfig.get_playerLevel())
				{
					result = ClientProtocols.E_GAME_EXCHANGE_FAILED_PLAYERLEVEL_NOT_MEET;
					break;
				}

				// 判断该物品是否已经过期
				long openTime =
					TimeRange.fixAndSelectRightTime(exchangeConfig.get_openTime(), null, null, playerNode, false);
				long closeTime =
					TimeRange.fixAndSelectRightTime(exchangeConfig.get_closeTime(), null, null, playerNode, true);
				if (System.currentTimeMillis() < openTime)
				{
					result = ClientProtocols.E_GAME_EXCHANGE_FAILED_EXCHANGE_NOT_OPEN;
					break;
				}

				if (closeTime > 0 && System.currentTimeMillis() > closeTime)
				{
					result = ClientProtocols.E_GAME_EXCHANGE_FAILED_EXCHANGE_ALREADY_CLOSED;
					break;
				}

				// 判断当前GroupId是否有效
				long resetTime = exchangeConfig.get_groupResetTime() * 1000;
				int index = 0;
				long resetCount = 0;
				if (resetTime <= 0)
				{
					index = 0;
				}
				else
				{
					resetCount = (System.currentTimeMillis() - openTime) / resetTime;
					if(resetCount < 0)
					{
						result = ClientProtocols.E_GAME_EXCHANGE_NOT_OPEN;
						break;
					}
					index = (int)(resetCount % exchangeConfig.Get_groupsCount());
				}
				int groupIdNow = index;

				if (groupId != groupIdNow)
				{
					result = ClientProtocols.E_GAME_EXCHANGE_FAILED_EXCHANGE_OUT_OF_TIME;
					break;
				}

				ArrayList<Cost> costs = Cost.generateCostListFromProtoBuf(request.getCostsList());
				List<ClientServerCommon.ItemEx> costsConfig = new ArrayList<>();
				for (int i = 0; i < exchangeConfig.Get_groupsByIndex(groupId).Get_costsCount(); i++)
				{
					costsConfig.add(exchangeConfig.Get_groupsByIndex(groupId).Get_costsByIndex(i));
				}

				List<ClientServerCommon.CostAsset> costAssetsConfig = new ArrayList<>();
				for (int i = 0; i < exchangeConfig.Get_groupsByIndex(groupId).Get_costAssetsCount(); i++)
				{
					costAssetsConfig.add(exchangeConfig.Get_groupsByIndex(groupId).Get_costAssetsByIndex(i));
				}

				// 判断玩家发来的Cost和配置文件中是否相同
				if (false == CostAndRewardManager.isMeetCostRequirement(costs, costsConfig, costAssetsConfig, cd, playerNode))
				{
					result = ClientProtocols.E_GAME_EXCHANGE_FAILED_COSTS_NOT_MEEET_REQUIREMENT;
					break;
				}
				
				if (result != ClientProtocols.E_GAME_EXCHANGE_SUCCESS)
				{
					break;
				}

				// 判断消耗是否足够
				Cost notEnoughCost = new Cost();
				if (false == CostAndRewardManager.checkCosts(playerNode,
					costs,
					cd,
					KodLogEvent.ExchangeLogic_Exchange,
					notEnoughCost))
				{
					crsToclient.setNotEnoughCost(notEnoughCost);
					builder.setCostAndRewardAndSync(crsToclient.toProtobuf());
					result = ClientProtocols.E_GAME_EXCHANGE_FAILED_CONSUMABLE_NOT_ENOUGH;
					break;
				}

				// 如果INDEX不等，则刷新Exchange数据
				// 兑换配置文件的刷新时间设计的意图是将配置多个兑换group的兑换项目限购次数清零，并且更新到下一个兑换group。现在只有一个兑换项目的限购兑换也收到影响
				if (playerNode.getPlayerInfo().getExchangeData().getExchanges().containsKey(request.getExchangeId())
					&& playerNode.getPlayerInfo()
						.getExchangeData()
						.getExchanges()
						.get(request.getExchangeId())
						.getResetCount() != resetCount && exchangeConfig.Get_groupsCount() > 1)
				{
					playerNode.getPlayerInfo()
						.getExchangeData()
						.getExchanges()
						.get(request.getExchangeId())
						.refresh((int)resetCount);
				}

				// 判断是否还有兑换次数 get_exchangeCount < 0 无限兑换
				if (exchangeConfig.get_exchangeCount() == 0
					|| (exchangeConfig.get_exchangeCount() > 0
						&& playerNode.getPlayerInfo()
							.getExchangeData()
							.getExchanges()
							.containsKey(request.getExchangeId()) && playerNode.getPlayerInfo()
						.getExchangeData()
						.getExchanges()
						.get(request.getExchangeId())
						.getAlreadyExchangeCount() >= exchangeConfig.get_exchangeCount()))
				{
					result = ClientProtocols.E_GAME_EXCHANGE_FAILED_EXTEND_MAX_EXCHANGE_COUNT;
					break;
				}

				// 如果玩家曾经兑换过
				Exchange exchange;
				long nextOpenTime = System.currentTimeMillis() + exchangeConfig.get_coolDownTime() * 1000;
				if (playerNode.getPlayerInfo().getExchangeData().getExchanges().containsKey(request.getExchangeId()))
				{
					exchange = playerNode.getPlayerInfo().getExchangeData().getExchanges().get(request.getExchangeId());
					exchange.setAlreadyExchangeCount(exchange.getAlreadyExchangeCount() + 1);
					exchange.setNextOpenTime(nextOpenTime);
				}
				else
				{
					exchange = new Exchange();
					exchange.setId(request.getExchangeId());
					exchange.setAlreadyExchangeCount(1);
					exchange.setNextOpenTime(nextOpenTime);
					exchange.setResetCount(resetCount);

					playerNode.getPlayerInfo().getExchangeData().getExchanges().put(exchange.getId(), exchange);
				}

				// 更新数据库
				ExchangeMgr.updateExchange(playerId, exchange);
				if(exchangeConfig.get_coolDownTime() == 0)
				{
					builder.setNextOpenTime(0);
				}
				else
				{
					builder.setNextOpenTime(nextOpenTime);
				}
				// 使用消耗品
				CostAndRewardAndSync crsHere = new CostAndRewardAndSync();
				crsHere.setCosts(costs);
				CostAndRewardManager.consumeCosts(playerNode, costs, cd, KodLogEvent.ExchangeLogic_Exchange, 0, 0);
				crsToclient.megerCostAndRewardAndSync(crsHere);

				// 获得奖励
				Reward reward =
					new Reward().fromClientServerCommon(exchangeConfig.Get_groupsByIndex(groupId).get_reward());
				
				CostAndRewardAndSync crsGetReward = new CostAndRewardAndSync();
				crsGetReward.mergeReward(reward);
				CostAndRewardManager.addReward(playerNode, reward, cd, KodLogEvent.ExchangeLogic_Exchange);
				crsToclient.megerCostAndRewardAndSync(crsGetReward);

				builder.setCostAndRewardAndSync(crsToclient.toProtobuf());
				// 发送跑马灯
				// if(cd.get_AssetDescConfig().GetAssetDescById(cd.get_ActivityConfig().get_exchangeActivity().get_activityId())!=null)
				// {
				// FlowMsgMaker.sendFlowMsgsFromReward(reward,
				// playerNode.getGamePlayer().getFixName(),
				// FlowMsgMaker._ActivityRewardMsg,cd.get_AssetDescConfig().GetAssetDescById(cd.get_ActivityConfig().get_exchangeActivity().get_activityId()).get_name());
				// }

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
