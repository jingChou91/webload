package com.kodgames.corgi.server.gameserver.exchange.logic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.ExchangeConfig;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryExchangeListReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryExchangeListRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.common.TimeRange;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.exchange.data.Exchange;
import com.kodgames.corgi.server.gameserver.exchange.data.ItemEx;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.corgi.server.gameserver.exchange.data.ExchangeComparator;


public class CG_QueryExchangeListReqHandler extends MessageHandler {
	private static final Logger logger = LoggerFactory
			.getLogger(CG_QueryExchangeListReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message) {

		CG_QueryExchangeListReq request = (CG_QueryExchangeListReq) message
				.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryExchangeListRes.Builder builder = GC_QueryExchangeListRes
				.newBuilder();
		Protocol protocol = new Protocol(
				ClientProtocols.P_GAME_GC_QUERY_EXCHANGE_LIST_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		int result = ClientProtocols.E_GAME_QUERY_EXCHANGE_LIST_SUCCESS;
		logger.info("CG_QueryExchangeListReq, playerId = {}", playerId);
		List<com.kodgames.corgi.protocol.CommonProtocols.Exchange> exchangeList = new ArrayList<com.kodgames.corgi.protocol.CommonProtocols.Exchange>();
		// Add lock
		ServerDataGS.playerManager.lockPlayer(playerId);
		try {
			do {
				PlayerNode playerNode = ServerDataGS.playerManager
						.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null) {
					logger.warn("get player failed");
					result = ClientProtocols.E_GAME_QUERY_EXCHANGE_LIST_FAILED_GET_PLAYER_FAILED;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Exchange))
				{
					result = ClientProtocols.E_GAME_EXCHANGE_FUNCTION_NOT_OPEN;
					break;
				}

				ExchangeConfig exchangeConfig = cd.get_ExchangeConfig();
				if (null == exchangeConfig) {
					result = ClientProtocols.E_GAME_QUERY_EXCHANGE_LIST_ERROR_EXCHANGE_CONFIG_ERROR;
					break;
				}
					
				long nowTime = System.currentTimeMillis(); 
				int j = exchangeConfig.Get_exchangesCount();//GetExchangeCount()
				for (int i = 0; i < j; ++i) 
				{
					ExchangeConfig.Exchange exchange = exchangeConfig
							.Get_exchangesByIndex(i);//GetExchange(i)
					if (exchange.Get_groupsCount() <= 0) {
						continue;
					}
					com.kodgames.corgi.protocol.CommonProtocols.Exchange.Builder temp = com.kodgames.corgi.protocol.CommonProtocols.Exchange
							.newBuilder();
					int id = exchange.get_id();
					temp.setExchangeId(id);
					temp.setSortIndex(exchange.get_sortIndex());
					temp.setVipLevel(exchange.get_vipLevel());
					temp.setPlayerLevel(exchange.get_playerLevel());
					temp.setExchangeCount(exchange.get_exchangeCount());
					long openTime = TimeRange.fixAndSelectRightTime(
							exchange.get_openTime(),
							exchange.get_relativeOpenTime(), null, playerNode,
							false);
					long closeTime = TimeRange.fixAndSelectRightTime(
							exchange.get_closeTime(),
							exchange.get_relativeCloseTime(), null, playerNode,
							true);
					temp.setOpenTime(openTime);
					temp.setEndTime(closeTime);

					long resetTime = exchange.get_groupResetTime() * 1000;
					long resetCount = (resetTime == 0) ? 0
							: (nowTime - openTime)
									/ resetTime;
					
					//配置了一个未来的时间,取模会得到负的值. 处理方式为不显示该条目
					if(resetCount < 0)
					{
						continue;
					}
					int index = (int) (resetCount % exchange.Get_groupsCount());
					int groupId = index;

					if (exchange.Get_groupsCount() == 1) {
						temp.setNextRefreshTime(-1);
					} else {
						temp.setNextRefreshTime(openTime + resetTime
								* (resetCount + 1));
					}

					// 兑换配置文件的刷新时间设计的意图是将配置多个兑换group的兑换项目限购次数清零，并且更新到下一个兑换group。现在只有一个兑换项目的限购兑换也收到影响
					if (playerNode.getPlayerInfo().getExchangeData()
							.getExchanges().containsKey(id)) {
						if (exchange.Get_groupsCount() == 1
								|| playerNode.getPlayerInfo().getExchangeData()
										.getExchanges().get(id).getResetCount() == resetCount) {
							temp.setAlreadyExchangeCount(playerNode
									.getPlayerInfo().getExchangeData()
									.getExchanges().get(id)
									.getAlreadyExchangeCount());
							temp.setNextOpenTime(playerNode.getPlayerInfo()
									.getExchangeData().getExchanges().get(id)
									.getNextOpenTime());
						}
					}
					ExchangeConfig.Group group = exchange.Get_groupsByIndex(groupId);
					temp.setGroupId(group.get_id());
					
					com.kodgames.corgi.protocol.CommonProtocols.ItemEx.Builder itemExBuilder = com.kodgames.corgi.protocol.CommonProtocols.ItemEx.newBuilder();
					itemExBuilder.setId(group.get_reward().get_id());
					itemExBuilder.setCount(group.get_reward().get_count());			
					itemExBuilder.setExtensionBreakThroughLevelFrom(group.get_reward().get_breakthoughtLevel());
					itemExBuilder.setExtensionBreakThroughLevelTo(group.get_reward().get_breakthoughtLevel());
					itemExBuilder.setExtensionLevelFrom(group.get_reward().get_level());
					itemExBuilder.setExtensionLevelTo(group.get_reward().get_level());
					temp.setGainItem(itemExBuilder); 
									
					for (int k = 0; k < group.Get_costsCount(); k++) {//GetCostCount()
						ItemEx itemEx = new ItemEx(group.Get_costsByIndex(k).get_id(), group//GetCost(k)
								.Get_costsByIndex(k).get_count(), group.Get_costsByIndex(k).get_extensionBreakThroughLevelFrom(), group.Get_costsByIndex(k).get_extensionBreakThroughLevelTo());
						temp.addCosts(itemEx.toProtobuf());
					}
					for (int k = 0; k < group.Get_costAssetsCount(); k++) {//GetCostAssetCount()
						temp.addCostAssets(Exchange.fromServerCommon(group
								.Get_costAssetsByIndex(k)));//GetCostAsset(k))
					}
					exchangeList.add(temp.build());
				}
				 // (exchangeList, new ExchangeComparator());
				Collections.sort(exchangeList, new ExchangeComparator());
				builder.addAllExchanges(exchangeList);
			} while (false);
		} finally {
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}
		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
