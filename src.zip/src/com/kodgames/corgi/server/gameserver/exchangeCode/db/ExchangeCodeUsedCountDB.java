package com.kodgames.corgi.server.gameserver.exchangeCode.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;

import com.kodgames.corgi.server.gameserver.exchangeCode.data.ExchangeCode;
import com.kodgames.gamedata.dbcommon.DBEasy;

public class ExchangeCodeUsedCountDB
{

	// 增加兑换码使用记录
	public static void insertUsedExchangeCodeCount(int index, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, int playerId, ExchangeCode code) throws SQLException
	{
		String sql = "insert ignore into exchange_code_used_count(code_prefix, player_id, code_used_num) values(?,? ,1)";
		vps[index] = con.prepareStatement(sql);
		DBEasy.doPrivateUpdate(vps[index], sql, new Object[] { code.getPrefix(), playerId });
	}

	// 更新兑换码使用次数
	public static void addUsedExchangeCodeCount(int index, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, int playerId, ExchangeCode code) throws SQLException
	{
		String sql = "update exchange_code_used_count set code_used_num = code_used_num + 1 where player_id = ? and code_prefix = ?";
		vps[index] = con.prepareStatement(sql);
		DBEasy.doPrivateUpdate(vps[index], sql, new Object[] { playerId, code.getPrefix() });
	}

	// 取得同一批次兑换码使用个数
	public static int getUsedExchangeCodeCount(int index, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, int playerId, ExchangeCode code) throws SQLException
	{
		String sql = "select code_used_num from exchange_code_used_count where code_prefix = ? and player_Id = ? ";
		vps[index] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, index);
		vrs[index] = DBEasy.doPrivateQuery(vps[index], sql, new Object[] { code.getPrefix(), playerId });
		if (vrs[index].next())
		{
			return vrs[index].getInt("code_used_num");
		}
		return 0;
	}

}
