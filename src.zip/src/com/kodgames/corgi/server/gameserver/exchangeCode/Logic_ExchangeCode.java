/*
 * 文 件 名:  Logic_ExchangeCode.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:  <描述>
 * 创 建 人:  <创建人>
 * 创建时间:  2014-4-30
 * 修 改 人:  <修改人>
 * 修改时间:  2014-4-30
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.exchangeCode;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.exchangeCode.logic.CG_ExchangeCodeReqHandler;

/**
 * <一句话功能简述> <功能详细描述>
 * 
 * @author 姓名
 * @version [版本号, 2014-4-30]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
public class Logic_ExchangeCode
{
	private CG_ExchangeCodeReqHandler cg_exchangeCodeHandler = null;

	public void init()
	{
		cg_exchangeCodeHandler = new CG_ExchangeCodeReqHandler();
	}

	public void registerProtoBufType(Controller controller)
	{
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_EXCHANGECODE_REQ, GameProtocolsForClient.CG_ExchangeCodeReq.getDefaultInstance());
	}

	public void registerMessageHandler(Controller controller)
	{
		controller.addHandler(ClientProtocols.P_GAME_CG_EXCHANGECODE_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_exchangeCodeHandler));
	}
}
