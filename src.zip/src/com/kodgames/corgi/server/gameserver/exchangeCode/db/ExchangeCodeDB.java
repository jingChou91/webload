package com.kodgames.corgi.server.gameserver.exchangeCode.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;

import com.kodgames.corgi.server.gameserver.exchangeCode.data.ExchangeCode;
import com.kodgames.gamedata.dbcommon.DBEasy;

public class ExchangeCodeDB
{

	// 更新兑换码可使用次数 <功能详细描述>
	public static void updateExchangeCode(int index, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, int playerId, ExchangeCode code) throws SQLException
	{
		String sql = null;
		sql = "replace into exchange_code (player_use_num, code) values(?, ?)";
		vps[index] = con.prepareStatement(sql);
		DBEasy.doPrivateUpdate(vps[index], sql, new Object[] { code.getPlayerUsedNum(), code.getCode() });
	}

	// 从数据库取得兑换码信息
	public static ExchangeCode getExchangeCode(int index, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, int playerId, String codeStr) throws SQLException
	{
		String sql = "select code,player_use_num from exchange_code where code = ? ";
		vps[index] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, index);
		vrs[index] = DBEasy.doPrivateQuery(vps[index], sql, new Object[] { codeStr });
		ExchangeCode code = null;
		if (vrs[index].next())
		{
			code = new ExchangeCode(vrs[index].getString("code"));
			code.setPlayerUsedNum(vrs[index].getInt("player_use_num"));
		}
		return code;
	}

}
