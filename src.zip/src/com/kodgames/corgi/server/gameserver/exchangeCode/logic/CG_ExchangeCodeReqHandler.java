/*
 * 文 件 名:  CG_ExchangeCodeHandler.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:  兑换码兑换请求处理
 * 创 建 人:  zhangdebo@kodgames.com
 * 创建时间:  2014-4-30
 * 修 改 人:  <修改人>
 * 修改时间:  2014-4-30
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.exchangeCode.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.AreaData;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_ExchangeCodeReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_ExchangeCodeRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.SQLFilter;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.exchangeCode.data.ConfigInfo;
import com.kodgames.corgi.server.gameserver.exchangeCode.data.ExchangeCodeConfigManager;
import com.kodgames.corgi.server.gameserver.exchangeCode.data.ExchangeManager;
import com.kodgames.corgi.server.gameserver.exchangeCode.data.ExchangeManager.ExchangeCodeType;
import com.kodgames.corgi.server.gameserver.exchangeCode.util.DesDecryptor;
import com.kodgames.corgi.server.gameserver.exchangeCode.util.ExchangeCodeCompatibleHelper;
import com.kodgames.corgi.server.gameserver.exchangeCode.util.FormatorUtil;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

/**
 * 兑换码兑换请求处理
 * 
 * @author zhangdebo@kodgames.com
 * @version [1.0, 2014-4-30]
 */
public class CG_ExchangeCodeReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_ExchangeCodeReqHandler.class);
	private static final int CODE_LENGTH = 12;
	public static final int NEW_CODE_LENGTH = 17;

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_ExchangeCodeHandler, playerId = {}", sender.getClientUID().getPlayerID());

		CG_ExchangeCodeReq request = (CG_ExchangeCodeReq) message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_ExchangeCodeRes.Builder builder = GC_ExchangeCodeRes.newBuilder();
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		
		String codeStr = request.getExchangeCode();
		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		int result = ClientProtocols.E_GAME_EXCHANGECODE_SUCCESS;
		do
		{
			if (codeStr == null || codeStr.length() == 0)
			{
				result = ClientProtocols.E_GAME_EXCHANGECODE_FAILED_NO_EXCHANGE_CODE;
				break;
			}
			if (codeStr.length() != CODE_LENGTH && codeStr.length() != NEW_CODE_LENGTH)
			{
				result = ClientProtocols.E_GAME_EXCHANGECODE_ERROR_FORMAT;
				break;
			}
			codeStr = codeStr.toUpperCase();
			ExchangeCodeType type = codeStr.length() == NEW_CODE_LENGTH ? ExchangeCodeType.Des : ExchangeCodeType.Normal;
			ConfigInfo config = ExchangeCodeConfigManager.getInstance().getConfig(codeStr.substring(0, 4));
			if (config == null)
			{
				result = ClientProtocols.E_GAME_EXCHANGECODE_ERROR_CODE;
				break;
			}

			ServerDataGS.playerManager.lockPlayer(playerId);
			try
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_EXCHANGECODE_LOAD_PLAYER_FAILED;
					break;
				}

				// 时间控制
				if (!isTimeValid(playerNode, config))
				{
					result = ClientProtocols.E_GAME_EXCHANGECODE_INVALID_TIME;
					break;
				}

				// 渠道控制
				int channelId = sender.getClientUID().getChannelId();
				if (!config.getChannelLimit().contains(channelId) && !config.getChannelLimit().contains(ConfigInfo.NO_LIMIT))
				{
					result = ClientProtocols.E_GAME_EXCHANGECODE_INVALID_CHANNEL;
					break;
				}

				// 区域控制
				int areaId = AreaData.getAreaId();
				if (!config.getAreaLimit().contains(areaId) && !config.getAreaLimit().contains(ConfigInfo.NO_LIMIT))
				{
					result = ClientProtocols.E_GAME_EXCHANGECODE_INVALID_AREA;
					break;
				}
				
				//判断新的兑换码是否在配置范围内
				if(type == ExchangeCodeType.Des)
				{
					//用于排除兑换码中的Ii0o
					if(!FormatorUtil.isLegal17DigitAndLetter(codeStr))
					{
						result = ClientProtocols.E_GAME_EXCHANGECODE_ERROR_CODE;
						break;	
					}
				
					String sign = codeStr.substring(0, 4);
					String encryptContext = codeStr.substring(4);
					DesDecryptor decryptor = new DesDecryptor();
					String plainText = decryptor.deCreateExchangeCode(encryptContext, sign);
					//###############兼容第一版生成器生成的兑换码
					if(!ExchangeCodeCompatibleHelper.isRealExchangeCode(sign, plainText, config, encryptContext))
					{
						result = ClientProtocols.E_GAME_EXCHANGECODE_ERROR_CODE;
						break;
					}
				}

				codeStr = SQLFilter.sql_inj(codeStr);
				result = ExchangeManager.doExchangeCode(playerId, codeStr, config, builder, type);
				if (result == ClientProtocols.E_GAME_EXCHANGECODE_SUCCESS)
				{
					Reward rewardConfig = ExchangeCodeConfigManager.getInstance().getConfig(codeStr.substring(0, 4)).getReward();
					Reward reward = new Reward();
					reward.copy(rewardConfig).refreshGuid();

					CostAndRewardAndSync crsForReward = new CostAndRewardAndSync();
					crsForReward.mergeReward(reward);
					CostAndRewardManager.addReward(playerNode, reward, cd, KodLogEvent.ExchangeCodeLogic_Exchange);
					crsForClient.megerCostAndRewardAndSync(crsForReward);

					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());

					String desc = config.getDescription();
					if (desc != null && !desc.trim().equals(""))
					{
						builder.setDescription(desc);
					}

					builder.setExchangeCode(request.getExchangeCode());
				}
			}
			finally
			{
				ServerDataGS.playerManager.unlockPlayer(playerId);
			}
		}
		while (false);

		builder.setCallback(request.getCallback());
		builder.setResult(result);

		ServerDataGS.transmitter.sendToClient(sender, ClientProtocols.P_GAME_GC_EXCHANGECODE_RES, builder.build());
		return HandlerAction.TERMINAL;
	}

	private boolean isTimeValid(PlayerNode playerNode, ConfigInfo config)
	{
		long currentTime = System.currentTimeMillis();
		long createAccountTime = playerNode.getPlayerInfo().getClientLoginMessage().getCreateTime();
		long relativeCreAccountStartTime = config.getRelativeTimeStart() + createAccountTime;
		long relativeCreAccountEndTime = config.getRelativeTimeEnd() + createAccountTime;

		if ((config.getAbsoluteTimeStart() <= currentTime || config.getAbsoluteTimeStart() == 0)
				&& (currentTime <= config.getAbsoluteTimeEnd() || config.getAbsoluteTimeEnd() == 0))
		{
			if ((relativeCreAccountStartTime <= currentTime || config.getRelativeTimeStart() == 0)
					&& (currentTime <= relativeCreAccountEndTime || config.getRelativeTimeEnd() == 0))
			{
				return true;
			}
		}
		return false;
	}
}
