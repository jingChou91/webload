package com.kodgames.corgi.server.gameserver.exchangeCode.data;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import javax.sql.rowset.CachedRowSet;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.gameconfiguration.AppPath;
import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.server.gameserver.avatar.data.Avatar;
import com.kodgames.corgi.server.gameserver.equipment.data.Equipment;
import com.kodgames.corgi.server.gameserver.skill.data.Skill;
import com.kodgames.gamedata.player.costandreward.Consume;
import com.kodgames.gamedata.player.costandreward.ItemType;
import com.kodgames.gamedata.player.costandreward.Reward;
import com.kodgames.gamedata.xml.IXmlLoader;
import com.kodgames.gamedata.xml.xmlConfig;

public class ExchangeCodeConfigManager implements IXmlLoader
{
	private static Logger logger = LoggerFactory.getLogger(ExchangeCodeConfigManager.class);

	private ConcurrentHashMap<String, ConfigInfo> configs = new ConcurrentHashMap<String, ConfigInfo>();
	private static ExchangeCodeConfigManager instance = new ExchangeCodeConfigManager();

	private ExchangeCodeConfigManager()
	{
	}

	public static ExchangeCodeConfigManager getInstance()
	{
		return instance;
	}

	public boolean init()
	{
		reload();
		return true;
	}

	private boolean reload()
	{
		return xmlConfig.load(AppPath.file_ExchangeCode, this);
	}

	public ConfigInfo getConfig(String id)
	{
		return configs.get(id);
	}

	/**
	 * 重载方法
	 * 
	 * @param root
	 * @return
	 */
	@Override
	public boolean reload(Element root)
	{
		// TODO Auto-generated method stub
		List<Element> xml_batches = root.elements("batch");
		ConcurrentHashMap<String, ConfigInfo> tempConfigs = new ConcurrentHashMap<>();
		for (Element batch : xml_batches)
		{
			ConfigInfo config = loadFromXml(batch);
			if (config != null && config.getId() != null)
			{
				Reward reward = new Reward();
				for (Element xml_reward : batch.elements("Reward"))
				{
					HashMap<String, String> kv = xmlConfig.getAttribute(xml_reward);
					reward.megerReward(getRewardFromXml(xmlConfig.parseHexInt(kv.get("id"), 0),
							xmlConfig.parseInt(kv.get("count"), 0)));
				}
				config.setReward(reward);
				tempConfigs.put(config.getId(), config);
			}
		}
		configs = tempConfigs;
		return true;
	}

	private static ConfigInfo loadFromXml(Element element)
	{
		ConfigInfo config = new ConfigInfo();
		HashMap<String, String> kv = xmlConfig.getAttribute(element);
		config.setId(xmlConfig.parseStr(kv.get("ID"), null));
		config.setAreaLimit(xmlConfig.parseStr(kv.get("area"), "-1"));
		config.setChannelLimit(xmlConfig.parseStr(kv.get("channel"), "-1"));
		config.setAbsoluteTimeStart(xmlConfig.parseDatetime(kv.get("absoluteTimeStart"), TimeZoneData.getTimeZone(), 0));
		config.setAbsoluteTimeEnd(xmlConfig.parseDatetime(kv.get("absoluteTimeEnd"), TimeZoneData.getTimeZone(), 0));
		config.setRelativeTimeStart(xmlConfig.parseTimeString(kv.get("relativeTimeStart"), "0-0-0 0:0:0", 0,
				TimeZoneData.getTimeZone()));
		config.setRelativeTimeEnd(xmlConfig.parseTimeString(kv.get("relativeTimeEnd"), "0-0-0 0:0:0", 0,
				TimeZoneData.getTimeZone()));
		config.setCodeMaxPlyerUseNum(xmlConfig.parseInt(kv.get("maxPlayerUseOneCodeNum"), 1));
		config.setCodeMaxUseNum(xmlConfig.parseInt(kv.get("maxUseNum"), 1));
		config.setDescription(xmlConfig.parseStr(kv.get("description"), ""));
		config.setCount(xmlConfig.parseInt(kv.get("count"), 0));
		return config;
	}

	private static Reward getRewardFromXml(int id, int count)
	{

		Reward reward = new Reward();
		if (ItemType.isAvatar(id))
		{
			for (int i = 0; i < count; ++i)
			{
				Avatar avatar = Avatar.genNewAvatar(id);
				reward.getAvatars().add(avatar);
			}
		}
		else if (ItemType.isEquipment(id))
		{
			for (int i = 0; i < count; ++i)
			{
				Equipment equip = Equipment.genNewEquip(id);
				reward.getEquipments().add(equip);
			}
		}
		else if (ItemType.isSkill(id))
		{
			for (int i = 0; i < count; ++i)
			{
				Skill skill = Skill.genNewSkill(id);
				reward.getSkills().add(skill);
			}
		}
		// 其余全为消耗，需保证配置文件必定正确
		else
		{
			reward.getConsumables().add(new Consume(id, count));
		}
		return reward;
	}

	@Override
	public boolean reloadFromMemory(String key, String value)
	{
		return xmlConfig.loadFromMemory(value, this);
	}

	/*
	 * 将从数据库中读取的配置文件转为xml格式
	 */
	public Element createXml(CachedRowSet rs) throws SQLException
	{
		Element root = DocumentHelper.createElement("exchangeCodeBatchesConfig");
		if (rs != null)
		{
			while (rs.next())
			{
				Element batch = root.addElement("batch");
				batch.addAttribute("ID", rs.getString("code_id"));
				batch.addAttribute("channel", rs.getString("channel"));
				batch.addAttribute("area", rs.getString("area"));
				batch.addAttribute("absoluteTimeStart", rs.getString("absolute_time_start"));
				batch.addAttribute("absoluteTimeEnd", rs.getString("absolute_time_end"));
				batch.addAttribute("relativeTimeStart", rs.getString("relative_time_start"));
				batch.addAttribute("relativeTimeEnd", rs.getString("relative_time_end"));
				batch.addAttribute("maxUseNum", rs.getString("max_use_num"));
				batch.addAttribute("maxPlayerUseOneCodeNum", rs.getString("max_player_use_one_code"));
				batch.addAttribute("description", rs.getString("description"));
				batch.addAttribute("count", rs.getString("gen_count"));
				

				JSONArray jsonRewards = null;
				try
				{

					jsonRewards = JSONArray.fromObject(rs.getString("reward"));
				}
				catch (Exception e)
				{
					logger.error("load exchangecode config error.", ExceptionUtils.getStackTrace(e));
					continue;
				}

				for (int i = 0; i < jsonRewards.size(); i++)
				{
					JSONObject jsonReward = jsonRewards.getJSONObject(i);
					Element reward = batch.addElement("Reward");
					reward.addAttribute("id", jsonReward.getString("rewardId"));
					reward.addAttribute("count", jsonReward.getString("count"));
				}
			}
		}
		return root;
	}
}
