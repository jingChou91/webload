/*
 * 文 件 名:  ExchangeCode.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:  兑换码
 * 创 建 人:  zhangdebo@kodgames.com
 * 创建时间:  2014-4-29
 * 修 改 人:  <修改人>
 * 修改时间:  2014-4-29
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.exchangeCode.data;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 兑换码
 * 
 * @author zhangdebo@kodgames.com
 * @version [1.0, 2014-4-29]
 */
public class ExchangeCode
{
	private static final Logger logger = LoggerFactory.getLogger(ExchangeCode.class);
	private static int prefix_length = 4;

	/*
	 * 兑换码ID，用兑换码前缀标示
	 */
	private String prefix;
	/*
	 * 兑换码
	 */
	private String code;
	/*
	 * 使用时间
	 */
	private long usedTime;
	/*
	 * 该兑换码可供多少玩家使用
	 */
	private int playerUsedNum;

	public ExchangeCode(String code)
	{
		if (code.length() < prefix_length)
		{
			logger.error(ExceptionUtils.getStackTrace(new Throwable("[" + code + "] is a illegal exchange code.")));
		}
		this.prefix = code.substring(0, prefix_length);
		this.code = code;
	}

	public void useCode()
	{
		this.playerUsedNum += 1;
	}

	public int getPlayerUsedNum()
	{
		return playerUsedNum;
	}

	public void setPlayerUsedNum(int playerUsedNum)
	{
		this.playerUsedNum = playerUsedNum;
	}

	public String getPrefix()
	{
		return prefix;
	}

	public void setPrefix(String prefix)
	{
		this.prefix = prefix;
	}

	public String getCode()
	{
		return code;
	}

	public void setCode(String code)
	{
		this.code = code;
	}

	public long getUsedTime()
	{
		return usedTime;
	}

	public void setUsedTime(long usedTime)
	{
		this.usedTime = usedTime;
	}
}
