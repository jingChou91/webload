package com.kodgames.corgi.server.gameserver.exchangeCode.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;

import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.server.gameserver.exchangeCode.data.ConfigInfo;
import com.kodgames.corgi.server.gameserver.exchangeCode.data.ExchangeCode;
import com.kodgames.corgi.server.gameserver.exchangeCode.data.ExchangeManager.ExchangeCodeType;
import com.kodgames.gamedata.dbcommon.InterfaceTransact;

public class DoTransact_UseExchangeCode implements InterfaceTransact
{
	private int playerId;
	private String codeStr;
	private ConfigInfo config;
	private ExchangeCode code;
	private ExchangeCodeType type;
	private int result = ClientProtocols.E_GAME_EXCHANGECODE_CONNECT_DATABASE_FAILED;

	public DoTransact_UseExchangeCode(int playerId, String codeStr, ConfigInfo config, ExchangeCodeType type)
	{
		this.playerId = playerId;
		this.codeStr = codeStr;
		this.config = config;
		this.type = type;
	}

	@Override
	public void doProc(Connection con, PreparedStatement[] vps, CachedRowSet[] vrs) throws SQLException
	{
		int index = -1;

		code = ExchangeCodeDB.getExchangeCode(++index, con, vps, vrs, playerId, codeStr);
		if (code == null && this.type == ExchangeCodeType.Normal)
		{
			result = ClientProtocols.E_GAME_EXCHANGECODE_ERROR_CODE;
			return;
		}
		
		if(code == null && this.type == ExchangeCodeType.Des)
		{
			code = new ExchangeCode(codeStr);
		}

		// 已经达到该激活码的使用次数上限 或 已被同一玩家使用过
		if (code.getPlayerUsedNum() >= config.getCodeMaxPlyerUseNum() || ExchangeCodeUsedDB.isUsedBySamePlayer(++index, con, vps, vrs, playerId, code))
		{
			result = ClientProtocols.E_GAME_EXCHANGECODE_ALREADY_USED;
			return;
		}

		// 同一批次使用次数
		int usedExchangeCodeCount = ExchangeCodeUsedCountDB.getUsedExchangeCodeCount(++index, con, vps, vrs, playerId, code);

		// 同一批次使用数目过多
		if (config.getCodeMaxUseNum() <= usedExchangeCodeCount)
		{
			result = ClientProtocols.E_GAME_EXCHANGECODE_ALREADY_USED_SAME_TYPE;
			return;
		}

		code.useCode();
		ExchangeCodeUsedDB.addUsedExchangeCode(++index, con, vps, vrs, playerId, code);

		// useCount表次数加1或者增加数据
		if (usedExchangeCodeCount > 0)
		{
			ExchangeCodeUsedCountDB.addUsedExchangeCodeCount(++index, con, vps, vrs, playerId, code);
		}
		else
		{
			ExchangeCodeUsedCountDB.insertUsedExchangeCodeCount(++index, con, vps, vrs, playerId, code);
		}
			
		ExchangeCodeDB.updateExchangeCode(++index, con, vps, vrs, playerId, code);
		
		result = ClientProtocols.E_GAME_EXCHANGECODE_SUCCESS;
	}

	public int getResult()
	{
		return result;
	}


	@Override
	public String getName()
	{
		return this.getClass().getSimpleName();
	}
}
