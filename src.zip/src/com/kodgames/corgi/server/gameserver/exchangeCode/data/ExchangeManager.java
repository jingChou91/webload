/*
 * 文 件 名:  ExchangeConfig.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:  兑换码兑换管理器
 * 创 建 人:  zhangdebo@kodgames.com
 * 创建时间:  2014-4-29
 * 修 改 人:  <修改人>
 * 修改时间:  2014-4-29
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.exchangeCode.data;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.dbclient.DBClient;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.exchangeCode.db.DoTransact_UseExchangeCode;
import com.kodgames.gamedata.dbcommon.DBEasy;

/**
 * 兑换码兑换管理器
 * 
 * @author zhangdebo@kodgames.com
 * @version [1.0, 2014-4-29]
 */
public class ExchangeManager
{
	private static final Logger logger = LoggerFactory.getLogger(ExchangeManager.class);
	public enum ExchangeCodeType{Normal, Des}

	public static int doExchangeCode(int playerId, String code, ConfigInfo config, GameProtocolsForClient.GC_ExchangeCodeRes.Builder builder,ExchangeCodeType type)
	{

		DBClient dbClient = ServerDataGS.dbCluster.getManagerDbClient();
		Connection con = null;
		try
		{
			con = dbClient.getConnection();
		}
		catch (SQLException e)
		{
			logger.warn("{}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
		}

		try
		{
			if (con != null)
			{
				DoTransact_UseExchangeCode transact = new DoTransact_UseExchangeCode(playerId, code, config, type);
				if (DBEasy.doTransact(con, transact))
				{
					return transact.getResult();
				}
			}
		}
		finally
		{
			if (con != null)
			{
				try
				{
					dbClient.returnConnection(con);
				}
				catch (SQLException e)
				{
					logger.warn("{}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
				}
			}
		}
		return ClientProtocols.E_GAME_EXCHANGECODE_CONNECT_DATABASE_FAILED;
	}
}
