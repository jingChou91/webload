package com.kodgames.corgi.server.gameserver.exchangeCode.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;

import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.exchangeCode.data.ExchangeCode;
import com.kodgames.gamedata.dbcommon.DBEasy;

public class ExchangeCodeUsedDB
{
	// 日志记录，使用的兑换码
	public static void addUsedExchangeCode(int playerId, String code)
	{
		String createTimeStr = ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(), System.currentTimeMillis(), ServerUtil.TimeWithoutMills);

		String sql = String.format("insert into exchange_code_used(code,player_id,use_time) VALUES ('%s',%d,'%s')", code, playerId, createTimeStr);

		ServerDataGS.dbCluster.getManagerDbClient().executeAsynchronousUpdate(playerId, sql);
	}

	public static boolean getUsedExchangeCode(int index, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, int playerId, ExchangeCode code) throws SQLException
	{
		String sql = "select * from exchange_code_used where code = ? and player_Id = ? limit 1";
		vps[index] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, index);
		vrs[index] = DBEasy.doPrivateQuery(vps[index], sql, new Object[] { code.getCode(), playerId });
		if (vrs[index] != null)
		{
			while (vrs[index].next())
			{
				return true;
			}
		}
		return false;
	}

	public static boolean addUsedExchangeCode(int index, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, int playerId, ExchangeCode code) throws SQLException
	{
		String sql = "insert into exchange_code_used(code,player_id,use_time) VALUES (?,?,?)";
		vps[index] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, index);
		String createTimeStr = ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(), System.currentTimeMillis(), ServerUtil.TimeWithoutMills);
		boolean result = DBEasy.doPrivateUpdate(vps[index], sql, new Object[] { code.getCode(), playerId, createTimeStr });
		return result;
	}

	// 当一个激活码可以多次使用时，判断该玩家是否已经使用过该激活码
	public static boolean isUsedBySamePlayer(int index, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, int playerId, ExchangeCode code) throws SQLException
	{
		String sql = "select player_Id from exchange_code_used where code = ? and player_Id = ? limit 1";
		vps[index] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, index);
		vrs[index] = DBEasy.doPrivateQuery(vps[index], sql, new Object[] { code.getCode(), playerId });
		if (vrs[index] != null)
		{
			while (vrs[index].next())
			{
				return true;
			}
		}
		return false;
	}
}
