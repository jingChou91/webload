/*
 * 文 件 名:  ConfigInfo.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:  兑换码配置
 * 创 建 人:  zhangdebo@kodgames.com
 * 创建时间:  2014-4-29
 * 修 改 人:  <修改人>
 * 修改时间:  2014-4-29
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.exchangeCode.data;

import java.util.HashSet;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.gamedata.player.costandreward.Reward;

/**
 * 兑换码配置
 * 
 * @author zhangdebo@kodgames.com
 * @version [1.0, 2014-4-29]
 */
public class ConfigInfo
{
	private static final Logger logger = LoggerFactory.getLogger(ConfigInfo.class);
	public static final String LIMIT_SEPARATOR = ",";
	public static final String UNTIL_SEPARATOR = ":";

	public static final int NO_LIMIT = -1;

	private String id;
	
	/*
	 * 兑换码数量
	 */
	private int count;
	
	/*
	 * 渠道限制
	 */
	private HashSet<Integer> channelLimit = new HashSet<Integer>();
	/*
	 * 服务器开区限制
	 */
	private HashSet<Integer> areaLimit = new HashSet<Integer>();
	/*
	 * 绝对时间限制，在此时间端内生效
	 */
	private long absoluteTimeStart;
	private long absoluteTimeEnd;
	/*
	 * 相对时间限制，相对于玩家注册后的时间段
	 */
	private long relativeTimeStart;
	private long relativeTimeEnd;
	/*
	 * 该批次兑换码一个玩家可以使用的个数
	 */
	private int codeMaxUseNum;
	/*
	 * 该批次中一个兑换码可使用的玩家数
	 */
	private int codeMaxPlyerUseNum;
	/*
	 * 奖励ID
	 */
	private Reward reward;

	private String description;

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id.toUpperCase();
	}

	public Reward getReward()
	{
		return reward;
	}

	public void setReward(Reward reward)
	{
		this.reward = reward;
	}

	public HashSet<Integer> getChannelLimit()
	{
		return channelLimit;
	}

	public void setChannelLimit(HashSet<Integer> channelLimit)
	{
		this.channelLimit = channelLimit;
	}

	public void setChannelLimit(String channelLimit)
	{
		this.channelLimit = parseConfig(channelLimit);
	}

	public void setAreaLimit(String areaLimit)
	{
		this.areaLimit = parseConfig(areaLimit);
	}

	/**
	 * 解析 形如"1,2,4:100,102"这样的字符串配置参数为整形
	 */
	private HashSet<Integer> parseConfig(String config)
	{
		HashSet<Integer> limit = new HashSet<Integer>();
		String[] ls = config.split(LIMIT_SEPARATOR);
		for (String s : ls)
		{
			if (!s.trim().equals(""))
			{
				if (s.contains(UNTIL_SEPARATOR))
				{
					String[] as = s.split(UNTIL_SEPARATOR);
					if (as.length == 2)
					{
						for (int i = Integer.parseInt(as[0]); i <= Integer.parseInt(as[1]); i++)
							limit.add(i);
					}
					else
					{
						logger.error(ExceptionUtils.getStackTrace(new Throwable("parse exchangeCode config error. wrong config.")));
					}
				}
				else
				{
					limit.add(Integer.parseInt(s));
				}
			}
		}
		return limit;
	}

	public HashSet<Integer> getAreaLimit()
	{
		return areaLimit;
	}

	public void setAreaLimit(HashSet<Integer> areaLimit)
	{
		this.areaLimit = areaLimit;
	}

	public long getAbsoluteTimeStart()
	{
		return absoluteTimeStart;
	}

	public void setAbsoluteTimeStart(long absoluteTimeStart)
	{
		this.absoluteTimeStart = absoluteTimeStart;
	}

	public long getAbsoluteTimeEnd()
	{
		return absoluteTimeEnd;
	}

	public void setAbsoluteTimeEnd(long absoluteTimeEnd)
	{
		this.absoluteTimeEnd = absoluteTimeEnd;
	}

	public long getRelativeTimeStart()
	{
		return relativeTimeStart;
	}

	public void setRelativeTimeStart(long relativeTimeStart)
	{
		this.relativeTimeStart = relativeTimeStart;
	}

	public long getRelativeTimeEnd()
	{
		return relativeTimeEnd;
	}

	public void setRelativeTimeEnd(long relativeTimeEnd)
	{
		this.relativeTimeEnd = relativeTimeEnd;
	}

	public int getCodeMaxUseNum()
	{
		return codeMaxUseNum;
	}

	public void setCodeMaxUseNum(int codeMaxUseNum)
	{
		this.codeMaxUseNum = codeMaxUseNum;
	}

	public int getCodeMaxPlyerUseNum()
	{
		return codeMaxPlyerUseNum;
	}

	public void setCodeMaxPlyerUseNum(int codeMaxPlyerUseNum)
	{
		this.codeMaxPlyerUseNum = codeMaxPlyerUseNum;
	}

	public String getDescription()
	{
		return description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	public int getCount()
	{
		return count;
	}

	public void setCount(int count)
	{
		this.count = count;
	}
}
