package com.kodgames.corgi.server.gameserver.exchangeCode.util;

import java.util.HashSet;
import java.util.Set;

import com.kodgames.corgi.server.gameserver.exchangeCode.data.ConfigInfo;
import com.kodgames.corgi.server.gameserver.exchangeCode.logic.CG_ExchangeCodeReqHandler;


/*为了兼容之前已经生成的有问题的兑换码
 * AD97 AD98 AD99
 * AE01-AE99
 * AF01-AF23
 * 这些兑换码
 */
public class ExchangeCodeCompatibleHelper 
{
	//-1表示错误
	//1表示需要兼容的旧版本
	//2表示新版本
	private final static int CODE_ERROR = -1;
	private final static int CODE_OLD_VERSION = 1;
	private final static int CODE_NEW_VERSION = 2;

	private static int getVersionBySign(String sign)
	{
		if(sign == null || sign.length() != 4)
		{
			return CODE_ERROR;
		}
		else if("AD97".equals(sign) || "AD98".equals(sign) || "AD99".equals(sign))
		{
			return CODE_OLD_VERSION;
		}
		else 
		{
			String subTitle = sign.substring(0, 2);
			String subTail = sign.substring(2);
			if(subTitle.equals("AE"))
			{
				try
				{
					int number = Integer.parseInt(subTail);
					if(0 < number  && number <= 99)
					{
						return CODE_OLD_VERSION;
					}
					else
					{
						return CODE_NEW_VERSION;
					}
				}
				catch(NumberFormatException e)
				{
					return CODE_NEW_VERSION;
				}
			}
			if(subTitle.equals("AF"))
			{
				try
				{
					int number = Integer.parseInt(subTail);
					if(0 < number  && number <= 23)
					{
						return CODE_OLD_VERSION;
					}
					else
					{
						return CODE_NEW_VERSION;
					}
				}
				catch(NumberFormatException e)
				{
					return CODE_NEW_VERSION;
				}
			}
		}
		return CODE_NEW_VERSION;
	}

	public static boolean isRealExchangeCode(String sign, String plainText, ConfigInfo config, String encryptContext)
	{	
		int type = getVersionBySign(sign);
		if(type == CODE_ERROR)
		{
			return false;
		}
		else if(type == CODE_OLD_VERSION)
		{
			if(!FormatorUtil.isLegal8Digit(plainText))
			{
				return false;
			}
			int hitNumber = Integer.parseInt(plainText);
			int lower = 0;
			int higher = Integer.valueOf(config.getCount());
			if(hitNumber < lower ||  hitNumber >= higher)
			{
				return false;
			}
			return true;
		}
		else
		{
			if(!FormatorUtil.isLegal8alphaDigit(plainText))
			{
				return false;
			}
			if(!plainText.substring(0, 4).equals(sign))
			{
				return false;
			}
			
			DesDecryptor decryptor = new DesDecryptor();
			String activityCode = decryptor.createActiveCode(plainText);
			if(activityCode.length() != CG_ExchangeCodeReqHandler.NEW_CODE_LENGTH)
			{
				return false;
			}
			
			if(!activityCode.substring(4).equals(encryptContext))
			{
				return false;
			}
			
			String decimi62 = plainText.substring(4);
			int hitNumber = Integer.parseInt(_62_10_Transformer.convertBase62ToDecimal(decimi62));
			int lower = 0;
			int higher = Integer.valueOf(config.getCount());
			if(hitNumber <= lower ||  hitNumber > higher)
			{
				return false;
			}
			return true;
		}
	}
}
