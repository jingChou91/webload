package com.kodgames.corgi.server.gameserver.arena.data;

import com.kodgames.corgi.protocol.DBProtocolsForServer.ArenaGradeRank;

public class ArenaDataBase
{
	private int arenaGradeId;
	private ArenaGradeRank arenaGradeRank;
	
	public int getArenaGradeId()
	{
		return arenaGradeId;
	}
	public void setArenaGradeId(int arenaGradeId)
	{
		this.arenaGradeId = arenaGradeId;
	}
	public ArenaGradeRank getArenaGradeRank()
	{
		return arenaGradeRank;
	}
	public void setArenaGradeRank(ArenaGradeRank arenaGradeRank)
	{
		this.arenaGradeRank = arenaGradeRank;
	}

}
