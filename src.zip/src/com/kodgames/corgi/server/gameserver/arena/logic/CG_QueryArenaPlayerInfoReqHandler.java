package com.kodgames.corgi.server.gameserver.arena.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ArenaConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.RobotConfig;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryArenaPlayerInfoReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryArenaPlayerInfoRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.arena.data.ArenaManager;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_QueryArenaPlayerInfoReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_QueryArenaPlayerInfoReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		CG_QueryArenaPlayerInfoReq request = (CG_QueryArenaPlayerInfoReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryArenaPlayerInfoRes.Builder builder = GC_QueryArenaPlayerInfoRes.newBuilder();
		builder.setCallback(request.getCallback());
		int playerIdCurrent = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerIdCurrent);

		int result = ClientProtocols.E_GAME_QUERY_ARENA_PLAYERINIFO_SUCCESS;
		int rank = request.getRank();
		int arenaGradeId = request.getArenaGradeId();
		logger.info("recv CG_QueryPlayerInfoReq, playerId = {}, rank = {}, arenaGradeId={} ", playerIdCurrent, rank, arenaGradeId);
		do
		{
			PlayerNode playerNode_tmp = ServerDataGS.playerManager.getPlayerNode(playerIdCurrent);
			if (playerNode_tmp == null || playerNode_tmp.getPlayerInfo() == null)
			{
				result = ClientProtocols.E_GAME_QUERY_ARENA_PLAYERINIFO_FAILED_GET_PLAYERINFO_FAILED;
				break;
			}
			if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode_tmp, ClientServerCommon._OpenFunctionType.Arena))
			{
				result = ClientProtocols.E_GAME_ARENA_FUNCTION_NOT_OPEN;
				break;
			}
			// 判断客户端数据是否正确
			ArenaConfig.ArenaGrade arenaGrade = cd.get_ArenaConfig().GetArenaGradeById(arenaGradeId);
			if (null == arenaGrade)
			{
				result = ClientProtocols.E_GAME_QUERY_ARENA_PLAYERINIFO_ERROR_ARENACONFIG_ERROR;
				break;
			}
			int topFew = arenaGrade.get_topFew();
			if (rank > topFew || rank <= 0)
			{
				result = ClientProtocols.E_GAME_QUERY_ARENA_PLAYERINIFO_ERROR_ARENACONFIG_ERROR;
				break;
			}

			//从内存管理器中取出该名次玩家ID
			int playerId = ArenaManager.getInstance().getPlayerIdByRank(arenaGradeId, rank);
			if(ArenaManager.isRobot(playerId))//如果是机器人
			{
				RobotConfig.Robot robot = cd.get_RobotConfig().getRobotByRobotId(playerId);
				if(robot == null)
				{
					result = ClientProtocols.E_GAME_QUERY_ARENA_ROBOTINIFO_FAILED_DATA_ERROR;// 名次必须在
					break;
				}
				
				ArenaManager.genPlayerProtoByRobot(cd, robot,builder);
			}
			else
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (null == playerNode || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_ARENA_PLAYERINIFO_FAILED_GET_PLAYERINFO_FAILED;
					break;
				}
				builder.setPlayer(playerNode.toProtoBuffer(cd));
			}

			
		}
		while (false);

		builder.setResult(result);
		Protocol queryPlayerInfoResProtocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_ARENA_PLAYERINIFO_RES);
		queryPlayerInfoResProtocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, queryPlayerInfoResProtocol);
		return HandlerAction.TERMINAL;
	}
}
