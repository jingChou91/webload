package com.kodgames.corgi.server.gameserver.arena.thread;

import java.util.concurrent.ConcurrentHashMap;

import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.corgi.server.common.LoopRunnable;
import com.kodgames.corgi.server.gameserver.arena.data.ArenaGradeRankData;
import com.kodgames.corgi.server.gameserver.arena.data.ArenaManager;
import com.kodgames.corgi.server.gameserver.arena.db.ArenaDB;

public class ArenaGradeRunnable extends LoopRunnable
{
	private static final long FIVE_MINUTE = 5 * 60 * 1000;

	public ArenaGradeRunnable()
	{
		super(FIVE_MINUTE);
	}

	@Override
	public void shutdownHook()
	{
		execute();
	}

	@Override
	public void execute()
	{
		ConcurrentHashMap<Integer, ArenaGradeRankData> temp = ArenaManager.getInstance().getArenaGradesCopy();

		for (Integer arenaGradeId : temp.keySet())
		{
			ArenaGradeRankData arenaGradeRankData = temp.get(arenaGradeId);

			DBProtocolsForServer.ArenaGradeRank.Builder builder = DBProtocolsForServer.ArenaGradeRank.newBuilder();

			for (Integer playerId : arenaGradeRankData.getAllRank())
			{
				builder.addPlayerId(playerId);
			}

			ArenaDB.replaceArenaGradeRank(arenaGradeId, builder.build());
		}
	}
}
