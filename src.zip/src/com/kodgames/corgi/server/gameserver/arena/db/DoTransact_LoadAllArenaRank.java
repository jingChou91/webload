package com.kodgames.corgi.server.gameserver.arena.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.concurrent.ConcurrentHashMap;

import javax.sql.rowset.CachedRowSet;

import com.kodgames.corgi.server.gameserver.arena.data.ArenaGradeRankData;
import com.kodgames.gamedata.dbcommon.InterfaceTransact;

/**
 * @描述
 */
public class DoTransact_LoadAllArenaRank implements InterfaceTransact
{
	private ConcurrentHashMap<Integer, ArenaGradeRankData> arenaGrades = new ConcurrentHashMap<>();

	@Override
	public String getName()
	{
		return this.getClass().getSimpleName();
	}

	private int result = -1;

	public int getResult()
	{
		return result;
	}

	public void setResult(int result)
	{
		this.result = result;
	}

	public DoTransact_LoadAllArenaRank(ConcurrentHashMap<Integer, ArenaGradeRankData> arenaGrades)
	{
		this.arenaGrades = arenaGrades;
	}

	@Override
	public void doProc(Connection con, PreparedStatement[] vps, CachedRowSet[] vrs)
		throws SQLException
	{

		setResult(-1);
		int queryIndex = -1;
		RowArena.loadAllArenaGradeRank(++queryIndex, con, vps, vrs, arenaGrades);

		setResult(1);
	}
}
