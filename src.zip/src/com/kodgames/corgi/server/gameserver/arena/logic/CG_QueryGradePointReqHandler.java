package com.kodgames.corgi.server.gameserver.arena.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ArenaConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryGradePointReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryGradePointRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.arena.data.ArenaManager;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_QueryGradePointReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_QueryGradePointReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		CG_QueryGradePointReq request = (CG_QueryGradePointReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryGradePointRes.Builder builder = GC_QueryGradePointRes.newBuilder();
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_QUERY_GRADE_POINT_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		logger.info("recv CG_QueryGradePointReqHandler, playerId = {}", playerId);

		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					logger.warn("get playerNode failed, playerId = {}", playerId);
					result = ClientProtocols.E_GAME_QUERY_GRADE_POINT_FAILED_GET_PLAYER_FAILED;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Arena))
				{
					result = ClientProtocols.E_GAME_ARENA_FUNCTION_NOT_OPEN;
					break;
				}

				ArenaConfig arenaConfig = cd.get_ArenaConfig();
				if(arenaConfig == null)
				{
					result = ClientProtocols.E_GAME_QUERY_GRADE_POINT_ERROR_ARENACONFIG_ERROR;
					break;
				}

				// 获取玩家所在竞技场
				int arenaGradeId = ArenaManager.getInstance().getArenaGradeIdByPlayerId(playerId);
				ArenaConfig.ArenaGrade arenaGradeConfig = arenaConfig.GetArenaGradeById(arenaGradeId);
				if(arenaGradeConfig == null)
				{
					result = ClientProtocols.E_GAME_QUERY_GRADE_POINT_FAILED_PLAYER_NOT_IN_ARENA;
					break;
				}

				int rank = ArenaManager.getInstance().getPlayerRank(playerId, arenaGradeId);
				if (rank <= 0)
				{
					logger.warn("Rank = {}", rank);
					result = ClientProtocols.E_GAME_QUERY_GRADE_POINT_FAILED_PLAYER_NOT_IN_ARENA;
					break;
				}

				ArenaConfig.RankSetting rankSetting = arenaConfig.GetRankSettingByRankLevel(arenaGradeId, rank);
				if (null == rankSetting)
				{
					logger.warn("get RankSetting failed");
					result = ClientProtocols.E_GAME_QUERY_GRADE_POINT_ERROR_ARENACONFIG_ERROR;
					break;
				}

				//比武场保持名次获得奖励时间：秒
				int interval = arenaGradeConfig.get_keepRandInterval();
				
				//计算新的积分 修改内存和数据库
				ArenaManager.computeGradePoint(playerNode,interval,rankSetting.get_reward().get_count());

				builder.setGradePoint(playerNode.getGamePlayer().getArenaPlayerData().getGradePoint());
			}
			while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		builder.setCallback(request.getCallback());
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_GRADE_POINT_RES);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
