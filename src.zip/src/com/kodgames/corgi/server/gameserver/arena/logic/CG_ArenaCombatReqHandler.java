package com.kodgames.corgi.server.gameserver.arena.logic;

import java.util.ArrayList;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ArenaConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.combat.record.CombatPlayer;
import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_ArenaCombatReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_ArenaCombatRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.asyncclient.CombatData;
import com.kodgames.corgi.server.asyncclient.QueryArenaCombatResultRes;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.arena.data.ArenaManager;
import com.kodgames.corgi.server.gameserver.marquee.data.FlowMessageBroadcaster;
import com.kodgames.corgi.server.gameserver.marquee.data.FlowMessageBroadcaster.BroadcastType;
import com.kodgames.corgi.server.gameserver.position.data.Location;
import com.kodgames.corgi.server.gameserver.position.data.Position;
import com.kodgames.corgi.server.gameserver.quest.data.QuestEventFactory;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.ItemType;
import com.kodgames.gamedata.player.costandreward.Reward;
import com.kodgames.gamedata.player.genplayer.GenCombatNormalPlayer;
import com.kodgames.gamedata.player.genplayer.GenCombatNpcPlayer;

public class CG_ArenaCombatReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_ArenaCombatReqHandler.class);
    private static final int arenaMaxRecordCount = 20;
	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		CG_ArenaCombatReq request = (CG_ArenaCombatReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_ArenaCombatRes.Builder builder = GC_ArenaCombatRes.newBuilder();

		builder.setCallback(request.getCallback());
		int result = ClientProtocols.E_GAME_ARENA_COMBAT_SUCCESS;
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		int playerIdA = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerIdA);
		
		CommonProtocols.Position position = request.getPosition();
		
		Protocol arenaCombatResProtocol = new Protocol(ClientProtocols.P_GAME_GC_ARENA_COMBAT_RES);
		logger.info("recv CG_ArenaCombatReq ,palyerIdA = {}, wantRank = {}", playerIdA, request.getRank());

		int arenaGradeId = ArenaManager.getInstance().getArenaGradeIdByPlayerId(playerIdA);
		if(arenaGradeId == 0)
		{
			result = ClientProtocols.E_GAME_ARENA_COMBAT_FAILED_ARENAA_IS_NULL;
			builder.setResult(result);
			arenaCombatResProtocol.setProtoBufMessage(builder.build());
			ServerDataGS.transmitter.sendToClient(sender, arenaCombatResProtocol);
			return HandlerAction.TERMINAL;
		}
		
		if(null == position)
		{
			result = ClientProtocols.E_GAME_ARENA_COMBAT_FAILED_NOT_POSITON;
			builder.setResult(result);
			arenaCombatResProtocol.setProtoBufMessage(builder.build());
			ServerDataGS.transmitter.sendToClient(sender, arenaCombatResProtocol);
			return HandlerAction.TERMINAL;
		}
		
		// 判断除了剧情npc外,是否有上阵角色
		int locationCount = position.getAvatarLocationsCount();
		if (locationCount < 1)
		{
			result = ClientProtocols.E_GAME_ARENA_COMBAT_FAILED_OT_HAVE_AVATAR_ON_POSITION;
			builder.setResult(result);
			arenaCombatResProtocol.setProtoBufMessage(builder.build());
			ServerDataGS.transmitter.sendToClient(sender, arenaCombatResProtocol);
			return HandlerAction.TERMINAL;
		}
		
		if(null == cd.get_RobotConfig())
		{
			result = ClientProtocols.E_GAME_ARENA_COMBAT_FAILED_ROBOT_CONFIG_IS_NULL;
			builder.setResult(result);
			arenaCombatResProtocol.setProtoBufMessage(builder.build());
			ServerDataGS.transmitter.sendToClient(sender, arenaCombatResProtocol);
			return HandlerAction.TERMINAL;
		}
		
		// 读取配置文件
		ArenaConfig arenaConf = cd.get_ArenaConfig();
		if (null == arenaConf)
		{
			logger.warn("get arenaconf failed");
			result = ClientProtocols.E_GAME_ARENA_COMBAT_ERROR_ARENACONFIG_ERROR;
			builder.setResult(result);
			arenaCombatResProtocol.setProtoBufMessage(builder.build());
			ServerDataGS.transmitter.sendToClient(sender, arenaCombatResProtocol);
			return HandlerAction.TERMINAL;
		}

		int playerIdB = ArenaManager.getInstance().getPlayerIdByRank(arenaGradeId, request.getRank());
		if(playerIdB <= 0)
		{
			if(cd.get_RobotConfig().getRobotByRobotId(playerIdB) == null){
				result = ClientProtocols.E_GAME_ARENA_COMBAT_FAILED_ARENA_ROBOT_IS_NULL;
				builder.setResult(result);
				arenaCombatResProtocol.setProtoBufMessage(builder.build());
				ServerDataGS.transmitter.sendToClient(sender, arenaCombatResProtocol);
				return HandlerAction.TERMINAL;
			}
		}
		
		QueryArenaCombatResultRes queryArenaCombatResultRes = new QueryArenaCombatResultRes(request.getCallback(),arenaGradeId, playerIdA, request.getRank(), sender, crsForClient,cd);
		int sequenceId = ServerDataGS.asyncClient.getSequenceId();

		// Add lock
		ServerDataGS.playerManager.lockPlayer(playerIdA, playerIdB);
		try
		{
			do 
			{
				PlayerNode playerA = ServerDataGS.playerManager.getPlayerNode(playerIdA);
				
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerA, ClientServerCommon._OpenFunctionType.Arena))
				{
					result = ClientProtocols.E_GAME_ARENA_FUNCTION_NOT_OPEN;
					break;
				}
				
				if (playerIdA == playerIdB)
				{
					logger.warn("playerIdA equal with playerIdB");
					result = ClientProtocols.E_GAME_ARENA_COMBAT_FAILED_PLAYERID_WRONG;
					break;
				}
				
				
				ArrayList<Cost> costs = new ArrayList<Cost>();
				for (int i = 0; i < arenaConf.Get_combatCostsCount(); i++)
				{
					ClientServerCommon.Cost costConf = arenaConf.Get_combatCostsByIndex(i);
					Cost otherCost = new Cost(costConf.get_id(), costConf.get_count());
					costs.add(otherCost);
				}
				
				Cost notEnoughCost = new Cost();
				if (false == CostAndRewardManager.checkCosts(playerA, costs, cd, KodLogEvent.Arena_Combat, notEnoughCost))
				{
					crsForClient.setNotEnoughCost(notEnoughCost);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_ARENA_COMBAT_FAILED_CONSUMABLE_NOT_ENOUGH;
					break;
				}
				
				CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
				CostAndRewardManager.consumeCosts(playerA, costs, cd, KodLogEvent.Arena_Combat, 0, 0);
				crsForCost.setCosts(costs);
				crsForClient.megerCostAndRewardAndSync(crsForCost);
				
				PlayerNode playerB = null; 
				if(!ArenaManager.isRobot(playerIdB))
				{
					playerB = ServerDataGS.playerManager.getPlayerNode(playerIdB);
					
					if (playerA == null || playerB == null)
					{
						logger.warn("PlayerA = NULL OR PlayerB = null");
						if (playerA == null)
						{
							result = ClientProtocols.E_GAME_ARENA_COMBAT_FAILED_PLAYERA_IS_NULL;
						}
						else
						{
							result = ClientProtocols.E_GAME_ARENA_COMBAT_FAILED_PLAYERB_IS_NULL;
						}

						break;
					}
					
					int positionId = playerB.getPlayerInfo().getPositionData().getMasterPositionId();
					//判断阵位Id是否有效
					boolean avaliable = false;
					
					if(playerB.getPlayerInfo().getPositionData().getPositions().containsKey(positionId) )
					{
						Position positionB = playerB.getPlayerInfo().getPositionData().getPositions().get(positionId);
						
						//如果玩家主阵位上没有角色,不能进入
						
						for(Map.Entry<Guid, Location> entry : positionB.getLocations().entrySet())
						{
							if(ItemType.isAvatar(entry.getValue().getResourceId()) && entry.getValue().getLocationId() != positionB.getEmployLocationId())
							{
								avaliable = true;
								break;
							}
						}
					}
					
					if(avaliable == false)
					{
						
						int rankA = ArenaManager.getInstance().getPlayerRank(playerIdA, arenaGradeId);
						int rankB = ArenaManager.getInstance().getPlayerRank(playerIdB, arenaGradeId);
						Reward combatReward = new Reward();
						int rankOri = ArenaManager.getInstance().getPlayerRank(playerIdA, arenaGradeId);
						if(rankOri > request.getRank() && request.getRank() <= 5 )
						{
							FlowMessageBroadcaster.prepareBroadcastMsg(playerA, 0, BroadcastType.ARENARANK, request.getRank());
						}
						ArenaManager.getInstance().changeRank(arenaGradeId, playerIdA, request.getRank());
						//刷新奖励次数
						playerA.getGamePlayer().getArenaPlayerData().refreshRewardRewardMax(cd);
						
						for (int i = 0; i < arenaConf.GetArenaGradeById(arenaGradeId).Get_challengeRewardsCount(); i++)
						{
							int rewardCount =arenaConf.GetArenaGradeById(arenaGradeId).Get_challengeRewardsByIndex(i).Get_rewardsCount();
							if(arenaConf.GetArenaGradeById(arenaGradeId).Get_challengeRewardsByIndex(i).get_maxCount() <= playerA.getGamePlayer().getArenaPlayerData().getArenaRewardTimes())
							{
								continue;
							}
							
							for (int j = 0; j < rewardCount; j++)
							{
								Reward rewardTemp = new Reward();
								rewardTemp = rewardTemp.fromClientServerCommon(arenaConf.GetArenaGradeById(arenaGradeId).Get_challengeRewardsByIndex(i).Get_rewardsByIndex(j));
								combatReward.megerReward(rewardTemp);
							}
						}
						
						//获得奖励
						CostAndRewardManager.addReward(playerA, combatReward, cd,  KodLogEvent.Arena_Combat);
						CostAndRewardAndSync crsForReward = new CostAndRewardAndSync();
						crsForReward.mergeReward(combatReward);
						crsForClient.megerCostAndRewardAndSync(crsForReward);
						builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
						// 计算并保存积分 
						int interval = arenaConf.GetArenaGradeById(arenaGradeId).get_keepRandInterval();
						ArenaConfig.RankSetting rankSettingA = arenaConf.GetRankSettingByRankLevel(arenaGradeId, rankA);
						ArenaConfig.RankSetting rankSettingB = arenaConf.GetRankSettingByRankLevel(arenaGradeId, rankB);
						// 计算新的积分 修改内存和数据库
						ArenaManager.computeGradePoint(playerA, interval, rankSettingB.get_reward().get_count());
						// 计算新的积分 修改内存和数据库
						ArenaManager.computeGradePoint(playerB, interval, rankSettingA.get_reward().get_count());
						result = ClientProtocols.E_GAME_ARENA_COMBAT_FAILED_NOT_POSITON_AVATAR;
						break;
					}
					
					
				}
				
				// 构造playerA的战斗数据
				CombatPlayer combatPlayerA =GenCombatNormalPlayer.loadCombatPlayerForDongeon(playerA, cd, position, 0);
				if (null == combatPlayerA)
				{
					result = ClientProtocols.E_GAME_ARENA_COMBAT_FAILED_CREATE_COMBAT_PLAYER_FAILED;
					break;
				}

				// 构造playerB的战斗数据
				CombatPlayer combatPlayerB = null;
				
				if(ArenaManager.isRobot(playerIdB))
				{
					combatPlayerB = GenCombatNpcPlayer.loadRobotCombatPlayer(cd.get_RobotConfig().getRobotByRobotId(playerIdB), cd, null, null);
				}
				else
				{
					combatPlayerB = GenCombatNormalPlayer.loadCombatPlayer(playerB, cd, 
				          playerB.getPlayerInfo().getPositionData().getMasterPositionId());
				}
				
				if (null == combatPlayerB)
				{
					result = ClientProtocols.E_GAME_ARENA_COMBAT_FAILED_CREATE_COMBAT_PLAYER_FAILED;
					break;
				}

				CombatData combatData = new CombatData();
				combatData.addPlayer(combatPlayerA);
				combatData.addPassivePlayers(combatPlayerB);
				combatData.setIsLoseAutoSkip(1);
				combatData.setSceneId(cd.get_SceneConfig().get_arenaSceneId());
				combatData.setSequenceId(sequenceId);
				combatData.setCd(cd);;
				combatData.setMaxRoundWin(false);
                combatData.setMaxRecordCount(arenaMaxRecordCount);//此处写死,比武场最大战斗回合
				ServerDataGS.asyncClient.send(combatData, queryArenaCombatResultRes);
				logger.info("SEND TO COMBATSERVER COMPUTE COMBAT RESULT!");
				
				// 竞技场每日任务
				QuestEventFactory.createArenaCombatEvent(playerA, cd);
				return HandlerAction.TERMINAL;
			}
			while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerIdA, playerIdB);
		}

		builder.setResult(result);
		arenaCombatResProtocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, arenaCombatResProtocol);

		return HandlerAction.TERMINAL;
	}
}
