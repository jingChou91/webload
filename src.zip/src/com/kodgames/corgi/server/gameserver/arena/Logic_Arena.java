package com.kodgames.corgi.server.gameserver.arena;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.arena.logic.CG_ArenaCombatReqHandler;
import com.kodgames.corgi.server.gameserver.arena.logic.CG_QueryArenaPlayerInfoReqHandler;
import com.kodgames.corgi.server.gameserver.arena.logic.CG_QueryArenaRankReqHandler;
import com.kodgames.corgi.server.gameserver.arena.logic.CG_QueryGradePointReqHandler;
import com.kodgames.corgi.server.gameserver.arena.logic.CG_QueryRankToFewReqHandler;

public class Logic_Arena 
{
	private CG_QueryArenaRankReqHandler  cg_QueryArenaRankReqHandler = null;
	private CG_ArenaCombatReqHandler cg_ArenaCombatReqHandler =null;
	private CG_QueryGradePointReqHandler cg_QueryGradePointReqHandler =null;
	private CG_QueryRankToFewReqHandler cg_QueryRankToFewResHandler =null;
	private CG_QueryArenaPlayerInfoReqHandler cg_QueryArenaPlayerInfoReqHandler =null;
	
	public void init() 
	{
		cg_QueryArenaRankReqHandler = new CG_QueryArenaRankReqHandler();
		cg_ArenaCombatReqHandler = new CG_ArenaCombatReqHandler();
		cg_QueryGradePointReqHandler = new CG_QueryGradePointReqHandler();
		cg_QueryRankToFewResHandler = new CG_QueryRankToFewReqHandler();
		cg_QueryArenaPlayerInfoReqHandler = new CG_QueryArenaPlayerInfoReqHandler();
	}

	public void registerProtoBufType(Controller controller) 
	{
        controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_ARENA_RANK_REQ, GameProtocolsForClient.CG_QueryArenaRankReq.getDefaultInstance()); 
        controller.registerMessageLite(ClientProtocols.P_GAME_CG_ARENA_COMBAT_REQ, GameProtocolsForClient.CG_ArenaCombatReq.getDefaultInstance()); 
        controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_GRADE_POINT_REQ, GameProtocolsForClient.CG_QueryGradePointReq.getDefaultInstance());
        controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_RANK_TOPFEW_REQ, GameProtocolsForClient.CG_QueryRankTopFewReq.getDefaultInstance());
        controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_ARENA_PLAYERINIFO_REQ, GameProtocolsForClient.CG_QueryArenaPlayerInfoReq.getDefaultInstance());
        
	}

	public void registerMessageHandler(Controller controller) 
	{
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_ARENA_RANK_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryArenaRankReqHandler ));
		controller.addHandler(ClientProtocols.P_GAME_CG_ARENA_COMBAT_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_ArenaCombatReqHandler ));
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_GRADE_POINT_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryGradePointReqHandler ));
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_RANK_TOPFEW_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryRankToFewResHandler ));
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_ARENA_PLAYERINIFO_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryArenaPlayerInfoReqHandler ));
	}
}
