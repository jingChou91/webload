package com.kodgames.corgi.server.gameserver.arena.data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ArenaConfig;
import ClientServerCommon.ArenaConfig.ArenaGrade;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.NpcConfig;
import ClientServerCommon.RobotConfig;

import com.kodgames.common.Guid;
import com.kodgames.common.RandomWrapper;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryArenaPlayerInfoRes;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.arena.db.ArenaDB;
import com.kodgames.corgi.server.gameserver.avatar.data.Avatar;
import com.kodgames.corgi.server.gameserver.goods.data.Goods;
import com.kodgames.corgi.server.gameserver.position.data.Location;
import com.kodgames.corgi.server.gameserver.position.data.Position;
import com.kodgames.gamedata.player.GamePlayer;
import com.kodgames.gamedata.player.PlayerDB;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.ItemType;

public class ArenaManager
{
	private static final Logger logger = LoggerFactory.getLogger(ArenaManager.class);
	// 比武场
	private ConcurrentHashMap<Integer, ArenaGradeRankData> arenaGrades = new ConcurrentHashMap<>();

	private static ArenaManager arenaManager = new ArenaManager();

	private ArenaManager()
	{
	}

	public synchronized static ArenaManager getInstance()
	{
		return arenaManager;
	}

	public synchronized boolean init()
	{
		ArenaDB.loadAllRank(arenaGrades);
		return true;
	}

	public synchronized ConcurrentHashMap<Integer, ArenaGradeRankData> getArenaGradesCopy()
	{
		ConcurrentHashMap<Integer, ArenaGradeRankData> arenaGradesCopy = new ConcurrentHashMap<>();
		for(Map.Entry<Integer, ArenaGradeRankData> entry : this.arenaGrades.entrySet())
		{
			arenaGradesCopy.put(entry.getKey(), entry.getValue().copy());
		}
		return arenaGradesCopy;
	}
	
	public synchronized List<Integer> getArenaGradesList()
	{
		List<Integer> arenaList = new ArrayList<Integer>();
		for(Map.Entry<Integer, ArenaGradeRankData> entry : this.arenaGrades.entrySet())
		{
			arenaList.add(entry.getKey());
		}
		return arenaList;
	}


	//查询竞技场可挑战的排名
	public synchronized LinkedHashMap<Integer, Integer> rankFirst8(int playerId, int arenaGradeId, int fixChallengeNum, int specialChallengeNum)
	{
		ArenaGradeRankData  arenaGradeRankData = this.arenaGrades.get(arenaGradeId);
		Vector<Integer> ranks = arenaGradeRankData.getAllRank();
		LinkedHashMap<Integer, Integer> challengeTemp = new LinkedHashMap<Integer, Integer>();

		int allNum = fixChallengeNum + specialChallengeNum;
		int rank = getPlayerRank(playerId, arenaGradeId);
		if (rank <= allNum)
		{
			int tempSize = 0;
			if (ranks.size() < allNum)
			{
				tempSize = ranks.size();
			}
			else
			{
				tempSize = allNum; 
			}

			for(int i = 0; i< tempSize; i++)
			{
				if(playerId == ranks.get(i))
				{
					continue;
				}

				challengeTemp.put(ranks.get(i), arenaGradeRankData.getPlayerIdRank().get(ranks.get(i)));
			}
		}
		else
		{
			int lastRank = rank - fixChallengeNum -1;
			int step = lastRank / specialChallengeNum;//step一定会大于1
			int mod = lastRank % specialChallengeNum;
			int lastIndex = 0;
			for (int i = 0; i < specialChallengeNum; i++)
			{
				int stepTemp = step;
				if (i == 0)
				{
					stepTemp = step + mod;
				}

				int index = lastIndex + RandomWrapper.NextInt(stepTemp);
				challengeTemp.put(ranks.get(index), arenaGradeRankData.getPlayerIdRank().get(ranks.get(index)));

				lastIndex += stepTemp;
			}

			for(int i = fixChallengeNum; i > 0 ; i--)
			{
				challengeTemp.put(ranks.get(rank-i-1), arenaGradeRankData.getPlayerIdRank().get(ranks.get(rank-i-1)));
			}

		}

		return challengeTemp;
	}

	public synchronized LinkedHashMap<Integer, Integer> topFew(int arenaGradeId, int topFew)
	{
		Vector<Integer> ranks = this.arenaGrades.get(arenaGradeId).getAllRank();
		ConcurrentHashMap<Integer, Integer> playerId2Rank = this.arenaGrades.get(arenaGradeId).getPlayerIdRank();

		LinkedHashMap<Integer, Integer> result = new LinkedHashMap<Integer, Integer>();
		for(int i = 0; i < topFew && i<ranks.size() ; i++)
		{
			result.put(ranks.get(i), playerId2Rank.get(ranks.get(i)));
		}

		return result;
	}

	// 交换两个玩家的排名, 返回被交换玩家的ID
	public synchronized int changeRank(int arenaGradeId, int playerIdA, int rankB)
	{
		int rankA = getPlayerRank(playerIdA, arenaGradeId);
		int playerIdB = getPlayerIdByRank(arenaGradeId, rankB);
		if(rankA > rankB)
		{
			Map<Integer, Integer> map = this.arenaGrades.get(arenaGradeId).getPlayerIdRank();
			Vector<Integer> allRanks = this.arenaGrades.get(arenaGradeId).getAllRank();

			allRanks.set(rankA - 1, playerIdB);
			allRanks.set(rankB - 1, playerIdA);
			map.put(playerIdA, rankB);
			map.put(playerIdB, rankA);
		}
		
		return playerIdB;
	}

	// 把玩家添加到最后一名，并返回玩家排名
	public synchronized int addPlayerAndRank(int arenaGradeId, int playerId)
	{
		if (this.arenaGrades.get(arenaGradeId).getAllRank().add(playerId))
		{
			int rank = this.arenaGrades.get(arenaGradeId).getAllRank().size();
			this.arenaGrades.get(arenaGradeId).getPlayerIdRank().put(playerId, rank);
			return rank;
		}
		return 0;
	}

	public synchronized boolean checkAddPlayerAndRank(PlayerNode playerNode, ConfigDatabase cd)
	{
		int playerId = playerNode.getPlayerId();
		if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Arena))
		{
			logger.debug("wolf smoke: isFunctionOpen    error");
			return false;
		}

		ArenaConfig arenaConfig = cd.get_ArenaConfig();
		if (arenaConfig == null)
		{
			logger.debug("wolf smoke: arenaConfig == null    error");
			return false;
		}
		
		int positionId = playerNode.getPlayerInfo().getPositionData().getMasterPositionId();
		//判断阵位Id是否有效
		if(!playerNode.getPlayerInfo().getPositionData().getPositions().containsKey(positionId))
		{
			logger.debug("wolf smoke: containsKey(positionId)    error");
			return false;
		}
		
		Position position = playerNode.getPlayerInfo().getPositionData().getPositions().get(positionId);
		
		//如果玩家主阵位上没有角色,不能进入
		boolean avaliable = false;
		for(Map.Entry<Guid, Location> entry : position.getLocations().entrySet())
		{
			if(ItemType.isAvatar(entry.getValue().getResourceId()) && entry.getValue().getLocationId() != position.getEmployLocationId())
			{
				avaliable = true;
			}
		}
		if(avaliable == false)
		{
			logger.debug("wolf smoke:avaliable == false    error");
			return false;
		}
		

		int arenaGradeId = ArenaManager.getInstance().getArenaGradeIdByPlayerId(playerId);
		ArenaConfig.ArenaGrade arenaGradeCfg = arenaConfig.GetArenaGradeById(arenaGradeId);
		// 如果玩家没有排名数据（第一次进入竞技场），把该玩家排到当前排名列表的最后一名
		if (arenaGradeCfg == null)
		{
			for (int i = 0; i < arenaConfig.Get_arenaGradesCount(); i++)
			{
				if (playerNode.getGamePlayer().getLevel() >= arenaConfig.Get_arenaGradesByIndex(i).get_fromLevel())
				{
					arenaGradeId = arenaConfig.Get_arenaGradesByIndex(i).get_arenaGradeId();
				}
			}

			int rank = ArenaManager.getInstance().addPlayerAndRank(arenaGradeId, playerId);
			if (rank <= 0)
			{
				logger.debug("wolf smoke:rank <= 0    error");
				return false;
			}

			long lastUpdateTime = System.currentTimeMillis();
			playerNode.getGamePlayer().getArenaPlayerData().setLastUpdateGradePointTime(lastUpdateTime);

			PlayerDB.updateGradePoint(playerId, playerNode.getGamePlayer().getArenaPlayerData().getGradePoint(), lastUpdateTime);
		}
		return true;
	}
	
	public synchronized int getArenaGradeIdByPlayerId(int playerId)
	{
		int arenaGradeId = 0;

		for(Map.Entry<Integer, ArenaGradeRankData> entry : this.arenaGrades.entrySet())
		{
			if(entry.getValue().getPlayerIdRank().containsKey(playerId))
			{
				arenaGradeId = entry.getKey(); 
				break;
			}
		}

		return arenaGradeId;
	}

	public synchronized int getPlayerRank(int playerId, int arenaGradeId)
	{
		int rank = 0 ;
		if(this.arenaGrades.containsKey(arenaGradeId))
		{
			ConcurrentHashMap<Integer, Integer> playerId2Rank = this.arenaGrades.get(arenaGradeId).getPlayerIdRank();
			if(playerId2Rank.containsKey(playerId))
			{
				rank = playerId2Rank.get(playerId);
			}
		}
		return rank;
	}

	public synchronized int getPlayerIdByRank(int arenaGradeId, int rank)
	{
		int playerId = 0;
		if(this.arenaGrades.containsKey(arenaGradeId))
		{
			Vector<Integer> playerIds = this.arenaGrades.get(arenaGradeId).getAllRank();
			if(playerIds.size() >= rank)
			{
				playerId = playerIds.get(rank-1);
			}
		}
		return playerId;
	}

	public static void addArenaRewardTimes(ConfigDatabase cd, int arenaGradeId, PlayerNode playerNode)
	{
		if(testAddArenaReward(cd, arenaGradeId, playerNode))
		{
			playerNode.getGamePlayer().getArenaPlayerData().addRewardTimes();
			ArenaDB.updatePlayerRewardTimes(playerNode.getPlayerId(), playerNode.getGamePlayer().getArenaPlayerData().getArenaRewardTimes());
		}
	}

	public static void computeGradePoint(PlayerNode playerNode, int interval, int rewardCount)
	{
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		long lastUpdateTime = gamePlayer.getArenaPlayerData().getLastUpdateGradePointTime();
		long increment = (System.currentTimeMillis() - lastUpdateTime) / (interval * 1000);

		lastUpdateTime += increment * interval * 1000;
		gamePlayer.getArenaPlayerData().setLastUpdateGradePointTime(lastUpdateTime);

		long gradePoint = rewardCount * increment;
		long gradPointPlayer = gamePlayer.getArenaPlayerData().addGradePoint(gradePoint);
		
		PlayerDB.updateGradePoint(playerNode.getPlayerId(), gradPointPlayer, lastUpdateTime);
	}

	//获取玩家获取积分速度
	public static int getSpeed(int playerId, int arenaGradeId, ConfigDatabase cd)
	{
		int rank = ArenaManager.getInstance().getPlayerRank(playerId, arenaGradeId);
		int speed = 0;
		if (rank > 0)
		{
			ArenaConfig.RankSetting rankSetting = cd.get_ArenaConfig().GetRankSettingByRankLevel(arenaGradeId, rank);
			if (null != rankSetting)
			{
				speed = rankSetting.get_reward().get_count();
			}
		}
		return speed;
	}

	public static CommonProtocols.PlayerRecord genPlayerRecordProbufFromPlayerNode(PlayerNode playerNode, int speed, int rank)
	{
		CommonProtocols.PlayerRecord.Builder builder = CommonProtocols.PlayerRecord.newBuilder();
		GamePlayer gamePlayer = playerNode.getGamePlayer();
		builder.setPlayerId(playerNode.getPlayerId());
		builder.setPlayerName(gamePlayer.getFixName());
		builder.setPlayerLevel(gamePlayer.getLevel());
		builder.setVipLevel(gamePlayer.getVipLevel());
		builder.setPower(gamePlayer.getPower());
		builder.setSpeed(speed);
		builder.setRank(rank);
		
		for(int i = 0 ; i < gamePlayer.getAvatarIds().length ; i ++)
		{
			int avatarResourceId = gamePlayer.getAvatarIds()[i];
			int battlePosition = gamePlayer.getAvatarBattlePositions()[i];
			if(avatarResourceId == 0)
			{
				continue;
			}
			builder.addAvatarResourceIds(avatarResourceId);
			builder.addAvatarBattlePositions(battlePosition);
		}
		return builder.build();
	}
	
	public static CommonProtocols.PlayerRecord genPlayerRecordProbufFromRobot(ConfigDatabase cd, int playerId, int speed, int rank)
	{
		RobotConfig.Robot robotCfg = cd.get_RobotConfig().getRobotByRobotId(playerId);
		CommonProtocols.PlayerRecord.Builder builder = CommonProtocols.PlayerRecord.newBuilder();
		builder.setPlayerId(robotCfg.get_robetId());
		builder.setPlayerName(ServerDataGS.nameMgr.findRobPlayerNameById(robotCfg.get_robetId()));
		builder.setPlayerLevel(robotCfg.get_level());
		builder.setVipLevel(0);
		
		ClientServerCommon.Npc npc = null;
		for(int i= 0; i < robotCfg.Get_npcsCount(); i++)
		{
			npc = robotCfg.Get_npcsByIndex(i);
			if(npc !=null)
			{
				NpcConfig.Npc npcCfg = cd.get_NpcConfig().GetNpcById(npc.get_npcId());
				int avatarResourceId = npcCfg.get_avatarId();
				int battlePosition = npc.get_battlePosition();
				builder.addAvatarResourceIds(avatarResourceId);
				builder.addAvatarBattlePositions(battlePosition);
				
			}
		}
		
		builder.setSpeed(speed);
		builder.setRank(rank);
		
		return builder.build();
	}

	// 转换(playerInfo不能为空)
	public static void genPlayerProtoByRobot(ConfigDatabase cd, ClientServerCommon.RobotConfig.Robot robot, GC_QueryArenaPlayerInfoRes.Builder builder)
	{
		if (robot == null)
		{
			return ;
		}

		com.kodgames.corgi.protocol.CommonProtocols.Player.Builder playerBuilder = com.kodgames.corgi.protocol.CommonProtocols.Player.newBuilder();

		com.kodgames.corgi.protocol.CommonProtocols.LevelAttrib.Builder levelAttributeBuilder = com.kodgames.corgi.protocol.CommonProtocols.LevelAttrib.newBuilder();
		levelAttributeBuilder.setLevel(robot.get_level());
		playerBuilder.setLevelAttrib(levelAttributeBuilder.build());
		playerBuilder.setName(ServerDataGS.nameMgr.findRobPlayerNameById(robot.get_robetId()));
		playerBuilder.setPlayerId(robot.get_robetId());
		
		CommonProtocols.PositionData.Builder positionDataBuilder = CommonProtocols.PositionData.newBuilder();
		int masterPositionId = cd.get_PositionConfig().GetDefaultPosition(0);
		positionDataBuilder.setMasterPositionId(masterPositionId);
		CommonProtocols.Position.Builder positionBuilder = CommonProtocols.Position.newBuilder(); 
		positionBuilder.setPositionId(masterPositionId);
		
		ClientServerCommon.Npc npc = null;
		for (int j = 0; j < robot.Get_npcsCount(); j++)
		{
			npc = robot.Get_npcsByIndex(j);
			NpcConfig.Npc npcCfg = cd.get_NpcConfig().GetNpcById(npc.get_npcId());
			
			Avatar avatar = Avatar.genNewAvatar(npcCfg.get_avatarId());
			avatar.setBreakthoughtLevel(npcCfg.get_breakthroughLevel());
			avatar.setLevel(npcCfg.get_level());
			playerBuilder.addAvatars(avatar.toProtoBuffer());
			
			CommonProtocols.Location.Builder locationBuilder = CommonProtocols.Location.newBuilder(); 
			locationBuilder.setGuid(avatar.getGuid().toString());
			locationBuilder.setPositionId(masterPositionId);
			locationBuilder.setRecourseId(avatar.getResourceId());
			locationBuilder.setLocationId(npc.get_battlePosition());
			locationBuilder.setShowLocationId(npc.get_battlePosition());

			positionBuilder.addAvatarLocations(locationBuilder.build());
		}
		positionDataBuilder.addPositions(positionBuilder.build());
		playerBuilder.setPositionData(positionDataBuilder.build());
		
		builder.setPlayer(playerBuilder.build());
	}
	
	public static Boolean isRobot(int playerId)
	{
		if(playerId < 0)
		{
			return true;
		}
		return false;
	}
	
    // 判断是否有可获得奖励次数
	public static boolean testAddArenaReward(ConfigDatabase cd, int arenaGradeId, PlayerNode playerNode)
	{
		playerNode.getGamePlayer().getArenaPlayerData().refreshRewardRewardMax(cd);
		ArenaGrade arenaGrade = cd.get_ArenaConfig().GetArenaGradeById(arenaGradeId);
		int count = arenaGrade.Get_challengeRewardsCount();
		for (int i = 0; i < count; i++)
		{
			if(arenaGrade.Get_challengeRewardsByIndex(i).get_maxCount() > playerNode.getGamePlayer().getArenaPlayerData().getArenaRewardTimes())
			{
				return true;
			}
		}
		return false;
	}
	
	public static Boolean isMaxReward(PlayerNode playerNode)
	{
		int areaGradeId = ArenaManager.getInstance().getArenaGradeIdByPlayerId(playerNode.getPlayerId());
		if( areaGradeId == 0)
		{
			return true;
		}
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerNode.getPlayerId());
		ArenaConfig arenaConf = cd.get_ArenaConfig();
		
		ArrayList<Cost> costs = new ArrayList<Cost>();
		for (int i = 0; i < arenaConf.Get_combatCostsCount(); i++)
		{
			ClientServerCommon.Cost costConf = arenaConf.Get_combatCostsByIndex(i);
			Cost otherCost = new Cost(costConf.get_id(), costConf.get_count());
			costs.add(otherCost);
		}
		
		Cost notEnoughCost = new Cost();
		if (false == CostAndRewardManager.checkCosts(playerNode, costs, cd, KodLogEvent.Arena_Combat, notEnoughCost))
		{
			return false;
		}
			
		if(false == testAddArenaReward(cd, areaGradeId, playerNode))
		{
			return false;
		}
		return true;
	}
	
	public static long lastChallengeResetTime(ConfigDatabase cd, long resetChallengePointTime)
	{
		boolean bChange = false;
		long now = System.currentTimeMillis();

		long noZone_ConfigTime =
			ClientServerCommon.ConvertTicksToMs.DateTimeToInt64(cd.get_ArenaConfig().toResetTime(cd.get_ArenaConfig()
				.get_restoreArenaChallengeTime()));// 0区的10:15 读出8区的 18:15 的 ticks的 long
		long cfgTime_withZone = ServerUtil.getLongForJava(noZone_ConfigTime, TimeZoneData.getTimeZone());// 8区的10:15的long
		long nextResetTime = ServerUtil.getNextRefreshTime(now, cfgTime_withZone);

		if (resetChallengePointTime == 0)
		{
			bChange = true;
		}
		else
		{

			long nextResetTime_LastTime = ServerUtil.getNextRefreshTime(resetChallengePointTime, cfgTime_withZone);
			if (nextResetTime_LastTime != nextResetTime)
			{
				bChange = true;
			}
		}

		if (bChange)
		{
			resetChallengePointTime = nextResetTime - 1L * 24 * 3600 * 1000;
		}
		return resetChallengePointTime;

	}
	
	// 小助手_比武场商店元宝购买
	public static boolean isRealMoneyCanBuy(PlayerNode playerNode, ConfigDatabase cd, int goodsId)
	{
		int count = cd.get_GoodStatusConfig().GetGoodById(goodsId).Get_statusByIndex(0).get_countLimit().get_count();
		Goods goods = playerNode.getPlayerInfo().getUniqueGoodsData().getUniqueGoods().get(goodsId);
		if (goods != null && goods.getAlreadyBuyCount() < count && isCostEnough(playerNode, cd, goodsId))
		{
			return true;
		}
		
		return false;
	}
	
	// 仅小助手的方法isRealMoneyCanBuy()使用
	private static boolean isCostEnough(PlayerNode playerNode, ConfigDatabase cd, int goodsId)
	{
		// 打折后价格
		int cost = cd.get_GoodStatusConfig().GetGoodById(goodsId).Get_statusByIndex(0).get_value();
		long arenaHonorPoint = playerNode.getGamePlayer().getArenaPlayerData().getGradePoint();
		// 打折后价格为0，则表示该商品没有打折
		if (cost > 0 && cost <= arenaHonorPoint)
		{
			return true;
		}
		else if (cost == 0 && cd.get_GoodConfig().GetGoodById(goodsId).Get_costsByIndex(0).get_count() <= arenaHonorPoint)
		{
			return true;
		}
		
		return false;
	}
	
	public static void bpRank()
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
		LinkedHashMap<Integer, Integer> rank = ArenaManager.getInstance().topFew(cd.get_ArenaConfig().Get_arenaGradesByIndex(0).get_arenaGradeId(), 1000);
		PlayerNode playerNode = null;
		for(Entry<Integer, Integer> entry : rank.entrySet())
		{
			int playerId = entry.getKey();
			boolean isRobot = ArenaManager.isRobot(playerId);
			if(isRobot)
			{
				RobotConfig.Robot robot = cd.get_RobotConfig().getRobotByRobotId(playerId);
				BPUtil.bwcrank(playerId, String.valueOf(robot.get_level()), entry.getValue());
			}
			else
			{
				playerNode = ServerDataGS.playerManager.getMemoryPlayerNode(entry.getKey());
				BPUtil.bwcrank(playerNode, String.valueOf(playerNode.getGamePlayer().getLevel()), entry.getValue());
			}
		}
	}
	
}
