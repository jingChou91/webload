package com.kodgames.corgi.server.gameserver.arena.logic;

import java.util.LinkedHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ArenaConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryRankTopFewReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryRankTopFewRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.arena.data.ArenaManager;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_QueryRankToFewReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_QueryRankToFewReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		CG_QueryRankTopFewReq request = (CG_QueryRankTopFewReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryRankTopFewRes.Builder builder = GC_QueryRankTopFewRes.newBuilder();
		builder.setCallback(request.getCallback());
		int playerId = sender.getClientUID().getPlayerID();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_RANK_TOPFEW_RES);
		int result = ClientProtocols.E_GAME_QUERY_RANK_TOPFEW_SUCCESS;

		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		logger.info("recv CG_QueryGradePointReqHandler, playerId = {}", playerId);
		
		do
		{
			PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
			if (playerNode == null || playerNode.getPlayerInfo() == null)
			{
				logger.warn("get playerNode failed, playerId = {}", playerId);
				result = ClientProtocols.E_GAME_QUERY_RANK_TOPFEW_ERROR_ARENACONFIG_ERROR;
				break;
			}
			if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Arena))
			{
				result = ClientProtocols.E_GAME_ARENA_FUNCTION_NOT_OPEN;
				break;
			}
			ArenaConfig arenaConf = cd.get_ArenaConfig();
			if (null == arenaConf)
			{
				logger.warn("get arenaconf config error");
				result = ClientProtocols.E_GAME_QUERY_RANK_TOPFEW_ERROR_ARENACONFIG_ERROR;
				break;
			}
			//判断该玩家在不在竞技场
			int arenaGradeId = ArenaManager.getInstance().getArenaGradeIdByPlayerId(playerId);
			ArenaConfig.ArenaGrade arenaGradeConfig = arenaConf.GetArenaGradeById(arenaGradeId);
			if (arenaGradeConfig == null)
			{
				logger.warn("arenaGradeId = {}", arenaGradeId);
				result = ClientProtocols.E_GAME_QUERY_RANK_TOPFEW_FAILED_PLAYER_NOT_IN_ARENA;
				break;
			}

			//能查看比武场前几名
			int topFew = arenaGradeConfig.get_topFew();
			if(topFew < 0)
			{
				result = ClientProtocols.E_GAME_QUERY_RANK_TOPFEW_ERROR_ARENACONFIG_ERROR;
				break;
			}
			
			LinkedHashMap<Integer, Integer> mapPlayRecord = ArenaManager.getInstance().topFew(arenaGradeId, topFew);
			for (Integer playerIdTemp : mapPlayRecord.keySet())
			{
				Integer rank = mapPlayRecord.get(playerIdTemp);
				int speed = ArenaManager.getSpeed(playerIdTemp, arenaGradeId, cd);
				if(ArenaManager.isRobot(playerIdTemp))//判断是否是机器人
				{
					builder.addPlayerRecords(ArenaManager.genPlayerRecordProbufFromRobot(cd, playerIdTemp, speed,rank));
				}
				else
				{
					PlayerNode playerNodeRecord = ServerDataGS.playerManager.getMemoryPlayerNode(playerIdTemp);
					if(playerNodeRecord == null || playerNodeRecord.getGamePlayer() == null)
					{
						continue;
					}
					builder.addPlayerRecords(ArenaManager.genPlayerRecordProbufFromPlayerNode(playerNodeRecord,speed,rank));
				}
			}
			
		}
		while (false);

		builder.setResult(result);
		builder.setCallback(request.getCallback());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
