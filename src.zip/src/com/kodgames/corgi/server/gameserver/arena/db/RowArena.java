package com.kodgames.corgi.server.gameserver.arena.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

import javax.sql.rowset.CachedRowSet;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ArenaConfig;
import ClientServerCommon.ConfigDatabase;

import com.google.protobuf.InvalidProtocolBufferException;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.corgi.protocol.DBProtocolsForServer.ArenaGradeRank;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.arena.data.ArenaDataBase;
import com.kodgames.corgi.server.gameserver.arena.data.ArenaGradeRankData;
import com.kodgames.corgi.server.gameserver.arena.data.ArenaManager;
import com.kodgames.gamedata.dbcommon.DBEasy;

public class RowArena
{
	private static final Logger logger = LoggerFactory.getLogger(RowArena.class);

	public static void loadAllArenaGradeRank(int queryIndex, Connection con, PreparedStatement[] vps,
		CachedRowSet[] vrs, ConcurrentHashMap<Integer, ArenaGradeRankData> arenaGrades)
		throws SQLException
	{
		String sql = "select arena_grade_id, rank_blob from arena_grade ";
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, null);
		
		ArenaGradeRankData arenaGradeRankData = null;
		arenaGrades.clear();
		ConfigDatabase cd = CfgDB.getDefautConfig();
		ArenaConfig arenaConfig = cd.get_ArenaConfig();
		int count = arenaConfig.Get_arenaGradesCount();
		
		Map<Integer, ArenaDataBase> dataBaseDataMap = new HashMap<Integer, ArenaDataBase>();
		ArenaDataBase arenaDataBase = null;
		if (vrs[queryIndex] != null)
		{
			CachedRowSet rs = vrs[queryIndex];
			while (rs.next())
			{
				int arenaGradeId = rs.getInt("arena_grade_id");
				arenaDataBase = new ArenaDataBase();
				byte[] rankBlob = rs.getBytes("rank_blob");
				if (rankBlob == null)
				{
					continue;
				}
				DBProtocolsForServer.ArenaGradeRank.Builder builder =DBProtocolsForServer.ArenaGradeRank.newBuilder();
				try
				{
					builder.mergeFrom(rankBlob);
				}
				catch (InvalidProtocolBufferException e)
				{
					logger.error(ExceptionUtils.getStackTrace(e));
				}
				
				ArenaGradeRank arenaGradeRank = builder.build();
				arenaDataBase.setArenaGradeRank(arenaGradeRank);
				
				dataBaseDataMap.put(arenaGradeId, arenaDataBase);
			}
		}
		//根据配置文件初始竞技场数据
		Vector<Integer> allRanks = null;
		ConcurrentHashMap<Integer, Integer> playerIdRank = null;
		
		for (int i = 0; i < count; i++)
		{
			int arenaGradeId = arenaConfig.Get_arenaGradesByIndex(i).get_arenaGradeId();
			allRanks = new Vector<Integer>();
			playerIdRank = new ConcurrentHashMap<Integer, Integer>();
			arenaGradeRankData = new ArenaGradeRankData();
			arenaGradeRankData.setAllRank(allRanks);
			arenaGradeRankData.setPlayerIdRank(playerIdRank);
			arenaGrades.put(arenaConfig.Get_arenaGradesByIndex(i).get_arenaGradeId(), arenaGradeRankData);
			if(dataBaseDataMap.containsKey(arenaGradeId)){
				ArenaDataBase aData = dataBaseDataMap.get(arenaGradeId);
				ArenaGradeRank areaArenaGradeRank = aData.getArenaGradeRank();
				int j = 0;
				for (Integer playerId : areaArenaGradeRank.getPlayerIdList())
				{
					//判断playerId
					if(!ArenaManager.isRobot(playerId) && !ServerDataGS.playerManager.getPlayerNodes().containsKey(playerId))
					{
						continue;
					}
					else
					{
						allRanks.add(playerId);
						playerIdRank.put(playerId, ++j);
					}
				}
			}
		}

	}
}
