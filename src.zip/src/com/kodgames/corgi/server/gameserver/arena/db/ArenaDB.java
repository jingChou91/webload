package com.kodgames.corgi.server.gameserver.arena.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.protocol.DBProtocolsForServer.ArenaGradeRank;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.dbclient.DBClient;
import com.kodgames.corgi.server.dbclient.KodLog;
import com.kodgames.corgi.server.dbclient.TableChangeEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.arena.data.ArenaGradeRankData;
import com.kodgames.gamedata.dbcommon.DBEasy;

public class ArenaDB
{
	private static final Logger logger = LoggerFactory.getLogger(ArenaDB.class);

	public static void loadAllRank(ConcurrentHashMap<Integer, ArenaGradeRankData> arenaGrades)
	{
		arenaGrades.clear();
		DBClient dbClient = ServerDataGS.dbCluster.getGameDBClient();
		Connection con = null;
		try
		{
			con = dbClient.getConnection();
		}
		catch (SQLException e)
		{
			logger.warn("{}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
		}

		try
		{
			if (con != null)
			{
				DoTransact_LoadAllArenaRank tt = new DoTransact_LoadAllArenaRank(arenaGrades);
				DBEasy.doTransact(con, tt);
			}
		}
		finally
		{
			if (con != null)
			{
				try
				{
					dbClient.returnConnection(con);
				}
				catch (SQLException e)
				{
					logger.warn("{}\n{}", e.getMessage(), ExceptionUtils.getStackTrace(e));
				}
			}
		}
	}
	
	public static void replaceArenaGradeRank(Integer arenaGradeId, ArenaGradeRank arenaGradeRank)
	{
		String currentTime = KodLog.getDatetime(System.currentTimeMillis());
		String sql = String.format(" replace into arena_grade(rank_blob, arena_grade_id, last_update_time) values (%s, %d, '%s')", ServerUtil.toHexString(arenaGradeRank.toByteArray()), arenaGradeId, currentTime);
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(0, sql);
	}
	
	public static void updatePlayerRewardTimes(int playerId, int arena_reward_times)
	{
		long arena_reward_date = System.currentTimeMillis();
		String sql = String.format(" update player set arena_reward_times = %d, arena_reward_date=%d where player_id = %d", arena_reward_times, arena_reward_date, playerId);
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(TableChangeEvent.getKey(playerId, TableChangeEvent.PLAYER_UPDATEPLAYERREWARDTIMES),playerId, sql);
	}
}
