package com.kodgames.corgi.server.gameserver.arena.data;

import java.util.Map;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

public class ArenaGradeRankData
{
	private Vector<Integer> allRank = null;
    private ConcurrentHashMap<Integer, Integer> playerIdRank = null;
    
	public Vector<Integer> getAllRank()
	{
		return allRank;
	}
	public void setAllRank(Vector<Integer> allRank)
	{
		this.allRank = allRank;
	}
	public ConcurrentHashMap<Integer, Integer> getPlayerIdRank()
	{
		return playerIdRank;
	}
	public void setPlayerIdRank(ConcurrentHashMap<Integer, Integer> playerIdRank)
	{
		this.playerIdRank = playerIdRank;
	}
	
	public ArenaGradeRankData copy()
	{
		Vector<Integer> allRankCopy = new Vector<>();
		ConcurrentHashMap<Integer, Integer> playerIdRankCopy = new ConcurrentHashMap<>();
		
		for(int i = 0 ; i < this.allRank.size(); i++)
		{
			allRankCopy.add(this.allRank.get(i));
		}
		
		for(Map.Entry<Integer, Integer> entry : this.playerIdRank.entrySet())
		{
			playerIdRankCopy.put(entry.getKey(), entry.getValue());
		}
		
		ArenaGradeRankData copy = new ArenaGradeRankData();
		copy.setAllRank(allRankCopy);
		copy.setPlayerIdRank(playerIdRankCopy);
		return copy;
	}
}
