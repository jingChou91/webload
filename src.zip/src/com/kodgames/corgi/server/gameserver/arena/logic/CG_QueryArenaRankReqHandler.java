package com.kodgames.corgi.server.gameserver.arena.logic;

import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ArenaConfig;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryArenaRankReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryArenaRankRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.arena.data.ArenaManager;
import com.kodgames.corgi.server.gameserver.position.data.Location;
import com.kodgames.corgi.server.gameserver.position.data.Position;
import com.kodgames.gamedata.player.PlayerDB;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.ItemType;

public class CG_QueryArenaRankReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_QueryArenaRankReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		CG_QueryArenaRankReq request = (CG_QueryArenaRankReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryArenaRankRes.Builder builder = GC_QueryArenaRankRes.newBuilder();
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_QUERY_ARENA_RANK_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_ARENA_RANK_RES);

		logger.info("recv CG_QueryArenaRankReq, playerId = {}", playerId);
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					logger.warn("get player failed, playerId = {}", playerId);
					result = ClientProtocols.E_GAME_QUERY_ARENA_RANK_FAILED_ADD_PLAYER_FAILED;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Arena))
				{
					result = ClientProtocols.E_GAME_ARENA_FUNCTION_NOT_OPEN;
					break;
				}

				ArenaConfig arenaConfig = cd.get_ArenaConfig();
				if (arenaConfig == null)
				{
					result = ClientProtocols.E_GAME_QUERY_ARENA_RANK_ERROR_ARENACONFIG_ERROR;
					break;
				}
				
				int positionId = playerNode.getPlayerInfo().getPositionData().getMasterPositionId();
				//判断阵位Id是否有效
				if(!playerNode.getPlayerInfo().getPositionData().getPositions().containsKey(positionId))
				{
					result = ClientProtocols.E_GAME_QUERY_ARENA_RANK_FAILED_NOT_POSITON_AVATAR;
					break;
				}
				
				Position position = playerNode.getPlayerInfo().getPositionData().getPositions().get(positionId);
				
				//如果玩家主阵位上没有角色,不能进入
				boolean avaliable = false;
				for(Map.Entry<Guid, Location> entry : position.getLocations().entrySet())
				{
					if(ItemType.isAvatar(entry.getValue().getResourceId()) && entry.getValue().getLocationId() != position.getEmployLocationId())
					{
						avaliable = true;
					}
				}
				if(avaliable == false)
				{
					result = ClientProtocols.E_GAME_QUERY_ARENA_RANK_FAILED_NOT_POSITON_AVATAR;
					break;
				}
				

				int arenaGradeId = ArenaManager.getInstance().getArenaGradeIdByPlayerId(playerId);
				ArenaConfig.ArenaGrade arenaGradeCfg = arenaConfig.GetArenaGradeById(arenaGradeId);
				// 如果玩家没有排名数据（第一次进入竞技场），把该玩家排到当前排名列表的最后一名
				if (arenaGradeCfg == null)
				{
					logger.info("First inter Arena, playerId = {}", playerId);
					for (int i = 0; i < arenaConfig.Get_arenaGradesCount(); i++)
					{
						if (playerNode.getGamePlayer().getLevel() >= arenaConfig.Get_arenaGradesByIndex(i).get_fromLevel())
						{
							arenaGradeId = arenaConfig.Get_arenaGradesByIndex(i).get_arenaGradeId();
						}
					}

					int rank = ArenaManager.getInstance().addPlayerAndRank(arenaGradeId, playerId);
					if (rank <= 0)
					{
						logger.warn("Rank = {}", rank);
						result = ClientProtocols.E_GAME_QUERY_ARENA_RANK_FAILED_ADD_PLAYER_FAILED;
						break;
					}

					long lastUpdateTime = System.currentTimeMillis();
					playerNode.getGamePlayer().getArenaPlayerData().setLastUpdateGradePointTime(lastUpdateTime);

					PlayerDB.updateGradePoint(playerId, playerNode.getGamePlayer().getArenaPlayerData().getGradePoint(), lastUpdateTime);
				}
				
				int rank = ArenaManager.getInstance().getPlayerRank(playerId, arenaGradeId);
				if (rank <= 0)
				{
					logger.warn("Rank = {}", rank);
					result = ClientProtocols.E_GAME_QUERY_ARENA_RANK_FAILED_PLAYER_NOT_IN_ARENAGRADE;
					break;
				}

				ArenaConfig.RankSetting rankSetting = arenaConfig.GetRankSettingByRankLevel(arenaGradeId, rank);
				if (null == rankSetting)
				{
					logger.warn("get RankSetting failed");
					result = ClientProtocols.E_GAME_QUERY_ARENA_RANK_ERROR_ARENACONFIG_ERROR;
					break;
				}

				int fixChallengeNum = arenaConfig.GetArenaGradeById(arenaGradeId).get_fixChallengeNum();
				int specialChallengeNum = arenaConfig.GetArenaGradeById(arenaGradeId).get_specialChallengeNum();
				int interval = arenaConfig.GetArenaGradeById(arenaGradeId).get_keepRandInterval();
				if (fixChallengeNum < 0 || interval <= 0 || specialChallengeNum < 0)
				{
					logger.warn("config value less than zore");
					result = ClientProtocols.E_GAME_QUERY_ARENA_RANK_ERROR_ARENACONFIG_ERROR;
					break;
				}

				int speed = ArenaManager.getSpeed(playerId, arenaGradeId, cd);

				// 得到个数为 randomOpponentCount 的可挑战
				LinkedHashMap<Integer, Integer> playerRecords =ArenaManager.getInstance().rankFirst8(playerId, arenaGradeId, fixChallengeNum, specialChallengeNum);
				for (Integer playerIdTemp : playerRecords.keySet())
				{
					Integer rankRecord = playerRecords.get(playerIdTemp);
					int speedRecord = ArenaManager.getSpeed(playerIdTemp, arenaGradeId, cd);
					if(ArenaManager.isRobot(playerIdTemp))
					{
						builder.addPlayerRecords(ArenaManager.genPlayerRecordProbufFromRobot(cd, playerIdTemp,speedRecord,rankRecord));
					}
					else
					{
						PlayerNode playerNodeRecord = ServerDataGS.playerManager.getMemoryPlayerNode(playerIdTemp);
						if(playerNodeRecord == null || playerNodeRecord.getGamePlayer() == null)
						{
							continue;
						}
						builder.addPlayerRecords(ArenaManager.genPlayerRecordProbufFromPlayerNode(playerNodeRecord,speedRecord,rankRecord));
					}
					
				}

				// 计算新的积分 修改内存和数据库
				ArenaManager.computeGradePoint(playerNode, interval, rankSetting.get_reward().get_count());
				playerNode.getGamePlayer().getArenaPlayerData().refresh(cd, playerNode.getGamePlayer().getVipLevel());

				// 当前名次
				builder.setSelfRank(rank);
				builder.setSpeed(speed);
				// 玩家已经挑战次数，和积分
				builder.setGradePoint(playerNode.getGamePlayer().getArenaPlayerData().getGradePoint());
				builder.setChallengeTimes(playerNode.getGamePlayer().getArenaPlayerData().getChallengePoint());
				long lastResetChallengeTime = ArenaManager.lastChallengeResetTime(cd, playerNode.getGamePlayer().getArenaPlayerData().getResetChallengePointTime());
				builder.setLastResetChallengeTime(lastResetChallengeTime);
				// 当前比武场
				builder.setArenaGradeId(arenaGradeId);
			}
			while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		builder.setCallback(request.getCallback());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
