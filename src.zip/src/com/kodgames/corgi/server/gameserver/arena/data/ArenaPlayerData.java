package com.kodgames.corgi.server.gameserver.arena.data;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.VipConfig;

import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.server.common.ServerUtil;

public class ArenaPlayerData
{
	private long gradePoint;// 积分
	private long lastUpdateGradePointTime;// 上次计算积分的时间
	private int challengePoint;// 已挑战次数
	private int arenaRewardTimes;
	private long arenaRewardDate;
	private long resetChallengePointTime;

	public long addGradePoint(long gradePoint)
	{
		this.gradePoint += gradePoint;
		return this.gradePoint;
	}

	public long getGradePoint()
	{
		return gradePoint;
	}

	public void setGradePoint(long gradePoint)
	{
		this.gradePoint = gradePoint;
	}

	public int getChallengePoint()
	{
		return challengePoint;
	}

	public long getLastUpdateGradePointTime()
	{
		return lastUpdateGradePointTime;
	}

	public void setLastUpdateGradePointTime(long lastUpdateGradePointTime)
	{
		this.lastUpdateGradePointTime = lastUpdateGradePointTime;
	}

	public long getResetChallengePointTime()
	{
		return resetChallengePointTime;
	}

	public void setResetChallengePointTime(long resetChallengePointTime)
	{
		this.resetChallengePointTime = resetChallengePointTime;
	}

	public void setChallengePoint(int challengePoint)
	{
		this.challengePoint = challengePoint;
	}

	public int getArenaRewardTimes()
	{
		return arenaRewardTimes;
	}

	public long getArenaRewardDate()
	{
		return arenaRewardDate;
	}

	public void setArenaRewardDate(long arenaRewardDate)
	{
		this.arenaRewardDate = arenaRewardDate;
	}

	public void setArenaRewardTimes(int arenaRewardTimes)
	{
		this.arenaRewardTimes = arenaRewardTimes;
	}

	public void addRewardTimes()
	{
		this.arenaRewardTimes++;
	}

	// 判断加积分
	public boolean testAddGradePoint(int change)
	{
		if (this.gradePoint + change < 0)
		{
			return false;
		}
		return true;
	}

	// 加积分
	public boolean addGradePoint(int change)
	{
		if (testAddGradePoint(change))
		{
			this.gradePoint += change;
			return true;
		}
		return false;
	}

	// -------------------------------------------------------------------
	// 判断挑战次数
	public boolean testAddChallengePoint(int change, ConfigDatabase cd, int vipLevel)
	{
		refresh_challengePointCount(cd);
		int limit = cd.get_VipConfig().GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.DailyArenaCombatCount);
		if (this.challengePoint + change <= limit)
		{
			// 竞技场挑战次数可为负数 ： 使用道具后： 剩余可挑战次数 = limit - 已使用次数
			return true;
		}
		else
		{
			return false;
		}
	}

	// 加挑战次数
	public boolean addChallengePoint(int change, ConfigDatabase cd, int vipLevel)
	{
		if (testAddChallengePoint(change, cd, vipLevel))
		{
			challengePoint += change;
			return true;
		}
		return false;
	}

	private boolean refresh_challengePointCount(ConfigDatabase cd)
	{

		boolean bChange = false;
		long now = System.currentTimeMillis();

		long noZone_ConfigTime =
			ClientServerCommon.ConvertTicksToMs.DateTimeToInt64(cd.get_ArenaConfig().toResetTime(cd.get_ArenaConfig()
				.get_restoreArenaChallengeTime()));// 0区的10:15 读出8区的 18:15 的 ticks的 long
		long cfgTime_withZone = ServerUtil.getLongForJava(noZone_ConfigTime, TimeZoneData.getTimeZone());// 8区的10:15的long
		long nextResetTime = ServerUtil.getNextRefreshTime(now, cfgTime_withZone);

		if (this.resetChallengePointTime == 0)
		{
			bChange = true;
		}
		else
		{

			long nextResetTime_LastTime = ServerUtil.getNextRefreshTime(this.resetChallengePointTime, cfgTime_withZone);
			if (nextResetTime_LastTime != nextResetTime)
			{
				bChange = true;
			}
		}

		if (bChange)
		{
			if (this.challengePoint > 0)
			{
				this.challengePoint = 0;
			}
			this.resetChallengePointTime = nextResetTime - 1L * 24 * 3600 * 1000;
		}

		return bChange;
	}
	
	public boolean refreshRewardRewardMax(ConfigDatabase cd)
	{

		boolean bChange = false;
		long now = System.currentTimeMillis();

		long noZone_ConfigTime =
			ClientServerCommon.ConvertTicksToMs.DateTimeToInt64(cd.get_ArenaConfig().toResetTime(cd.get_ArenaConfig()
				.get_restoreArenaChallengeTime()));// 0区的10:15 读出8区的 18:15 的 ticks的 long
		long cfgTime_withZone = ServerUtil.getLongForJava(noZone_ConfigTime, TimeZoneData.getTimeZone());// 8区的10:15的long
		long nextResetTime = ServerUtil.getNextRefreshTime(now, cfgTime_withZone);

		if (this.arenaRewardDate == 0)
		{
			bChange = true;
		}
		else
		{

			long nextResetTime_LastTime = ServerUtil.getNextRefreshTime(this.arenaRewardDate, cfgTime_withZone);
			if (nextResetTime_LastTime != nextResetTime)
			{
				bChange = true;
			}
		}

		if (bChange)
		{
			if (this.arenaRewardTimes > 0)
			{
				this.arenaRewardTimes = 0;
			}
			this.arenaRewardDate = nextResetTime - 1L * 24 * 3600 * 1000;
		}

		return bChange;
	}
	
	// -------------------------------------------------------------------
	//
	public void refresh(ConfigDatabase cd, int vipLevel)
	{
		refresh_challengePointCount(cd);
	}

}
