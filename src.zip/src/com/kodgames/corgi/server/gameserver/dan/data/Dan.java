package com.kodgames.corgi.server.gameserver.dan.data;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon.IMathParser;

import com.kodgames.common.Guid;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.corgi.server.gameserver.avatar.data.Card;
import com.kodgames.corgi.server.gameserver.dan.util.DanUtil;

public class Dan extends Card
{
	private static final Logger logger = LoggerFactory.getLogger(Dan.class);

	private List<Integer> attributes = new ArrayList<Integer>();
	private boolean locked = false; // 是否锁定
	private long creatTime = 0L; // 创建时间

	@Override
	public Object[] getObjectListForInsertRow(int playerId, int status_did_delete)
	{
		return new Object[]{};
	}

	@Override
	/**
	 * 只能传入Dan类型的参数,否则会导致向下转型失败
	 */
	public Dan copy(Card card)
	{
		Dan dan = (Dan)card;
		setGuid(Guid.genNewGuid(dan.getGuid().toString()));
		setResourceId(dan.getResourceId());
		setLevel(dan.getLevel());
		setExperience(dan.getExperience());
		setBreakthoughtLevel(dan.getBreakthoughtLevel());
		setLocked(dan.isLocked());
		setCreatTime(dan.getCreatTime());

		this.attributes.clear();
		for (int attributeId : dan.attributes)
		{
			this.attributes.add(attributeId);
		}

		return this;
	}

	public static Dan genNewDan(int recourceId)
	{
		Dan dan = new Dan();
		dan.setGuid(new Guid());
		dan.setResourceId(recourceId);
		dan.setLevel(1);
		dan.setExperience(0);
		dan.setBreakthoughtLevel(0);
		dan.setLocked(false);
		dan.setCreatTime(System.currentTimeMillis());
		return dan;
	}

	@Override
	public CommonProtocols.Dan toProtoBuffer()
	{
		CommonProtocols.Dan.Builder danBuilder = CommonProtocols.Dan.newBuilder();
		ConfigDatabase cd = ConfigDatabase.get_DefaultCfg();
		DanConfig.Dan danCfg = cd.get_DanConfig().GetDanById(this.getResourceId());
		if (danCfg != null)
		{
			danBuilder.setType(danCfg.get_Type());
		}
		danBuilder.setGuid(getGuid().toString());
		danBuilder.setResourceId(this.getResourceId());
		CommonProtocols.LevelAttrib.Builder levelAttributeBuilder = CommonProtocols.LevelAttrib.newBuilder();
		levelAttributeBuilder.setLevel(this.getLevel());
		levelAttributeBuilder.setExperience(this.getExperience());
		danBuilder.setLevelAttrib(levelAttributeBuilder.build());
		danBuilder.setBreakthoughtLevel(this.getBreakthoughtLevel());
		danBuilder.setLocked(this.isLocked());
		danBuilder.setCreateTime(this.getCreatTime());

		// 检测内丹属性数量
		if (this.getAttributes().size() < this.getBreakthoughtLevel())
		{
			logger.error("______!!!  dan attributes Size < breakthought,Then Auto FixDanAttributesCount  Guid:"
				+ this.getGuid().toString());
			DanUtil.fixDanAttributesCount(this);
		}
		float danPower = 0f;
		for (int id : this.attributes)
		{
			CommonProtocols.DanAttributeGroup danAttributeGroup =
				DanUtil.getDanAttributeGroupPro(cd, getResourceId(), id);
			if (danAttributeGroup != null)
			{
				danBuilder.addAttributeIds(id);
				danBuilder.addDanAttributeGroups(danAttributeGroup);
			}
		}
		for(int danAttributeGroupId : this.getAttributes())
		{
			DanConfig.DanAttributeGroup danAttributeGroup = cd.get_DanConfig().GetDanAttributeGroup(danAttributeGroupId);
			if(danAttributeGroup == null)
			{
				continue;
			}
			for(int j=0;j<danAttributeGroup.Get_AttributeIdsCount();j++)
			{
				int danAttributeId = danAttributeGroup.Get_AttributeIdsByIndex(j);
				DanConfig.DanAttribute danAttribute = cd.get_DanConfig().GetDanAttributeById(danAttributeId);
				if (danAttribute != null)
				{
					ClientServerCommon.PowerAttribute powerAttribute = danAttribute.get_PowerAttributes();
					if(null != powerAttribute)
					{
						danPower += powerAttribute.GetValue(this.getLevel());
					}
				}
			}
					
		}
		danBuilder.setDanPower(danPower);
		return danBuilder.build();
	}

	public static CommonProtocols.Dan toProtoBuffer(DBProtocolsForServer.DanDB dan)
	{
		CommonProtocols.Dan.Builder danBuilder = CommonProtocols.Dan.newBuilder();
		ConfigDatabase cd = ConfigDatabase.get_DefaultCfg();
		DanConfig.Dan danCfg = cd.get_DanConfig().GetDanById(dan.getResourceId());
		if (danCfg != null)
		{
			danBuilder.setType(danCfg.get_Type());
		}
		danBuilder.setGuid(dan.getGuid().toString());
		danBuilder.setResourceId(dan.getResourceId());
		CommonProtocols.LevelAttrib.Builder levelAttributeBuilder = CommonProtocols.LevelAttrib.newBuilder();
		levelAttributeBuilder.setLevel(dan.getLevel());
		levelAttributeBuilder.setExperience(dan.getExperience());
		danBuilder.setLevelAttrib(levelAttributeBuilder.build());
		danBuilder.setBreakthoughtLevel(dan.getBreakthoughtLevel());
		danBuilder.setLocked(dan.getLocked());
		danBuilder.setCreateTime(dan.getCreateTime());

		for (int id : dan.getAttributeIdsList())
		{
			CommonProtocols.DanAttributeGroup danAttributeGroup =
				DanUtil.getDanAttributeGroupPro(cd, dan.getResourceId(), id);
			if (danAttributeGroup != null)
			{
				danBuilder.addAttributeIds(id);
				danBuilder.addDanAttributeGroups(danAttributeGroup);
			}
		}
		return danBuilder.build();
	}

	public Dan fromProtoBuffer(com.kodgames.corgi.protocol.CommonProtocols.Dan protocol)
	{
		this.setGuid(Guid.genNewGuid(protocol.getGuid()));
		this.setResourceId(protocol.getResourceId());
		this.setLevel(protocol.getLevelAttrib().getLevel());
		this.setExperience(protocol.getLevelAttrib().getExperience());
		this.setBreakthoughtLevel(protocol.getBreakthoughtLevel());
		this.setLocked(protocol.getLocked());
		this.setCreatTime(protocol.getCreateTime());

		for (int attributeId : protocol.getAttributeIdsList())
		{
			this.getAttributes().add(attributeId);
		}

		return this;
	}

	public DBProtocolsForServer.DanDB toDBProtoBuf()
	{
		DBProtocolsForServer.DanDB.Builder builder = DBProtocolsForServer.DanDB.newBuilder();
		builder.setGuid(getGuid().toString());
		builder.setResourceId(this.getResourceId());
		builder.setLevel(this.getLevel());
		builder.setExperience(this.getExperience());
		builder.setBreakthoughtLevel(this.getBreakthoughtLevel());
		builder.setLocked(this.isLocked());
		builder.addAllAttributeIds(this.getAttributes());
		builder.setCreateTime(this.getCreatTime());

		return builder.build();
	}

	public void fromDBProtoBuf(DBProtocolsForServer.DanDB danDB)
	{
		this.setGuid(Guid.genNewGuid(danDB.getGuid()));
		this.setResourceId(danDB.getResourceId());
		this.setLevel(danDB.getLevel());
		this.setExperience(danDB.getExperience());
		this.setBreakthoughtLevel(danDB.getBreakthoughtLevel());
		this.setLocked(danDB.getLocked());
		this.setCreatTime(danDB.getCreateTime());
		for (int attributeId : danDB.getAttributeIdsList())
		{
			this.getAttributes().add(attributeId);
		}
		// 检测内丹属性数量
		if (this.getAttributes().size() < this.getBreakthoughtLevel())
		{
			logger.error("______!!!  dan attributes Size < breakthought,Then Auto FixDanAttributesCount  Guid:" + this.getGuid().toString());
			DanUtil.fixDanAttributesCount(this);
		}
	}

	@Override
	public void setupVariable(IMathParser parser, ConfigDatabase cd)
	{

	}

	public List<Integer> getAttributes()
	{
		return attributes;
	}

	public void setAttributes(List<Integer> attributes)
	{
		this.attributes = attributes;
	}

	public boolean isLocked()
	{
		return locked;
	}

	public int getLocked()
	{
		return locked ? 1 : 0;
	}

	public void setLocked(boolean locked)
	{
		this.locked = locked;
	}

	public long getCreatTime()
	{
		return creatTime;
	}

	public void setCreatTime(long creatTime)
	{
		this.creatTime = creatTime;
	}

}
