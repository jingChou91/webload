package com.kodgames.corgi.server.gameserver.dan.db;

import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.dbclient.TableChangeEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.gamedata.player.PlayerNode;

public class DanInfoDB
{
	public static void updateDanInfo(PlayerNode playerNode)
	{
		String sql =
			String.format("replace into dan_info (player_id,dan_infos) values (%d,%s)",
				playerNode.getPlayerId(),
				ServerUtil.toHexString(playerNode.getPlayerInfo().getDanData().toDBProtolBuf().toByteArray()));
		ServerDataGS.dbCluster.getGameDBClient()
		.executeAsynchronousUpdate(TableChangeEvent.getKey(playerNode.getPlayerId(), TableChangeEvent.DANINFO_UPDATE),
			playerNode.getPlayerId(), sql);
	}
}
