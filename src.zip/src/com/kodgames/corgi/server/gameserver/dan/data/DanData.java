package com.kodgames.corgi.server.gameserver.dan.data;

import java.util.ArrayList;

import com.kodgames.common.Guid;
import com.kodgames.corgi.protocol.DBProtocolsForServer;

public class DanData
{
	private ArrayList<Dan> dans = new ArrayList<>();

	public ArrayList<Dan> getDans()
	{
		return dans;
	}

	public void setDans(ArrayList<Dan> dans)
	{
		this.dans = dans;
	}

	// 查丹
	public Dan getDan(Guid guid)
	{
		for (Dan _dan : dans)
		{
			if (_dan.getGuid().equals(guid))
			{
				return _dan;
			}
		}
		return null;
	}

	// 加丹
	public boolean addDan(Dan dan)
	{
		if (getDan(dan.getGuid()) == null)
		{
			return dans.add(dan);
		}

		return false;
	}

	// 删丹
	public boolean removeDan(Guid guid)
	{
		Dan _dan = getDan(guid);
		if (_dan != null)
		{
			return dans.remove(_dan);
		}
		return false;
	}
	
	public DBProtocolsForServer.DanInfoDB toDBProtolBuf()
	{
		DBProtocolsForServer.DanInfoDB.Builder builder = DBProtocolsForServer.DanInfoDB.newBuilder();
		for (Dan dan : dans)
		{
			builder.addDanDBs(dan.toDBProtoBuf());
		}
		
		return builder.build();
	}
	
	public void fromDBProtolBuf(DBProtocolsForServer.DanInfoDB danInfoDB)
	{
		for (DBProtocolsForServer.DanDB danDB : danInfoDB.getDanDBsList())
		{
			Dan dan = new Dan();
			dan.fromDBProtoBuf(danDB);
			this.getDans().add(dan);
		}
	}
}
