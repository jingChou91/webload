package com.kodgames.corgi.server.gameserver.dan.logic;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_DanLevelUpReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_DanLevelUpRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dan.data.Dan;
import com.kodgames.corgi.server.gameserver.dan.db.DanInfoDB;
import com.kodgames.corgi.server.gameserver.dan.util.DanUtil;
import com.kodgames.gamedata.player.PlayerAttributeMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.genplayer.PowerMgr;

public class CG_DanLevelUpReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_DanLevelUpReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_DanLevelUpReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_DanLevelUpReq request = (CG_DanLevelUpReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_DanLevelUpRes.Builder builder = GC_DanLevelUpRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_DAN_LEVEL_UP_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_DAN_LEVEL_UP_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		
		Guid guid = Guid.genNewGuid(request.getGuid());
		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_DAN_LEVEL_UP_FAILED_LOAD_PALYER;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.DanHome))
				{
					result = ClientProtocols.E_GAME_DAN_LEVEL_UP_FAILED_FUNCTION_NOT_OPEN;
					break;
				}
				DanConfig danConfig = cd.get_DanConfig();
				if (danConfig == null)
				{
					result = ClientProtocols.E_GAME_DAN_LEVEL_UP_FAILED_LOAD_CONFIG;
					break;
				}
				
				Dan dan = playerNode.getPlayerInfo().getDanData().getDan(guid);
				if (dan == null)
				{
					result = ClientProtocols.E_GAME_DAN_LEVEL_UP_FAILED_DAN_NOT_FOUND;
					break;
				}
				DanConfig.Dan danCfg = danConfig.GetDanById(dan.getResourceId());
				if (danCfg == null)
				{
					result = ClientProtocols.E_GAME_DAN_LEVEL_UP_FAILED_DANCONFIG_ERROR;
					break;
				}
				
				// 是否已达最高等级
				if (dan.getLevel() >= danConfig.get_MaxLevel())
				{
					result = ClientProtocols.E_GAME_DAN_LEVEL_UP_FAILED_LEVEL_MAX;
					break;
				}
				
				DanConfig.LevelInfo levelInfoCfg = danCfg.GetLevelInfoByBreakAndLevel(dan.getBreakthoughtLevel(), dan.getLevel());
				if (levelInfoCfg == null)
				{
					result = ClientProtocols.E_GAME_DAN_LEVEL_UP_FAILED_LEVELINFO_ERROR;
					break;
				}
				
				ArrayList<Cost> costs = new ArrayList<Cost>();
				Cost costNotEnough = new Cost();
				CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
				// 升级货币消耗
				ClientServerCommon.Cost moneyCost = levelInfoCfg.get_MoneyCost();
				if (moneyCost == null)
				{
					result = ClientProtocols.E_GAME_DAN_LEVEL_UP_FAILED_MONEY_COST_CONFIG_ERROR;
					break;
				}
				costs.add(new Cost(moneyCost.get_id(), moneyCost.get_count()));
				// 货币是否足够
				if (!CostAndRewardManager.checkCosts(playerNode, costs, cd, KodLogEvent.Dan_LevelUp, costNotEnough))
				{
					crsForClient.setNotEnoughCost(costNotEnough);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_DAN_LEVEL_UP_FAILED_MONEY_COST_NOT_ENOUGH;
					break;
				}
				// 升级道具消耗
				for (int i = 0; i < levelInfoCfg.Get_CostsCount(); i++)
				{
					costs.add(new Cost(levelInfoCfg.Get_CostsByIndex(i).get_id(), levelInfoCfg.Get_CostsByIndex(i).get_count()));
				}
				// 道具是否足够
				if (!CostAndRewardManager.checkCosts(playerNode, costs, cd, KodLogEvent.Dan_LevelUp, costNotEnough))
				{
					crsForClient.setNotEnoughCost(costNotEnough);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_DAN_LEVEL_UP_FAILED_ITEM_COSTS_NOT_ENOUGH;
					break;
				}
				
				// 随出升级操作后的等级
				int levelAfter = DanUtil.getLevelAfterLevelUp(levelInfoCfg);
				
				// 获得升级后等级失败
				if (levelAfter == -1)
				{
					result = ClientProtocols.E_GAME_DAN_LEVEL_UP_FAILED_GET_RESULT;
					break;
				}
				
				// 升级前等级
				int levelBefore = dan.getLevel();
				
				// 修改内存
				crsForCost.setCosts(costs);
				CostAndRewardManager.consumeCosts(playerNode, costs, cd, KodLogEvent.Dan_LevelUp, 0, 0);
				crsForClient.megerCostAndRewardAndSync(crsForCost);
				// 等级变化
				if (levelBefore != levelAfter)
				{
					// 修改等级
					dan.setLevel(levelAfter);
					// 修改数据库
					DanInfoDB.updateDanInfo(playerNode);
				}
				// 埋点日志
				BPUtil.dansj(playerNode, dan.getResourceId(), dan.getBreakthoughtLevel(), levelBefore, levelAfter);
				
				builder.setLevel(levelAfter);
				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
				//战力
				float power = PowerMgr.calPower(playerNode, cd);
				PlayerAttributeMgr.setPlayerPower(playerNode, (int)power);
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
