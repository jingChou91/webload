package com.kodgames.corgi.server.gameserver.dan;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.dan.logic.CG_DanAttributeRefreshReqHandler;
import com.kodgames.corgi.server.gameserver.dan.logic.CG_DanBreakthoughtReqHandler;
import com.kodgames.corgi.server.gameserver.dan.logic.CG_DanLevelUpReqHandler;
import com.kodgames.corgi.server.gameserver.dan.logic.CG_QueryDanUpgradeReqHandler;

public class Logic_Dan
{
	private CG_QueryDanUpgradeReqHandler cg_QueryDanUpgradeReqHandler = null;
	private CG_DanLevelUpReqHandler cg_DanLevelUpReqHandler = null;
	private CG_DanBreakthoughtReqHandler cg_DanBreakthoughtReqHandler = null;
	private CG_DanAttributeRefreshReqHandler cG_DanAttributeRefreshReqHandler = null;
	
	public void init()
	{
		cg_QueryDanUpgradeReqHandler = new CG_QueryDanUpgradeReqHandler();
		cg_DanLevelUpReqHandler = new CG_DanLevelUpReqHandler();
		cg_DanBreakthoughtReqHandler = new CG_DanBreakthoughtReqHandler();
		cG_DanAttributeRefreshReqHandler = new CG_DanAttributeRefreshReqHandler();
	}
	
	public void registerProtoBufType(Controller controller)
	{
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_DAN_UPGRADE_REQ, GameProtocolsForClient.CG_QueryDanUpgradeReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_DAN_LEVEL_UP_REQ, GameProtocolsForClient.CG_DanLevelUpReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_DAN_BREAKTHOUGHT_REQ, GameProtocolsForClient.CG_DanBreakthoughtReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_DAN_ATTRIBUTE_REFRESH_REQ, GameProtocolsForClient.CG_DanAttributeRefreshReq.getDefaultInstance());
	}
	
	public void registerMessageHandler(Controller controller)
	{
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_DAN_UPGRADE_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryDanUpgradeReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_DAN_LEVEL_UP_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_DanLevelUpReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_DAN_BREAKTHOUGHT_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_DanBreakthoughtReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_DAN_ATTRIBUTE_REFRESH_REQ, ServerUtil.getFacilityMessageHandlerFactory(cG_DanAttributeRefreshReqHandler));
	}
}
