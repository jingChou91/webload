package com.kodgames.corgi.server.gameserver.dan.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryDanUpgradeReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryDanUpgradeRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dan.data.Dan;
import com.kodgames.corgi.server.gameserver.dan.data.DanData;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_QueryDanUpgradeReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_QueryDanUpgradeReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_QueryDanUpgradeReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_QueryDanUpgradeReq request = (CG_QueryDanUpgradeReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryDanUpgradeRes.Builder builder = GC_QueryDanUpgradeRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_DAN_UPGRADE_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_QUERY_DAN_UPGRADE_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		String guidStr = request.getDanGUID();
		int upgradeType = request.getUpgradeType();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_UPGRADE_FAILED;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.DanHome))
				{
					result = ClientProtocols.E_GAME_ALCHEMY_FAILED_FUNCTION_OPEN;
					break;
				}
				DanConfig danCfg = cd.get_DanConfig();
				if (danCfg == null)
				{
					result = ClientProtocols.E_GAME_ALCHEMY_FAILED_LOAD_CONFIG;
					break;
				}
				DanData danData = playerNode.getPlayerInfo().getDanData();
				Guid guid = Guid.genNewGuid(guidStr);
				Dan dan = danData.getDan(guid);
				if (dan == null)
				{
					result = ClientProtocols.E_GAME_ALCHEMY_FAILED_FUNCTION_OPEN;
					break;
				}
				
				switch (upgradeType) 
				{
					case DanConfig._UpgradeType.LevelUp:
						
						
						
						break;
					case DanConfig._UpgradeType.BreakThought:
						
						
						
						break;
						
					case DanConfig._UpgradeType.AttributeRefresh:
						
						
						
						break;

					default:
						break;
				}
				
				
				

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
