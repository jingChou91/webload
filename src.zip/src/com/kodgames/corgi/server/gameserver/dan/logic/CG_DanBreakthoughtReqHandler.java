package com.kodgames.corgi.server.gameserver.dan.logic;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_DanBreakthoughtReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_DanBreakthoughtRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dan.data.Dan;
import com.kodgames.corgi.server.gameserver.dan.db.DanInfoDB;
import com.kodgames.corgi.server.gameserver.dan.util.DanUtil;
import com.kodgames.gamedata.player.PlayerAttributeMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.genplayer.PowerMgr;

public class CG_DanBreakthoughtReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_DanBreakthoughtReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_DanBreakthoughtReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_DanBreakthoughtReq request = (CG_DanBreakthoughtReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_DanBreakthoughtRes.Builder builder = GC_DanBreakthoughtRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_DAN_BREAKTHOUGHT_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_DAN_BREAKTHOUGHT_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();

		Guid guid = Guid.genNewGuid(request.getGuid());
		
		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_DAN_BREAKTHOUGHT_FAILED_LOAD_PALYER;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.DanHome))
				{
					result = ClientProtocols.E_GAME_DAN_BREAKTHOUGHT_FAILED_FUNCTION_NOT_OPEN;
					break;
				}
				DanConfig danConfig = cd.get_DanConfig();
				if (danConfig == null)
				{
					result = ClientProtocols.E_GAME_DAN_BREAKTHOUGHT_FAILED_LOAD_CONFIG;
					break;
				}
				
				Dan dan = playerNode.getPlayerInfo().getDanData().getDan(guid);
				if (dan == null)
				{
					result = ClientProtocols.E_GAME_DAN_BREAKTHOUGHT_FAILED_DAN_NOT_FOUND;
					break;
				}
				DanConfig.Dan danCfg = danConfig.GetDanById(dan.getResourceId());
				if (danCfg == null)
				{
					result = ClientProtocols.E_GAME_DAN_BREAKTHOUGHT_FAILED_DANCONFIG_ERROR;
					break;
				}
				
				// 是否已达最高突破等级
				if (dan.getBreakthoughtLevel() >= danConfig.get_MaxBreakthought())
				{
					result = ClientProtocols.E_GAME_DAN_BREAKTHOUGHT_FAILED_BREAKTHOUGHT_MAX;
					break;
				}
				
				DanConfig.BreakthoughtInfo breakthoughtInfoCfg = danCfg.GetBreakthoughtInfoByBreakthought(dan.getBreakthoughtLevel());
				if (breakthoughtInfoCfg == null)
				{
					result = ClientProtocols.E_GAME_DAN_BREAKTHOUGHT_FAILED_BREAKTHOUGHT_INFO_ERROR;
					break;
				}
				
				DanConfig.BreakthoughtDetial breakthoughtDetialCfg = breakthoughtInfoCfg.GetBreakthoughtDetialByLevel(dan.getLevel());
				if (breakthoughtDetialCfg == null)
				{
					result = ClientProtocols.E_GAME_DAN_BREAKTHOUGHT_FAILED_BREAKTHOUGHT_DETIAL_ERROR;
					break;
				}
				
				// 未达到升阶所需最低等级
				if (dan.getLevel() < breakthoughtInfoCfg.get_MinLevel())
				{
					result = ClientProtocols.E_GAME_DAN_BREAKTHOUGHT_FAILED_LEVEL_NOT_ENOUGH;
					break;
				}
				
				ArrayList<Cost> costs = new ArrayList<Cost>();
				Cost costNotEnough = new Cost();
				CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
				// 升阶货币消耗
				ClientServerCommon.Cost moneyCost = breakthoughtInfoCfg.get_MoneyCost();
				if (moneyCost == null)
				{
					result = ClientProtocols.E_GAME_DAN_BREAKTHOUGHT_FAILED_MONEY_COST_CONFIG_ERROR;
					break;
				}
				costs.add(new Cost(moneyCost.get_id(), moneyCost.get_count()));
				// 货币是否足够
				if (!CostAndRewardManager.checkCosts(playerNode, costs, cd, KodLogEvent.Dan_Breakthought, costNotEnough))
				{
					crsForClient.setNotEnoughCost(costNotEnough);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_DAN_BREAKTHOUGHT_FAILED_MONEY_COST_NOT_ENOUGH;
					break;
				}
				// 升阶道具消耗
				for (int i = 0; i < breakthoughtInfoCfg.Get_CostsCount(); i++)
				{
					costs.add(new Cost(breakthoughtInfoCfg.Get_CostsByIndex(i).get_id(), breakthoughtInfoCfg.Get_CostsByIndex(i).get_count()));
				}
				// 道具是否足够
				if (!CostAndRewardManager.checkCosts(playerNode, costs, cd, KodLogEvent.Dan_Breakthought, costNotEnough))
				{
					crsForClient.setNotEnoughCost(costNotEnough);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_DAN_BREAKTHOUGHT_FAILED_ITEM_COSTS_NOT_ENOUGH;
					break;
				}
				
				// 随出升阶后的结果数据
				DanConfig.BreakthoughtResult breakthoughtResult = DanUtil.getResultAfterBreakthought(breakthoughtDetialCfg);
				
				// 获得升级后结果数据失败
				if (breakthoughtResult == null)
				{
					result = ClientProtocols.E_GAME_DAN_BREAKTHOUGHT_FAILED_BREAKTHOUGHT_RESULT_ERROR;
					break;
				}
				
				// 升阶前品阶
				int breakthoughtBefore = dan.getBreakthoughtLevel();
				// 升阶前等级
				int levelBefore = dan.getLevel();
				
				// 修改内存
				crsForCost.setCosts(costs);
				CostAndRewardManager.consumeCosts(playerNode, costs, cd, KodLogEvent.Dan_Breakthought, 0, 0);
				crsForClient.megerCostAndRewardAndSync(crsForCost);
				// 修改等级
				dan.setLevel(breakthoughtResult.get_LevelAfter());
				// 修改品质
				dan.setBreakthoughtLevel(breakthoughtResult.get_BreakthoughtAfter());
				// 是否品质提升
				if (breakthoughtBefore < dan.getBreakthoughtLevel())
				{
					// 品质之后,补足属性
					if (!DanUtil.fixDanAttributesCount(dan))
					{
						// 补属性失败
						result = ClientProtocols.E_GAME_DAN_BREAKTHOUGHT_FAILED_FIX_ATTRIBUTE;
						break;
					}
				}
				builder.setDan(dan.toProtoBuffer());
				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
				
				if (levelBefore != dan.getLevel() || breakthoughtBefore!= dan.getBreakthoughtLevel())
				{
					// 修改数据库
					DanInfoDB.updateDanInfo(playerNode);
				}
				
				// 埋点日志
				BPUtil.dantp(playerNode, dan.getResourceId(), breakthoughtBefore, levelBefore, dan.getBreakthoughtLevel(), dan.getLevel());
				//战力
				float power = PowerMgr.calPower(playerNode, cd);
				PlayerAttributeMgr.setPlayerPower(playerNode, (int)power);
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
