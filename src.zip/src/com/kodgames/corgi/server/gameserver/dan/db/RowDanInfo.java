package com.kodgames.corgi.server.gameserver.dan.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;

import com.google.protobuf.InvalidProtocolBufferException;
import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.corgi.server.gameserver.dan.data.DanData;
import com.kodgames.gamedata.dbcommon.DBEasy;
import com.kodgames.gamedata.player.PlayerNode;

public class RowDanInfo
{
	private static final Logger logger = LoggerFactory.getLogger(RowDanInfo.class);

//	// 插入
//	public static boolean insertPrivateList(PlayerNode playerNode)
//	{
//		String sql =
//			String.format("replace into dan_info (player_id,dan_infos) values (%d,%s)",
//				playerNode.getPlayerId(),
//				ServerUtil.toHexString(playerNode.getPlayerInfo().getDanData().toDBProtolBuf().toByteArray()));
//		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerNode.getPlayerId(), sql);
//		return true;
//	}

	// 查询
	public static void selectPrivate(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs,
		PlayerNode playerNode, ConfigDatabase cd)
		throws SQLException
	{
		String sql = "select * from dan_info where player_id=? limit 1";
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, new Object[] {playerNode.getPlayerId()});
		DanData danData = new DanData();
		if (vrs[queryIndex] != null)
		{
			CachedRowSet rs = vrs[queryIndex];
			if (rs.next())
			{
				byte[] danInfo = rs.getBytes("dan_infos");
				if(null != danInfo)
				{
					DBProtocolsForServer.DanInfoDB.Builder builder = DBProtocolsForServer.DanInfoDB.newBuilder();
					try
					{
						builder.mergeFrom(danInfo);
					}
					catch (InvalidProtocolBufferException e1)
					{
						logger.debug(ExceptionUtils.getStackTrace(e1));
					}
					danData.fromDBProtolBuf(builder.build());;
				}
			}
		}
		playerNode.getPlayerInfo().setDanData(danData);
	}
}
