package com.kodgames.corgi.server.gameserver.dan.data;

import java.util.List;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.common.Guid;
import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.corgi.server.gameserver.dan.db.DanInfoDB;
import com.kodgames.gamedata.player.PlayerNode;

public class DanMgr
{
	// 内丹
	public static Dan getDan(Guid guid, PlayerNode playerNode)
	{
		return playerNode.getPlayerInfo().getDanData().getDan(guid);
	}

	// 添加内丹
	public static boolean addDan(PlayerNode playerNode, Dan dan)
	{
		DanData danData = playerNode.getPlayerInfo().getDanData();
		if (danData.addDan(dan))
		{
			DanInfoDB.updateDanInfo(playerNode);
			return true;
		}
		return false;
	}

	// 删除内丹
	public static boolean removeDan(PlayerNode playerNode, Guid guid, ConfigDatabase cd)
	{
		Dan dan = DanMgr.getDan(guid, playerNode);
		if (null == dan)
		{
			return false;
		}

		DanData danData = playerNode.getPlayerInfo().getDanData();
		if (danData.removeDan(guid))
		{
			DanInfoDB.updateDanInfo(playerNode);
			return true;
		}
		return false;
	}
	
	public static DBProtocolsForServer.DanDB getDan(List<DBProtocolsForServer.DanDB> dans, String guid)
	{
		for (DBProtocolsForServer.DanDB dan : dans)
		{
			if (dan.getGuid().equals(guid))
			{
				return dan;
			}
		}

		return null;
	}

}
