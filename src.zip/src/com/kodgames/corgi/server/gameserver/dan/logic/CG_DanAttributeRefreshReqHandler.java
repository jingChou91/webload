package com.kodgames.corgi.server.gameserver.dan.logic;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_DanAttributeRefreshReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_DanAttributeRefreshRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dan.data.Dan;
import com.kodgames.corgi.server.gameserver.dan.data.DanMgr;
import com.kodgames.corgi.server.gameserver.dan.db.DanInfoDB;
import com.kodgames.corgi.server.gameserver.dan.util.DanUtil;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;

public class CG_DanAttributeRefreshReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_DanAttributeRefreshReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_DanAttributeRefreshReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_DanAttributeRefreshReq request = (CG_DanAttributeRefreshReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_DanAttributeRefreshRes.Builder builder = GC_DanAttributeRefreshRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_DAN_ATTRIBUTE_REFRESH_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_DAN_ATTRIBUTE_REFRESH_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();

		String guid = request.getGuid();
		List<Integer> attributeGroupIds = request.getAttributeGroupIdsList();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_DAN_ATTRIBUTE_REFRESH_FAILED_LOAD_PALYER;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.DanHome))
				{
					result = ClientProtocols.E_GAME_DAN_ATTRIBUTE_REFRESH_FAILED_FUNCTION_NOT_OPEN;
					break;
				}
				DanConfig danCfg = cd.get_DanConfig();
				if (danCfg == null)
				{
					result = ClientProtocols.E_GAME_DAN_ATTRIBUTE_REFRESH_FAILED_LOAD_CONFIG;
					break;
				}

				// 验证guid
				Dan dan = DanMgr.getDan(Guid.genNewGuid(guid), playerNode);
				if (dan == null)
				{
					result = ClientProtocols.E_GAME_DAN_ATTRIBUTE_REFRESH_FAILED_DAN_NOT_FOUND;
					break;
				}
				
				// 要洗练的属性id组为空
				if (attributeGroupIds.size() == 0)
				{
					result = ClientProtocols.E_GAME_DAN_ATTRIBUTE_REFRESH_FAILED_IDS_EMPTY;
					break;
				}
				
				HashSet<Integer> refreshedIds = new HashSet<Integer>();
				// 验证danAttributes
				for (Integer id : attributeGroupIds)
				{
					// 要洗练的id不存在
					if (!dan.getAttributes().contains(id))
					{
						result = ClientProtocols.E_GAME_DAN_ATTRIBUTE_REFRESH_FAILED_WRONG_ATTRIBUTEID;
						break;
					}
					
					// 要洗练的id重复
					if (refreshedIds.contains(id))
					{
						result = ClientProtocols.E_GAME_DAN_ATTRIBUTE_REFRESH_FAILED_ID_REPEATED;
						break;
					}
					refreshedIds.add(id);
				}
				
				if (result != ClientProtocols.E_GAME_DAN_ATTRIBUTE_REFRESH_SUCCESS)
				{
					break;
				}
				
				DanConfig.AttributeRefreshCost attributeRefreshCost = danCfg.GetAttributeRefreshCost(dan.getBreakthoughtLevel());
				if (attributeRefreshCost == null)
				{
					result = ClientProtocols.E_GAME_DAN_ATTRIBUTE_REFRESH_FAILED_REFRESHCOST_INFO_ERROR;
					break;
				}

				// 洗练属性条数
				int count = attributeGroupIds.size();
				ArrayList<Cost> costs = new ArrayList<Cost>();
				Cost costNotEnough = new Cost();
				CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
				// 货币消耗
				ClientServerCommon.Cost moneyCost = attributeRefreshCost.get_MoneyCost();
				if (moneyCost == null)
				{
					result = ClientProtocols.E_GAME_DAN_ATTRIBUTE_REFRESH_FAILED_MONEY_COST_CONFIG_ERROR;
					break;
				}
				costs.add(new Cost(moneyCost.get_id(), moneyCost.get_count() * count));
				// 货币是否足够
				if (!CostAndRewardManager.checkCosts(playerNode, costs, cd, KodLogEvent.Dan_AttributeRefresh, costNotEnough))
				{
					crsForClient.setNotEnoughCost(costNotEnough);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_DAN_ATTRIBUTE_REFRESH_FAILED_MONEY_COST_NOT_ENOUGH;
					break;
				}
				// 道具消耗
				for (int i = 0; i < attributeRefreshCost.Get_CostsCount(); i++)
				{
					ClientServerCommon.Cost costCfg = attributeRefreshCost.Get_CostsByIndex(i);
					costs.add(new Cost(costCfg.get_id(), costCfg.get_count() * count));
				}
				// 道具是否足够
				if (!CostAndRewardManager.checkCosts(playerNode, costs, cd, KodLogEvent.Dan_AttributeRefresh, costNotEnough))
				{
					crsForClient.setNotEnoughCost(costNotEnough);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_DAN_ATTRIBUTE_REFRESH_FAILED_ITEM_COSTS_NOT_ENOUGH;
					break;
				}
				
				// 洗练后的属性组
				List<Integer> newAttributeGroupIds = new ArrayList<Integer>();
				for (int id : dan.getAttributes())
				{
					newAttributeGroupIds.add(id);
				}
				
				for (int id : attributeGroupIds)
				{
					// 洗练失败
					if (!DanUtil.refreshDanAttribute(cd, newAttributeGroupIds, id))
					{
						result = ClientProtocols.E_GAME_DAN_ATTRIBUTE_REFRESH_FAILED_RESULT_ERROR;
						break;
					}
				}
				if (result != ClientProtocols.E_GAME_DAN_ATTRIBUTE_REFRESH_SUCCESS)
				{
					break;
				}
				
				// 扣除消耗
				crsForCost.setCosts(costs);
				CostAndRewardManager.consumeCosts(playerNode, costs, cd, KodLogEvent.Dan_AttributeRefresh, 0, 0);
				crsForClient.megerCostAndRewardAndSync(crsForCost);
				// 修改内存
				dan.setAttributes(newAttributeGroupIds);
				// 数据库
				DanInfoDB.updateDanInfo(playerNode);
				// 返回客户端
				builder.setDan(dan.toProtoBuffer());
				
				// 埋点日志
				BPUtil.danxl(playerNode, dan.getResourceId(), dan.getBreakthoughtLevel());
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
