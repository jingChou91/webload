package com.kodgames.corgi.server.gameserver.dan.util;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.common.ValueRandomer;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.dan.data.Dan;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;

public class DanUtil
{
	private static final Logger logger = LoggerFactory.getLogger(DanUtil.class);

	public static boolean isRandomAttributeGroupId(int id)
	{
		return id == 0 || id == -1;
	}

	/**
	 * 根据权重生成升级操作后的等级
	 */
	public static int getLevelAfterLevelUp(DanConfig.LevelInfo levelInfoCfg)
	{
		ValueRandomer random = new ValueRandomer();
		for (int i = 0; i < levelInfoCfg.Get_LevelUpResultsCount(); i++)
		{
			random.addValue(levelInfoCfg.Get_LevelUpResultsByIndex(i).get_Weight(),
				levelInfoCfg.Get_LevelUpResultsByIndex(i).get_ResultLevel());
		}
		random.SetTotalValue();
		Object data = random.RandomData();
		if (data != null)
		{
			return (int)data;
		}

		return -1;
	}

	/**
	 * 根据权重生成升阶后的数据
	 */
	public static DanConfig.BreakthoughtResult getResultAfterBreakthought(
		DanConfig.BreakthoughtDetial breakthoughtDetialCfg)
	{
		ValueRandomer random = new ValueRandomer();
		for (int i = 0; i < breakthoughtDetialCfg.Get_BreakthoughtResultsCount(); i++)
		{
			random.addValue(breakthoughtDetialCfg.Get_BreakthoughtResultsByIndex(i).get_Weight(),
				breakthoughtDetialCfg.Get_BreakthoughtResultsByIndex(i));
		}
		random.SetTotalValue();
		Object data = random.RandomData();
		if (data != null)
		{
			return (DanConfig.BreakthoughtResult)data;
		}

		return null;
	}

	/**
	 * 根据算法id生成属性
	 */
	public static List<Integer> genAttributesByAlgorithmId(int recourseId, int level, int breakthought, int algorithmId)
	{
		logger.debug("__________begin Gen Dan Attribute.......recoureid: " + recourseId + " Level: " + level
			+ " breakthought: " + breakthought + " algorithmId:  " + algorithmId);
		ConfigDatabase cd = ConfigDatabase.get_DefaultCfg();
		List<Integer> attributeIds = new ArrayList<Integer>();
		DanConfig danCfg = cd.get_DanConfig();
		DanConfig.AttributeAlgorithm attributeAlgorithmCfg = danCfg.GetAttributeAlgorithmById(algorithmId);
		if (attributeAlgorithmCfg != null)
		{
			// 属性数量与内丹品质不匹配,打印错误日志,但是继续生成生成内丹
			if (attributeAlgorithmCfg.Get_AlgorithmAttributesCount() != breakthought)
			{
				logger.error("______Gen new Dan Attributes Count Not Match Breakthought__Has atuo Fix.recoureid: "
					+ recourseId + " Level: " + level + " breakthought: " + breakthought + " algorithmId:  "
					+ algorithmId);
			}
			// 属性必须为breakthouhgt个,多余的忽视
			for (int i = 0; i < attributeAlgorithmCfg.Get_AlgorithmAttributesCount()
				&& attributeIds.size() < breakthought; i++)
			{
				ValueRandomer random = new ValueRandomer();
				DanConfig.AlgorithmAttribute algorithmAttribute =
					attributeAlgorithmCfg.Get_AlgorithmAttributesByIndex(i);
				for (int j = 0; j < algorithmAttribute.Get_AttributeGroupWeightsCount(); j++)
				{
					DanConfig.AttributeGroupWeight attributeGroupWeight =
						algorithmAttribute.Get_AttributeGroupWeightsByIndex(j);
					int weight = attributeGroupWeight.get_Weight();
					int attributeGroupId = attributeGroupWeight.get_AttributeGroupId();
					// 权重大于0才有效
					if (weight <= 0)
					{
						continue;
					}
					// 随机属性
					if (DanUtil.isRandomAttributeGroupId(attributeGroupId))
					{
						int randomAttributeGroupId =
							DanUtil.genNewDanRandomAttributeGroup(attributeIds, cd, recourseId, level, breakthought);
						if (randomAttributeGroupId != -1)
						{
							random.addValue(weight, randomAttributeGroupId);
						}
						else
						{
							logger.error("__________________________Gen New Dan Attributes Faild!!!!!!Can not Gen Random AttributeId,recoureseId: "
								+ recourseId
								+ " Level: "
								+ level
								+ " breakthought: "
								+ breakthought
								+ " algorithmId:  " + algorithmId);
						}

					}
					// 非随机属性
					else
					{
						// 满足属性出现限制
						DanConfig.NewDanAttribute newDanAttribute =
							danCfg.GetNewDanAttribute(recourseId, attributeGroupWeight.get_AttributeGroupId());
						if (newDanAttribute != null && newDanAttribute.get_MinBreakthough() <= breakthought)
						{
							if (attributeIds.contains(attributeGroupId))
							{
								// logger.error("__________________________Gen New Dan Attributes Error,Dan already Have this Special AttributeId,recoureseId: "
								// + recourseId
								// + " algorithmId:  "
								// + algorithmId
								// + "  AttributeGroupId  "
								// + attributeGroupId);
							}
							else
							{
								random.addValue(weight, attributeGroupId);
							}

						}
					}

				}
				random.SetTotalValue();
				Object data = random.RandomData();
				if (data != null)
				{
					int resultId = (int)data;
					attributeIds.add(resultId);
				}
				else
				{
					logger.error("__________________________Gen New Dan Attributes error,RandomPool is empty,i=  " + i);
				}
			}
		}
		// 无论什么原因导致内丹属性数量小于品质level,都随机生成属性来补足修正
		int attributeCout = attributeIds.size();
		if (attributeCout < breakthought)
		{
			for (int i = 0; i < breakthought - attributeCout; i++)
			{
				int randomAttributeGroupId =
					DanUtil.genNewDanRandomAttributeGroup(attributeIds, cd, recourseId, level, breakthought);
				if (randomAttributeGroupId != -1)
				{
					attributeIds.add(randomAttributeGroupId);
				}
				else
				{
					// 修正失败,直接返回null
					logger.error("__________________________Gen New Dan Attributes Faild111!!!!!!,recoureseId: "
						+ recourseId + " Level: " + level + " breakthought: " + breakthought + " algorithmId:  "
						+ algorithmId);
				}
			}
		}
		if (attributeIds.size() == breakthought)
		{
			logger.debug("__________ Gen Dan Attribute Success,AttributeIds:"
				+ ServerUtil.listToString(attributeIds, "|"));
			return attributeIds;
		}
		else
		{
			logger.error("__________________________Gen New Dan Attributes Faild222!!!!!!,recoureseId: " + recourseId
				+ "AlgorithmId: " + algorithmId + "AttributeIds.size: " + attributeIds.size());
			return attributeIds;
		}
	}

	/**
	 * 根据算法id生成展示属性
	 */
	public static List<Integer> genShowAttributesByAlgorithmId(int recourseId, int level, int breakthought,
		int algorithmId)
	{
		ConfigDatabase cd = ConfigDatabase.get_DefaultCfg();
		List<Integer> attributeIds = new ArrayList<Integer>();
		DanConfig danCfg = cd.get_DanConfig();
		DanConfig.AttributeAlgorithm attributeAlgorithmCfg = danCfg.GetAttributeAlgorithmById(algorithmId);
		if (attributeAlgorithmCfg != null)
		{
			// 属性数量与内丹品质不匹配,打印错误日志,但是继续生成生成内丹
			if (attributeAlgorithmCfg.Get_AlgorithmAttributesCount() != breakthought)
			{
				logger.error("______Gen Show Dan Attributes Count Not Match Breakthought__Has atuo Fix.recoureid: "
					+ recourseId + " Level: " + level + " breakthought: " + breakthought + " algorithmId:  "
					+ algorithmId);
			}
			// 属性必须为breakthouhgt个,多余的忽视
			for (int i = 0; i < attributeAlgorithmCfg.Get_AlgorithmAttributesCount()
				&& attributeIds.size() < breakthought; i++)
			{
				ValueRandomer random = new ValueRandomer();
				DanConfig.AlgorithmAttribute algorithmAttribute =
					attributeAlgorithmCfg.Get_AlgorithmAttributesByIndex(i);
				boolean hasGen = false;
				for (int j = 0; j < algorithmAttribute.Get_AttributeGroupWeightsCount(); j++)
				{
					//多选一视为随机属性
					if (algorithmAttribute.Get_AttributeGroupWeightsCount() > 1)
					{
						attributeIds.add(-1);
						hasGen = true;
						break;
					}
					DanConfig.AttributeGroupWeight attributeGroupWeight =
						algorithmAttribute.Get_AttributeGroupWeightsByIndex(j);
					int weight = attributeGroupWeight.get_Weight();
					int attributeGroupId = attributeGroupWeight.get_AttributeGroupId();
					// 权重大于0才有效
					if (attributeGroupWeight.get_Weight() <= 0)
					{
						continue;
					}
					// 随机属性
					if (DanUtil.isRandomAttributeGroupId(attributeGroupId))
					{
						attributeIds.add(-1);
						hasGen = true;
						break;
					}
					// 非随机属性
					else
					{
						// 满足属性出现限制
						DanConfig.NewDanAttribute newDanAttribute =
							danCfg.GetNewDanAttribute(recourseId, attributeGroupWeight.get_AttributeGroupId());
						if (newDanAttribute != null && newDanAttribute.get_MinBreakthough() <= breakthought)
						{
							random.addValue(weight, attributeGroupId);
						}
					}

				}
				if (!hasGen)
				{
					random.SetTotalValue();
					Object data = random.RandomData();
					if (data != null)
					{
						int resultId = (int)data;
						attributeIds.add(resultId);
					}
					else
					{
						logger.error("__________________________Gen Show Dan Attributes error,RandomPool is empty....recoureid: "
							+ recourseId
							+ " Level: "
							+ level
							+ " breakthought: "
							+ breakthought
							+ " algorithmId:  "
							+ algorithmId);
					}
				}
			}
		}
		while (attributeIds.size() < breakthought)
		{
			attributeIds.add(-1);
		}
		return attributeIds;

	}

	/**
	 * 根据内丹品质,随机生成并补全内丹不足的属性, return true表示成功,false表示失败
	 */
	public static boolean fixDanAttributesCount(Dan dan)
	{
		ConfigDatabase cd = ConfigDatabase.get_DefaultCfg();
		List<Integer> attributeIds = dan.getAttributes();
		int resourseId = dan.getResourceId();
		int level = dan.getLevel();
		int breakthought = dan.getBreakthoughtLevel();
		for (int i = attributeIds.size(); i < dan.getBreakthoughtLevel(); i++)
		{
			int randomAttributeGroupId =
				DanUtil.genNewDanRandomAttributeGroup(attributeIds, cd, resourseId, level, breakthought);
			if (randomAttributeGroupId != -1)
			{
				attributeIds.add(randomAttributeGroupId);
			}
			else
			{
				logger.error("__________________________Fix Dan Attributes Count Faild!!!!!!Can not Gen Random AttributeId,recoureseId: "
					+ resourseId + " Level: " + level + " breakthought: " + breakthought);
				return false;
			}
		}
		if (attributeIds.size() == breakthought)
		{
			return true;
		}
		return false;
	}

	/**
	 * 根据资源id生成一个随机属性
	 */
	public static int genNewDanRandomAttributeGroup(List<Integer> attributeIds, ConfigDatabase cd, int recourseId,
		int level, int breakthought)
	{
		ValueRandomer random = new ValueRandomer();
		DanConfig danCfg = cd.get_DanConfig();
		for (int i = 0; i < danCfg.Get_NewDanAttributeInfosCount(); i++)
		{
			DanConfig.NewDanAttributeInfo newDanAttributeInfo = danCfg.Get_NewDanAttributeInfosByIndex(i);
			// 指定resourceId的内丹
			if (newDanAttributeInfo.get_ResourseId() == recourseId)
			{
				// 每个属性
				for (int j = 0; j < newDanAttributeInfo.Get_NewDanAttributesCount(); j++)
				{
					DanConfig.NewDanAttribute newDanAttribute = newDanAttributeInfo.Get_NewDanAttributesByIndex(j);
					// 满足出现限制条件
					if (newDanAttribute.get_MinBreakthough() <= breakthought)
					{
						// 该内丹目前无该属性
						if (!attributeIds.contains(newDanAttribute.get_AttributeGroupId()))
						{
							random.addValue(newDanAttribute.get_Weight(), newDanAttribute.get_AttributeGroupId());
						}
					}
				}
			}
		}
		random.SetTotalValue();
		Object data = random.RandomData();
		if (data != null)
		{
			return (int)data;
		}
		return -1;
	}

	/**
	 * 获取指定内丹的所有属性配置
	 */
	public static List<CommonProtocols.DanAttributeGroup> getDanAttributeGroupProList(ConfigDatabase cd,
		int resourseId, List<Integer> attributeGroupIds)
	{
		List<CommonProtocols.DanAttributeGroup> danAttributeGroupList =
			new ArrayList<CommonProtocols.DanAttributeGroup>();
		for (int attributeGroupId : attributeGroupIds)
		{
			if (attributeGroupId == -1)
			{
				continue;
			}
			CommonProtocols.DanAttributeGroup danAttributeGroup =
				DanUtil.getDanAttributeGroupPro(cd, resourseId, attributeGroupId);
			if (danAttributeGroup != null)
			{
				danAttributeGroupList.add(danAttributeGroup);
			}
		}
		return danAttributeGroupList;
	}

	/**
	 * 根据属性组id获取相关配置信息
	 */
	public static CommonProtocols.DanAttributeGroup getDanAttributeGroupPro(ConfigDatabase cd, int resourseId,
		int attributeGroupId)
	{
		CommonProtocols.DanAttributeGroup.Builder danAttributeGroupBuilder =
			CommonProtocols.DanAttributeGroup.newBuilder();

		DanConfig danCfg = cd.get_DanConfig();
		DanConfig.DanAttributeGroup danAttributeGroupCfg = danCfg.GetDanAttributeGroup(attributeGroupId);
		if (danAttributeGroupCfg == null)
		{
			logger.error("__________________Bad DanAttributeGroupId: " + attributeGroupId);
			return null;
		}
		danAttributeGroupBuilder.setId(danAttributeGroupCfg.get_Id());
		danAttributeGroupBuilder.setAttributeDesc(danAttributeGroupCfg.get_AttributeDesc());
		for (int i = 0; i < danAttributeGroupCfg.Get_AttributeIdsCount(); i++)
		{
			int attributeId = danAttributeGroupCfg.Get_AttributeIdsByIndex(i);
			DanConfig.DanAttribute danAttribute = danCfg.GetDanAttributeById(attributeId);
			if (danAttribute == null)
			{
				logger.error("__________________Bad Dan AttributeId: " + attributeId);
				return null;
			}
			CommonProtocols.DanAttribute.Builder danAttributeBuilder = CommonProtocols.DanAttribute.newBuilder();
			danAttributeBuilder.setId(danAttribute.get_Id());
			danAttributeBuilder.setFuncType(danAttribute.get_FuncType());
			for (int j = 0; j < danAttribute.Get_FuncParamsCount(); j++)
			{
				danAttributeBuilder.addFuncParams(danAttribute.Get_FuncParamsByIndex(j));
			}
			for (int j = 0; j < danAttribute.Get_ModifierSetsCount(); j++)
			{
				ClientServerCommon.PropertyModifierSet modifierSetCfg = danAttribute.Get_ModifierSetsByIndex(j);
				CommonProtocols.PropertyModifierSet.Builder modifierSetBuilder =
					CommonProtocols.PropertyModifierSet.newBuilder();
				modifierSetBuilder.setLevelFilter(modifierSetCfg.get_levelFilter());
				for (int k = 0; k < modifierSetCfg.Get_modifiersCount(); k++)
				{
					ClientServerCommon.PropertyModifier modifierCfg = modifierSetCfg.Get_modifiersByIndex(k);
					CommonProtocols.PropertyModifier.Builder modifierBuilder =
						CommonProtocols.PropertyModifier.newBuilder();
					modifierBuilder.setType(modifierCfg.get_type());
					modifierBuilder.setModifyType(modifierCfg.get_modifyType());
					modifierBuilder.setAttributeType(modifierCfg.get_attributeType());
					modifierBuilder.setAttributeValue(modifierCfg.get_attributeValue());
					modifierSetBuilder.addModifiers(modifierBuilder.build());
				}
				danAttributeBuilder.addPropertyModifierSets(modifierSetBuilder.build());
			}
			for (int j = 0; j < danAttribute.Get_TargetConditionsCount(); j++)
			{
				ClientServerCommon.TargetCondition targetConditionCfg = danAttribute.Get_TargetConditionsByIndex(j);
				if (targetConditionCfg.get_type() == ClientServerCommon.TargetCondition._Type.AvatarId)
				{
					CommonProtocols.TargetCondition.Builder targetConditionBuilder =
						CommonProtocols.TargetCondition.newBuilder();
					targetConditionBuilder.setType(targetConditionCfg.get_type());
					targetConditionBuilder.setIntValue(targetConditionCfg.get_intValue());
					danAttributeBuilder.addTargetConditions(targetConditionBuilder.build());
				}

			}
			danAttributeGroupBuilder.addDanAttributes(danAttributeBuilder.build());
		}
		return danAttributeGroupBuilder.build();
	}

	/**
	 * 洗练指定的一个属性
	 */
	public static boolean refreshDanAttribute(ConfigDatabase cd, List<Integer> attributeGroupIds, int refreshedId)
	{
		// 根据权重生成洗练信息
		DanConfig.AttributeRefresh attributeRefreshCfg = DanUtil.genAttributeRefresh(cd);
		if (attributeRefreshCfg == null)
		{
			return false;
		}
		int newId = DanUtil.genAttributeGroupIdByAttributeRefreshInfo(attributeRefreshCfg, attributeGroupIds);
		if (newId == -1)
		{
			return false;
		}

		// 被洗练的属性id所处位置
		int index = attributeGroupIds.indexOf(refreshedId);
		// 删除原属性id
		attributeGroupIds.remove(index);
		// 在原位置插入洗练后的属性id
		attributeGroupIds.add(index, newId);

		return true;
	}

	/**
	 * 根据优先级策略,生成一个洗练结果类别
	 */
	public static DanConfig.AttributeRefresh genAttributeRefresh(ConfigDatabase cd)
	{
		DanConfig dancfg = cd.get_DanConfig();
		DanConfig.RefreshWeightInfo refreshWeightInfoCfg = null;
		int type1 = 0;
		int type2 = 0;
		// 类型1
		ValueRandomer random1 = new ValueRandomer();
		for (int i = 0; i < dancfg.Get_RefreshWeightInfosCount(); i++)
		{
			DanConfig.RefreshWeightInfo tmpRefreshWeightInfoCfg = dancfg.Get_RefreshWeightInfosByIndex(i);
			int weight = tmpRefreshWeightInfoCfg.get_AttributeRefreshWeight1().get_Weight();
			if (weight > 0)
			{
				random1.addValue(weight, tmpRefreshWeightInfoCfg);
			}
		}
		random1.SetTotalValue();
		Object data1 = random1.RandomData();
		if (data1 != null)
		{
			refreshWeightInfoCfg = (DanConfig.RefreshWeightInfo)data1;
			type1 = refreshWeightInfoCfg.get_AttributeRefreshWeight1().get_Num();
		}
		else
		{
			return null;
		}
		// 类型2
		ValueRandomer random2 = new ValueRandomer();
		for (int i = 0; i < refreshWeightInfoCfg.Get_AttributeRefreshWeight2Count(); i++)
		{
			DanConfig.WeightNum weightNumCfg = refreshWeightInfoCfg.Get_AttributeRefreshWeight2ByIndex(i);
			int weight = weightNumCfg.get_Weight();
			if (weight > 0)
			{
				random2.addValue(weight, weightNumCfg.get_Num());
			}
		}
		random2.SetTotalValue();
		Object data2 = random2.RandomData();
		if (data2 != null)
		{
			type2 = (int)data2;
		}
		else
		{
			return null;
		}
		// 结果
		return cd.get_DanConfig().GetAttributeRefreshByTypes(type1, type2);
	}

	/**
	 * 根据洗练结果类别下个结果的权重生成一个属性组id
	 */
	public static int genAttributeGroupIdByAttributeRefreshInfo(DanConfig.AttributeRefresh attributeRefreshCfg,
		List<Integer> attributeGroupIds)
	{
		ValueRandomer random = new ValueRandomer();
		for (int i = 0; i < attributeRefreshCfg.Get_AttributeGroupWeightsCount(); i++)
		{
			DanConfig.AttributeGroupWeight attributeGroupWeightCfg =
				attributeRefreshCfg.Get_AttributeGroupWeightsByIndex(i);
			int weight = attributeGroupWeightCfg.get_Weight();
			int attributeGroupId = attributeGroupWeightCfg.get_AttributeGroupId();
			if (weight > 0 && !attributeGroupIds.contains(attributeGroupId))
			{
				random.addValue(weight, attributeGroupId);
			}
		}
		random.SetTotalValue();
		Object data = random.RandomData();
		if (data != null)
		{
			return (int)data;
		}
		return -1;
	}

}
