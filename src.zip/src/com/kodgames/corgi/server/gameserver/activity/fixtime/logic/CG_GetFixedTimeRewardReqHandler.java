package com.kodgames.corgi.server.gameserver.activity.fixtime.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._ActivityType;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityMgr;
import com.kodgames.corgi.server.gameserver.activity.fixtime.ActivityHandleFixtimeManager;
import com.kodgames.corgi.server.gameserver.activity.fixtime.data.PlayerFixedTimeActivityData;
import com.kodgames.corgi.server.gameserver.activity.fixtime.data.PlayerFixedTimeActivityManager;
import com.kodgames.corgi.server.gameserver.quest.data.QuestEventFactory;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class CG_GetFixedTimeRewardReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_GetFixedTimeRewardReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_GetFixedTimeActivityRewardReqHandler, playerId = {}", sender.getClientUID().getPlayerID());
		GameProtocolsForClient.CG_GetFixedTimeActivityRewardReq request =
			(GameProtocolsForClient.CG_GetFixedTimeActivityRewardReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GameProtocolsForClient.GC_GetFixedTimeActivityRewardRes.Builder builder =
			GameProtocolsForClient.GC_GetFixedTimeActivityRewardRes.newBuilder();

		int result = ClientProtocols.E_GAME_GET_FIXEDTIME_ACTIVITY_REWARD_SUCCESS;
		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();

		ClientServerCommon.ActivityConfig.FixedTimeActivity fixedTimeActivity =
			cd.get_ActivityConfig().get_fixedTimeActivity();

		int activityId = fixedTimeActivity.get_activity().get_activityId();
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);			
				if (playerNode == null)
				{
					result = ClientProtocols.E_GAME_GET_FIXEDTIME_ACTIVITY_REWARD_FAILED_LOAD_PLAYER;
					break;
				}
				if(!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.FixedTimeActivity))
				{
					result = ClientProtocols.E_GAME_GET_FIXEDTIME_ACTIVITY_REWARD_FAILED_LEVEL_WRONG;
					break;
				}

				if (!ActivityMgr.getInstance().checkIsStart(_ActivityType.GETFIXTEDTIMEACTIVITY, activityId, playerNode))
				{
					// 活动尚未开启
					result = ClientProtocols.E_GAME_GET_FIXEDTIME_ACTIVITY_REWARD_FAILED_WRONG;
					break;
				}
				
				PlayerFixedTimeActivityData fixedTimeActivityInfo = playerNode.getPlayerInfo().getPlayerFixedTimeActivityData();

				long lastGetTime = fixedTimeActivityInfo.getLastGetTime();
				if (lastGetTime > ActivityHandleFixtimeManager.noticeTime)
				{
					result = ClientProtocols.E_GAME_ACTIVITY_TIME_TAKEN_PART_IN;
					break;
				}

				// 计算奖励
				// 不需要数量控制,不需要概率控制
				Reward reward = new Reward();
				for (int i = 0; i < fixedTimeActivity.Get_rewardCount(); i++)
				{
					Reward rewardTemp = new Reward();
					rewardTemp = rewardTemp.fromClientServerCommon(fixedTimeActivity.Get_rewardByIndex(i));
					reward.megerReward(rewardTemp);
				}
				CostAndRewardAndSync crsHere = new CostAndRewardAndSync();
				CostAndRewardManager.addReward(playerNode, reward, cd, KodLogEvent.GetFixTime);
				long now = System.currentTimeMillis();
				PlayerFixedTimeActivityManager.updateFixedTimeActivityInfo(playerNode, now);
				crsHere.mergeReward(reward);
				crsForClient.megerCostAndRewardAndSync(crsHere);

				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
				fixedTimeActivityInfo = playerNode.getPlayerInfo().getPlayerFixedTimeActivityData();
				builder.setLastGetTime(now);

				// 助手
				playerNode.getPlayerInfo().getAssisantData().getFixTime().notifyObservers();

				BPUtil.activity(playerNode, activityId);

				// 客栈休息每日任务
				QuestEventFactory.createDoActivityEvent(playerNode, activityId, cd);
				
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setCallback(request.getCallback());
		builder.setResult(result);

		ServerDataGS.transmitter.sendToClient(sender,
			ClientProtocols.P_GAME_GC_GET_FIXEDTIME_ACTIVITY_REWARD_RES,
			builder.build());

		return HandlerAction.TERMINAL;
	}
}
