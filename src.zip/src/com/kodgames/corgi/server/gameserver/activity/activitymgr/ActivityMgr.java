package com.kodgames.corgi.server.gameserver.activity.activitymgr;

import java.util.ArrayList;
import java.util.List;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._ActivityType;
import ClientServerCommon._TimeDurationType;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.gameconfiguration.KodThreadName;
import com.kodgames.corgi.protocol.CommonProtocols.ActivityTimer;
import com.kodgames.corgi.server.gameserver.activity.data.ActivityData;
import com.kodgames.corgi.server.gameserver.activity.data.ActivityInfo;
import com.kodgames.corgi.server.gameserver.activity.fixtime.ActivityHandleFixtimeManager;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.ActivityHandleOperationActivityManager;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.data.OperationActivityMgr;
import com.kodgames.corgi.server.gameserver.danhome.Logic_Alchemy;
import com.kodgames.corgi.server.gameserver.danhome.Logic_Decompose;
import com.kodgames.corgi.server.gameserver.danhome.util.Alchemy.AlchemyActivityUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Decompose.DecomposeActivityUtil;
import com.kodgames.corgi.server.gameserver.dungeon.ActivityHandleSecretManager;
import com.kodgames.corgi.server.gameserver.firstthree.Logic_FirstThreeDay;
import com.kodgames.corgi.server.gameserver.guild.Logic_GuildPlayerExchangeShop;
import com.kodgames.corgi.server.gameserver.guildstage.Logic_GuildStageActivity;
import com.kodgames.corgi.server.gameserver.levelreward.ActivityHandleLevelRewardManager;
import com.kodgames.corgi.server.gameserver.mysteryer.ActivityHandleMystryerManager;
import com.kodgames.corgi.server.gameserver.sevenelevengifts.Logic_SevenElevenGifts;
import com.kodgames.corgi.server.gameserver.tavern.Logic_TavernNormalActivity;
import com.kodgames.corgi.server.gameserver.tavern.Logic_TavernTenActivity;
import com.kodgames.corgi.server.gameserver.zentia.Logic_Zentia;
import com.kodgames.corgi.server.gameserver.zentia.data.ZentiaMgr;
import com.kodgames.corgi.server.timer.TimerMgr;
import com.kodgames.gamedata.player.PlayerNode;

public class ActivityMgr
{
	private static ActivityMgr activityMgr = null;
	private ActivityEnviroment activityEnv = null;

	private ActivityHandleFixtimeManager activityHandleFixtimeManager = null;
	private ActivityHandleSecretManager activityHandleSecretManager = null;
	private ActivityHandleOperationActivityManager activityHandleOperationActivityManager = null;
	private ActivityHandleLevelRewardManager levelRewardManager = null;
	private ActivityHandleMystryerManager activityHandleMystryerManager = null;
	private Logic_Zentia logic_Zentia = null;
	private Logic_Alchemy logic_Alchemy = null;
	private Logic_Decompose logic_Decompose = null;
	private Logic_GuildPlayerExchangeShop logic_GuildPlayerExchangeShop = null;
	private Logic_GuildStageActivity logic_GuildStageActivity = null;
	private Logic_FirstThreeDay logic_FirstThreeDay = null;
	private ActivityNotifyRunnable notifyRunnable = null;
	private Logic_SevenElevenGifts logic_SevenElevenGifts = null;
	private Logic_TavernNormalActivity logic_TavernNormalActivity = null;
	private Logic_TavernTenActivity logic_TavernTenActivity = null;

	public static ActivityMgr getInstance()
	{
		if (null == activityMgr)
		{
			activityMgr = new ActivityMgr();
		}

		return activityMgr;
	}

	public synchronized void refreshConfig(ConfigDatabase cd)
	{
		activityHandleFixtimeManager.handleConfigRefresh(cd, activityEnv);
		activityHandleSecretManager.handleConfigRefresh(cd, activityEnv);
		activityHandleOperationActivityManager.handleConfigRefresh(cd, activityEnv);
		activityHandleMystryerManager.handleConfigRefresh(cd, activityEnv);
		logic_Zentia.handleConfigRefresh(cd, activityEnv);
		logic_Alchemy.handleConfigRefresh(cd, activityEnv);
		logic_Decompose.handleConfigRefresh(cd, activityEnv);
		logic_GuildPlayerExchangeShop.handleConfigRefresh(cd, activityEnv);
		logic_GuildStageActivity.handleConfigRefresh(cd, activityEnv);
		logic_FirstThreeDay.handleConfigRefresh(cd, activityEnv);
		logic_TavernNormalActivity.handleConfigRefresh(cd, activityEnv);
		logic_TavernTenActivity.handleConfigRefresh(cd, activityEnv);
        logic_SevenElevenGifts.handleConfigRefresh(cd, activityEnv);
	}

	public boolean init(Controller controller)
	{
		activityHandleFixtimeManager = new ActivityHandleFixtimeManager();
		activityHandleSecretManager = new ActivityHandleSecretManager();
		activityHandleOperationActivityManager = new ActivityHandleOperationActivityManager();
		levelRewardManager = new ActivityHandleLevelRewardManager();
		activityHandleMystryerManager = new ActivityHandleMystryerManager();
		logic_SevenElevenGifts = new Logic_SevenElevenGifts();
		logic_FirstThreeDay = new Logic_FirstThreeDay();
		logic_TavernNormalActivity = new Logic_TavernNormalActivity();
		logic_TavernTenActivity = new Logic_TavernTenActivity();		
		logic_Zentia = new Logic_Zentia();
		logic_Alchemy = new Logic_Alchemy();
		logic_Decompose = new Logic_Decompose();
		logic_GuildStageActivity = new Logic_GuildStageActivity();
		logic_GuildPlayerExchangeShop = new Logic_GuildPlayerExchangeShop();

		activityHandleFixtimeManager.init(controller);
		activityHandleSecretManager.init(controller);
		activityHandleOperationActivityManager.init(controller);
		levelRewardManager.init(controller);
		activityHandleMystryerManager.init(controller);
		logic_SevenElevenGifts.init(controller);		
		AlchemyActivityUtil.getInstance().setLogic(logic_Alchemy);
		DecomposeActivityUtil.getInstance().setLogic(logic_Decompose);
		ZentiaMgr.getInstance().setActivityHandle(logic_Zentia);
		logic_Zentia.init(controller);
		logic_Alchemy.init(controller);
		logic_Decompose.init(controller);

		notifyRunnable = new ActivityNotifyRunnable();

		OperationActivityMgr.getInstance().setActivityHandle(activityHandleOperationActivityManager);
		return true;
	}

	public void addToActivityNotify(ActivityData activityData, int playerId)
	{
		notifyRunnable.addData(activityData, playerId);
	}

	public void informQueryInitInfoFinished(int playerId)
	{
		notifyRunnable.informSend(playerId);
	}

	public boolean start()
	{
		activityEnv = new ActivityEnviroment();
		activityHandleFixtimeManager.start(activityEnv);
		activityHandleSecretManager.start(activityEnv);
		activityHandleOperationActivityManager.start(activityEnv);
		levelRewardManager.start(activityEnv);
		activityHandleMystryerManager.start(activityEnv);

		logic_SevenElevenGifts.start(activityEnv);
		logic_FirstThreeDay.start(activityEnv);
		logic_TavernNormalActivity.start(activityEnv);
		logic_TavernTenActivity.start(activityEnv);		
		logic_Zentia.start(activityEnv);
		logic_Alchemy.start(activityEnv);
		logic_Decompose.start(activityEnv);
		logic_GuildPlayerExchangeShop.start(activityEnv);
		logic_GuildStageActivity.start(activityEnv);
		

		Thread thread = new Thread(notifyRunnable, KodThreadName.genName("ActivityNotifyThread"));
		thread.start();

		// 检查是否有注册时需要触发的通知
		activityEnv.checkRegisterInform();

		TimerMgr.getTimerMgr().start();
		return true;
	}

	public void release()
	{

	}

	public ActivityEnviroment getActivityEnv()
	{
		return activityEnv;
	}

	public boolean checkIsStart(int activityType, int activityId, PlayerNode playerNode)
	{
		if (_ActivityType.GETFIXTEDTIMEACTIVITY == activityType)
		{
			return activityHandleFixtimeManager.isActivityActivate(activityId, playerNode);
		}
		if (_ActivityType.SECRETACTIVIYT == activityType)
		{
			return activityHandleSecretManager.isActivityActivate(activityId, playerNode);
		}
		if (_ActivityType.FIRSTTHREEDAY == activityType)
		{
			return logic_FirstThreeDay.isActivityActivate(activityId, playerNode);
		}
		if (_ActivityType.SEVENELEVENGIFT == activityType)
		{
			return logic_SevenElevenGifts.isActivityActivate(activityId, playerNode);
		}
		if (_ActivityType.NORMALTAVERNACTIVITY == activityType)
		{
			return logic_TavernNormalActivity.isActivityActivate(activityId, playerNode);
		}
		if (_ActivityType.TENTAVERNACTIVITY == activityType)
		{
			return logic_TavernTenActivity.isActivityActivate(activityId, playerNode);
		}
		return false;
	}
	
	public ArrayList<com.kodgames.corgi.protocol.CommonProtocols.ActivityData> getAllActivityData(PlayerNode playerNode, ConfigDatabase cd)
	{
		ArrayList<com.kodgames.corgi.protocol.CommonProtocols.ActivityData> activityDatas = new ArrayList<com.kodgames.corgi.protocol.CommonProtocols.ActivityData>();

		activityHandleFixtimeManager.getActivityData(activityDatas, playerNode);
		activityHandleSecretManager.getActivityData(activityDatas, playerNode); // 需要测试秘境活动已结束时，是否填充了数据
		activityHandleOperationActivityManager.getActivityData(activityDatas, playerNode);
		activityHandleMystryerManager.getActivityData(activityDatas, playerNode);
		logic_SevenElevenGifts.getActivityData(activityDatas, playerNode);		
		logic_Zentia.getActivityData(activityDatas, playerNode);
		logic_Alchemy.getActivityData(activityDatas, playerNode);
		logic_Decompose.getActivityData(activityDatas, playerNode);

		logic_GuildPlayerExchangeShop.getActivityData(activityDatas, playerNode);
		logic_GuildStageActivity.getActivityData(activityDatas, playerNode);
		//不包含等级礼包信息
		
		// 不包含等级礼包信息
		int acitivytLevelReward = cd.get_LevelRewardConfig().get_activityId();
		ActivityData activityData = new ActivityData(_ActivityType.LEVLEREWARDACTIVITY, acitivytLevelReward);
		List<ActivityTimer> timerList = new ArrayList<ActivityTimer>();
		ActivityInfo activityInfo = new ActivityInfo(_TimeDurationType.Unknown, 0, 0, timerList, false);
		activityData.addActivityInfo(activityInfo);
		activityDatas.add(activityData.toBuffer());

		return activityDatas;
	}
}
