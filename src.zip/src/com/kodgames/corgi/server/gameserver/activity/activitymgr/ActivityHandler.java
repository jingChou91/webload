package com.kodgames.corgi.server.gameserver.activity.activitymgr;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ActivityConfig;
import ClientServerCommon.ActivityConfig.Activity;
import ClientServerCommon.ActivityConfig.ActivityCondition;
import ClientServerCommon.ActivityConfig.ActivitySpecialTime;
import ClientServerCommon._ActivityTimerStatus;
import ClientServerCommon._ActivityType;
import ClientServerCommon._Isvalid;
import ClientServerCommon._TimeDurationType;

import com.kodgames.corgi.gameconfiguration.AreaData;
import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.protocol.CommonProtocols.ActivityTimer;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.activity.data.ActivityData;
import com.kodgames.corgi.server.gameserver.activity.data.ActivityInfo;
import com.kodgames.corgi.server.gameserver.activity.data.ActivityTimerStatus;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.xml.xmlConfig;

/*
 * 活动的处理对象接口
 * 
 * @note 还不支持相对账号时间的活动
 */
public abstract class ActivityHandler
{
	//当前活动的本地存储信息
	protected ConcurrentHashMap<Integer, ActivityElement> elementMaps = new ConcurrentHashMap<Integer, ActivityElement>();		//activityID--Element
	
	private static final Logger logger = LoggerFactory.getLogger(ActivityHandler.class);
	private static final String MAX_DATE = "2020-12-31 23:59:59";
	
	private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	private static final int ACTIVITY_SPECIALTIME_SAME = 0;
	private static final int ACTIVITY_SPECIALTIME_ADD = 1;
	private static final int ACTIVITY_SPECIALTIME_DEL = 2;
	
	protected ConcurrentHashMap<Integer, ActivitySpecialTimeInfo> todayTimerList = new ConcurrentHashMap<Integer, ActivitySpecialTimeInfo>();
	
	protected int type;	//活动类型
	public ActivityHandler(int type)
	{
		this.type = type;
	}

	public List<ActivityTimer> getClientTodayTimeList(int activityId)
	{		
		ActivitySpecialTimeInfo todayTimer = todayTimerList.get(activityId);
		if (todayTimer == null)
		{
			return null;
		}
		
		List<ActivityTimer> list = new ArrayList<ActivityTimer>();
		Iterator<ActivityTimerStatus> iterator = todayTimer.getTimerList().iterator();
		ActivityTimerStatus activityTimerStatus = null;
		while(iterator.hasNext())
		{
			activityTimerStatus = iterator.next();
			if ((activityTimerStatus.getTimerStatus() & _ActivityTimerStatus.Client) == 0)
			{
				continue;
			}
			
			list.add(activityTimerStatus.toProtobuf());
		}
		
		if (logger.isTraceEnabled())
		{
			String strOut = String.format("getClientTodayTimeList id %x timerCount %d ###### ", activityId, list.size());
		
			for (ActivityTimer timer : list)
			{
				String tmp = String.format("%s--%s, ", dateFormat.format(timer.getTimer()), timer.getStatus());
				strOut += tmp;
			}
			logger.trace(strOut);
		}
		
		return list;
	}
	
	private ConcurrentHashMap<Integer, ActivitySpecialTimeInfo> nextTimerList = new ConcurrentHashMap<Integer, ActivitySpecialTimeInfo>();
	public List<ActivityTimer> getClientNextTimeList(int activityId)
	{
		ActivitySpecialTimeInfo nextTimer = nextTimerList.get(activityId);
		if (nextTimer == null)
		{
			return null;
		}
		
		List<ActivityTimer> list = new ArrayList<ActivityTimer>();
		Iterator<ActivityTimerStatus> iterator = nextTimer.getTimerList().iterator();
		ActivityTimerStatus activityTimerStatus = null;
		while(iterator.hasNext())
		{
			activityTimerStatus = iterator.next();
			if ((activityTimerStatus.getTimerStatus() & _ActivityTimerStatus.Client) == 0)
			{
				continue;
			}

			list.add(activityTimerStatus.toProtobuf());
		}
		
		if (logger.isTraceEnabled())
		{
			String strOut = String.format("getClientNextTimeList id %x timerCount %d ###### ", activityId, list.size());
		
			for (ActivityTimer timer : list)
			{
				String tmp = String.format("%s--%s, ", dateFormat.format(timer.getTimer()), timer.getStatus());
				strOut += tmp;
			}
			logger.trace(strOut);
		}
		
		return list;
	}
	/*
	 * 模块启动的逻辑处理
	 * 模块启动后，首先从活动管理器读取上一次的异常活动数据@ActivityEnviroment.getLastAbortActivity
	 * 模块根据自身逻辑和异常活动信息判断异常活动是否继续或者进行结算等动作，
	 * 如果需要继续，则将异常活动的剩余时间点作为一次性的活动，注册给活动管理器
	 * 异常活动处理完成后，读取活动配置，计算出下一周期的时间点，并将活动注册到活动管理器@ActivityEnviroment.registerActivity
	 */
	public abstract boolean start(ActivityEnviroment activityEnv);
	
	/*
	 * 通知逻辑模块定时器到
	 * @param activityID 活动id
	 * @param openTime   该时间段的开启时间
	 * @param closeTime  该时间段的结束时间
	 * @param specialIndex 该活动的多个时间段的触发序号
	 * @param timerStatus 该节点的状态值
	 * @param timerIndex 该节点的序号
	 * @param playerId 玩家id，针对玩家的活动处理时需要填充
	 * @param startOnce 是否为启动时的通知处理，启动的通知处理不需要处理当前周期和下一周期数据，只用于逻辑模块初始化数据
	 */
	public boolean handleActivity(int activityID, long openTime, long closeTime, int specialIndex, int timerStatus, int timerIndex, int playerId, boolean startOnce)
	{
		logger.debug("handleActivity id {} open {} close {} index {} status {} player {} startOnce {}",
			activityID, openTime, closeTime, timerIndex, timerStatus, playerId, startOnce);
		if (startOnce)
		{
			return true;
		}
		ActivityElement element = elementMaps.get(activityID);
		if (element == null)
		{
			logger.warn("handleActivity can't find LocalInfo from elementMaps unexpected");
			return false;
		}

		ActivitySpecialTimeInfo timeInfo = element.getSpecialTimeByTime(openTime+1);
		if (timeInfo == null)
		{
			logger.warn("handleActivity can't find LocalSpecialTime from elementMaps unexpected");
			return false;
		}
		
		//周期性活动在周期开始点，重新保存Today数据
		if ((timerStatus & _ActivityTimerStatus.DurationStart) > 0)
		{
			ActivitySpecialTimeInfo todayInfo = new ActivitySpecialTimeInfo(timeInfo);
			todayTimerList.put(element.getActivityID(), todayInfo);
			
			if (logger.isTraceEnabled())
			{
				String strOut = String.format("handleActivity refresh todayTimerList id %x timerCount %d ###### ", element.getActivityID(), timeInfo.getTimerList().size());
			
				for (ActivityTimerStatus timer : timeInfo.getTimerList())
				{
					String tmp = String.format("%s--%s, ", dateFormat.format(timer.getTimer()), timer.getTimerStatus());
					strOut += tmp;
				}
				logger.trace(strOut);
			}
		}
		
		//下一周期的通知点会通知给客户端下一周期的数据
		if ((timerStatus & _ActivityTimerStatus.InformNext) > 0)
		{
			handleInformNextRound(activityID, openTime, closeTime, specialIndex, playerId);
		}
		
		return true;
	}
	
	public void registerActivity(ActivityEnviroment activityEnv, ActivityConfig.Activity activity)
	{
		if (activity.get_isValid() != _Isvalid.Open)
		{
			logger.debug("registerActivity activity {} is not open", activity.get_activityId());
			return;
		}
		int lowLevel = parseActivityLevelMin(activity.get_condition());
		int upLevel = parseActivityLevelMax(activity.get_condition());
		
		ActivityElement element = new ActivityElement(type, activity.get_name(), -1, activity.get_activityId(), lowLevel, upLevel);
		
		int count = activity.Get_specialTimesCount();
		logger.debug("registerActivity id {} name {} specialTimeCount {}", activity.get_activityId(), activity.get_name(), count);
		for (int i = 0; i < count; i++)
		{
			ActivitySpecialTime specialTime = activity.Get_specialTimesByIndex(i);
			long openTime = parseOpenTime(specialTime);
			long endTime = parseCloseTime(specialTime);

			ActivitySpecialTimeInfo specialTimeInfo = new ActivitySpecialTimeInfo(specialTime.get_index(), specialTime.get_timeDurationType(),
				openTime, endTime, specialTime.get_resetType(), specialTime.get_resetCount(), calcTimeListFromTimeCell(specialTime));
			
			element.addSpecialTime(specialTimeInfo);
		}
	
		registerActivityElement(activityEnv, element);
		
		elementMaps.put(activity.get_activityId(), element);
	}
	
	protected ConcurrentLinkedDeque<ActivityTimerStatus> calcTimeListFromTimeCell(ActivitySpecialTime specialTime)
	{
		ConcurrentLinkedDeque<ActivityTimerStatus> timerList = new ConcurrentLinkedDeque<ActivityTimerStatus>();
		ActivityTimerStatus activityTimerStatus = null;
		for(int j = 0; j < specialTime.Get_timeCellsCount(); j++)
		{
			ActivityConfig.TimeCell timeCell = specialTime.Get_timeCellsByIndex(j);
			
			long noZone_ConfigTime = ClientServerCommon.ConvertTicksToMs.DateTimeToInt64(timeCell.GetStartDateTime());// 0区的10:15 读出8区的 18:15 的 ticks的 long
			long cfgTime_withZone = ServerUtil.getLongForJava(noZone_ConfigTime, TimeZoneData.getTimeZone());// 8区的10:15的long
			activityTimerStatus = new ActivityTimerStatus(cfgTime_withZone, _ActivityTimerStatus.Client | _ActivityTimerStatus.Server | _ActivityTimerStatus.Start);
			timerList.add(activityTimerStatus);
			
			noZone_ConfigTime = ClientServerCommon.ConvertTicksToMs.DateTimeToInt64(timeCell.GetEndDateTime());// 0区的10:15 读出8区的 18:15 的 ticks的 long
			cfgTime_withZone = ServerUtil.getLongForJava(noZone_ConfigTime, TimeZoneData.getTimeZone());// 8区的10:15的long
			activityTimerStatus = new ActivityTimerStatus(cfgTime_withZone, _ActivityTimerStatus.Client | _ActivityTimerStatus.Server | _ActivityTimerStatus.End);
			timerList.add(activityTimerStatus);
		}
		
		if(timerList.isEmpty())
		{
			specialTime.set_timeDurationType(_TimeDurationType.Unknown);

			long openTime = parseOpenTime(specialTime);
			long endTime = parseCloseTime(specialTime);

			activityTimerStatus =
				new ActivityTimerStatus(openTime, _ActivityTimerStatus.Client | _ActivityTimerStatus.Server
					| _ActivityTimerStatus.Start);
			timerList.add(activityTimerStatus);

			activityTimerStatus =
				new ActivityTimerStatus(endTime, _ActivityTimerStatus.Client | _ActivityTimerStatus.Server
					| _ActivityTimerStatus.End);
			timerList.add(activityTimerStatus);
		}
		timerList.getFirst().addTimerStatus(_ActivityTimerStatus.InformNext);
		
		if (logger.isTraceEnabled())
		{
			String strOut = String.format("calcTimeListFromTimeCell timerCount %d openTime %s closeTime %s ###### ", timerList.size(), 
				dateFormat.format(parseOpenTime(specialTime)), dateFormat.format(parseCloseTime(specialTime)));
		
			for (ActivityTimerStatus timerStatus : timerList)
			{
				String tmp = String.format("%s--%s,  ", dateFormat.format(timerStatus.getTimer()), timerStatus.getTimerStatus());
				strOut += tmp;
			}
			logger.trace(strOut);
		}
		
		return timerList;
	}

	protected int parseActivityLevelMin(ActivityConfig.ActivityCondition condition)
	{
		if (condition == null)
		{
			return 0;
		}
		
		if (condition.get_activatePlayerLevelLower() < condition.get_startPlayerLevelLower())
		{
			return condition.get_startPlayerLevelLower();
		}
		else
		{
			return condition.get_activatePlayerLevelLower();
		}
	}
	
	protected int parseActivityLevelMax(ActivityCondition condition)
	{
		if (condition == null)
		{
			return 0;
		}
		
		if (condition.get_activatePlayerLevelUpper() > condition.get_startPlayerLevelUpper())
		{
			return condition.get_startPlayerLevelUpper();
		}
		else
		{
			return condition.get_activatePlayerLevelUpper();
		}
	}
	
	protected long parseCloseTime(ActivitySpecialTime specialTime)
	{
		if (specialTime == null)
		{
			return 0;
		}

		String activateAbsoluteCloseTime = specialTime.get_activateAbsoluteCloseTime();// 激活关闭绝对时间
		long activateAbsCloseTime = 0;
		if (activateAbsoluteCloseTime != null && !activateAbsoluteCloseTime.trim().equals(""))
		{
			activateAbsCloseTime = getAbsoluteTimeFromAbsolute(activateAbsoluteCloseTime);
		}
		
		long areaStartTime = AreaData.getAreaStartTimeMS();
		String activateRelativeStartServiceCloseTime = specialTime.get_activateRelativeStartServiceCloseTime();// 激活关闭相对开服时间，初始化时已转化成绝对时间
		long activateRelaStartServCloseTime = 0;
		if (activateRelativeStartServiceCloseTime != null && !activateRelativeStartServiceCloseTime.trim().equals(""))
		{
			activateRelaStartServCloseTime = getAbsoluteTimeFromRelativeClose(activateRelativeStartServiceCloseTime, areaStartTime);
		}
		
		String closeTime = specialTime.get_closeTime();// 活动关闭时间,为0表示没有关闭时间
		long closeTimeNum = 0;
		if (closeTime != null && !closeTime.trim().equals(""))
		{
			closeTimeNum = getAbsoluteTimeFromAbsolute(closeTime);
		}

		String startRelativeStartServiceCloseTime = specialTime.get_startRelativeStartServiceCloseTime();// 相对开服关闭时间
		long startRelaStartServCloseTime = 0;
		if (startRelativeStartServiceCloseTime != null && !startRelativeStartServiceCloseTime.trim().equals(""))
		{
			startRelaStartServCloseTime = getAbsoluteTimeFromRelativeClose(startRelativeStartServiceCloseTime, areaStartTime);
		}
	
		if(activateAbsCloseTime > 0 && activateAbsCloseTime < closeTimeNum)
		{
			closeTimeNum = activateAbsCloseTime;
		}
		if(activateRelaStartServCloseTime > 0 && activateRelaStartServCloseTime < closeTimeNum)
		{
			closeTimeNum = activateRelaStartServCloseTime;
		}
		if(startRelaStartServCloseTime > 0)
		{
			if(closeTimeNum == 0 || (closeTimeNum > 0 && startRelaStartServCloseTime < closeTimeNum))
			{
				closeTimeNum = startRelaStartServCloseTime;
			}
		}

		return closeTimeNum;
	}
	
	protected long parseOpenTime(ActivitySpecialTime specialTime)
	{
		if (specialTime == null)
		{
			return 0;
		}

		String activateAbsoluteOpenTime = specialTime.get_activateAbsoluteOpenTime();// 激活开启绝对时间
		long activateAbsOpenTime = 0;
		if (activateAbsoluteOpenTime != null && !activateAbsoluteOpenTime.trim().equals(""))
		{
			activateAbsOpenTime = getAbsoluteTimeFromAbsolute(activateAbsoluteOpenTime);
		}
		
		long areaStartTime = AreaData.getAreaStartTimeMS();
		String activateRelativeStartServiceOpenTime = specialTime.get_activateRelativeStartServiceOpenTime();// 激活开启相对开服时间，初始化时已转化成绝对时间
		long activateRelaStartServOpenTime = 0;
		if (activateRelativeStartServiceOpenTime != null && !activateRelativeStartServiceOpenTime.trim().equals(""))
		{
			activateRelaStartServOpenTime = getAbsoluteTimeFromRelativeOpen(activateRelativeStartServiceOpenTime, areaStartTime);
		}
	
		String openTime = specialTime.get_openTime();// 活动开启时间毫秒数,为0表示肯定开启了
		long openTimeNum = 0;
		if (openTime != null && !openTime.trim().equals(""))
		{
			openTimeNum = getAbsoluteTimeFromAbsolute(openTime);
		}

		String startRelativeStartServiceOpenTime = specialTime.get_startRelativeStartServiceOpenTime();// 相对开服开启时间
		long startRelaStartServOpenTime = 0;
		if (startRelativeStartServiceOpenTime != null && !startRelativeStartServiceOpenTime.trim().equals(""))
		{
			startRelaStartServOpenTime = getAbsoluteTimeFromRelativeOpen(startRelativeStartServiceOpenTime, areaStartTime);
		}

		if(activateAbsOpenTime > 0 && activateAbsOpenTime > openTimeNum)
		{
			openTimeNum = activateAbsOpenTime;
		}
		if(activateRelaStartServOpenTime > 0 && activateRelaStartServOpenTime > openTimeNum)
		{
			openTimeNum = activateRelaStartServOpenTime;
		}
		if(startRelaStartServOpenTime > 0 && startRelaStartServOpenTime > openTimeNum)
		{
			openTimeNum = startRelaStartServOpenTime;
		}
		
		return openTimeNum;
	}
	
	public void informNextRoundTimeList(int activityId, int playerId, ActivitySpecialTimeInfo timeInfo)
	{
		if (timeInfo == null)
		{
			return;
		}
		
		//当同一活动id支持多个时间段时，需要对入参进行检测，防止重复通知
		//如果想要只通知一次，需要修改注册部分的逻辑
		ActivitySpecialTimeInfo nextInfo = new ActivitySpecialTimeInfo(timeInfo);
		nextTimerList.put(activityId, nextInfo);
		
		if (logger.isTraceEnabled())
		{
			String strOut = String.format("informNextRoundTimeList id %x timerCount %d openTime %s closeTime %s ###### ", activityId, 
				timeInfo.getTimerList().size(), dateFormat.format(timeInfo.getOpenTime()), dateFormat.format(timeInfo.getCloseTime()));
		
			for (ActivityTimerStatus timerStatus : timeInfo.getTimerList())
			{
				String tmp = String.format("%s--%s,  ", dateFormat.format(timerStatus.getTimer()), timerStatus.getTimerStatus());
				strOut += tmp;
			}
			logger.trace(strOut);
		}
		boolean isDuration = false;
		if (this.type == _ActivityType.SECRETACTIVIYT)
		{
			isDuration = true;
		}
		
		//对于客栈来说,Open和Close需要置为本周期的周期开始点和结束点
		long openTime = timeInfo.getOpenTime();
		long closeTime = timeInfo.getCloseTime();
		
		if (this.type == _ActivityType.GETFIXTEDTIMEACTIVITY)
		{
			openTime = timeInfo.getTimerList().getFirst().getTimer();
			closeTime = timeInfo.getTimerList().getLast().getTimer();
		}
		
		ActivityData activityData = new ActivityData(type, activityId);
		ActivityInfo activityInfo = new ActivityInfo(timeInfo.getDurationType(), openTime, closeTime, getClientNextTimeList(activityId), isDuration);
		activityData.addActivityInfo(activityInfo);
		ActivityMgr.getInstance().addToActivityNotify(activityData, playerId);
	}
	
	public void informTodayRoundTimeList(int activityId, ActivitySpecialTimeInfo timeInfo)
	{
		//当同一活动id支持多个时间段时，需要对入参进行检测，防止重复通知
		//如果想要只通知一次，需要修改注册部分的逻辑
		ActivitySpecialTimeInfo todayInfo = new ActivitySpecialTimeInfo(timeInfo);
		todayTimerList.put(activityId, todayInfo);
		
		if (logger.isTraceEnabled())
		{
			String strOut = String.format("informTodayRoundTimeList id %x timerCount %d openTime %s closeTime %s durationType %d ###### ", activityId, 
				timeInfo.getTimerList().size(), dateFormat.format(timeInfo.getOpenTime()), dateFormat.format(timeInfo.getCloseTime()),
				timeInfo.getDurationType());
		
			for (ActivityTimerStatus timerStatus : timeInfo.getTimerList())
			{
				String tmp = String.format("%s--%s,  ", dateFormat.format(timerStatus.getTimer()), timerStatus.getTimerStatus());
				strOut += tmp;
			}
			logger.trace(strOut);
		}
	}
	
	private long getAbsoluteTimeFromRelativeOpen(String openStr, long time)
	{
		return xmlConfig.parseTimeString(openStr, "0-0-0 0:0:0", time, TimeZoneData.getTimeZone());
	}

	private long getAbsoluteTimeFromRelativeClose(String closeStr, long time)
	{
		return xmlConfig.parseTimeString(closeStr, MAX_DATE, time, TimeZoneData.getTimeZone());
	}
	
	private long getAbsoluteTimeFromAbsolute(String openStr)
	{
		long defaultTime = 0;
		return xmlConfig.parseDatetime(openStr, TimeZoneData.getTimeZone(), defaultTime);
	}
	
	/*
	 * 判断活动是否处于激活状态
	 */
	public abstract boolean isActivityActivate(int activityId, PlayerNode playerNode);
	
	
	public void getActivityData(ArrayList<com.kodgames.corgi.protocol.CommonProtocols.ActivityData> activityDatas, PlayerNode playerNode)
	{	
		long now = System.currentTimeMillis();
		
		for(Map.Entry<Integer, ActivityElement> entry : elementMaps.entrySet())
		{
			ActivityElement element = entry.getValue();
			int activityId = element.getActivityID();
			
			ActivitySpecialTimeInfo timeInfo = todayTimerList.get(activityId);
			if (timeInfo == null)
			{
				logger.error("getActivityData id {} not found todayTimerList", activityId);
				continue;
			}
			
			boolean isDuration = false;
			if (this.type == _ActivityType.SECRETACTIVIYT)
			{
				isDuration = true;
			}
			
			//对于客栈来说,Open和Close需要置为本周期的周期开始点和结束点
			long openTime = timeInfo.getOpenTime();
			long closeTime = timeInfo.getCloseTime();
			
			if (this.type == _ActivityType.GETFIXTEDTIMEACTIVITY)
			{
				openTime = timeInfo.getTimerList().getFirst().getTimer();
				closeTime = timeInfo.getTimerList().getLast().getTimer();
			}
				
			ActivityInfo activityInfo = new ActivityInfo(timeInfo.getDurationType(), openTime, closeTime, getClientTodayTimeList(activityId), isDuration);
			ActivityData activityData = new ActivityData(type, activityId);
			activityData.addActivityInfo(activityInfo);
			
			if (logger.isTraceEnabled())
			{
				logger.trace("getActivityData inform client data activityData---------- {}", activityData.toString());
			}
			
			if (activityData.hasActivityInfo())
			{
				activityDatas.add(activityData.toBuffer());
			}
			
			//判断当前时间是否超过了informNext，如果超过，需要触发针对该玩家的通知
			for (ActivityTimerStatus timerStatus : timeInfo.getTimerList())
			{
				if ((timerStatus.getTimerStatus() & _ActivityTimerStatus.InformNext) > 0)
				{
					if (timerStatus.getTimer() <= now)
					{
						//触发通知
						ActivitySpecialTimeInfo nextInfo = nextTimerList.get(activityId);
						if (null != nextInfo)
						{
							informNextRoundTimeList(activityId, playerNode.getPlayerId(), nextInfo);
						};
					}
					
					break;
				}
			}
		}
	}
	
	protected boolean checkIsStart(int activityId, PlayerNode playerNode)
	{
		long now = System.currentTimeMillis();
		ActivityElement element = elementMaps.get(activityId);
		if(element == null)
		{
			return false;
		}
		
		int level = 0;
		if(playerNode != null)
		{		
			//createTime = playerNode.getPlayerInfo().getClientLoginMessage().getCreateTime();
			level = playerNode.getGamePlayer().getLevel();
			
			if (level > 0)
			{
				if (element.getActivityCondition().startLowerPlayerLevel > 0 && level < element.getActivityCondition().startLowerPlayerLevel)
				{
					return false;
				}

				if (element.getActivityCondition().startUpperPlayerLevel > 0 && level > element.getActivityCondition().startUpperPlayerLevel)
				{
					return false;
				}
			}
		}
		
		ActivitySpecialTimeInfo timeInfo = element.getSpecialTimeByTime(now);
		if (timeInfo == null)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	/*
	 * 判断活动的时间节点是否更新
	 */
	protected void checkActivityTimeChanged(ActivityEnviroment activityEnv, Activity activity)
	{
		ActivityElement element = elementMaps.get(activity.get_activityId());
		if (element == null)
		{
			registerActivity(ActivityMgr.getInstance().getActivityEnv(), activity);
			return;
		}
		
		//采用双层循环，判断是新增，删除还是修改
		ConcurrentLinkedQueue<ActivitySpecialTimeInfo> infoList = element.getSpecialTimes();
		int oldCount = infoList.size();
		int newCount = activity.Get_specialTimesCount();
		
		int[] oldInfo = new int[oldCount];
		for (int i = 0; i < oldCount; i++)
		{
			oldInfo[i] = ACTIVITY_SPECIALTIME_DEL;	//表示removed
		}
		int[] newInfo = new int[newCount];
		for (int i = 0; i < newCount; i++)
		{
			newInfo[i] = ACTIVITY_SPECIALTIME_ADD;		//表示add
		}
		
		for (int newIndex = 0; newIndex < activity.Get_specialTimesCount(); newIndex++)
		{
			int oldIndex = 0;
			ActivitySpecialTime specialTime = activity.Get_specialTimesByIndex(newIndex);
			for(ActivitySpecialTimeInfo timeInfo : infoList)
			{
				if (oldInfo[oldIndex] != ACTIVITY_SPECIALTIME_SAME && isSameSpecialTime(timeInfo, specialTime))
				{
					newInfo[newIndex] = ACTIVITY_SPECIALTIME_SAME;	//same
					oldInfo[oldIndex] = ACTIVITY_SPECIALTIME_SAME;
					break;
				}
				oldIndex++;
			}
		}
		
		//删除未开始的活动
		int index = 0;
		for (ActivitySpecialTimeInfo timeInfo : infoList)
		{
			if (oldInfo[index] == ACTIVITY_SPECIALTIME_DEL)
			{
				activityEnv.removeTimerByActivityIDAndTime(activity.get_activityId(), timeInfo.getOpenTime(), timeInfo.getCloseTime());
				infoList.remove(timeInfo);
			}
			
			index++;
		}
	
		//检查比较结果，
		//TODO:暂不支持当前活动的修改，只支持新增活动
		for (int i = 0; i < newCount; i++)
		{
			if (newInfo[i] == ACTIVITY_SPECIALTIME_ADD)
			{
				ActivitySpecialTime specialTime = activity.Get_specialTimesByIndex(i);

				long openTime = parseOpenTime(specialTime);
				long endTime = parseCloseTime(specialTime);

				ActivitySpecialTimeInfo timeInfo =
					new ActivitySpecialTimeInfo(specialTime.get_index(), specialTime.get_timeDurationType(), openTime,
						endTime, specialTime.get_resetType(), specialTime.get_resetCount(),	calcTimeListFromTimeCell(specialTime));

				activityEnv.registerSpecialTime(element.getActivityID(), timeInfo, this);
				
				element.addSpecialTime(timeInfo);
			}
		}
		
		calcTodayAndNextTimerList(element);
	}
	
	protected boolean isSameSpecialTime(ActivitySpecialTimeInfo timeInfo, ActivitySpecialTime specialTime)
	{
		boolean isSamed = true;
		ConcurrentLinkedDeque<ActivityTimerStatus> newList = calcTimeListFromTimeCell(specialTime);

		if (timeInfo.getDurationType() == specialTime.get_timeDurationType())
		{
			//不能简单的进行数量判断，因为timeInfo中有活动插入的周期开始点和结束点
//			if (timeInfo.getTimerList().size() != newList.size())
//			{
//				isSamed = false;
//			}
//			else
			{
				//比较open和close，因为神秘商人会补timerList中的点，没有符合open、close
				long newClose = parseCloseTime(specialTime);
				long newOpen = parseOpenTime(specialTime);
				long oldClose = timeInfo.getCloseTime();
				long oldOpen = timeInfo.getOpenTime();
				if (newOpen != oldOpen || newClose != oldClose)
				{
					isSamed = false;
				}
				else 
				{
					Iterator<ActivityTimerStatus> iterNew = newList.iterator();
					Iterator<ActivityTimerStatus> iterOld = timeInfo.getTimerList().iterator();
					while (iterNew.hasNext()) 
					{
						if (!iterOld.hasNext())
						{
							isSamed = false;
							break;
						}
				
						ActivityTimerStatus newTimer = iterNew.next();
						ActivityTimerStatus oldTimer = iterOld.next();
						
						while ((oldTimer.getTimerStatus() & (_ActivityTimerStatus.Client | _ActivityTimerStatus.Server)) == 0)
						{
							if (!iterOld.hasNext())
							{
								return false;
							}
							
							oldTimer = iterOld.next();
						}

						if (!isSameTimer(newTimer.getTimer(), oldTimer.getTimer(), timeInfo.getDurationType()))
						{
							isSamed = false;
							break;
						}
					}

					if (iterOld.hasNext()) 
					{
						isSamed = false;
					}
				}
			}
		}
		else
		{
			isSamed = false;
		}
		return isSamed;
	}
	
	protected boolean isSameTimer(long timeSrc, long timeDst, int timerInterval)
	{
		long minTime = timeSrc;
		long maxTime = timeDst;
		if (timeSrc > timeDst)
		{
			minTime = timeDst;
			maxTime = timeSrc;
		}
		
		if (minTime == maxTime)
		{
			return true;
		}
		
		if (minTime < System.currentTimeMillis())
		{
				TimeZone tz = TimeZone.getTimeZone(ServerUtil.getTimeZoneStringFromInt(TimeZoneData.getTimeZone()));
				Calendar tmpCalendar = Calendar.getInstance(tz);
				tmpCalendar.setTimeInMillis(minTime);

				// 将整个活动的周期向后推移到现在之后
				while (tmpCalendar.getTimeInMillis() < System.currentTimeMillis())
				{
					switch (timerInterval)
					{
						case _TimeDurationType.Day:
							tmpCalendar.add(Calendar.DAY_OF_YEAR, 1);
							break;
						case _TimeDurationType.Week:
							tmpCalendar.add(Calendar.WEEK_OF_YEAR, 1);
							break;
						case _TimeDurationType.Month:
							tmpCalendar.add(Calendar.MONTH, 1);
							break;
						case _TimeDurationType.Year:
						default:
							return false;
					}
					
					if (maxTime == tmpCalendar.getTimeInMillis())
					{
						return true;
					}
				}
				
				return maxTime == tmpCalendar.getTimeInMillis();
		}
		
		return false;
	}

	public void registerActivityElement(ActivityEnviroment activityEnv, ActivityElement element)
	{
		ConcurrentLinkedQueue<ActivitySpecialTimeInfo> specialTimes = element.getSpecialTimes();
		if (specialTimes == null || specialTimes.isEmpty())
		{
			return;
		}

		for(ActivitySpecialTimeInfo info : specialTimes)
		{
			//对活动的时间有效性进行判断
			activityEnv.registerSpecialTime(element.getActivityID(), info, this);
		}
		
		calcTodayAndNextTimerList(element);
	}
	
	private int calcTodayTimeInfo(ActivitySpecialTimeInfo today, ActivitySpecialTimeInfo input, long curTime)
	{
		//非周期的活动，判断是否处于open和close之间
		long inputFirst = input.getOpenTime();
		long inputLast = input.getCloseTime();
		
		long todayFirst = today.getOpenTime();
		long todayLast = today.getCloseTime();
		
		if (isDurationType(input.getDurationType()))
		{
			//周期性活动，需要根据活动模块插入的周期开始点和结束点进行判断
			inputFirst = input.getTimerList().getFirst().getTimer();
			inputLast = input.getTimerList().getLast().getTimer();
			
			todayFirst = today.getTimerList().getFirst().getTimer();
			todayLast = today.getTimerList().getLast().getTimer();			
		}
		
		return checkTimerForToday(todayFirst, todayLast, inputFirst, inputLast, curTime);
	}
	
	/*
	 * 计算当前周期的时间段
	 * @param todayOpen 保存的当前周期开始点
	 * @param todayClose 保存的当前周期结束点
	 * @param inputOpen 要比较的周期开始点
	 * @param inputClose 要比较的周期结束点
	 * @param curTime 比较的基准时间，通常为当前时间
	 * 
	 * @return 0 当前保存数据有效
	 * @return 1 输入的比较周期数据有效
	 */
	private int checkTimerForToday(long todayOpen, long todayClose, long inputOpen, long inputClose, long curTime)
	{
		if (todayOpen <= curTime && todayClose > curTime)
		{
			return 0;
		}
		
		if (inputOpen <= curTime && inputClose > curTime)
		{
			return 1;
		}
		
		if (todayOpen == inputOpen || todayClose == inputClose)
		{
			return 0;
		}
		
		//保存和要比较的周期都不是当前时段，取最近一个开始的时间段
		if (inputOpen > curTime)
		{
			if (todayOpen > curTime)
			{
				if (inputOpen < todayOpen)
				{
					return 1;
				}
			}
			else
			{
				return 1;
			}
		}
		
		return 0;
	}
	
	private int calcNextTimeInfo(ActivitySpecialTimeInfo next, ActivitySpecialTimeInfo input, long curTime)
	{
		if (null == next)
		{
			return 1;
		}
		//非周期的活动，判断是否处于open和close之间
		long inputFirst = input.getOpenTime();
		//long inputLast = input.getCloseTime();
		
		long nextFirst = next.getOpenTime();
		//long nextLast = next.getCloseTime();
		
		if (isDurationType(input.getDurationType()))
		{
			//周期性活动，需要根据活动模块插入的周期开始点和结束点进行判断
			inputFirst = input.getTimerList().getFirst().getTimer();
			//inputLast = input.getTimerList().getLast().getTimer();
			
			nextFirst = next.getTimerList().getFirst().getTimer();
			//nextLast = next.getTimerList().getLast().getTimer();			
		}
		
		return checkTimerForNext(nextFirst, inputFirst, curTime);
	}
	
	/*
	 * 计算下一周期的时间段
	 * @param nextOpen 保存的下一周期开始点
	 * @param inputOpen 要比较的周期开始点
	 * @param curTime 比较的基准时间，通常为当前时间
	 * 
	 * @return -1 2个周期的数据均无效
	 * @return 0 当前保存数据有效
	 * @return 1 输入的比较周期数据有效
	 */
	private int checkTimerForNext(long nextOpen, long inputOpen, long curTime)
	{
		if (nextOpen == inputOpen)
		{
			return 0;
		}
		
		// 下一周期的数据，取开始时间在当前时间之后，最早开始的
		if (nextOpen < curTime) // 保存的数据无效，即活动已开启
		{
			if (inputOpen < curTime)
			{
				// 输入数据也无效
				return -1;
			}
			else
			{
				// 数据数据有效，未开启的时间段
				return 1;
			}
		}
		else		// 保存的数据时未开启的时间段
		{
			if (inputOpen > curTime) // 输入的也是未开启的时间段
			{
				if (inputOpen < nextOpen)
				{
					// 取最早开始的时间段
					return 1;
				}
			}
		}
		
		return 0;
	}
	
	public boolean isDurationType(int type)
	{
		switch(type)
		{
			case _TimeDurationType.Day:
			case _TimeDurationType.Week:
			case _TimeDurationType.Month:
				return true;
			case _TimeDurationType.Year:
				default:
					return false;
		}
	}
	
	private void handleInformNextRound(int activityID, long openTime, long closeTime, int specialIndex, int playerId)
	{
		ActivityElement element = elementMaps.get(activityID);
		if (element == null)
		{
			logger.warn("handleInformNextRound can't find LocalInfo from elementMaps unexpected");
			return;
		}
		
		long now = System.currentTimeMillis();
		ActivitySpecialTimeInfo nextInfo = null;
		if (isDurationType(element.getSpecialTimes().element().getDurationType()))
		{
			//注册时经历了时间迭代计算，此时比为当前周期
			nextInfo = element.getSpecialTimes().element();	
			long addTime = this.calcNextDuration(nextInfo);
			if (0 != addTime)
			{
				Iterator<ActivityTimerStatus> iter = nextInfo.getTimerList().iterator();
				while (iter.hasNext())
				{
					ActivityTimerStatus status = iter.next();
					status.addTimer(addTime);
				}
			}
		}
		else
		{
			ConcurrentLinkedQueue<ActivitySpecialTimeInfo> specialTimes = element.getSpecialTimes();
			// 重新遍历计算当前周期和下一周期的数据，在注册时，对于过期数据进行了处理
			for (ActivitySpecialTimeInfo info : specialTimes)
			{
				int nextRtn = calcNextTimeInfo(nextInfo, info, now);
				if (1 == nextRtn)
				{
					nextInfo = info;
				}
			}
		}
		
		if (null != nextInfo)
		{
//			if(nextInfo.getCloseTime() <= now)
//			{
//				return;
//			}
			informNextRoundTimeList(activityID, playerId, nextInfo);
		}
	}
	
	private void calcTodayAndNextTimerList(ActivityElement element)
	{
		long now = System.currentTimeMillis();
		ActivitySpecialTimeInfo newToday = null;
		ActivitySpecialTimeInfo newNext = null;
		if (element.getSpecialTimes().isEmpty())
		{
			return;
		}
		
		if (isDurationType(element.getSpecialTimes().element().getDurationType()))
		{
			//注册时经历了时间迭代计算，此时比为当前周期
			newToday = element.getSpecialTimes().element();		
		}
		else
		{
			ConcurrentLinkedQueue<ActivitySpecialTimeInfo> specialTimes = element.getSpecialTimes();
			// 重新遍历计算当前周期和下一周期的数据，在注册时，对于过期数据进行了处理
			for (ActivitySpecialTimeInfo info : specialTimes)
			{
				if (newToday == null)
				{
					newToday = info;
				}

				int todayRtn = calcTodayTimeInfo(newToday, info, now);
				if (1 == todayRtn)
				{
					newToday = info;
				}
			}
		}

		if (newToday == null)
		{
			logger.error("registerSpecialTime found today is null");
			return;
		}
		
		ActivitySpecialTimeInfo oldToday = todayTimerList.get(element.getActivityID());
		ActivitySpecialTimeInfo oldNext = nextTimerList.get(element.getActivityID());
		
		if (oldToday == null || !oldToday.isSameSpecialTimeInfo(newToday))
		{
			informTodayRoundTimeList(element.getActivityID(), newToday);
		}
		
		if (isDurationType(element.getSpecialTimes().element().getDurationType()))
		{
			//注册时经历了时间迭代计算，此时比为当前周期
			long addTime = this.calcNextDuration(newToday);
			if (0 != addTime)
			{
				Iterator<ActivityTimerStatus> iter = newToday.getTimerList().iterator();
				while (iter.hasNext())
				{
					ActivityTimerStatus status = iter.next();
					status.addTimer(addTime);
				}
			}
			
			newNext = newToday;
		}
		else
		{
			ConcurrentLinkedQueue<ActivitySpecialTimeInfo> specialTimes = element.getSpecialTimes();
			// 重新遍历计算当前周期和下一周期的数据，在注册时，对于过期数据进行了处理
			for (ActivitySpecialTimeInfo info : specialTimes)
			{
				int nextRtn = calcNextTimeInfo(newNext, info, now);
				if (1 == nextRtn)
				{
					newNext = info;
				}
				else if (-1 == nextRtn)
				{
					newNext = null;
				}
			}
		}

		if (newNext != null && (oldNext == null || !oldNext.isSameSpecialTimeInfo(newNext)))
		{
			informNextRoundTimeList(element.getActivityID(), 0, newNext);
		}
	}
	
	private long calcNextDuration(ActivitySpecialTimeInfo timeInfo)
	{
		ActivityTimerStatus timer = timeInfo.getTimerList().getFirst();

		TimeZone tz = TimeZone.getTimeZone(ServerUtil.getTimeZoneStringFromInt(TimeZoneData.getTimeZone()));
		Calendar tmpCalendar = Calendar.getInstance(tz);
		tmpCalendar.setTimeInMillis(timer.getTimer());

		switch (timeInfo.getDurationType())
		{
			case _TimeDurationType.Day:
				tmpCalendar.add(Calendar.DAY_OF_YEAR, 1);
				break;
			case _TimeDurationType.Week:
				tmpCalendar.add(Calendar.WEEK_OF_YEAR, 1);
				break;
			case _TimeDurationType.Month:
				tmpCalendar.add(Calendar.MONTH, 1);
				break;
			case _TimeDurationType.Year:
			default:
				return 0;
		}
		
		if (timeInfo.getCloseTime() != 0 && tmpCalendar.getTimeInMillis() > timeInfo.getCloseTime())
		{
			return 0;
		}

		// 获取递进的时间差值
		return tmpCalendar.getTimeInMillis() - timer.getTimer();
	}
}
