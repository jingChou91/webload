package com.kodgames.corgi.server.gameserver.activity.operationactivty.data;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map.Entry;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.common.Pair;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.ActivityHandleOperationActivityManager;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.db.AccumulateDB;
import com.kodgames.corgi.server.gameserver.email.util.specialemail.EmailAccumulateUtil;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Reward;

public class OperationActivityMgr 
{
	private static final Logger logger = LoggerFactory.getLogger(OperationActivityMgr.class);
	private static OperationActivityMgr operationMgr = new OperationActivityMgr();
	private ActivityHandleOperationActivityManager activityHandle = null;
	
	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	public static OperationActivityMgr getInstance()
	{
		return operationMgr;
	}
	
	public void setActivityHandle(ActivityHandleOperationActivityManager activityHandle)
	{
		this.activityHandle = activityHandle;
	}
	
	public void purchase(PlayerNode playerNode, int rmb, ConfigDatabase cd)
	{
		try
		{
			//找到活动Id
			long nowTime = System.currentTimeMillis();
			int activityId = cd.get_OperationConfig().get_Operations().get_ActivityId();
			boolean isStart = activityHandle.isActivityActivate(activityId, playerNode);
			if(isStart)
			{
				//充值时间必须在当前活动的充值时间内
				long purchaseOpenTime = activityHandle.getPurchaseOpen(activityId, cd, nowTime);
				long purchaseCloseTime = activityHandle.getPurchaseClose(activityId, cd, nowTime);
				
				logger.info("purchase accumulate playerId ={},rmb={} start={},close={}", playerNode.getPlayerId() ,rmb, format.format(new Date(purchaseOpenTime)), format.format(new Date(purchaseCloseTime)));
				if(nowTime < purchaseOpenTime || nowTime > purchaseCloseTime)
				{
					logger.error("purchase accumulate " + playerNode.getPlayerId() + "not in purchase time");
					return;
				}
				refreshAccumulateData(nowTime, playerNode, cd);
				
				if(playerNode.getPlayerInfo().getOperationActivityData().getAccumulateActivity().isNeedInit(activityId))
				{
					int index = activityHandle.getNowActivityIndex(activityId, nowTime);
					AccumulateActivity accumulateActivity = new AccumulateActivity();
					accumulateActivity.addAccumulateActivity(activityId, cd, index);
					playerNode.getPlayerInfo().getOperationActivityData().setAccumulateActivity(accumulateActivity);
				}
				
				AccumulateActivity accumulateActivity = playerNode.getPlayerInfo().getOperationActivityData().getAccumulateActivity();
				if(null != accumulateActivity)
				{
					accumulateActivity.addCycleMoney(rmb);
					AccumulateDB.updateAccumulateData(playerNode);
					// 小绿点
					playerNode.getPlayerInfo().getAssisantData().getAccumulateActivity().notifyObservers();
				}
			}
			else
			{
				logger.error("purchase accumulate " + playerNode.getPlayerId() + " activity is not start ");
			}
		}
		catch(Exception ex)
		{
			logger.error("purchase accumulate " + ExceptionUtils.getStackTrace(ex));
		}
		
	}
	
	public boolean refreshAccumulate(long nowTime, PlayerNode playerNode, ConfigDatabase cd)
	{
		if(refreshAccumulateData(nowTime, playerNode, cd))
		{
			AccumulateDB.updateAccumulateData(playerNode);
		}
		return true;
	}
	
	//领取奖励
	//刷新数据,返回值表示是否刷新了数据
	public boolean refreshAccumulateData(long nowTime, PlayerNode playerNode, ConfigDatabase cd)
	{
		//校验数据
		AccumulateActivity activityAcc = playerNode.getPlayerInfo().getOperationActivityData().getAccumulateActivity();
		if(checkData(activityAcc, cd))
		{
			return true;
		}
		boolean isRefresh = false;
		ClientServerCommon.OperationConfig cfgOperation = cd.get_OperationConfig();
		int activityId = activityAcc.getActivityId();
		
		if(activityId == 0)
		{
			return false;
		}
		long lastFreshTime = activityAcc.getLastFreshTime();
		
		boolean isStart = activityHandle.isActivityActivate(activityId, playerNode);
		long time1 = activityHandle.getPickRewardResetTime(activityId, nowTime); //根据当前时间获取下次活动开启时间;
		long time2 = activityHandle.getPickRewardResetTime(activityId, lastFreshTime);
			
		if(time1 != time2 || !isStart || time1 == 0)
		{
			ArrayList<com.kodgames.common.Pair<Integer, com.kodgames.common.Pair<Integer, Reward>>> objs = new ArrayList<com.kodgames.common.Pair<Integer, com.kodgames.common.Pair<Integer, Reward>>>();
			for(Entry<Integer, OperationItem> entrySet : activityAcc.getOperationItemList().entrySet())
			{	
				OperationItem operationItem = entrySet.getValue();
				com.kodgames.common.Pair<Integer, com.kodgames.common.Pair<Integer, Reward>> obj = refreshOneAccumulateData(nowTime, playerNode, activityId, operationItem, cfgOperation);
				if(obj != null)
				{
					objs.add(obj);
					
				}
			}
			if(objs.size() != 0)
			{
				//对ArrayList进行插入排序
				insertSort(objs);
				long nowTimeForEmail = System.currentTimeMillis();
				for(Pair<Integer, Pair<Integer, Reward>> pair : objs)
				{
					EmailAccumulateUtil.sendPlayerEmailsByRewardSetId(playerNode, 0,  pair.getSecond().getFirst(), pair.getSecond().getSecond(),  pair.getFirst(), nowTimeForEmail);
					nowTimeForEmail++;
				}
			}
			isRefresh = true;
			activityAcc.clear();
		}
		return isRefresh;
	}
	
	public void insertSort(ArrayList<com.kodgames.common.Pair<Integer, com.kodgames.common.Pair<Integer, Reward>>> a){  
        int length=a.size(); //数组长度  
        int j;               //当前值的位置  
        int i;               //指向j前的位置  
        Pair<Integer, Pair<Integer, Reward>> key;             //当前要进行插入排序的值  
        //从数组的第二个位置开始遍历值  
        for(j=1 ; j < length; j++){  
            key =a.get(j);  
            i=j-1;  
            //a[i]比当前值大时，a[i]后移一位,空出i的位置，好让下一次循环的值后移  
            while((i >= 0) && (a.get(i).getFirst() < key.getFirst())){  
                a.set(i+1, a.get(i));//将a[i]值后移
                i--;         //i前移  
            }//跳出循环(找到要插入的中间位置或已遍历到0下标)  
            a.set(i+1, key);    //将当前值插入  
        }  
    }
	private com.kodgames.common.Pair<Integer, com.kodgames.common.Pair<Integer, Reward>> refreshOneAccumulateData(long nowTime, PlayerNode playerNode, int activityId, OperationItem operationItem, ClientServerCommon.OperationConfig  cfgOperation)
	{
		com.kodgames.common.Pair<Integer, com.kodgames.common.Pair<Integer, Reward>> rewards = null; 
		int currentPurchaseCount = operationItem.getAccumulateActivity().getCycleMoney()/ cfgOperation.getOperationItemById(operationItem.getItemId()).get_CompareValue();
		int cycleMaxCount = cfgOperation.getOperationItemById(operationItem.getItemId()).get_CycleMaxCount();
		
		int nowAvailablePickCount  = Math.min(currentPurchaseCount, cycleMaxCount) - operationItem.getCurrentPickCount();			
		if(nowAvailablePickCount > 0)
		{	
			//发送邮件给玩家
			Reward reward = new Reward();
			for(int i = 0; i <  cfgOperation.getOperationItemById(operationItem.getItemId()).Get_RewardsCount(); ++i)
			{
				Reward oneReward = new Reward();
				oneReward.fromClientServerCommon( cfgOperation.getOperationItemById(operationItem.getItemId()).Get_RewardsByIndex(i));	
				reward.megerReward(oneReward);
			}
			int itemMoney = cfgOperation.getOperationItemById(operationItem.getItemId()).get_CompareValue();
			
			com.kodgames.common.Pair<Integer, Reward> t2 = new com.kodgames.common.Pair<Integer, Reward>(nowAvailablePickCount, reward);
			rewards = new com.kodgames.common.Pair<Integer, com.kodgames.common.Pair<Integer, Reward>>(itemMoney, t2);
			//EmailAccumulateUtil.sendPlayerEmailsByRewardSetId(playerNode, 0, nowAvailablePickCount, reward, itemMoney);
			// 小绿点
			playerNode.getPlayerInfo().getAssisantData().getAccumulateActivity().notifyObservers();
		}
		operationItem.setCurrentPickCount(0);		
		return rewards;
	}
	
	public boolean isCanGetAnyAccumulateReward(PlayerNode playerNode, ConfigDatabase cd)
	{
		long nowTime = System.currentTimeMillis();
		AccumulateActivity accumulateActivity = playerNode.getPlayerInfo().getOperationActivityData().getAccumulateActivity();
		// 校验内存与配置文件是否匹配
		if(checkData(accumulateActivity, cd))
		{
			return false;
		}
		int activityId = accumulateActivity.getActivityId();
		if((activityHandle.getPickRewardOpen(activityId, cd, nowTime) != 0) && (activityHandle.getPickRewardOpen(activityId, cd, nowTime) > nowTime) )
		{
			return false;
		}
		
		if((activityHandle.getPickRewardClose(activityId, cd, nowTime) != 0) && (activityHandle.getPickRewardClose(activityId, cd, nowTime) < nowTime) )
		{
			return false;
		}
		for(Entry<Integer, OperationItem> entryOperation : accumulateActivity.getOperationItemList().entrySet())
		{
			if(entryOperation.getValue().isCouldPickReward(cd))
			{
				return true;
			}
		}
		
		return false;
	}
	private boolean checkData(AccumulateActivity accumulateActivity, ConfigDatabase cd)
	{
		return accumulateActivity.checkData(cd);
	}
}
