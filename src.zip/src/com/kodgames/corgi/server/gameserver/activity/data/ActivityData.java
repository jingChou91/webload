package com.kodgames.corgi.server.gameserver.activity.data;

import java.util.ArrayList;
import java.util.List;

import com.kodgames.corgi.protocol.CommonProtocols;

public class ActivityData
{
	private int activityType;
	private int activityId;

	private List<ActivityInfo> list = new ArrayList<ActivityInfo>();

	public ActivityData(int activityType, int activityId)
	{
		this.activityType = activityType;
		this.activityId = activityId;
	}
	
	public int getActivityType()
	{
		return activityType;
	}

	public int getActivityId()
	{
		return activityId;
	}

	public CommonProtocols.ActivityData toBuffer()
	{
		CommonProtocols.ActivityData.Builder builder = CommonProtocols.ActivityData.newBuilder();
		builder.setActivityType(this.activityType);
		builder.setActivityId(this.activityId);
		for(ActivityInfo activityInfo : list)
		{
			builder.addActivityData(activityInfo.toBuffer());
		}
		return builder.build();
	}
	
	public boolean hasActivityInfo()
	{
		return list.size() > 0;
	}
	
	public void addActivityInfo(ActivityInfo activityInfo)
	{
		list.add(activityInfo);
	}

	public String toString()
	{
		String rtn = String.format("activityId %x activityType %d ", activityId, activityType);
		
		for (ActivityInfo info : list)
		{
			rtn += info.toString();
			rtn += "~~~~~~~";
		}
		
		return rtn;
	}
}
