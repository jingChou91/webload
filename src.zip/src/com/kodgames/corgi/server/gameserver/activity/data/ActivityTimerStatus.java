package com.kodgames.corgi.server.gameserver.activity.data;

public class ActivityTimerStatus
{
	private long timer;
	private int timerStatus;
	
	public ActivityTimerStatus(long timer, int timerStatus)
	{
		this.timer = timer;
		this.timerStatus = timerStatus;
	}
	
	public long getTimer()
	{
		return this.timer;
	}
	
	public int getTimerStatus()
	{
		return this.timerStatus;
	}
	
	public void addTimerStatus(int timerStatus)
	{
		this.timerStatus |= timerStatus;
	}

	public void addTimer(long timerAdd)
	{
		this.timer += timerAdd;
	}
	
	public ActivityTimerStatus fromProtobuf(com.kodgames.corgi.protocol.CommonProtocols.ActivityTimer protocol)
	{
		this.timer = protocol.getTimer();
		this.timerStatus = protocol.getStatus();
		return this;
	}

	public com.kodgames.corgi.protocol.CommonProtocols.ActivityTimer toProtobuf()
	{
		com.kodgames.corgi.protocol.CommonProtocols.ActivityTimer.Builder protoBuilder = com.kodgames.corgi.protocol.CommonProtocols.ActivityTimer.newBuilder();
		protoBuilder.setTimer(timer);
		protoBuilder.setStatus(timerStatus);
		return protoBuilder.build();
	}
}
