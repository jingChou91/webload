package com.kodgames.corgi.server.gameserver.activity.activitymgr;

import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.kodgames.corgi.server.gameserver.activity.data.ActivityTimerStatus;

/*
 * 活动类，包含活动的所有元素
 * !不支持活动的激活条件，只支持活动开启条件，目前所有活动的激活条件均未配置
 */
public class ActivityElement
{
	private int type;				//活动类型
	private String name;			//活动名字
	private int activityID;			//活动id
	private int owner;				//表示事件是全服的，还是个人的，类型待定？？建议直接用用户ID类型
	private ActivityCondition condition;//活动条件
	private ConcurrentLinkedQueue<ActivitySpecialTimeInfo> specialTimeLists = new ConcurrentLinkedQueue<ActivitySpecialTimeInfo>();//时间段列表

	private static int elementID;	//活动id，唯一标识，按照顺序排列
	
	public class ActivityCondition
	{
		//int activateLowerPlayerLevel;	//激活活动的人物等级下限
		//int activateUpperPlayerLevel;	//激活活动的人物等级上限
		int startLowerPlayerLevel;		//开启活动的人物等级下限
		int startUpperPlayerLevel;		//开启活动的人物等级上限
	}
	
	/*
	 * 构造活动元素
	 * @param type 活动类型
	 * @param name 活动名字
	 * @param ownerType 活动所有者类型，全服统一或者个人
	 * @param activityID 活动id
	 * @param lowPlayerLevel 开启活动的人物等级下限
	 * @param upperPlayerLevel 开启活动的人物等级上限
	 */
	public ActivityElement(int type, String name, int ownerType, int activityID, int lowerPlayerLevel, int upperPlayerLevel)
	{
		this.type = type;
		this.name = name;
		this.owner = ownerType;
		this.activityID = activityID;
		
		this.condition = new ActivityCondition();		
		this.condition.startLowerPlayerLevel = lowerPlayerLevel;
		this.condition.startUpperPlayerLevel = upperPlayerLevel;
		
		ActivityElement.elementID++;
	}
	
	/*
	 * @param index 时间段序号
	 * @param timeInterval 活动的周期间隔
	 * @param startTime 活动开始时间
	 * @param endTime 活动的结束时间
	 * @param timerList 活动的时间节点
	 * @param resetType 活动的重置类型
	 * @param resetCount 重置计数
	 */
	public void addSpecialTime(int index, int timeInterval, long startTime, long endTime, int resetType, int resetCount, ConcurrentLinkedDeque<ActivityTimerStatus> timerList)
	{
		ActivitySpecialTimeInfo specialTime = new ActivitySpecialTimeInfo(index, timeInterval, startTime, endTime, resetType, resetCount, timerList);
		
		this.specialTimeLists.add(specialTime);
	}
	
	public void addSpecialTime(ActivitySpecialTimeInfo specialTime)
	{
		this.specialTimeLists.add(specialTime);
	}
	
	public ActivitySpecialTimeInfo getSpecialTimeByTime(long time)
	{
		for(ActivitySpecialTimeInfo info : specialTimeLists)
		{
			if (info.getOpenTime() <= time && info.getCloseTime() >= time)
			{
				return info;
			}
			
			if (info.getOpenTime() <= time && info.getCloseTime() == 0)
			{
				return info;
			}
		}
		
		return null;
	}
	
	public ConcurrentLinkedQueue<ActivitySpecialTimeInfo> getSpecialTimes()
	{
		return specialTimeLists;
	}
	
	public void setSpecialTimes(ConcurrentLinkedQueue<ActivitySpecialTimeInfo> newSpecLists)
	{
		this.specialTimeLists = newSpecLists;
	}

	public int getType()
	{
		return type;
	}
	
	public String getName()
	{
		return name;
	}

	public int getOwner()
	{
		return owner;
	}

	public int getActivityID()
	{
		return activityID;
	}

	public void setActivityID(int activityID)
	{
		this.activityID = activityID;
	}

	public int getElementID()
	{
		return elementID;
	}
	
	public ActivityCondition getActivityCondition()
	{
		return condition;
	}
}
