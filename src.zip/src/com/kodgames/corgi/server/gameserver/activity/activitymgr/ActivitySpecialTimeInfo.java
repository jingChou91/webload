package com.kodgames.corgi.server.gameserver.activity.activitymgr;

import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedDeque;

import com.kodgames.corgi.server.gameserver.activity.data.ActivityTimerStatus;

public class ActivitySpecialTimeInfo
{
	private int index;					//本时间段的序号
	private long openTime;				//本时间段的开启时间
	private long closeTime;				//本时间段的结束时间
	private int durationType;			//活动的周期类型
	private int resetType;				//活动的重置类型
	private int resetCount;				//活动重置的时间单位数量
	private ConcurrentLinkedDeque<ActivityTimerStatus> timerList = new ConcurrentLinkedDeque<ActivityTimerStatus>();		//本时间段的所有时间节点
	
	public ActivitySpecialTimeInfo(int index, int timeInterval, long startTime, long endTime, int resetType, int resetCount, ConcurrentLinkedDeque<ActivityTimerStatus> timerList)
	{
		this.index = index;
		this.openTime = startTime;
		this.closeTime = endTime;
		this.durationType = timeInterval;
		this.resetType = resetType;
		this.resetCount = resetCount;
		this.timerList = timerList;
	}
	
	public ActivitySpecialTimeInfo(ActivitySpecialTimeInfo value)
	{
		this.index = value.index;
		this.openTime = value.openTime;
		this.closeTime = value.closeTime;
		this.durationType = value.durationType;
		this.resetCount = value.resetCount;
		this.resetType = value.resetType;
		
		for (ActivityTimerStatus status : value.getTimerList())
		{
			ActivityTimerStatus newStatus = new ActivityTimerStatus(status.getTimer(), status.getTimerStatus());
			this.timerList.add(newStatus);
		}
	}
	
	public int getIndex()
	{
		return index;
	}
	public long getOpenTime()
	{
		return openTime;
	}
	public long getCloseTime()
	{
		return closeTime;
	}
	public int getDurationType()
	{
		return durationType;
	}
	public int getResetType()
	{
		return resetType;
	}
	public int getResetCount()
	{
		return resetCount;
	}
	public ConcurrentLinkedDeque<ActivityTimerStatus> getTimerList()
	{
		return timerList;
	}
	
	public void insertTimerStatus(ActivityTimerStatus timerStatus, boolean isFirst)
	{
		if (isFirst)
		{
			timerList.addFirst(timerStatus);
		}
		else
		{
			timerList.addLast(timerStatus);
		}
	}
	
	public boolean isSameSpecialTimeInfo(ActivitySpecialTimeInfo input)
	{
		if (this.openTime != input.openTime || this.closeTime != input.closeTime || this.durationType != input.durationType
			|| this.resetType != input.resetType || this.resetCount != input.resetCount || this.timerList.size() != input.timerList.size())
		{
			return false;
		}
		
		Iterator<ActivityTimerStatus> iter = this.timerList.iterator();
		Iterator<ActivityTimerStatus> iterInput = input.timerList.iterator();
		while(iter.hasNext())
		{
			ActivityTimerStatus thisStatus = iter.next();
			ActivityTimerStatus inputStatus = iterInput.next();
			
			if (thisStatus.getTimer() != inputStatus.getTimer() || thisStatus.getTimerStatus() != inputStatus.getTimerStatus())
			{
				return false;
			}
		}
		
		return true;
	}
}
