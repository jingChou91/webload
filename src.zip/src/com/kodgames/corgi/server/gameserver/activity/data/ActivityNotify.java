package com.kodgames.corgi.server.gameserver.activity.data;

import java.util.ArrayList;
import java.util.List;

import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryNotifyRes;

public class ActivityNotify
{
	private List<ActivityData> listActivityData = new ArrayList<ActivityData>();
	public GC_QueryNotifyRes toBuff()
	{
		GC_QueryNotifyRes.Builder builder = GC_QueryNotifyRes.newBuilder();
		int result = ClientProtocols.E_GAME_QUERY_NOTIFY_SUCCESS;
		builder.setResult(result);
		builder.setAssisantNum(-1);
		builder.setCallback(0);
		for(ActivityData activityData : listActivityData)
		{
			builder.addActivityData(activityData.toBuffer());
		}
		return builder.build();
	}
	
	public int getSize()
	{
		return listActivityData.size();
	}
	
	public void add(ActivityData activityData)
	{
		listActivityData.add(activityData);
	}
	
	public String toString()
	{
		String rtn = "";
		for (ActivityData data : listActivityData)
		{
			rtn += data.toString();
			rtn += "$$$$$$$";
		}
		
		return rtn;
	}
}



