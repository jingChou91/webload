package com.kodgames.corgi.server.gameserver.activity.operationactivty;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentLinkedDeque;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ActivityConfig;
import ClientServerCommon.ActivityConfig.Activity;
import ClientServerCommon.ActivityConfig.ActivitySpecialTime;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._ActivityTimerStatus;
import ClientServerCommon._ActivityType;
import ClientServerCommon._TimeDurationType;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityElement;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityEnviroment;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityHandler;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivitySpecialTimeInfo;
import com.kodgames.corgi.server.gameserver.activity.data.ActivityTimerStatus;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.logic.CG_OperationActivityPickRewardReqHandler;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.logic.CG_OperationActivityQueryReqHandler;
import com.kodgames.gamedata.player.PlayerNode;

public class ActivityHandleOperationActivityManager extends ActivityHandler
{
	private static final Logger logger = LoggerFactory.getLogger(ActivityHandleOperationActivityManager.class);

	private CG_OperationActivityQueryReqHandler  cg_OperationActivityQueryReqHandler = null;
	private CG_OperationActivityPickRewardReqHandler  cg_OperationActivityPickRewardReqHandler = null;

	public ActivityHandleOperationActivityManager()
	{
		super(_ActivityType.ACCUMULATEACTIVITY);
	}

	@Override
	public boolean handleActivity(int activityID, long openTime, long closeTime, int specialIndex, int timerStatus,
		int timerIndex, int playerId, boolean startOnce)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if (!super.handleActivity(activityID, openTime, closeTime, specialIndex, timerStatus, timerIndex, playerId, startOnce))
		{
			return false;
		}

		String strOut = String.format("handleActivity id %x openTime %s closeTime %s timerStatus %x ", activityID, 
			dateFormat.format(openTime), dateFormat.format(closeTime), timerStatus);
		logger.debug(strOut);
		logger.debug("specialIndex = {}, timerIndex = {}, timerStatus = {}, playerId = {}, startOnce = {}", specialIndex,timerIndex, timerStatus, playerId, startOnce);

		if ((_ActivityTimerStatus.Start & timerStatus) > 0)
		{
			if (todayTimerList == null || todayTimerList.get(activityID) == null || todayTimerList.get(activityID).getTimerList() == null)
			{
				logger.warn("OperationActivityManager can't found id {} timeInfo but super found", activityID);
				return false;
			}
		}

		if ((_ActivityTimerStatus.Refresh & timerStatus) > 0)
		{
			if (todayTimerList == null || todayTimerList.get(activityID) == null || todayTimerList.get(activityID).getTimerList() == null)
			{
				logger.warn("OperationActivityManager can't found id {} timeInfo but super found", activityID);
				return false;
			}
		}

		return true;
	}

	public boolean init(Controller controller)
	{
		cg_OperationActivityQueryReqHandler = new CG_OperationActivityQueryReqHandler(this);
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_OPERATION_ACTIVITY_QUERY_REQ, GameProtocolsForClient.CG_OperationActivityQueryReq.getDefaultInstance()); 
		controller.addHandler(ClientProtocols.P_GAME_CG_OPERATION_ACTIVITY_QUERY_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_OperationActivityQueryReqHandler ));

		cg_OperationActivityPickRewardReqHandler = new CG_OperationActivityPickRewardReqHandler(this);
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_OPERATION_ACTIVITY_PICK_REWARD_REQ, GameProtocolsForClient.CG_OperationActivityPickRewardReq.getDefaultInstance()); 
		controller.addHandler(ClientProtocols.P_GAME_CG_OPERATION_ACTIVITY_PICK_REWARD_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_OperationActivityPickRewardReqHandler ));
		return true;
	}

	public boolean start(ActivityEnviroment activityEnv)
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
		int activityId = cd.get_OperationConfig().get_Operations().get_ActivityId();

		Activity operation = cd.get_ActivityConfig().GetActivityById(activityId);
		registerActivity(activityEnv, operation);

		return false;
	}

	//获取下一次重置时间，用于倒计时，
	//暂不支持相对时间设置
	public Long getPickRewardResetTime(int activityId, long time)
	{
		if (!elementMaps.containsKey(activityId))
		{
			return 0l;
		}

		ActivityElement element = elementMaps.get(activityId);
		ActivitySpecialTimeInfo timeInfo = element.getSpecialTimeByTime(time);
		if (timeInfo != null)
		{
			// 首先选中specialTime，然后判断reset是否有效
			if (timeInfo.getResetCount() == 0)
			{
				return timeInfo.getTimerList().getLast().getTimer();
			}

			// reset有效，下一个时间在timerList中
			for (ActivityTimerStatus timer : timeInfo.getTimerList())
			{
				if ((timer.getTimerStatus() & (_ActivityTimerStatus.Refresh | _ActivityTimerStatus.End)) > 0)
				{
					if (timer.getTimer() > time || time == 0)
					{
						return timer.getTimer();
					}
				}
			}

			return timeInfo.getCloseTime();
		}

		return 0l;
	}


	public void handleConfigRefresh(ConfigDatabase newCfg, ActivityEnviroment activityEnv)
	{
		int activityId = newCfg.get_OperationConfig().get_Operations().get_ActivityId();

		Activity operation = newCfg.get_ActivityConfig().GetActivityById(activityId);

		checkActivityTimeChanged(activityEnv, operation);
	}

	@Override
	protected ConcurrentLinkedDeque<ActivityTimerStatus> calcTimeListFromTimeCell(ActivitySpecialTime specialTime)
	{
		// 累计充值活动的TimeCell固定为2个,包含start和end
		ConcurrentLinkedDeque<ActivityTimerStatus> timerList = new ConcurrentLinkedDeque<ActivityTimerStatus>();
		ActivityTimerStatus activityTimerStatus = null;

		ActivityConfig.TimeCell timeCell = specialTime.Get_timeCellsByIndex(0);
		long noZone_ConfigTime = ClientServerCommon.ConvertTicksToMs.DateTimeToInt64(timeCell.GetStartDateTime());
		long purchaseStart = ServerUtil.getLongForJava(noZone_ConfigTime, TimeZoneData.getTimeZone());

		noZone_ConfigTime = ClientServerCommon.ConvertTicksToMs.DateTimeToInt64(timeCell.GetEndDateTime());
		long purchaseEnd = ServerUtil.getLongForJava(noZone_ConfigTime, TimeZoneData.getTimeZone());

		timeCell = specialTime.Get_timeCellsByIndex(1);
		noZone_ConfigTime = ClientServerCommon.ConvertTicksToMs.DateTimeToInt64(timeCell.GetStartDateTime());
		long rewardStart = ServerUtil.getLongForJava(noZone_ConfigTime, TimeZoneData.getTimeZone());

		noZone_ConfigTime = ClientServerCommon.ConvertTicksToMs.DateTimeToInt64(timeCell.GetEndDateTime());
		long rewardEnd = ServerUtil.getLongForJava(noZone_ConfigTime, TimeZoneData.getTimeZone());

		activityTimerStatus = new ActivityTimerStatus(purchaseStart, _ActivityTimerStatus.Client | _ActivityTimerStatus.Server | _ActivityTimerStatus.Start);
		timerList.add(activityTimerStatus);

		// 充值时间和领奖时间完全重叠时，重置周期有效，不重叠是，重置周期无效
		if (purchaseStart == rewardStart && purchaseEnd == rewardEnd)
		{
			Calendar cycleCalendar = Calendar.getInstance();
			TimeZone tz = TimeZone.getTimeZone(ServerUtil.getTimeZoneStringFromInt(TimeZoneData.getTimeZone()));
			cycleCalendar.setTimeZone(tz);
			cycleCalendar.setTimeInMillis(purchaseStart);

			while (true)
			{
				cycleCalendar.set(Calendar.SECOND, 0);
				cycleCalendar.set(Calendar.MINUTE, 0);
				cycleCalendar.set(Calendar.HOUR_OF_DAY, 0);
				cycleCalendar.add(Calendar.DAY_OF_YEAR, specialTime.get_resetCount());
				long cycleTime = cycleCalendar.getTimeInMillis();
				if (cycleTime < purchaseEnd)
				{
					activityTimerStatus = new ActivityTimerStatus(cycleTime, _ActivityTimerStatus.Client | _ActivityTimerStatus.Server | _ActivityTimerStatus.Refresh);
					timerList.add(activityTimerStatus);
				}
				else
				{
					break;
				}
			}

			activityTimerStatus = new ActivityTimerStatus(purchaseEnd, _ActivityTimerStatus.Client | _ActivityTimerStatus.Server | _ActivityTimerStatus.End);
			timerList.add(activityTimerStatus);
		}
		else
		{
			if (purchaseEnd <= rewardStart)
			{
				activityTimerStatus = new ActivityTimerStatus(purchaseEnd, _ActivityTimerStatus.Client | _ActivityTimerStatus.Server | _ActivityTimerStatus.End);
				timerList.add(activityTimerStatus);

				activityTimerStatus = new ActivityTimerStatus(rewardStart, _ActivityTimerStatus.Client | _ActivityTimerStatus.Server | _ActivityTimerStatus.RewardStart);
				timerList.add(activityTimerStatus);
			}
			else
			{
				activityTimerStatus = new ActivityTimerStatus(rewardStart, _ActivityTimerStatus.Client | _ActivityTimerStatus.Server | _ActivityTimerStatus.RewardStart);
				timerList.add(activityTimerStatus);

				activityTimerStatus = new ActivityTimerStatus(purchaseEnd, _ActivityTimerStatus.Client | _ActivityTimerStatus.Server | _ActivityTimerStatus.End);
				timerList.add(activityTimerStatus);
			}

			activityTimerStatus = new ActivityTimerStatus(rewardEnd, _ActivityTimerStatus.Client | _ActivityTimerStatus.Server | _ActivityTimerStatus.RewardEnd);
			timerList.add(activityTimerStatus);

			specialTime.set_resetCount(0);
			specialTime.set_resetType(_TimeDurationType.Unknown);;
		}

		//取倒数第二个点计算下一周期
		Iterator<ActivityTimerStatus> iter = timerList.descendingIterator();
		int i = 0;
		while (iter.hasNext())
		{
			ActivityTimerStatus timerStatus = iter.next();
			if (i == 2)
			{
				timerStatus.addTimerStatus(_ActivityTimerStatus.InformNext);
				break;
			}

			i++;
		}

		if (timerList.size() <= 2)
		{
			//
			timerList.getFirst().addTimerStatus(_ActivityTimerStatus.InformNext);
		}

		return timerList;
	}

	@Override
	public boolean isActivityActivate(int activityId, PlayerNode playerNode)
	{
		boolean result = checkIsStart(activityId, playerNode);

		return result;
	}

	public ActivitySpecialTimeInfo getNowPurchaseActivity(int activityId, long now)
	{
		ActivityElement element = elementMaps.get(activityId);
		if (element == null)
		{
			return null;
		}

		ActivitySpecialTimeInfo localInfo = element.getSpecialTimeByTime(now);
		if (localInfo == null)
		{
			return null;
		}

		return localInfo;
	}

	public int getNowActivityIndex(int activityId, long now)
	{
		ActivityElement element = elementMaps.get(activityId);
		if (element == null)
		{
			return -1;
		}

		ActivitySpecialTimeInfo localInfo = element.getSpecialTimeByTime(now);
		if (localInfo == null)
		{
			return -1;
		}

		return localInfo.getIndex() - 1;
	}

	public Long getPurchaseOpen(int activityId, ConfigDatabase cd, long now)
	{
		ActivitySpecialTimeInfo timeInfo = getNowPurchaseActivity(activityId, now);
		if (null == timeInfo)
		{
			return 0l;
		}
		//充值开启绝对时间，充值开启相对活动开启时间	
		for (ActivityTimerStatus timerStatus : timeInfo.getTimerList())
		{
			if ((timerStatus.getTimerStatus() & _ActivityTimerStatus.Start) > 0)
			{
				return timerStatus.getTimer();
			}
		}

		return timeInfo.getOpenTime();
	}

	public Long getPurchaseClose(int activityId, ConfigDatabase cd, long now)
	{
		ActivitySpecialTimeInfo timeInfo = getNowPurchaseActivity(activityId, now);
		if (null == timeInfo)
		{
			return 0l;
		}
		//充值开启绝对时间，充值开启相对活动开启时间	
		for (ActivityTimerStatus timerStatus : timeInfo.getTimerList())
		{
			if ((timerStatus.getTimerStatus() & _ActivityTimerStatus.End) > 0)
			{
				return timerStatus.getTimer();
			}
		}

		return timeInfo.getCloseTime();
	}

	public Long getPickRewardOpen(int activityId, ConfigDatabase cd, long now)
	{
		ActivitySpecialTimeInfo timeInfo = getNowPurchaseActivity(activityId, now);
		if (null == timeInfo)
		{
			return 0l;
		}

		for (ActivityTimerStatus timerStatus : timeInfo.getTimerList())
		{
			if ((timerStatus.getTimerStatus() & _ActivityTimerStatus.RewardStart) > 0)
			{
				return timerStatus.getTimer();
			}
		}

		return timeInfo.getOpenTime();
	}

	public Long getPickRewardClose(int activityId, ConfigDatabase cd, long now)
	{
		ActivitySpecialTimeInfo timeInfo = getNowPurchaseActivity(activityId, now);
		if (null == timeInfo)
		{
			return 0l;
		}

		for (ActivityTimerStatus timerStatus : timeInfo.getTimerList())
		{
			if ((timerStatus.getTimerStatus() & _ActivityTimerStatus.RewardEnd) > 0)
			{
				return timerStatus.getTimer();
			}
		}

		return timeInfo.getCloseTime();
	}
}
