package com.kodgames.corgi.server.gameserver.activity.activitymgr;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon._ActivityTimerStatus;
import ClientServerCommon._ActivityType;
import ClientServerCommon._TimeDurationType;

import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.activity.data.ActivityTimerStatus;
import com.kodgames.corgi.server.timer.TimerHandler;
import com.kodgames.corgi.server.timer.TimerMgr;

/*
 * 活动环境管理对象，为各逻辑模块提供活动注册和通知
 * 
 * @see 逻辑模块的调用流程
 * 逻辑模块继承@see ActivityHandler实现活动通知接口
 * @see 第一步调用@see getLastAbortActivity获取上一次异常结束的活动数据
 * 逻辑模块进行判断该活动是否结算或者丢弃等
 * @see 第二步，如果异常活动有需要继续注册的，调用@see registerActivity注册后续的时间点
 * @see 第三步调用@see registerActivityFromSettingByType按照类型注册启动后所有后续活动
 * 
 */
public class ActivityEnviroment implements TimerHandler
{
	public class OnceHandleActer implements Runnable
	{
		private ActivityHandler handler;
		private int activityID;
		private long openTime;
		private long closeTime;
		private int specialIndex;
		private int timerStatus;
		private int timerIndex;
		
		public OnceHandleActer(ActivityHandler handler, int activityID, long openTime, long closeTime, int specialIndex, int timerStatus, int timerIndex)
		{
			this.handler = handler;
			this.activityID = activityID;
			this.openTime = openTime;
			this.closeTime = closeTime;
			this.specialIndex = specialIndex;
			this.timerStatus = timerStatus;
			this.timerIndex = timerIndex;
		}

		@Override
		public void run()
		{
			this.handler.handleActivity(activityID, openTime, closeTime, specialIndex, timerStatus, timerIndex, 0, true);
		}
	}

	public class ActivityData
	{
		int timerIndex;
		int timeEnumStat;
		long openTime;
		long closeTime;
		int specialTimeIndex;
		int activityID;
		ActivityHandler handler;
	
		public ActivityData(int timerIndex, int timeEnumStat, long openTime, long closeTime, int specialTimeIndex, int activityID, ActivityHandler handler)
		{
			this.timerIndex = timerIndex;
			this.timeEnumStat = timeEnumStat;
			this.openTime = openTime;
			this.closeTime = closeTime;
			this.specialTimeIndex = specialTimeIndex;
			this.activityID = activityID;
			this.handler = handler;
		}
	}
	private static final Logger logger = LoggerFactory.getLogger(ActivityEnviroment.class);
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	//以活动id为单位存储的定时器id列表
	private ConcurrentHashMap<Integer, ConcurrentHashMap<Long, ConcurrentLinkedQueue<Integer>>> activityTimerLists = new ConcurrentHashMap<Integer, ConcurrentHashMap<Long, ConcurrentLinkedQueue<Integer>>>();
	private ConcurrentHashMap<Integer, ActivityData> timerActivityLists = new ConcurrentHashMap<Integer, ActivityData>(); // 活动与时间定时器ID列表，key-TimerID
																	// value-活动信息，包括当前处于的活动步骤，活动信息，处理对象信息
	
	private ConcurrentLinkedQueue<Thread> threadList = new ConcurrentLinkedQueue<Thread>();

	@Override
	public void handleTimeAction(int timerID)
	{
		ActivityData data = timerActivityLists.get(timerID);
		if (data != null)
		{
			logger.debug("handleTimeAction timerID = {}, activityID = {}, openTime = {}, closeTime = {}, specialIndex = {}, timerIndex = {}, status = {}",
				timerID, data.activityID, data.openTime, data.closeTime, data.specialTimeIndex, data.timerIndex, data.timeEnumStat);
			
			data.handler.handleActivity(data.activityID, data.openTime, data.closeTime, data.specialTimeIndex, data.timeEnumStat, data.timerIndex, 0, false);
		}
		else
		{
			logger.warn("handleTimeAction timerID {} not found activity", timerID);
		}
	}

	public ActivityEnviroment()
	{
	}

	//删除某个时间段的定时器
	public void removeTimerByActivityIDAndTime(int activityID, long openTime, long closeTime)
	{
		ConcurrentHashMap<Long, ConcurrentLinkedQueue<Integer>> timerIdList = activityTimerLists.get(activityID);
		if (timerIdList != null)
		{
			ConcurrentLinkedQueue<Integer> idList = timerIdList.get(openTime);
			if (idList != null)
			{
				Iterator<Map.Entry<Integer, ActivityData>> iter = timerActivityLists.entrySet().iterator();
				while (iter.hasNext())
				{
					Map.Entry<Integer, ActivityData> data = iter.next();
					if (idList.contains(data.getKey()))
					{
						iter.remove();
					}
				}
			}
			
			if (timerIdList.isEmpty())
			{
			activityTimerLists.remove(activityID);
			}
		}
	}
	
	public void registerSpecialTime(int activityId, ActivitySpecialTimeInfo timeInfo, ActivityHandler handler)
	{
		long now = System.currentTimeMillis();
		if (timeInfo.getCloseTime() != 0 && now >= timeInfo.getCloseTime())
		{
			//如果活动已结束，直接返回
			return;
		}
		
		if (!handler.isDurationType(timeInfo.getDurationType()))
		{
			// 如果当前时间段的最后一个时间点已结束
			if (now > timeInfo.getTimerList().getLast().getTimer())
			{
				// 非周期性的活动，代表本时间段已结束，不需要注册该活动
				return;
			}
			
			//插入周期开始点
			long startTime = timeInfo.getOpenTime();
			if (startTime >= timeInfo.getTimerList().getFirst().getTimer())
			{
				ActivityTimerStatus timerStatus = timeInfo.getTimerList().getFirst();
				timerStatus.addTimerStatus(_ActivityTimerStatus.DurationStart);
			}
			else
			{
				ActivityTimerStatus timerStatus = new ActivityTimerStatus(startTime, _ActivityTimerStatus.DurationStart);
				timeInfo.insertTimerStatus(timerStatus, true);
			}
			
			//插入周期结束点
			long endTime = timeInfo.getCloseTime();
			if (endTime <= timeInfo.getTimerList().getLast().getTimer())
			{
				ActivityTimerStatus timerStatus = timeInfo.getTimerList().getLast();
				timerStatus.addTimerStatus(_ActivityTimerStatus.DurationEnd );
			}
			else
			{
				ActivityTimerStatus timerStatus = new ActivityTimerStatus(endTime, _ActivityTimerStatus.DurationEnd);
				timeInfo.insertTimerStatus(timerStatus, false);
			}
		}
		else
		{		
			//插入周期开始点
			long startTime = getDurationStartTime(timeInfo);
			if (startTime >= timeInfo.getTimerList().getFirst().getTimer())
			{
				ActivityTimerStatus timerStatus = timeInfo.getTimerList().getFirst();
				timerStatus.addTimerStatus(_ActivityTimerStatus.DurationStart);
			}
			else
			{
				ActivityTimerStatus timerStatus = new ActivityTimerStatus(startTime, _ActivityTimerStatus.DurationStart);
				timeInfo.insertTimerStatus(timerStatus, true);
			}
			
			//插入周期结束点
			long endTime = getDurationEndTime(timeInfo);
			if (endTime <= timeInfo.getTimerList().getLast().getTimer())
			{
				ActivityTimerStatus timerStatus = timeInfo.getTimerList().getLast();
				timerStatus.addTimerStatus(_ActivityTimerStatus.DurationEnd);
			}
			else
			{
				ActivityTimerStatus timerStatus = new ActivityTimerStatus(endTime, _ActivityTimerStatus.DurationEnd);
				timeInfo.insertTimerStatus(timerStatus, false);
			}
			
			// 如果当前时间段的最后一个时间点已结束
			if (now > timeInfo.getTimerList().getLast().getTimer()) 
			{
				// 周期性的活动需要推算时间
				long interval = calcIntervalDurationToNow(timeInfo);

				// 将列表中时间点递推至当前周期段
				Iterator<ActivityTimerStatus> iter = timeInfo.getTimerList().iterator();

				while (iter.hasNext())
				{
					ActivityTimerStatus status = iter.next();
					status.addTimer(interval);
				}
			}

		}

		//周期通知点在注册时，由活动的逻辑模块将相应的timer置状态
		if (logger.isTraceEnabled())
		{
			String strOut = String.format("registerSpecialTime id %x timerCount %d openTime %s closeTime %s ###### ", activityId, 
				timeInfo.getTimerList().size(), dateFormat.format(timeInfo.getOpenTime()), dateFormat.format(timeInfo.getCloseTime()));
		
			for (ActivityTimerStatus timerStatus : timeInfo.getTimerList())
			{
				String tmp = String.format("%s--%s,  ", dateFormat.format(timerStatus.getTimer()), timerStatus.getTimerStatus());
				strOut += tmp;
			}
			logger.trace(strOut);
		}
		
		//如果当前活动处于活动过程中，要及时通知逻辑模块当前状态
		Iterator<ActivityTimerStatus> iter = timeInfo.getTimerList().iterator();
		boolean activeNow = false;
		int timerInformIndex = 0;
		while (iter.hasNext())
		{
			ActivityTimerStatus timerStatus = iter.next();
			if (timerStatus.getTimer() < System.currentTimeMillis())
			{
				activeNow = true;
				timerInformIndex++;
			}
		}
		
		timerInformIndex--;		//因为timerInformIndex指向了下一个未开始的时间点，所以需要减1
		ConcurrentHashMap<Long, ConcurrentLinkedQueue<Integer>> timerIDList = activityTimerLists.get(activityId);
		if (timerIDList == null)
		{
			timerIDList = new ConcurrentHashMap<Long, ConcurrentLinkedQueue<Integer>>();
			activityTimerLists.put(activityId, timerIDList);
		}
		
		ConcurrentLinkedQueue<Integer> idList = new ConcurrentLinkedQueue<Integer>();
		timerIDList.put(timeInfo.getOpenTime(), idList);
	
		// 将活动根据时间步骤进行拆分，向时间管理器注册多个定时器
		iter = timeInfo.getTimerList().iterator();
		int i = 0;
		while(iter.hasNext())
		{
			ActivityTimerStatus timer = iter.next();
			int timerID = TimerMgr.getTimerMgr().reigsterTimer(timer.getTimer(), timeInfo.getDurationType(), timeInfo.getCloseTime(), this);
			if (-1 != timerID)
			{
				timerActivityLists.put(timerID, new ActivityData(i, timer.getTimerStatus(), timeInfo.getOpenTime(),
					timeInfo.getCloseTime(), timeInfo.getIndex(), activityId, handler));
				idList.add(timerID);
			}
			if (activeNow && i == timerInformIndex)
			{
				Thread thread = new Thread(new OnceHandleActer(handler, activityId, timeInfo.getOpenTime(), timeInfo.getCloseTime(), timeInfo.getIndex(), timer.getTimerStatus(), i));
				threadList.add(thread);
				activeNow = false;
			}
			
			i++;
		}
	}
	
	private long getDurationStartTime(ActivitySpecialTimeInfo timeInfo)
	{
		TimeZone tz = TimeZone.getTimeZone(ServerUtil.getTimeZoneStringFromInt(TimeZoneData.getTimeZone()));
		
		//插入周期开始点
		long first = timeInfo.getTimerList().getFirst().getTimer();
		Calendar tmpCalendar = Calendar.getInstance(tz);
		tmpCalendar.setFirstDayOfWeek(Calendar.MONDAY);
		tmpCalendar.setTimeInMillis(first);
		switch (timeInfo.getDurationType())
		{
			case _TimeDurationType.Day:
				tmpCalendar.set(Calendar.SECOND, 0);
				tmpCalendar.set(Calendar.MINUTE, 0);
				tmpCalendar.set(Calendar.HOUR_OF_DAY, 0);
				break;
			case _TimeDurationType.Week:
				tmpCalendar.set(Calendar.SECOND, 0);
				tmpCalendar.set(Calendar.MINUTE, 0);
				tmpCalendar.set(Calendar.HOUR_OF_DAY, 0);
				tmpCalendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
				;
				break;
			case _TimeDurationType.Month:
				tmpCalendar.set(Calendar.SECOND, 0);
				tmpCalendar.set(Calendar.MINUTE, 0);
				tmpCalendar.set(Calendar.HOUR_OF_DAY, 0);
				tmpCalendar.set(Calendar.DAY_OF_MONTH, 1);
				break;
		}
		
		return tmpCalendar.getTimeInMillis() + 1000;
	}
	
	private long getDurationEndTime(ActivitySpecialTimeInfo timeInfo)
	{
		TimeZone tz = TimeZone.getTimeZone(ServerUtil.getTimeZoneStringFromInt(TimeZoneData.getTimeZone()));
		
		//插入周期开始点
		long last = timeInfo.getTimerList().getLast().getTimer();
		Calendar tmpCalendar = Calendar.getInstance(tz);
		tmpCalendar.setFirstDayOfWeek(Calendar.MONDAY);
		tmpCalendar.setTimeInMillis(last);
		switch (timeInfo.getDurationType())
		{
			case _TimeDurationType.Day:
				tmpCalendar.set(Calendar.SECOND, 0);
				tmpCalendar.set(Calendar.MINUTE, 0);
				tmpCalendar.set(Calendar.HOUR_OF_DAY, 0);
				tmpCalendar.add(Calendar.DAY_OF_WEEK, 1);
				break;
			case _TimeDurationType.Week:
				tmpCalendar.set(Calendar.SECOND, 0);
				tmpCalendar.set(Calendar.MINUTE, 0);
				tmpCalendar.set(Calendar.HOUR_OF_DAY, 0);
				tmpCalendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
				tmpCalendar.add(Calendar.WEEK_OF_YEAR, 1);
				break;
			case _TimeDurationType.Month:
				tmpCalendar.set(Calendar.SECOND, 0);
				tmpCalendar.set(Calendar.MINUTE, 0);
				tmpCalendar.set(Calendar.HOUR_OF_DAY, 0);
				tmpCalendar.set(Calendar.DAY_OF_MONTH, 1);
				tmpCalendar.add(Calendar.MONTH, 1);
				break;
		}
		
		return tmpCalendar.getTimeInMillis() - 1000;
	}
	
	private long calcIntervalDurationToNow(ActivitySpecialTimeInfo timeInfo)
	{
		TimeZone tz = TimeZone.getTimeZone(ServerUtil.getTimeZoneStringFromInt(TimeZoneData.getTimeZone()));
		Calendar tmpCalendar = Calendar.getInstance(tz);
		
		long closeTime = timeInfo.getTimerList().getLast().getTimer();
		tmpCalendar.setTimeInMillis(closeTime);
		long now = System.currentTimeMillis();

		while (tmpCalendar.getTimeInMillis() <= now)
		{
			switch (timeInfo.getDurationType())
			{
				case _TimeDurationType.Day:
					tmpCalendar.add(Calendar.DAY_OF_YEAR, 1);
					break;
				case _TimeDurationType.Week:
					tmpCalendar.add(Calendar.WEEK_OF_YEAR, 1);
					break;
				case _TimeDurationType.Month:
					tmpCalendar.add(Calendar.MONTH, 1);
					break;
			}
		}

		// 获取递进的时间差值
		return tmpCalendar.getTimeInMillis() - closeTime;
	}
	
	public void checkRegisterInform()
	{
		for (Thread thread : threadList)
		{
			thread.start();
		}
		
		threadList.clear();
	}
}
