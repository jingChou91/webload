package com.kodgames.corgi.server.gameserver.activity.operationactivty.data;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.OperationConfig;
import ClientServerCommon.OperationConfig.OperationInfo;

import com.kodgames.corgi.protocol.DBProtocolsForServer.AccumulateDB;

public class AccumulateActivity
{
	private int cycleMoney;// 本周期内充值记录
	private int activityId = 0;//活动Id;
	private long lastFreshTime = System.currentTimeMillis();//上次刷新时间
	private Map<Integer, OperationItem> operationItemList = new HashMap<Integer, OperationItem>();
	
	public int getActivityId()
	{
		return activityId;
	}
	public void setActivityId(int activityId)
	{
		this.activityId = activityId;
	}
	
	public Map<Integer, OperationItem> getOperationItemList()
	{
		return this.operationItemList;
	}
	
	public void setOperationItemList(Map<Integer, OperationItem> operationItemList)
	{
		this.operationItemList = operationItemList;
	}
	
	public void put(int itemId, OperationItem operationItem)
	{
		operationItemList.put(itemId, operationItem);
	}
	public int getCycleMoney() 
	{
		return cycleMoney;
	}
	public void setCycleMoney(int cycleMoney) 
	{
		this.cycleMoney = cycleMoney;
	}
	public boolean isNeedInit(int activityId) 
	{
		return this.activityId == 0;
	}
	public void addCycleMoney(int rmb) 
	{
		this.cycleMoney += rmb;
	}
	public long getLastFreshTime() 
	{
		return lastFreshTime;
	}
	public void setLastFreshTime(long lastFreshTime)
	{
		this.lastFreshTime = lastFreshTime;
	}
	
	public void fromProtoBuf(AccumulateDB accumulateDB)
	{
		this.setActivityId(accumulateDB.getActivityId());
		this.setCycleMoney(accumulateDB.getCycleMoney());
		this.setLastFreshTime(accumulateDB.getLastFreshTime());
		Map<Integer, OperationItem> operationItemList = new HashMap<Integer, OperationItem>();
		for(AccumulateDB.OperationItem operationItemDB: accumulateDB.getOperationItemsList())
		{
			OperationItem operationItem = new OperationItem();
			operationItem.setItemId(operationItemDB.getItemId());
			operationItem.setAccumulateActivity(this);
			operationItem.setCurrentPickCount(operationItemDB.getCurrentPickCount());
			operationItemList.put(operationItem.getItemId(), operationItem);
		}
		this.setOperationItemList(operationItemList);
	}
	public AccumulateDB toProtobuf()
	{
		AccumulateDB.Builder accumulateActivityBuilder = AccumulateDB.newBuilder(); 
		accumulateActivityBuilder.setActivityId(this.getActivityId());
		accumulateActivityBuilder.setCycleMoney(this.getCycleMoney());
		accumulateActivityBuilder.setLastFreshTime(this.getLastFreshTime());
		for(Entry<Integer, OperationItem> operationSet : operationItemList.entrySet())
		{
			AccumulateDB.OperationItem.Builder operationItemBuilder = AccumulateDB.OperationItem.newBuilder(); 
			operationItemBuilder.setItemId(operationSet.getKey());
			operationItemBuilder.setCurrentPickCount(operationSet.getValue().getCurrentPickCount());
			accumulateActivityBuilder.addOperationItems(operationItemBuilder);
		}
		return accumulateActivityBuilder.build();
	}
	
	public void addAccumulateActivity(int activityId, ConfigDatabase cd, int index)
	{
		this.setActivityId(activityId);
		ClientServerCommon.OperationConfig.Operation operation = cd.get_OperationConfig().getOperationById(activityId);
		OperationInfo info = operation.Get_OperationInfosByIndex(index);
		int count = info.Get_OperationItemsCount();
		OperationConfig.OperationItem operationActivityItem = null;
		OperationItem operationItem = null;
		this.getOperationItemList().clear();
		for (int i = 0; i < count; i++)
		{
			operationActivityItem = info.Get_OperationItemsByIndex(i);
			operationItem = new OperationItem();
			operationItem.setAccumulateActivity(this);
			operationItem.setItemId(operationActivityItem.get_ItemId());
			this.put(operationActivityItem.get_ItemId(), operationItem);
		}
	}
	
	/**
	 * 清除玩家本周期内所有数据
	 */
	public void clear()
	{
		this.cycleMoney = 0;// 本周期内充值记录
		this.activityId = 0;//活动Id;
		this.lastFreshTime = System.currentTimeMillis();//上次刷新时间
		this.operationItemList.clear();
	}
	
	public boolean checkData(ConfigDatabase cd)
	{
		ClientServerCommon.OperationConfig operationConfig = cd.get_OperationConfig();
		ClientServerCommon.OperationConfig.OperationItem item = null;
		boolean isNeedClear = false;
		for(Entry<Integer, OperationItem> operationSet : operationItemList.entrySet())
		{
			item = operationConfig.getOperationItemById(operationSet.getKey());
			// 玩家身上存在配置文件中没有的条目
			if(null == item )
			{
				isNeedClear = true;
				break;
			}
		}
		if(isNeedClear)
		{
			this.clear();
			return true;
		}
		return false;
	}
}

