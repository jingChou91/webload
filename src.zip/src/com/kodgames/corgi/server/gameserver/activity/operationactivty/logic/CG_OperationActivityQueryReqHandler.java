package com.kodgames.corgi.server.gameserver.activity.operationactivty.logic;

import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.OperationConfig;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.ActivityHandleOperationActivityManager;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.data.AccumulateActivity;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.data.OperationActivityMgr;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.data.OperationItem;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.db.AccumulateDB;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_OperationActivityQueryReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_OperationActivityQueryReqHandler.class);

	private ActivityHandleOperationActivityManager activityHandleOperationActivityManager = null;
	public CG_OperationActivityQueryReqHandler(ActivityHandleOperationActivityManager activityHandleOperationActivityManager)
	{
		this.activityHandleOperationActivityManager = activityHandleOperationActivityManager;
	}
	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv ActivityHandleOperationActivityManager, playerId = {}", sender.getClientUID().getPlayerID());
		GameProtocolsForClient.CG_OperationActivityQueryReq request =(GameProtocolsForClient.CG_OperationActivityQueryReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);
		boolean isRefresh = false;
		GameProtocolsForClient.GC_OperationActivityQueryRes.Builder builder = GameProtocolsForClient.GC_OperationActivityQueryRes.newBuilder();

		int result = ClientProtocols.E_GAME_OPERATION_ACTIVITY_QUERY_SUCCESS;
		int playerId = sender.getClientUID().getPlayerID();
		
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		
		OperationConfig operationConfig = cd.get_OperationConfig();
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);	
			do
			{		
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_OPERATION_ACTIVITY_QUERY_FAILED_LOAD_PLAYER;
					break;
				}
				if(null == operationConfig)
				{
					result = ClientProtocols.E_GAME_OPERATION_ACTIVITY_QUERY_FAILED_LOAD_CONFIG;
					break;
				}
				
				
				long now = System.currentTimeMillis();
				//刷新数据,返回值表示是否刷新了数据
				if(OperationActivityMgr.getInstance().refreshAccumulateData(now, playerNode, cd))
				{
					isRefresh = true;
				}
				
				int activityId = cd.get_OperationConfig().get_Operations().get_ActivityId();
				
				boolean isStart = activityHandleOperationActivityManager.isActivityActivate(activityId, playerNode);
				if(!isStart)
				{
					result = ClientProtocols.E_GAME_QUERY_ACCUMULATE_FAILED_ACTIVITY_START_FAILED;
					break;
				}
				
				boolean isNeedInit = playerNode.getPlayerInfo().getOperationActivityData().getAccumulateActivity().isNeedInit(activityId);
				
				AccumulateActivity accumulateActivity = null;
				if(isNeedInit)
				{
					isRefresh = true;
					AccumulateActivity accumulateActivityNew = new AccumulateActivity();
					int index = activityHandleOperationActivityManager.getNowActivityIndex(activityId, now);
					if (index != -1)
					{
						accumulateActivityNew.addAccumulateActivity(activityId, cd, index);
						playerNode.getPlayerInfo().getOperationActivityData().setAccumulateActivity(accumulateActivityNew);
					}
				}
				
				accumulateActivity = playerNode.getPlayerInfo().getOperationActivityData().getAccumulateActivity();
				
				builder.setActivityId(activityId);
				builder.setCycleMoney(accumulateActivity.getCycleMoney());
				for(Entry<Integer, OperationItem> itemId :accumulateActivity.getOperationItemList().entrySet())
				{
					builder.addOperationActivityItems(itemId.getValue().toProtoBuf(cd));
				}
				
				builder.setOperationIndex(activityHandleOperationActivityManager.getNowActivityIndex(activityId, now));
				builder.setPurchaseOpenTime(activityHandleOperationActivityManager.getPurchaseOpen(activityId, cd, now));
				builder.setPurchaseCloseTime(activityHandleOperationActivityManager.getPurchaseClose(activityId, cd, now));
				builder.setPickRewardOpenTime(activityHandleOperationActivityManager.getPickRewardOpen(activityId, cd, now));
				builder.setPickRewardCloseTime(activityHandleOperationActivityManager.getPickRewardClose(activityId, cd, now));
				isRefresh = true;
			} while (false);
			if(isRefresh)//更改内存，存库
			{
				AccumulateDB.updateAccumulateData(playerNode);
			}
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);		
		}
		builder.setCallback(request.getCallback());
		builder.setResult(result);

		ServerDataGS.transmitter.sendToClient(sender, ClientProtocols.P_GAME_GC_OPERATION_ACTIVITY_QUERY_RES, builder.build());
		return HandlerAction.TERMINAL;
	}
}
