package com.kodgames.corgi.server.gameserver.activity.fixtime.data;

public class PlayerFixedTimeActivityData
{
	private long lastGetTime; //上次领取定点活动奖励的时间

	public long getLastGetTime()
	{
		return lastGetTime;
	}

	public void setLastGetTime(long lastGetTime) 
	{
		this.lastGetTime = lastGetTime;
	}
}
