package com.kodgames.corgi.server.gameserver.activity.data;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import ClientServerCommon._TimeDurationType;

import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.CommonProtocols.ActivityTimer;

public class ActivityInfo
{
	private int resetType;
	private long openTime;
	private long closeTime;
	private List<ActivityTimer> times = new ArrayList<ActivityTimer>();
	
	private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	//isSercet用于特殊处理秘境，将openTime和CloseTime强制设置为本周期的开始和结束
	public ActivityInfo(int resetType, long openTime, long closeTime, List<ActivityTimer> timesList, boolean isSercet)
	{
		this.resetType = resetType;
		this.openTime = openTime;
		this.closeTime = closeTime;
		if (null != timesList && timesList.size() >= 1) 
		{
			times.addAll(timesList);
		}

		// 只有秘境进行该处理
		if (isSercet) 
		{
			switch (resetType) {
			case _TimeDurationType.Day:
			case _TimeDurationType.Week:
			case _TimeDurationType.Month:
				this.openTime = timesList.get(0).getTimer();
				this.closeTime = timesList.get(timesList.size() - 1).getTimer();
			case _TimeDurationType.Year:
			default:
				return;
			}
		}
	}

	public CommonProtocols.ActivityInfo toBuffer()
	{
		CommonProtocols.ActivityInfo.Builder builder = CommonProtocols.ActivityInfo.newBuilder();
		builder.setResetType(resetType);
		builder.setOpenTime(this.openTime);
		builder.setCloseTime(this.closeTime);
		for (ActivityTimer a : times)
		{
			builder.addTimes(a);
		}
		return builder.build();
	}
	
	public String toString()
	{
		String rtn = String.format("resetType %d openTime %s closeTime %s  ####", resetType, dateFormat.format(openTime), dateFormat.format(closeTime));
		
		for (ActivityTimer timer : times)
		{
			String tmp = String.format("%s--%x, ", dateFormat.format(timer.getTimer()), timer.getStatus());
			rtn += tmp;
		}
		
		return rtn;
	}
}
