package com.kodgames.corgi.server.gameserver.activity.operationactivty.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;
import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.gamedata.dbcommon.DBEasy;
import com.kodgames.gamedata.player.PlayerNode;

//运营活动初始化
public class RowOperationActivity
{
	private static final Logger logger = LoggerFactory.getLogger(RowOperationActivity.class);

	
	//游戏初始化，加载玩家游戏累计充值活动数据
	public static void selectOperationActivity(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs,
		PlayerNode playerNode)
		throws SQLException
	{
		String sql = "select * from operation_activity where player_id = " + playerNode.getPlayerId();
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, null);
		if (vrs[queryIndex] != null)
		{
			CachedRowSet rs = vrs[queryIndex];
			while (rs.next())
			{
				byte[] buffer = rs.getBytes("accumulates");
				
				DBProtocolsForServer.AccumulateDB.Builder builder = DBProtocolsForServer.AccumulateDB.newBuilder();

				if (buffer != null && buffer.toString() != "")
				{
					try
					{
						builder.mergeFrom(buffer);
					}
					catch (InvalidProtocolBufferException e)
					{
						logger.error(ExceptionUtils.getStackTrace(e));
					}
					playerNode.getPlayerInfo().getOperationActivityData().getAccumulateActivity().fromProtoBuf(builder.build());
				}
			}
		}
	}
}
