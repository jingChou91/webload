package com.kodgames.corgi.server.gameserver.activity.operationactivty.data;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.protocol.CommonProtocols.OperationActivityItem;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Reward;

public class OperationItem
{
	private int itemId;
	private int currentPickCount;//最后周期领取次数
	private AccumulateActivity accumulateActivity;
	
	public int getItemId() 
	{
		return itemId;
	}
	public void setItemId(int itemId) 
	{
		this.itemId = itemId;
	}
	public int getCurrentPickCount() 
	{
		return currentPickCount;
	}
	public void setCurrentPickCount(int currentPickCount) 
	{
		this.currentPickCount = currentPickCount;
	}
	
	public Reward pickAccumulateReward(PlayerNode playerNode, ClientServerCommon.OperationConfig cfgOperation, long nowTime)
	{
		Reward reward = new Reward();
		int currentPurchaseCount = this.accumulateActivity.getCycleMoney()/ cfgOperation.getOperationItemById(itemId).get_CompareValue();
		int cycleMaxCount = cfgOperation.getOperationItemById(getItemId()).get_CycleMaxCount();
		ClientServerCommon.OperationConfig.OperationItem cfgOperationItem = cfgOperation.getOperationItemById(getItemId());
		this.accumulateActivity.setLastFreshTime(nowTime);
		int nowAvailablePickCount = (currentPurchaseCount > cycleMaxCount ? cycleMaxCount : currentPurchaseCount) - getCurrentPickCount();
		if(nowAvailablePickCount > 0)
		{		
			for(int i = 0; i < cfgOperationItem.Get_RewardsCount(); ++i)
			{
				Reward oneReward = new Reward();
				oneReward.fromClientServerCommon(cfgOperationItem.Get_RewardsByIndex(i));	
				reward.megerReward(oneReward);
			}
			// 小绿点
			playerNode.getPlayerInfo().getAssisantData().getAccumulateActivity().notifyObservers();
			this.currentPickCount++;			
		}
		return reward;
	}
	
	public OperationActivityItem toProtoBuf(ConfigDatabase cd)
	{
		com.kodgames.corgi.protocol.CommonProtocols.OperationActivityItem.Builder builder = com.kodgames.corgi.protocol.CommonProtocols.OperationActivityItem.newBuilder();
		builder.setItemId(this.itemId);
		
		ClientServerCommon.OperationConfig.OperationItem itemConfig = cd.get_OperationConfig().getOperationItemById(this.itemId);
		int currentPurchaseCount = this.accumulateActivity.getCycleMoney()/ itemConfig.get_CompareValue();
		
		int min = currentPurchaseCount >= itemConfig.get_CycleMaxCount() ? itemConfig.get_CycleMaxCount() : currentPurchaseCount;
		int couldPickCounts= min - currentPickCount;
		if(couldPickCounts < 0)
		{
			couldPickCounts = 0;
		}
		builder.setIsEverPurchase(currentPurchaseCount >= 1);
		builder.setCouldPickCounts(couldPickCounts);
		return builder.build();
	}
	
	public boolean isCouldPickReward(ConfigDatabase cd)
	{
		ClientServerCommon.OperationConfig.OperationItem itemConfig = cd.get_OperationConfig().getOperationItemById(this.itemId);
		
		int currentPurchaseCount = this.accumulateActivity.getCycleMoney()/ itemConfig.get_CompareValue();
		int min = currentPurchaseCount >= itemConfig.get_CycleMaxCount() ? itemConfig.get_CycleMaxCount() : currentPurchaseCount;
		int couldPickCounts= min - currentPickCount;
		if(couldPickCounts < 0)
		{
			couldPickCounts = 0;
		}
		return couldPickCounts>=1;
		
	}
	public AccumulateActivity getAccumulateActivity() {
		return this.accumulateActivity;
	}
	public void setAccumulateActivity(AccumulateActivity accumulateActivity) {
		this.accumulateActivity = accumulateActivity;
	}
}