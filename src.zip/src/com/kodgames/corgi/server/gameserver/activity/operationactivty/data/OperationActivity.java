package com.kodgames.corgi.server.gameserver.activity.operationactivty.data;



public class OperationActivity
{
	private AccumulateActivity accumulateActivity = new AccumulateActivity();//累计充值活动
	
	public AccumulateActivity getAccumulateActivity()
	{
		return this.accumulateActivity;
	}	
	
	public void setAccumulateActivity(AccumulateActivity accumulateActivity)
	{
		this.accumulateActivity = accumulateActivity;
	}
}
