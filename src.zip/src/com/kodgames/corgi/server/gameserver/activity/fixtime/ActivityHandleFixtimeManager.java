package com.kodgames.corgi.server.gameserver.activity.fixtime;

import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ActivityConfig.FixedTimeActivity;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.TaskConfig._TaskType;
import ClientServerCommon._ActivityTimerStatus;
import ClientServerCommon._ActivityType;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityEnviroment;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityHandler;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivitySpecialTimeInfo;
import com.kodgames.corgi.server.gameserver.activity.data.ActivityTimerStatus;
import com.kodgames.corgi.server.gameserver.activity.fixtime.logic.CG_GetFixedTimeRewardReqHandler;
import com.kodgames.corgi.server.gameserver.activity.fixtime.logic.CG_QueryGetFixedTimeRewardReqHandler;
import com.kodgames.corgi.server.gameserver.task.timer.GlobalTimerMgr;
import com.kodgames.gamedata.player.PlayerNode;

public class ActivityHandleFixtimeManager extends ActivityHandler
{
	private static final Logger logger = LoggerFactory.getLogger(ActivityHandleFixtimeManager.class);

	public static long noticeTime;
	private int status = _ActivityTimerStatus.Unknown;

	private CG_GetFixedTimeRewardReqHandler  cG_GetFixedTimeActivityRewardReqHandler = null;
	private CG_QueryGetFixedTimeRewardReqHandler  cg_QueryGetFixedTimeRewardReqHandler = null;

	public ActivityHandleFixtimeManager()
	{
		super(_ActivityType.GETFIXTEDTIMEACTIVITY);
	}

	@Override
	public boolean handleActivity(int activityID, long openTime, long closeTime, int specialIndex, int timerStatus,
			int timerIndex, int playerId, boolean startOnce)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if (!super.handleActivity(activityID, openTime, closeTime, specialIndex, timerStatus, timerIndex, playerId, startOnce))
		{
			return false;
		}

		if ((timerStatus & (_ActivityTimerStatus.DurationStart | _ActivityTimerStatus.DurationEnd)) == 0)
		{
			ActivitySpecialTimeInfo timeInfo = todayTimerList.get(activityID);
			if (timeInfo == null || timeInfo.getTimerList() == null)
			{
				logger.warn("FixtimeManagerActivity can't found id {} timeInfo but super found", activityID);
				return false;
			}

			ActivityTimerStatus activityTimerStatus = (ActivityTimerStatus)(timeInfo.getTimerList().toArray()[timerIndex]);
			ActivityHandleFixtimeManager.noticeTime = activityTimerStatus.getTimer();
			
			String strOut = String.format("ActivityHandleFixtimeManager id %x noticeTime %s timerStatus %x ", activityID, 
					dateFormat.format(activityTimerStatus.getTimer()), timerStatus);
			logger.debug(strOut);
			logger.debug("ActivityHandleFixtimeManager specialIndex = {}, timerIndex = {}, timerStatus = {}, playerId = {}, startOnce = {}", specialIndex,timerIndex, timerStatus, playerId, startOnce);

			
			this.status = timerStatus;
			GlobalTimerMgr.getInstance().execute(_TaskType.FixTimeRewardAssistant, 0);
		}

		return true;
	}

	public boolean init(Controller controller)
	{
		cG_GetFixedTimeActivityRewardReqHandler = new CG_GetFixedTimeRewardReqHandler();
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_GET_FIXEDTIME_ACTIVITY_REWARD_REQ, GameProtocolsForClient.CG_GetFixedTimeActivityRewardReq.getDefaultInstance()); 
		controller.addHandler(ClientProtocols.P_GAME_CG_GET_FIXEDTIME_ACTIVITY_REWARD_REQ, ServerUtil.getFacilityMessageHandlerFactory(cG_GetFixedTimeActivityRewardReqHandler ));

		cg_QueryGetFixedTimeRewardReqHandler = new CG_QueryGetFixedTimeRewardReqHandler();
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_GET_FIXEDTIME_ACTIVITY_REWARD_REQ, GameProtocolsForClient.CG_QueryGetFixedTimeActivityRewardReq.getDefaultInstance()); 
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_GET_FIXEDTIME_ACTIVITY_REWARD_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryGetFixedTimeRewardReqHandler ));
		return true;
	}

	public boolean start(ActivityEnviroment activityEnv)
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
		registerActivity(activityEnv, cd.get_ActivityConfig().get_fixedTimeActivity().get_activity());
		return false;
	}

	public boolean isActivityActivate(int activityId, PlayerNode playerNode)
	{
		if (!super.checkIsStart(activityId, playerNode))
		{
			return false;
		}
		return (status & _ActivityTimerStatus.Start) > 0;
	}

	public void handleConfigRefresh(ConfigDatabase newCfg, ActivityEnviroment activityEnv)
	{
		FixedTimeActivity fixedTimeActivity = newCfg.get_ActivityConfig().get_fixedTimeActivity();
		checkActivityTimeChanged(activityEnv, fixedTimeActivity.get_activity());
	}
}
