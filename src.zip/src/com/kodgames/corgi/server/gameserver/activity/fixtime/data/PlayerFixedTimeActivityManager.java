package com.kodgames.corgi.server.gameserver.activity.fixtime.data;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._ActivityType;

import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityMgr;
import com.kodgames.corgi.server.gameserver.activity.fixtime.ActivityHandleFixtimeManager;
import com.kodgames.gamedata.player.PlayerDB;
import com.kodgames.gamedata.player.PlayerNode;

public class PlayerFixedTimeActivityManager
{
	public static void updateFixedTimeActivityInfo(PlayerNode playerNode, long lastUpdateTime)
	{
		playerNode.getPlayerInfo().getPlayerFixedTimeActivityData().setLastGetTime(lastUpdateTime);
		PlayerDB.updateFixTimeActivty(playerNode.getPlayerId(), lastUpdateTime);
	}
	
	public static Boolean isCanGetRewad(PlayerNode playerNode)
	{
		ConfigDatabase cd=CfgDB.getPlayerConfig(playerNode.getPlayerId());
		ClientServerCommon.ActivityConfig.FixedTimeActivity fixedTimeActivity = cd.get_ActivityConfig().get_fixedTimeActivity();
	
		int activityId = fixedTimeActivity.get_activity().get_activityId();
		PlayerFixedTimeActivityData fixedTimeActivityInfo = playerNode.getPlayerInfo().getPlayerFixedTimeActivityData();
		boolean isStart = ActivityMgr.getInstance().checkIsStart(_ActivityType.GETFIXTEDTIMEACTIVITY, activityId, playerNode);
		if(isStart)
		{
			long lastGetTime = fixedTimeActivityInfo.getLastGetTime();
			if (lastGetTime < ActivityHandleFixtimeManager.noticeTime)
			{
				return true;
			}
		}
		return false;
	}
}
