package com.kodgames.corgi.server.gameserver.activity.operationactivty.db;

import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.data.AccumulateActivity;
import com.kodgames.gamedata.player.PlayerNode;

public class AccumulateDB {
	public static void updateAccumulateData(PlayerNode playerNode)
	{
		AccumulateActivity accumulateData =
			playerNode.getPlayerInfo().getOperationActivityData().getAccumulateActivity();

		String sql =
			String.format("replace into operation_activity (accumulates, player_id) values( %s, %d)",
				ServerUtil.toHexString(accumulateData.toProtobuf().toByteArray()),
				playerNode.getPlayerId());
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerNode.getPlayerId(), sql);
	}
}
