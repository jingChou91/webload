package com.kodgames.corgi.server.gameserver.activity.activitymgr;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentSkipListSet;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.LoopRunnable;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.activity.data.ActivityData;
import com.kodgames.corgi.server.gameserver.activity.data.ActivityNotify;
import com.kodgames.gamedata.player.PlayerNode;

/*
 * 通知玩家活动的下一周期时间数据，同种类型的时间周期，只能有一个通知
 */
public class ActivityNotifyRunnable extends LoopRunnable
{
	private static final long SleepTime = 1 * 1000;
	private final Logger logger = LoggerFactory.getLogger(ActivityNotifyRunnable.class); 
	
	private ConcurrentLinkedQueue<ActivityData> commonData = new ConcurrentLinkedQueue<ActivityData>();
	//高优先级数据，需要快速推送，一般是玩家上线时触发的数据
	private ConcurrentHashMap<Integer, ConcurrentLinkedQueue<ActivityData>> highPriorityPlayerData = new ConcurrentHashMap<Integer, ConcurrentLinkedQueue<ActivityData>>();
	//触发的玩家数据，需要暂停发送，等该玩家queryInitInfo完成后，才能进行通知
	private ConcurrentHashMap<Integer, ConcurrentLinkedQueue<ActivityData>> playerDataQueue = new ConcurrentHashMap<Integer, ConcurrentLinkedQueue<ActivityData>>();

	public ActivityNotifyRunnable()
	{
		super(SleepTime);
	}

	@Override
	public synchronized void execute()
	{
		notifyToClient();
	}
	
	public void addData(ActivityData activityData, int playerId)
	{
		if (playerId == 0)
		{
			commonData.add(activityData);
		}
		else
		{
			ConcurrentLinkedQueue<ActivityData> dataList = playerDataQueue.get(playerId);
			if (dataList == null)
			{
				dataList = new ConcurrentLinkedQueue<ActivityData>();
				playerDataQueue.put(playerId, dataList);
			}

			dataList.add(activityData);
		}
	}
	
	public void informSend(int playerId)
	{
		ConcurrentLinkedQueue<ActivityData> dataList = playerDataQueue.get(playerId);
		if (null == dataList)
		{
			return;
		}
		
		playerDataQueue.remove(playerId);
		highPriorityPlayerData.put(playerId, dataList);
	}
	
	private void notifyActivity(int playerId, ActivityNotify activityNotify)
	{
		logger.debug("notifyActivity playerId {} notify {}", playerId, activityNotify.toString());
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_NOTIFY_RES);
		protocol.setProtoBufMessage(activityNotify.toBuff());
		ServerDataGS.transmitter.sendToClient(playerId, protocol);
	}
	
	private void sendHighPriorityData()
	{
		ConcurrentHashMap<Integer, ConcurrentLinkedQueue<ActivityData>> tmpDatas = highPriorityPlayerData;
		highPriorityPlayerData = new ConcurrentHashMap<Integer, ConcurrentLinkedQueue<ActivityData>>();
		for (Map.Entry<Integer, ConcurrentLinkedQueue<ActivityData>> entry : tmpDatas.entrySet())
		{
			ActivityNotify activityNotify = new ActivityNotify();
			for (ActivityData activityData : entry.getValue())
			{
				activityNotify.add(activityData);
				logger.debug("sendHighPriorityData  playerId={}， activityId={}  ", entry.getKey(), activityData.getActivityId());
			}
			
			notifyActivity(entry.getKey(), activityNotify);
		}
		
		tmpDatas.clear();
	}
	
	private void sendData()
	{
		ActivityNotify activityNotify = new ActivityNotify();
		ConcurrentLinkedQueue<ActivityData> tmpDatas = commonData;
		commonData = new ConcurrentLinkedQueue<ActivityData>();
		ActivityData data= null;
		while (!tmpDatas.isEmpty()) 
		{
			data = tmpDatas.poll();
			logger.debug("activityNofity  activityId={}  ", data.getActivityId());
			activityNotify.add(data);
		}
		
		if(activityNotify.getSize() > 0)
		{
			try
			{
				int i = 0;
				ConcurrentSkipListSet<Integer> onlinePlayerIds = ServerDataGS.playerManager.getOnlinePlayerIdsClone();
				for(Integer playerId : onlinePlayerIds)
				{
					PlayerNode playerNode = ServerDataGS.playerManager.getMemoryPlayerNode(playerId);
					if(playerNode != null && playerNode.getPlayerInfo() != null)
					{
						i++;
						if(i % 500 == 0)
						{
							//检查是否有紧急数据
							sendHighPriorityData();
							
							Thread.sleep(500l);
						}
						notifyActivity(playerId, activityNotify);
					}
				}
			}
			catch(Exception e)
			{
				logger.error("notifyToClient sleep error ", ExceptionUtils.getStackTrace(e));
			}
		}
	}
	
	private void notifyToClient()
	{
		sendHighPriorityData();
		sendData();
	}

}
