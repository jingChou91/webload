package com.kodgames.corgi.server.gameserver.activity.fixtime.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import system.DateTime;
import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.friendcampaignrank.util.FCRankTimeUtil;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Reward;

public class CG_QueryGetFixedTimeRewardReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_QueryGetFixedTimeRewardReqHandler.class);
	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_GetFixedTimeActivityRewardReqHandler, playerId = {}", sender.getClientUID().getPlayerID());
		GameProtocolsForClient.CG_QueryGetFixedTimeActivityRewardReq request = (GameProtocolsForClient.CG_QueryGetFixedTimeActivityRewardReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GameProtocolsForClient.GC_QueryGetFixedTimeActivityRewardRes.Builder builder = GameProtocolsForClient.GC_QueryGetFixedTimeActivityRewardRes.newBuilder();

		int result = ClientProtocols.P_GAME_CG_QUERY_GET_FIXEDTIME_ACTIVITY_REWARD_SUCCESS;
		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		ClientServerCommon.ActivityConfig.FixedTimeActivity fixedTimeActivity = cd.get_ActivityConfig().get_fixedTimeActivity();

		do
		{
			PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);			
			if (playerNode == null || playerNode.getPlayerInfo() == null)
			{
				result = ClientProtocols.E_GAME_CG_QURY_GET_FIXEDTIME_REWARD_FAILED_LOAD_PLAYER;
				break;
			}
			if(null == fixedTimeActivity)
			{
				result = ClientProtocols.E_GAME_CG_QURY_GET_FIXEDTIME_REWARD_FAILED_LOAD_CONFIG;
				break;
			}
			
			long lastGetTime = playerNode.getPlayerInfo().getPlayerFixedTimeActivityData().getLastGetTime();
			
			//因客户端线上bug,临时解决方案，当lastGetTime不是今天，即发给客户端0
			DateTime refreshTime =  cd.get_FriendCampaignConfig().get_FCRankRefreshDateTime();
			if(!FCRankTimeUtil.inCurrentCycle(lastGetTime, System.currentTimeMillis(), refreshTime))
			{
				lastGetTime = 0;
			}
			
			builder.setLastGetTime(lastGetTime);
			int rewardCount = fixedTimeActivity.Get_rewardCount();
			Reward reward = new Reward();
			for(int i =0; i < rewardCount; i++)
			{
				Reward rewardTemp = new Reward();
				rewardTemp = rewardTemp.fromClientServerCommon(fixedTimeActivity.Get_rewardByIndex(i));
				reward.megerReward(rewardTemp);
				builder.addReward(reward.toProtobuf());
			}
			builder.setResetType(fixedTimeActivity.get_activity().Get_specialTimesByIndex(0).get_resetType());
			
		} while (false);

		builder.setCallback(request.getCallback());
		builder.setResult(result);

		ServerDataGS.transmitter.sendToClient(sender,
			ClientProtocols.P_GAME_GC_QUERY_GET_FIXEDTIME_ACTIVITY_REWARD_RES,
			builder.build());

		return HandlerAction.TERMINAL;
	}
}
