package com.kodgames.corgi.server.gameserver.activity.operationactivty.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.OperationConfig;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.ActivityHandleOperationActivityManager;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.data.AccumulateActivity;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.data.OperationActivityMgr;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.data.OperationItem;
import com.kodgames.corgi.server.gameserver.activity.operationactivty.db.AccumulateDB;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class CG_OperationActivityPickRewardReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_OperationActivityPickRewardReqHandler.class);

	private ActivityHandleOperationActivityManager activityHandleOperationActivityManager = null;
	public CG_OperationActivityPickRewardReqHandler(ActivityHandleOperationActivityManager activityHandleOperationActivityManager)
	{
		this.activityHandleOperationActivityManager = activityHandleOperationActivityManager;
	}
	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv ActivityHandleOperationActivityManager, playerId = {}", sender.getClientUID().getPlayerID());
		GameProtocolsForClient.CG_OperationActivityPickRewardReq request =(GameProtocolsForClient.CG_OperationActivityPickRewardReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);
		GameProtocolsForClient.GC_OperationActivityPickRewardRes.Builder builder = GameProtocolsForClient.GC_OperationActivityPickRewardRes.newBuilder();
		builder.setCallback(request.getCallback());
		int result = ClientProtocols.E_GAME_OPERATION_ACTIVITY_PICK_REWARD_SUCCESS;
		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		boolean isRefresh = false;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);			
			do
			{
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_PICK_REWARD_ACCUMULATE_FAILED_LOAD_PLAYER;
					break;
				}
					
				int itemId = request.getItemId();
				long nowTime = System.currentTimeMillis();
				
				int activityId = cd.get_OperationConfig().get_Operations().get_ActivityId();
				
				isRefresh = OperationActivityMgr.getInstance().refreshAccumulateData(nowTime, playerNode, cd);
				boolean isStart = activityHandleOperationActivityManager.isActivityActivate(activityId, playerNode);
				if(!isStart)
				{
					result = ClientProtocols.E_GAME_PICK_REWARD_ACCUMULATE_FAILED_ACTIVITY_START_FAILED;
					break;
				}
				
				AccumulateActivity accumulateActivity = playerNode.getPlayerInfo().getOperationActivityData().getAccumulateActivity();
				if(accumulateActivity == null)
				{
					result = ClientProtocols.E_GAME_PICK_REWARD_ACCUMULATE_FAILED_ACCUMULATE_ACTIVITY_HISTORY_RECORD_NULL_FAILED; //没有充值活动历史记录 
					break;
				}
				OperationConfig operationConfig = cd.get_OperationConfig();
				if(operationConfig == null || operationConfig.getOperationById(activityId) == null || operationConfig.getOperationItemById(itemId) == null)
				{
					result = ClientProtocols.E_GAME_PICK_REWARD_ACCUMULATE_FAILED_ACCUMULATE_CONFIG_ACTIVITY_NULL_FAILED; //配置文件读取信息失败
					break;
				}
				OperationItem operationItem = accumulateActivity.getOperationItemList().get(request.getItemId());
				if(operationItem == null )
				{
					result = ClientProtocols.E_GAME_PICK_REWARD_ACCUMULATE_FAILED_ACCUMULATE_ACTIVITY_NULL_FAILED; //没有该条目
					break;
				}
				
				if((activityHandleOperationActivityManager.getPickRewardOpen(activityId, cd, nowTime) != 0) && (activityHandleOperationActivityManager.getPickRewardOpen(activityId, cd, nowTime) > nowTime) )
				{
					result = ClientProtocols.E_GAME_PICK_REWARD_ACCUMULATE_FAILED_PICK_TIME_END; //领取奖励时间还未开启
					break;
				}
				
				if((activityHandleOperationActivityManager.getPickRewardClose(activityId, cd, nowTime) != 0) && (activityHandleOperationActivityManager.getPickRewardClose(activityId, cd, nowTime) < nowTime) )
				{
					result = ClientProtocols.E_GAME_PICK_REWARD_ACCUMULATE_FAILED_PICK_TIME_END; //领取时结束
					break;
				}
				
				//是否可领，是否可领奖励大于1
				if(!operationItem.isCouldPickReward(cd))
				{
					result = ClientProtocols.E_GAME_PICK_REWARD_ACCUMULATE_FAILED_ACCUMULATE_ACTIVITY_NOREWARD_FAILED; //没有该条目
					break;
				}
				isRefresh = true;
				Reward reward = operationItem.pickAccumulateReward(playerNode, operationConfig, nowTime);
				com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync crsGetReward = new com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync();
				crsGetReward.mergeReward(reward);
				CostAndRewardManager.addReward(playerNode, reward, cd, KodLogEvent.AccumulateLogic_PickReward);
				builder.setCostAndRewardAndSync(crsGetReward.toProtobuf());
				builder.setOperationActivityItem(operationItem.toProtoBuf(cd));
			} while (false);
			if(isRefresh)
			{
				AccumulateDB.updateAccumulateData(playerNode);
			}
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}
		builder.setCallback(request.getCallback());
		builder.setResult(result);
		ServerDataGS.transmitter.sendToClient(sender, ClientProtocols.P_GAME_GC_OPERATION_ACTIVITY_PICK_REWARD_RES, builder.build());
		return HandlerAction.TERMINAL;
	}
}
