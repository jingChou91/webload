package com.kodgames.corgi.server.gameserver.equipment.data;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.IMathParser;

import com.kodgames.common.Guid;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.server.gameserver.avatar.data.Card;

public class Equipment extends Card
{
	private static final Logger logger = LoggerFactory.getLogger(Equipment.class);

	@Override
	public Object[] getObjectListForInsertRow(int playerId, int status_did_delete)
	{
		return new Object[] { playerId, getGuid().toString(), getResourceId(), getLevel(), getExperience(), getBreakthoughtLevel(), status_did_delete };
	}

	@Override
	public Equipment copy(Card card)
	{
		setGuid(Guid.genNewGuid(card.getGuid().toString()));
		setResourceId(card.getResourceId());
		setLevel(card.getLevel());
		setExperience(card.getExperience());
		setBreakthoughtLevel(card.getBreakthoughtLevel());

		return this;
	}

	public static Equipment genNewEquip(int recourceId)
	{
		Equipment equip = new Equipment();
		equip.setGuid(new Guid());
		equip.setResourceId(recourceId);
		equip.setLevel(1);
		equip.setExperience(0);
		equip.setBreakthoughtLevel(0);
		return equip;
	}

	@Override
	public CommonProtocols.Equipment toProtoBuffer()
	{
		CommonProtocols.Equipment.Builder equipBuilder = CommonProtocols.Equipment.newBuilder();

		equipBuilder.setGuid(getGuid().toString());
		equipBuilder.setResourceId(getResourceId());
		CommonProtocols.LevelAttrib.Builder levelAttributeBuilder = CommonProtocols.LevelAttrib.newBuilder();
		levelAttributeBuilder.setLevel(getLevel());
		levelAttributeBuilder.setExperience(getExperience());
		equipBuilder.setLevelAttrib(levelAttributeBuilder.build());
		equipBuilder.setBreakthoughtLevel(getBreakthoughtLevel());

		return equipBuilder.build();
	}

	public Equipment fromProtoBuffer(com.kodgames.corgi.protocol.CommonProtocols.Equipment protocol)
	{
		this.setGuid(Guid.genNewGuid(protocol.getGuid()));
		this.setResourceId(protocol.getResourceId());
		this.setLevel(protocol.getLevelAttrib().getLevel());
		this.setExperience(protocol.getLevelAttrib().getExperience());
		this.setBreakthoughtLevel(protocol.getBreakthoughtLevel());

		return this;
	}

	@Override
	public void setupVariable(IMathParser parser, ConfigDatabase cd)
	{
	}
}
