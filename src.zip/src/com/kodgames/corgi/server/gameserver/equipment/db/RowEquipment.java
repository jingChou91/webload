package com.kodgames.corgi.server.gameserver.equipment.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.sql.rowset.CachedRowSet;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.common.Guid;
import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.common.TableSelect;
import com.kodgames.corgi.server.gameserver.avatar.data.Card;
import com.kodgames.corgi.server.gameserver.equipment.data.Equipment;
import com.kodgames.gamedata.dbcommon.DBEasy;
import com.kodgames.gamedata.player.PlayerNode;

public class RowEquipment
{
	// 插入
	public static boolean insertPrivateList(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, PlayerNode playerNode) throws SQLException
	{
		String createTimeStr = ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(), System.currentTimeMillis(), ServerUtil.TimeWithoutMills);
		String sql = String.format("insert into " + TableSelect.get_equipment(playerNode.getPlayerId()) + " (" + "player_id,guid,resource_id,level,experience,breakthought_level"
				+ ",status_did_delete,create_time) VALUES (?,?,?,?,?,?,?,'%s')", createTimeStr);

		vps[queryIndex] = con.prepareStatement(sql);

		ArrayList<Equipment> equips = playerNode.getPlayerInfo().getEquipData().getEquips();
		if (equips != null)
		{
			for (Equipment equipment : equips)
			{
				if (!Card.isBasicCard(playerNode, equipment))
				{
					Object[] objList = equipment.getObjectListForInsertRow(playerNode.getPlayerId(), 0);
					boolean ret = DBEasy.doPrivateUpdate(vps[queryIndex], sql, objList);
					if (!ret)
					{
						return false;
					}
				}
			}
			return true;
		}
		return false;
	}

	/*
	 * 插入基础装备卡牌
	 */
	public static boolean insertBasicPrivateList(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, PlayerNode playerNode) throws SQLException
	{

		String sql = "insert into " + TableSelect.get_equipment_basic(playerNode.getPlayerId()) + " (player_id,resource_id,amount) VALUES (?,?,?)";
		vps[queryIndex] = con.prepareStatement(sql);

		HashMap<Integer, Integer> basicEquipMap = playerNode.getPlayerInfo().getEquipData().getBasicEquipMap();
		if (basicEquipMap != null)
		{
			for (Entry<Integer, Integer> entry : basicEquipMap.entrySet())
			{
				Object[] objList = new Object[] { playerNode.getPlayerId(), entry.getKey(), entry.getValue() };
				boolean ret = DBEasy.doPrivateUpdate(vps[queryIndex], sql, objList);
				if (!ret)
				{
					return false;
				}
			}
			return true;
		}
		return false;
	}

	// 查询
	public static void selectPrivate(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, PlayerNode playerNode, ConfigDatabase cd) throws SQLException
	{
		String sql = "select * from " + TableSelect.get_equipment(playerNode.getPlayerId()) + " where player_id=? AND status_did_delete=0";
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, new Object[] { playerNode.getPlayerId() });
		ArrayList<Equipment> equips = new ArrayList<Equipment>();
		equips.clear();

		if (vrs[queryIndex] != null)
		{
			CachedRowSet rs = vrs[queryIndex];
			while (rs.next())
			{
				Equipment equipment = new Equipment();

				// player_id
				equipment.setGuid(Guid.genNewGuid(rs.getString("guid")));
				equipment.setResourceId(rs.getInt("resource_id"));
				equipment.setLevel(rs.getInt("level"));
				equipment.setExperience(rs.getInt("experience"));
				equipment.setBreakthoughtLevel(rs.getInt("breakthought_level"));
				equipment.setFromBasic(false);
				
				if (cd.get_EquipmentConfig().GetEquipmentById(equipment.getResourceId()) != null)
				{
					equips.add(equipment);
				}
			}
		}
		playerNode.getPlayerInfo().getEquipData().getEquips().addAll(equips);
	}

	/*
	 * 查询基础装备卡牌
	 */
	public static void selectBasicPrivate(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs, PlayerNode playerNode, ConfigDatabase cd)
			throws SQLException
	{
		String sql = "select * from " + TableSelect.get_equipment_basic(playerNode.getPlayerId()) + " where player_id=? ";
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, new Object[] { playerNode.getPlayerId() });
		ArrayList<Equipment> equips = new ArrayList<Equipment>();
		equips.clear();
		HashMap<Integer, Integer> basicEquipMap = new HashMap<Integer, Integer>();

		if (vrs[queryIndex] != null)
		{
			CachedRowSet rs = vrs[queryIndex];
			while (rs.next())
			{
				int resourceId = rs.getInt("resource_id");
				int amount = rs.getInt("amount");

				if (cd.get_EquipmentConfig().GetEquipmentById(resourceId) != null)
				{
					for (int i = 0; i < amount; i++)
					{
						Equipment equipment = Equipment.genNewEquip(resourceId);
						equipment.setFromBasic(true);
						equips.add(equipment);
					}
					basicEquipMap.put(resourceId, amount);
				}

			}
		}
		playerNode.getPlayerInfo().getEquipData().setBasicEquipMap(basicEquipMap);
		playerNode.getPlayerInfo().getEquipData().getEquips().addAll(equips);
	}

}
