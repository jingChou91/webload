package com.kodgames.corgi.server.gameserver.equipment.db;

import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.common.TableSelect;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.equipment.data.Equipment;

public class EquipmentDB 
{
	public static void addEquipment(int playerId, Equipment equip)
	{
		String createTimeStr = ServerUtil.convertLongToTimeStringWithTimezone(TimeZoneData.getTimeZone(), System.currentTimeMillis(), ServerUtil.TimeWithoutMills);
		
		String sql = String.format("insert into "+TableSelect.get_equipment(playerId)+" ("
						+ "player_id,guid,resource_id,level,experience,breakthought_level"
						+ ",status_did_delete,create_time)" + " VALUES ( %d,'%s',%d,%d,%d,%d,0,'%s')", playerId, equip.getGuid(),equip.getResourceId(),
						equip.getLevel(), equip.getExperience(), equip.getBreakthoughtLevel(), createTimeStr);
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId,sql);
	}
	
	public static void removeEquipment(int playerId,String equipGuid ,boolean relDel )
	{
		if(relDel)
		{
			String sql = String.format("delete from "+TableSelect.get_equipment(playerId)+" where player_id=%d AND guid='%s'", playerId, equipGuid);
			ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId,sql);
		}
		else
		{
			String sql = String.format("update "+TableSelect.get_equipment(playerId)+" set " + "status_did_delete=1" + " where player_id=%d AND guid='%s'", playerId, equipGuid);
			ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId,sql);
		}
	}
	
	public static void updateEquipment(int playerId, Equipment equip)
	{
		String sql = String.format("update "+TableSelect.get_equipment(playerId)+" set resource_id=%d, level=%d, experience=%d, breakthought_level=%d"
				+ " where player_id=%d AND guid='%s'",
				equip.getResourceId(), equip.getLevel(), equip.getExperience(), equip.getBreakthoughtLevel(), playerId, equip.getGuid());
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId,sql);
	}
	
	/*
	 * 增加基础装备卡牌
	 * @param amount add之后该resourceId的卡牌数量
	 */
	public static void addBasicEquipment(int playerId,int resourceId,int amount)
	{
		if(amount > 0)
		{
			String sql = String.format("replace into " + TableSelect.get_equipment_basic(playerId)
				+ " (player_id,resource_id,amount) values (%d,%d,%d)", playerId, resourceId, amount);
			ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId,sql);
		}
	}
	
	/*
	 * 删除装备卡牌
	 * 判断amount是否等于1，等于1则在equipment_basic中直接删除这条记录；大于1则更新equipment_basic中该记录将amount字段值减一
	 * (基础卡牌没有假删，全为真删)
	 * @param amount remove之后该resourceId的卡牌数量
	 */
	public static void removeBasicEquipment(int playerId,int resourceId,int amount)
	{
		if(amount > 0)
		{
			String sql = String.format("update " + TableSelect.get_equipment_basic(playerId) + " set amount=%d "
				  + " where player_id = %d and resource_id = %d", amount, playerId, resourceId);
			ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId,sql);
		}
		else if(amount == 0)
		{
			String sql = String.format("delete from " + TableSelect.get_equipment_basic(playerId) + " where player_id=%d and resource_id=%d",
				playerId, resourceId);
			ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(playerId,sql);
		}
	}
	
}
