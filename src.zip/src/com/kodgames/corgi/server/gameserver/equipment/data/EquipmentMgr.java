package com.kodgames.corgi.server.gameserver.equipment.data;

import java.util.List;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.EquipmentConfig;

import com.kodgames.common.Guid;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.server.gameserver.avatar.data.Card;
import com.kodgames.corgi.server.gameserver.equipment.db.EquipmentDB;
import com.kodgames.gamedata.player.PlayerNode;

public class EquipmentMgr
{
	// 查装备
	public static Equipment getEquipment(Guid guid, PlayerNode playerNode)
	{
		return playerNode.getPlayerInfo().getEquipData().getEquipment(guid);
	}

	// 添加装备
	public static boolean addEquipment(PlayerNode playerNode, Equipment equip)
	{
		EquipmentData equipData = playerNode.getPlayerInfo().getEquipData();
		if (equipData.addEquipment(equip))
		{
			if (Card.isBasicCard(playerNode, equip))
			{
				equipData.addBasicCard(equip.getResourceId());
				EquipmentDB.addBasicEquipment(playerNode.getPlayerId(), equip.getResourceId(), equipData.getBasicCardCount(equip.getResourceId()));
			}
			else
			{
				EquipmentDB.addEquipment(playerNode.getPlayerId(), equip);
			}
			return true;
		}
		return false;
	}

	// 删除装备
	public static boolean removeEquipment(PlayerNode playerNode, Guid guid, ConfigDatabase cd)
	{
		Equipment equip = EquipmentMgr.getEquipment(guid, playerNode);
		if (null == equip)
		{
			return false;
		}

		EquipmentData equipData = playerNode.getPlayerInfo().getEquipData();
		if (equipData.removeEquipment(guid))
		{
			if (Card.isBasicCard(playerNode, equip))
			{
				EquipmentMgr.removeBasicEquipment(playerNode, equip);
			}
			else
			{
				// 不同品质删除方式不同
				EquipmentConfig.Equipment equipCfg = cd.get_EquipmentConfig().GetEquipmentById(equip.getResourceId());
				if (equipCfg != null && (equipCfg.get_qualityLevel() >= 4 || equip.getLevel() > 1 || equip.getBreakthoughtLevel() > 0))
				{
					EquipmentDB.removeEquipment(playerNode.getPlayerId(), guid.toString(), false);
				}

				else
				{
					EquipmentDB.removeEquipment(playerNode.getPlayerId(), guid.toString(), true);
				}
			}

			return true;
		}
		return false;
	}

	// 更新装备
	public static void updateEquipment(PlayerNode playerNode, Equipment equip, boolean isBasicCardBefore)
	{
		if (isBasicCardBefore && equip.isFromBasic())
		{
			EquipmentMgr.removeBasicEquipment(playerNode, equip);
			EquipmentDB.addEquipment(playerNode.getPlayerId(), equip);
		}
		else
		{
			EquipmentDB.updateEquipment(playerNode.getPlayerId(), equip);
		}
	}

	/*
	 * 从阵容中卸下一张卡牌后若该卡牌满足基础卡牌条件时， 将该卡牌数据从equipment表中移动到equipment_basic表中
	 */
	public static void moveEquipToBasic(PlayerNode playerNode, Equipment equip)
	{
		if (Card.isBasicCard(playerNode, equip))
		{
			// 从equipment表中移除该记录
			EquipmentDB.removeEquipment(playerNode.getPlayerId(), equip.getGuid().toString(), true);
			// 在equipment_basic表中增加该记录
			EquipmentData equipData = playerNode.getPlayerInfo().getEquipData();

			equipData.addBasicCard(equip.getResourceId());
			EquipmentDB.addBasicEquipment(playerNode.getPlayerId(), equip.getResourceId(), equipData.getBasicCardCount(equip.getResourceId()));
		}

	}

	private static void removeBasicEquipment(PlayerNode playerNode, Equipment equip)
	{
		EquipmentData equipData = playerNode.getPlayerInfo().getEquipData();
		int amount = equipData.getBasicCardCount(equip.getResourceId());
		if (amount > 0)
		{
			amount--;
			if (amount > 0)
			{
				equipData.getBasicEquipMap().put(equip.getResourceId(), amount);
			}
			else
			{
				equipData.getBasicEquipMap().remove(equip.getResourceId());
			}
			EquipmentDB.removeBasicEquipment(playerNode.getPlayerId(), equip.getResourceId(), amount);
		}
	}

	public static CommonProtocols.Equipment getEquipment(List<CommonProtocols.Equipment> equipments, String guid)
	{
		for (CommonProtocols.Equipment equipment : equipments)
		{
			if (equipment.getGuid().equals(guid))
			{
				return equipment;
			}
		}

		return null;
	}

}
