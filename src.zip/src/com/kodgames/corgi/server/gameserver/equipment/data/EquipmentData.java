package com.kodgames.corgi.server.gameserver.equipment.data;

import java.util.ArrayList;
import java.util.HashMap;

import com.kodgames.common.Guid;

public class EquipmentData
{
	private ArrayList<Equipment> equips = new ArrayList<>();
	private HashMap<Integer, Integer> basicEquipMap = new HashMap<Integer, Integer>(); // key：装备的resourceId value：相同resourceId的卡牌数量

	// -----------------------------get set ------------------------------------
	public HashMap<Integer, Integer> getBasicEquipMap()
	{
		return basicEquipMap;
	}
	
	public void setBasicEquipMap(HashMap<Integer, Integer> basicEquipMap)
	{
		this.basicEquipMap = basicEquipMap;
	}

	public ArrayList<Equipment> getEquips()
	{
		return equips;
	}

	public void setEquips(ArrayList<Equipment> equips)
	{
		this.equips = equips;
	}

	// -----------------------------get set ------------------------------------

	// 查装备
	public Equipment getEquipment(Guid guid)
	{
		for (Equipment _equip : equips)
		{
			if (_equip.getGuid().equals(guid))
			{
				return _equip;
			}
		}
		return null;
	}

	// 加装备
	public boolean addEquipment(Equipment equipment)
	{
		if (getEquipment(equipment.getGuid()) == null)
		{
			return equips.add(equipment);
		}

		return false;
	}

	// 删装备
	public boolean removeEquipment(Guid guid)
	{
		Equipment _equip = getEquipment(guid);
		if (_equip != null)
		{
			return equips.remove(_equip);
		}
		return false;
	}
	
	public void addBasicCard(int resourcdId)
	{
		int amount = 1;
		if (basicEquipMap.containsKey(resourcdId))
		{
			amount = basicEquipMap.get(resourcdId) + 1;
		}
		
		basicEquipMap.put(resourcdId, amount);
	}
	
	public int getBasicCardCount(int resourceId)
	{
		if (basicEquipMap.containsKey(resourceId))
		{
			return basicEquipMap.get(resourceId);
		}
		
		return 0;
	}
}
