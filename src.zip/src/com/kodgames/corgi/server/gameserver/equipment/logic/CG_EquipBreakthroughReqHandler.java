package com.kodgames.corgi.server.gameserver.equipment.logic;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.EquipmentConfig;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_EquipBreakthoughtReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_EquipBreakthoughtRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.KodLogUtil;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.avatar.data.Card;
import com.kodgames.corgi.server.gameserver.equipment.data.Equipment;
import com.kodgames.corgi.server.gameserver.equipment.data.EquipmentMgr;
import com.kodgames.corgi.server.gameserver.marquee.data.FlowMessageBroadcaster;
import com.kodgames.corgi.server.gameserver.position.data.PositionMgr;
import com.kodgames.gamedata.player.PlayerAttributeMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.genplayer.PowerMgr;

/**
 * @author Zhangyile
 * 
 */
public class CG_EquipBreakthroughReqHandler extends MessageHandler
{
	public static final Logger logger = LoggerFactory.getLogger(CG_EquipBreakthroughReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		CG_EquipBreakthoughtReq request = (CG_EquipBreakthoughtReq) message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_EquipBreakthoughtRes.Builder builder = GC_EquipBreakthoughtRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_EQUIP_BREAKTHOUGHT_RES);
		builder.setCallback(request.getCallback());
		int result = ClientProtocols.E_GAME_EQUIP_BREAKTHOUGHT_SUCCESS;
		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		logger.info("recv CG_EquipBreakthoughtReq , playerId = {}", playerId);

		// 装备GUID
		Guid equipGUID = Guid.genNewGuid(request.getEquipGUID());
		// 被销毁的装备GUID集合
		List<String> destroyEquipGUIDs = request.getDestroyEquipGUIDsList();

		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_EQUIP_BREAKTHOUGHT_FAILED_LOAD_PLAYER;
					break;
				}

				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.EquipmentRefine))
				{
					result = ClientProtocols.E_GAME_EQUIP_BREAKTHOUGHT_FUNCTION_NOT_OPEN;
					break;
				}

				Equipment equipment = EquipmentMgr.getEquipment(equipGUID, playerNode);
				if (equipment == null)
				{
					result = ClientProtocols.E_GAME_EQUIP_BREAKTHOUGHT_FAILED_LOAD_THISEQUIP;
					break;
				}
				int breakthoughtLevel = equipment.getBreakthoughtLevel();
				EquipmentConfig.Equipment equipCfg = cd.get_EquipmentConfig().GetEquipmentById(equipment.getResourceId());
				if (equipCfg == null)
				{
					result = ClientProtocols.E_GAME_EQUIP_BREAKTHOUGHT_FAILED_EQUIPMENTCONFIG_ERROR;
					break;
				}

				// 装备突破配置信息
				EquipmentConfig.EquipBreakthrough equipBreakthrough = equipCfg.GetBreakthroughByTimes(equipment.getBreakthoughtLevel());
				if (null == equipBreakthrough || equipBreakthrough.get_breakThrough() == null)
				{
					result = ClientProtocols.E_GAME_EQUIP_BREAKTHOUGHT_FAILED_EQUIPMENTCONFIG_ERROR;
					break;
				}

				// 最大突破级别
				int maxBreakThroughLevel = equipCfg.GetMaxBreakthoughtLevel();
				if (maxBreakThroughLevel <= equipment.getBreakthoughtLevel())
				{
					result = ClientProtocols.E_GAME_EQUIP_BREAKTHOUGHT_FAILED_EXCEED_MAX_BREAKTHOUGHLEVEL;
					break;
				}
				// 检测装备是否满级
				if (equipment.getLevel() < equipBreakthrough.get_breakThrough().get_powerUpLevelLimit())
				{
					result = ClientProtocols.E_GAME_EQUIP_BREAKTHOUGHT_FAILED_EQUIPMENT_LEVEL_NOT_ENOUGH;
					break;
				}

				// 检测被销毁的卡信息是否正确
				if (!checkDestoryGUIDS(playerNode, destroyEquipGUIDs, equipGUID))
				{
					result = ClientProtocols.E_GAME_EQUIP_BREAKTHOUGHT_FAILED_DESTORYGUIDS_WRONG;
					break;
				}

				int costItemId = equipBreakthrough.get_breakThrough().get_itemCostItemId();
				int costItemCount = equipBreakthrough.get_breakThrough().get_itemCostItemCount();
				int cardReduceItemCount = equipBreakthrough.get_breakThrough().get_sameCardDeductItemCount();

				// 检查消耗是否足够
				int needCardCount = costItemCount / cardReduceItemCount;
				ArrayList<Cost> costs = new ArrayList<>();
				int realItemCount = 0;
				if (needCardCount <= request.getDestroyEquipGUIDsCount())
				{
					for (int i = 0; i < needCardCount; i++)
					{
						costs.add(new Cost(equipment.getResourceId(), Guid.genNewGuid(request.getDestroyEquipGUIDs(i))));
					}
				}
				else
				{
					for (String guid : request.getDestroyEquipGUIDsList())
					{
						costs.add(new Cost(equipment.getResourceId(), Guid.genNewGuid(guid)));
					}

					realItemCount = costItemCount - cardReduceItemCount * request.getDestroyEquipGUIDsCount();
					costs.add(new Cost(costItemId, realItemCount));
				}

				for (int i = 0; i < equipBreakthrough.get_breakThrough().Get_otherCostsCount(); i++)
				{
					ClientServerCommon.Cost cost = equipBreakthrough.get_breakThrough().Get_otherCostsByIndex(i);
					Cost otherCost = new Cost(cost.get_id(), cost.get_count());
					costs.add(otherCost);
				}

				Cost notEnoughCost = new Cost();
				if (false == CostAndRewardManager.checkCosts(playerNode, costs, cd, KodLogEvent.EquipLogic_EquipBreakthrough, notEnoughCost))
				{
					crsForClient.setNotEnoughCost(notEnoughCost);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_EQUIP_BREAKTHOUGHT_FAILED_CONSUMABLE_NOT_ENOUGH;
					break;
				}

				CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
				CostAndRewardManager.consumeCosts(playerNode, costs, cd, KodLogEvent.EquipLogic_EquipBreakthrough, 0, 0);
				crsForCost.setCosts(costs);
				crsForClient.megerCostAndRewardAndSync(crsForCost);

				// 判断突破的装备是否是基础卡
				boolean isBasicCardBefore = Card.isBasicCard(playerNode, equipment);

				// 更新数据库
				equipment.setBreakthoughtLevel(equipment.getBreakthoughtLevel() + 1);
				EquipmentMgr.updateEquipment(playerNode, equipment, isBasicCardBefore);

				builder.setEquipment(equipment.toProtoBuffer());
				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());

				if (equipment.getBreakthoughtLevel() > 5)
				{
					FlowMessageBroadcaster.prepareBroadcastMsg(playerNode, equipment.getResourceId(), FlowMessageBroadcaster.BroadcastType.EQUIPMENTBREAKTHROUGH,
							equipment.getBreakthoughtLevel());
				}
				// Log
				KodLogUtil.equip_breakthoughlevelup(playerNode, equipment, cd);
				BPUtil.zbtp(playerNode, equipment.getResourceId(), equipment.getBreakthoughtLevel(), breakthoughtLevel, destroyEquipGUIDs.size(), realItemCount);
				//战力
				float power = PowerMgr.calPower(playerNode, cd);
				PlayerAttributeMgr.setPlayerPower(playerNode, (int)power);
			}
			while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);

		return HandlerAction.TERMINAL;
	}

	private boolean checkDestoryGUIDS(PlayerNode playerNode, List<String> destoryGUIDs, Guid equipGUID)
	{
		int resourseId = EquipmentMgr.getEquipment(equipGUID, playerNode).getResourceId();
		HashSet<String> guids = new HashSet<>();
		Guid destoryGuid = null;
		for (String tmp : destoryGUIDs)
		{
			destoryGuid = Guid.genNewGuid(tmp);
			// 判断装备是或否存在
			if ((EquipmentMgr.getEquipment(destoryGuid, playerNode) == null))
			{
				return false;
			}
			// 判断资源id是否相同
			if ((resourseId != EquipmentMgr.getEquipment(destoryGuid, playerNode).getResourceId()))
			{
				return false;
			}

			// 判断是否在上阵
			if (PositionMgr.checkGuid(destoryGuid, playerNode) == false)
			{
				return false;
			}

			guids.add(tmp);
		}

		// 判断GUIDS有没有重复
		if (guids.size() != destoryGUIDs.size())
		{
			return false;
		}

		return true;
	}
}
