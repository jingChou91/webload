package com.kodgames.corgi.server.gameserver.equipment.logic;

import java.util.ArrayList;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.EquipmentConfig;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_EquipLevelUpReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_EquipLevelUpRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.KodLogUtil;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.avatar.data.Card;
import com.kodgames.corgi.server.gameserver.equipment.data.Equipment;
import com.kodgames.corgi.server.gameserver.equipment.data.EquipmentMgr;
import com.kodgames.gamedata.player.PlayerAttributeMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.genplayer.PowerMgr;

public class CG_EquipLevelUpReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_EquipLevelUpReqHandler.class);

	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		CG_EquipLevelUpReq request = (CG_EquipLevelUpReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_EquipLevelUpRes.Builder builder = GC_EquipLevelUpRes.newBuilder();
		int result = ClientProtocols.E_GAME_EQUIP_LEVEL_UP_SUCCESS;
		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		Guid equipGuid = Guid.genNewGuid(request.getEquipGUID());
		boolean strengthenType = request.getStrengthenType();// true是强化一次，false是一键强化
		logger.info("recv CG_EquipLevelUpReq, playerId = {}", playerId);

		PlayerNode playerNode = null;

		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null)
				{
					result = ClientProtocols.E_GAME_EQUIP_LEVEL_UP_FAILED_LOAD_PLAYER;
					break;
				}

				int originalGameMoney = playerNode.getGamePlayer().getGameMoney();
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.EquipmentLevelUp))
				{
					result = ClientProtocols.E_GAME_EQUIP_LEVEL_UP_FUNCTION_NOT_OPEN;
					break;
				}

				Equipment equipment = EquipmentMgr.getEquipment(equipGuid, playerNode);
				if (equipment == null)
				{
					result = ClientProtocols.E_GAME_EQUIP_LEVEL_UP_FAILED_GUID_ERROR;
					break;
				}
				int old_Level = equipment.getLevel();
				EquipmentConfig.Equipment equipCfg =
					cd.get_EquipmentConfig().GetEquipmentById(equipment.getResourceId());
				if (equipCfg == null)
				{
					result = ClientProtocols.E_GAME_EQUIP_LEVEL_UP_FAILED_CONFIG_ERROR;
					break;
				}

				EquipmentConfig.EquipBreakthrough equipBreakthrough =
					equipCfg.GetBreakthroughByTimes(equipment.getBreakthoughtLevel());
				if (equipBreakthrough == null)
				{
					result = ClientProtocols.E_GAME_EQUIP_LEVEL_UP_FAILED_CONFIG_ERROR;
					break;
				}

				int maxLevel = equipBreakthrough.get_breakThrough().get_powerUpLevelLimit();
				float critFactor = equipCfg.get_critFactor();
				// 判断装备等级是否符合
				if (equipment.getLevel() >= maxLevel)
				{
					result = ClientProtocols.E_GAME_EQUIP_LEVEL_UP_FAILED_IS_MAX_LEVEL;
					break;
				}
				// 判断要升级的装备是否是基础卡
				boolean isBasicCardBefore = Card.isBasicCard(playerNode, equipment);

				// 升级一次
				if (strengthenType)
				{
					result = procLevelUp(playerNode, cd, maxLevel, critFactor, equipCfg.get_qualityLevel(), crsForClient, equipment, true, builder);
				}
				else
				// 一键升级
				{
					// 如果玩家vip级别不够,那么不能一键强化
					int openVipLevel = cd.get_VipConfig().GetVipLevelByOpenFunctionType(ClientServerCommon._OpenFunctionType.EquipmentLevelUpOneClick);
					if (playerNode.getGamePlayer().getVipLevel() < openVipLevel)
					{
						result = ClientProtocols.E_GAME_EQUIP_LEVEL_UP_FAILED_VIPLEVEL_INVALID;
						break;
					}
					
					int oldLevel = equipment.getLevel();
					boolean isFirstLevelUp = true;
					// 循环执行升级操作
					while (equipment.getLevel() < maxLevel)
					{
						result = procLevelUp(playerNode, cd, maxLevel, critFactor, equipCfg.get_qualityLevel(), crsForClient, equipment, isFirstLevelUp, builder);

						if (oldLevel == equipment.getLevel())
						{
							break;
						}
						isFirstLevelUp = false;
						oldLevel = equipment.getLevel();
					}
				}
				// 更新数据库数据库
				if (result == ClientProtocols.E_GAME_EQUIP_LEVEL_UP_SUCCESS)
				{
					EquipmentMgr.updateEquipment(playerNode, equipment, isBasicCardBefore);
				}

				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
				builder.setLevelAfter(equipment.getLevel());

				// Log
				KodLogUtil.equip_levelup(playerNode, equipment, cd, old_Level);
				
				String costsInfo = "";
				if(crsForClient.getCosts() != null)
				{
					for(Cost cost : crsForClient.getCosts())
					{
						costsInfo += cost.toString();
					}
					int currentGameMoney = playerNode.getGamePlayer().getGameMoney();
					logger.info("playerId:{}, equipmentResourceId:{}, old_Level:{}, new_Level:{}, originalGameMoney:{}, currentGameMoney:{}, costMoney:{}, costsForClient:{}", playerId, equipment.getResourceId(), old_Level, equipment.getLevel(), originalGameMoney, currentGameMoney, originalGameMoney- currentGameMoney, costsInfo);
				}
				BPUtil.zbqh(playerNode, equipment.getResourceId(), equipment.getLevel(), old_Level);
				//战力
				float power = PowerMgr.calPower(playerNode, cd);
				PlayerAttributeMgr.setPlayerPower(playerNode, (int)power);
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}
		builder.setCallback(request.getCallback());
		builder.setResult(result);
		ServerDataGS.transmitter.sendToClient(sender, ClientProtocols.P_GAME_GC_EQUIP_LEVEL_UP_RES, builder.build());
		return HandlerAction.TERMINAL;
	}

	// 处理升级逻辑
	private int procLevelUp(PlayerNode playerNode, ConfigDatabase cd, int levelMax, float critFactor, int quality,
		CostAndRewardAndSync crsForClient, Equipment equipment, boolean isFirst, GC_EquipLevelUpRes.Builder builder)
	{
		ClientServerCommon.QualityCost qualityCostCfg =
			cd.get_EquipmentConfig().GetQualityCostByLevelAndQuality(equipment.getLevel(), quality);
		if (qualityCostCfg == null)
		{
			return ClientProtocols.E_GAME_EQUIP_LEVEL_UP_FAILED_CONFIG_ERROR;
		}
		ArrayList<Cost> costs = new ArrayList<>();
		for (int i = 0; i < qualityCostCfg.Get_costsCount(); i++)
		{
			costs.add(new Cost(qualityCostCfg.Get_costsByIndex(i).get_id(), qualityCostCfg.Get_costsByIndex(i).get_count()));
		}
		Cost notEnoughCost = new Cost();
		if (CostAndRewardManager.checkCosts(playerNode, costs, cd, KodLogEvent.EquipLogic_EquipLevelUp, notEnoughCost) == false)
		{
			if (isFirst)
			{
				crsForClient.setNotEnoughCost(notEnoughCost);
				return ClientProtocols.E_GAME_EQUIP_LEVEL_UP_FAILED_COST_NOT_ENOUGH;
			}
			else
			{
				return ClientProtocols.E_GAME_EQUIP_LEVEL_UP_SUCCESS;
			}
		}
		CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
		CostAndRewardManager.consumeCosts(playerNode, costs, cd, KodLogEvent.EquipLogic_EquipLevelUp, 0, 0);
		crsForCost.setCosts(costs);
		crsForClient.megerCostAndRewardAndSync(crsForCost);

		// 暴级不能超过最高等级
		if ((new Random()).nextFloat() < critFactor && equipment.getLevel() < levelMax - 1)
		{
			builder.setCritCount(builder.getCritCount() + 1);
			equipment.setLevel(equipment.getLevel() + 2);
		}
		else
		{
			equipment.setLevel(equipment.getLevel() + 1);
		}
		return ClientProtocols.E_GAME_EQUIP_LEVEL_UP_SUCCESS;
	}
}