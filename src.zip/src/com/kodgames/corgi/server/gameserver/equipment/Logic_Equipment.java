package com.kodgames.corgi.server.gameserver.equipment;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.equipment.logic.CG_EquipBreakthroughReqHandler;
import com.kodgames.corgi.server.gameserver.equipment.logic.CG_EquipLevelUpReqHandler;

public class Logic_Equipment{
	private CG_EquipBreakthroughReqHandler cg_EquipBreakthroughReqHandler= null;
	private CG_EquipLevelUpReqHandler cg_EquipLevelUpReqHandler = null;
	
	public void init()
	{
		cg_EquipBreakthroughReqHandler = new CG_EquipBreakthroughReqHandler();
	    cg_EquipLevelUpReqHandler = new CG_EquipLevelUpReqHandler();
	}
	
	public void registerProtoBufType(Controller controller)
	{
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_EQUIP_BREAKTHOUGHT_REQ, GameProtocolsForClient.CG_EquipBreakthoughtReq.getDefaultInstance());
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_EQUIP_LEVEL_UP_REQ, GameProtocolsForClient.CG_EquipLevelUpReq.getDefaultInstance());
		
	}
	
	public void registerMessageHandler(Controller controller)
	{
		controller.addHandler(ClientProtocols.P_GAME_CG_EQUIP_BREAKTHOUGHT_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_EquipBreakthroughReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_EQUIP_LEVEL_UP_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_EquipLevelUpReqHandler));
	}

}
