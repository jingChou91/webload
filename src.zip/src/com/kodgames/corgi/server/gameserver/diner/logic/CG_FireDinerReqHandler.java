/*
 * 文 件 名:  CG_FireDinerReqHandler.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述: 
 * 创 建 人:  ZYL
 * 创建时间:  2014年5月27日
 * 修 改 人:  <修改人>
 * 修改时间:  2014年5月27日
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.diner.logic;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_FireDinerReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_FireDinerRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.diner.data.Diner;
import com.kodgames.corgi.server.gameserver.diner.data.DinerData;
import com.kodgames.corgi.server.gameserver.diner.data.DinerMgr;
import com.kodgames.corgi.server.gameserver.diner.data.RecordDinerData;
import com.kodgames.gamedata.player.PlayerNode;

/**
 * 解雇门客处理
 * 
 * @author ZYL
 * @version [版本号, 2014年5月27日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */

public class CG_FireDinerReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_FireDinerReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{

		CG_FireDinerReq request = (CG_FireDinerReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_FireDinerRes.Builder builder = GC_FireDinerRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_FIRE_DINER_RES);
		builder.setCallback(request.getCallback());
		int dinerId = request.getDinerId();
		int qualityType = request.getQualityType();
		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		int result = ClientProtocols.E_GAME_FIRE_DINER_SUCCESS;
		logger.info("recv CG_FireDinerReq, playerId = {}", playerId);
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);

				// 加载玩家失败
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					logger.warn("get playerInfo failed, playerId = {}", playerId);
					result = ClientProtocols.E_GAME_FIRE_DINER_FAILED_LOAD_PLAYER_FAILED;
					break;
				}
				
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Diner))
				{
					result = ClientProtocols.E_GAME_DINER_FUNCTION_NOT_OPEN;
					break;
				}

				// 加载Diner Cfg失败;
				ClientServerCommon.DinerConfig dinerCfg = cd.get_DinerConfig();
				if (dinerCfg == null)
				{
					result = ClientProtocols.E_GAME_FIRE_DINER_FAILED_CONFIG_ERROR;
					break;
				}

				// 加载Diner失败;
				ClientServerCommon.DinerConfig.Diner diner = dinerCfg.GetDinerById(dinerId);
				if (diner == null)
				{
					result = ClientProtocols.E_GAME_FIRE_DINER_FAILED_CONFIG_DINER_INVALID_ERROR;
					break;
				}
				DinerData dinerData = playerNode.getPlayerInfo().getDinerInfoData().getDinerData();
				RecordDinerData recordDinerData = playerNode.getPlayerInfo().getDinerInfoData().getRecordDinerData();

				// 门客不存在，无法解雇
				Diner needFireDiner = dinerData.getDiner(dinerId, qualityType);
				
				ArrayList<Diner> needFireDiners = new ArrayList<Diner>();
				needFireDiners.add(needFireDiner);
				if (needFireDiner == null)
				{
					result = ClientProtocols.E_GAME_FIRE_DINER_FAILED_DINER_NOT_EXISTS;
					break;
				}

				// 更新数据库
				DinerMgr.removeDinerData(dinerData, recordDinerData, needFireDiners, playerId);
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}
		builder.setResult(result);
		builder.setCallback(request.getCallback());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
