/*
 * 文 件 名:  CG_RefreshDinerListReqHandler.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述: 
 * 创 建 人:  ZYL
 * 创建时间:  2014年5月27日
 * 修 改 人:  <修改人>
 * 修改时间:  2014年5月27日
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.diner.logic;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.VipConfig;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_RefreshDinerListReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_RefreshDinerListRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.diner.data.DinerMgr;
import com.kodgames.corgi.server.gameserver.diner.data.RecordDiner;
import com.kodgames.corgi.server.gameserver.diner.data.RecordDinerData;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;

/**
 * 刷新门客处理
 * 
 * @author ZYL
 * @version [版本号, 2014年5月27日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */

public class CG_RefreshDinerListReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_RefreshDinerListReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{

		CG_RefreshDinerListReq request = (CG_RefreshDinerListReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_RefreshDinerListRes.Builder builder = GC_RefreshDinerListRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_REFRESH_DINER_LIST_RES);
		builder.setCallback(request.getCallback());
		int bagId = request.getBagId();
		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		int result = ClientProtocols.E_GAME_REFRESH_DINER_LIST_SUCCESS;
		logger.info("recv CG_RefreshDinerListReq, playerId = {}", playerId);
		Long nowTime;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				nowTime = System.currentTimeMillis();
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);

				// 加载玩家失败
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					logger.warn("get playerInfo failed, playerId = {}", playerId);
					result = ClientProtocols.E_GAME_REFRESH_DINER_LIST_LOAD_PLAYER_FAILED;
					break;
				}

				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Diner))
				{
					result = ClientProtocols.E_GAME_DINER_FUNCTION_NOT_OPEN;
					break;
				}

				// 配置文件失败
				ClientServerCommon.DinerConfig dinerCfg = cd.get_DinerConfig();
				if (dinerCfg == null)
				{
					result = ClientProtocols.E_GAME_REFRESH_DINER_LIST_FAILED_CONFIG_ERROR;
					break;
				}
				ClientServerCommon.DinerConfig.DinerBag cfgDinerBag = dinerCfg.GetDinerBagById(bagId);

				// 初始化数据失败,Query_LIST失败
				if (cfgDinerBag == null)
				{
					result = ClientProtocols.E_GAME_REFRESH_DINER_LIST_FAILED_CONFIG_ERROR;
					break;
				}

				RecordDinerData recordDinerData = playerNode.getPlayerInfo().getDinerInfoData().getRecordDinerData();
				// 初始化数据失败,Query_LIST失败
				if (recordDinerData == null || recordDinerData.getRecordDiners().size() == 0)
				{
					result = ClientProtocols.E_GAME_REFRESH_DINER_LIST_FAILED_INIT_RECORD_DINERS_FAILED;
					break;
				}
				int qualityType = cfgDinerBag.get_QualityType();
				int refreshType = cfgDinerBag.get_RefreshType();

				// 判断系统是否可以重置系统可以重置
				RecordDiner recordDiner = recordDinerData.getRecordDiner(qualityType);
				if (RecordDiner.canSystemReset(recordDiner.getLastResetTime(), nowTime, dinerCfg))
				{
					// recordDiner.setNormalRefreshCount(0);
					// recordDiner.setSpecialRefreshCount(0);
					recordDiner.setLastResetTime(nowTime);
				}

				// 手动刷新
				if (refreshType == ClientServerCommon.DinerConfig._DinerRefreshType.Special
					|| refreshType == ClientServerCommon.DinerConfig._DinerRefreshType.Common)
				{
					VipConfig vipCfg = cd.get_VipConfig();
					int vipLevel = playerNode.getGamePlayer().getVipLevel();

					/*
					 * result = exceedMaxRefreshCount(recordDinerData, qualityType, vipCfg, vipLevel, refreshType); if
					 * (result != ClientProtocols.E_GAME_REFRESH_DINER_LIST_SUCCESS) { break; }
					 */

					// 检查消耗品
					ArrayList<Cost> costs = new ArrayList<Cost>();
					for (int i = 0; i < cfgDinerBag.Get_CostsCount(); ++i)
					{
						ClientServerCommon.Cost costX = cfgDinerBag.Get_CostsByIndex(i);
						if (costX != null)
						{
							costs.add(new Cost(costX.get_id(), costX.get_count()));
						}
					}
					Cost notEnoughCost = new Cost();
					if (CostAndRewardManager.checkCosts(playerNode,
						costs,
						cd,
						KodLogEvent.DinerLogic_RefreshDiner,
						notEnoughCost) == false)
					{
						crsForClient.setNotEnoughCost(notEnoughCost);
						builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
						result = ClientProtocols.E_GAME_REFRESH_DINER_LIST_FAILED_CONSUMABLE_NOT_ENOUGH;
						break;
					}
					CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
					CostAndRewardManager.consumeCosts(playerNode, costs, cd, KodLogEvent.DinerLogic_RefreshDiner, 0, 0);
					crsForCost.setCosts(costs);
					crsForClient.megerCostAndRewardAndSync(crsForCost);

					/*
					 * recordDiner.setNormalRefreshCount(refreshType ==
					 * ClientServerCommon.DinerConfig._DinerRefreshType.Common ? recordDiner.getNormalRefreshCount() + 1
					 * : recordDiner.getNormalRefreshCount()); recordDiner.setSpecialRefreshCount(refreshType ==
					 * ClientServerCommon.DinerConfig._DinerRefreshType.Special ? recordDiner.getSpecialRefreshCount() +
					 * 1 : recordDiner.getSpecialRefreshCount());
					 */
				}

				// 进行系统刷新
				else
				{
					if (!RecordDiner.canSystemRefreshMultiTimes(qualityType,
						recordDiner.getLastRefreshTime(),
						nowTime,
						dinerCfg))
					{
						result = ClientProtocols.E_GAME_REFRESH_DINER_LIST_FAILED_REFRESH_TIME_INVALID;
						break;
					}
				}

				recordDiner.setDinerIds(DinerMgr.randomRefreshDiners(cfgDinerBag, dinerCfg));

				recordDiner.setQualityType(qualityType);
				recordDiner.setLastRefreshTime(nowTime);

				DinerMgr.refreshRecordDinerData(playerNode.getPlayerInfo().getDinerInfoData().getDinerData(),
					recordDiner,
					recordDinerData,
					playerId); // DB

				builder.setDinerPackage(DinerMgr.buildDinerPackage(recordDiner,
					RecordDiner.getSystemRefreshTimeMultiTimes(qualityType, nowTime, dinerCfg),
					cd));
				builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}
		System.out.println(result);
		builder.setResult(result);
		builder.setCallback(request.getCallback());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}

	/*
	 * int exceedMaxRefreshCount(RecordDinerData recordDinerData, int qualityType, VipConfig vipCfg, int vipLevel, int
	 * refreshType) { int result = ClientProtocols.E_GAME_REFRESH_DINER_LIST_SUCCESS; if (refreshType ==
	 * ClientServerCommon.AvatarConfig._AvatarCountryType.UnKnow) { return
	 * ClientProtocols.E_GAME_REFRESH_DINER_LIST_FAILED_CAMP_TYPE_INVALID; } int configNormalRefreshCount =
	 * getNormalRefreshCountByType(qualityType, vipCfg, vipLevel); int configSpecialRefreshCount =
	 * getSpecialRefreshCountByType(qualityType, vipCfg, vipLevel);
	 * 
	 * if (configNormalRefreshCount < 0 || configSpecialRefreshCount < 0) { return
	 * ClientProtocols.E_GAME_REFRESH_DINER_LIST_QUALITY_TYPE_INVALID_ERROR; // 类型错误 }
	 * 
	 * int normalRefreshCount = recordDinerData.getRecordDiner(qualityType).getNormalRefreshCount(); int
	 * specialRefreshCount = recordDinerData.getRecordDiner(qualityType).getSpecialRefreshCount();
	 * 
	 * if ((normalRefreshCount >= configNormalRefreshCount && refreshType ==
	 * ClientServerCommon.DinerConfig._DinerRefreshType.Common) || (specialRefreshCount >= configSpecialRefreshCount &&
	 * refreshType != ClientServerCommon.DinerConfig._DinerRefreshType.Common)) { return
	 * ClientProtocols.E_GAME_REFRESH_DINER_LIST_FAILED_EXCEED_MAX_REFRESH_COUNT; }
	 * 
	 * return result; }
	 */

	/*
	 * public int getSpecialRefreshCountByType(int qualityType, VipConfig vipCfg, int vipLevel) { switch (qualityType) {
	 * case ClientServerCommon.DinerConfig._AvatarRarityType.Normal: return vipCfg.GetVipLimitByVipLevel(vipLevel,
	 * VipConfig._VipLimitType.DinerNorRefreshSpecialCount); case ClientServerCommon.DinerConfig._AvatarRarityType.Rare:
	 * return vipCfg.GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.DinerRareRefreshSpecialCount); case
	 * ClientServerCommon.DinerConfig._AvatarRarityType.Elite: return vipCfg.GetVipLimitByVipLevel(vipLevel,
	 * VipConfig._VipLimitType.DinerEliRefreshSpecialCount); default: return -1; } }
	 * 
	 * public int getNormalRefreshCountByType(int qualityType, VipConfig vipCfg, int vipLevel) { switch (qualityType) {
	 * case ClientServerCommon.DinerConfig._AvatarRarityType.Normal: return vipCfg.GetVipLimitByVipLevel(vipLevel,
	 * VipConfig._VipLimitType.DinerNorRefreshAllCount); case ClientServerCommon.DinerConfig._AvatarRarityType.Rare:
	 * return vipCfg.GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.DinerRareRefreshAllCount); case
	 * ClientServerCommon.DinerConfig._AvatarRarityType.Elite: return vipCfg.GetVipLimitByVipLevel(vipLevel,
	 * VipConfig._VipLimitType.DinerEliRefreshAllCount); default: return -1; } }
	 */

}
