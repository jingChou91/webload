package com.kodgames.corgi.server.gameserver.diner.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;
import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.gamedata.dbcommon.DBEasy;
import com.kodgames.gamedata.player.PlayerNode;

public class RowDiner
{
	private static final Logger logger = LoggerFactory.getLogger(RowDiner.class);

	//游戏初始化，加载玩家雇佣的门客数据
	public static void selectDiners(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs,
		PlayerNode playerNode)
		throws SQLException
	{
		String sql = "select hired_diners, record_diners from diner_info where player_id = " + playerNode.getPlayerId();
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, null);

		if (vrs[queryIndex] != null)
		{
			CachedRowSet rs = vrs[queryIndex];
			while (rs.next())
			{
				byte[] buffer = rs.getBytes("hired_diners");
				if (buffer != null)
				{
					DBProtocolsForServer.DinerData.Builder builder = DBProtocolsForServer.DinerData.newBuilder();
					try
					{
						builder.mergeFrom(buffer);
					}
					catch (InvalidProtocolBufferException e)
					{
						logger.error(ExceptionUtils.getStackTrace(e));
					}
					playerNode.getPlayerInfo().getDinerInfoData().getDinerData().fromProtoBuff(builder.build());
				}
				
				byte[] record_dinersBuffer = rs.getBytes("record_diners");

				if (record_dinersBuffer != null)
				{
					DBProtocolsForServer.RecordDinerData.Builder builder =
						DBProtocolsForServer.RecordDinerData.newBuilder();
					try
					{
						builder.mergeFrom(record_dinersBuffer);
					}
					catch (InvalidProtocolBufferException e)
					{
						logger.error(ExceptionUtils.getStackTrace(e));
					}
					playerNode.getPlayerInfo().getDinerInfoData().getRecordDinerData().fromProtoBuff(builder.build());
				}
			}
		}
	}
}
