package com.kodgames.corgi.server.gameserver.diner.db;

import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.dbclient.TableChangeEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.diner.data.DinerData;
import com.kodgames.corgi.server.gameserver.diner.data.RecordDinerData;

public class DinerDB
{

	 // 更新雇佣门客信息
	public static void updateDinerInfoData(DinerData dinerData, RecordDinerData recordDinerData, int playerId)
	{
		String sql =
			String.format("replace into diner_info(player_Id, hired_diners, record_diners) values(%d, %s, %s)",
				playerId,
				ServerUtil.toHexString(dinerData.toProtoBuff().toByteArray()),
				ServerUtil.toHexString(recordDinerData.toProtoBuff().toByteArray()));
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(TableChangeEvent.getKey(playerId, TableChangeEvent.DINER_INFO_UPDATEDINERINFODATA),playerId, sql);
	}
}
