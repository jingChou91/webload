/*
 * 文 件 名:  CG_HireDinerReqHandler.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述: 
 * 创 建 人:  ZYL
 * 创建时间:  2014年5月27日
 * 修 改 人:  <修改人>
 * 修改时间:  2014年5月27日
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.diner.logic;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DinerConfig;
import ClientServerCommon.VipConfig;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_HireDinerReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_HireDinerRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.avatar.data.Avatar;
import com.kodgames.corgi.server.gameserver.diner.data.Diner;
import com.kodgames.corgi.server.gameserver.diner.data.DinerData;
import com.kodgames.corgi.server.gameserver.diner.data.DinerMgr;
import com.kodgames.corgi.server.gameserver.diner.data.RecordDiner;
import com.kodgames.corgi.server.gameserver.diner.data.RecordDinerData;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;

/**
 * 雇佣门客处理
 * 
 * @author ZYL
 * @version [版本号, 2014年5月27日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */

public class CG_HireDinerReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_HireDinerReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		CG_HireDinerReq request = (CG_HireDinerReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);
		GC_HireDinerRes.Builder builder = GC_HireDinerRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_HIRE_DINER_RES);
		builder.setCallback(request.getCallback());

		int dinerId = request.getDinerId();
		int qualityType = request.getQualityType();

		int playerId = sender.getClientUID().getPlayerID();

		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();

		int result = ClientProtocols.E_GAME_HIRE_DINER_SUCCESS;
		logger.info("recv CG_HireDinerReq, playerId = {}", playerId);
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				// 加载玩家失败
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					logger.warn("get playerInfo failed, playerId = {}", playerId);
					result = ClientProtocols.E_GAME_HIRE_DINER_FAILED_LOAD_PLAYER_FAILED;
					break;
				}

				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Diner))
				{
					result = ClientProtocols.E_GAME_DINER_FUNCTION_NOT_OPEN;
					break;
				}

				// 加载Diner Cfg失败;
				ClientServerCommon.DinerConfig dinerCfg = cd.get_DinerConfig();
				if (dinerCfg == null)
				{
					result = ClientProtocols.E_GAME_HIRE_DINER_FAILED_CONFIG_ERROR;
					break;
				}

				// 加载Diner失败;
				ClientServerCommon.DinerConfig.Diner cfgDiner = dinerCfg.GetDinerById(dinerId);
				if (cfgDiner == null)
				{
					result = ClientProtocols.E_GAME_HIRE_DINER_FAILED_CONFIG_DINER_INVALID_ERROR;
					break;
				}

				// 类型错误
				if (qualityType != ClientServerCommon.DinerConfig._AvatarRarityType.Normal
					&& qualityType != ClientServerCommon.DinerConfig._AvatarRarityType.Rare
					&& qualityType != ClientServerCommon.DinerConfig._AvatarRarityType.Elite)
				{
					result = ClientProtocols.E_GAME_HIRE_DINER_FAILED_QUALITY_TYPE_INVALID_ERROR;
					break;
				}

				long nowTime = System.currentTimeMillis();
				RecordDinerData recordDinerData = playerNode.getPlayerInfo().getDinerInfoData().getRecordDinerData();
				RecordDiner recordDiner = recordDinerData.getRecordDiner(qualityType);
				if(null == recordDiner)
				{
					result = ClientProtocols.E_GAME_HIRE_DINER_FAILED_QUALITY_TYPE_INVALID_ERROR;
					break;
				}
				// 判断系统是否可以重置
				if (RecordDiner.canSystemReset(recordDiner.getLastResetTime(), nowTime, dinerCfg))
				{
					// recordDiner.setNormalRefreshCount(0);
					// recordDiner.setSpecialRefreshCount(0);
					recordDiner.setLastResetTime(nowTime);
				}

				if (RecordDiner.canSystemRefreshMultiTimes(qualityType,
					nowTime,
					recordDiner.getLastRefreshTime(),
					dinerCfg))
				{
					DinerConfig.DinerBag dinerBag =
						dinerCfg.GetDinerBagByRefreshType(qualityType,
							ClientServerCommon.DinerConfig._DinerRefreshType.System);

					// 查找配置文件中是否有数据
					if (dinerBag == null)
					{
						result = ClientProtocols.E_GAME_QUERY_DINER_LIST_FAILED_CONFIG_DINER_BAG_NOT_FOUND_ERROR;
						break;
					}
					ArrayList<Integer> ids = DinerMgr.randomRefreshDiners(dinerBag, dinerCfg);

					// 查找配置文件中是否有数据
					if (ids == null)
					{
						result = ClientProtocols.E_GAME_QUERY_DINER_LIST_FAILED_CONFIG_DINER_BAG_NOT_FOUND_ERROR;
						break;
					}
					recordDiner.setDinerIds(ids);
					recordDiner.setLastRefreshTime(nowTime);
				}

				// 记录中没有该 Diner
				if (!recordDinerData.existsRecordDiner(qualityType, dinerId))
				{
					result = ClientProtocols.E_GAME_HIRE_DINER_FAILED_DINER_NOT_EXISTS_IN_LIST;
					break;
				}
				DinerData dinerData = playerNode.getPlayerInfo().getDinerInfoData().getDinerData();

				// Diner已经存在，不能雇佣，只能续约
				if (dinerData != null && dinerData.getDiner(dinerId, qualityType) != null)
				{
					result = ClientProtocols.E_GAME_HIRE_DINER_FAILED_DINER_EXISTS;
					break;
				}

				// 第一次登陆，初始化数据
				if (dinerData.getDiners().size() == 0)
				{
					dinerData.addDiners(ClientServerCommon.DinerConfig._AvatarRarityType.Normal, new ArrayList<Diner>());
					dinerData.addDiners(ClientServerCommon.DinerConfig._AvatarRarityType.Rare, new ArrayList<Diner>());
					dinerData.addDiners(ClientServerCommon.DinerConfig._AvatarRarityType.Elite, new ArrayList<Diner>());
				}

				// 判断是否超过最大雇佣次数
				VipConfig vipCfg = cd.get_VipConfig();
				int vipLevel = playerNode.getGamePlayer().getVipLevel();
				
				ClientServerCommon.DinerConfig.AvatarSlice avatarSlice = cd.get_DinerConfig().GetDinerById(request.getDinerId()).get_AvatarSlice();
				ClientServerCommon.AvatarConfig.Avatar cfgAvatar = cd.get_AvatarConfig().GetAvatarById(avatarSlice.get_AvatarId());
				int qualityLevel = cfgAvatar.get_qualityLevel();
				result = exceedMaxHireCount(dinerData, qualityLevel, vipCfg, vipLevel, cd);

				if (result != ClientProtocols.E_GAME_HIRE_DINER_SUCCESS)
				{
					break;
				}

				// 检查消耗品
				ArrayList<Cost> costs = new ArrayList<Cost>();
				for (int i = 0; i < cfgDiner.Get_CostsCount(); ++i)
				{
					costs.add(new Cost(cfgDiner.Get_CostsByIndex(i).get_id(), cfgDiner.Get_CostsByIndex(i).get_count()));
				}
				Cost notEnoughCost = new Cost();
				if (CostAndRewardManager.checkCosts(playerNode,
					costs,
					cd,
					KodLogEvent.DinerLogic_HireDiner,
					notEnoughCost) == false)
				{
					crsForClient.setNotEnoughCost(notEnoughCost);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_HIRE_DINER_FAILED_CONSUMABLE_NOT_ENOUGH;
					break;
				}
				CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
				CostAndRewardManager.consumeCosts(playerNode, costs, cd, KodLogEvent.DinerLogic_HireDiner, 0, 0);

				crsForCost.setCosts(costs);
				crsForClient.megerCostAndRewardAndSync(crsForCost);

				Diner needHireDiner = new Diner();
				int remainTime = cfgDiner.get_RemainTime();

				needHireDiner.setDinerId(dinerId);
				needHireDiner.setAvatarGuid(new Guid());
				needHireDiner.setQualityType(qualityType);
				needHireDiner.setDeadLineTime(nowTime + remainTime * 3600 * 1000);
				needHireDiner.setLastHireOrRenewTime(nowTime);

				CommonProtocols.Avatar avatar = new Avatar().toProtoBuffer(cd, needHireDiner);
				CommonProtocols.Reward.Builder rewardBuilder = CommonProtocols.Reward.newBuilder();
				rewardBuilder.addAvatars(avatar);

				CommonProtocols.CostAndRewardAndSync.Builder crsBuilder =
					CommonProtocols.CostAndRewardAndSync.newBuilder();
				crsBuilder.setReward(rewardBuilder);
				crsBuilder.mergeFrom(crsForClient.toProtobuf());

				builder.setCostAndRewardAndSync(crsBuilder);

				com.kodgames.corgi.protocol.CommonProtocols.HiredDiner.Builder hiredDinerBuilder =
					com.kodgames.corgi.protocol.CommonProtocols.HiredDiner.newBuilder();
				hiredDinerBuilder.setAvatarGuid(avatar.getGuid());
				hiredDinerBuilder.setEndTime(nowTime + remainTime * 3600 * 1000);
				hiredDinerBuilder.setHireTime(nowTime);
				hiredDinerBuilder.setDinerId(dinerId);
				hiredDinerBuilder.setQualityType(qualityType);
				hiredDinerBuilder.setState(cfgDiner.get_State());

				builder.setHiredDiner(hiredDinerBuilder);

				DinerMgr.addDinerData(dinerData, recordDinerData, needHireDiner, playerId);
				
				//Log
				BPUtil.zmmk(playerNode, qualityType, dinerId);
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		builder.setCallback(request.getCallback());

		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}

	int exceedMaxHireCount(DinerData dinerData, int qualityLevel, VipConfig vipCfg, int vipLevel, ConfigDatabase cd)
	{
		int result = ClientProtocols.E_GAME_HIRE_DINER_SUCCESS;
		int maxHireCount = 0;
		switch (qualityLevel)
		{
			case 3:
			{
				maxHireCount = vipCfg.GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.ThreeHangersEmploymentCount);
				break;
			}
			case 4:
			{
				maxHireCount = vipCfg.GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.FourHangersEmploymentCount);
				break;
			}
			case 5:
			{
				maxHireCount = vipCfg.GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.FiveHangersEmploymentCount);
				break;
			}
			default:
				break;
		}
		if (result == ClientProtocols.E_GAME_HIRE_DINER_SUCCESS)
		{
			if (dinerData.getDinerCountByQuality(qualityLevel, cd) >= maxHireCount)
			{
				result = ClientProtocols.E_GAME_HIRE_DINER_FAILED_EXCEED_MAX_HIRE_COUNT;
				// 超过最大可雇佣次数
			}
		}
		return result;
	}

}
