/*
 * 文 件 名:  CG_QueryDinerListReqHandler.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述: 
 * 创 建 人:  ZYL
 * 创建时间:  2014年5月27日
 * 修 改 人:  <修改人>
 * 修改时间:  2014年5月27日
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.diner.logic;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DinerConfig;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryDinerListReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryDinerListRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.diner.data.Diner;
import com.kodgames.corgi.server.gameserver.diner.data.DinerData;
import com.kodgames.corgi.server.gameserver.diner.data.DinerMgr;
import com.kodgames.corgi.server.gameserver.diner.data.RecordDiner;
import com.kodgames.corgi.server.gameserver.diner.data.RecordDinerData;
import com.kodgames.corgi.server.gameserver.diner.db.DinerDB;
import com.kodgames.gamedata.player.PlayerNode;

/**
 * 查询门客处理
 * 
 * @author ZYL
 * @version [版本号, 2014年5月27日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */

public class CG_QueryDinerListReqHandler extends MessageHandler
{
	private static final Logger logger = LoggerFactory.getLogger(CG_QueryDinerListReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{

		CG_QueryDinerListReq request = (CG_QueryDinerListReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryDinerListRes.Builder builder = GC_QueryDinerListRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_DINER_LIST_RES);
		builder.setCallback(request.getCallback());
		int result = ClientProtocols.E_GAME_QUERY_DINER_LIST_DINER_SUCCESS;

		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		logger.info("recv CG_QueryDinerListReq, playerId = {}", playerId);
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					logger.warn("get playerInfo failed, playerId = {}", playerId);
					result = ClientProtocols.E_GAME_QUERY_DINER_LIST_LOAD_PLAYER_FAILED; // 加载玩家失败
					break;
				}
				
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Diner))
				{
					result = ClientProtocols.E_GAME_DINER_FUNCTION_NOT_OPEN;
					break;
				}

				ClientServerCommon.DinerConfig dinerCfg = cd.get_DinerConfig();
				if (dinerCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DINER_LIST_FAILED_CONFIG_ERROR; // 加载Diner Cfg失败;
					break;
				}
				RecordDinerData recordDinerData = playerNode.getPlayerInfo().getDinerInfoData().getRecordDinerData(); // 玩家上次数据库中保留的数据，读取到内存中的数据,保留的数据
				if (recordDinerData.getRecordDiners().size() == 0)
				{
					recordDinerData.addRecordDiner(ClientServerCommon.DinerConfig._AvatarRarityType.Normal,
						new RecordDiner());
					recordDinerData.addRecordDiner(ClientServerCommon.DinerConfig._AvatarRarityType.Rare,
						new RecordDiner());
					recordDinerData.addRecordDiner(ClientServerCommon.DinerConfig._AvatarRarityType.Elite,
						new RecordDiner());
				}
				Set<Entry<Integer, RecordDiner>> entries = recordDinerData.getRecordDiners().entrySet();
				Long nowTime = System.currentTimeMillis();

				boolean needUpdateDataBase = false;
				for (Entry<Integer, RecordDiner> entry : entries)
				{

					int qualityType = entry.getKey();
					RecordDiner recordDiner = entry.getValue();

					// 第一次初始化，没有数据
					if (entry.getValue().getDinerIds().size() == 0)
					{
						DinerConfig.DinerBag dinerBag =
							dinerCfg.GetDinerBagByRefreshType(entry.getKey(),
								ClientServerCommon.DinerConfig._DinerRefreshType.System);

						// 没有找到该包
						if (dinerBag == null)
						{
							result = ClientProtocols.E_GAME_QUERY_DINER_LIST_FAILED_CONFIG_DINER_BAG_NOT_FOUND_ERROR;
							break;
						}

						// 没有找到该包
						ArrayList<Integer> ids = DinerMgr.randomRefreshDiners(dinerBag, dinerCfg);
						if (ids == null)
						{
							result = ClientProtocols.E_GAME_QUERY_DINER_LIST_FAILED_CONFIG_DINER_BAG_NOT_FOUND_ERROR;
							break;
						}
						recordDiner.setDinerIds(ids);
						recordDiner.setLastRefreshTime(nowTime);
						recordDiner.setLastResetTime(nowTime);
					//	recordDiner.setNormalRefreshCount(0);
					//	recordDiner.setSpecialRefreshCount(0);
						recordDiner.setQualityType(qualityType);
						needUpdateDataBase = true;
					}
					else
					{
						// 如果系统可以重置的设置
						if (RecordDiner.canSystemReset(recordDiner.getLastResetTime(), nowTime, dinerCfg))
						{
				//			recordDiner.setNormalRefreshCount(0);
				//			recordDiner.setSpecialRefreshCount(0);
							recordDiner.setLastResetTime(nowTime);
							needUpdateDataBase = true;
						}

						// 如果需要系统刷新门客的设置
						if (RecordDiner.canSystemRefreshMultiTimes(qualityType,
							nowTime,
							recordDiner.getLastRefreshTime(),
							dinerCfg))
						{
							DinerConfig.DinerBag dinerBag =
								dinerCfg.GetDinerBagByRefreshType(entry.getKey(),
									ClientServerCommon.DinerConfig._DinerRefreshType.System);
							if (dinerBag == null)
							{
								result =
									ClientProtocols.E_GAME_QUERY_DINER_LIST_FAILED_CONFIG_DINER_BAG_NOT_FOUND_ERROR;
								break;
							}

							ArrayList<Integer> ids = DinerMgr.randomRefreshDiners(dinerBag, dinerCfg);
							if (ids == null)
							{
								result =
									ClientProtocols.E_GAME_QUERY_DINER_LIST_FAILED_CONFIG_DINER_BAG_NOT_FOUND_ERROR;
								break;
							}
							recordDiner.setDinerIds(ids);
							recordDiner.setLastRefreshTime(nowTime);
							needUpdateDataBase = true;
						}
					}
					if (result != ClientProtocols.E_GAME_QUERY_DINER_LIST_DINER_SUCCESS)
					{
						break;
					}
					builder.addDinerPackages(DinerMgr.buildDinerPackage(recordDiner,
						RecordDiner.getSystemRefreshTimeMultiTimes(entry.getKey(), nowTime, dinerCfg),
						cd));
				}
				if (result != ClientProtocols.E_GAME_QUERY_DINER_LIST_DINER_SUCCESS)
				{
					break;
				}
				
				//刷新已经解雇的门课
				DinerData dinerData = playerNode.getPlayerInfo().getDinerInfoData().getDinerData();
				if(dinerData != null)
				{
					Set<Entry<Integer, ArrayList<Diner>>> dinerEntries = dinerData.getDiners().entrySet();
					for(Entry<Integer,  ArrayList<Diner>> entry : dinerEntries)
					{
						Iterator<Diner> iter= entry.getValue().iterator();
						while(iter.hasNext())
						{
							Diner diner = iter.next();
							if(diner.getDeadLineTime() < nowTime)
							{
								iter.remove();
								needUpdateDataBase = true;
							}
						}
					}
				}
				
				if (needUpdateDataBase == true)
				{
					DinerDB.updateDinerInfoData(playerNode.getPlayerInfo().getDinerInfoData().getDinerData(),
						recordDinerData,
						playerId);
				}
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}
		builder.setResult(result);
		builder.setCallback(request.getCallback());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}

}