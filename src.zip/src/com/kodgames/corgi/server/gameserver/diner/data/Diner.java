/*
 * 文 件 名:  Diner.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述: 
 * 创 建 人:  ZYL
 * 创建时间:  2014年5月27日
 * 修 改 人:  <修改人>
 * 修改时间:  2014年5月27日
 * 修改内容:  <修改内容>
 */

package com.kodgames.corgi.server.gameserver.diner.data;

import com.kodgames.common.Guid;
import com.kodgames.corgi.protocol.DBProtocolsForServer;

/**
 * 一个门客的数据及相关操作
 * 
 * @author // 门客信息，对应数据库中玩家雇佣的一条门客的信息
 * @version [版本号, 2014年5月27日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */

public class Diner
{
	// 门客Id
	private int dinerId;

	// 门客品质
	private int qualityType;

	// 门客对应角色的avatarGuid
	private Guid avatarGuid;

	// 门客到期时间
	private long deadLineTime;

	// 上一次雇佣或者刷新时间
	private long lastHireOrRenewTime;

	public int getDinerId()
	{
		return dinerId;
	}

	public void setDinerId(int dinerId)
	{
		this.dinerId = dinerId;
	}

	public Guid getAvatarGuid()
	{
		return avatarGuid;
	}

	public void setAvatarGuid(Guid avatarGuid)
	{
		this.avatarGuid = avatarGuid;
	}

	public int getQualityType()
	{
		return qualityType;
	}

	public void setQualityType(int qualityType)
	{
		this.qualityType = qualityType;
	}

	public long getLastHireOrRenewTime()
	{
		return lastHireOrRenewTime;
	}

	public void setLastHireOrRenewTime(long lastHireOrRenewTime)
	{
		this.lastHireOrRenewTime = lastHireOrRenewTime;
	}

	public long getDeadLineTime()
	{
		return deadLineTime;
	}

	public void setDeadLineTime(long deadLineTime)
	{
		this.deadLineTime = deadLineTime;
	}

	public DBProtocolsForServer.Diner toProtoBuff()
	{
		DBProtocolsForServer.Diner.Builder proto = DBProtocolsForServer.Diner.newBuilder();
		proto.setDinerId(dinerId);
		proto.setQualityType(qualityType);
		proto.setAvatarGuid(avatarGuid.toString());
		proto.setDeadLineTime(deadLineTime);
		proto.setHireTime(lastHireOrRenewTime);
		return proto.build();
	}

	public void fromProtoBuff(DBProtocolsForServer.Diner protoDiner)
	{
		setDinerId(protoDiner.getDinerId());
		setQualityType(protoDiner.getQualityType());
		setDeadLineTime(protoDiner.getDeadLineTime());
		setLastHireOrRenewTime(protoDiner.getHireTime()); // 获取上次刷新时间
		setAvatarGuid(Guid.genNewGuid(protoDiner.getAvatarGuid()));
	}
}
