/*
 * 文 件 名:  DinerMgr.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述: 
 * 创 建 人:  ZYL
 * 创建时间:  2014年5月27日
 * 修 改 人:  <修改人>
 * 修改时间:  2014年5月27日
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.diner.data;

import java.util.ArrayList;
import java.util.List;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DinerConfig;
import ClientServerCommon.MeridianConfig;

import com.kodgames.common.ValueRandomer;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.server.gameserver.diner.db.DinerDB;

/**
 * 门客数据库和内存管理，以及额外的一些辅助功能
 * 
 * @author ZYL
 * @version [版本号, 2014年5月27日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
public class DinerMgr
{

	public static void removeDinerData(DinerData dinerData, RecordDinerData recordDinerData, ArrayList<Diner> diners, int playerId)
	{
		for(Diner diner : diners)
		{
			dinerData.removeDiner(diner.getDinerId(), diner.getQualityType());
		}
		DinerDB.updateDinerInfoData(dinerData, recordDinerData, playerId);
	}

	public static void addDinerData(DinerData dinerData, RecordDinerData recordDinerData, Diner diner, int playerId)
	{
		dinerData.addDiner(diner);
		DinerDB.updateDinerInfoData(dinerData, recordDinerData, playerId);
	}

	public static void renewDinerData(DinerData dinerData, RecordDinerData recordDinerData, Diner diner, int playerId)
	{
		dinerData.removeDiner(diner.getDinerId(), diner.getQualityType());
		dinerData.addDiner(diner);
		DinerDB.updateDinerInfoData(dinerData, recordDinerData, playerId);
	}

	public static void refreshRecordDinerData(DinerData dinerData, RecordDiner recordDiner,
		RecordDinerData recordDinerData, int playerId)
	{
		recordDinerData.removeRecordDiner(recordDiner.getQualityType());
		recordDinerData.addRecordDiner(recordDiner.getQualityType(), recordDiner);
		DinerDB.updateDinerInfoData(dinerData, recordDinerData, playerId);
	}

	// 随机得出每个包中的唯一的门客Id,且保证Id不会重复
	public static ArrayList<Integer> randomRefreshDiners(DinerConfig.DinerBag dinerBag,
		ClientServerCommon.DinerConfig dinerCfg)
	{
		ArrayList<Integer> dinerIds = new ArrayList<Integer>();
		ValueRandomer random = new ValueRandomer();
		int bagCounts = dinerBag.get_DinerBagIds().get_Count();
		for (int i = 0; i < bagCounts; ++i)
		{
			// 随机品质
			random.Clear();
			int bagId = dinerBag.Get_DinerBagIdsByIndex(i);
			DinerConfig.DinerBagMap bagMap = dinerCfg.GetDinerBagMap(bagId);
			for (int j = 0; j < bagMap.Get_DinerQualityMapCount(); ++j)
			{
				random.addValue(bagMap.Get_DinerQualityMapByIndex(j).get_Factor(), bagMap.Get_DinerQualityMapByIndex(j)
					.get_DinerQualityMapId());
			}

			random.SetTotalValue();
			int idx = random.Random();
			if (idx != -1)
			{
				int qualityId = (int)random.GetData(idx);
				random.Clear();

				// 从品质随机id
				DinerConfig.DinerAvatarFactorMap dinerMap = dinerCfg.GetDinerAvatarFactorMap(qualityId);
				int dinerCount = dinerMap.Get_DinerIdFactorMapCount();

				for (int j = 0; j < dinerCount; ++j)
				{
					random.addValue(dinerMap.Get_DinerIdFactorMapByIndex(j).get_DinerFactor(),
						dinerMap.Get_DinerIdFactorMapByIndex(j).get_DinerId());
				}
				int dinerId = 0;
				do
				{
					random.SetTotalValue();
					idx = random.Random();
					if (idx == -1)
						break;
					dinerId = (Integer)random.GetData(idx);
					random.removeValue(idx);
				} while (dinerIds.contains(dinerId));
				if (dinerId != 0)
				{
					dinerIds.add(dinerId);
				}
			}
		}
		return dinerIds;
	}

	// 生成DinerPackge供客户端使用
	public static CommonProtocols.DinerPackage.Builder buildDinerPackage(RecordDiner recordDiner,
		long nextSystemRefreshTime, ConfigDatabase cd)
	{

		CommonProtocols.DinerPackage.Builder dinerPackageBuilder = CommonProtocols.DinerPackage.newBuilder();
		dinerPackageBuilder.setQualityType(recordDiner.getQualityType());

		dinerPackageBuilder.setNormalRefreshAmount(recordDiner.getNormalRefreshCount());
		dinerPackageBuilder.setSpecialRefreshAmonut(recordDiner.getSpecialRefreshCount());

		dinerPackageBuilder.setLastRefreshTime(recordDiner.getLastRefreshTime());
		dinerPackageBuilder.setNextRefreshTime(nextSystemRefreshTime);
		dinerPackageBuilder.setRefreshCountResetTime(recordDiner.getLastResetTime());

		for (int dinerId : recordDiner.getDinerIds())
		{
			CommonProtocols.QueryDiner.Builder queryDinerBuilder = CommonProtocols.QueryDiner.newBuilder();

			queryDinerBuilder.setDinerId(dinerId);

			ClientServerCommon.DinerConfig.Diner cfgDiner = cd.get_DinerConfig().GetDinerById(dinerId);
			ClientServerCommon.DinerConfig.AvatarSlice avatarSlice = cfgDiner.get_AvatarSlice();

			queryDinerBuilder.setAvatarResourceId(avatarSlice.get_AvatarId());
			queryDinerBuilder.setLevel(avatarSlice.get_AvatarLevel());
			queryDinerBuilder.setBreakThroughLevel(avatarSlice.get_BreakThroughLevel());

			CommonProtocols.DomineerData.Builder domineerDatabuilder = CommonProtocols.DomineerData.newBuilder();
			for (int i = 0; i < avatarSlice.Get_DomineeringMapCount(); ++i)
			{
				ClientServerCommon.DinerConfig.ItemTuple itemTuple = avatarSlice.Get_DomineeringMapByIndex(i);
				CommonProtocols.Domineer.Builder domineerBuilder = CommonProtocols.Domineer.newBuilder();
				domineerBuilder.setDomineerId(itemTuple.get_Key());
				domineerBuilder.setLevel(itemTuple.get_Value());
				domineerDatabuilder.addDomineers(domineerBuilder.build());
			}
			queryDinerBuilder.setDomineerData(domineerDatabuilder.build());

			// 经脉
			for (int i = 0; i < avatarSlice.Get_MeridiansMapCount(); ++i)
			{
				CommonProtocols.MeridianData.Builder meridianDataBuilder = CommonProtocols.MeridianData.newBuilder();
				ClientServerCommon.DinerConfig.ItemTuple itemTuple = avatarSlice.Get_MeridiansMapByIndex(i);
				meridianDataBuilder.setId(itemTuple.get_Key());

				MeridianConfig.Meridian meridianCfg = cd.get_MeridianConfig().GetMeridianById(itemTuple.get_Key());

				MeridianConfig.Buff buffCfg = cd.get_MeridianConfig().GetBuffById(itemTuple.get_Value());
				if (meridianCfg != null && buffCfg != null)
				{
					for (int j = 0; j < buffCfg.get_modifierSet().Get_modifiersCount(); j++)
					{
						ClientServerCommon.PropertyModifier modifierCfg = buffCfg.get_modifierSet().Get_modifiersByIndex(j);
						CommonProtocols.PropertyModifier.Builder modifierBuilder =
							CommonProtocols.PropertyModifier.newBuilder();

						modifierBuilder.setType(modifierCfg.get_type());
						modifierBuilder.setModifyType(modifierCfg.get_modifyType());
						modifierBuilder.setAttributeType(modifierCfg.get_attributeType());
						modifierBuilder.setAttributeValue(modifierCfg.get_attributeValue());
						meridianDataBuilder.addModifiers(modifierBuilder);
					}
				}
				queryDinerBuilder.addMeridianDatas(meridianDataBuilder.build());
			}
			queryDinerBuilder.setState(cfgDiner.get_State());

			for (int i = 0; i < cfgDiner.Get_CostsCount(); ++i)
			{
				ClientServerCommon.Cost cost = cfgDiner.Get_CostsByIndex(i);
				queryDinerBuilder.addCosts(new com.kodgames.gamedata.player.costandreward.Cost(cost.get_id(),
					cost.get_count()).toProtobuf());
			}
			dinerPackageBuilder.addQueryDiners(queryDinerBuilder);
		}
		return dinerPackageBuilder;
	}
	
	public static CommonProtocols.HiredDiner getHiredDiner(List<CommonProtocols.HiredDiner> hiredDiners, String guid)
	{
		for(CommonProtocols.HiredDiner hiredDiner : hiredDiners)
		{
			if(hiredDiner.getAvatarGuid().equals(guid))
			{
				return hiredDiner;
			}
		}
		return null;
	}

}
