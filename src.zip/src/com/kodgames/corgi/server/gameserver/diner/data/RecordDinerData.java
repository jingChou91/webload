/*
 * 文 件 名: RecordDinerData.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述: 
 * 创 建 人:  ZYL
 * 创建时间:  2014年5月27日
 * 修 改 人:  <修改人>
 * 修改时间:  2014年5月27日
 * 修改内容:  <修改内容>
 */

package com.kodgames.corgi.server.gameserver.diner.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import com.kodgames.corgi.protocol.DBProtocolsForServer;

/**
 * 刷新列表门客集合类。 所有品质门客的列表,以及相关内存操作, 对应数据库中记录的门客列表
 * 
 * @author ZYL
 * @version [版本号, 2014年5月27日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */

public class RecordDinerData
{
	private HashMap<Integer, RecordDiner> recordDiners = new HashMap<Integer, RecordDiner>();

	public HashMap<Integer, RecordDiner> getRecordDiners()
	{
		return recordDiners;
	}

	public void setRecordDiners(HashMap<Integer, RecordDiner> recordDiners)
	{
		this.recordDiners = recordDiners;
	}

	public RecordDiner getRecordDiner(int qualityType)
	{
		return recordDiners.get(qualityType);
	}

	public void addRecordDiner(int qualityType, RecordDiner recordDiner)
	{
		if (!recordDiners.containsKey(qualityType))
		{
			recordDiners.put(qualityType, recordDiner);
		}
	}

	public void removeRecordDiner(int qualityType)
	{
		if (recordDiners.containsKey(qualityType))
		{
			recordDiners.remove(qualityType);
		}
	}

	// 判断集合中是否存在RecordDiner
	public boolean existsRecordDiner(int qualityType, int dinerId)
	{
		if (!recordDiners.containsKey(qualityType))
		{
			return false;
		}
		ArrayList<Integer> ids = recordDiners.get(qualityType).getDinerIds();
		for (int id : ids)
		{
			if (id == dinerId)
			{
				return true;
			}
		}
		return false;
	}

	public DBProtocolsForServer.RecordDinerData toProtoBuff()
	{
		DBProtocolsForServer.RecordDinerData.Builder proto = DBProtocolsForServer.RecordDinerData.newBuilder();
		Set<Entry<Integer, RecordDiner>> entries = recordDiners.entrySet();
		for (Entry<Integer, RecordDiner> entry : entries)
		{
			RecordDiner recordDiner = entry.getValue();
			proto.addRecordDiners(recordDiner.toProtoBuff());
		}
		return proto.build();
	}

	public void fromProtoBuff(DBProtocolsForServer.RecordDinerData protoRecordDinerData)
	{
		for (int i = 0; i < protoRecordDinerData.getRecordDinersCount(); ++i)
		{
			RecordDiner recordDiner = new RecordDiner();
			recordDiner.fromProtoBuff(protoRecordDinerData.getRecordDiners(i));
			recordDiners.put(recordDiner.getQualityType(), recordDiner);
		}
	}

}
