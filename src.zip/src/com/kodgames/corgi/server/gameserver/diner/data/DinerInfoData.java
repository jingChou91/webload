/*
 * 文 件 名:  DinerInfoData.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述:  DinerData 和recordDinerData的 数据集合,方便统一操作
 * 创 建 人:  ZYL
 * 创建时间:  2014年5月27日
 * 修 改 人:  <修改人>
 * 修改时间:  2014年5月27日
 * 修改内容:  <修改内容>
 */

package com.kodgames.corgi.server.gameserver.diner.data;


/**
 * DinerData 和recordDinerData的 数据集合,方便统一操作
 * 
 * @author ZYL
 * @version [版本号, 2014年5月27日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
public class DinerInfoData
{
	private DinerData dinerData = new DinerData();
	private RecordDinerData recordDinerData = new RecordDinerData();

	public DinerData getDinerData()
	{
		return dinerData;
	}

	public void setDinerData(DinerData dinerData)
	{
		this.dinerData = dinerData;
	}

	public RecordDinerData getRecordDinerData()
	{
		return recordDinerData;
	}

	public void setRecordDinerData(RecordDinerData recordDinerData)
	{
		this.recordDinerData = recordDinerData;
	}

}
