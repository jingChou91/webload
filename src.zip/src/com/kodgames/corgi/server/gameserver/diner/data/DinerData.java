/*
 * 文 件 名:  DinerData.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述: 
 * 创 建 人:  ZYL
 * 创建时间:  2014年5月27日
 * 修 改 人:  <修改人>
 * 修改时间:  2014年5月27日
 * 修改内容:  <修改内容>
 */
package com.kodgames.corgi.server.gameserver.diner.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.common.Guid;
import com.kodgames.corgi.protocol.DBProtocolsForServer;

/**
 * 某个 玩家所有已雇佣门客的信息
 * 
 * @author // 门客信息，对应数据库中玩家雇佣的一条门客的信息
 * @version [版本号, 2014年5月27日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
public class DinerData
{
	private HashMap<Integer, ArrayList<Diner>> diners = new HashMap<Integer, ArrayList<Diner>>();

	public HashMap<Integer, ArrayList<Diner>> getDiners()
	{
		return diners;
	}

	public void setDiners(HashMap<Integer, ArrayList<Diner>> diners)
	{
		this.diners = diners;
	}

	// 判断门客Guid是否存在
	public boolean isExistGuid(Guid guid)
	{
		Set<Entry<Integer, ArrayList<Diner>>> entries = diners.entrySet();

		// 遍历所有品质类型
		for (Entry<Integer, ArrayList<Diner>> entry : entries)
		{
			// 品质类型对应的门客
			for (Diner diner : entry.getValue())
			{
				// 若不存在guid或者门客已经到期则返回则不存在
				if (diner.getAvatarGuid().equals(guid) && diner.getDeadLineTime() > System.currentTimeMillis())
				{
					return true;
				}
			}
		}
		return false;
	}

	// 通过Guid获取门客
	public Diner getDiner(Guid guid)
	{
		for (Entry<Integer, ArrayList<Diner>> entry : diners.entrySet())
		{
			for (Diner diner : entry.getValue())
			{
				if (diner.getAvatarGuid().equals(guid) && diner.getDeadLineTime() > System.currentTimeMillis())
				{
					return diner;
				}
			}
		}

		return null;
	}
	
	
	// 获取当前门客数量
	public int getDinerCountByQuality(int qualityLevel, ConfigDatabase cd)
	{
		int count = 0;
		for (Entry<Integer, ArrayList<Diner>> entry : diners.entrySet())
		{
			for (Diner diner : entry.getValue())
			{
				if (diner.getDeadLineTime() > System.currentTimeMillis())
				{
					ClientServerCommon.DinerConfig.AvatarSlice avatarSlice = cd.get_DinerConfig().GetDinerById(diner.getDinerId()).get_AvatarSlice();
					ClientServerCommon.AvatarConfig.Avatar avatar = cd.get_AvatarConfig().GetAvatarById(avatarSlice.get_AvatarId());
					if(avatar.get_qualityLevel() == qualityLevel)
					{
						++count;
					}					
				}
			}
		}
		return count;
	}

	// 添加某一品质下的门客季候
	public void addDiners(int qualityType, ArrayList<Diner> diners)
	{
		this.diners.put(qualityType, diners);
	}

	public Diner getDiner(int dinerId, int qualityType)
	{
		if (diners.containsKey(qualityType))
		{
			for (int i = 0; i < diners.get(qualityType).size(); ++i)
			{
				if (diners.get(qualityType).get(i).getDinerId() == dinerId)
				{
					return diners.get(qualityType).get(i);
				}
			}
		}
		return null;
	}

	public void removeDiner(int dinerId, int qualityType)
	{
		if (diners.containsKey(qualityType))
		{
			for (int i = 0; i < diners.get(qualityType).size(); ++i)
			{
				if (diners.get(qualityType).get(i).getDinerId() == dinerId)
				{
					diners.get(qualityType).remove(i);
				}
			}
		}
	}

	public void addDiner(Diner diner)
	{
		if (diners.containsKey(diner.getQualityType()))
		{
			ArrayList<Diner> dinerList = diners.get(diner.getQualityType());
			dinerList.add(diner);
		}
		else
		{
			ArrayList<Diner> dinerList = new ArrayList<Diner>();
			dinerList.add(diner);
			diners.put(diner.getQualityType(), dinerList);
		}
	}

	public DBProtocolsForServer.DinerData toProtoBuff()
	{
		DBProtocolsForServer.DinerData.Builder proto = DBProtocolsForServer.DinerData.newBuilder();
		if (diners != null)
		{
			Set<Entry<Integer, ArrayList<Diner>>> entries = diners.entrySet();

			for (Entry<Integer, ArrayList<Diner>> entry : entries)
			{
				for (Diner diner : entry.getValue())
				{
					proto.addDiners(diner.toProtoBuff());
				}
			}
		}
		return proto.build();
	}

	public void fromProtoBuff(DBProtocolsForServer.DinerData protoData)
	{
		if (this.diners.size() != 0)
		{
			this.diners.clear();
		}
		for (int i = 0; i < protoData.getDinersCount(); ++i)
		{
			Diner diner = new Diner();
			diner.fromProtoBuff(protoData.getDiners(i));
			this.addDiner(diner);
		}
	}

}
