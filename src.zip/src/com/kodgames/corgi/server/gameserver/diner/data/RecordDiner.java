/*
 * 文 件 名: RecordDiner.java
 * 版    权:  KodGames Co., Ltd. Copyright 2011-2014,  All rights reserved
 * 描    述: 
 * 创 建 人:  ZYL
 * 创建时间:  2014年5月27日
 * 修 改 人:  <修改人>
 * 修改时间:  2014年5月27日
 * 修改内容:  <修改内容>
 */

package com.kodgames.corgi.server.gameserver.diner.data;

import java.util.ArrayList;
import java.util.HashMap;

import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.corgi.server.common.ServerUtil;

/**
 * 刷新列表门客类
 * 
 * @author ZYL
 * @version [版本号, 2014年5月27日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */

public class RecordDiner
{
	private ArrayList<Integer> dinerIds = new ArrayList<Integer>();

	// 门客品级枚举【1普通 2.精英 3.稀有】
	private int qualityType;

	// 玩家已经刷新的次数
	private int specialRefreshCount;

	// 特殊刷新次数
	private int normalRefreshCount;
	// private int hiredDinerCount; //可以通过dinerId的数量计算出来

	// 上次刷新的时间
	private long lastRefreshTime;

	// 上次刷新的时间
	private long lastResetTime;

	public int getQualityType()
	{
		return qualityType;
	}

	public void setQualityType(int qualityType)
	{
		this.qualityType = qualityType;
	}

	public int getSpecialRefreshCount()
	{
		return specialRefreshCount;
	}

	public void setSpecialRefreshCount(int refreshCount)
	{
		this.specialRefreshCount = refreshCount;
	}

	public int getNormalRefreshCount()
	{
		return normalRefreshCount;
	}

	public void setNormalRefreshCount(int refreshCount)
	{
		this.normalRefreshCount = refreshCount;
	}

	public long getLastRefreshTime()
	{
		return lastRefreshTime;
	}

	public void setLastRefreshTime(long lastRefreshTime)
	{
		this.lastRefreshTime = lastRefreshTime;
	}

	public long getLastResetTime()
	{
		return lastResetTime;
	}

	public void setLastResetTime(long lastResetTime)
	{
		this.lastResetTime = lastResetTime;
	}

	public ArrayList<Integer> getDinerIds()
	{
		return dinerIds;
	}

	public void setDinerIds(ArrayList<Integer> dinerIds)
	{
		this.dinerIds = dinerIds;
	}

	public DBProtocolsForServer.RecordDiner toProtoBuff()
	{
		com.kodgames.corgi.protocol.DBProtocolsForServer.RecordDiner.Builder proto =
			DBProtocolsForServer.RecordDiner.newBuilder();
		proto.setQualityType(qualityType);
		proto.setNormalRefreshCount(normalRefreshCount);
		proto.setSpecialRefreshCount(specialRefreshCount);
		proto.setLastRefreshTime(lastRefreshTime);
		proto.setLastResetTime(lastResetTime);
		for (int i = 0; i < dinerIds.size(); ++i)
		{
			proto.addDinerIds(dinerIds.get(i));
		}
		return proto.build();
	}

	public void fromProtoBuff(DBProtocolsForServer.RecordDiner protoRecordDiner)
	{
		setQualityType(protoRecordDiner.getQualityType());
		setNormalRefreshCount(protoRecordDiner.getNormalRefreshCount());
		setSpecialRefreshCount(protoRecordDiner.getSpecialRefreshCount());
		setLastRefreshTime(protoRecordDiner.getLastRefreshTime());
		setLastResetTime(protoRecordDiner.getLastResetTime());
		dinerIds.clear();
		for (int i = 0; i < protoRecordDiner.getDinerIdsCount(); ++i)
		{
			dinerIds.add(protoRecordDiner.getDinerIds(i));
		}
	}

	private static HashMap<Integer, ArrayList<Long>> getThisRefreshTimes(ClientServerCommon.DinerConfig dinerCfg,
		long nowTimeMillis)
	{
		HashMap<Integer, ArrayList<Long>> refreshTimes = new HashMap<Integer, ArrayList<Long>>();

		long cfgTime;
		long cfgTimeWithZone;

		for (int i = 0; i < dinerCfg.Get_DinerBagRefreshTimesCount(); ++i)
		{
			ClientServerCommon.DinerConfig.DinerBagRefreshTime rf = dinerCfg.Get_DinerBagRefreshTimesByIndex(i);
			int quality = rf.get_DinerBagQuality();
			ArrayList<Long> times = new ArrayList<Long>();
			for (int j = 0; j < rf.Get_RefreshTimesCount(); ++j)
			{
				cfgTime =
					ClientServerCommon.ConvertTicksToMs.DateTimeToInt64(dinerCfg.toDateTime(rf.Get_RefreshTimesByIndex(j)));
				cfgTimeWithZone = ServerUtil.getLongForJava(cfgTime, TimeZoneData.getTimeZone());// 8区的10:15的long
				times.add(cfgTimeWithZone);
			}
			refreshTimes.put(quality, times);
		}
		return refreshTimes;
	}

	public static boolean canSystemReset(long nowTimeMillis, long lastRefreshTime,
		ClientServerCommon.DinerConfig dinerCfg)
	{
		long cfgTime =
			ClientServerCommon.ConvertTicksToMs.DateTimeToInt64(dinerCfg.toDateTime(dinerCfg.get_ResetTime()));
		long cfgTimeWithZone = ServerUtil.getLongForJava(cfgTime, TimeZoneData.getTimeZone());
		long thisResetTime = cfgTimeWithZone;

		long time1 = getNextRefreshTime(nowTimeMillis, thisResetTime);
		long time2 = getNextRefreshTime(lastRefreshTime, thisResetTime);

		if (time1 != time2)
		{
			return true;
		}
		return false;
	}

	public static Long getNextRefreshTime(long time, long refreshTime)
	{
		long dtime = refreshTime - time;

		dtime = dtime % (24 * 60 * 60 * 1000L); //

		if (dtime > 0)
		{
			refreshTime = dtime + time;
		}
		else
		{
			refreshTime = dtime + time + 24 * 60 * 60 * 1000;
		}

		return refreshTime;// 相对于time的下次刷新时间
	}

	public static boolean canSystemRefreshMultiTimes(int qualityType, long nowMillions, long lastRefreshTime,
		ClientServerCommon.DinerConfig dinerCfg)
	{
		ArrayList<Long> nowDates = getThisRefreshTimes(dinerCfg, nowMillions).get(qualityType);

		for (long nowDate : nowDates)
		{
			long time1 = getNextRefreshTime(nowMillions, nowDate);
			long time2 = getNextRefreshTime(lastRefreshTime, nowDate);
			if (time1 != time2)
			{
				return true;
			}
		}
		return false;

	}

	// 根据当前时间获取下次刷新时间
	public static long getSystemRefreshTimeMultiTimes(int qualityType, long nowMillions,
		ClientServerCommon.DinerConfig dinerCfg)
	{
		ArrayList<Long> nowDates = getThisRefreshTimes(dinerCfg, nowMillions).get(qualityType);
		long nextRefreshTime = getNextRefreshTime(nowMillions, nowDates.get(0));
		for (int i = 1; i < nowDates.size(); ++i)
		{
			if (nextRefreshTime > getNextRefreshTime(nowMillions, nowDates.get(i)))
			{
				nextRefreshTime = getNextRefreshTime(nowMillions, nowDates.get(i));
			}
		}
		return nextRefreshTime;
	}

}
