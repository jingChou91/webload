package com.kodgames.corgi.server.gameserver.diner;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.diner.logic.CG_FireDinerReqHandler;
import com.kodgames.corgi.server.gameserver.diner.logic.CG_HireDinerReqHandler;
import com.kodgames.corgi.server.gameserver.diner.logic.CG_QueryDinerListReqHandler;
import com.kodgames.corgi.server.gameserver.diner.logic.CG_RefreshDinerListReqHandler;
import com.kodgames.corgi.server.gameserver.diner.logic.CG_RenewDinerReqHandler;

public class Logic_Diner {
	private CG_QueryDinerListReqHandler cg_QueryDinerListReqHandler = null;
	private CG_HireDinerReqHandler cg_HireDinerReqHandler = null;
	private CG_FireDinerReqHandler cg_FireDinerReqHandler = null;
	private CG_RenewDinerReqHandler cg_RenewDinerReqHandler = null;
	private CG_RefreshDinerListReqHandler cg_RefreshDinerListReqHandler = null;

	

	public void init() {	
		cg_QueryDinerListReqHandler = new CG_QueryDinerListReqHandler();
		cg_HireDinerReqHandler = new CG_HireDinerReqHandler();
		cg_FireDinerReqHandler = new CG_FireDinerReqHandler();
		cg_RenewDinerReqHandler = new CG_RenewDinerReqHandler();
		cg_RefreshDinerListReqHandler = new CG_RefreshDinerListReqHandler();
	}
	
	public void registerProtoBufType(Controller controller) {	
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_DINER_LIST_REQ, GameProtocolsForClient.CG_QueryDinerListReq.getDefaultInstance());
        controller.registerMessageLite(ClientProtocols.P_GAME_CG_HIRE_DINER_REQ, GameProtocolsForClient.CG_HireDinerReq.getDefaultInstance());        
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_FIRE_DINER_REQ, GameProtocolsForClient.CG_FireDinerReq.getDefaultInstance());
        controller.registerMessageLite(ClientProtocols.P_GAME_CG_RENEW_DINER_REQ, GameProtocolsForClient.CG_RenewDinerReq.getDefaultInstance());        
        controller.registerMessageLite(ClientProtocols.P_GAME_CG_REFRESH_DINER_LIST_REQ, GameProtocolsForClient.CG_RefreshDinerListReq.getDefaultInstance());        

	}
	
	public void registerMessageHandler(Controller controller) {	
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_DINER_LIST_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryDinerListReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_HIRE_DINER_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_HireDinerReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_FIRE_DINER_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_FireDinerReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_RENEW_DINER_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_RenewDinerReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_REFRESH_DINER_LIST_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_RefreshDinerListReqHandler));
	}
}
