package com.kodgames.corgi.server.gameserver.domineer.db;

import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.dbclient.TableChangeEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.gamedata.player.PlayerNode;

public class DomineerDB
{
	public static void replaceDomineer(int playerId, PlayerNode playerNode)
	{
		String sqlCommand =
			String.format("replace into domineer (player_id, domineer_info) values(%d, %s)",
				playerId,
				ServerUtil.toHexString(playerNode.getPlayerInfo().getDomineerData().toDBProtoBuf().toByteArray()));
		ServerDataGS.dbCluster.getGameDBClient().executeAsynchronousUpdate(TableChangeEvent.getKey(playerId, TableChangeEvent.DOMINEER_REPLACEDOMINEER),playerId, sqlCommand);
	}
}
