package com.kodgames.corgi.server.gameserver.domineer.logic;

import java.util.ArrayList;
import java.util.HashSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.AvatarConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DomineerConfig;

import com.kodgames.common.Guid;
import com.kodgames.common.ValueRandomer;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_ChangeDomineerReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_ChangeDomineerRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.dbclient.bplog.BPUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.avatar.data.Avatar;
import com.kodgames.corgi.server.gameserver.avatar.data.AvatarMgr;
import com.kodgames.corgi.server.gameserver.avatar.data.Card;
import com.kodgames.corgi.server.gameserver.domineer.data.Domineer;
import com.kodgames.corgi.server.gameserver.domineer.data.DomineerMgr;
import com.kodgames.gamedata.player.PlayerAttributeMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.genplayer.PowerMgr;

public class CG_ChangeDomineerReqHandler extends MessageHandler {

	private static final Logger logger = LoggerFactory.getLogger(CG_ChangeDomineerReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message) {

		CG_ChangeDomineerReq request = (CG_ChangeDomineerReq) message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_ChangeDomineerRes.Builder builder = GC_ChangeDomineerRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_CHANGE_DOMINEER_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();
		int result = ClientProtocols.E_GAME_CHANGE_DOMINEER_SUCCESS;
		logger.info("recv CG_ChangeDomineerReq, playerId = {}", playerId);
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if(playerNode ==null||playerNode.getPlayerInfo()==null)
				{
					logger.warn("get playerInfo failed, playerId = {}", playerId);
					result = ClientProtocols.E_GAME_CHANGE_DOMINEER_FAILED_LOAD_PLAYER;
					break;
				}
				
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Domineer))
				{
					result = ClientProtocols.E_GAME_DOMINEER_FUNCTION_NOT_OPEN;
					break;
				}
				
				//判断玩家等级是否达到开启条件
				int level = playerNode.getGamePlayer().getLevel();
				if(level < cd.get_LevelConfig().GetPlayerLevelByOpenFunciton(ClientServerCommon._OpenFunctionType.AvatarDomineer))
				{
					logger.warn("playerLevel = {} not enough...", playerId);
					result = ClientProtocols.E_GAME_CHANGE_DOMINEER_FAILED_PLAYER_LEVEL_NOT_ENOUGH;
					break;
				}

				Avatar avatar = AvatarMgr.getAvatar(Guid.genNewGuid(request.getAvatarGuid()), playerNode);
                if(avatar == null)
                {
                	result = ClientProtocols.E_GAME_CHANGE_DOMINEER_FAILED_AVATAR_NOT_EXISTS;
					break;
                }

                DomineerConfig domineerConfig = cd.get_DomineerConfig();
                if(domineerConfig == null)
                {
                	result = ClientProtocols.E_GAME_CHANGE_DOMINEER_FAILED_DOMINEERCONFIG_ERROR;
					break;
                }
                
                //如果上次洗练没有保存或者取消,不能继续洗练
                Domineer domineer = playerNode.getPlayerInfo().getDomineerData().getDomineer(Guid.genNewGuid(request.getAvatarGuid()));
                if(domineer.getUnsaveDomineer().size() != 0)
                {
                	result = ClientProtocols.E_GAME_CHANGE_DOMINEER_FAILED_RESULT_NOT_SAVE;
					break;
                }
                
                //判断该角色的突破等级是否达到开启要求
                if(avatar.getBreakthoughtLevel() < domineerConfig.get_NeedAvatarBreakThroughLevel())
                {
                	result = ClientProtocols.E_GAME_CHANGE_DOMINEER_FAILED_AVATAR_BREAKTHROUGH_LEVEL_NOT_ENOUGH;
					break;
                }
                
                
                //判断销毁角色ID是否有效
                HashSet<String> guids = new HashSet<>();
                for(String desGuid : request.getDestroyAvatarGUIDsList())
                {
                	Avatar avatarDestory = AvatarMgr.getAvatar(Guid.genNewGuid(desGuid), playerNode);
                	if(avatarDestory == null|| avatarDestory.getResourceId() != avatar.getResourceId() || avatarDestory.getGuid().equals(request.getAvatarGuid()) )
                	{
                		result = ClientProtocols.E_GAME_CHANGE_DOMINEER_FAILED_DESTROY_AVATAR_ERROR;
    					break;
                	}
                	
                    //判断消耗角色是否在上阵
                    if(playerNode.getPlayerInfo().getPositionData().checkGuid(avatarDestory.getGuid()) == false)
                    {
                    	result = ClientProtocols.E_GAME_CHANGE_DOMINEER_FAILED_AVATAR_IN_POSITION;
    					break;
                    }
                	
                	guids.add(desGuid);//防止有重复的GUID
                }
                if(guids.size() != request.getDestroyAvatarGUIDsCount() ||result != ClientProtocols.E_GAME_CHANGE_DOMINEER_SUCCESS)
                {
                	break;
                }
                
                int domineerLevel = playerNode.getPlayerInfo().getDomineerData().getDomineerLevel(Guid.genNewGuid(request.getAvatarGuid()));
                AvatarConfig.Avatar avatarCfg = cd.get_AvatarConfig().GetAvatarById(avatar.getResourceId());
                if(avatarCfg == null)
                {
                	result = ClientProtocols.E_GAME_CHANGE_DOMINEER_FAILED_AVATARCONFIG_ERROR;
					break;
                }
                
                //如果是第一次洗练初始化数据
                if(domineer.getDomineers().size() == 0)
                {
                	DomineerConfig.DefaultDomineer defaultDomineer = domineerConfig.GetDefaultDomineerByCountryType(avatarCfg.get_countryType());
                	if(defaultDomineer == null)
                	{
                		result = ClientProtocols.E_GAME_CHANGE_DOMINEER_FAILED_DOMINEERCONFIG_ERROR;
    					break;
                	}
                	
                	domineer.getDomineers().add(defaultDomineer.get_DomineerId());
                	domineer.setLevel(defaultDomineer.get_Level());
                }
            
                
                
                //判断配置文件是否正确
                DomineerConfig.DomineerCostSet domineerCostSet = domineerConfig.GetDomineerCostSetByQualityLevel(avatarCfg.get_qualityLevel());
                if(domineerCostSet == null)
                {
                	result = ClientProtocols.E_GAME_CHANGE_DOMINEER_FAILED_DOMINEERCONFIG_ERROR;
					break;
                }
                
                DomineerConfig.DomineerCost domineerCost = domineerCostSet.GetDomineerCostByLevel(domineerLevel);
                if(domineerCost == null)
                {
                	result = ClientProtocols.E_GAME_CHANGE_DOMINEER_FAILED_DOMINEERCONFIG_ERROR;
					break;
                }
                
                //检查消耗是否足够
                int needCardCount = domineerCost.get_ItemCostItemCount() / domineerCost.get_SameCardDeductItemCount();
                ArrayList<Cost> costs = new ArrayList<>();
                int realItemCount = 0;
                if(needCardCount <= request.getDestroyAvatarGUIDsCount())
                {
                	for(int i = 0 ; i < needCardCount ; i++)
                	{
                		costs.add(new Cost(avatar.getResourceId(), Guid.genNewGuid(request.getDestroyAvatarGUIDs(i))));
                	}
                }
                else
                {
                	for(String guid : request.getDestroyAvatarGUIDsList())
                	{
                		costs.add(new Cost(avatar.getResourceId(), Guid.genNewGuid(guid)));
                	}
					
                	realItemCount = domineerCost.get_ItemCostItemCount() - request.getDestroyAvatarGUIDsCount() * domineerCost.get_SameCardDeductItemCount();
                	costs.add(new Cost(domineerCost.get_ItemCostItemId(), realItemCount));
				}
                
                for(int i = 0; i <domineerCost.Get_OtherCostsCount() ; i++)
                {
                	ClientServerCommon.Cost cost = domineerCost.Get_OtherCostsByIndex(i);
                	Cost otherCost = new Cost(cost.get_id(), cost.get_count());
                	costs.add(otherCost);
                }
                
                //判断消耗是否足够
                Cost notEnoughCost = new Cost();
                if(false == CostAndRewardManager.checkCosts(playerNode, costs, cd, KodLogEvent.DomineerLogic_ChangeDomineer, notEnoughCost))
                {
                	crsForClient.setNotEnoughCost(notEnoughCost);
                	builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
                	result = ClientProtocols.E_GAME_CHANGE_DOMINEER_FAILED_CONSUMABLE_IS_NOT_ENOUGH;
					break;
                }
                
                
                int donmineerSkillLevel = domineer.getLevel() >= avatarCfg.get_qualityLevel() ? avatarCfg.get_qualityLevel() : (domineer.getLevel()+1);
                //随机合纵技能
                int oldSkillId = 0;
                for(Integer domineerSkillId : domineer.getDomineers())
                {
                	DomineerConfig.Domineer domineerCfg = domineerConfig.GetDomineerById(domineerSkillId);
                	if(domineerCfg != null && domineerCfg.get_Type() == DomineerConfig._DomineerType.HeZong)
                	{
                		oldSkillId = domineerCfg.get_DomineerId();
                		break;
                	}
                }
                
                int newHeZongSkillId = randomDomineerSkill(DomineerConfig._DomineerType.HeZong,domineerConfig,donmineerSkillLevel,oldSkillId);
                domineer.getUnsaveDomineer().add(newHeZongSkillId);
                
                //随机连横技能
                oldSkillId = 0;
                for(Integer domineerSkillId : domineer.getDomineers())
                {
                	DomineerConfig.Domineer domineerCfg = domineerConfig.GetDomineerById(domineerSkillId);
                	if(domineerCfg != null && domineerCfg.get_Type() == DomineerConfig._DomineerType.LianHeng)
                	{
                		oldSkillId = domineerCfg.get_DomineerId();
                		break;
                	}
                }
                newHeZongSkillId = randomDomineerSkill(DomineerConfig._DomineerType.LianHeng,domineerConfig,donmineerSkillLevel,oldSkillId);
                domineer.getUnsaveDomineer().add(newHeZongSkillId);
                
                // 有霸气技能的卡牌不再是基础卡牌
                if (Card.isBasicCard(playerNode, avatar))
				{
					AvatarMgr.updateAvatar(playerNode, avatar, true);
				}
                
                //数据库内存操作
                DomineerMgr.updateDomineer(playerNode, domineer);
                
                //消耗物品
                CostAndRewardManager.consumeCosts(playerNode, costs, cd, KodLogEvent.DomineerLogic_ChangeDomineer, 0, 0);
                CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
                crsForCost.setCosts(costs);
                crsForClient.megerCostAndRewardAndSync(crsForCost);
                
                builder.setAvatar(avatar.toProtoBuffer(playerNode, cd));
                
                BPUtil.xkbq(playerNode, avatar.getResourceId(), request.getDestroyAvatarGUIDsList().size(), realItemCount);
                
              //战力
				float power = PowerMgr.calPower(playerNode, cd);
				PlayerAttributeMgr.setPlayerPower(playerNode, (int)power);
			}while(false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
		builder.setResult(result);
		builder.setCallback(request.getCallback());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
	
	private int randomDomineerSkill(int domineerType, DomineerConfig domineerConfig, int level, int oldDomineerSkillId)
	{
		ValueRandomer random = new ValueRandomer();
		for(int i = 0;i<domineerConfig.Get_DomineersCount();i++)
		{
			DomineerConfig.Domineer domineercfg	= domineerConfig.Get_DomineersByIndex(i);
			if(domineercfg == null || domineercfg.get_Type() != domineerType || domineercfg.GetDomineerLevelByLevel(level) == null ||domineercfg.get_DomineerId() == oldDomineerSkillId)
				continue;
			
			random.addValue(domineercfg.GetDomineerLevelByLevel(level).get_Weight(),domineercfg);
		}
		
		random.SetTotalValue();
		int idx = random.Random();
		DomineerConfig.Domineer domineercfg = (DomineerConfig.Domineer) random.GetData(idx);
		return domineercfg.get_DomineerId();
	}
	
}


