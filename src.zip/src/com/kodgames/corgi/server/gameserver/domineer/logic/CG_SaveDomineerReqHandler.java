package com.kodgames.corgi.server.gameserver.domineer.logic;

import java.util.HashSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.AvatarConfig;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DomineerConfig;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_SaveDomineerReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_SaveDomineerRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.avatar.data.Avatar;
import com.kodgames.corgi.server.gameserver.avatar.data.AvatarMgr;
import com.kodgames.corgi.server.gameserver.avatar.data.Card;
import com.kodgames.corgi.server.gameserver.domineer.data.Domineer;
import com.kodgames.corgi.server.gameserver.domineer.data.DomineerMgr;
import com.kodgames.gamedata.player.PlayerAttributeMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.genplayer.PowerMgr;

public class CG_SaveDomineerReqHandler extends MessageHandler {

	private static final Logger logger = LoggerFactory.getLogger(CG_SaveDomineerReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message) {

		CG_SaveDomineerReq request = (CG_SaveDomineerReq) message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_SaveDomineerRes.Builder builder = GC_SaveDomineerRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_SAVE_DOMINEER_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		int result = ClientProtocols.E_GAME_SAVE_DOMINEER_SUCCESS;
		logger.info("recv CG_SaveDomineerReq, playerId = {}", playerId);
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if(playerNode ==null||playerNode.getPlayerInfo()==null)
				{
					logger.warn("get playerInfo failed, playerId = {}", playerId);
					result = ClientProtocols.E_GAME_SAVE_DOMINEER_FAILED_LOAD_PLAYER;
					break;
				}
				
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, ClientServerCommon._OpenFunctionType.Domineer))
				{
					result = ClientProtocols.E_GAME_DOMINEER_FUNCTION_NOT_OPEN;
					break;
				}
				
				Avatar avatar = AvatarMgr.getAvatar(Guid.genNewGuid(request.getAvatarGuid()), playerNode);
                if(avatar == null)
                {
                	result = ClientProtocols.E_GAME_SAVE_DOMINEER_FAILED_AVATAR_NOT_EXISTS;
					break;
                }

                DomineerConfig domineerConfig = cd.get_DomineerConfig();
                if(domineerConfig == null)
                {
                	result = ClientProtocols.E_GAME_SAVE_DOMINEER_FAILED_DOMINEERCONFIG_ERROR;
					break;
                }
                
                AvatarConfig.Avatar avatarCfg = cd.get_AvatarConfig().GetAvatarById(avatar.getResourceId());
                if(avatarCfg == null)
                {
                	result = ClientProtocols.E_GAME_SAVE_DOMINEER_FAILED_AVATARCONFIG_ERROR;
					break;
                }
                
                Domineer domineer = playerNode.getPlayerInfo().getDomineerData().getDomineer(Guid.genNewGuid(request.getAvatarGuid()));
                if(domineer.getUnsaveDomineer().size() == 0)
                {
                	result = ClientProtocols.E_GAME_SAVE_DOMINEER_FAILED_NOT_RESULT_SAVE;
					break;
                }
                
                if(request.getIsSave())          	
                {
                	domineer.setDomineers(domineer.getUnsaveDomineer());
                	domineer.setUnsaveDomineer(new HashSet<Integer>());
                	
                	
                	//更新等级
                	int donmineerSkillLevel = domineer.getLevel() >= avatarCfg.get_qualityLevel() ? avatarCfg.get_qualityLevel() : (domineer.getLevel()+1);
                    domineer.setLevel(donmineerSkillLevel);
                }
                else
                {
                	//判断VIP
                	int openVipLevel = cd.get_VipConfig().GetVipLevelByOpenFunctionType(_OpenFunctionType.UnsaveAvatarDomineer);
                	if(playerNode.getGamePlayer().getVipLevel() < openVipLevel)
                	{
                		result = ClientProtocols.E_GAME_SAVE_DOMINEER_FAILED_VIP_NOT_ENOUGH;
    					break;
                	}
                	
                	domineer.setUnsaveDomineer(new HashSet<Integer>());
				}
                
                // 有霸气技能的卡牌不再是基本卡牌
				if (Card.isBasicCard(playerNode, avatar))
				{
					AvatarMgr.updateAvatar(playerNode, avatar, true);
				}
            	//改数据和内存
            	DomineerMgr.updateDomineer(playerNode, domineer);
            	
            	builder.setAvatar(avatar.toProtoBuffer(playerNode, cd));
            	//战力
				float power = PowerMgr.calPower(playerNode, cd);
				PlayerAttributeMgr.setPlayerPower(playerNode, (int)power);
                
			}while(false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		builder.setCallback(request.getCallback());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}


