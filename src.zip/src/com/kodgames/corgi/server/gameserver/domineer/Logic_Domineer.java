package com.kodgames.corgi.server.gameserver.domineer;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.domineer.logic.CG_ChangeDomineerReqHandler;
import com.kodgames.corgi.server.gameserver.domineer.logic.CG_SaveDomineerReqHandler;

public class Logic_Domineer {
	private CG_ChangeDomineerReqHandler cg_ChangeDomineerReqHandler = null;
	private CG_SaveDomineerReqHandler cg_SaveDomineerReqHandler = null;

	public void init() {	
		cg_ChangeDomineerReqHandler = new CG_ChangeDomineerReqHandler();
		cg_SaveDomineerReqHandler = new CG_SaveDomineerReqHandler();
	}
	
	public void registerProtoBufType(Controller controller) {	
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_CHANGE_DOMINEER_REQ, GameProtocolsForClient.CG_ChangeDomineerReq.getDefaultInstance());
        controller.registerMessageLite(ClientProtocols.P_GAME_CG_SAVE_DOMINEER_REQ,GameProtocolsForClient.CG_SaveDomineerReq.getDefaultInstance());        
	}
	
	public void registerMessageHandler(Controller controller) {	
		controller.addHandler(ClientProtocols.P_GAME_CG_CHANGE_DOMINEER_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_ChangeDomineerReqHandler));
		controller.addHandler(ClientProtocols.P_GAME_CG_SAVE_DOMINEER_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_SaveDomineerReqHandler));
	}
}