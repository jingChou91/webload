package com.kodgames.corgi.server.gameserver.domineer.data;

import com.kodgames.corgi.server.gameserver.domineer.db.DomineerDB;
import com.kodgames.gamedata.player.PlayerNode;

public class DomineerMgr
{
	public static void updateDomineer(PlayerNode playerNode , Domineer domineer)
	{
		playerNode.getPlayerInfo().getDomineerData().getDomineers().put(domineer.getGuid(), domineer);
		
		DomineerDB.replaceDomineer(playerNode.getPlayerId(), playerNode);
	}
}
