package com.kodgames.corgi.server.gameserver.domineer.data;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;

import com.kodgames.common.Guid;
import com.kodgames.corgi.protocol.DBProtocolsForServer;

public class DomineerData
{
	private HashMap<Guid, Domineer> domineers = new HashMap<>();

	// ------------------------------get set--------------------------------------

	public HashMap<Guid, Domineer> getDomineers()
	{
		return domineers;
	}

	public void setDomineers(HashMap<Guid, Domineer> domineers)
	{
		this.domineers = domineers;
	}

	// --------------------------------------------
	public int getDomineerLevel(Guid guid)
	{
		if (domineers.containsKey(guid))
			return domineers.get(guid).getLevel();

		return 0;
	}

	public Domineer getDomineer(Guid guid)
	{
		if (domineers.containsKey(guid))
			return domineers.get(guid);

		return new Domineer(guid);
	}

	public DBProtocolsForServer.DomineerInfo toDBProtoBuf()
	{
		DBProtocolsForServer.DomineerInfo.Builder builder = DBProtocolsForServer.DomineerInfo.newBuilder();
		for (Entry<Guid, Domineer> entry : domineers.entrySet())
		{
			Domineer domineerTemp = entry.getValue();
			DBProtocolsForServer.DomineerDb.Builder domineerDBbuilder = DBProtocolsForServer.DomineerDb.newBuilder();
			domineerDBbuilder.setGuid(domineerTemp.getGuid().toString());
			domineerDBbuilder.setLevel(domineerTemp.getLevel());
			domineerDBbuilder.setUnsaveDomineers(genDomineerStr(domineerTemp.getUnsaveDomineer()));
			domineerDBbuilder.setDomineers(genDomineerStr(domineerTemp.getDomineers()));
			builder.addDomineerDatas(domineerDBbuilder.build());
		}
		return builder.build();
	}

	private String genDomineerStr(HashSet<Integer> set)
	{
		StringBuffer sb = new StringBuffer();
		if (set != null && set.size() > 0)
		{
			int index = 0;
			for (Integer id : set)
			{
				if (id != null)
				{
					if (index == 0)
					{
						sb.append(id);
					}
					else
					{
						sb.append("|" + id);
					}
					++index;
				}
			}
		}

		return sb.toString();
	}

}
