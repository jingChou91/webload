package com.kodgames.corgi.server.gameserver.domineer.data;

import java.util.HashSet;

import com.kodgames.common.Guid;

public class Domineer 
{
	private int level; //霸气技能等级
	private HashSet<Integer> domineers = new HashSet<>(); //未保存的霸气技能
	private HashSet<Integer> unsaveDomineer = new HashSet<>(); //保存的霸气技能
	private Guid guid; //角色GUID
	
	public Domineer(Guid guid)
	{
		this.guid = guid;
	}

	//------------------get  set -------------------------
	public int getLevel()
	{
		return level;
	}
	public Guid getGuid() 
	{
		return guid;
	}
	public void setGuid(Guid guid) 
	{
		this.guid = guid;
	}
	public void setLevel(int level)
	{
		this.level = level;
	}
	public HashSet<Integer> getDomineers() 
	{
		return domineers;
	}
	public void setDomineers(HashSet<Integer> domineers)
	{
		this.domineers = domineers;
	}
	public HashSet<Integer> getUnsaveDomineer() 
	{
		return unsaveDomineer;
	}
	public void setUnsaveDomineer(HashSet<Integer> unsaveDomineer)
	{
		this.unsaveDomineer = unsaveDomineer;
	}
}
