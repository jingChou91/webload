package com.kodgames.corgi.server.gameserver.danhome.data.struct;

import java.util.List;

import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.dan.util.DanUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Alchemy.AlchemyUtil;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon.Logger;

public class SpecialDanReward
{
	private int id;
	private int cycleGetTimes;// 本周期已获得次数
	private int totalGetTimes;// 总共获得次数
	private long lastRefreshTime;// 已经经历过循环的次数

	/**
	 * 判断并激活
	 */
	public boolean active(ConfigDatabase cd, DanConfig.SpecialDanReward specialDanRewardCfg,
		ClientServerCommon.Reward rewardCfg, List<Integer> attributeGroupIds)
	{
		if (AlchemyUtil.verifyTime(specialDanRewardCfg.get_BeginTime(), specialDanRewardCfg.get_EndTime()))
		{
			// 等级和品质满足
			if (SpecialDanReward.verifyLevel(specialDanRewardCfg, rewardCfg))
			{
				// 等级和品质满足
				if (SpecialDanReward.verifyAttributeGroupIds(cd, specialDanRewardCfg, attributeGroupIds))
				{
					// 有剩余次数
					if (totalGetTimes < specialDanRewardCfg.get_MaxGetTimes())
					{
						if (specialDanRewardCfg.get_IsUseCycle())
						{
							if (cycleGetTimes < specialDanRewardCfg.get_CycleMaxGetTimes())
							{
								cycleGetTimes++;
								totalGetTimes++;
								return true;
							}
						}
						else
						{
							totalGetTimes++;
							return true;
						}
					}
				}
			}

		}
		return false;
	}

	/**
	 * 验证属性是否满足激活条件
	 */
	public static boolean verifyAttributeGroupIds(ConfigDatabase cd, DanConfig.SpecialDanReward specialDanRewardCfg,
		List<Integer> attributeGroupIds)
	{
		DanConfig.AttributeAlgorithm attributeAlgorithmCfg =
			cd.get_DanConfig().GetAttributeAlgorithmById(specialDanRewardCfg.get_AlgorithmId());
		if (attributeAlgorithmCfg == null)
		{
			return false;
		}
		for (int i = 0; i < attributeAlgorithmCfg.Get_AlgorithmAttributesCount(); i++)
		{
			DanConfig.AlgorithmAttribute algorithmAttribute = attributeAlgorithmCfg.Get_AlgorithmAttributesByIndex(i);
			for (int j = 0; j < algorithmAttribute.Get_AttributeGroupWeightsCount(); j++)
			{
				DanConfig.AttributeGroupWeight attributeGroupWeight =
					algorithmAttribute.Get_AttributeGroupWeightsByIndex(j);
				int weight = attributeGroupWeight.get_Weight();
				int attributeGroupId = attributeGroupWeight.get_AttributeGroupId();
				// 权重大于0才有效
				if (weight <= 0)
				{
					continue;
				}
				// 随机属性
				if (DanUtil.isRandomAttributeGroupId(attributeGroupId))
				{
					continue;
				}
				else
				{
					if (!attributeGroupIds.contains(attributeGroupId))
					{
						return false;
					}
				}
			}

		}
		return true;

	}

	/**
	 * 验证等级和品质是否满足激活条件
	 */
	public static boolean verifyLevel(DanConfig.SpecialDanReward specialDanRewardCfg,
		ClientServerCommon.Reward rewardCfg)
	{
		if (rewardCfg.get_level() != specialDanRewardCfg.get_Level())
		{
			return false;
		}
		if (rewardCfg.get_breakthoughtLevel() != specialDanRewardCfg.get_Breakthought())
		{
			return false;
		}
		return true;
	}

	/**
	 * 重置周期循环信息
	 */
	public boolean resetCycle(DanConfig.SpecialDanReward specialDanCfg)
	{
		// 判断是否需要重置循环
		if (this.isNeedRefesh(specialDanCfg, lastRefreshTime))
		{
			this.setCycleGetTimes(0);
			this.setLastRefreshTime(System.currentTimeMillis());
			return true;
		}
		return false;
	}

	/**
	 * 判断当前是否需要循环刷新
	 */
	public boolean isNeedRefesh(DanConfig.SpecialDanReward specialDanCfg, long lastRefreshTime)
	{
		if (null == specialDanCfg.get_BeginTime() || "".equals(specialDanCfg.get_BeginTime()))
		{
			Logger.Error("______Alchemy SpecialDanReward Not have BeginTime");
			return false;
		}
		long now = System.currentTimeMillis();
		long begin =
			ServerUtil.convertTimeStringWithTimezoneToLong(TimeZoneData.getTimeZone(), specialDanCfg.get_BeginTime());
		long end =
			ServerUtil.convertTimeStringWithTimezoneToLong(TimeZoneData.getTimeZone(), specialDanCfg.get_EndTime());
		if (now < begin || now > end)
		{
			return false;
		}
		long nextRefreshTime = begin;
		while (nextRefreshTime < lastRefreshTime)
		{
			nextRefreshTime += specialDanCfg.get_CycleDays() * AlchemyUtil.DAY;
		}
		if (begin <= nextRefreshTime && nextRefreshTime <= end)
		{
			if (nextRefreshTime < now)
			{
				return true;
			}
		}
		return false;
	}

	public SpecialDanReward()
	{
	}

	public SpecialDanReward(int id)
	{
		super();
		this.id = id;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public int getCycleGetTimes()
	{
		return cycleGetTimes;
	}

	public void setCycleGetTimes(int cycleGetTimes)
	{
		this.cycleGetTimes = cycleGetTimes;
	}

	public int getTotalGetTimes()
	{
		return totalGetTimes;
	}

	public void setTotalGetTimes(int totalGetTimes)
	{
		this.totalGetTimes = totalGetTimes;
	}

	public long getLastRefreshTime()
	{
		return lastRefreshTime;
	}

	public void setLastRefreshTime(long lastRefreshTime)
	{
		this.lastRefreshTime = lastRefreshTime;
	}

}
