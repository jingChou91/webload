package com.kodgames.corgi.server.gameserver.danhome.logic.alchemy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryDanHomeReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryDanHomeRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.danhome.util.DHUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Alchemy.AlchemyUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Decompose.DecomposeActivityUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Decompose.DecomposeUtil;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_QueryDanHomeReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_QueryDanHomeReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_QueryDanHomeReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_QueryDanHomeReq request = (CG_QueryDanHomeReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryDanHomeRes.Builder builder = GC_QueryDanHomeRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_DAN_HOME_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_QUERY_DAN_HOME_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_HOME_FAILED_LOAD_PLAYER;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.DanHome))
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_HOME_FAILED_FUNCTION_NOT_OPEN;
					break;
				}
				DanConfig danCfg = cd.get_DanConfig();
				if (danCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_HOME_FAILED_LOAD_CONFIG;
					break;
				}
//				DanHomeData dhData = playerNode.getPlayerInfo().getDanHomeData();
				int decomposeActivityNum = DecomposeActivityUtil.getDecomposeActivityNum();

				// 功能是否开启
				if (!danCfg.get_IsDanHomeOpen())
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_HOME_FAILED_DAN_HOME_NOT_OPEN;
					break;
				}
				// 炼丹活动切换
				AlchemyUtil.activityChange(playerNode, cd);
				// 分解
				DecomposeUtil.activityChange(playerNode, cd);
				// 炼丹系统刷新
				DHUtil.systemRefresh(playerNode, cd);
				// 返回客户端分解相关信息
				builder.setDecomposeInfo(DecomposeUtil.genDecomposeInfo(cd, playerNode, decomposeActivityNum));
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
