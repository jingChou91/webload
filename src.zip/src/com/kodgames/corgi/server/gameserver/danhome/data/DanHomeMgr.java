package com.kodgames.corgi.server.gameserver.danhome.data;

import com.kodgames.corgi.server.gameserver.danhome.db.DanHomeDB;
import com.kodgames.gamedata.player.PlayerNode;

public class DanHomeMgr
{
	public static void updateDB(PlayerNode playerNode)
	{
		DanHomeDB.updateDanHome(playerNode);
	}
}
