package com.kodgames.corgi.server.gameserver.danhome.logic.alchemy;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_AlchemyReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_AlchemyRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dan.data.Dan;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeData;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeMgr;
import com.kodgames.corgi.server.gameserver.danhome.util.DHUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Alchemy.AlchemyActivityUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Alchemy.AlchemyUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Decompose.DecomposeActivityUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Decompose.DecomposeUtil;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class CG_AlchemyReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_AlchemyReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_AlchemyReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_AlchemyReq request = (CG_AlchemyReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_AlchemyRes.Builder builder = GC_AlchemyRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_ALCHEMY_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_ALCHEMY_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();

		int type = request.getAlchemyType();
		List<CommonProtocols.Cost> costs_Client = request.getCostsList();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_ALCHEMY_FAILED_LOAD_PLAYER;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.DanHome))
				{
					result = ClientProtocols.E_GAME_ALCHEMY_FAILED_FUNCTION_OPEN;
					break;
				}
				DanConfig danCfg = cd.get_DanConfig();
				if (danCfg == null)
				{
					result = ClientProtocols.E_GAME_ALCHEMY_FAILED_LOAD_CONFIG;
					break;
				}
				DanHomeData dhData = playerNode.getPlayerInfo().getDanHomeData();

				// 功能是否开启
				if (!danCfg.get_IsDanHomeOpen())
				{
					result = ClientProtocols.E_GAME_ALCHEMY_FAILED_DAN_HOME_NOT_OPEN;
					break;
				}
				// 活动切换
				if (AlchemyUtil.activityChange(playerNode, cd))
				{
					builder.setIsNeedRefresh(true);
					break;
				}
				builder.setIsNeedRefresh(false);
				// 系统刷新
				DHUtil.systemRefresh(playerNode, cd);
				int activityNum = AlchemyActivityUtil.getAlchemyActivityNum();
				int alchemyCount = dhData.getAlchemyCount();
				// 炼丹消耗
				ArrayList<Cost> costs = new ArrayList<Cost>();
				if (type == DanConfig._OperateType.Alchemy)
				{
					// 玩家此次炼丹消耗
					Cost alchemyCost = AlchemyUtil.getAlchemyCost(dhData, danCfg, activityNum, alchemyCount);
					costs.add(alchemyCost);

				}
				else if (type == DanConfig._OperateType.BatchAlchemy)
				{
					// 玩家批量炼丹消耗
					costs = AlchemyUtil.getBatchAlchemyCost(dhData, danCfg, activityNum, alchemyCount);

				}
				else
				{
					result = ClientProtocols.E_GAME_ALCHEMY_FAILED_TYPE;
					break;
				}
				logger.debug("____________Client Costs  And  Server Costs Match and Same");
				// 验证客户端消耗和服务器消耗是否一致
				if (!AlchemyUtil.verifyTimeCosts(costs, costs_Client))
				{
					result = ClientProtocols.E_GAME_ALCHEMY_FAILED_COST;
					break;
				}
				// 验证并消耗
				Cost costNotEnough = new Cost();
				CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
				if (!CostAndRewardManager.checkCosts(playerNode, costs, cd, KodLogEvent.Dan_Alchemy, costNotEnough))
				{
					crsForClient.setNotEnoughCost(costNotEnough);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_ALCHEMY_FAILED_COST_NOT_ENOUGH;
					logger.debug("____________Consume Not  Enough!!!");
					break;
				}
				crsForCost.setCosts(costs);
				CostAndRewardManager.consumeCosts(playerNode, costs, cd, KodLogEvent.Dan_Alchemy, 0, 0);
				crsForClient.megerCostAndRewardAndSync(crsForCost);
				logger.debug("____________Consume Enough");

				// 炼丹所有奖励
				List<ClientServerCommon.Reward> rewardCfgs = new ArrayList<ClientServerCommon.Reward>();
				List<ClientServerCommon.Reward> extraRewardCfgs = new ArrayList<ClientServerCommon.Reward>();
				if (type == DanConfig._OperateType.Alchemy)
				{
					// 炼丹奖励
					ClientServerCommon.Reward alchemyRewardCfg = AlchemyUtil.GenAlchemyResult(danCfg, activityNum);
					if (alchemyRewardCfg == null)
					{
						result = ClientProtocols.E_GAME_ALCHEMY_FAILED_ALCHEMY_RESULT_NULL;
						break;
					}
					// 计数器奖励
					ClientServerCommon.Reward counterRewardCfg = AlchemyUtil.GenCounterReward(dhData, cd, activityNum);
					// 如果计数器生效,使用计数器的奖励
					if (counterRewardCfg != null)
					{
						alchemyRewardCfg = counterRewardCfg;
					}
					rewardCfgs.add(alchemyRewardCfg);
					logger.debug("__________Alchemy  Reward,RewardId:" + alchemyRewardCfg.get_id() + " RewardCount:"
						+ alchemyRewardCfg.get_count());
					// 更新今日已炼丹次数
					dhData.addAlchemyCount();
				}
				else if (type == DanConfig._OperateType.BatchAlchemy)
				{
					for (int i = 0; i < danCfg.get_BatchAlchemyCount(); i++)
					{
						// 炼丹奖励
						ClientServerCommon.Reward alchemyRewardCfg = AlchemyUtil.GenAlchemyResult(danCfg, activityNum);
						if (alchemyRewardCfg == null)
						{
							result = ClientProtocols.E_GAME_ALCHEMY_FAILED_ALCHEMY_RESULT_NULL;
							break;
						}
						// 计数器奖励
						ClientServerCommon.Reward counterRewardCfg =
							AlchemyUtil.GenCounterReward(dhData, cd, activityNum);
						// 如果计数器生效,使用计数器的奖励
						if (counterRewardCfg != null)
						{
							alchemyRewardCfg = counterRewardCfg;
						}
						rewardCfgs.add(alchemyRewardCfg);
						logger.debug("__________Alchemy  Reward,RewardId:" + alchemyRewardCfg.get_id()
							+ " RewardCount:" + alchemyRewardCfg.get_count());
						// 更新今日已炼丹次数
						dhData.addAlchemyCount();
					}
				}

				// 保存炼丹结果
				Reward reward = new Reward();
				Reward baseReward = new Reward();
				Reward extraReward = new Reward();
				// 炼丹所有奖励
				for (ClientServerCommon.Reward tmp : rewardCfgs)
				{
					Reward tmpReward = new Reward();
					tmpReward.fromClientServerCommon(tmp);
					for (Dan dan : tmpReward.getDans())
					{
						// 指定内丹奖励
						List<ClientServerCommon.Reward> alchemyRewardCfgs =
							AlchemyUtil.GenSpecialDanReward(dhData, cd, activityNum, tmp, dan.getAttributes());
						AlchemyUtil.mergeServerCommonReward(extraRewardCfgs, alchemyRewardCfgs);
					}
					baseReward.megerReward(tmpReward);
				}
				for (ClientServerCommon.Reward tmp : extraRewardCfgs)
				{
					extraReward.megerReward(new Reward().fromClientServerCommon(tmp));
				}
				reward.megerReward(baseReward).megerReward(extraReward);
				CostAndRewardAndSync crsForReward = new CostAndRewardAndSync();
				CostAndRewardManager.addReward(playerNode, reward, cd, KodLogEvent.Dan_Alchemy);
				crsForReward.mergeReward(reward);
				crsForReward.setViewFixReward(baseReward);
				crsForReward.setViewRandomReward(extraReward);
				crsForClient.megerCostAndRewardAndSync(crsForReward);

				// 保存数据库
				DanHomeMgr.updateDB(playerNode);

				// 返回玩家下次炼丹消耗
				Cost alchemyCost = AlchemyUtil.getAlchemyCost(dhData, danCfg, activityNum, dhData.getAlchemyCount());
				builder.addAlchemyCosts(alchemyCost.toProtobuf());
				// 返回玩家批量炼丹消耗
				List<Cost> batchAlchemyCosts =
					AlchemyUtil.getBatchAlchemyCost(dhData, danCfg, activityNum, dhData.getAlchemyCount());
				for (Cost cost : batchAlchemyCosts)
				{
					builder.addBatchAlchemyCosts(cost.toProtobuf());
				}
				// 返回今日已炼丹次数
				builder.setTodayAlchemyCount(dhData.getAlchemyCount());
				// 返回展示计数器
				CommonProtocols.ShowCounter showCounter = AlchemyUtil.genShowCounterInfo(dhData, cd, activityNum);
				if (showCounter != null)
				{
					builder.setShowCounter(showCounter);
				}
				int decomposeActivityNum = DecomposeActivityUtil.getDecomposeActivityNum();
				// 返回客户端分解相关信息
				builder.setDecomposeInfo(DecomposeUtil.genDecomposeInfo(cd, playerNode, decomposeActivityNum));
				
				// 小助手
				playerNode.getPlayerInfo().getAssisantData().getDanHome().notifyObservers();

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
