package com.kodgames.corgi.server.gameserver.danhome.util.Decompose;

import com.kodgames.corgi.server.gameserver.danhome.Logic_Decompose;
import com.kodgames.gamedata.player.PlayerNode;

public class DecomposeActivityUtil
{
	private static DecomposeActivityUtil dHActivityUtil = null;
	private Logic_Decompose logic_Decompose = null;

	private DecomposeActivityUtil()
	{
	}

	public static synchronized DecomposeActivityUtil getInstance()
	{
		if (null == dHActivityUtil)
		{
			dHActivityUtil = new DecomposeActivityUtil();
		}
		return dHActivityUtil;
	}

	public void setLogic(Logic_Decompose logic)
	{
		this.logic_Decompose = logic;
	}

	/**
	 * 获取当前活动编号(当活动未开启时强制返回0)
	 */
	public static int getDecomposeActivityNum()
	{
		int activityNum =
			DecomposeActivityUtil.getInstance().logic_Decompose.getActivityCurrentIndex(System.currentTimeMillis());
		if (activityNum == -1)
		{
			return -1;
		}
		return activityNum;
	}

	/**
	 * 获取当前活动编号开启时间
	 */
	public static long getDecomposeActivityStartTime(int activityNum)
	{
		long startTime =
			DecomposeActivityUtil.getInstance().logic_Decompose.getDecomposeActivityStartTime(activityNum - 1);
		return startTime;
	}

	/**
	 * 获取当前活动编号关闭时间
	 */
	public static long getDecomposeActivityEndTime(int activityNum)
	{
		long endTime = DecomposeActivityUtil.getInstance().logic_Decompose.getDecomposeActivityEndTime(activityNum - 1);
		return endTime;
	}

	/**
	 * 判断当前活动是否开启
	 */
	public static boolean isDecomposeActivityOpen(long time)
	{
		boolean result = (DecomposeActivityUtil.getDecomposeActivityNum() != 0);
		return result;
	}

	/**
	 * 活动切换
	 */
	public static boolean isDecomposeActivityChange(PlayerNode playerNode)
	{
		int activityNum = playerNode.getPlayerInfo().getDanHomeData().getDecomposeActivityNum();
		if (activityNum != DecomposeActivityUtil.getDecomposeActivityNum())
		{
			return true;
		}
		return false;
	}

}
