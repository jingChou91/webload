package com.kodgames.corgi.server.gameserver.danhome.logic.alchemy;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.common.ValueRandomer;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_PickAlchemyBoxReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_PickAlchemyBoxRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeData;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeMgr;
import com.kodgames.corgi.server.gameserver.danhome.util.DHUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Alchemy.AlchemyActivityUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Alchemy.AlchemyUtil;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class CG_PickAlchemyBoxReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_PickAlchemyBoxReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_PickAlchemyBoxReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_PickAlchemyBoxReq request = (CG_PickAlchemyBoxReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_PickAlchemyBoxRes.Builder builder = GC_PickAlchemyBoxRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_PICK_ALCHEMY_BOX_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_PICK_ALCHEMY_BOX_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();

		int boxId = request.getBoxId();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_PICK_ALCHEMY_BOX_FAILED_LOAD_PALYER;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.DanHome))
				{
					result = ClientProtocols.E_GAME_PICK_ALCHEMY_BOX_FAILED_FUNCTION_NOT_OPEN;
					break;
				}
				DanConfig danCfg = cd.get_DanConfig();
				if (danCfg == null)
				{
					result = ClientProtocols.E_GAME_PICK_ALCHEMY_BOX_FAILED_LOAD_CONFIG;
					break;
				}
				DanHomeData dhData = playerNode.getPlayerInfo().getDanHomeData();

				// 功能是否开启
				if (!danCfg.get_IsDanHomeOpen())
				{
					result = ClientProtocols.E_GAME_PICK_ALCHEMY_BOX_FAILED_DAN_HOME_NOT_OPEN;
					break;
				}
				// 活动切换
				if (AlchemyUtil.activityChange(playerNode, cd))
				{
					builder.setIsNeedRefresh(true);
					break;
				}
				builder.setIsNeedRefresh(false);
				// 系统刷新
				DHUtil.systemRefresh(playerNode, cd);
				int activityNum = AlchemyActivityUtil.getAlchemyActivityNum();
				int alchemyCount = dhData.getAlchemyCount();

				Map<Integer, Boolean> boxRewards = dhData.getFixBoxRewards(cd, activityNum, false);
				Boolean hasPicked = boxRewards.get(boxId);
				if (hasPicked == null)
				{
					result = ClientProtocols.E_GAME_PICK_ALCHEMY_BOX_FAILED_BOX_REWARD_INFO;
					break;
				}
				if (hasPicked)
				{
					result = ClientProtocols.E_GAME_PICK_ALCHEMY_BOX_FAILED_ALREADY_PICKED;
					break;
				}
				DanConfig.BoxReward boxRewardCfg = danCfg.GetBoxRewardById(activityNum, boxId);
				if (boxRewardCfg == null)
				{
					result = ClientProtocols.E_GAME_PICK_ALCHEMY_BOX_FAILED_BOX_REWARD_CONFIG_NULL;
					break;
				}
				if (boxRewardCfg.get_AlchemyCount() > alchemyCount)
				{
					result = ClientProtocols.E_GAME_PICK_ALCHEMY_BOX_FAILED_ALCHEMY_COUNT_NOT_ENOUGH;
					break;
				}

				// 获取随机奖励
				List<ClientServerCommon.Reward> randomRewardCfgs = new ArrayList<ClientServerCommon.Reward>();
				for (int i = 0; i < boxRewardCfg.Get_RandomRewardsCount(); i++)
				{
					DanConfig.RandomReward randomRewardCfg = boxRewardCfg.Get_RandomRewardsByIndex(i);
					ValueRandomer random = new ValueRandomer();
					for (int j = 0; j < randomRewardCfg.Get_RewardWeightsCount(); j++)
					{
						DanConfig.RewardWeight rewardWeightCfg = randomRewardCfg.Get_RewardWeightsByIndex(j);
						random.addValue(rewardWeightCfg.get_Weight(), rewardWeightCfg.get_Reward());
					}
					random.SetTotalValue();
					Object data = random.RandomData();
					if (data != null)
					{
						randomRewardCfgs.add((ClientServerCommon.Reward)data);
					}
				}

				// 获得具体商品
				Reward reward = new Reward();
				for (int i = 0; i < boxRewardCfg.Get_RewardsCount(); i++)
				{
					reward.megerReward(new Reward().fromClientServerCommon(boxRewardCfg.Get_RewardsByIndex(i)));
				}
				for (int i = 0; i < randomRewardCfgs.size(); i++)
				{
					reward.megerReward(new Reward().fromClientServerCommon(randomRewardCfgs.get(i)));
				}

				// 修改内存
				CostAndRewardAndSync crsForReward = new CostAndRewardAndSync();
				CostAndRewardManager.addReward(playerNode, reward, cd, KodLogEvent.Dan_AlchemyPickBox);
				crsForReward.mergeReward(reward);
				crsForClient.megerCostAndRewardAndSync(crsForReward);
				// 更新已领取信息
				boxRewards.put(boxId, true);
				// 修改数据库
				DanHomeMgr.updateDB(playerNode);

				// 返回宝箱结果
				Reward coummonReward = new Reward();
				for (int i = 0; i < boxRewardCfg.Get_RewardsCount(); i++)
				{
					coummonReward.megerReward(new Reward().fromClientServerCommon(boxRewardCfg.Get_RewardsByIndex(i)));
				}
				builder.setReward(coummonReward.toProtobuf());
				Reward extraReward = new Reward();
				for (ClientServerCommon.Reward tmp : randomRewardCfgs)
				{
					extraReward.megerReward(new Reward().fromClientServerCommon(tmp));
				}
				builder.setRandomReward(extraReward.toProtobuf());

				// 小助手
				playerNode.getPlayerInfo().getAssisantData().getDanHome().notifyObservers();
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
