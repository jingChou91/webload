package com.kodgames.corgi.server.gameserver.danhome.util.Alchemy;

import com.kodgames.corgi.server.gameserver.danhome.Logic_Alchemy;
import com.kodgames.gamedata.player.PlayerNode;

public class AlchemyActivityUtil
{
	private static AlchemyActivityUtil dHActivityUtil = null;
	private Logic_Alchemy logic_Alchemy = null;

	private AlchemyActivityUtil()
	{
	}

	public static synchronized AlchemyActivityUtil getInstance()
	{
		if (null == dHActivityUtil)
		{
			dHActivityUtil = new AlchemyActivityUtil();
		}
		return dHActivityUtil;
	}

	public void setLogic(Logic_Alchemy logic)
	{
		this.logic_Alchemy = logic;
	}

	/**
	 * 获取当前活动编号开启时间
	 */
	public static long getAlchemyActivityStartTime(int activityNum)
	{
		long startTime = AlchemyActivityUtil.getInstance().logic_Alchemy.getAlchemyActivityStartTime(activityNum - 1);
		return startTime;
	}

	/**
	 * 获取当前活动编号关闭时间
	 */
	public static long getAlchemyActivityEndTime(int activityNum)
	{
		long endTime = AlchemyActivityUtil.getInstance().logic_Alchemy.getAlchemyActivityEndTime(activityNum - 1);
		return endTime;
	}

	/**
	 * 获取当前活动编号(当活动未开启时强制返回0)
	 */
	public static int getAlchemyActivityNum()
	{
		int activityNum =
			AlchemyActivityUtil.getInstance().logic_Alchemy.getActivityCurrentIndex(System.currentTimeMillis());
		if (activityNum == -1)
		{
			return -1;
		}
		return activityNum;
	}

	/**
	 * 判断当前活动是否开启
	 */
	public static boolean isAlchemyActivityOpen(long time)
	{
		boolean result = (AlchemyActivityUtil.getAlchemyActivityNum() != 0);
		return result;
	}

	/**
	 * 获取下次刷新时间
	 */
	public static long getAlchemyNextRefreshTime(long time)
	{
		return System.currentTimeMillis();
	}

	/**
	 * 活动切换
	 */
	public static boolean isAlchemyActivityChange(PlayerNode playerNode)
	{
		int activityNum = playerNode.getPlayerInfo().getDanHomeData().getAlchemyActivityNum();
		if (activityNum != AlchemyActivityUtil.getAlchemyActivityNum())
		{
			return true;
		}
		return false;
	}

}
