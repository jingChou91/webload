package com.kodgames.corgi.server.gameserver.danhome.logic.decompose;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon.DanConfig.ActivityExplain;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryDanDecomposeReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryDanDecomposeRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.danhome.util.DHUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Decompose.DecomposeActivityUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Decompose.DecomposeUtil;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_QueryDanDecomposeReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_QueryDanDecomposeReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv QueryDanDecomposeReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_QueryDanDecomposeReq request = (CG_QueryDanDecomposeReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryDanDecomposeRes.Builder builder = GC_QueryDanDecomposeRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_DAN_DECOMPOSE_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_QUERY_DAN_DECOMPOSE_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_DECOMPOSE_FAILED_LOAD_PALYER;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.DanHome))
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_DECOMPOSE_FAILED_FUNCTION_NOT_OPEN;
					break;
				}
				DanConfig danCfg = cd.get_DanConfig();
				if (danCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_DECOMPOSE_FAILED_LOAD_CONFIG;
					break;
				}
//				DanHomeData dhData = playerNode.getPlayerInfo().getDanHomeData();
				int activityNum = DecomposeActivityUtil.getDecomposeActivityNum();

				// 功能是否开启
				if (!danCfg.get_IsDanHomeOpen())
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_DECOMPOSE_FAILED_DAN_HOME_NOT_OPEN;
					break;
				}
				if (!danCfg.get_IsDecomposeOpen())
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_DECOMPOSE_FAILED_DECOMPOSE_NOT_OPEN;
					break;
				}
				// 活动切换
				DecomposeUtil.activityChange(playerNode, cd);
				// 系统刷新
				DHUtil.systemRefresh(playerNode, cd);
				// 返回下次刷新时间
				builder.setNextRefreshTime(ServerUtil.nextRefreshTime(System.currentTimeMillis(),
					danCfg.get_RefreshTimeDateTime()));
				// 活动标题
				ActivityExplain explainCfg = danCfg.GetActivityExplain(DanConfig._ActivityType.Decompose, activityNum);
				if (explainCfg != null)
				{
					builder.setActivityName(explainCfg.get_AcitvityName());
				}
				// 开启关闭时间
				builder.setActivityStartTime(DecomposeActivityUtil.getDecomposeActivityStartTime(activityNum));
				builder.setActivityEndTime(DecomposeActivityUtil.getDecomposeActivityEndTime(activityNum));
				// 分解消耗
				
				//返回客户端分解相关信息
				builder.setDecomposeInfo(DecomposeUtil.genDecomposeInfo(cd, playerNode, activityNum));
				
				

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
