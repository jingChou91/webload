package com.kodgames.corgi.server.gameserver.danhome;

import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedDeque;

import ClientServerCommon.ActivityConfig.ActivitySpecialTime;
import ClientServerCommon.ConfigDatabase;
import ClientServerCommon._ActivityTimerStatus;
import ClientServerCommon._ActivityType;
import ClientServerCommon._TimeDurationType;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityElement;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityEnviroment;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivityHandler;
import com.kodgames.corgi.server.gameserver.activity.activitymgr.ActivitySpecialTimeInfo;
import com.kodgames.corgi.server.gameserver.activity.data.ActivityTimerStatus;
import com.kodgames.corgi.server.gameserver.danhome.logic.alchemy.CG_AlchemyReqHandler;
import com.kodgames.corgi.server.gameserver.danhome.logic.alchemy.CG_PickAlchemyBoxReqHandler;
import com.kodgames.corgi.server.gameserver.danhome.logic.alchemy.CG_QueryAlchemyReqHandler;
import com.kodgames.corgi.server.gameserver.danhome.logic.alchemy.CG_QueryDanActivityReqHandler;
import com.kodgames.corgi.server.gameserver.danhome.logic.alchemy.CG_QueryDanHomeReqHandler;
import com.kodgames.gamedata.player.PlayerNode;

public class Logic_Alchemy extends ActivityHandler
{
	
	public Logic_Alchemy()
	{
		super(_ActivityType.ALCHEMY);
	}
	
	private int activityId;

	public void init(Controller controller)
	{
		CG_AlchemyReqHandler cg_AlchemyReqHandler = new CG_AlchemyReqHandler();
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_ALCHEMY_REQ, GameProtocolsForClient.CG_AlchemyReq.getDefaultInstance());
		controller.addHandler(ClientProtocols.P_GAME_CG_ALCHEMY_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_AlchemyReqHandler));
		
		CG_PickAlchemyBoxReqHandler cg_PickAlchemyBoxReqHandler = new CG_PickAlchemyBoxReqHandler();
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_PICK_ALCHEMY_BOX_REQ, GameProtocolsForClient.CG_PickAlchemyBoxReq.getDefaultInstance());
		controller.addHandler(ClientProtocols.P_GAME_CG_PICK_ALCHEMY_BOX_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_PickAlchemyBoxReqHandler));
		
		CG_QueryAlchemyReqHandler cg_QueryAlchemyReqHandler = new CG_QueryAlchemyReqHandler();
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_ALCHEMY_REQ, GameProtocolsForClient.CG_QueryAlchemyReq.getDefaultInstance());
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_ALCHEMY_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryAlchemyReqHandler));
		
		CG_QueryDanActivityReqHandler cg_QueryDanActivityReqHandler = new CG_QueryDanActivityReqHandler();
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_DAN_ACTIVITY_REQ, GameProtocolsForClient.CG_QueryDanActivityReq.getDefaultInstance());
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_DAN_ACTIVITY_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryDanActivityReqHandler));
		
		CG_QueryDanHomeReqHandler cg_QueryDanHomeReqHandler = new CG_QueryDanHomeReqHandler();
		controller.registerMessageLite(ClientProtocols.P_GAME_CG_QUERY_DAN_HOME_REQ, GameProtocolsForClient.CG_QueryDanHomeReq.getDefaultInstance());
		controller.addHandler(ClientProtocols.P_GAME_CG_QUERY_DAN_HOME_REQ, ServerUtil.getFacilityMessageHandlerFactory(cg_QueryDanHomeReqHandler));	
	}
	
	@Override
	public boolean start(ActivityEnviroment activityEnv)
	{
		ConfigDatabase cd = CfgDB.getDefautConfig();
		
		int activityId = cd.get_DanConfig().get_AlchemyActivityId();
		this.activityId = activityId;
		
		ClientServerCommon.ActivityConfig.Activity activityConfig = cd.get_ActivityConfig().GetActivityById(activityId);
		registerActivity(activityEnv, activityConfig);
		
		return false;
	}
	
	public void handleConfigRefresh(ConfigDatabase newCfg, ActivityEnviroment activityEnv)
	{
		ClientServerCommon.ActivityConfig.Activity activityConfig = newCfg.get_ActivityConfig().GetActivityById(activityId);
		checkActivityTimeChanged(activityEnv, activityConfig);
	}
	
	@Override
	protected ConcurrentLinkedDeque<ActivityTimerStatus> calcTimeListFromTimeCell(ActivitySpecialTime specialTime)
	{
		specialTime.set_timeDurationType(_TimeDurationType.Unknown);
		
		long openTime = parseOpenTime(specialTime);
		long endTime = parseCloseTime(specialTime);
		
		ConcurrentLinkedDeque<ActivityTimerStatus> timerList = new ConcurrentLinkedDeque<ActivityTimerStatus>();
		ActivityTimerStatus activityTimerStatus = null;
		
		activityTimerStatus = new ActivityTimerStatus(openTime, _ActivityTimerStatus.Client | _ActivityTimerStatus.Server | _ActivityTimerStatus.Start);
		timerList.add(activityTimerStatus);
		
		activityTimerStatus = new ActivityTimerStatus(endTime, _ActivityTimerStatus.Client | _ActivityTimerStatus.Server | _ActivityTimerStatus.End);
		timerList.add(activityTimerStatus);
		
		// 取倒数第二个点计算下一周期
		Iterator<ActivityTimerStatus> iter = timerList.descendingIterator();
		int i = 0;
		while (iter.hasNext()) 
		{
			ActivityTimerStatus timerStatus = iter.next();
			if (i == 2) 
			{
				timerStatus.addTimerStatus(_ActivityTimerStatus.InformNext);
				break;
			}

			i++;
		}

		if (timerList.size() <= 2)
		{
			//
			timerList.getFirst().addTimerStatus(_ActivityTimerStatus.InformNext);
		}

		return timerList;
	}

	//获取当前活动编号
	public Integer getActivityCurrentIndex(long time)
	{
		int result = -1;
	
		ActivityElement activityInfo = elementMaps.get(activityId);
		if(null != activityInfo)
		{
			ActivitySpecialTimeInfo timeInfo = activityInfo.getSpecialTimeByTime(time);
			if (null != timeInfo)
			{
				return timeInfo.getIndex();
			}
		}
		return result;
	}
	
	//获取活动开启时间
	public Long getAlchemyActivityStartTime(int index)
	{
		ActivityElement activityInfo = elementMaps.get(activityId);
		if(null != activityInfo)
		{
			for (ActivitySpecialTimeInfo timeInfo : activityInfo.getSpecialTimes())
			{
				if (timeInfo.getIndex() == index)
				{
					return timeInfo.getOpenTime();
				}
			}
		}
		
		return 0l;
	}
	//获取活动关闭时间
	public Long getAlchemyActivityEndTime(int index)
	{
		ActivityElement activityInfo = elementMaps.get(activityId);
		if(null != activityInfo)
		{
			for (ActivitySpecialTimeInfo timeInfo : activityInfo.getSpecialTimes())
			{
				if (timeInfo.getIndex() == index)
				{
					return timeInfo.getCloseTime();
				}
			}
		}
		
		return 0l;
	}
	@Override
	public boolean isActivityActivate(int activityId, PlayerNode playerNode)
	{
		return false;
	}
}
