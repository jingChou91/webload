package com.kodgames.corgi.server.gameserver.danhome.data;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;

import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.corgi.server.gameserver.danhome.data.struct.Counter;
import com.kodgames.corgi.server.gameserver.danhome.data.struct.SpecialDanReward;
import com.kodgames.corgi.server.gameserver.danhome.util.Alchemy.AlchemyUtil;
import com.kodgames.gamedata.player.PlayerNode;

public class DanHomeData
{
	private static final Logger logger = LoggerFactory.getLogger(AlchemyUtil.class);

	private long lastRefreshTime;// 上次刷新时间
	private int alchemyActivityNum;// 当前炼丹活动编号
	private int decomposeActivityNum;// 当前分解活动编号
	private int alchemyCount;// 今日已炼丹次数
	private int danDecomposeCount;// 今日已免费分解次数
	private int danItemDecomposeCount;// 今日已道具分解次数
	private Map<Integer, Counter> counters = new HashMap<Integer, Counter>();// 计数器
	private Map<Integer, Boolean> boxRewards = new HashMap<Integer, Boolean>();// 宝箱id_是否已领取
	private Map<Integer, SpecialDanReward> specialDanRewards = new HashMap<Integer, SpecialDanReward>();// 指定内丹奖励Id_已奖励次数
	private Map<Integer, Long> type_LastQueryTime = new HashMap<Integer, Long>(); // 灵丹阁上次查询时间

	/**
	 * 更新灵丹阁上次查询时间
	 */
	public void updateLastQueryTime(int type)
	{
		type_LastQueryTime.put(type, System.currentTimeMillis());
	}

	/**
	 * 获取灵丹阁上次查询时间
	 */
	public long getLastQueryTime(int type)
	{
		Long lastQueryTime = type_LastQueryTime.get(type);
		if (lastQueryTime == null)
		{
			type_LastQueryTime.put(type, 0L);
			return 0L;
		}
		return lastQueryTime;
	}

	public void addAlchemyCount()
	{
		this.alchemyCount++;
	}

	public void addDanDecomposeCount(int num)
	{
		this.danDecomposeCount = this.danDecomposeCount + num;
	}

	public void addDanItemDecomposeCount(int num)
	{
		this.danItemDecomposeCount = this.danItemDecomposeCount + num;
	}

	/**
	 * 分解活动切换
	 */
	public void decopmoseActivityChangeRefresh(ConfigDatabase cd, int activityNum)
	{
		// 今日已分解次数清零
		this.setDanDecomposeCount(0);
		this.setDanItemDecomposeCount(0);
		// 更新当前活动编号
		this.setDecomposeActivityNum(activityNum);
	}

	/**
	 * 炼丹活动切换刷新 1今日已炼丹次数清零2清空所有宝箱的领取记录3重置所有计数器4判断所有指定内丹奖励5更新当前活动编号
	 */
	public void alchemyActivityChangeRefresh(ConfigDatabase cd, int activityNum)
	{
		// 今日已炼丹次数清零
		this.setAlchemyCount(0);
		// 清空宝箱领取记录
		this.getFixBoxRewards(cd, activityNum, true);
		// 重置所有计数器
		this.getFixCounters(cd, activityNum, true);
		// 重置所有指定内丹的奖励次数
		this.getFixSpecialDanRewards(cd, activityNum, true);
		// 更新当前活动编号
		this.setAlchemyActivityNum(activityNum);
	}

	/**
	 * 炼丹系统刷新 1今日已炼丹次数清零2清空所有宝箱的领取记录3重置所有天循环计数器5更新刷新时间
	 */
	public void systemRefresh(ConfigDatabase cd)
	{
		DanConfig danCfg = cd.get_DanConfig();
		// 今日已炼丹次数清零
		this.setAlchemyCount(0);
		// 今日已分解次数清零
		this.setDanDecomposeCount(0);
		this.setDanItemDecomposeCount(0);
		// 清空宝箱领取记录
		for (Map.Entry<Integer, Boolean> entry : this.getFixBoxRewards(cd, alchemyActivityNum, false).entrySet())
		{
			logger.debug("_______Alchemy   Box   Reset,BoxId: " + entry.getKey());
			entry.setValue(false);
		}
		// 重置天循环的计数器
		for (Map.Entry<Integer, Counter> entry : this.getFixCounters(cd, alchemyActivityNum, false).entrySet())
		{
			Counter counter = entry.getValue();
			DanConfig.Counter counterCfg = danCfg.GetCounterById(alchemyActivityNum, counter.getId());
			// 是天刷新计数器
			if (counterCfg != null && counterCfg.get_IsDailyReset())
			{
				if (AlchemyUtil.verifyTime(counterCfg.get_BeginTime(), counterCfg.get_EndTime()))
				{
					logger.debug("_______Alchemy   DailyReset  Counter   Reset,CounterId: " + entry.getKey()
						+ " CounterBeginTime: " + counterCfg.get_BeginTime() + "  CounterEndTime:  "
						+ counterCfg.get_EndTime());
					counter.reset();
				}
			}
		}
		// 更新刷新时间
		this.setLastRefreshTime(System.currentTimeMillis());
	}

	/**
	 * 判断并重置周期循环的指定内丹奖励
	 */
	public void alchemySpecialDanRefresh(ConfigDatabase cd, PlayerNode playerNode)
	{
		DanConfig danCfg = cd.get_DanConfig();
		boolean change = false;
		// 重置周期循环的指定内丹的奖励次数
		for (Map.Entry<Integer, SpecialDanReward> entry : this.getFixSpecialDanRewards(cd, alchemyActivityNum, false)
			.entrySet())
		{
			SpecialDanReward specialDanReward = entry.getValue();
			DanConfig.SpecialDanReward specialDanCfg =
				danCfg.GetSpecialDanRewardById(alchemyActivityNum, specialDanReward.getId());
			// 是否是周期循环
			if (specialDanCfg != null && specialDanCfg.get_IsUseCycle())
			{
				if (AlchemyUtil.verifyTime(specialDanCfg.get_BeginTime(), specialDanCfg.get_EndTime()))
				{
					// 判断是否需要重置周期循环
					boolean flag = specialDanReward.resetCycle(specialDanCfg);
					if (flag)
					{
						change = true;
						logger.debug("_______Alchemy   Cycle SpecialDanReward   Reset,Id: " + entry.getKey()
							+ " SpecialDanRewardBeginTime: " + specialDanCfg.get_BeginTime()
							+ "  SpecialDanRewardEndTime:  " + specialDanCfg.get_EndTime());
					}
				}

			}
		}
		if (change)
		{
			DanHomeMgr.updateDB(playerNode);
		}

	}

	/**
	 * 按照配置文件修正计数器
	 */
	public Map<Integer, Counter> getFixCounters(ConfigDatabase cd, int activityNum, boolean delAllData)
	{

		DanConfig danCfg = cd.get_DanConfig();
		// 清除所有当前数据
		if (delAllData)
		{
			counters.clear();
		}
		// 获取配置文件中的所有计数器的id
		Set<Integer> ids = new HashSet<Integer>();
		for (int i = 0; i < danCfg.Get_CountersCount(); i++)
		{
			DanConfig.Counter counterCfg = danCfg.Get_CountersByIndex(i);
			if (counterCfg.get_ActivityNum() == activityNum)
			{
				ids.add(counterCfg.get_Id());
			}
		}
		// 添加配置文件中独有的
		for (int id : ids)
		{
			if (!counters.containsKey(id))
			{
				counters.put(id, new Counter(id));
			}
		}
		// 删除内存中独有的
		Set<Integer> delIds = new HashSet<Integer>();
		for (int id : counters.keySet())
		{
			if (!ids.contains(id))
			{
				delIds.add(id);
			}
		}
		for (Integer id : delIds)
		{
			counters.remove(id);
		}
		return counters;
	}

	/**
	 * 按照配置文件修正宝箱
	 */
	public Map<Integer, Boolean> getFixBoxRewards(ConfigDatabase cd, int activityNum, boolean delAllData)
	{

		DanConfig danCfg = cd.get_DanConfig();
		// 清除所有当前数据
		if (delAllData)
		{
			boxRewards.clear();
		}
		// 获取配置文件中的所有计数器的id
		Set<Integer> ids = new HashSet<Integer>();
		for (int i = 0; i < danCfg.Get_BoxRewardsCount(); i++)
		{
			DanConfig.BoxReward boxRewardCfg = danCfg.Get_BoxRewardsByIndex(i);
			if (boxRewardCfg.get_ActivityNum() == activityNum)
			{
				ids.add(boxRewardCfg.get_Id());
			}
		}
		// 添加配置文件中独有的
		for (int id : ids)
		{
			if (!boxRewards.containsKey(id))
			{
				boxRewards.put(id, false);
			}
		}
		// 删除内存中独有的
		Set<Integer> delIds = new HashSet<Integer>();
		for (int id : boxRewards.keySet())
		{
			if (!ids.contains(id))
			{
				delIds.add(id);
			}
		}
		for (Integer id : delIds)
		{
			boxRewards.remove(id);
		}
		return boxRewards;
	}

	/**
	 * 按照配置文件修正指定内丹奖励
	 */
	public Map<Integer, SpecialDanReward> getFixSpecialDanRewards(ConfigDatabase cd, int activityNum, boolean delAllData)
	{

		DanConfig danCfg = cd.get_DanConfig();
		// 清除所有当前数据
		if (delAllData)
		{
			specialDanRewards.clear();
		}
		// 获取配置文件中的所有计数器的id
		Set<Integer> ids = new HashSet<Integer>();
		for (int i = 0; i < danCfg.Get_SpecialDanRewardsCount(); i++)
		{
			DanConfig.SpecialDanReward specialDanCfg = danCfg.Get_SpecialDanRewardsByIndex(i);
			if (specialDanCfg.get_ActivityNum() == activityNum)
			{
				ids.add(specialDanCfg.get_Id());
			}
		}
		// 添加配置文件中独有的
		for (int id : ids)
		{
			if (!specialDanRewards.containsKey(id))
			{
				specialDanRewards.put(id, new SpecialDanReward(id));
			}
		}
		// 删除内存中独有的
		Set<Integer> delIds = new HashSet<Integer>();
		for (int id : specialDanRewards.keySet())
		{
			if (!ids.contains(id))
			{
				delIds.add(id);
			}
		}
		for (Integer id : delIds)
		{
			specialDanRewards.remove(id);
		}
		return specialDanRewards;
	}

	public DBProtocolsForServer.AlchemyCounterInfoDB getAlchemyCounterInfoDBProtoBuff()
	{
		DBProtocolsForServer.AlchemyCounterInfoDB.Builder builder =
			DBProtocolsForServer.AlchemyCounterInfoDB.newBuilder();
		for (Map.Entry<Integer, Counter> entry : counters.entrySet())
		{
			DBProtocolsForServer.AlchemyCounterDB.Builder alchemyCounterBuilder =
				DBProtocolsForServer.AlchemyCounterDB.newBuilder();
			Counter counter = entry.getValue();
			alchemyCounterBuilder.setId(counter.getId());
			alchemyCounterBuilder.setRefreshTimes(counter.getRefreshTimes());
			alchemyCounterBuilder.setActivateTimes(counter.getActivateTimes());
			builder.addAlchemyCounterDBs(alchemyCounterBuilder.build());
		}
		return builder.build();
	}

	public DBProtocolsForServer.AlchemyBoxInfoDB getAlchemyBoxInfoDBProtoBuff()
	{
		DBProtocolsForServer.AlchemyBoxInfoDB.Builder builder = DBProtocolsForServer.AlchemyBoxInfoDB.newBuilder();
		for (Map.Entry<Integer, Boolean> entry : boxRewards.entrySet())
		{
			DBProtocolsForServer.AlchemyBoxDB.Builder alchemyBoxBuilder =
				DBProtocolsForServer.AlchemyBoxDB.newBuilder();
			alchemyBoxBuilder.setId(entry.getKey());
			alchemyBoxBuilder.setHasPicked(entry.getValue());
			builder.addAlchemyBoxDBs(alchemyBoxBuilder.build());
		}
		return builder.build();
	}

	public DBProtocolsForServer.AlchemySpecialDanRewardInfoDB getAlchemySpecialDanRewardInfoDBProtoBuff()
	{
		DBProtocolsForServer.AlchemySpecialDanRewardInfoDB.Builder builder =
			DBProtocolsForServer.AlchemySpecialDanRewardInfoDB.newBuilder();
		for (Map.Entry<Integer, SpecialDanReward> entry : specialDanRewards.entrySet())
		{
			DBProtocolsForServer.AlchemySpecialDanRewardDB.Builder alchemyCounterBuilder =
				DBProtocolsForServer.AlchemySpecialDanRewardDB.newBuilder();
			SpecialDanReward specialDanReward = entry.getValue();
			alchemyCounterBuilder.setId(specialDanReward.getId());
			alchemyCounterBuilder.setTotalGetTimes(specialDanReward.getTotalGetTimes());
			alchemyCounterBuilder.setCycleGetTimes(specialDanReward.getCycleGetTimes());
			// TODO
			alchemyCounterBuilder.setLastRefreshTime(specialDanReward.getLastRefreshTime());
			builder.addAlchemySpecialDanRewardDBs(alchemyCounterBuilder.build());
		}
		return builder.build();
	}

	public int getAlchemyActivityNum()
	{
		return alchemyActivityNum;
	}

	public void setAlchemyActivityNum(int alchemyActivityNum)
	{
		this.alchemyActivityNum = alchemyActivityNum;
	}

	public int getAlchemyCount()
	{
		return alchemyCount;
	}

	public void setAlchemyCount(int alchemyCount)
	{
		this.alchemyCount = alchemyCount;
	}

	public Map<Integer, Counter> getCounters()
	{
		return counters;
	}

	public void setCounters(Map<Integer, Counter> counters)
	{
		this.counters = counters;
	}

	public Map<Integer, Boolean> getBoxRewards()
	{
		return boxRewards;
	}

	public void setBoxRewards(Map<Integer, Boolean> boxRewards)
	{
		this.boxRewards = boxRewards;
	}

	public Map<Integer, SpecialDanReward> getSpecialDanRewards()
	{
		return specialDanRewards;
	}

	public void setSpecialDanRewards(Map<Integer, SpecialDanReward> specialDanRewards)
	{
		this.specialDanRewards = specialDanRewards;
	}

	public long getLastRefreshTime()
	{
		return lastRefreshTime;
	}

	public void setLastRefreshTime(long lastRefreshTime)
	{
		this.lastRefreshTime = lastRefreshTime;
	}

	public int getDanDecomposeCount()
	{
		return danDecomposeCount;
	}

	public void setDanDecomposeCount(int danDecomposeCount)
	{
		this.danDecomposeCount = danDecomposeCount;
	}

	public int getDanItemDecomposeCount()
	{
		return danItemDecomposeCount;
	}

	public void setDanItemDecomposeCount(int danItemDecomposeCount)
	{
		this.danItemDecomposeCount = danItemDecomposeCount;
	}

	public int getDecomposeActivityNum()
	{
		return decomposeActivityNum;
	}

	public void setDecomposeActivityNum(int decomposeActivityNum)
	{
		this.decomposeActivityNum = decomposeActivityNum;
	}

	public Map<Integer, Long> getType_LastQueryTime()
	{
		return type_LastQueryTime;
	}

	public void setType_LastQueryTime(Map<Integer, Long> type_LastQueryTime)
	{
		this.type_LastQueryTime = type_LastQueryTime;
	}

}
