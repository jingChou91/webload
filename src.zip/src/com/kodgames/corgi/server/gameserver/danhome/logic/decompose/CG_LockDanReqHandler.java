package com.kodgames.corgi.server.gameserver.danhome.logic.decompose;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_LockDanReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_LockDanRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dan.data.Dan;
import com.kodgames.corgi.server.gameserver.dan.data.DanMgr;
import com.kodgames.corgi.server.gameserver.dan.db.DanInfoDB;
import com.kodgames.corgi.server.gameserver.danhome.util.DHUtil;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_LockDanReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_LockDanReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_LockDanReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_LockDanReq request = (CG_LockDanReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_LockDanRes.Builder builder = GC_LockDanRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_LOCK_DAN_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_LOCK_DAN_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		int type = request.getType();
		Guid guid = Guid.genNewGuid(request.getGuid());

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_LOCK_DAN_FAILED_LOAD_PALYER;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.DanHome))
				{
					result = ClientProtocols.E_GAME_LOCK_DAN_FAILED_FUNCTION_NOT_OPEN;
					break;
				}
				DanConfig danCfg = cd.get_DanConfig();
				if (danCfg == null)
				{
					result = ClientProtocols.E_GAME_LOCK_DAN_FAILED_LOAD_CONFIG;
					break;
				}

				// 功能是否开启
				if (!danCfg.get_IsDanHomeOpen())
				{
					result = ClientProtocols.E_GAME_LOCK_DAN_FAILED_DAN_HOME_NOT_OPEN;
					break;
				}
				builder.setIsNeedRefresh(false);
				// 系统刷新
				DHUtil.systemRefresh(playerNode, cd);

				Dan dan = DanMgr.getDan(guid, playerNode);
				if (dan == null)
				{
					result = ClientProtocols.E_GAME_LOCK_DAN_FAILED_DAN_NOT_FOUND;
					break;
				}
				
				switch (type)
				{
					case DanConfig._LockType.Locked:
						// 重复加锁
						if (dan.isLocked())
						{
							result = ClientProtocols.E_GAME_LOCK_DAN_FAILED_ALREADY_LOCKED;
							break;
						}
						dan.setLocked(true);
						break;
						
					case DanConfig._LockType.Unlock:
						// 重复解锁
						if (!dan.isLocked())
						{
							result = ClientProtocols.E_GAME_LOCK_DAN_FAILED_ALREADY_UNLOCKED;
							break;
						}
						dan.setLocked(false);
						break;

					default:
						// 操作类型错误
						result = ClientProtocols.E_GAME_LOCK_DAN_FAILED_WRONG_TYPE;
						break;
				}
				
				if (result == ClientProtocols.E_GAME_LOCK_DAN_SUCCESS)
				{
					// 更新数据库
					DanInfoDB.updateDanInfo(playerNode);
				}
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
