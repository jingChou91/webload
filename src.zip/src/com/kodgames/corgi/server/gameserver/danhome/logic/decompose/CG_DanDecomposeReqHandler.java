package com.kodgames.corgi.server.gameserver.danhome.logic.decompose;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.common.Guid;
import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_DanDecomposeReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_DanDecomposeRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.dbclient.KodLogEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.dan.data.Dan;
import com.kodgames.corgi.server.gameserver.dan.data.DanMgr;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeData;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeMgr;
import com.kodgames.corgi.server.gameserver.danhome.util.DHUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Decompose.DecomposeActivityUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Decompose.DecomposeUtil;
import com.kodgames.corgi.server.gameserver.position.data.PositionMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.CostAndRewardAndSync;
import com.kodgames.gamedata.player.costandreward.CostAndRewardManager;
import com.kodgames.gamedata.player.costandreward.Reward;

public class CG_DanDecomposeReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_DanDecomposeReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_DanDecomposeReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_DanDecomposeReq request = (CG_DanDecomposeReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_DanDecomposeRes.Builder builder = GC_DanDecomposeRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_DAN_DECOMPOSE_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_DAN_DECOMPOSE_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);
		CostAndRewardAndSync crsForClient = new CostAndRewardAndSync();

		int type = request.getType();
		List<String> guidList = request.getGuidsList();
		CommonProtocols.Cost cost = request.getCost();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_LOAD_PALYER;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.DanHome))
				{
					result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_FUNCTION_NOT_OPEN;
					break;
				}
				DanConfig danCfg = cd.get_DanConfig();
				if (danCfg == null)
				{
					result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_LOAD_CONFIG;
					break;
				}
				DanHomeData dhData = playerNode.getPlayerInfo().getDanHomeData();

				// 功能是否开启
				if (!danCfg.get_IsDanHomeOpen())
				{
					result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_DAN_HOME_NOT_OPEN;
					break;
				}
				if (!danCfg.get_IsDecomposeOpen())
				{
					result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_DECOMPOSE_NOT_OPEN;
					break;
				}
				// 活动切换
				if (DecomposeUtil.activityChange(playerNode, cd))
				{
					builder.setIsNeedRefresh(true);
					break;
				}
				builder.setIsNeedRefresh(false);
				// 系统刷新
				DHUtil.systemRefresh(playerNode, cd);
				int activityNum = DecomposeActivityUtil.getDecomposeActivityNum();

				if (guidList.size() == 0)
				{
					result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_GUID_LIST_SIZE_ZERO;
					break;
				}
				HashSet<Dan> dans = new HashSet<Dan>();
				for (String guid : guidList)
				{
					Dan dan = DanMgr.getDan(Guid.genNewGuid(guid), playerNode);
					if (dan == null)
					{
						result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_DAN_NOT_FOUND;
						break;
					}
					// 在阵上
					if (!PositionMgr.checkGuid(dan.getGuid(), playerNode))
					{
						result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_ALREADY_ON_POSITION;
						break;
					}
					if (dan.isLocked())
					{
						result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_ALREADY_LOCKED;
						break;
					}
					if (dans.contains(dan))
					{
						result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_DAN_INFO_ERROR;
						break;
					}
					dans.add(dan);
				}
				if (result != ClientProtocols.E_GAME_DAN_DECOMPOSE_SUCCESS)
				{
					break;
				}

				// 分解奖励
				Reward decomposeReward = new Reward();
				// 分解消耗
				ArrayList<Cost> costs = new ArrayList<Cost>();
				int vipLevel = playerNode.getGamePlayer().getVipLevel();
				if (type == DanConfig._DecomposeType.Free)
				{
					// 剩余免费分解件数不足
					if (dans.size() > DecomposeUtil.getRemainDecomposeCount(cd, dhData, vipLevel, activityNum))
					{
						result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_REMAIN_FREE_NOT_ENOUGH;
						break;
					}
					for (Dan dan : dans)
					{
						// 获得分解奖励和结果
						result = DecomposeUtil.getDecomposeResult(dan, activityNum, decomposeReward, danCfg);
						if (result != ClientProtocols.E_GAME_DAN_DECOMPOSE_SUCCESS)
						{
							break;
						}
						// 被分解的内丹
						costs.add(new Cost(dan.getResourceId(), dan.getGuid()));
					}
				}
				else if (type == DanConfig._DecomposeType.Charge)
				{
					// 免费分解次数有剩余
					if (DecomposeUtil.getRemainDecomposeCount(cd, dhData, vipLevel, activityNum) > 0)
					{
						result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_REMAIN_FREE;
						break;
					}
					// 剩余道具分解件数不足
					if (dans.size() > DecomposeUtil.getRemainItemDecomposeCount(cd, dhData, vipLevel, activityNum))
					{
						result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_REMAIN_CHARGE_NOT_ENOUGH;
						break;
					}

					ClientServerCommon.Cost costCfg = danCfg.get_ItemDecomposeCost();
					if (costCfg == null)
					{
						result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_LOAD_COST_CONFIG;
						break;
					}

					if (cost.getId() != costCfg.get_id() || cost.getCount() != costCfg.get_count() * dans.size())
					{
						// 客户端数据过时
						result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_DATA_OUT_OF_DATE;
						break;
					}

					for (Dan dan : dans)
					{
						// 获得分解奖励和结果
						result = DecomposeUtil.getDecomposeResult(dan, activityNum, decomposeReward, danCfg);
						if (result != ClientProtocols.E_GAME_DAN_DECOMPOSE_SUCCESS)
						{
							break;
						}
						// 被分解的内丹
						costs.add(new Cost(dan.getResourceId(), dan.getGuid()));
					}
					// 付费分解的额外消耗
					costs.add(new Cost(cost.getId(), cost.getCount()));
				}
				else
				{
					result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_WRONG_DECOMPOSE_TYPE;
					break;
				}
				if (result != ClientProtocols.E_GAME_DAN_DECOMPOSE_SUCCESS)
				{
					break;
				}

				// 消耗
				Cost costNotEnough = new Cost();
				CostAndRewardAndSync crsForCost = new CostAndRewardAndSync();
				if (!CostAndRewardManager.checkCosts(playerNode, costs, cd, KodLogEvent.Dan_Decompose, costNotEnough))
				{
					crsForClient.setNotEnoughCost(costNotEnough);
					builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
					result = ClientProtocols.E_GAME_DAN_DECOMPOSE_FAILED_COSTS_NOT_ENOUGH;
					break;
				}
				CostAndRewardManager.consumeCosts(playerNode, costs, cd, KodLogEvent.Dan_Decompose, 0, 0);
				crsForCost.setCosts(costs);
				crsForClient.megerCostAndRewardAndSync(crsForCost);
				// 奖励
				CostAndRewardAndSync crsForReward = new CostAndRewardAndSync();
				CostAndRewardManager.addReward(playerNode, decomposeReward, cd, KodLogEvent.Dan_Decompose);
				crsForReward.mergeReward(decomposeReward);
				crsForClient.megerCostAndRewardAndSync(crsForReward);
				// 增加分解次数
				if (type == DanConfig._DecomposeType.Free)
				{
					dhData.addDanDecomposeCount(dans.size());
				}
				else
				{
					dhData.addDanItemDecomposeCount(dans.size());
				}
				// 数据库
				DanHomeMgr.updateDB(playerNode);

				// 返回客户端分解相关信息
				builder.setDecomposeInfo(DecomposeUtil.genDecomposeInfo(cd, playerNode, activityNum));
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		builder.setCostAndRewardAndSync(crsForClient.toProtobuf());
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
