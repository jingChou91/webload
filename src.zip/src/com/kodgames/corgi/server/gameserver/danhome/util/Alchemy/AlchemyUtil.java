package com.kodgames.corgi.server.gameserver.danhome.util.Alchemy;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon.DanConfig.AlchemyCost;

import com.kodgames.common.ValueRandomer;
import com.kodgames.corgi.gameconfiguration.TimeZoneData;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryAlchemyRes;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.dan.util.DanUtil;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeData;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeMgr;
import com.kodgames.corgi.server.gameserver.danhome.data.struct.Counter;
import com.kodgames.corgi.server.gameserver.danhome.data.struct.SpecialDanReward;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.ItemType;

public class AlchemyUtil
{
	public static int DEFAULT_ACTIVITYNUM = -1;// 默认活动编号
	public static int DAY = 24 * 60 * 60 * 1000;

	private static final Logger logger = LoggerFactory.getLogger(AlchemyUtil.class);

	/**
	 * 根据RewardConfig生成展示用ShowReward
	 */
	public static CommonProtocols.ShowReward GenShowReward(ConfigDatabase cd, ClientServerCommon.Reward rewardCfg)
	{
		CommonProtocols.ShowReward.Builder builder = CommonProtocols.ShowReward.newBuilder();
		if (rewardCfg != null)
		{
			builder.setId(rewardCfg.get_id());
			builder.setLevel(rewardCfg.get_level());
			builder.setBreakthought(rewardCfg.get_breakthoughtLevel());
			builder.setCount(rewardCfg.get_count());
			if (ItemType.isDan(rewardCfg.get_id()))
			{
				List<Integer> attributeIds =
					DanUtil.genShowAttributesByAlgorithmId(rewardCfg.get_id(),
						rewardCfg.get_level(),
						rewardCfg.get_breakthoughtLevel(),
						rewardCfg.get_attributeAlgorithmId());
				builder.addAllAttributeIds(attributeIds);
				List<CommonProtocols.DanAttributeGroup> danAttributeGroupList =
					DanUtil.getDanAttributeGroupProList(cd, rewardCfg.get_id(), attributeIds);
				builder.addAllDanAttributeGroups(danAttributeGroupList);
			}
		}
		return builder.build();
	}

	/**
	 * 根据具体数值生成展示用ShowReward
	 */
	public static CommonProtocols.ShowReward GenShowReward(ConfigDatabase cd, int id, int level, int breakthought,
		int count, int algorithmId)
	{
		CommonProtocols.ShowReward.Builder builder = CommonProtocols.ShowReward.newBuilder();
		builder.setId(id);
		builder.setLevel(level);
		builder.setBreakthought(breakthought);
		builder.setCount(count);
		if (ItemType.isDan(id))
		{
			List<Integer> attributeIds = DanUtil.genShowAttributesByAlgorithmId(id, level, breakthought, algorithmId);
			builder.addAllAttributeIds(attributeIds);
			List<CommonProtocols.DanAttributeGroup> danAttributeGroupList =
				DanUtil.getDanAttributeGroupProList(cd, id, attributeIds);
			builder.addAllDanAttributeGroups(danAttributeGroupList);
		}
		return builder.build();
	}

	/**
	 * 获取计数器奖励
	 */
	public static ClientServerCommon.Reward GenCounterReward(DanHomeData dhData, ConfigDatabase cd, int activityNum)
	{
		DanConfig danCfg = cd.get_DanConfig();
		// 增加计数器的刷新次数
		AlchemyUtil.addCountersRefershTimes(dhData, cd, activityNum);
		// 获取所有被激活的计数器
		List<DanConfig.Counter> counterCfgs = AlchemyUtil.getActivitedCounters(dhData, cd, activityNum);
		while (counterCfgs.size() > 0)
		{
			// 获取并删除计数器集合中的一个计数器
			DanConfig.Counter counterCfg = AlchemyUtil.getAndRemoveEffectiveCounter(counterCfgs);
			// 判断计数器是否生效
			double randomDouble = Math.random();
			logger.debug("__________Alchemy   Counter Math.Random,CounterId:" + counterCfg.get_Id()
				+ "  randomDouble: " + randomDouble + " EffectiveProbability:  "
				+ counterCfg.get_EffectiveProbability());
			if (randomDouble <= counterCfg.get_EffectiveProbability())
			{
				logger.debug("__________Alchemy Counter Effective!!!,CounterId:" + counterCfg.get_Id());
				int counterRewardId = counterCfg.get_CounterRewardId();
				DanConfig.CounterReward counterRewardCfg = danCfg.GetCounterRewardById(counterRewardId);
				if (counterRewardCfg != null)
				{
					ValueRandomer random = new ValueRandomer();
					DanConfig.RandomReward randomRewardCfg = counterRewardCfg.get_RandomReward();
					for (int i = 0; i < randomRewardCfg.Get_RewardWeightsCount(); i++)
					{
						DanConfig.RewardWeight rewardWeightCfg = randomRewardCfg.Get_RewardWeightsByIndex(i);
						random.addValue(rewardWeightCfg.get_Weight(), rewardWeightCfg.get_Reward());
					}
					logger.debug("_______Alchemy Counter  Reward   RandomPool.Size = : " + random.valueSize());
					random.SetTotalValue();
					Object data = random.RandomData();
					if (data != null)
					{
						return (ClientServerCommon.Reward)data;
					}
				}
			}
			else
			{
				logger.debug("__________Alchemy Counter Un Effective,CounterId:" + counterCfg.get_Id());
			}
		}
		return null;
	}

	/**
	 * 获取并删除计数器集合中的一个计数器
	 */
	public static DanConfig.Counter getAndRemoveEffectiveCounter(List<DanConfig.Counter> counters)
	{
		boolean hasResult = false;
		DanConfig.Counter counter = null;
		if (counters.size() == 0)
		{
			return null;
		}
		// 只有一个计数器,直接返回
		if (counters.size() == 1)
		{
			counter = counters.get(0);
			hasResult = true;
		}
		// 有显示用计数器,返回该计数器
		if (!hasResult)
		{
			for (DanConfig.Counter tmp : counters)
			{
				if (tmp.get_IsShowCounter())
				{
					counter = tmp;
					hasResult = true;
				}
			}
		}

		// 取优先级最高的计数器
		int priority = 0;
		if (!hasResult)
		{
			for (DanConfig.Counter tmp : counters)
			{
				if (tmp.get_Priority() > priority)
				{
					counter = tmp;
					priority = tmp.get_Priority();
					hasResult = true;
				}
			}
		}
		counters.remove(counter);
		return counter;
	}

	/**
	 * 增加计数器的刷新次数
	 */
	public static void addCountersRefershTimes(DanHomeData dhData, ConfigDatabase cd, int activityNum)
	{
		// 对于每个计数器,如果当前处于计数器的激活时间之内,并且已炼丹次数<生效起始次数+激活所需炼丹次数*(最大激活次数-1),那么已炼丹次数+1.
		DanConfig danCfg = cd.get_DanConfig();
		Map<Integer, Counter> counters = dhData.getFixCounters(cd, activityNum, false);
		for (Map.Entry<Integer, Counter> entry : counters.entrySet())
		{
			DanConfig.Counter counterCfg = danCfg.GetCounterById(activityNum, entry.getKey());
			if (counterCfg != null)
			{
				entry.getValue().testAndAddRefreshTimes(counterCfg);
			}
		}
	}

	/**
	 * 获取所有被激活的计数器
	 */
	public static List<DanConfig.Counter> getActivitedCounters(DanHomeData dhData, ConfigDatabase cd, int activityNum)
	{
		DanConfig danCfg = cd.get_DanConfig();
		List<DanConfig.Counter> counterCfgs = new ArrayList<DanConfig.Counter>();
		Map<Integer, Counter> counters = dhData.getFixCounters(cd, activityNum, false);
		for (Map.Entry<Integer, Counter> entry : counters.entrySet())
		{
			Counter counter = entry.getValue();
			DanConfig.Counter counterCfg = danCfg.GetCounterById(activityNum, entry.getKey());
			if (counterCfg != null)
			{
				// 如果计数器可以激活
				if (counter.canActive(counterCfg))
				{
					// 激活计数器
					counter.addActivateTimes();
					counterCfgs.add(counterCfg);
					logger.debug("_________Alchemy Counter Activated!!!  CounterId: " + counter.getId()
						+ "  refreshTimes  " + counter.getRefreshTimes() + "  new ActivatedTimes  "
						+ counter.getActivateTimes() + " BeginNeedTimes: " + counterCfg.get_BeginNeedTimes()
						+ " ActivateNeedTimes: " + counterCfg.get_NeedTimes());
				}
			}
		}
		return counterCfgs;
	}

	/**
	 * 练出指定内丹奖励
	 */
	public static List<ClientServerCommon.Reward> GenSpecialDanReward(DanHomeData dhData, ConfigDatabase cd,
		int activityNum, ClientServerCommon.Reward rewardCfg, List<Integer> attributeGroupIds)
	{
		List<ClientServerCommon.Reward> results = new ArrayList<ClientServerCommon.Reward>();
		DanConfig danCfg = cd.get_DanConfig();
		Map<Integer, SpecialDanReward> specialDanRewards = dhData.getFixSpecialDanRewards(cd, activityNum, false);
		for (int i = 0; i < danCfg.Get_SpecialDanRewardsCount(); i++)
		{
			DanConfig.SpecialDanReward specialDanRewardCfg = danCfg.Get_SpecialDanRewardsByIndex(i);
			if (specialDanRewardCfg.get_ActivityNum() == activityNum
				&& specialDanRewardCfg.get_ResourseId() == rewardCfg.get_id())
			{
				SpecialDanReward specialDanReward = specialDanRewards.get(specialDanRewardCfg.get_Id());
				if (specialDanReward != null)
				{
					// 如果成功激活
					if (specialDanReward.active(cd, specialDanRewardCfg, rewardCfg, attributeGroupIds))
					{
						logger.debug("________Alchemy SpecialDanReward Activated!!! Id: "
							+ specialDanRewardCfg.get_Id() + "CauseBy ( DanId: " + rewardCfg.get_id() + "  level:  "
							+ rewardCfg.get_level() + "  breakthough:  " + rewardCfg.get_breakthoughtLevel() + " )");
						for (int j = 0; j < specialDanRewardCfg.Get_RandomRewardsCount(); j++)
						{
							ValueRandomer random = new ValueRandomer();
							DanConfig.RandomReward randomReward = specialDanRewardCfg.Get_RandomRewardsByIndex(j);
							for (int k = 0; k < randomReward.Get_RewardWeightsCount(); k++)
							{
								DanConfig.RewardWeight rewardWeight = randomReward.Get_RewardWeightsByIndex(k);
								random.addValue(rewardWeight.get_Weight(), rewardWeight.get_Reward());
							}
							random.SetTotalValue();
							Object data = random.RandomData();
							if (data != null)
							{
								results.add((ClientServerCommon.Reward)data);
							}
						}
						break;// 只激活一个
					}
				}
			}
		}
		return results;
	}

	/**
	 * 生成炼丹结果
	 */
	public static ClientServerCommon.Reward GenAlchemyResult(DanConfig danCfg, int activityNum)
	{
		ValueRandomer random = new ValueRandomer();
		for (int i = 0; i < danCfg.Get_AlchemyResultsCount(); i++)
		{
			DanConfig.AlchemyResult alchemyResult = danCfg.Get_AlchemyResultsByIndex(i);
			// 取当前活动的结果和默认结果
			if (alchemyResult.get_ActivityNum() == AlchemyUtil.DEFAULT_ACTIVITYNUM
				|| alchemyResult.get_ActivityNum() == activityNum)
			{
				// 验证是否符合时间限制
				if (AlchemyUtil.verifyTime(alchemyResult.get_BeginTime(), alchemyResult.get_EndTime()))
				{
					// 放入随机池
					random.addValue(alchemyResult.get_Weight(), alchemyResult.get_Id());
				}
			}
		}
		logger.debug("_________Alchemmy Result RandomPool Size =  " + random.valueSize());
		random.SetTotalValue();
		Object data = random.RandomData();
		if (data != null)
		{
			int resultId = (int)data;
			logger.debug("_________Alchemmy Result   Id: " + resultId);
			DanConfig.AlchemyResult alchemyResult = danCfg.GetAlchemyResultById(resultId);
			if (alchemyResult != null)
			{
				return alchemyResult.get_Reward();
			}
		}
		return null;
	}

	/**
	 * 验证当前时间是否在时间范围之内
	 */
	public static boolean verifyTime(String beginTime, String endTime)
	{
		long now = System.currentTimeMillis();
		long begin = ServerUtil.convertTimeStringWithTimezoneToLong(TimeZoneData.getTimeZone(), beginTime);
		long end = ServerUtil.convertTimeStringWithTimezoneToLong(TimeZoneData.getTimeZone(), endTime);
		// 开始关闭时间都没有,返回true
		if (("".equals(beginTime) || beginTime == null) && ("".equals(endTime) || endTime == null))
		{
			return true;
		}
		// 有开始没关闭
		if ((!"".equals(beginTime) || beginTime != null) && ("".equals(endTime) || endTime == null))
		{
			return begin < now;
		}
		// 没开始有关闭
		if (("".equals(beginTime) || beginTime == null) && (!"".equals(endTime) || endTime != null))
		{
			return now < end;
		}
		// 有开始,有关闭
		if ((!"".equals(beginTime) || beginTime != null) && (!"".equals(endTime) || endTime != null))
		{
			return (begin < now) && (now < end);
		}
		return false;
	}

	/**
	 * 比较两个Costs中的数据是否相同
	 */
	public static boolean verifyTimeCosts(List<Cost> costs, List<CommonProtocols.Cost> costs_pro)
	{
		if (costs.size() != costs_pro.size())
		{
			return false;
		}
		for (CommonProtocols.Cost cost_pro : costs_pro)
		{
			Cost cost = AlchemyUtil.getCostFromList(costs, cost_pro.getId());
			if (cost == null || cost.getCount() != cost_pro.getCount())
			{
				return false;
			}
		}
		return true;
	}

	/**
	 * 向客户端返回展示计数器
	 */
	public static CommonProtocols.ShowCounter genShowCounterInfo(DanHomeData dhData, ConfigDatabase cd, int activityNum)
	{
		DanConfig danCfg = cd.get_DanConfig();
		Map<Integer, Counter> counters = dhData.getFixCounters(cd, activityNum, false);
		for (int i = 0; i < danCfg.Get_CountersCount(); i++)
		{
			DanConfig.Counter counterCfg = danCfg.Get_CountersByIndex(i);
			if (counterCfg.get_ActivityNum() == activityNum && counterCfg.get_IsShowCounter())
			{
				Counter counter = counters.get(counterCfg.get_Id());
				if (counter != null)
				{
					CommonProtocols.ShowCounter.Builder showCounterBuilder = CommonProtocols.ShowCounter.newBuilder();
					int remianTimes = counter.getRemainTimesForActive(counterCfg);
					if (remianTimes == -1)
					{
						continue;
					}
					showCounterBuilder.setRemainCount(remianTimes);
					DanConfig.CounterReward counterRewardCfg =
						danCfg.GetCounterRewardById(counterCfg.get_CounterRewardId());
					if (counterRewardCfg != null)
					{

						DanConfig.RandomReward randomRewardCfg = counterRewardCfg.get_RandomReward();
						for (int k = 0; k < randomRewardCfg.Get_RewardWeightsCount(); k++)
						{
							DanConfig.RewardWeight rewardWeight = randomRewardCfg.Get_RewardWeightsByIndex(k);
							ClientServerCommon.Reward rewardCfg = rewardWeight.get_Reward();
							showCounterBuilder.addRewards(AlchemyUtil.GenShowReward(cd, rewardCfg));
						}
					}
					return showCounterBuilder.build();
				}
			}
		}
		return null;
	}

	/**
	 * 向客户端返回宝箱奖励信息
	 */
	public static void genBoxRewardInfo(GC_QueryAlchemyRes.Builder builder, DanHomeData dhData, ConfigDatabase cd,
		int activityNum)
	{
		DanConfig danCfg = cd.get_DanConfig();
		Map<Integer, Boolean> boxRewards = dhData.getFixBoxRewards(cd, activityNum, false);
		for (int i = 0; i < danCfg.Get_BoxRewardsCount(); i++)
		{
			DanConfig.BoxReward boxRewardCfg = danCfg.Get_BoxRewardsByIndex(i);
			if (boxRewardCfg.get_ActivityNum() == activityNum)
			{
				CommonProtocols.BoxReward.Builder boxRewardBuilder = CommonProtocols.BoxReward.newBuilder();
				Boolean bool = boxRewards.get(boxRewardCfg.get_Id());
				if (bool != null)
				{
					boxRewardBuilder.setHasPicked(bool);
					boxRewardBuilder.setId(boxRewardCfg.get_Id());
					boxRewardBuilder.setIconId(boxRewardCfg.get_IconId());
					boxRewardBuilder.setOpenIconId(boxRewardCfg.get_OpenIconId());
					boxRewardBuilder.setHasActivityIcon(boxRewardCfg.get_HasActivityIcon());
					boxRewardBuilder.setAlchemyCount(boxRewardCfg.get_AlchemyCount());
					for (int j = 0; j < boxRewardCfg.Get_RewardsCount(); j++)
					{
						ClientServerCommon.Reward rewardCfg = boxRewardCfg.Get_RewardsByIndex(j);
						boxRewardBuilder.addRewards(AlchemyUtil.GenShowReward(cd, rewardCfg));
					}
					for (int j = 0; j < boxRewardCfg.Get_RandomRewardsCount(); j++)
					{
						DanConfig.RandomReward randomRewardCfg = boxRewardCfg.Get_RandomRewardsByIndex(j);
						for (int k = 0; k < randomRewardCfg.Get_RewardWeightsCount(); k++)
						{
							DanConfig.RewardWeight rewardWeight = randomRewardCfg.Get_RewardWeightsByIndex(k);
							ClientServerCommon.Reward rewardCfg = rewardWeight.get_Reward();
							boxRewardBuilder.addRandomRewards(AlchemyUtil.GenShowReward(cd, rewardCfg));
						}
					}
					builder.addBoxRewards(boxRewardBuilder.build());
				}
			}
		}
	}

	/**
	 * 合并消耗
	 */
	private static ArrayList<Cost> mergeCosts(List<Cost> costs)
	{
		ArrayList<Cost> results = new ArrayList<Cost>();
		for (Cost tmp : costs)
		{
			Cost cost = AlchemyUtil.getCostFromList(results, tmp.getId());
			if (cost != null)
			{
				cost.setCount(cost.getCount() + tmp.getCount());
			}
			else
			{
				results.add(tmp);
			}
		}
		return results;
	}

	private static Cost getCostFromList(List<Cost> costs, int id)
	{
		for (Cost cost : costs)
		{
			if (cost.getId() == id)
			{
				return cost;
			}
		}
		return null;
	}

	/**
	 * 获取批量炼丹消耗
	 */
	public static ArrayList<Cost> getBatchAlchemyCost(DanHomeData dhData, DanConfig danCfg, int activityNum,
		int alchemyCount)
	{
		ArrayList<Cost> costs = new ArrayList<Cost>();
		for (int i = 0; i < danCfg.get_BatchAlchemyCount(); i++)
		{
			Cost cost = AlchemyUtil.getAlchemyCost(dhData, danCfg, activityNum, alchemyCount + i);
			if (cost != null)
			{
				costs.add(cost);
			}
		}
		costs = AlchemyUtil.mergeCosts(costs);
		return costs;
	}

	/**
	 * 获取指定活动的某次炼丹的消耗
	 */
	public static Cost getAlchemyCost(DanHomeData dhData, DanConfig danCfg, int activityNum, int alchemyCount)
	{
		AlchemyCost alchemyCostCfg = danCfg.GetAlchemyCost(activityNum, alchemyCount + 1);
		if (alchemyCostCfg != null)
		{
			ClientServerCommon.Cost costCfg = alchemyCostCfg.get_Cost();
			if (costCfg != null)
			{
				Cost cost = new Cost(costCfg.get_id(), costCfg.get_count());
				return cost;
			}
		}
		else
		{
			alchemyCostCfg = danCfg.GetMaxCountAlchemyCost(activityNum);
			if (alchemyCostCfg != null)
			{
				ClientServerCommon.Cost costCfg = alchemyCostCfg.get_Cost();
				if (costCfg != null)
				{
					Cost cost = new Cost(costCfg.get_id(), costCfg.get_count());
					return cost;
				}
			}
		}
		return null;
	}

	/**
	 * 炼丹活动切换
	 */
	public static boolean activityChange(PlayerNode playerNode, ConfigDatabase cd)
	{
		DanHomeData dhData = playerNode.getPlayerInfo().getDanHomeData();
		// 活动开启且玩家状态切换
		if (AlchemyActivityUtil.isAlchemyActivityChange(playerNode))
		{
			logger.debug("______________Activity Change!!!");
			// 活动切换
			dhData.alchemyActivityChangeRefresh(cd, AlchemyActivityUtil.getAlchemyActivityNum());
			// 修改数据库
			DanHomeMgr.updateDB(playerNode);
			// 小助手
			playerNode.getPlayerInfo().getAssisantData().getDanHome().notifyObservers();
			return true;
		}
		logger.debug("______________Activity Not Change");
		return false;
	}

	/**
	 * 测试代码
	 */
	public static void printMemory(ConfigDatabase cd, DanHomeData dhData)
	{
		int alchemyActivityNum = dhData.getAlchemyActivityNum();
		logger.debug("__________Memeory: alchemyActivityNum: " + alchemyActivityNum);
		logger.debug("__________Memeory: alchemyLastRefreshTime: " + new Date(dhData.getLastRefreshTime()).toString());
		logger.debug("__________Memeory: alchemyCount: " + dhData.getAlchemyCount());

		for (Map.Entry<Integer, Counter> entry : dhData.getFixCounters(cd, alchemyActivityNum, false).entrySet())
		{
			Counter counter = entry.getValue();
			logger.debug("__________Memeory: Counter Id: " + counter.getId() + "  refreshTimes: "
				+ counter.getRefreshTimes() + "  activateTimes: " + counter.getActivateTimes());
		}
		for (Map.Entry<Integer, SpecialDanReward> entry : dhData.getFixSpecialDanRewards(cd, alchemyActivityNum, false)
			.entrySet())
		{
			SpecialDanReward specialDanReward = entry.getValue();
			logger.debug("__________Memeory: specialDanReward Id: " + specialDanReward.getId() + "  cycleGetTimes: "
				+ specialDanReward.getCycleGetTimes() + "  totalGetTimes: " + specialDanReward.getTotalGetTimes()
				+ "  LastRefreshTime: " + new Date(specialDanReward.getLastRefreshTime()).toString());
		}
		for (Map.Entry<Integer, Boolean> entry : dhData.getFixBoxRewards(cd, alchemyActivityNum, false).entrySet())
		{
			logger.debug("__________Memeory: Box Id: " + entry.getKey() + "  HasPicked: " + entry.getValue());
		}
	}

	/**
	 * 合并Reward
	 */
	public static void mergeServerCommonReward(List<ClientServerCommon.Reward> totalRewardCfgs,
		List<ClientServerCommon.Reward> rewardCfgs)
	{
		for (ClientServerCommon.Reward tmp : rewardCfgs)
		{
			totalRewardCfgs.add(tmp);
		}
	}

	// /**
	// * 判断当前是否需要刷新
	// */
	// private static boolean isAlchemyNeedRefersh(long lastRefreshTime)
	// {
	// long nextRefreshTime = DHActivityUtil.getAlchemyNextRefreshTime(System.currentTimeMillis());
	// long time = DHActivityUtil.getAlchemyNextRefreshTime(lastRefreshTime);
	// if (nextRefreshTime != time)
	// {
	// return true;
	// }
	// return false;
	// }

}
