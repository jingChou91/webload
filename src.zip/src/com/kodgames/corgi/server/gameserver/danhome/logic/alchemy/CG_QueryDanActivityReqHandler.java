package com.kodgames.corgi.server.gameserver.danhome.logic.alchemy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryDanActivityReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryDanActivityRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.danhome.util.DHUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Alchemy.AlchemyActivityUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Alchemy.AlchemyUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Decompose.DecomposeActivityUtil;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_QueryDanActivityReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_QueryDanActivityReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_QueryDanActivityReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_QueryDanActivityReq request = (CG_QueryDanActivityReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryDanActivityRes.Builder builder = GC_QueryDanActivityRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_DAN_ACTIVITY_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_QUERY_DAN_ACTIVITY_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		int type = request.getActivityType();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_ACTIVITY_FAILED_LOAD_PLAYER;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.DanHome))
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_ACTIVITY_FAILED_FUNCTION_NOT_OPEN;
					break;
				}
				DanConfig danCfg = cd.get_DanConfig();
				if (danCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_ACTIVITY_FAILED_LOAD_CONFIG;
					break;
				}

				// 功能是否开启
				if (!danCfg.get_IsDanHomeOpen())
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_ACTIVITY_FAILED_DAN_HOME_NOT_OPEN;
					break;
				}
				// 活动切换
				if (AlchemyUtil.activityChange(playerNode, cd))
				{
					builder.setIsNeedRefresh(true);
					break;
				}
				builder.setIsNeedRefresh(false);
				// 系统刷新
				DHUtil.systemRefresh(playerNode, cd);
				// 如果是炼丹活动
				if (type == DanConfig._ActivityType.Alchemy)
				{
					int activityNum = AlchemyActivityUtil.getAlchemyActivityNum();
					// 当前炼丹活动的说明
					DanConfig.ActivityExplain explainCfg =
						danCfg.GetActivityExplain(DanConfig._ActivityType.Alchemy, activityNum);
					builder.setAcitvityName(explainCfg.get_AcitvityName());
					// 每个详细说明切页
					for (int i = 0; i < explainCfg.Get_ActivityDetailsCount(); i++)
					{
						DanConfig.ActivityDetail detailCfg = explainCfg.Get_ActivityDetailsByIndex(i);
						// 如果是宝箱
						if (DanConfig._ActivityDetailType.Box == detailCfg.get_Type())
						{
							CommonProtocols.DanActivityTap.Builder activityTapBuilder =
								CommonProtocols.DanActivityTap.newBuilder();
							activityTapBuilder.setType(DanConfig._ActivityDetailType.Box);
							activityTapBuilder.setIconId(detailCfg.get_IconId());
							activityTapBuilder.setActivityDesc(detailCfg.get_ActivityDesc());
							for (int j = 0; j < danCfg.Get_BoxRewardsCount(); j++)
							{
								CommonProtocols.DanActivityReward.Builder activityRewardBuilder =
									CommonProtocols.DanActivityReward.newBuilder();

								DanConfig.BoxReward boxRewardCfg = danCfg.Get_BoxRewardsByIndex(j);
								if (boxRewardCfg.get_ActivityNum() != activityNum)
								{
									continue;
								}
								activityRewardBuilder.setAlchemyCount(boxRewardCfg.get_AlchemyCount());
								for (int k = 0; k < boxRewardCfg.Get_RewardsCount(); k++)
								{
									ClientServerCommon.Reward rewardCfg = boxRewardCfg.Get_RewardsByIndex(k);
									activityRewardBuilder.addBaseRewards(AlchemyUtil.GenShowReward(cd, rewardCfg));
								}
								for (int k = 0; k < boxRewardCfg.Get_RandomRewardsCount(); k++)
								{
									DanConfig.RandomReward randomRewardCfg = boxRewardCfg.Get_RandomRewardsByIndex(k);
									for (int m = 0; m < randomRewardCfg.Get_RewardWeightsCount(); m++)
									{
										DanConfig.RewardWeight rewardWeightCfg =
											randomRewardCfg.Get_RewardWeightsByIndex(m);
										activityRewardBuilder.addExtraRewards(AlchemyUtil.GenShowReward(cd,
											rewardWeightCfg.get_Reward()));
									}

								}
								activityTapBuilder.addDanActivityRewards(activityRewardBuilder.build());
							}
							builder.addDanActivityTaps(activityTapBuilder.build());
						}
						// 如果是指定丹
						else if (DanConfig._ActivityDetailType.SpecialDan == detailCfg.get_Type())
						{
							CommonProtocols.DanActivityTap.Builder activityTapBuilder =
								CommonProtocols.DanActivityTap.newBuilder();
							activityTapBuilder.setType(DanConfig._ActivityDetailType.SpecialDan);
							activityTapBuilder.setIconId(detailCfg.get_IconId());
							activityTapBuilder.setActivityDesc(detailCfg.get_ActivityDesc());
							for (int j = 0; j < danCfg.Get_SpecialDanRewardsCount(); j++)
							{

								DanConfig.SpecialDanReward specialDanRewardCfg = danCfg.Get_SpecialDanRewardsByIndex(j);
								if (specialDanRewardCfg.get_ActivityNum() != activityNum)
								{
									continue;
								}
								CommonProtocols.DanActivityReward.Builder activityRewardBuilder =
									CommonProtocols.DanActivityReward.newBuilder();
								activityRewardBuilder.addBaseRewards(AlchemyUtil.GenShowReward(cd,
									specialDanRewardCfg.get_ResourseId(),
									specialDanRewardCfg.get_Level(),
									specialDanRewardCfg.get_Breakthought(),
									1,
									specialDanRewardCfg.get_AlgorithmId()));
								for (int n = 0; n < specialDanRewardCfg.Get_RandomRewardsCount(); n++)
								{
									DanConfig.RandomReward randomRewardCfg =
										specialDanRewardCfg.Get_RandomRewardsByIndex(n);
									for (int l = 0; l < randomRewardCfg.Get_RewardWeightsCount(); l++)
									{
										DanConfig.RewardWeight rewardWeightCfg =
											randomRewardCfg.Get_RewardWeightsByIndex(l);
										activityRewardBuilder.addExtraRewards(AlchemyUtil.GenShowReward(cd,
											rewardWeightCfg.get_Reward()));
									}
								}
								activityTapBuilder.addDanActivityRewards(activityRewardBuilder.build());

							}
							builder.addDanActivityTaps(activityTapBuilder.build());
						}

					}

				}
				else if (type == DanConfig._ActivityType.Decompose)
				{
					int activityNum = DecomposeActivityUtil.getDecomposeActivityNum();
					// 当前炼丹活动的说明
					DanConfig.ActivityExplain explainCfg =
						danCfg.GetActivityExplain(DanConfig._ActivityType.Decompose, activityNum);
					builder.setAcitvityName(explainCfg.get_AcitvityName());
					// 每个详细说明切页
					for (int i = 0; i < explainCfg.Get_ActivityDetailsCount(); i++)
					{
						DanConfig.ActivityDetail detailCfg = explainCfg.Get_ActivityDetailsByIndex(i);
						// 如果是分解结果
						if (DanConfig._ActivityDetailType.DecomposeResult == detailCfg.get_Type())
						{
							CommonProtocols.DanActivityTap.Builder activityTapBuilder =
								CommonProtocols.DanActivityTap.newBuilder();
							activityTapBuilder.setType(DanConfig._ActivityDetailType.DecomposeResult);
							activityTapBuilder.setIconId(detailCfg.get_IconId());
							activityTapBuilder.setActivityDesc(detailCfg.get_ActivityDesc());
							for (int j = 0; j < danCfg.Get_DecomposeResultInfosCount(); j++)
							{
								DanConfig.DecomposeResultInfo decomposeResultInfoCfg =
									danCfg.Get_DecomposeResultInfosByIndex(j);
								if (decomposeResultInfoCfg.get_ActivityNum() != activityNum)
								{
									continue;
								}

								for (int k = 0; k < decomposeResultInfoCfg.Get_DecomposeResultsCount(); k++)
								{
									CommonProtocols.DanActivityReward.Builder activityRewardBuilder =
										CommonProtocols.DanActivityReward.newBuilder();
									activityRewardBuilder.setResourseId(decomposeResultInfoCfg.get_Id());

									DanConfig.DecomposeResult decomposeResultCfg =
										decomposeResultInfoCfg.Get_DecomposeResultsByIndex(k);
									activityRewardBuilder.setBreakthought(decomposeResultCfg.get_Breakthought());
									activityRewardBuilder.setLevel(decomposeResultCfg.get_Level());
									for (int m = 0; m < decomposeResultCfg.Get_PosibilityRewardsCount(); m++)
									{
										DanConfig.PosibilityReward posibilityRewardCfg =
											decomposeResultCfg.Get_PosibilityRewardsByIndex(m);
										CommonProtocols.ShowReward.Builder showRewardBuilder =
											CommonProtocols.ShowReward.newBuilder();
										showRewardBuilder.setId(posibilityRewardCfg.get_Id());
										// 客户端不展示数量
										showRewardBuilder.setCount(-1);
										// if (posibilityRewardCfg.get_Posibility() >= 1)
										// {
										// activityRewardBuilder.addBaseRewards(showRewardBuilder.build());
										// }
										// else
										// {
										activityRewardBuilder.addExtraRewards(showRewardBuilder.build());
										// }
									}
									for (int m = 0; m < decomposeResultCfg.Get_RandomRewardsCount(); m++)
									{
										DanConfig.RandomReward randomRewardCfg =
											decomposeResultCfg.Get_RandomRewardsByIndex(m);
										for (int n = 0; n < randomRewardCfg.Get_RewardWeightsCount(); n++)
										{
											DanConfig.RewardWeight rewardWeightCfg =
												randomRewardCfg.Get_RewardWeightsByIndex(n);
											activityRewardBuilder.addExtraRewards(AlchemyUtil.GenShowReward(cd,
												rewardWeightCfg.get_Reward()));
										}
									}
									activityTapBuilder.addDanActivityRewards(activityRewardBuilder.build());
								}
							}
							builder.addDanActivityTaps(activityTapBuilder.build());
						}
						else if (DanConfig._ActivityDetailType.DecomposeCount == detailCfg.get_Type())
						{
							CommonProtocols.DanActivityTap.Builder activityTapBuilder =
								CommonProtocols.DanActivityTap.newBuilder();
							activityTapBuilder.setType(DanConfig._ActivityDetailType.DecomposeCount);
							activityTapBuilder.setIconId(detailCfg.get_IconId());
							activityTapBuilder.setActivityDesc(detailCfg.get_ActivityDesc());
							builder.addDanActivityTaps(activityTapBuilder.build());
						}
						else if (DanConfig._ActivityDetailType.DecomposePosibility == detailCfg.get_Type())
						{
							CommonProtocols.DanActivityTap.Builder activityTapBuilder =
								CommonProtocols.DanActivityTap.newBuilder();
							activityTapBuilder.setType(DanConfig._ActivityDetailType.DecomposePosibility);
							activityTapBuilder.setIconId(detailCfg.get_IconId());
							activityTapBuilder.setActivityDesc(detailCfg.get_ActivityDesc());
							builder.addDanActivityTaps(activityTapBuilder.build());
						}
					}

				}
				else
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_ACTIVITY_FAILED_ACTIVITY_TYPE;
					break;
				}
			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
