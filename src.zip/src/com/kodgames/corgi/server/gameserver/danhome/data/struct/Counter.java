package com.kodgames.corgi.server.gameserver.danhome.data.struct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.DanConfig;

import com.kodgames.corgi.server.gameserver.danhome.util.Alchemy.AlchemyUtil;

public class Counter
{
	private static final Logger logger = LoggerFactory.getLogger(AlchemyUtil.class);

	private int id;
	private int refreshTimes;// 已计数次数
	private int activateTimes;// 已激活次数

	public void addActivateTimes()
	{
		this.activateTimes++;
	}

	public void testAndAddRefreshTimes(DanConfig.Counter config)
	{
		if (AlchemyUtil.verifyTime(config.get_BeginTime(), config.get_EndTime()))
		{
			int maxRefreshTimes =
				config.get_BeginNeedTimes() + config.get_NeedTimes() * (config.get_MaxActivatedTimes() - 1);
			if (refreshTimes < maxRefreshTimes)
			{
				refreshTimes++;
				logger.debug("_____Alchemy  Counter RefreshTimes ++,CounterId: " + id + " new refreshTimes: "
					+ refreshTimes + "  activateTimes:  " + activateTimes + " BeginNeedTimes: "
					+ config.get_BeginNeedTimes() + " ActivateNeedTimes: " + config.get_NeedTimes());
			}
		}
	}

	/**
	 * 判断计数器是可以否激活
	 */
	public boolean canActive(DanConfig.Counter config)
	{
		if (AlchemyUtil.verifyTime(config.get_BeginTime(), config.get_EndTime()))
		{
			// 已激活次数<最大激活次数
			if (activateTimes < config.get_MaxActivatedTimes())
			{
				if (refreshTimes < config.get_BeginNeedTimes())
				{
					return false;
				}
				// 已炼丹次数==计数器生效起始次数 并且从未激活过
				if (refreshTimes == config.get_BeginNeedTimes() && activateTimes == 0)
				{
					return true;
				}
				// (已炼丹次数-计数器生效起始次数)/激活所需炼丹次数>(已激活次数-1)
				if ((refreshTimes - config.get_BeginNeedTimes()) / config.get_NeedTimes() > (activateTimes - 1))
				{
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * 获取该计数器下次激活所需次数
	 */
	public int getRemainTimesForActive(DanConfig.Counter config)
	{
		// 如果现在已经可以激活,那么下次刷新一定激活
		if (canActive(config))
		{
			return 1;
		}
		// 如果不在激活时间范围,那么返回-1
		if (!AlchemyUtil.verifyTime(config.get_BeginTime(), config.get_EndTime()))
		{
			return -1;
		}
		// 如果已达最大激活次数,那么返回-1
		if (activateTimes >= config.get_MaxActivatedTimes())
		{
			return -1;
		}
		// 当未达起始激活次数时
		if (refreshTimes < config.get_BeginNeedTimes())
		{
			return config.get_BeginNeedTimes() - refreshTimes;
		}
		// 当已达起始激活次数
		else
		{
			return config.get_NeedTimes() - ((refreshTimes - config.get_BeginNeedTimes()) % config.get_NeedTimes());
		}
	}

	/**
	 * 重置计数器
	 */
	public void reset()
	{
		this.setRefreshTimes(0);
		this.setActivateTimes(0);
	}

	public Counter()
	{
	}

	public Counter(int id)
	{
		super();
		this.id = id;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public int getRefreshTimes()
	{
		return refreshTimes;
	}

	public void setRefreshTimes(int refreshTimes)
	{
		this.refreshTimes = refreshTimes;
	}

	public int getActivateTimes()
	{
		return activateTimes;
	}

	public void setActivateTimes(int activateTimes)
	{
		this.activateTimes = activateTimes;
	}

}
