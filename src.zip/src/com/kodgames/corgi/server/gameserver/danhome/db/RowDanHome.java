package com.kodgames.corgi.server.gameserver.danhome.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.rowset.CachedRowSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;

import com.google.protobuf.InvalidProtocolBufferException;
import com.kodgames.corgi.protocol.DBProtocolsForServer;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeData;
import com.kodgames.corgi.server.gameserver.danhome.data.struct.Counter;
import com.kodgames.corgi.server.gameserver.danhome.data.struct.SpecialDanReward;
import com.kodgames.gamedata.dbcommon.DBEasy;
import com.kodgames.gamedata.player.PlayerNode;

public class RowDanHome
{
	private static final Logger logger = LoggerFactory.getLogger(RowDanHome.class);

	public static void selectPrivate(int queryIndex, Connection con, PreparedStatement[] vps, CachedRowSet[] vrs,
		PlayerNode playerNode, ConfigDatabase cd)
		throws SQLException
	{
		String sql = "select * from dan_home where player_id=?";
		vps[queryIndex] = con.prepareStatement(sql);
		DBEasy.closeRowSet(vrs, queryIndex);
		vrs[queryIndex] = DBEasy.doPrivateQuery(vps[queryIndex], sql, new Object[] {playerNode.getPlayerId()});

		if (vrs[queryIndex] != null)
		{
			CachedRowSet rs = vrs[queryIndex];
			while (rs.next())
			{
				DanHomeData dhData = playerNode.getPlayerInfo().getDanHomeData();
				int alchemyActivityNum = rs.getInt("alchemy_activity_num");
				int alchemyCount = rs.getInt("alchemy_count");
				long lastRefreshTime = rs.getLong("last_refresh_time");
				int decomposeActivityNum = rs.getInt("decompose_activity_num");
				int danDecomposeCount = rs.getInt("decompose_count");
				int danItemDecomposeCount = rs.getInt("item_decompose_count");
				dhData.setAlchemyActivityNum(alchemyActivityNum);
				dhData.setAlchemyCount(alchemyCount);
				dhData.setLastRefreshTime(lastRefreshTime);
				dhData.setDecomposeActivityNum(decomposeActivityNum);
				dhData.setDanDecomposeCount(danDecomposeCount);
				dhData.setDanItemDecomposeCount(danItemDecomposeCount);

				// 计数器信息
				byte[] counter_info = rs.getBytes("counter_info");
				DBProtocolsForServer.AlchemyCounterInfoDB.Builder counterInfoBuilder =
					DBProtocolsForServer.AlchemyCounterInfoDB.newBuilder();
				if (counter_info != null)
				{
					try
					{
						counterInfoBuilder.mergeFrom(counter_info);
					}
					catch (InvalidProtocolBufferException e)
					{
						logger.error("DanHome load Counters information failed.");
					}
				}
				Map<Integer, Counter> counters = new HashMap<Integer, Counter>();// 计数器
				for (int i = 0; i < counterInfoBuilder.getAlchemyCounterDBsCount(); i++)
				{
					DBProtocolsForServer.AlchemyCounterDB counterDB = counterInfoBuilder.getAlchemyCounterDBs(i);
					Counter counter = new Counter();
					counter.setId(counterDB.getId());
					counter.setRefreshTimes(counterDB.getRefreshTimes());
					counter.setActivateTimes(counterDB.getActivateTimes());
					counters.put(counter.getId(), counter);
				}
				dhData.setCounters(counters);

				// 宝箱信息
				byte[] box_reward_info = rs.getBytes("box_reward_info");
				DBProtocolsForServer.AlchemyBoxInfoDB.Builder boxInfoBuilder =
					DBProtocolsForServer.AlchemyBoxInfoDB.newBuilder();
				if (box_reward_info != null)
				{
					try
					{
						boxInfoBuilder.mergeFrom(box_reward_info);
					}
					catch (InvalidProtocolBufferException e)
					{
						logger.error("DanHome load boxs information failed.");
					}
				}
				Map<Integer, Boolean> boxRewards = new HashMap<Integer, Boolean>();// 宝箱id_是否已领取
				for (int i = 0; i < boxInfoBuilder.getAlchemyBoxDBsCount(); i++)
				{
					DBProtocolsForServer.AlchemyBoxDB boxDB = boxInfoBuilder.getAlchemyBoxDBs(i);
					boxRewards.put(boxDB.getId(), boxDB.getHasPicked());
				}
				dhData.setBoxRewards(boxRewards);

				// 计数器信息
				byte[] special_dan_reward_info = rs.getBytes("special_dan_reward_info");
				DBProtocolsForServer.AlchemySpecialDanRewardInfoDB.Builder apecialDanRewardInfoBuilder =
					DBProtocolsForServer.AlchemySpecialDanRewardInfoDB.newBuilder();

				if (special_dan_reward_info != null)
				{
					try
					{
						apecialDanRewardInfoBuilder.mergeFrom(special_dan_reward_info);
					}
					catch (InvalidProtocolBufferException e)
					{
						logger.error("DanHome load specialDanReward information failed.");
					}
				}
				Map<Integer, SpecialDanReward> specialDanRewards = new HashMap<Integer, SpecialDanReward>();// 指定内丹奖励Id_已奖励次数
				for (int i = 0; i < apecialDanRewardInfoBuilder.getAlchemySpecialDanRewardDBsCount(); i++)
				{
					DBProtocolsForServer.AlchemySpecialDanRewardDB specialDanRewardDB =
						apecialDanRewardInfoBuilder.getAlchemySpecialDanRewardDBs(i);
					SpecialDanReward specialDanReward = new SpecialDanReward();
					specialDanReward.setId(specialDanRewardDB.getId());
					specialDanReward.setCycleGetTimes(specialDanRewardDB.getCycleGetTimes());
					specialDanReward.setTotalGetTimes(specialDanRewardDB.getTotalGetTimes());
					specialDanReward.setLastRefreshTime(specialDanRewardDB.getLastRefreshTime());
					specialDanRewards.put(specialDanReward.getId(), specialDanReward);
				}
				dhData.setSpecialDanRewards(specialDanRewards);
				// 上次查询时间
				String lastQueryTimes = rs.getString("last_query_time");
				Map<Integer, Long> mapLastQueryTime = new HashMap<Integer, Long>();
				if (lastQueryTimes != null && !lastQueryTimes.trim().equals(""))
				{
					String[] tempLastQueryTimess = lastQueryTimes.split("\\|");
					for (int j = 0; j < tempLastQueryTimess.length; j++)
					{
						String[] lastQueryTime = tempLastQueryTimess[j].split("&");
						if (lastQueryTime.length == 2)
						{
							mapLastQueryTime.put(Integer.parseInt(lastQueryTime[0]), Long.parseLong(lastQueryTime[1]));
						}
					}
					dhData.setType_LastQueryTime(mapLastQueryTime);
				}
			}
		}
	}
}
