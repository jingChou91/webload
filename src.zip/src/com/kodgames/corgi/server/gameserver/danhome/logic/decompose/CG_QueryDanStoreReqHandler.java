package com.kodgames.corgi.server.gameserver.danhome.logic.decompose;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryDanStoreReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryDanStoreRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeData;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeMgr;
import com.kodgames.corgi.server.gameserver.danhome.util.DHUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Decompose.DecomposeUtil;
import com.kodgames.gamedata.player.PlayerNode;

public class CG_QueryDanStoreReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_QueryDanStoreReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv QueryDanStoreReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_QueryDanStoreReq request = (CG_QueryDanStoreReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryDanStoreRes.Builder builder = GC_QueryDanStoreRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_DAN_STORE_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_QUERY_DAN_STORE_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		int type = request.getType();

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_STORE_FAILED_LOAD_PALYER;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.DanHome))
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_STORE_FAILED_FUNCTION_NOT_OPEN;
					break;
				}
				DanConfig danCfg = cd.get_DanConfig();
				if (danCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_STORE_FAILED_LOAD_CONFIG;
					break;
				}
				DanHomeData dhData = playerNode.getPlayerInfo().getDanHomeData();

				// 功能是否开启
				if (!danCfg.get_IsDanHomeOpen())
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_STORE_FAILED_DAN_HOME_NOT_OPEN;
					break;
				}
				// 系统刷新
				DHUtil.systemRefresh(playerNode, cd);

				if (type != DanConfig._DanType.Sky && type != DanConfig._DanType.Earth
					&& type != DanConfig._DanType.Human && type != DanConfig._DanType.Ghost
					&& type != DanConfig._DanType.God)
				{
					result = ClientProtocols.E_GAME_QUERY_DAN_STORE_FAILED_TYPE_ERROR;
					break;
				}

				// 返回上次查询时间
				builder.addDanStoreQueryTimes(DecomposeUtil.getDanStoreQueryTime(dhData, DanConfig._DanType.Sky));
				builder.addDanStoreQueryTimes(DecomposeUtil.getDanStoreQueryTime(dhData, DanConfig._DanType.Earth));
				builder.addDanStoreQueryTimes(DecomposeUtil.getDanStoreQueryTime(dhData, DanConfig._DanType.Human));
				builder.addDanStoreQueryTimes(DecomposeUtil.getDanStoreQueryTime(dhData, DanConfig._DanType.Ghost));
				builder.addDanStoreQueryTimes(DecomposeUtil.getDanStoreQueryTime(dhData, DanConfig._DanType.God));

				// 修改内存
				dhData.updateLastQueryTime(type);
				// 修改数据库
				DanHomeMgr.updateDB(playerNode);

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
