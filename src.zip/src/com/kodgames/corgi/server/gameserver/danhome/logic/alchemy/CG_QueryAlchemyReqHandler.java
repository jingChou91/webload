package com.kodgames.corgi.server.gameserver.danhome.logic.alchemy;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon.DanConfig.ActivityExplain;
import ClientServerCommon._OpenFunctionType;

import com.kodgames.corgi.core.ClientNode;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.protocol.GameProtocolsForClient.CG_QueryAlchemyReq;
import com.kodgames.corgi.protocol.GameProtocolsForClient.GC_QueryAlchemyRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.FunctionOpenUtil;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeData;
import com.kodgames.corgi.server.gameserver.danhome.util.DHUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Alchemy.AlchemyActivityUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Alchemy.AlchemyUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Decompose.DecomposeActivityUtil;
import com.kodgames.corgi.server.gameserver.danhome.util.Decompose.DecomposeUtil;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Cost;

public class CG_QueryAlchemyReqHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(CG_QueryAlchemyReqHandler.class);

	@Override
	public HandlerAction handleClientMessage(ClientNode sender, Protocol message)
	{
		logger.info("recv CG_QueryAlchemyReq, playerId = {}", sender.getClientUID().getPlayerID());

		CG_QueryAlchemyReq request = (CG_QueryAlchemyReq)message.getProtoBufMessage();
		super.setExceptionCallbackForClient(request.getCallback());
		super.setTransmitter(ServerDataGS.transmitter);

		GC_QueryAlchemyRes.Builder builder = GC_QueryAlchemyRes.newBuilder();
		Protocol protocol = new Protocol(ClientProtocols.P_GAME_GC_QUERY_ALCHEMY_RES);
		builder.setCallback(request.getCallback());

		int playerId = sender.getClientUID().getPlayerID();
		int result = ClientProtocols.E_GAME_QUERY_ALCHEMY_SUCCESS;
		ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

		PlayerNode playerNode = null;
		ServerDataGS.playerManager.lockPlayer(playerId);
		try
		{
			do
			{
				playerNode = ServerDataGS.playerManager.getPlayerNode(playerId);
				if (playerNode == null || playerNode.getPlayerInfo() == null)
				{
					result = ClientProtocols.E_GAME_QUERY_ALCHEMY_FAILED_LOAD_PLAYER;
					break;
				}
				if (!FunctionOpenUtil.isFunctionOpen(cd, playerNode, _OpenFunctionType.DanHome))
				{
					result = ClientProtocols.E_GAME_QUERY_ALCHEMY_FAILED_FUNCTION_NOT_OPEN;
					break;
				}
				DanConfig danCfg = cd.get_DanConfig();
				if (danCfg == null)
				{
					result = ClientProtocols.E_GAME_QUERY_ALCHEMY_FAILED_LOAD_CONFIG;
					break;
				}
				DanHomeData dhData = playerNode.getPlayerInfo().getDanHomeData();

				AlchemyUtil.printMemory(cd, dhData);
				// 功能是否开启
				if (!danCfg.get_IsDanHomeOpen())
				{
					result = ClientProtocols.E_GAME_QUERY_ALCHEMY_FAILED_DAN_HOME_NOT_OPEN;
					break;
				}
				// 活动切换
				AlchemyUtil.activityChange(playerNode, cd);
				// 系统刷新
				DHUtil.systemRefresh(playerNode, cd);
				// 返回下次刷新时间
				builder.setNextRefreshTime(ServerUtil.nextRefreshTime(System.currentTimeMillis(),
					danCfg.get_RefreshTimeDateTime()));
				// 当前活动编号和炼丹次数
				int activityNum = AlchemyActivityUtil.getAlchemyActivityNum();
				int alchemyCount = dhData.getAlchemyCount();
				// 返回玩家此次炼丹消耗
				Cost alchemyCost = AlchemyUtil.getAlchemyCost(dhData, danCfg, activityNum, alchemyCount);
				if (alchemyCost == null)
				{
					result = ClientProtocols.E_GAME_QUERY_ALCHEMY_FAILED_QUERY_COST_ERROR;
					break;
				}
				builder.addAlchemyCosts(alchemyCost.toProtobuf());
				// 返回玩家批量炼丹消耗
				List<Cost> costs = AlchemyUtil.getBatchAlchemyCost(dhData, danCfg, activityNum, alchemyCount);
				for (Cost cost : costs)
				{
					builder.addBatchAlchemyCosts(cost.toProtobuf());
				}
				// 返回今日已炼丹次数
				builder.setTodayAlchemyCount(alchemyCount);
				// 返回客户端图标信息
				DanConfig.AlchemyActivity alchemyActivityCfg = danCfg.GetAlchemyActivityByNum(activityNum);
				if (alchemyActivityCfg != null)
				{
					CommonProtocols.AlchemyClientIcon.Builder clientIconBuilder =
						CommonProtocols.AlchemyClientIcon.newBuilder();
					clientIconBuilder.setAlchemyIcon(alchemyActivityCfg.get_AlchemyIcon());
					clientIconBuilder.setAlchemyDesc(alchemyActivityCfg.get_AlchemyDesc());
					clientIconBuilder.setBackIcon(alchemyActivityCfg.get_BackIcon());
					ActivityExplain explainCfg =
						danCfg.GetActivityExplain(DanConfig._ActivityType.Alchemy, activityNum);
					if (explainCfg != null)
					{
						clientIconBuilder.setActivityName(explainCfg.get_AcitvityName());
					}
					clientIconBuilder.setActivityStartTime(AlchemyActivityUtil.getAlchemyActivityStartTime(activityNum));
					clientIconBuilder.setActivityEndTime(AlchemyActivityUtil.getAlchemyActivityEndTime(activityNum));
					clientIconBuilder.setNoActivityText(danCfg.get_NoAitivityDesc());
					builder.setAlchemyClientIcon(clientIconBuilder.build());
				}
				// 返回客户端宝箱信息
				AlchemyUtil.genBoxRewardInfo(builder, dhData, cd, activityNum);
				// 返回展示计数器
				CommonProtocols.ShowCounter showCounter = AlchemyUtil.genShowCounterInfo(dhData, cd, activityNum);
				if (showCounter != null)
				{
					builder.setShowCounter(showCounter);
				}
				int decomposeActivityNum = DecomposeActivityUtil.getDecomposeActivityNum();
				//返回客户端分解相关信息
				builder.setDecomposeInfo(DecomposeUtil.genDecomposeInfo(cd, playerNode, decomposeActivityNum));

			} while (false);
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(playerId);
		}

		builder.setResult(result);
		protocol.setProtoBufMessage(builder.build());
		ServerDataGS.transmitter.sendToClient(sender, protocol);
		return HandlerAction.TERMINAL;
	}
}
