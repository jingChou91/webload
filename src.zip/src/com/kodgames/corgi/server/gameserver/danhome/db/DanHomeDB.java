package com.kodgames.corgi.server.gameserver.danhome.db;

import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.dbclient.TableChangeEvent;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeData;
import com.kodgames.corgi.server.gameserver.danhome.util.DHUtil;
import com.kodgames.gamedata.player.PlayerNode;

public class DanHomeDB
{
	public static void updateDanHome(PlayerNode playerNode)
	{
		DanHomeData dhData = playerNode.getPlayerInfo().getDanHomeData();
		String sqlCommand =
			String.format("replace into dan_home (player_id,last_refresh_time,alchemy_activity_num,decompose_activity_num, alchemy_count,decompose_count,item_decompose_count,counter_info,box_reward_info,special_dan_reward_info,last_query_time) VALUES (%d,%d,%d,%d,%d,%d,%d,%s,%s,%s,'%s')",
				playerNode.getPlayerId(),
				dhData.getLastRefreshTime(),
				dhData.getAlchemyActivityNum(),
				dhData.getDecomposeActivityNum(),
				dhData.getAlchemyCount(),
				dhData.getDanDecomposeCount(),
				dhData.getDanItemDecomposeCount(),
				ServerUtil.toHexString(dhData.getAlchemyCounterInfoDBProtoBuff().toByteArray()),
				ServerUtil.toHexString(dhData.getAlchemyBoxInfoDBProtoBuff().toByteArray()),
				ServerUtil.toHexString(dhData.getAlchemySpecialDanRewardInfoDBProtoBuff().toByteArray()),
				DHUtil.MapToString(dhData.getType_LastQueryTime()));

		ServerDataGS.dbCluster.getGameDBClient()
			.executeAsynchronousUpdate(TableChangeEvent.getKey(playerNode.getPlayerId(),
				TableChangeEvent.DANHOME_UPDATE),
				playerNode.getPlayerId(),
				sqlCommand);
	}
}
