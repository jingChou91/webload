package com.kodgames.corgi.server.gameserver.danhome.util.Decompose;

import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;
import ClientServerCommon.VipConfig;

import com.kodgames.common.ValueRandomer;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.CommonProtocols;
import com.kodgames.corgi.server.gameserver.dan.data.Dan;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeData;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeMgr;
import com.kodgames.gamedata.player.PlayerNode;
import com.kodgames.gamedata.player.costandreward.Consume;
import com.kodgames.gamedata.player.costandreward.Cost;
import com.kodgames.gamedata.player.costandreward.Reward;

public class DecomposeUtil
{
	public static final int DEFAULT_ACTIVITYNUM = -1;// 默认活动编号
	public static final int DAY = 24 * 60 * 60 * 1000;

	private static final Logger logger = LoggerFactory.getLogger(DecomposeUtil.class);

	/**
	 * 返回客户端分解相关信息
	 */
	public static CommonProtocols.DecomposeInfo genDecomposeInfo(ConfigDatabase cd, PlayerNode playerNode,
		int activityNum)
	{
		DanConfig danCfg = cd.get_DanConfig();
		DanHomeData dhData = playerNode.getPlayerInfo().getDanHomeData();

		CommonProtocols.DecomposeInfo.Builder builder = CommonProtocols.DecomposeInfo.newBuilder();
		int vipLevel = playerNode.getGamePlayer().getVipLevel();
		builder.setDanDecomposeCout(DecomposeUtil.getRemainDecomposeCount(cd, dhData, vipLevel, activityNum));
		builder.setDanItemDecomposeCount(DecomposeUtil.getRemainItemDecomposeCount(cd, dhData, vipLevel, activityNum));
		builder.setMaxDanDecomposeCout(DecomposeUtil.getMaxDecomposeCount(cd, vipLevel, activityNum));
		builder.setMaxDanItemDecomposeCount(DecomposeUtil.getMaxItemDecomposeCount(cd, vipLevel, activityNum));
		ClientServerCommon.Cost cost = danCfg.get_ItemDecomposeCost();
		Cost decomposeCost = new Cost(cost.get_id(), cost.get_count());
		builder.setDecomposeCost(decomposeCost.toProtobuf());
		return builder.build();
	}

	/**
	 * 根据类型获取灵丹阁上次查询时间
	 */
	public static CommonProtocols.DanStoreQueryTime getDanStoreQueryTime(DanHomeData dhData, int type)
	{
		CommonProtocols.DanStoreQueryTime.Builder builder = CommonProtocols.DanStoreQueryTime.newBuilder();
		builder.setType(type);
		builder.setLastQueryTime(dhData.getLastQueryTime(type));
		return builder.build();
	}

	/**
	 * 获得分解结果和奖励
	 */
	public static int getDecomposeResult(Dan dan, int activityNum, Reward reward, DanConfig danCfg)
	{
		DanConfig.DecomposeResultInfo decomposeResultInfo =
			danCfg.GetDecomposeResultInfoByDanId(activityNum, dan.getResourceId());
		DanConfig.DecomposeResult decomposeResult = null;
		if (decomposeResultInfo != null)
		{
			decomposeResult = decomposeResultInfo.GetDecomposeResultByLevel(dan.getLevel(), dan.getBreakthoughtLevel());
		}
		if (decomposeResult == null)
		{
			decomposeResultInfo = danCfg.GetDecomposeResultInfoByDanId(DEFAULT_ACTIVITYNUM, dan.getResourceId());
			if (decomposeResultInfo != null)
			{
				decomposeResult =
					decomposeResultInfo.GetDecomposeResultByLevel(dan.getLevel(), dan.getBreakthoughtLevel());
			}
		}
		if (decomposeResult == null)
		{
			logger.error("___________________get DanConfig.DecomposeResult error, activityNum = {}, id = {}, level={}, breakthoughtLevel={}",
				DEFAULT_ACTIVITYNUM,
				dan.getResourceId(),
				dan.getLevel(),
				dan.getBreakthoughtLevel());
			return ClientProtocols.E_GAME_AVATAR_LEVEL_UP_FAILED_LOAD_EQUIPMENT;
		}

		Random random = new Random();
		// 概率奖励
		for (int i = 0; i < decomposeResult.Get_PosibilityRewardsCount(); i++)
		{
			DanConfig.PosibilityReward posibilityReward = decomposeResult.Get_PosibilityRewardsByIndex(i);
			// 概率满足
			double posibility = Math.random();
			logger.debug(" ___________________Dan Decompose PosibilityResult Math.random(): " + posibility
				+ " EffectivePosibility: " + posibilityReward.get_Posibility());
			if (posibilityReward.get_Posibility() > 0 && posibility <= posibilityReward.get_Posibility())
			{
				int amount =
					random.nextInt(posibilityReward.get_CountMax() - posibilityReward.get_CountMin() + 1)
						+ posibilityReward.get_CountMin();

				Consume consume = new Consume(posibilityReward.get_Id(), amount);
				logger.debug(" ___________________Dan Decompose PosibilityResult Effective!!! RewardId:"
					+ posibilityReward.get_Id() + " amount:" + amount);
				reward.getConsumables().add(consume);
			}
		}

		// 随机奖励
		for (int i = 0; i < decomposeResult.Get_RandomRewardsCount(); i++)
		{
			ValueRandomer valueRandomer = new ValueRandomer();
			DanConfig.RandomReward randomReward = decomposeResult.Get_RandomRewardsByIndex(i);
			for (int j = 0; j < randomReward.Get_RewardWeightsCount(); j++)
			{
				DanConfig.RewardWeight rewardWeight = randomReward.Get_RewardWeightsByIndex(j);
				if (rewardWeight.get_Weight() > 0)
				{
					valueRandomer.addValue(rewardWeight.get_Weight(), rewardWeight.get_Reward());
				}
			}
			valueRandomer.SetTotalValue();
			Object data = valueRandomer.RandomData();
			logger.debug(" ___________________Dan Decompose WeightResult  RandomPool Size:" + valueRandomer.valueSize());
			if (data != null)
			{
				ClientServerCommon.Reward tmpReward = (ClientServerCommon.Reward)data;
				logger.debug(" ___________________Dan Decompose WeightResult Effective!!! RewardId:"
					+ tmpReward.get_id() + " count:" + tmpReward.get_count());
				reward.megerReward(new Reward().fromClientServerCommon(tmpReward));
			}
		}

		return ClientProtocols.E_GAME_DAN_DECOMPOSE_SUCCESS;
	}

	/**
	 * 分解活动切换
	 */
	public static boolean activityChange(PlayerNode playerNode, ConfigDatabase cd)
	{
		DanHomeData dhData = playerNode.getPlayerInfo().getDanHomeData();
		// 活动开启且玩家状态切换
		if (DecomposeActivityUtil.isDecomposeActivityChange(playerNode))
		{
			logger.debug("______________DecomposeActivity Change!!!");
			// 活动切换
			dhData.decopmoseActivityChangeRefresh(cd, DecomposeActivityUtil.getDecomposeActivityNum());
			// 修改数据库
			DanHomeMgr.updateDB(playerNode);
			return true;
		}
		logger.debug("______________DecomposeActivity Not Change");
		return false;
	}

	/**
	 * 获取剩余免费分解次数
	 */
	public static int getRemainDecomposeCount(ConfigDatabase cd, DanHomeData dhData, int vipLevel, int activityNum)
	{
		VipConfig vipCfg = cd.get_VipConfig();
		DanConfig danCfg = cd.get_DanConfig();
		int maxCount = vipCfg.GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.DanDecomposeCount);
		DanConfig.DecomposeActivityInfo activityInfo = danCfg.GetDecomposeActivityInfo(activityNum);
		if (activityInfo != null)
		{
			maxCount += activityInfo.get_ActiviyDecomposeCount();
		}
		int decomposeCount = dhData.getDanDecomposeCount();
		int result = maxCount - decomposeCount;
		return result > 0 ? result : 0;
	}

	/**
	 * 获取最大免费分解次数
	 */
	public static int getMaxDecomposeCount(ConfigDatabase cd, int vipLevel, int activityNum)
	{
		VipConfig vipCfg = cd.get_VipConfig();
		DanConfig danCfg = cd.get_DanConfig();
		int maxCount = vipCfg.GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.DanDecomposeCount);
		DanConfig.DecomposeActivityInfo activityInfo = danCfg.GetDecomposeActivityInfo(activityNum);
		if (activityInfo != null)
		{
			maxCount += activityInfo.get_ActiviyDecomposeCount();
		}
		return maxCount;
	}

	/**
	 * 获取剩余道具分解次数
	 */
	public static int getRemainItemDecomposeCount(ConfigDatabase cd, DanHomeData dhData, int vipLevel, int activityNum)
	{
		VipConfig vipCfg = cd.get_VipConfig();
		DanConfig danCfg = cd.get_DanConfig();
		int maxCount = vipCfg.GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.DanItemDecomposeCount);
		DanConfig.DecomposeActivityInfo activityInfo = danCfg.GetDecomposeActivityInfo(activityNum);
		if (activityInfo != null)
		{
			maxCount += activityInfo.get_ActiviyDecomposeCount();
		}
		int decomposeCount = dhData.getDanItemDecomposeCount();
		int result = maxCount - decomposeCount;
		return result > 0 ? result : 0;
	}

	/**
	 * 获取最大道具分解次数
	 */
	public static int getMaxItemDecomposeCount(ConfigDatabase cd, int vipLevel, int activityNum)
	{
		VipConfig vipCfg = cd.get_VipConfig();
		DanConfig danCfg = cd.get_DanConfig();
		int maxCount = vipCfg.GetVipLimitByVipLevel(vipLevel, VipConfig._VipLimitType.DanItemDecomposeCount);
		DanConfig.DecomposeActivityInfo activityInfo = danCfg.GetDecomposeActivityInfo(activityNum);
		if (activityInfo != null)
		{
			maxCount += activityInfo.get_ActiviyDecomposeCount();
		}
		return maxCount;
	}
}
