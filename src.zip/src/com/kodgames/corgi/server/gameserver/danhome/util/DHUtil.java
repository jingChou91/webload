package com.kodgames.corgi.server.gameserver.danhome.util;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.DanConfig;

import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeData;
import com.kodgames.corgi.server.gameserver.danhome.data.DanHomeMgr;
import com.kodgames.gamedata.player.PlayerNode;

public class DHUtil
{
	private static final Logger logger = LoggerFactory.getLogger(DHUtil.class);

	// Map转string
	public static String MapToString(Map<Integer, Long> map)
	{
		String str = "";
		for (Map.Entry<Integer, Long> entry : map.entrySet())
		{
			str += entry.getKey() + "&" + entry.getValue() + "|";
		}
		return str;
	}

	/**
	 * 系统刷新
	 */
	public static boolean systemRefresh(PlayerNode playerNode, ConfigDatabase cd)
	{
		DanHomeData dhData = playerNode.getPlayerInfo().getDanHomeData();
		// 重置指定丹奖励的周期循环
		dhData.alchemySpecialDanRefresh(cd, playerNode);
		// 判断是否需要刷新
		// if (AlchemyUtil.isAlchemyNeedRefersh(dhData.getAlchemyLastRefreshTime()))
		if (ServerUtil.isNeedRefresh(cd.get_DanConfig().get_RefreshTimeDateTime(), dhData.getLastRefreshTime()))
		{
			logger.debug("___________System Refresh!");
			// 系统刷新
			dhData.systemRefresh(cd);
			// 修改数据库
			DanHomeMgr.updateDB(playerNode);
			
			// 小助手
			playerNode.getPlayerInfo().getAssisantData().getDanHome().notifyObservers();
			return true;
		}
		logger.debug("___________System Not Refresh");
		dhData.setLastRefreshTime(System.currentTimeMillis());
		return false;
	}
	
	/**
	 * 小助手用， 玩家是否有可领取的炼丹次数奖励
	 */
	public static boolean hasRewardCanGet(ConfigDatabase cd, PlayerNode playerNode)
	{
		DanHomeData danHomeData = playerNode.getPlayerInfo().getDanHomeData();
		int activityNum = danHomeData.getAlchemyActivityNum();
		DanConfig danConfig = cd.get_DanConfig();
		for (int i = 0; i < danConfig.Get_BoxRewardsCount(); i++)
		{
			DanConfig.BoxReward boxReward = danConfig.Get_BoxRewardsByIndex(i);
			Boolean hasPicked = danHomeData.getBoxRewards().get(boxReward.get_Id());
			if (boxReward.get_ActivityNum() == activityNum
				&& boxReward.get_AlchemyCount() <= danHomeData.getAlchemyCount()
				&& (hasPicked == null || !hasPicked))
			{
				return true;
			}
		}
		
		return false;
	}
}
