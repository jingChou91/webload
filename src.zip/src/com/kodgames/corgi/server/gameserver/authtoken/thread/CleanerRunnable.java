/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.gameserver.authtoken.thread;

import java.util.HashSet;
import java.util.Map.Entry;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.CorgiUID;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.InterfaceProtocolsForClient.ClientDisconnect;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.LoopRunnable;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.ServerDataGS.ClientSession;
import com.kodgames.corgi.server.gameserver.ServerDataGS.SessionStatus;
import com.kodgames.corgi.server.gameserver.assistant.data.ObserverMgr;
import com.kodgames.corgi.server.gameserver.chat.data.ShowDialogPlayerIdMgr;
import com.kodgames.corgi.server.gameserver.initinfo.data.LoginMessageMgr;
import com.kodgames.corgi.server.gameserver.startserverreward.data.StartServerRewardMgr;
import com.kodgames.corgi.server.gameserver.task.timer.PlayerTimerMgr;
import com.kodgames.gamedata.commonconfig.CommonConfigMgr;
import com.kodgames.gamedata.player.PlayerNode;

/**
 * 
 * @author marui
 */
public class CleanerRunnable extends LoopRunnable 
{
	private static final Logger logger = LoggerFactory.getLogger(CleanerRunnable.class);

	private static long dSleepTimeSecond = 10;
	private static long dExpireTimeSecond = 3600;
	private static long disconnectedSecond = 30;

	public CleanerRunnable()
	{
		super(dSleepTimeSecond * 1000);
	}

	@Override
	public void execute()
	{
		long expiredTime = System.currentTimeMillis() - dExpireTimeSecond * 1000; // 超时时间
		long disconnectedExpiredTime = System.currentTimeMillis() - disconnectedSecond * 1000;// verified_disconnected或者unverified尽快踢掉
		HashSet<Integer> delSessions = new HashSet<>();

		for (ServerDataGS.ClientSession session : ServerDataGS.sessions.values())
		{
			if (session.getStatus() != SessionStatus.verified_Connected)
			{
				delSessions.add(session.getPlayerId());
			}
			else if (session.getLastUpdateTime() < expiredTime)// 超时
			{
				delSessions.add(session.getPlayerId());
			}
		}

		for (Integer playerId : delSessions)
		{
			ServerDataGS.ClientSession session = ServerDataGS.sessions.get(playerId);
			// 如果不是客户端主动断开连接
			if (session.getStatus() == SessionStatus.verified_disconnected
				|| session.getStatus() == SessionStatus.unverified)
			{
				if (session.getLastUpdateTime() < disconnectedExpiredTime)
				{
					session.getChannel().close();
					ServerDataGS.transmitter.closeClientConnection(session.getPlayerId());
					ServerDataGS.sessions.remove(session.getPlayerId());
					if (session.getCorgiUID() != null)
					{
						offLine(session.getPlayerId(), session.getCorgiUID());
					}
				}
			}
			else if (session.getLastUpdateTime() < expiredTime)
			{
				ClientDisconnect.Builder clientDisconnect = ClientDisconnect.newBuilder();
				clientDisconnect.setPlayerId(session.getPlayerId());
				clientDisconnect.setResult(CommonConfigMgr.getInstance()
					.getValue("E_INTERFACE_CLIENT_DISCONNECT_TIME_OUT"));
				Protocol protocol = new Protocol(ClientProtocols.P_INTERFACE_IC_CLIENT_DISCONNECT);
				protocol.setProtoBufMessage(clientDisconnect.build());
				ServerDataGS.transmitter.sendAndClose(session.getChannel(), protocol);
				ServerDataGS.sessions.remove(session.getPlayerId());
				offLine(session.getPlayerId(), session.getCorgiUID());
			}
		}
	}

	@Override
	public void shutdownHook()
	{
		// 踢掉在线玩家
		for (Entry<Integer, ClientSession> entry : ServerDataGS.sessions.entrySet())
		{
			int playerId = entry.getKey();
			ClientSession session = entry.getValue();
			if(ServerDataGS.playerManager.isOnline(playerId))
			{
				ClientDisconnect.Builder clientDisconnect = ClientDisconnect.newBuilder();
				clientDisconnect.setPlayerId(playerId);
				clientDisconnect.setResult(CommonConfigMgr.getInstance().getValue("E_INTERFACE_CLIENT_DISCONNECT_MAINTENANCE"));
				Protocol protocol = new Protocol(ClientProtocols.P_INTERFACE_IC_CLIENT_DISCONNECT);
				protocol.setProtoBufMessage(clientDisconnect.build());
				ServerDataGS.transmitter.sendAndClose(session.getChannel(), protocol);
				offLine(playerId, session.getCorgiUID());
			}
		}
		logger.debug("all player has been kicked. player number : {}", ServerDataGS.sessions.size());
	}

	private void offLine(int playerId, CorgiUID corgiUID)
	{
		if(ServerDataGS.playerManager.isOnline(playerId))
		{
			ServerDataGS.playerManager.lockPlayer(playerId);
			try
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getMemoryPlayerNode(playerId);
				if (playerNode != null && playerNode.getPlayerInfo() != null)
				{
					LoginMessageMgr.updatePlayerLogoutTime(playerNode, System.currentTimeMillis());
					
					ConfigDatabase cd = CfgDB.getPlayerConfig(playerId);

					// 刷新玩家登陆累计天数
					StartServerRewardMgr.refreshDayCount(cd, playerNode);
					StartServerRewardMgr.updateStartServerRewardInfo(playerNode);
					
					//删除玩家相关小助手信息
					PlayerTimerMgr.getInstance().removePlayer(playerId);
					ObserverMgr.getInstance().removeObserver(playerId);
					
					ShowDialogPlayerIdMgr.getInstance().removeShowPlayerId(playerId);
					
					// 清除玩家CorgiUID
					playerNode.getPlayerInfo().getClientLoginMessage().setCorgiUID(null);
				}
			}
			catch(Exception e)
			{
				logger.error("PlayerId = {} /n {}", playerId, ExceptionUtils.getStackTrace(e));
			}
			finally
			{
				ServerDataGS.playerManager.unlockPlayer(playerId);
				ServerDataGS.playerManager.resetPlayerNode(playerId);
			}
		}
	}
}
