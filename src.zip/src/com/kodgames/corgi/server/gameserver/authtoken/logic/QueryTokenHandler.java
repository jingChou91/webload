/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.gameserver.authtoken.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.CorgiUID;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.core.ServerNode;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.AuthProtocolsForServer.AI_QueryTokenRes;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.InterfaceProtocolsForClient.IC_AuthTokenRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.server.common.TableSelect;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.ServerDataGS.SessionStatus;
import com.kodgames.corgi.server.gameserver.assistant.AssisantHelper;
import com.kodgames.corgi.server.gameserver.assistant.GreenPointHelper;
import com.kodgames.gamedata.baseinfo.BaseInfoConfigMgr;
import com.kodgames.gamedata.player.PlayerNode;

/**
 * 
 * @author koduser
 */
public class QueryTokenHandler extends MessageHandler
{

	private static final Logger logger = LoggerFactory.getLogger(QueryTokenHandler.class);

	@Override
	public HandlerAction handleServerMessage(ServerNode sender, Protocol message)
	{
		AI_QueryTokenRes request = (AI_QueryTokenRes)message.getProtoBufMessage();
		IC_AuthTokenRes.Builder authbuilder = IC_AuthTokenRes.newBuilder();
		Protocol authTokenProtocol = new Protocol(ClientProtocols.P_INTERFACE_IC_AUTH_TOKEN_RES);
		authbuilder.setCallback(request.getCallback());
		CorgiUID clientUID = new CorgiUID();
		logger.info("recv QueryTokenRes from authServer");

		ServerDataGS.ClientSession session = ServerDataGS.sessions.get(request.getPlayerId());
		if (session == null || session.getSeqId() != request.getSeqId())
		{
			logger.debug("QueryToken session is null ,request.getPlayerId() = {}", request.getPlayerId());
			return HandlerAction.TERMINAL;
		}

		int sequenceID = 0;
		if (request.getResult() == ClientProtocols.E_SERVER_PROC_ERROR)
		{
			logger.warn("E_SERVER_PROC_ERROR");
			authbuilder.setResult(ClientProtocols.E_SERVER_PROC_ERROR);
		}
		else if (request.getResult() == ClientProtocols.E_INTERFACE_AUTH_TOKEN_FAILED_EXPIRED)
		{
			logger.warn("E_INTERFACE_TOKEN_EXPIRED");
			authbuilder.setResult(ClientProtocols.E_INTERFACE_AUTH_TOKEN_FAILED_EXPIRED);
		}
		else if (request.getResult() == ClientProtocols.E_INTERFACE_AUTH_TOKEN_FAILED)
		{
			logger.warn("auth token failed");
			authbuilder.setResult(ClientProtocols.E_INTERFACE_AUTH_TOKEN_FAILED);
		}
		else if (!session.getToken().equals(request.getToken()))
		{
			logger.warn("Token is wrong");
			authbuilder.setResult(ClientProtocols.E_INTERFACE_AUTH_TOKEN_FAILED_INCORRECT_TOKEN);
		}
		else
		{
			boolean limitPass = true;
			// 人数限制
			if (BaseInfoConfigMgr.getInstance().getCfg().isLoginNumLimitOpen())
			{
				if (ServerDataGS.playerManager.getOnlinePlayerNum() >= BaseInfoConfigMgr.getInstance()
					.getCfg()
					.getMaxOnLine())
				{
					authbuilder.setResult(ClientProtocols.E_INTERFACE_AUTH_TOKEN_MAX_ONLINE_NUM);
					limitPass = false;
				}
				else if (ServerDataGS.udids.size() >= BaseInfoConfigMgr.getInstance().getCfg().getMaxDevice()
					&& !ServerDataGS.udids.contains(request.getDeviceInfo().getUDID()))
				{
					authbuilder.setResult(ClientProtocols.E_INTERFACE_AUTH_TOKEN_MAX_DEVICE_NUM);
					limitPass = false;
				}
				else if (TableSelect.playerIdxMax >= BaseInfoConfigMgr.getInstance().getCfg().getMaxAccount()
					&& !TableSelect.getAllPlayerIdx().containsKey(request.getPlayerId()))
				{
					authbuilder.setResult(ClientProtocols.E_INTERFACE_AUTH_TOKEN_MAX_ACCOUNT_NUM);
					limitPass = false;
				}

			}

			if (limitPass)
			{
				authbuilder.setResult(ClientProtocols.E_INTERFACE_AUTH_TOKEN_SUCCESS);

				clientUID.setPlayerID(request.getPlayerId());// playerId
				clientUID.setChannelUserName(request.getChannelUserName());
				clientUID.setDeviceInfo(request.getDeviceInfo());
				clientUID.setLoginTime(request.getLoginTime());
				clientUID.setIpMessage(request.getIpMessage());
				clientUID.setSequenceID(CorgiUID.getNextSeqId());
				sequenceID = clientUID.getSequenceId();
				clientUID.setChannelUniqueId(request.getChannelUniqueId());
				clientUID.setClientVersion(request.getClientVersion());
				clientUID.setMarketChannelId(request.getMarketChannelId());
				clientUID.setChannelId(request.getChannelId());
				// 记录当前GameServer的配置文件版本号
				clientUID.setServerXmlVersion(CfgDB.getVersion());

				session.setStatus(SessionStatus.verified_Connected);
				session.setCorgiUID(clientUID);
				session.setNormalPlayer(false);
				ServerDataGS.transmitter.addClientNode(clientUID, session.getChannel(), session.getClientAddress());
			}
		}

		IC_AuthTokenRes response = authbuilder.build();
		authTokenProtocol.setProtoBufMessage(response);

		if (authbuilder.getResult() != ClientProtocols.E_INTERFACE_AUTH_TOKEN_SUCCESS)
		{
			ServerDataGS.transmitter.send(session.getChannel(), authTokenProtocol);
		}
		else
		{
			// 玩家上线
			// 更新玩家的版本
			
			//验证Token成功后预先加载player
			ConfigDatabase cd = CfgDB.getDefautConfig();
			ServerDataGS.playerManager.getLocalPlayerInfo_Common(clientUID.getPlayerID(), CfgDB.getDefautConfig(), true, clientUID);
			ServerDataGS.playerManager.lockPlayer(clientUID.getPlayerID());
			try
			{
				PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(clientUID.getPlayerID());
				if(playerNode != null && playerNode.getPlayerInfo() != null)
				{
					// 小助手初始化
					AssisantHelper.initPlayerAssisant(playerNode, cd);
					
					// 小绿点初始化
					GreenPointHelper.initPlayerGreenPoint(playerNode, cd);
				}
			}
			finally
			{
				ServerDataGS.playerManager.unlockPlayer(clientUID.getPlayerID());
			}
			
			ServerDataGS.transmitter.send(session.getChannel(), authTokenProtocol);
		}
		return HandlerAction.TERMINAL;
	}
}
