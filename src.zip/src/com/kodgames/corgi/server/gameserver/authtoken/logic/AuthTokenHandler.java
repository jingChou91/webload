/*
   * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kodgames.corgi.server.gameserver.authtoken.logic;

import java.net.InetSocketAddress;
import java.net.SocketAddress;

import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ClientServerCommon.ConfigDatabase;

import com.kodgames.corgi.core.CorgiUID;
import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.gameconfiguration.AreaData;
import com.kodgames.corgi.gameconfiguration.CfgDB;
import com.kodgames.corgi.protocol.AuthProtocolsForServer.IA_QueryTokenReq;
import com.kodgames.corgi.protocol.ClientProtocols;
import com.kodgames.corgi.protocol.InterfaceProtocolsForClient.CI_AuthTokenReq;
import com.kodgames.corgi.protocol.InterfaceProtocolsForClient.ClientDisconnect;
import com.kodgames.corgi.protocol.InterfaceProtocolsForClient.IC_AuthTokenRes;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.Protocols;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.corgi.server.gameserver.ServerDataGS;
import com.kodgames.corgi.server.gameserver.ServerDataGS.ClientSession;
import com.kodgames.corgi.server.gameserver.ServerDataGS.SessionStatus;
import com.kodgames.corgi.server.gameserver.assistant.AssisantHelper;
import com.kodgames.corgi.server.gameserver.assistant.GreenPointHelper;
import com.kodgames.gamedata.commonconfig.CommonConfigMgr;
import com.kodgames.gamedata.player.PlayerNode;

/**
 * 
 * @author marui
 */
public class AuthTokenHandler extends MessageHandler {
	
	private static final Logger logger = LoggerFactory.getLogger(AuthTokenHandler.class);
	@Override
	public HandlerAction handleMessage(Channel channel,SocketAddress remoteAddress, Protocol message) {

		this.execute(channel, remoteAddress, message);
		return HandlerAction.TERMINAL;
	}

	private void execute(Channel channel, SocketAddress remoteAddress,Protocol message) {
		CI_AuthTokenReq request = (CI_AuthTokenReq) message.getProtoBufMessage();
	    //to  client
		IC_AuthTokenRes.Builder  authbuilder = IC_AuthTokenRes.newBuilder();
		Protocol authTokenProtocol = new Protocol(ClientProtocols.P_INTERFACE_IC_AUTH_TOKEN_RES);
	   //to authserver
		IA_QueryTokenReq.Builder querybuilder = IA_QueryTokenReq.newBuilder();
       //to authserver
		querybuilder.setCallback(request.getCallback());
		querybuilder.setPlayerId(request.getPlayerId());
		querybuilder.setAreaId(AreaData.getAreaId());
		querybuilder.setToken(request.getToken());
		
		logger.info("recv CI_AuthTokenReq, playerId = {}", request.getPlayerId());
		
		if(ServerDataGS.isOpen == false)
		{
			ClientDisconnect.Builder clientDisconnect = ClientDisconnect.newBuilder();
			clientDisconnect.setPlayerId(request.getPlayerId());
			clientDisconnect.setResult(CommonConfigMgr.getInstance().getValue("E_INTERFACE_CLIENT_DISCONNECT_MAINTENANCE"));
			Protocol protocol = new Protocol(ClientProtocols.P_INTERFACE_IC_CLIENT_DISCONNECT);
			protocol.setProtoBufMessage(clientDisconnect.build());
			ServerDataGS.transmitter.sendAndClose(channel, protocol);
			return;
		}
		

		ServerDataGS.ClientSession session = ServerDataGS.sessions.get(request.getPlayerId());
		String token=null;
		
		//Session不为空 并且Session已经验证过
		if (session != null &&( session.getStatus() == SessionStatus.verified_Connected ||  session.getStatus() == SessionStatus.verified_disconnected)) 
		{
			token = session.getToken();
		}
		
		// The session doesn't exist or a new login, so load the token from		
		if (token == null || !token.equals(request.getToken())) {
			
			logger.info("QueryToken to authServer");
			//一个区只有一个InterfaceServer
			//If the player login same area from a new device, should disconnected old device
			
            if(token != null && session.getStatus() == SessionStatus.verified_Connected)
            {
            	//踢掉目前的账号
                logger.info("disconnect playerId: {}", request.getPlayerId());
                
                //给客户端发消息
                ClientDisconnect.Builder clientDisconnect = ClientDisconnect.newBuilder();
                clientDisconnect.setPlayerId(request.getPlayerId());
                clientDisconnect.setResult(CommonConfigMgr.getInstance().getValue("E_INTERFACE_CLIENT_DISCONNECT_SAME_PLAYER_AUHT"));
        		Protocol protocol = new Protocol(ClientProtocols.P_INTERFACE_IC_CLIENT_DISCONNECT);
        		protocol.setProtoBufMessage(clientDisconnect.build());
        		ServerDataGS.transmitter.sendAndClose(session.getChannel(), protocol);
            }

	        //save token
			ServerDataGS.ClientSession clientsession= new ClientSession(request.getPlayerId(),request.getToken(),(InetSocketAddress)remoteAddress,channel);
			querybuilder.setSeqId(clientsession.getSeqId());
			ServerDataGS.ClientSession temp = ServerDataGS.sessions.put(clientsession.getPlayerId(), clientsession);
			if(session != null && temp != null && session.getChannel()!=temp.getChannel())
			{
				temp.getChannel().close();
			}

			ServerDataGS.transmitter.sendToServer(Protocols.PROTOCOL_TYPE_AUTH,request.getPlayerId(),ServerProtocols.P_AUTH_SERVER_QUERY_TOKEN_REQ, querybuilder.build());
			return;
		}
		
		logger.info("Token aleady exist in interfaceServer");
		session.setChannel(channel);
		session.setClientAddress((InetSocketAddress)remoteAddress);
		session.setStatus(SessionStatus.verified_Connected);
		session.getCorgiUID().setIpMessage(channel.getRemoteAddress().toString());
		session.getCorgiUID().setSequenceID(CorgiUID.getNextSeqId());
		session.setNormalPlayer(false);
		ServerDataGS.transmitter.addClientNode(session.getCorgiUID(),channel,remoteAddress);
		
		authbuilder.setResult(ClientProtocols.E_INTERFACE_AUTH_TOKEN_SUCCESS);
		authbuilder.setCallback(request.getCallback());
		IC_AuthTokenRes response = authbuilder.build();
		authTokenProtocol.setProtoBufMessage(response);
		
		
		
		//验证Token成功后预先加载player
		CorgiUID clientUID = session.getCorgiUID();
		ConfigDatabase cd = CfgDB.getDefautConfig();
		
		ServerDataGS.playerManager.getLocalPlayerInfo_Common(clientUID.getPlayerID(), CfgDB.getDefautConfig(), true, clientUID);
		ServerDataGS.playerManager.lockPlayer(clientUID.getPlayerID());
		try
		{
			PlayerNode playerNode = ServerDataGS.playerManager.getPlayerNode(clientUID.getPlayerID());
			if(playerNode != null && playerNode.getPlayerInfo() != null)
			{
				// 小助手初始化
				AssisantHelper.initPlayerAssisant(playerNode, cd);
				
				// 小绿点初始化
				GreenPointHelper.initPlayerGreenPoint(playerNode, cd);
			}
		}
		finally
		{
			ServerDataGS.playerManager.unlockPlayer(clientUID.getPlayerID());
		}
		
		ServerDataGS.transmitter.send(channel, authTokenProtocol);
	}
}