package com.kodgames.corgi.server.gameserver.authtoken;

import com.kodgames.corgi.core.Controller;
import com.kodgames.corgi.protocol.AuthProtocolsForServer;
import com.kodgames.corgi.protocol.ServerProtocols;
import com.kodgames.corgi.server.common.ServerUtil;
import com.kodgames.corgi.server.gameserver.authtoken.logic.QueryTokenHandler;

public class Logic_AuthTokenServer {
	private QueryTokenHandler queryTokenHandler = null;

	public void init() {	
		queryTokenHandler = new QueryTokenHandler();	
	}
	
	public void registerProtoBufType(Controller controller)
	{	
		controller.registerMessageLite(ServerProtocols.P_AUTH_SERVER_QUERY_TOKEN_RES,AuthProtocolsForServer.AI_QueryTokenRes.getDefaultInstance());
	}
	
	public void registerMessageHandler(Controller controller) 
	{	
		controller.addHandler(ServerProtocols.P_AUTH_SERVER_QUERY_TOKEN_RES,ServerUtil.getFacilityMessageHandlerFactory(queryTokenHandler));
	}
}
