package com.kodgames.corgi.gameconfiguration;

import ClientServerCommon.IMathParser;
import ClientServerCommon.IMathParserFactory;

/**
 *
 * @author Elvin
 */
public class MathParserFactory implements IMathParserFactory
{
	@Override
	public IMathParser CreateMathParser(String string) 
	{
		return (IMathParser) new MathParser(string);
	}
	
	public IMathParser CreateMathParser() 
	{
		return (IMathParser) new MathParser();
	}
}
