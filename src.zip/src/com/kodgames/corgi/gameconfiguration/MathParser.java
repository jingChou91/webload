package com.kodgames.corgi.gameconfiguration;

import java.util.Stack;

import org.nfunk.jep.JEP;
import org.nfunk.jep.Node;
import org.nfunk.jep.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class MathParser implements ClientServerCommon.IMathParser {
	private JEP parser;
	private String expression = "";
	private boolean bParsed = false;

	private static final Logger logger = LoggerFactory.getLogger(MathParser.class);

	public class Max extends org.nfunk.jep.function.PostfixMathCommand {
		public Max() {
			numberOfParameters = 2;
		}

		@Override
		public void run(Stack stack) throws ParseException {
			// check the stack
			checkStack(stack);

			// get the parameter from the stack
			Object paramOne = stack.pop();
			Object paramTwo = stack.pop();

			// check whether the argument is of the right type
			if (paramOne instanceof Double && paramTwo instanceof Double) {
				// calculate the result
				double result;
				if (((Double) paramOne).doubleValue() > ((Double) paramTwo).doubleValue()) {
					result = ((Double) paramOne).doubleValue();
				}
				else {
					result = ((Double) paramTwo).doubleValue();
				}

				// push the result on the inStack
				stack.push(new Double(result));
			}
			else {
				throw new ParseException("Invalid parameter type");
			}
		}
	}

	public class Min extends org.nfunk.jep.function.PostfixMathCommand {
		public Min() {
			numberOfParameters = 2;
		}

		@Override
		public void run(Stack stack) throws ParseException {
			// check the stack
			checkStack(stack);

			// get the parameter from the stack
			Object paramOne = stack.pop();
			Object paramTwo = stack.pop();

			// check whether the argument is of the right type
			if (paramOne instanceof Double && paramTwo instanceof Double) {
				// calculate the result
				double result;
				if (((Double) paramOne).doubleValue() < ((Double) paramTwo).doubleValue()) {
					result = ((Double) paramOne).doubleValue();
				}
				else {
					result = ((Double) paramTwo).doubleValue();
				}

				// push the result on the inStack
				stack.push(new Double(result));
			}
			else {
				throw new ParseException("Invalid parameter type");
			}
		}
	}

	public class Range extends org.nfunk.jep.function.PostfixMathCommand {
		public Range() {
			numberOfParameters = 3;
		}

		@Override
		public void run(Stack stack) throws ParseException {
			// check the stack
			checkStack(stack);

			// get the parameter from the stack
			Object param1 = stack.pop();
			Object param2 = stack.pop();
			Object param3 = stack.pop();

			// check whether the argument is of the right type
			if (param1 instanceof Double && param2 instanceof Double && param3 instanceof Double) {
				// calculate the result

				double result = 0;
				double value = (Double) param1;
				double min = (Double) param2;
				double max = (Double) param3;

				if (min > max) {
					double temp = min;
					min = max;
					max = temp;
				}

				if (value < min)
					result = min;
				else if (value > max)
					result = max;
				else
					result = value;

				stack.push(new Double(result));
			}
			else {
				throw new ParseException("Invalid parameter type");
			}
		}
	}

	public MathParser(String expression) {
		parser = new JEP();
		parser.addFunction("Max", new Max());
		parser.addFunction("Min", new Min());
		parser.addFunction("Range", new Range());
		parser.addStandardFunctions();
		parser.addStandardConstants();
		SetExpression(expression);
	}

	public MathParser() {
		parser = new JEP();
		parser.addFunction("Max", new Max());
		parser.addFunction("Min", new Min());
		parser.addFunction("Range", new Range());
		parser.addStandardFunctions();
		parser.addStandardConstants();
	}

	public JEP GetParser() {
		return parser;
	}

	@Override
	public void SetExpression(String expression) {
		this.expression = expression;
		this.bParsed = false;
	}

	@Override
	public String GetExpression() {
		return this.expression;
	}

	@Override
	public void SetVariable(String name, float value) {
		parser.addVariable(name, value);
	}

	@Override
	public void RemoveAllVariables() {

	}

	@Override
	public double Evaluate() {
		if (bParsed) {
			return parser.getValue();
		}
		else {
			Node node = parser.parseExpression(expression);
			if (node != null) {
				bParsed = true;
				double v = parser.getValue();
				return v;
			}
			else {
				logger.error("expression={} info={}", expression, parser.getErrorInfo());
				return 0;
			}
		}
	}
}
