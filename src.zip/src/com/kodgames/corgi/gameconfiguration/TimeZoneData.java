package com.kodgames.corgi.gameconfiguration;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class TimeZoneData {

	private static final Logger logger = LoggerFactory.getLogger(TimeZoneData.class);
	private static int timezone = -25;
	
	private TimeZoneData(){
		
	}
	
	public static void setTimezone(int timezone)
	{
		logger.warn("Set Timezone = {}", timezone);
		TimeZoneData.timezone = timezone;
	}
	
	public static int getTimeZone() 
	{
		if(timezone==-25)
		{
			logger.error("bad timezone\n{}",ExceptionUtils.getStackTrace(new Throwable()));
		}
		return timezone;
	}
	
}
