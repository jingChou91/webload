package com.kodgames.corgi.gameconfiguration;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.IMathParser;

public interface IExpressionObj {

	void setupVariable(IMathParser parser,ConfigDatabase cd);
}
