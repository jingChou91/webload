package com.kodgames.corgi.gameconfiguration;

import java.util.HashMap;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.IMathParser;

public class ExpressionCalc
{
	static HashMap<String, IMathParser> parsers = new HashMap<String, IMathParser>();

	public static synchronized double calcExpression(ConfigDatabase cd, String exp, IExpressionObj... args)
	{

		IMathParser parser = parsers.get(exp);
		if (parser == null)
		{
			parser = ConfigDatabase.get_MathParserFactory().CreateMathParser(exp);
			if (parser != null)
			{
				parsers.put(exp, parser);
			}
		}

		if (parser != null)
		{
			if (args != null)
			{
				for (IExpressionObj obj : args)
				{
					obj.setupVariable(parser, cd);
				}
			}
			return parser.Evaluate();
		}
		else
		{
			return 0;
		}
	}

	// 装备卖出价格公式=基础价格 *(1 + 突破等级)
	// BasicPrice * (1 + BreakThrough_Level)
	public static int getValue_EquipSellPrice(ConfigDatabase cd, IExpressionObj equipment)
	{
		return (int) Math.round(calcExpression(cd, cd.get_EquipmentConfig().get_sellPrice_Expression(), equipment));
	}

	// 角色卖出价格公式=基础价格 *(1 + 突破等级)
	// BasicPrice * (1 + BreakThrough_Level)
	public static int getValue_AvatarSellPrice(ConfigDatabase cd, IExpressionObj avatar)
	{
		return (int) Math.round(calcExpression(cd, cd.get_AvatarConfig().get_sellPrice_Expression(), avatar));
	}

}
