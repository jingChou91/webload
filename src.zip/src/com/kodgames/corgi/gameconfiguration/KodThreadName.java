package com.kodgames.corgi.gameconfiguration;

import java.util.concurrent.atomic.AtomicInteger;

public class KodThreadName {

	private static final AtomicInteger value = new AtomicInteger(1);
	
	public static String genName(String name){
		if(name!=null){
			return name+"_"+value.getAndIncrement();	
		}
		else{
			return "KOD_Thread"+"_"+value.getAndIncrement();
		}
	}
}
