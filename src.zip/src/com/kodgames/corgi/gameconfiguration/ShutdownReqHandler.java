package com.kodgames.corgi.gameconfiguration;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sun.misc.Signal;
import sun.misc.SignalHandler;

import com.kodgames.corgi.core.MessageHandler;
import com.kodgames.corgi.core.ServerNode;
import com.kodgames.corgi.protocol.Protocol;
import com.kodgames.corgi.protocol.Protocols;
import com.kodgames.corgi.server.common.BaseServerData;
import com.kodgames.corgi.server.common.LoopRunnable;
import com.kodgames.corgi.server.gameserver.ServerDataGS;

public class ShutdownReqHandler extends MessageHandler implements SignalHandler
{
	private static final Logger logger = LoggerFactory.getLogger(ShutdownReqHandler.class);
	
	private void shutdown()
	{
		logger.error("ShutdownReqHandler");

        if(Protocols.type(BaseServerData.transmitter.getLocalServerID()) == Protocols.SERVER_TYPE_GAME)
        {
        	ServerDataGS.isOpen = false;
    		try
    		{
    			Thread.sleep(2000);
    		}
    		catch (InterruptedException e)
    		{
    			logger.error(ExceptionUtils.getStackTrace(e));
    		}

    		// 必要线程关闭
    		LoopRunnable.shutdwonAll();
        }
        
		logger.error("all threads has been stopped.");
		System.exit(0);
	}

	@Override
	public HandlerAction handleServerMessage(ServerNode sender, Protocol message)
	{
        shutdown();
		return HandlerAction.TERMINAL;
	}

	@Override
	public void handle(Signal arg0) 
	{
		shutdown();
	}
}
