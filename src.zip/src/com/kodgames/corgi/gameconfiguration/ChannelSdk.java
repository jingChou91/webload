package com.kodgames.corgi.gameconfiguration;

public class ChannelSdk
{
	//畅游集成SDK
	public static final String CYAGGREGATE_APP_KEY = "1402474128866";
	public static final String CYAGGREGATE_APP_SECRETKEY = "e237590a518d405688da794d8c895b7c";
	
	public static final Integer CYCYAGGREGATE_Tag = 325;
	public static final Integer CYCYAGGREGATE_LOGINVERIFY_OPCODE = 10001;
	public static final Integer CYCYAGGREGATE_RECEIPTVERIFY_OPCODE = 5003;
	public static final Integer CYCYAGGREGATE_RECEIPTUPDATE_OPCODE = 5004;
	
	public static final String CMEG_APP_KEY = "4a08af2bfdd8dcccaec5fd635b65feff";
	
	//易幻appkey
	public static final String EFUN_APP_KEY = "E422700E605AD8DC17468E49114BF0EE";
	public static final String EFUN_APP_RECHARGE = "A22DD727CFA9F24DC4A930841F5B956E"; //充值的key
	
}
