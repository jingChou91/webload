package com.kodgames.corgi.gameconfiguration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientServerCommonLogger implements ClientServerCommon.ILogger {

	private static final Logger logger = LoggerFactory.getLogger(ClientServerCommonLogger.class);

	@Override
	public void Debug(Object arg0) {
		logger.debug(arg0.toString());
	}

	@Override
	public void Debug(String arg0, Object[] arg1) {
		logger.debug(arg0, arg1);
	}

	@Override
	public void Error(Object arg0) {
		logger.error(arg0.toString());
	}

	@Override
	public void Error(String arg0, Object[] arg1) {
		logger.error(arg0, arg1);
	}

	@Override
	public void Info(Object arg0) {
		logger.info(arg0.toString());
	}

	@Override
	public void Info(String arg0, Object[] arg1) {
		logger.info(arg0, arg1);
	}

	@Override
	public void Warn(Object arg0) {
		logger.warn(arg0.toString());
	}

	@Override
	public void Warn(String arg0, Object[] arg1) {
		logger.warn(arg0, arg1);
	}

}
