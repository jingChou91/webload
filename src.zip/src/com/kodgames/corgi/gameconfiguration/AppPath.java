package com.kodgames.corgi.gameconfiguration;

public class AppPath
{
	public static String PATH_conf_manager = "../conf_manager/";
	public static String file_NameBanWords;
	public static String file_gagBanWords;
	public static String file_playerNameConfig;
	public static String file_statistics;
	public static String file_common;
	public static String file_ManagerServerConfig;
	public static String file_AreaConfig;
	public static String file_DBServer;
	public static String file_BaseInfo;
	public static String file_notice;
	public static String file_ExchangeCode;
	public static String file_AppURL;
	public static String file_GateServerConfig;
	public static String file_PurchaseServer;

	public static String PATH_conf_client = "../conf_client/";
	public static String file_Battle_09000101;
	public static String file_Battle_09000102;

	public static String PATH_ConfigClientManifest = "../conf_client/ClientManifest/";
	public static String file_ClientManifest_Android;
	public static String file_ClientManifest_iPhone;

	public static String PATH_conf_common = "../conf_common/";
	public static String file_logback;
	public static String file_ManagerAddress;

	static
	{
		String tempValue = null;

		tempValue = getString("PATH_ConfigManager");
		if (tempValue != null)
			PATH_conf_manager = tempValue;

		tempValue = getString("PATH_ConfigCommon");
		if (tempValue != null)
			PATH_conf_common = tempValue;

		tempValue = getString("PATH_Configs");
		if (tempValue != null)
			PATH_conf_client = tempValue;
		
		tempValue = getString("PATH_ConfigClientManifest");
		if (tempValue != null)
			PATH_ConfigClientManifest = tempValue;

		file_logback =                              PATH_conf_common + "logback.xml";
		file_ManagerAddress =                       PATH_conf_common + "ManagerAddress.xml";
		
		file_NameBanWords =                         PATH_conf_manager + "NameBanWords.xml";
		file_gagBanWords =                          PATH_conf_manager + "GagBanWords.xml";
		file_playerNameConfig =                     PATH_conf_manager + "playerNameConfig.xml";
		file_statistics =                           PATH_conf_manager + "statistics.xml";
		file_common =                               PATH_conf_manager + "common.xml";
		file_AreaConfig =                           PATH_conf_manager + "AreaConfig.xml";
		file_DBServer =                             PATH_conf_manager + "DBServer.xml";
		file_ManagerServerConfig =                  PATH_conf_manager + "ManagerServerConfig.xml";
		file_BaseInfo =                             PATH_conf_manager + "BaseInfo.xml";
		file_notice =                               PATH_conf_manager + "notice.xml";
		file_ExchangeCode =                         PATH_conf_manager + "ExchangeCodeConfig.xml";
		file_AppURL=                                PATH_conf_manager + "AppURL.xml";
		file_GateServerConfig=                      PATH_conf_manager + "GateServer.xml";
		file_PurchaseServer = 						PATH_conf_manager + "PurchaseServer.xml";
		
		file_Battle_09000101=                       PATH_conf_client + "Battle_09000101.bytes";
		file_Battle_09000102=                       PATH_conf_client + "Battle_09000102.bytes";
		
		file_ClientManifest_Android =               PATH_ConfigClientManifest + "ClientManifest_Android.xml";
		file_ClientManifest_iPhone =                PATH_ConfigClientManifest + "ClientManifest_iPhone.xml";
	}

	public static String getString(String key)
	{
		String value = System.getProperty(key);
		return value;
	}
}
