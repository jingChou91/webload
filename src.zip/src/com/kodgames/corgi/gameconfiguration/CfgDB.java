package com.kodgames.corgi.gameconfiguration;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import ClientServerCommon.ConfigDatabase;
import ClientServerCommon.ConfigSetting;
import ClientServerCommon.Configuration;
import ClientServerCommon.FileLoader;

public class CfgDB
{
	private static ConfigDatabase cfg;
	private static AtomicInteger versionNow = new AtomicInteger(0);
	private final static ReentrantReadWriteLock rwlock = new ReentrantReadWriteLock();
	
	static
	{
		ConfigDatabase.AddLogger(new ClientServerCommonLogger());
		ConfigDatabase.Initialize(new MathParserFactory(), false, false);
	}

	public static void initialize(String _configPath)
	{
		ConfigDatabase cfgNew = CreateConfigDatabase(_configPath, Configuration._FileFormat.Xml);
		rwlock.writeLock().lock();
		try
		{
			cfg = cfgNew;
			ConfigDatabase.set_DefaultCfg(cfg);
			versionNow.incrementAndGet();
		}
		finally
		{
			rwlock.writeLock().unlock();
		}
		
	}

	public static void initialize(boolean needAddVersion)
	{
		ConfigDatabase cfgNew = CreateConfigDatabase(AppPath.PATH_conf_client, Configuration._FileFormat.XMLMemory);
		rwlock.writeLock().lock();
		try
		{
			cfg = cfgNew;
			ConfigDatabase.set_DefaultCfg(cfg);
			if(needAddVersion)
			{
				versionNow.incrementAndGet();
			}
		}
		finally
		{
			rwlock.writeLock().unlock();
		}
	}
	
	private static ConfigDatabase CreateConfigDatabase(String basePath, int fileFormat)
	{
		ConfigSetting cfgSetting = new ConfigSetting(fileFormat);

		cfgSetting.set_StringsConfig(basePath + "Text.xml");
		cfgSetting.set_GameConfig(basePath + "GameConfig.xml");
		cfgSetting.set_LevelConfig(basePath + "LevelConfig.xml");
		cfgSetting.set_SceneConfig(basePath + "SceneConfig.xml");
		cfgSetting.set_AvatarAssetConfig(basePath + "AvatarAssetConfig.xml");
		cfgSetting.set_AnimationConfig(basePath + "AnimationConfig.xml");
		cfgSetting.set_ActionConfig(basePath + "ActionConfig.xml");
		cfgSetting.set_EquipmentConfig(basePath + "EquipmentConfig.xml");
		cfgSetting.set_AvatarConfig(basePath + "AvatarConfig.xml");
		cfgSetting.set_NpcConfig(basePath + "NpcConfig.xml");
		cfgSetting.set_AssetDescConfig(basePath + "AssetDescConfig.xml");
		cfgSetting.set_ItemConfig(basePath + "ItemConfig.xml");
		cfgSetting.set_GoodConfig(basePath + "GoodConfig.xml");
		cfgSetting.set_GoodStatusConfig(basePath + "GoodStatusConfig.xml");
		cfgSetting.set_SkillConfig(basePath + "SkillConfig.xml");
		cfgSetting.set_CampaignConfig(basePath + "CampaignConfig.xml");
		cfgSetting.set_ArenaConfig(basePath + "ArenaConfig.xml");
		cfgSetting.set_DailySignInConfig(basePath + "DailySignInConfig.xml");
		cfgSetting.set_InitPlayerConfig(basePath + "InitPlayerConfig.xml");
		cfgSetting.set_RewardConfig(basePath + "RewardConfig.xml");
		cfgSetting.set_ActivityConfig(basePath + "ActivityConfig.xml");
		cfgSetting.set_PveConfig(basePath + "PveConfig.xml");
		cfgSetting.set_ClientManifest(basePath + "ClientManifest.xml");
		cfgSetting.set_AppleGoodConfig(basePath + "AppleGoodConfig.xml");
		cfgSetting.set_VipConfig(basePath + "VipConfig.xml");
		cfgSetting.set_LevelRewardConfig(basePath + "LevelRewardConfig.xml");
		cfgSetting.set_TavernConfig(basePath + "TavernConfig.xml");
		cfgSetting.set_TutorialConfig(basePath + "TutorialConfig.xml");
		cfgSetting.set_QuestConfig(basePath + "QuestConfig.xml");
		cfgSetting.set_GuideConfig(basePath + "GuideConfig.xml");
		cfgSetting.set_DialogueConfig(basePath + "DialogueConfig.xml");
		cfgSetting.set_LocalNotificationConfig(basePath + "LocalNotificationConfig.xml");
		cfgSetting.set_ExchangeConfig(basePath + "ExchangeConfig.xml");
		cfgSetting.set_FirstGetConfig(basePath + "FirstGetConfig.xml");
		cfgSetting.set_MeridianConfig(basePath + "MeridianConfig.xml");
		cfgSetting.set_StartServerRewardConfig(basePath + "StartServerRewardConfig.xml");
		cfgSetting.set_QuestionConfig(basePath + "QuestionConfig.xml");
		cfgSetting.set_CycleActivityConfig(basePath + "CycleActivityConfig.xml");
		cfgSetting.set_MysteryShopConfig(basePath + "MysteryShopConfig.xml");
		cfgSetting.set_PositionConfig(basePath + "PositionConfig.xml");
		cfgSetting.set_DomineerConfig(basePath + "DomineerConfig.xml");
		cfgSetting.set_PartnerConfig(basePath + "PartnerConfig.xml");
		cfgSetting.set_SuiteConfig(basePath + "SuiteConfig.xml");
		cfgSetting.set_DinerConfig(basePath + "DinerConfig.xml");
		cfgSetting.set_ChatAndMarqueeConfig(basePath + "ChatAndMarqueeConfig.xml");
		cfgSetting.set_IllustrationConfig(basePath + "IllustrationConfig.xml");
		cfgSetting.set_RobotConfig(basePath + "RobotConfig.xml");
		cfgSetting.set_LevelRewardConfig(basePath + "LevelRewardConfig.xml");
		cfgSetting.set_TaskConfig(basePath + "TaskConfig.xml");
		cfgSetting.set_MelaleucaFloorConfig(basePath + "MelaleucaFloorConfig.xml");
		cfgSetting.set_TreasureBowlConfig(basePath + "TreasureBowlConfig.xml");
		cfgSetting.set_MonthCardConfig(basePath+"MonthCardConfig.xml");
		cfgSetting.set_WolfSmokeConfig(basePath+"WolfSmokeConfig.xml");
		cfgSetting.set_SpecialGoodsConfig(basePath+"SpecialGoodsConfig.xml");
		cfgSetting.set_QinInfoConfig(basePath+"QinInfoConfig.xml");
		cfgSetting.set_OperationConfig(basePath + "OperationConfig.xml");
		cfgSetting.set_FriendConfig(basePath + "FriendConfig.xml");
		cfgSetting.set_MarvellousAdventureConfig(basePath + "MarvellousAdventureConfig.xml");
		cfgSetting.set_FriendCampaignConfig(basePath + "FriendCampaignConfig.xml");
		cfgSetting.set_AllPlayerGiftCounterConfig(basePath + "AllPlayerGiftCounterConfig.xml");
		cfgSetting.set_IllusionConfig(basePath + "IllusionConfig.xml");
		cfgSetting.set_MysteryerConfig(basePath + "MysteryerConfig.xml");
		cfgSetting.set_InviteCodeConfig(basePath + "InviteCodeConfig.xml");
		cfgSetting.set_FirstThreeDayConfig(basePath + "FirstThreeDayConfig.xml");
		cfgSetting.set_SevenElevenGiftConfig(basePath + "SevenElevenGiftConfig.xml");		
		cfgSetting.set_ZentiaConfig(basePath + "ZentiaConfig.xml");
		cfgSetting.set_DanConfig(basePath + "DanConfig.xml");
		cfgSetting.set_GuildConfig(basePath + "GuildConfig.xml");
		cfgSetting.set_GuildPublicShopConfig(basePath + "GuildPublicShopConfig.xml");
		cfgSetting.set_GuildPrivateShopConfig(basePath + "GuildPrivateShopConfig.xml");
		cfgSetting.set_GuildExchangeShopConfig(basePath + "GuildExchangeShopConfig.xml");
		cfgSetting.set_GuildStageConfig(basePath + "GuildStageConfig.xml");
		cfgSetting.set_PowerConfig(basePath + "PowerConfig.xml");
		cfgSetting.set_ChangeNameConfig(basePath + "ChangeNameConfig.xml");
		cfgSetting.set_BeastConfig(basePath + "BeastConfig.xml");
		ConfigDatabase cfgDB = new ConfigDatabase();
		cfgDB.LoadGameConfig(new FileLoader(), cfgSetting);

		return cfgDB;
	}

	public static ConfigDatabase getDefautConfig()
	{
		rwlock.readLock().lock();
		try
		{
			return CfgDB.cfg;
		}
		finally
		{
			rwlock.readLock().unlock();
		}
	}

	public static ConfigDatabase getPlayerConfig(int playerId)
	{
		rwlock.readLock().lock();
		try
		{
			return CfgDB.cfg;
		}
		finally
		{
			rwlock.readLock().unlock();
		}
	}
	
	public static int getVersion()
	{
		rwlock.readLock().lock();
		try
		{
			return versionNow.get();
		}
		finally
		{
			rwlock.readLock().unlock();
		}
	}
}